import Foundation
import Darwin

@_silgen_name("installIpa")
private func c_installIpa(_ ipaPath: NSString, _ force: Int8, _ useInstalldMethod: Int8, _ skipUICache: Int8) -> Int32

@_silgen_name("uninstallAppById")
private func c_uninstallAppById(_ appId: NSString, _ useCustomMethod: Int8) -> Int32

@_silgen_name("uninstallAppByPath")
private func c_uninstallAppByPath(_ appPath: NSString, _ useCustomMethod: Int8) -> Int32

@_silgen_name("registerPath")
private func c_registerPath(_ path: NSString, _ uninstall: Int8, _ asSystem: Int8) -> Int8

@_silgen_name("enableJIT")
private func c_enableJIT(_ appId: NSString) -> Int32

@_silgen_name("fixPermissionsOfAppBundle")
private func c_fixPermissionsOfAppBundle(_ path: NSString)

@_silgen_name("trollStoreAppPath")
private func c_trollStoreAppPath() -> NSString

@_silgen_name("trollStoreInstalledAppBundlePaths")
private func c_trollStoreInstalledAppBundlePaths() -> NSArray

public class AppManager {
    public static func installIPA(path: String, force: Bool, useInstalldMethod: Bool, skipUICache: Bool) throws {
        let ret = c_installIpa(path as NSString, force ? 1 : 0, useInstalldMethod ? 1 : 0, skipUICache ? 1 : 0)
        if ret != 0 {
            throw AppManagerError(code: ret)
        }
    }
    
    public static func uninstallApp(bundleId: String, useCustomMethod: Bool) throws {
        let ret = c_uninstallAppById(bundleId as NSString, useCustomMethod ? 1 : 0)
        if ret != 0 {
            throw AppManagerError(code: ret)
        }
    }
    
    public static func uninstallAppByPath(appPath: String, useCustomMethod: Bool) throws {
        let ret = c_uninstallAppByPath(appPath as NSString, useCustomMethod ? 1 : 0)
        if ret != 0 {
            throw AppManagerError(code: ret)
        }
    }
    
    public static func enableJIT(bundleId: String) throws {
        let ret = c_enableJIT(bundleId as NSString)
        if ret != 0 {
            throw AppManagerError(code: ret)
        }
    }
    
    public static func changeRegistration(appPath: String, isSystem: Bool) throws {
        let ret = c_registerPath(appPath as NSString, 0, isSystem ? 1 : 0)
        if ret == 0 {
            throw AppManagerError(code: -1)
        }
    }
    
    public static func getInstalledApps() -> [TrollStoreAppInfo] {
        var apps: [TrollStoreAppInfo] = []
        
        if let appPaths = c_trollStoreInstalledAppBundlePaths() as? [String] {
            for appPath in appPaths {
                if let appInfo = parseAppInfo(from: appPath) {
                    apps.append(appInfo)
                }
            }
        }
        
        return apps.sorted { $0.displayName < $1.displayName }
    }
    
    public static func openApp(bundleId: String) -> Bool {
        let workspace: AnyObject? = NSClassFromString("LSApplicationWorkspace")?.perform(NSSelectorFromString("defaultWorkspace"))?.takeUnretainedValue()
        if let ws = workspace {
            let selector = NSSelectorFromString("openApplicationWithBundleID:")
            if ws.responds(to: selector) {
                _ = ws.perform(selector, with: bundleId)
                return true
            }
        }
        return false
    }
    
    private static func parseAppInfo(from appPath: String) -> TrollStoreAppInfo? {
        let infoPlistPath = (appPath as NSString).appendingPathComponent("Info.plist")
        guard let infoDict = NSDictionary(contentsOfFile: infoPlistPath) as? [String: Any] else { return nil }
        
        let displayName = (infoDict["CFBundleDisplayName"] as? String) ?? (infoDict["CFBundleName"] as? String) ?? "Unknown"
        let bundleId = (infoDict["CFBundleIdentifier"] as? String) ?? ""
        let icon = loadAppIcon(from: appPath, infoDict: infoDict)
        let isSystem = isSystemRegistered(appPath: appPath)
        
        return TrollStoreAppInfo(
            displayName: displayName,
            bundleIdentifier: bundleId,
            appPath: appPath,
            icon: icon,
            isSystemRegistered: isSystem
        )
    }
    
    private static func loadAppIcon(from appPath: String, infoDict: [String: Any]) -> UIImage? {
        if let iconFiles = infoDict["CFBundleIcons"] as? [String: Any],
           let primaryIcon = iconFiles["CFBundlePrimaryIcon"] as? [String: Any],
           let iconFilesArray = primaryIcon["CFBundleIconFiles"] as? [String],
           let iconName = iconFilesArray.first {
            
            let iconPath = (appPath as NSString).appendingPathComponent(iconName)
            let extensions = ["", ".png", "@2x.png", "@3x.png"]
            
            for ext in extensions {
                let fullPath = iconPath + ext
                if let image = UIImage(contentsOfFile: fullPath) {
                    return image
                }
            }
        }
        
        return nil
    }
    
    private static func isSystemRegistered(appPath: String) -> Bool {
        let containerPath = (appPath as NSString).deletingLastPathComponent
        let markerPath = (containerPath as NSString).appendingPathComponent(".TrollStore")
        return FileManager.default.fileExists(atPath: markerPath)
    }
}

public struct AppManagerError: Error, LocalizedError {
    public let code: Int32
    
    public var errorDescription: String? {
        switch code {
        case 166: return NSLocalizedString("Error_166", comment: "")
        case 167: return NSLocalizedString("Error_167", comment: "")
        case 168: return NSLocalizedString("Error_168", comment: "")
        case 170: return NSLocalizedString("Error_170", comment: "")
        case 171: return NSLocalizedString("Error_171", comment: "")
        case 172: return NSLocalizedString("Error_172", comment: "")
        case 173: return NSLocalizedString("Error_173", comment: "")
        case 175: return NSLocalizedString("Error_175", comment: "")
        case 178: return NSLocalizedString("Error_178", comment: "")
        case 180: return NSLocalizedString("Error_180", comment: "")
        case 181: return NSLocalizedString("Error_181", comment: "")
        case 182: return NSLocalizedString("Error_182", comment: "")
        case 184: return NSLocalizedString("Error_184", comment: "")
        case 185: return NSLocalizedString("Error_185", comment: "")
        default: return NSLocalizedString("Error_Unknown", comment: "")
        }
    }
}
