import Foundation
import UIKit
import Darwin

public struct TrollStoreAppInfo {
    public let displayName: String
    public let bundleIdentifier: String
    public let appPath: String
    public let icon: UIImage?
    public let isSystemRegistered: Bool
}

public enum TrollStoreError: Error, LocalizedError {
    case spawnFailed
    case commandFailed(code: Int32)
    
    public var errorDescription: String? {
        switch self {
        case .spawnFailed: return NSLocalizedString("Spawn_Failed", comment: "")
        case .commandFailed(let code): return String(format: NSLocalizedString("Error_Code", comment: ""), code)
        }
    }
}

public class RootHelper {
    public static func execute(args: [String]) throws -> Int32 {
        let helperPath = (Bundle.main.bundlePath as NSString).appendingPathComponent("trollstorehelper")
        var argv: [UnsafeMutablePointer<CChar>?] = [strdup(helperPath)]
        argv.append(contentsOf: args.map { strdup($0) })
        argv.append(nil)
        defer {
            for ptr in argv {
                if let p = ptr { free(p) }
            }
        }
        var pid: pid_t = 0
        var status: Int32 = 0
        let spawnResult = argv.withUnsafeMutableBufferPointer { buffer -> Int32 in
            return posix_spawn(&pid, helperPath, nil, nil, buffer.baseAddress, nil)
        }
        if spawnResult != 0 { throw TrollStoreError.spawnFailed }
        waitpid(pid, &status, 0)
        let exited = (status & 0x7f) == 0
        let exitCode = Int32((status >> 8) & 0xff)
        if !exited { throw TrollStoreError.commandFailed(code: -1) }
        return exitCode
    }
    
    public static func ldid(args: [String]) throws -> Int32 {
        let ldidPath = (Bundle.main.bundlePath as NSString).appendingPathComponent("ldid")
        var argv: [UnsafeMutablePointer<CChar>?] = [strdup(ldidPath)]
        argv.append(contentsOf: args.map { strdup($0) })
        argv.append(nil)
        defer {
            for ptr in argv {
                if let p = ptr { free(p) }
            }
        }
        var pid: pid_t = 0
        var status: Int32 = 0
        let spawnResult = argv.withUnsafeMutableBufferPointer { buffer -> Int32 in
            return posix_spawn(&pid, ldidPath, nil, nil, buffer.baseAddress, nil)
        }
        if spawnResult != 0 { throw TrollStoreError.spawnFailed }
        waitpid(pid, &status, 0)
        let exited = (status & 0x7f) == 0
        let exitCode = Int32((status >> 8) & 0xff)
        if !exited { throw TrollStoreError.commandFailed(code: -1) }
        return exitCode
    }
}

public class AppManager {
    public static func installIPA(path: String, force: Bool, useInstalldMethod: Bool, skipUICache: Bool) throws {
        var args = ["install"]
        if useInstalldMethod { args.append("installd") }
        if force { args.append("force") }
        if skipUICache { args.append("skip-uicache") }
        args.append(path)
        let ret = try RootHelper.execute(args: args)
        if ret != 0 { throw TrollStoreError.commandFailed(code: ret) }
    }
    
    public static func uninstallApp(bundleId: String, useCustomMethod: Bool) throws {
        var args = ["uninstall"]
        if useCustomMethod { args.append("custom") }
        args.append(bundleId)
        let ret = try RootHelper.execute(args: args)
        if ret != 0 { throw TrollStoreError.commandFailed(code: ret) }
    }
    
    public static func enableJIT(bundleId: String) throws {
        let ret = try RootHelper.execute(args: ["enable-jit", bundleId])
        if ret != 0 { throw TrollStoreError.commandFailed(code: ret) }
    }
    
    public static func changeRegistration(appPath: String, isSystem: Bool) throws {
        let registration = isSystem ? "System" : "User"
        let ret = try RootHelper.execute(args: ["modify-registration", appPath, registration])
        if ret != 0 { throw TrollStoreError.commandFailed(code: ret) }
    }
    
    public static func getInstalledApps() -> [TrollStoreAppInfo] {
        var apps: [TrollStoreAppInfo] = []
        let fm = FileManager.default
        let appsPath = "/var/containers/Bundle/Application"
        guard let contents = try? fm.contentsOfDirectory(atPath: appsPath) else { return apps }
        for item in contents {
            let appContainerPath = (appsPath as NSString).appendingPathComponent(item)
            var isDir: ObjCBool = false
            if fm.fileExists(atPath: appContainerPath, isDirectory: &isDir) && isDir.boolValue {
                let markerPath = (appContainerPath as NSString).appendingPathComponent(".TrollStore")
                if fm.fileExists(atPath: markerPath) {
                    if let appPath = findAppPath(in: appContainerPath) {
                        if let appInfo = parseAppInfo(from: appPath) {
                            apps.append(appInfo)
                        }
                    }
                }
            }
        }
        return apps.sorted { $0.displayName < $1.displayName }
    }
    
    public static func openApp(bundleId: String) -> Bool {
        guard let cls = NSClassFromString("LSApplicationWorkspace") as? NSObject.Type else { return false }
        let workspace: AnyObject? = cls.perform(NSSelectorFromString("defaultWorkspace"))?.takeUnretainedValue()
        if let ws = workspace {
            let selector = NSSelectorFromString("openApplicationWithBundleID:")
            if ws.responds(to: selector) {
                _ = ws.perform(selector, with: bundleId)
                return true
            }
        }
        return false
    }
    
    private static func findAppPath(in containerPath: String) -> String? {
        let fm = FileManager.default
        guard let contents = try? fm.contentsOfDirectory(atPath: containerPath) else { return nil }
        for item in contents {
            if item.hasSuffix(".app") {
                let appPath = (containerPath as NSString).appendingPathComponent(item)
                var isDir: ObjCBool = false
                if fm.fileExists(atPath: appPath, isDirectory: &isDir) && isDir.boolValue {
                    return appPath
                }
            }
        }
        return nil
    }
    
    private static func parseAppInfo(from appPath: String) -> TrollStoreAppInfo? {
        let infoPlistPath = (appPath as NSString).appendingPathComponent("Info.plist")
        guard let infoDict = NSDictionary(contentsOfFile: infoPlistPath) as? [String: Any] else { return nil }
        let displayName = (infoDict["CFBundleDisplayName"] as? String) ?? (infoDict["CFBundleName"] as? String) ?? "Unknown"
        let bundleId = (infoDict["CFBundleIdentifier"] as? String) ?? ""
        let icon = loadAppIcon(from: appPath, infoDict: infoDict)
        let isSystem = isSystemRegistered(appPath: appPath)
        return TrollStoreAppInfo(
            displayName: displayName,
            bundleIdentifier: bundleId,
            appPath: appPath,
            icon: icon,
            isSystemRegistered: isSystem
        )
    }
    
    private static func loadAppIcon(from appPath: String, infoDict: [String: Any]) -> UIImage? {
        if let iconFiles = infoDict["CFBundleIcons"] as? [String: Any],
           let primaryIcon = iconFiles["CFBundlePrimaryIcon"] as? [String: Any],
           let iconFilesArray = primaryIcon["CFBundleIconFiles"] as? [String],
           let iconName = iconFilesArray.first {
            let iconPath = (appPath as NSString).appendingPathComponent(iconName)
            let extensions = ["", ".png", "@2x.png", "@3x.png"]
            for ext in extensions {
                let fullPath = iconPath + ext
                if let image = UIImage(contentsOfFile: fullPath) {
                    return image
                }
            }
        }
        return nil
    }
    
    private static func isSystemRegistered(appPath: String) -> Bool {
        let containerPath = (appPath as NSString).deletingLastPathComponent
        let markerPath = (containerPath as NSString).appendingPathComponent(".TrollStore")
        return FileManager.default.fileExists(atPath: markerPath)
    }
}
