import Foundation
import UIKit

public struct TrollStoreAppInfo {
    public let displayName: String
    public let bundleIdentifier: String
    public let appPath: String
    public let icon: UIImage?
    public let isSystemRegistered: Bool
    public let size: UInt64
    public let creationDate: Date
}

public class AppManager {
    private static let iconCache = NSCache<NSString, UIImage>()

    public static func getInstalledApps() -> [TrollStoreAppInfo] {
        var apps: [TrollStoreAppInfo] = []
        let fm = FileManager.default
        let appsRoot = TrollStorePaths.applicationsPath
        guard let containerDirs = try? fm.contentsOfDirectory(atPath: appsRoot) else { return apps }
        for containerDir in containerDirs {
            let containerPath = (appsRoot as NSString).appendingPathComponent(containerDir)
            var isDir: ObjCBool = false
            if fm.fileExists(atPath: containerPath, isDirectory: &isDir) && isDir.boolValue {
                if let appPath = findAppPath(in: containerPath) {
                    if let info = parseAppInfo(from: appPath, containerPath: containerPath) {
                        apps.append(info)
                    }
                }
            }
        }
        return apps
    }

    public static func openApp(bundleId: String) -> Bool {
        guard let cls = NSClassFromString("LSApplicationWorkspace") as? NSObject.Type else { return false }
        guard let workspace = cls.perform(NSSelectorFromString("defaultWorkspace"))?.takeUnretainedValue() as? NSObject else { return false }
        let selector = NSSelectorFromString("openApplicationWithBundleID:")
        guard workspace.responds(to: selector) else { return false }
        _ = workspace.perform(selector, with: bundleId)
        return true
    }

    private static func findAppPath(in containerPath: String) -> String? {
        let fm = FileManager.default
        guard let contents = try? fm.contentsOfDirectory(atPath: containerPath) else { return nil }
        for item in contents {
            if item.hasSuffix(".app") {
                let appPath = (containerPath as NSString).appendingPathComponent(item)
                var isDir: ObjCBool = false
                if fm.fileExists(atPath: appPath, isDirectory: &isDir) && isDir.boolValue {
                    return appPath
                }
            }
        }
        return nil
    }

    private static func parseAppInfo(from appPath: String, containerPath: String) -> TrollStoreAppInfo? {
        let fm = FileManager.default
        let infoPlistPath = (appPath as NSString).appendingPathComponent("Info.plist")
        guard let infoDict = NSDictionary(contentsOfFile: infoPlistPath) as? [String: Any] else { return nil }
        let displayName = (infoDict["CFBundleDisplayName"] as? String) ?? (infoDict["CFBundleName"] as? String) ?? ((appPath as NSString).lastPathComponent as NSString).deletingPathExtension
        let bundleId = (infoDict["CFBundleIdentifier"] as? String) ?? ""
        let icon = loadAppIcon(from: appPath, infoDict: infoDict, bundleId: bundleId)
        let isSystem = isSystemRegistered(containerPath: containerPath)
        let attributes = try? fm.attributesOfItem(atPath: appPath)
        let size = attributes?[.size] as? UInt64 ?? 0
        let creationDate = attributes?[.creationDate] as? Date ?? Date.distantPast
        return TrollStoreAppInfo(
            displayName: displayName,
            bundleIdentifier: bundleId,
            appPath: appPath,
            icon: icon,
            isSystemRegistered: isSystem,
            size: size,
            creationDate: creationDate
        )
    }

    private static func isSystemRegistered(containerPath: String) -> Bool {
        let marker = (containerPath as NSString).appendingPathComponent(TrollStorePaths.activeMarker)
        let inactive = (containerPath as NSString).appendingPathComponent(TrollStorePaths.inactiveMarker)
        let fm = FileManager.default
        if fm.fileExists(atPath: inactive) { return false }
        return fm.fileExists(atPath: marker)
    }

    private static func loadAppIcon(from appPath: String, infoDict: [String: Any], bundleId: String) -> UIImage? {
        let key = bundleId as NSString
        if let cached = iconCache.object(forKey: key) {
            return cached
        }
        var iconName: String?
        if let icons = infoDict["CFBundleIcons"] as? [String: Any],
           let primary = icons["CFBundlePrimaryIcon"] as? [String: Any] {
            if let name = primary["CFBundleIconName"] as? String {
                iconName = name
            } else if let files = primary["CFBundleIconFiles"] as? [String], let first = files.first, let last = files.last {
                iconName = first.commonPrefix(with: last)
            }
        }
        if iconName == nil, let icons = infoDict["CFBundleIcons~ipad"] as? [String: Any],
           let primary = icons["CFBundlePrimaryIcon"] as? [String: Any] {
            if let name = primary["CFBundleIconName"] as? String {
                iconName = name
            } else if let files = primary["CFBundleIconFiles"] as? [String], let first = files.first, let last = files.last {
                iconName = first.commonPrefix(with: last)
            }
        }
        guard let baseName = iconName else { return nil }
        let fm = FileManager.default
        guard let contents = try? fm.contentsOfDirectory(atPath: appPath) else { return nil }
        var candidates: [String] = []
        for item in contents {
            if item.hasPrefix(baseName) && (item.hasSuffix(".png") || (item as NSString).pathExtension.isEmpty) {
                candidates.append(item)
            }
        }
        candidates.sort()
        for candidate in candidates.reversed() {
            let fullPath = (appPath as NSString).appendingPathComponent(candidate)
            if let image = UIImage(contentsOfFile: fullPath) {
                iconCache.setObject(image, forKey: key)
                return image
            }
        }
        return nil
    }
}
