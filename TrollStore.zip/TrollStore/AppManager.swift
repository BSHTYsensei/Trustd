import Foundation
import UIKit
import Darwin

@_silgen_name("trollStoreInstalledAppBundlePaths")
func trollStoreInstalledAppBundlePaths() -> NSArray

@_silgen_name("trollStoreAppPath")
func trollStoreAppPath() -> NSString

@_silgen_name("shouldRegisterAsUserByDefault")
func shouldRegisterAsUserByDefault() -> Bool

@_silgen_name("isRemovableSystemApp")
func isRemovableSystemApp(_ bundleID: NSString) -> Bool

@_silgen_name("killall")
func killall(_ process: NSString, _ graceful: Bool)

public func respring() {
    killall("backboardd", true)
}

public struct TrollStoreAppInfo {
    public let displayName: String
    public let bundleIdentifier: String
    public let appPath: String
    public let icon: UIImage?
    public let isSystemRegistered: Bool
}

public enum TrollStoreError: Error, LocalizedError {
    case spawnFailed
    case commandFailed(code: Int32)

    public var errorDescription: String? {
        switch self {
        case .spawnFailed: return NSLocalizedString("Spawn_Failed", comment: "")
        case .commandFailed(let code): return String(format: NSLocalizedString("Error_Code", comment: ""), code)
        }
    }
}

public class RootHelper {
    public static func execute(args: [String]) throws -> Int32 {
        let helperPath = (Bundle.main.bundlePath as NSString).appendingPathComponent(TrollStorePaths.helperName)
        var argv: [UnsafeMutablePointer<CChar>?] = [strdup(helperPath)]
        argv.append(contentsOf: args.map { strdup($0) })
        argv.append(nil)
        defer {
            for ptr in argv {
                if let p = ptr { free(p) }
            }
        }
        var pid: pid_t = 0
        var status: Int32 = 0
        let spawnResult = argv.withUnsafeMutableBufferPointer { buffer -> Int32 in
            return posix_spawn(&pid, helperPath, nil, nil, buffer.baseAddress, nil)
        }
        if spawnResult != 0 { throw TrollStoreError.spawnFailed }
        waitpid(pid, &status, 0)
        let exited = (status & 0x7f) == 0
        let exitCode = Int32((status >> 8) & 0xff)
        if !exited { throw TrollStoreError.commandFailed(code: -1) }
        return exitCode
    }

    public static func ldid(args: [String]) throws -> Int32 {
        let ldidPath = (Bundle.main.bundlePath as NSString).appendingPathComponent(TrollStorePaths.ldidName)
        var argv: [UnsafeMutablePointer<CChar>?] = [strdup(ldidPath)]
        argv.append(contentsOf: args.map { strdup($0) })
        argv.append(nil)
        defer {
            for ptr in argv {
                if let p = ptr { free(p) }
            }
        }
        var pid: pid_t = 0
        var status: Int32 = 0
        let spawnResult = argv.withUnsafeMutableBufferPointer { buffer -> Int32 in
            return posix_spawn(&pid, ldidPath, nil, nil, buffer.baseAddress, nil)
        }
        if spawnResult != 0 { throw TrollStoreError.spawnFailed }
        waitpid(pid, &status, 0)
        let exited = (status & 0x7f) == 0
        let exitCode = Int32((status >> 8) & 0xff)
        if !exited { throw TrollStoreError.commandFailed(code: -1) }
        return exitCode
    }
}

public class AppManager {
    public static func installIPA(path: String, force: Bool, useInstalldMethod: Bool, skipUICache: Bool) throws {
        var args = [TrollStoreCommands.install]
        if useInstalldMethod { args.append("installd") }
        if force { args.append("force") }
        if skipUICache { args.append("skip-uicache") }
        args.append(path)
        let ret = try RootHelper.execute(args: args)
        if ret != 0 { throw TrollStoreError.commandFailed(code: ret) }
    }

    public static func uninstallApp(bundleId: String, useCustomMethod: Bool) throws {
        var args = [TrollStoreCommands.uninstall]
        if useCustomMethod { args.append("custom") }
        args.append(bundleId)
        let ret = try RootHelper.execute(args: args)
        if ret != 0 { throw TrollStoreError.commandFailed(code: ret) }
    }

    public static func enableJIT(bundleId: String) throws {
        let ret = try RootHelper.execute(args: [TrollStoreCommands.enableJIT, bundleId])
        if ret != 0 { throw TrollStoreError.commandFailed(code: ret) }
    }

    public static func changeRegistration(appPath: String, isSystem: Bool) throws {
        let registration = isSystem ? "System" : "User"
        let ret = try RootHelper.execute(args: [TrollStoreCommands.modifyRegistration, appPath, registration])
        if ret != 0 { throw TrollStoreError.commandFailed(code: ret) }
    }

    public static func getInstalledApps() -> [TrollStoreAppInfo] {
        var apps: [TrollStoreAppInfo] = []
        guard let paths = trollStoreInstalledAppBundlePaths() as? [String] else { return apps }
        for appPath in paths {
            if let appInfo = parseAppInfo(from: appPath) {
                apps.append(appInfo)
            }
        }
        return apps.sorted { $0.displayName.localizedStandardCompare($1.displayName) == .orderedAscending }
    }

    public static func openApp(bundleId: String) -> Bool {
        guard let cls = NSClassFromString("LSApplicationWorkspace") as? NSObject.Type else { return false }
        let workspace: AnyObject? = cls.perform(NSSelectorFromString("defaultWorkspace"))?.takeUnretainedValue()
        if let ws = workspace {
            let selector = NSSelectorFromString("openApplicationWithBundleID:")
            if ws.responds(to: selector) {
                _ = ws.perform(selector, with: bundleId)
                return true
            }
        }
        return false
    }

    public static func isSystemRegistered(appPath: String) -> Bool {
        let containerPath = (appPath as NSString).deletingLastPathComponent
        let markerPath = (containerPath as NSString).appendingPathComponent(TrollStorePaths.activeMarker)
        if FileManager.default.fileExists(atPath: markerPath) {
            return !shouldRegisterAsUserByDefault()
        }
        return false
    }

    private static func parseAppInfo(from appPath: String) -> TrollStoreAppInfo? {
        let infoPlistPath = (appPath as NSString).appendingPathComponent("Info.plist")
        guard let infoDict = NSDictionary(contentsOfFile: infoPlistPath) as? [String: Any] else { return nil }
        let displayName = (infoDict["CFBundleDisplayName"] as? String) ?? (infoDict["CFBundleName"] as? String) ?? ((appPath as NSString).lastPathComponent as NSString).deletingPathExtension
        let bundleId = (infoDict["CFBundleIdentifier"] as? String) ?? ""
        let icon = loadAppIcon(from: appPath, infoDict: infoDict)
        let isSystem = isSystemRegistered(appPath: appPath)
        return TrollStoreAppInfo(
            displayName: displayName,
            bundleIdentifier: bundleId,
            appPath: appPath,
            icon: icon,
            isSystemRegistered: isSystem
        )
    }

    private static func loadAppIcon(from appPath: String, infoDict: [String: Any]) -> UIImage? {
        var iconName: String?
        if let icons = infoDict["CFBundleIcons"] as? [String: Any],
           let primary = icons["CFBundlePrimaryIcon"] as? [String: Any] {
            if let name = primary["CFBundleIconName"] as? String {
                iconName = name
            } else if let files = primary["CFBundleIconFiles"] as? [String], let first = files.first, let last = files.last {
                iconName = first.commonPrefix(with: last)
            }
        }
        if iconName == nil, let icons = infoDict["CFBundleIcons~ipad"] as? [String: Any],
           let primary = icons["CFBundlePrimaryIcon"] as? [String: Any] {
            if let name = primary["CFBundleIconName"] as? String {
                iconName = name
            } else if let files = primary["CFBundleIconFiles"] as? [String], let first = files.first, let last = files.last {
                iconName = first.commonPrefix(with: last)
            }
        }
        guard let baseName = iconName else { return nil }
        let fm = FileManager.default
        guard let contents = try? fm.contentsOfDirectory(atPath: appPath) else { return nil }
        var candidates: [String] = []
        for item in contents {
            if item.hasPrefix(baseName) && (item.hasSuffix(".png") || (item as NSString).pathExtension.isEmpty) {
                candidates.append(item)
            }
        }
        candidates.sort()
        for candidate in candidates.reversed() {
            let fullPath = (appPath as NSString).appendingPathComponent(candidate)
            if let image = UIImage(contentsOfFile: fullPath) {
                return image
            }
        }
        return nil
    }
}