import Foundation
import Security

public struct TrollStoreInstallError: Error, LocalizedError {
    public let code: Int32
    public var errorDescription: String? {
        return NSLocalizedString("Error_\(code)", comment: "")
    }
}

public func dumpEntitlements(binaryPath: String) -> [String: Any]? {
    let url = URL(fileURLWithPath: binaryPath) as CFURL
    var staticCode: SecStaticCode?
    let status = SecStaticCodeCreateWithPath(url, SecCSFlags(rawValue: 0), &staticCode)
    if status != errSecSuccess || staticCode == nil { return nil }
    
    var info: CFDictionary?
    let infoStatus = SecCodeCopySigningInformation(staticCode!, SecCSFlags(rawValue: kSecCSSigningInformation), &info)
    if infoStatus != errSecSuccess || info == nil { return nil }
    
    let dict = info! as NSDictionary
    if let entData = dict[kSecCodeInfoEntitlementsDict as String] as? [String: Any] {
        return entData
    }
    return nil
}

public func setEntitlements(binaryPath: String, entitlements: [String: Any]) throws {
    let entitlementsData = try PropertyListSerialization.data(fromPropertyList: entitlements, format: .xml, options: 0)
    let tempPath = NSTemporaryDirectory().appending(UUID().uuidString).appending(".plist")
    try entitlementsData.write(to: URL(fileURLWithPath: tempPath))
    let ret = try RootHelper.ldid(args: ["-S\(tempPath)", binaryPath])
    try? FileManager.default.removeItem(atPath: tempPath)
    if ret != 0 { throw TrollStoreInstallError(code: 175) }
}

public func setEntitlementsForApp(appPath: String, entitlements: [String: Any]) throws {
    let fm = FileManager.default
    guard let enumerator = fm.enumerator(atPath: appPath) else { return }
    while let element = enumerator.nextObject() as? String {
        if (element as NSString).lastPathComponent == "Info.plist" {
            let infoPlistPath = (appPath as NSString).appendingPathComponent(element)
            guard let infoDict = NSDictionary(contentsOfFile: infoPlistPath) as? [String: Any] else { continue }
            guard let executable = infoDict["CFBundleExecutable"] as? String, !executable.isEmpty else { continue }
            let packageType = infoDict["CFBundlePackageType"] as? String
            if packageType == "FMWK" { continue }
            let binaryDir = (infoPlistPath as NSString).deletingLastPathComponent
            let binaryPath = (binaryDir as NSString).appendingPathComponent(executable)
            if fm.fileExists(atPath: binaryPath) {
                try setEntitlements(binaryPath: binaryPath, entitlements: entitlements)
            }
        }
    }
}

public func getTrollStoreAppPath() -> String {
    return Bundle.main.bundlePath
}
