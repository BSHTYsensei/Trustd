import Foundation
import Darwin

enum TrollStorePaths {
    static let rootPath = "/var/containers/Bundle/TrollStore"
    static let applicationsPath = "/var/containers/Bundle/TrollStore/Applications"
    static let activeMarker = ".TrollStore"
    static let inactiveMarker = ".TrollStoreInactive"
    static let ldidName = "ldid"
    static let helperName = "trollstorehelper"
    static let extraEntitlementsName = "entitlements.plist"
}

enum TrollStoreCommands {
    static let install = "install"
    static let uninstall = "uninstall"
    static let refresh = "refresh"
    static let refreshAll = "refresh-all"
    static let urlScheme = "url-scheme"
    static let respring = "respring"
    static let enableJIT = "enable-jit"
    static let modifyRegistration = "modify-registration"
    static let installTrollStore = "install-trollstore"
    static let uninstallTrollStore = "uninstall-trollstore"
    static let installPersistenceHelper = "install-persistence-helper"
}

enum TrollStoreDefaults {
    static let installationMethod = "installationMethod"
    static let uninstallationMethod = "uninstallationMethod"
    static let installAlertConfiguration = "installAlertConfiguration"
    static let autoInitLdid = "autoInitLdid"
    static let urlSchemeEnabled = "urlSchemeEnabled"
}

public struct TrollStoreInstallError: Error, LocalizedError {
    public let code: Int32

    public var errorDescription: String? {
        return TrollStoreInstallError.description(for: code)
    }

    public static func description(for code: Int32) -> String {
        switch code {
        case 166: return NSLocalizedString("Error_166", comment: "")
        case 167: return NSLocalizedString("Error_167", comment: "")
        case 168: return NSLocalizedString("Error_168", comment: "")
        case 169: return NSLocalizedString("Error_169", comment: "")
        case 170: return NSLocalizedString("Error_170", comment: "")
        case 171: return NSLocalizedString("Error_171", comment: "")
        case 172: return NSLocalizedString("Error_172", comment: "")
        case 173: return NSLocalizedString("Error_173", comment: "")
        case 174: return NSLocalizedString("Error_174", comment: "")
        case 175: return NSLocalizedString("Error_175", comment: "")
        case 176: return NSLocalizedString("Error_176", comment: "")
        case 177: return NSLocalizedString("Error_177", comment: "")
        case 178: return NSLocalizedString("Error_178", comment: "")
        case 179: return NSLocalizedString("Error_179", comment: "")
        case 180: return NSLocalizedString("Error_180", comment: "")
        case 181: return NSLocalizedString("Error_181", comment: "")
        case 182: return NSLocalizedString("Error_182", comment: "")
        case 183: return NSLocalizedString("Error_183", comment: "")
        case 184: return NSLocalizedString("Error_184", comment: "")
        case 185: return NSLocalizedString("Error_185", comment: "")
        default: return NSLocalizedString("Error_Unknown", comment: "")
        }
    }
}

public class RootHelper {
    public static func execute(args: [String]) throws -> Int32 {
        let helperPath = (Bundle.main.bundlePath as NSString).appendingPathComponent(TrollStorePaths.helperName)
        return try runProcess(helperPath, args, captureOutput: false).0
    }

    public static func executeCapturingOutput(args: [String]) throws -> (Int32, Data) {
        let helperPath = (Bundle.main.bundlePath as NSString).appendingPathComponent(TrollStorePaths.helperName)
        return try runProcess(helperPath, args, captureOutput: true)
    }

    public static func runProcess(_ executable: String, _ args: [String], workingDirectory: String? = nil, captureOutput: Bool) throws -> (Int32, Data) {
        var argv: [UnsafeMutablePointer<CChar>?] = [strdup(executable)]
        argv.append(contentsOf: args.map { strdup($0) })
        argv.append(nil)
        defer {
            for ptr in argv {
                if let p = ptr {
                    free(p)
                }
            }
        }
        var pipefd: [Int32] = [0, 0]
        var action: posix_spawn_file_actions_t?
        if posix_spawn_file_actions_init(&action) != 0 {
            throw TrollStoreInstallError(code: -1)
        }
        defer {
            _ = posix_spawn_file_actions_destroy(&action)
        }
        if let workingDirectory = workingDirectory {
            if posix_spawn_file_actions_addchdir_np(&action, workingDirectory) != 0 {
                throw TrollStoreInstallError(code: -1)
            }
        }
        if captureOutput {
            if pipe(&pipefd) != 0 {
                throw TrollStoreInstallError(code: -1)
            }
            if posix_spawn_file_actions_adddup2(&action, pipefd[1], 1) != 0 {
                _ = close(pipefd[0])
                _ = close(pipefd[1])
                throw TrollStoreInstallError(code: -1)
            }
            if posix_spawn_file_actions_addclose(&action, pipefd[0]) != 0 {
                _ = close(pipefd[0])
                _ = close(pipefd[1])
                throw TrollStoreInstallError(code: -1)
            }
        }
        var pid: pid_t = 0
        let spawnResult = argv.withUnsafeMutableBufferPointer { buffer -> Int32 in
            return posix_spawn(&pid, executable, &action, nil, buffer.baseAddress, nil)
        }
        if captureOutput {
            _ = close(pipefd[1])
        }
        if spawnResult != 0 {
            if captureOutput {
                _ = close(pipefd[0])
            }
            throw TrollStoreInstallError(code: spawnResult)
        }
        var data = Data()
        if captureOutput {
            var buffer = [UInt8](repeating: 0, count: 4096)
            while true {
                let bytesRead = read(pipefd[0], &buffer, buffer.count)
                if bytesRead <= 0 {
                    break
                }
                data.append(buffer, count: bytesRead)
            }
            _ = close(pipefd[0])
        }
        var status: Int32 = 0
        _ = waitpid(pid, &status, 0)
        if (status & 0x7f) != 0 {
            throw TrollStoreInstallError(code: -1)
        }
        return (Int32((status >> 8) & 0xff), data)
    }
}

public class InstallationManager {
    public static func installIPA(path: String, force: Bool, useInstalldMethod: Bool, skipUICache: Bool, entitlements: [String: Any]? = nil) throws {
        if let entitlements = entitlements, !entitlements.isEmpty {
            let patchedIPA = try repackIPAWithEntitlements(ipaPath: path, entitlements: entitlements)
            defer { try? FileManager.default.removeItem(atPath: patchedIPA) }
            try runInstall(ipaPath: patchedIPA, force: force, useInstalldMethod: useInstalldMethod, skipUICache: skipUICache)
        } else {
            try runInstall(ipaPath: path, force: force, useInstalldMethod: useInstalldMethod, skipUICache: skipUICache)
        }
    }

    private static func runInstall(ipaPath: String, force: Bool, useInstalldMethod: Bool, skipUICache: Bool) throws {
        var args = [TrollStoreCommands.install]
        if useInstalldMethod { args.append("installd") }
        if force { args.append("force") }
        if skipUICache { args.append("skip-uicache") }
        args.append(ipaPath)
        let ret = try RootHelper.execute(args: args)
        if ret != 0 { throw TrollStoreInstallError(code: ret) }
    }

    private static func repackIPAWithEntitlements(ipaPath: String, entitlements: [String: Any]) throws -> String {
        let fm = FileManager.default
        let workDir = NSTemporaryDirectory().appending(UUID().uuidString)
        try fm.createDirectory(atPath: workDir, withIntermediateDirectories: true)
        let unzipRet = try RootHelper.runProcess("/usr/bin/unzip", ["-o", ipaPath, "-d", workDir], captureOutput: false).0
        if unzipRet != 0 {
            try? fm.removeItem(atPath: workDir)
            throw TrollStoreInstallError(code: 168)
        }
        let payloadPath = (workDir as NSString).appendingPathComponent("Payload")
        guard let payloadContents = try? fm.contentsOfDirectory(atPath: payloadPath) else {
            try? fm.removeItem(atPath: workDir)
            throw TrollStoreInstallError(code: 167)
        }
        guard let appName = payloadContents.first(where: { $0.hasSuffix(".app") }) else {
            try? fm.removeItem(atPath: workDir)
            throw TrollStoreInstallError(code: 167)
        }
        let appPath = (payloadPath as NSString).appendingPathComponent(appName)
        let infoPlistPath = (appPath as NSString).appendingPathComponent("Info.plist")
        guard let infoDict = NSDictionary(contentsOfFile: infoPlistPath) as? [String: Any],
              let executable = infoDict["CFBundleExecutable"] as? String else {
            try? fm.removeItem(atPath: workDir)
            throw TrollStoreInstallError(code: 176)
        }
        let binaryPath = (appPath as NSString).appendingPathComponent(executable)
        if !fm.fileExists(atPath: binaryPath) {
            try? fm.removeItem(atPath: workDir)
            throw TrollStoreInstallError(code: 174)
        }
        let entitlementsData = try PropertyListSerialization.data(fromPropertyList: entitlements, format: .xml, options: 0)
        let entitlementsPath = (workDir as NSString).appendingPathComponent("entitlements.plist")
        try entitlementsData.write(to: URL(fileURLWithPath: entitlementsPath))
        let ldidPath = (Bundle.main.bundlePath as NSString).appendingPathComponent(TrollStorePaths.ldidName)
        let ldidRet = try RootHelper.runProcess(ldidPath, ["-S\(entitlementsPath)", binaryPath], captureOutput: false).0
        if ldidRet != 0 {
            try? fm.removeItem(atPath: workDir)
            throw TrollStoreInstallError(code: 175)
        }
        let repackedIPA = NSTemporaryDirectory().appending(UUID().uuidString).appending(".ipa")
        let zipRet = try RootHelper.runProcess("/usr/bin/zip", ["-qr", repackedIPA, "Payload"], workingDirectory: workDir, captureOutput: false).0
        try? fm.removeItem(atPath: workDir)
        if zipRet != 0 {
            throw TrollStoreInstallError(code: 168)
        }
        return repackedIPA
    }

    public static func uninstallApp(bundleId: String, useCustomMethod: Bool) throws {
        var args = [TrollStoreCommands.uninstall]
        if useCustomMethod { args.append("custom") }
        args.append(bundleId)
        let ret = try RootHelper.execute(args: args)
        if ret != 0 { throw TrollStoreInstallError(code: ret) }
    }

    public static func enableJIT(bundleId: String) throws {
        let ret = try RootHelper.execute(args: [TrollStoreCommands.enableJIT, bundleId])
        if ret != 0 { throw TrollStoreInstallError(code: ret) }
    }

    public static func changeRegistration(appPath: String, isSystem: Bool) throws {
        let registration = isSystem ? "System" : "User"
        let ret = try RootHelper.execute(args: [TrollStoreCommands.modifyRegistration, appPath, registration])
        if ret != 0 { throw TrollStoreInstallError(code: ret) }
    }

    public static func dumpEntitlements(binaryPath: String) throws -> [String: Any] {
        let ldidPath = (Bundle.main.bundlePath as NSString).appendingPathComponent(TrollStorePaths.ldidName)
        let (ret, data) = try RootHelper.runProcess(ldidPath, ["-e", binaryPath], captureOutput: true)
        if ret != 0 { throw TrollStoreInstallError(code: 175) }
        guard let plist = try? PropertyListSerialization.propertyList(from: data, options: [], format: nil),
              let dict = plist as? [String: Any] else { return [:] }
        return dict
    }

    public static func setEntitlements(binaryPath: String, entitlements: [String: Any]) throws {
        let data = try PropertyListSerialization.data(fromPropertyList: entitlements, format: .xml, options: 0)
        let tmpPath = NSTemporaryDirectory().appending(UUID().uuidString).appending(".plist")
        try data.write(to: URL(fileURLWithPath: tmpPath))
        defer { try? FileManager.default.removeItem(atPath: tmpPath) }
        let ldidPath = (Bundle.main.bundlePath as NSString).appendingPathComponent(TrollStorePaths.ldidName)
        let (ret, _) = try RootHelper.runProcess(ldidPath, ["-S\(tmpPath)", binaryPath], captureOutput: false)
        if ret != 0 { throw TrollStoreInstallError(code: 175) }
    }

    public static func writeExtraEntitlements(appPath: String, entitlements: [String: Any]) throws {
        let data = try PropertyListSerialization.data(fromPropertyList: entitlements, format: .xml, options: 0)
        let target = (appPath as NSString).appendingPathComponent(TrollStorePaths.extraEntitlementsName)
        try data.write(to: URL(fileURLWithPath: target))
    }

    public static func clearExtraEntitlements(appPath: String) {
        let target = (appPath as NSString).appendingPathComponent(TrollStorePaths.extraEntitlementsName)
        try? FileManager.default.removeItem(atPath: target)
    }
}
