import Foundation
import Darwin
public struct TrollStoreInstallError: Error, LocalizedError {
public let code: Int32
public var errorDescription: String? {
return TrollStoreInstallError.description(for: code)
}
public static func description(for code: Int32) -> String {
switch code {
case 166: return NSLocalizedString("Error_166", comment: "")
case 167: return NSLocalizedString("Error_167", comment: "")
case 168: return NSLocalizedString("Error_168", comment: "")
case 170: return NSLocalizedString("Error_170", comment: "")
case 171: return NSLocalizedString("Error_171", comment: "")
case 172: return NSLocalizedString("Error_172", comment: "")
case 173: return NSLocalizedString("Error_173", comment: "")
case 175: return NSLocalizedString("Error_175", comment: "")
case 178: return NSLocalizedString("Error_178", comment: "")
case 180: return NSLocalizedString("Error_180", comment: "")
case 181: return NSLocalizedString("Error_181", comment: "")
case 182: return NSLocalizedString("Error_182", comment: "")
case 184: return NSLocalizedString("Error_184", comment: "")
case 185: return NSLocalizedString("Error_185", comment: "")
default: return NSLocalizedString("Error_Unknown", comment: "")
}
}
}
private extension TrollStoreInstallError {
static func fallbackEntitlements() -> [String: Any] {
return [
 "application-identifier": "TROLLTROLL.*",
 "com.apple.developer.team-identifier": "TROLLTROLL",
 "get-task-allow": true,
 "keychain-access-groups": ["TROLLTROLL.*", "com.apple.token"]
]
}
}
public func installIPA(path: String, force: Bool, useInstalldMethod: Bool, skipUICache: Bool) throws {
let ret = c_installIpa(path as NSString, force ? 1 : 0, useInstalldMethod ? 1 : 0, skipUICache ? 1 : 0)
if ret != 0 {
throw TrollStoreInstallError(code: ret)
}
}
public func signAppParallel(path: String) throws {
cleanCodeSignatures(at: path)
let binaries = findAppBundleBinaries(appPath: path)
let group = DispatchGroup()
var parallelError: Int32 = 0
let queue = DispatchQueue(label: "com.trollstore.sign", attributes: .concurrent)
let lock = NSLock()
for binary in binaries {
group.enter()
queue.async {
let entitlements = dumpEntitlements(binaryPath: binary.binaryPath) ?? TrollStoreInstallError.fallbackEntitlements()
let ret = signSingleBinary(path: binary.binaryPath, entitlements: entitlements)
if ret != 0 {
lock.lock()
if parallelError == 0 { parallelError = ret }
lock.unlock()
}
group.leave()
}
}
group.wait()
if parallelError != 0 {
throw TrollStoreInstallError(code: parallelError)
}
let bundleSignRet = spawnLdid(args: ["-s", path])
if bundleSignRet != 0 {
throw TrollStoreInstallError(code: 175)
}
let allExecutables = findAllExecutables(in: path)
let ctGroup = DispatchGroup()
var ctError: Int32 = 0
for execPath in allExecutables {
ctGroup.enter()
queue.async {
do {
try applyCoreTrustBypass(at: execPath)
} catch let error as TrollStoreInstallError {
lock.lock()
if ctError == 0 { ctError = error.code }
lock.unlock()
} catch {
lock.lock()
if ctError == 0 { ctError = 185 }
lock.unlock()
}
ctGroup.leave()
}
}
ctGroup.wait()
if ctError != 0 {
throw TrollStoreInstallError(code: ctError)
}
}
public func dumpEntitlements(binaryPath: String) -> [String: Any]? {
guard let dict = c_dumpEntitlementsFromBinaryAtPath(binaryPath as NSString) else {
return nil
}
return dict as? [String: Any]
}
public func setEntitlements(binaryPath: String, entitlements: [String: Any]) throws {
let entitlementsData = try PropertyListSerialization.data(fromPropertyList: entitlements, format: .xml, options: 0)
let tempPath = NSTemporaryDirectory().appending(UUID().uuidString).appending(".plist")
try entitlementsData.write(to: URL(fileURLWithPath: tempPath))
let signRet = spawnLdid(args: ["-S\(tempPath)", binaryPath])
try? FileManager.default.removeItem(atPath: tempPath)
if signRet != 0 {
throw TrollStoreInstallError(code: 175)
}
try applyCoreTrustBypass(at: binaryPath)
}
public func setEntitlementsForApp(appPath: String, entitlements: [String: Any]) throws {
let binaries = findAppBundleBinaries(appPath: appPath)
for binary in binaries {
try setEntitlements(binaryPath: binary.binaryPath, entitlements: entitlements)
}
}
public func getTrollStoreAppPath() -> String {
return c_trollStoreAppPath() as String
}
@_silgen_name("installIpa")
private func c_installIpa(_ ipaPath: NSString, _ force: Int8, _ useInstalldMethod: Int8, _ skipUICache: Int8) -> Int32
@_silgen_name("signApp")
private func c_signApp(_ appPath: NSString) -> Int32
@_silgen_name("fixPermissionsOfAppBundle")
private func c_fixPermissionsOfAppBundle(_ path: NSString)
@_silgen_name("registerPath")
private func c_registerPath(_ path: NSString, _ uninstall: Int8, _ asSystem: Int8) -> Int8
@_silgen_name("dumpEntitlementsFromBinaryAtPath")
private func c_dumpEntitlementsFromBinaryAtPath(_ path: NSString) -> NSDictionary?
@_silgen_name("signAdhoc")
private func c_signAdhoc(_ filePath: NSString, _ entitlements: NSDictionary?) -> Int32
@_silgen_name("apply_coretrust_bypass")
private func c_applyCoreTrustBypass(_ path: UnsafePointer<CChar>) -> Int32
@_silgen_name("trollStoreAppPath")
private func c_trollStoreAppPath() -> NSString
private func cleanCodeSignatures(at path: String) {
let fm = FileManager.default
guard let enumerator = fm.enumerator(atPath: path) else { return }
while let element = enumerator.nextObject() as? String {
if element.hasSuffix("_CodeSignature") {
let fullPath = (path as NSString).appendingPathComponent(element)
try? fm.removeItem(atPath: fullPath)
}
}
}
private func signSingleBinary(path: String, entitlements: [String: Any]) -> Int32 {
var tempPath: String? = nil
var args: [String]
if let entitlementsData = try? PropertyListSerialization.data(fromPropertyList: entitlements, format: .xml, options: 0) {
tempPath = NSTemporaryDirectory().appending(UUID().uuidString).appending(".plist")
try? entitlementsData.write(to: URL(fileURLWithPath: tempPath!))
args = ["-S\(tempPath!)", path]
} else {
args = ["-s", path]
}
let ret = spawnLdid(args: args)
if let tp = tempPath {
try? FileManager.default.removeItem(atPath: tp)
}
return ret
}
private func spawnLdid(args: [String]) -> Int32 {
let ldidPath = (c_trollStoreAppPath() as String).appending("/ldid")
var argv: [UnsafeMutablePointer<CChar>?] = [strdup(ldidPath)]
argv.append(contentsOf: args.map { strdup($0) })
argv.append(nil)
defer {
for ptr in argv {
if let p = ptr { free(p) }
}
}
var pid: pid_t = 0
var status: Int32 = 0
let spawnResult = argv.withUnsafeMutableBufferPointer { buffer -> Int32 in
return posix_spawn(&pid, ldidPath, nil, nil, buffer.baseAddress, nil)
}
if spawnResult != 0 { return -1 }
waitpid(pid, &status, 0)
let exited = (status & 0x7f) == 0
let exitCode = (status >> 8) & 0xff
return exited ? exitCode : -1
}
private func applyCoreTrustBypass(at binaryPath: String) throws {
let ret = binaryPath.withCString { c_applyCoreTrustBypass($0) }
switch ret {
case 0: return
case 2: throw TrollStoreInstallError(code: 180)
case 3: return
default: throw TrollStoreInstallError(code: 185)
}
}
private func findAppBundleBinaries(appPath: String) -> [(binaryPath: String, bundleId: String)] {
var result: [(binaryPath: String, bundleId: String)] = []
let fm = FileManager.default
guard let enumerator = fm.enumerator(atPath: appPath) else { return result }
while let element = enumerator.nextObject() as? String {
if (element as NSString).lastPathComponent == "Info.plist" {
let infoPlistPath = (appPath as NSString).appendingPathComponent(element)
guard let infoDict = NSDictionary(contentsOfFile: infoPlistPath) as? [String: Any] else { continue }
guard let bundleId = infoDict["CFBundleIdentifier"] as? String, !bundleId.isEmpty else { continue }
guard let executable = infoDict["CFBundleExecutable"] as? String, !executable.isEmpty else { continue }
let packageType = infoDict["CFBundlePackageType"] as? String
if packageType == "FMWK" { continue }
let binaryDir = (infoPlistPath as NSString).deletingLastPathComponent
let binaryPath = (binaryDir as NSString).appendingPathComponent(executable)
if fm.fileExists(atPath: binaryPath) {
result.append((binaryPath: binaryPath, bundleId: bundleId))
}
}
}
return result
}
private func findAllExecutables(in path: String) -> [String] {
var result: [String] = []
let fm = FileManager.default
guard let enumerator = fm.enumerator(atPath: path) else { return result }
while let element = enumerator.nextObject() as? String {
let fullPath = (path as NSString).appendingPathComponent(element)
var isDir: ObjCBool = false
if fm.fileExists(atPath: fullPath, isDirectory: &isDir) && !isDir.boolValue {
if fm.isExecutableFile(atPath: fullPath) {
if let handle = FileHandle(forReadingAtPath: fullPath) {
let magic = handle.readData(ofLength: 4)
handle.closeFile()
if magic.count == 4 {
let m = magic.withUnsafeBytes { $0.load(as: UInt32.self) }
if m == 0xFEEDFACE || m == 0xCEFAEDFE || m == 0xFEEDFACF || m == 0xCFFAEDFE || m == 0xCAFEBABE || m == 0xBEBAFECA {
result.append(fullPath)
}
}
}
}
}
}
return result
}
