import Foundation
import Darwin

enum TrollStorePaths {
    static let rootPath = "/var/containers/Bundle/TrollStore"
    static let mainPath = "/var/containers/Bundle/TrollStore/Main"
    static let applicationsPath = "/var/containers/Bundle/TrollStore/Applications"
    static let activeMarker = ".TrollStore"
    static let inactiveMarker = ".TrollStoreInactive"
    static let persistenceMarker = ".TrollStorePersistenceHelper"
    static let ldidName = "ldid"
    static let ldidVersionName = "ldid.version"
    static let helperName = "trollstorehelper"
    static let persistenceHelperName = "PersistenceHelper"
    static let urlScheme = "apple-magnifier"
    static let errorDomain = "TrollStoreErrorDomain"
}

enum TrollStoreCommands {
    static let install = "install"
    static let uninstall = "uninstall"
    static let uninstallPath = "uninstall-path"
    static let refresh = "refresh"
    static let refreshAll = "refresh-all"
    static let urlScheme = "url-scheme"
    static let reboot = "reboot"
    static let respring = "respring"
    static let enableJIT = "enable-jit"
    static let modifyRegistration = "modify-registration"
    static let transferApps = "transfer-apps"
    static let installTrollStore = "install-trollstore"
    static let uninstallTrollStore = "uninstall-trollstore"
    static let installLdid = "install-ldid"
    static let installPersistenceHelper = "install-persistence-helper"
    static let uninstallPersistenceHelper = "uninstall-persistence-helper"
    static let registerUserPersistenceHelper = "register-user-persistence-helper"
    static let checkDevMode = "check-dev-mode"
    static let armDevMode = "arm-dev-mode"
}

enum TrollStoreDefaults {
    static let installationMethod = "installationMethod"
    static let uninstallationMethod = "uninstallationMethod"
    static let installAlertConfiguration = "installAlertConfiguration"
    static let autoInitLdid = "autoInitLdid"
    static let urlSchemeEnabled = "urlSchemeEnabled"
    static let appId = "com.opa334.TrollStore"
    static let appName = "TrollStore"
    static let otherAppName = "TrollStore Lite"
}

enum TrollStoreNotifications {
    static let applicationsChanged = "ApplicationsChanged"
    static let reloadSettings = "TrollStoreReloadSettingsNotification"
}

enum PersistenceHelperType: Int32 {
    case user = 1
    case system = 2
    case all = 3
}

@_silgen_name("apply_coretrust_bypass")
func apply_coretrust_bypass(_ path: UnsafePointer<CChar>) -> Int32

@_silgen_name("TSRootHelperSignAdhoc")
func TSRootHelperSignAdhoc(_ filePath: NSString, _ entitlements: NSDictionary?) -> Int32

@_silgen_name("TSRootHelperSignAppParallel")
func TSRootHelperSignAppParallel(_ appPath: NSString) -> Int32

@_silgen_name("TSRootHelperApplyCoreTrustParallel")
func TSRootHelperApplyCoreTrustParallel(_ appPath: NSString, _ mainExecutablePath: NSString, _ outEncryptedMain: UnsafeMutablePointer<Bool>?, _ outAdditionalEncrypted: UnsafeMutablePointer<Bool>?) -> Int32

@_silgen_name("TSRootHelperIsSameFile")
func TSRootHelperIsSameFile(_ path1: NSString, _ path2: NSString) -> Bool

@_silgen_name("TSRootHelperInfoDictionaryForAppPath")
func TSRootHelperInfoDictionaryForAppPath(_ appPath: NSString) -> NSDictionary?

@_silgen_name("TSRootHelperAppMainExecutablePath")
func TSRootHelperAppMainExecutablePath(_ appPath: NSString) -> NSString?

@_silgen_name("TSRootHelperAppIdForAppPath")
func TSRootHelperAppIdForAppPath(_ appPath: NSString) -> NSString?

@_silgen_name("TSRootHelperGetDeclaredExploitTypeFromInfoDictionary")
func TSRootHelperGetDeclaredExploitTypeFromInfoDictionary(_ dict: NSDictionary) -> Int32

@_silgen_name("TSRootHelperIsPlatformVulnerableToExploitType")
func TSRootHelperIsPlatformVulnerableToExploitType(_ type: Int32) -> Bool

@_silgen_name("TSRootHelperCoreTrustExploitType")
func TSRootHelperCoreTrustExploitType() -> Int32

@_silgen_name("TSRootHelperGetStaticCodeRef")
func TSRootHelperGetStaticCodeRef(_ path: NSString) -> SecStaticCode?

@_silgen_name("TSRootHelperContainsFakeAppStoreExtensions")
func TSRootHelperContainsFakeAppStoreExtensions(_ codeRef: SecStaticCode) -> Bool

@_silgen_name("TSRootHelperEnumerateMachOsInBundle")
func TSRootHelperEnumerateMachOsInBundle(_ appPath: NSString) -> NSArray

@_silgen_name("TSRootHelperCollectBundleMainBinaries")
func TSRootHelperCollectBundleMainBinaries(_ appPath: NSString, _ mainExecutablePath: NSString) -> NSArray

@_silgen_name("TSRootHelperBuildEntitlementsForMainBinary")
func TSRootHelperBuildEntitlementsForMainBinary(_ binaryPath: NSString, _ bundleId: NSString, _ isMainBinary: Bool) -> NSDictionary?

@_silgen_name("TSRootHelperDumpEntitlementsFromBinary")
func TSRootHelperDumpEntitlementsFromBinary(_ binaryPath: NSString) -> NSDictionary?

@_silgen_name("TSRootHelperSetEntitlementsForBinary")
func TSRootHelperSetEntitlementsForBinary(_ binaryPath: NSString, _ entitlements: NSDictionary?) -> Int32

@_silgen_name("TSRootHelperSetEntitlementsForApp")
func TSRootHelperSetEntitlementsForApp(_ appPath: NSString, _ entitlements: NSDictionary?) -> Int32

public struct TrollStoreInstallError: Error, LocalizedError {
    public let code: Int32
    public var errorDescription: String? {
        return TrollStoreInstallError.description(for: code)
    }
    public static func description(for code: Int32) -> String {
        switch code {
        case 166: return NSLocalizedString("Error_166", comment: "")
        case 167: return NSLocalizedString("Error_167", comment: "")
        case 168: return NSLocalizedString("Error_168", comment: "")
        case 169: return NSLocalizedString("Error_169", comment: "")
        case 170: return NSLocalizedString("Error_170", comment: "")
        case 171: return NSLocalizedString("Error_171", comment: "")
        case 172: return NSLocalizedString("Error_172", comment: "")
        case 173: return NSLocalizedString("Error_173", comment: "")
        case 174: return NSLocalizedString("Error_174", comment: "")
        case 175: return NSLocalizedString("Error_175", comment: "")
        case 176: return NSLocalizedString("Error_176", comment: "")
        case 177: return NSLocalizedString("Error_177", comment: "")
        case 178: return NSLocalizedString("Error_178", comment: "")
        case 179: return NSLocalizedString("Error_179", comment: "")
        case 180: return NSLocalizedString("Error_180", comment: "")
        case 181: return NSLocalizedString("Error_181", comment: "")
        case 182: return NSLocalizedString("Error_182", comment: "")
        case 183: return NSLocalizedString("Error_183", comment: "")
        case 184: return NSLocalizedString("Error_184", comment: "")
        case 185: return NSLocalizedString("Error_185", comment: "")
        default: return NSLocalizedString("Error_Unknown", comment: "")
        }
    }
}

final class TSSignEntry: NSObject {
    let path: NSString
    let entitlements: NSDictionary?
    let isMainBinary: Bool

    init(path: NSString, entitlements: NSDictionary?, isMainBinary: Bool) {
        self.path = path
        self.entitlements = entitlements
        self.isMainBinary = isMainBinary
    }
}

private func tsRequiresDevMode(_ entitlements: NSDictionary?) -> Bool {
    guard let entitlements = entitlements else { return false }
    if #available(iOS 16, *) {
        let keys = [
            "get-task-allow",
            "task_for_pid-allow",
            "com.apple.system-task-ports",
            "com.apple.system-task-ports.control",
            "com.apple.system-task-ports.token.control",
            "com.apple.private.cs.debugger"
        ]
        for key in keys {
            if let value = entitlements[key] as? NSNumber, value.boolValue {
                return true
            }
        }
    }
    return false
}

private func tsShouldSkipSigningFastPath(_ appPath: NSString, _ appInfoDict: NSDictionary, _ mainExecutablePath: NSString) -> Bool {
    let declared = TSRootHelperGetDeclaredExploitTypeFromInfoDictionary(appInfoDict)
    if TSRootHelperIsPlatformVulnerableToExploitType(declared) {
        return true
    }
    if declared != 0 {
    }
    let customRootType = TSRootHelperCoreTrustExploitType()
    if TSRootHelperIsPlatformVulnerableToExploitType(customRootType) {
        if let codeRef = TSRootHelperGetStaticCodeRef(mainExecutablePath) {
            if TSRootHelperContainsFakeAppStoreExtensions(codeRef) {
                return true
            }
        }
    }
    return false
}

func signAppParallel(_ appPath: NSString) -> Int32 {
    guard let appInfoDict = TSRootHelperInfoDictionaryForAppPath(appPath) else { return 172 }
    guard let mainExecutablePath = TSRootHelperAppMainExecutablePath(appPath) else { return 176 }

    let fm = FileManager.default
    if !fm.fileExists(atPath: mainExecutablePath as String) { return 174 }

    if tsShouldSkipSigningFastPath(appPath, appInfoDict, mainExecutablePath) {
        return 0
    }

    var requiresDevMode = false
    var hasAdditionalEncryptedBinaries = false

    var mainBinaryEntries: [TSSignEntry] = []
    guard let collected = TSRootHelperCollectBundleMainBinaries(appPath, mainExecutablePath) as? [NSDictionary] else {
        return 167
    }
    for item in collected {
        guard let path = item["path"] as? NSString else { continue }
        var entitlements = item["entitlements"] as? NSDictionary
        let isMain = (item["isMain"] as? NSNumber)?.boolValue ?? false
        if TSRootHelperIsSameFile(path, mainExecutablePath) {
            if entitlements == nil {
                entitlements = [
                    "application-identifier": "TROLLTROLL.*",
                    "com.apple.developer.team-identifier": "TROLLTROLL",
                    "get-task-allow": true,
                    "keychain-access-groups": ["TROLLTROLL.*", "com.apple.token"]
                ]
            }
        }
        if entitlements == nil {
            entitlements = NSMutableDictionary()
        }
        var mutable = entitlements!.mutableCopy() as? NSMutableDictionary
        if mutable == nil {
            mutable = NSMutableDictionary()
            mutable!.addEntries(from: entitlements!)
        }
        if tsRequiresDevMode(mutable as NSDictionary?) {
            requiresDevMode = true
        }
        mainBinaryEntries.append(TSSignEntry(path: path, entitlements: mutable as NSDictionary?, isMainBinary: isMain))
    }

    var signedPaths = Set<String>()
    var allEntries: [TSSignEntry] = []
    for entry in mainBinaryEntries {
        signedPaths.insert(entry.path as String)
        allEntries.append(entry)
    }

    if let allMachOs = TSRootHelperEnumerateMachOsInBundle(appPath) as? [NSString] {
        for macho in allMachOs {
            let key = macho as String
            if signedPaths.contains(key) { continue }
            signedPaths.insert(key)
            allEntries.append(TSSignEntry(path: macho, entitlements: nil, isMainBinary: false))
        }
    }

    var signError: Int32 = 0
    let signLock = NSLock()
    let iterations = allEntries.count
    if iterations > 0 {
        DispatchQueue.concurrentPerform(iterations: iterations) { index in
            let entry = allEntries[index]
            let ret = TSRootHelperSignAdhoc(entry.path, entry.entitlements)
            if ret != 0 {
                signLock.lock()
                if signError == 0 {
                    signError = ret
                }
                signLock.unlock()
            }
        }
    }
    if signError != 0 { return signError }

    let mainRecursiveRet = TSRootHelperSignAppParallel(appPath)
    if mainRecursiveRet != 0 { return mainRecursiveRet }

    var encryptedMain = false
    var additionalEncrypted = false
    let bypassRet = TSRootHelperApplyCoreTrustParallel(appPath, mainExecutablePath, &encryptedMain, &additionalEncrypted)
    if encryptedMain { return 180 }
    if bypassRet != 0 { return bypassRet }
    if additionalEncrypted { hasAdditionalEncryptedBinaries = true }

    if requiresDevMode { return 182 }
    if hasAdditionalEncryptedBinaries { return 184 }
    return 0
}

func dumpEntitlements(binaryPath: String) -> [String: Any]? {
    return TSRootHelperDumpEntitlementsFromBinary(binaryPath as NSString) as? [String: Any]
}

func setEntitlements(binaryPath: String, entitlements: [String: Any]) throws {
    let ret = TSRootHelperSetEntitlementsForBinary(binaryPath as NSString, entitlements as NSDictionary)
    if ret != 0 { throw TrollStoreInstallError(code: ret) }
}

func setEntitlementsForApp(appPath: String, entitlements: [String: Any]) throws {
    let ret = TSRootHelperSetEntitlementsForApp(appPath as NSString, entitlements as NSDictionary)
    if ret != 0 { throw TrollStoreInstallError(code: ret) }
}

@_cdecl("TSSwiftSignAppParallel")
public func TSSwiftSignAppParallel(_ appPath: NSString) -> Int32 {
    return signAppParallel(appPath)
}