import Foundation
import Darwin
import UIKit

@_silgen_name("archive_read_new")
func archive_read_new() -> OpaquePointer?
@_silgen_name("archive_read_support_format_all")
func archive_read_support_format_all(_ a: OpaquePointer?) -> Int32
@_silgen_name("archive_read_support_filter_all")
func archive_read_support_filter_all(_ a: OpaquePointer?) -> Int32
@_silgen_name("archive_read_open_filename")
func archive_read_open_filename(_ a: OpaquePointer?, _ filename: UnsafePointer<CChar>?, _ block_size: Int) -> Int32
@_silgen_name("archive_read_next_header")
func archive_read_next_header(_ a: OpaquePointer?, _ entry: UnsafeMutablePointer<OpaquePointer?>?) -> Int32
@_silgen_name("archive_entry_pathname")
func archive_entry_pathname(_ entry: OpaquePointer?) -> UnsafePointer<CChar>?
@_silgen_name("archive_entry_size")
func archive_entry_size(_ entry: OpaquePointer?) -> Int64
@_silgen_name("archive_read_data")
func archive_read_data(_ a: OpaquePointer?, _ buff: UnsafeMutableRawPointer?, _ size: Int) -> Int
@_silgen_name("archive_read_close")
func archive_read_close(_ a: OpaquePointer?) -> Int32
@_silgen_name("archive_read_free")
func archive_read_free(_ a: OpaquePointer?) -> Int32

enum TrollStorePaths {
    static let rootPath = "/var/containers/Bundle/TrollStore"
    static let applicationsPath = "/var/containers/Bundle/TrollStore/Applications"
    static let activeMarker = ".TrollStore"
    static let inactiveMarker = ".TrollStoreInactive"
    static let ldidName = "ldid"
    static let helperName = "trollstorehelper"
    static let extraEntitlementsName = "entitlements.plist"
}

enum TrollStoreCommands {
    static let install = "install"
    static let uninstall = "uninstall"
    static let refresh = "refresh"
    static let refreshAll = "refresh-all"
    static let urlScheme = "url-scheme"
    static let respring = "respring"
    static let enableJIT = "enable-jit"
    static let modifyRegistration = "modify-registration"
    static let installTrollStore = "install-trollstore"
    static let uninstallTrollStore = "uninstall-trollstore"
    static let installPersistenceHelper = "install-persistence-helper"
}

enum TrollStoreDefaults {
    static let installationMethod = "installationMethod"
    static let uninstallationMethod = "uninstallationMethod"
    static let installAlertConfiguration = "installAlertConfiguration"
    static let autoInitLdid = "autoInitLdid"
    static let urlSchemeEnabled = "urlSchemeEnabled"
}

public struct TrollStoreInstallError: Error, LocalizedError {
    public let code: Int32
    public var errorDescription: String? {
        return TrollStoreInstallError.description(for: code)
    }
    public static func description(for code: Int32) -> String {
        switch code {
        case 166: return NSLocalizedString("Error_166", comment: "")
        case 167: return NSLocalizedString("Error_167", comment: "")
        case 168: return NSLocalizedString("Error_168", comment: "")
        case 169: return NSLocalizedString("Error_169", comment: "")
        case 170: return NSLocalizedString("Error_170", comment: "")
        case 171: return NSLocalizedString("Error_171", comment: "")
        case 172: return NSLocalizedString("Error_172", comment: "")
        case 173: return NSLocalizedString("Error_173", comment: "")
        case 174: return NSLocalizedString("Error_174", comment: "")
        case 175: return NSLocalizedString("Error_175", comment: "")
        case 176: return NSLocalizedString("Error_176", comment: "")
        case 177: return NSLocalizedString("Error_177", comment: "")
        case 178: return NSLocalizedString("Error_178", comment: "")
        case 179: return NSLocalizedString("Error_179", comment: "")
        case 180: return NSLocalizedString("Error_180", comment: "")
        case 181: return NSLocalizedString("Error_181", comment: "")
        case 182: return NSLocalizedString("Error_182", comment: "")
        case 183: return NSLocalizedString("Error_183", comment: "")
        case 184: return NSLocalizedString("Error_184", comment: "")
        case 185: return NSLocalizedString("Error_185", comment: "")
        default: return NSLocalizedString("Error_Unknown", comment: "")
        }
    }
}

public class RootHelper {
    private static let spawnLock = NSLock()
    public static func execute(args: [String]) throws -> Int32 {
        let helperPath = (Bundle.main.bundlePath as NSString).appendingPathComponent(TrollStorePaths.helperName)
        return try runProcess(helperPath, args, captureOutput: false).0
    }
    public static func executeCapturingOutput(args: [String]) throws -> (Int32, Data) {
        let helperPath = (Bundle.main.bundlePath as NSString).appendingPathComponent(TrollStorePaths.helperName)
        return try runProcess(helperPath, args, captureOutput: true)
    }
    public static func runProcess(_ executable: String, _ args: [String], workingDirectory: String? = nil, captureOutput: Bool) throws -> (Int32, Data) {
        spawnLock.lock()
        defer { spawnLock.unlock() }
        var argv: [UnsafeMutablePointer<CChar>?] = [strdup(executable)]
        argv.append(contentsOf: args.map { strdup($0) })
        argv.append(nil)
        defer {
            for ptr in argv {
                if let p = ptr { free(p) }
            }
        }
        var pipefd: [Int32] = [0, 0]
        var action: posix_spawn_file_actions_t? = nil
        _ = posix_spawn_file_actions_init(&action)
        defer { _ = posix_spawn_file_actions_destroy(&action) }
        var previousDirectory: String? = nil
        if let wd = workingDirectory {
            previousDirectory = FileManager.default.currentDirectoryPath
            _ = FileManager.default.changeCurrentDirectoryPath(wd)
        }
        if captureOutput {
            if pipe(&pipefd) != 0 {
                if let prev = previousDirectory { _ = FileManager.default.changeCurrentDirectoryPath(prev) }
                throw TrollStoreInstallError(code: -1)
            }
            _ = posix_spawn_file_actions_adddup2(&action, pipefd[1], 1)
            _ = posix_spawn_file_actions_addclose(&action, pipefd[0])
        }
        var pid: pid_t = 0
        let spawnResult = argv.withUnsafeMutableBufferPointer { buffer -> Int32 in
            return posix_spawn(&pid, executable, &action, nil, buffer.baseAddress, nil)
        }
        if let prev = previousDirectory {
            _ = FileManager.default.changeCurrentDirectoryPath(prev)
        }
        if captureOutput {
            _ = close(pipefd[1])
        }
        if spawnResult != 0 {
            if captureOutput { _ = close(pipefd[0]) }
            throw TrollStoreInstallError(code: spawnResult)
        }
        var data = Data()
        if captureOutput {
            var buffer = [UInt8](repeating: 0, count: 4096)
            while true {
                let bytesRead = read(pipefd[0], &buffer, buffer.count)
                if bytesRead <= 0 { break }
                data.append(buffer, count: bytesRead)
            }
            _ = close(pipefd[0])
        }
        var status: Int32 = 0
        _ = waitpid(pid, &status, 0)
        let exited = (status & 0x7f) == 0
        if !exited {
            throw TrollStoreInstallError(code: -1)
        }
        return (Int32((status >> 8) & 0xff), data)
    }
}

public class InstallationManager {
    private static var downloadObservations: [Int: NSKeyValueObservation] = [:]
    public static func parseIPA(path: String) -> [String: Any]? {
        let a = archive_read_new()
        _ = archive_read_support_format_all(a)
        _ = archive_read_support_filter_all(a)
        let openResult = path.withCString { cPath in
            archive_read_open_filename(a, cPath, 10240)
        }
        guard openResult == 0 else {
            _ = archive_read_free(a)
            return nil
        }
        var entry: OpaquePointer?
        defer {
            _ = archive_read_close(a)
            _ = archive_read_free(a)
        }
        while archive_read_next_header(a, &entry) == 0 {
            if let cName = archive_entry_pathname(entry) {
                let name = String(cString: cName)
                if name.hasSuffix(".app/Info.plist") && name.contains("Payload/") {
                    let size = archive_entry_size(entry)
                    if size > 0 {
                        var data = Data()
                        var remaining = Int(size)
                        let bufferSize = 8192
                        while remaining > 0 {
                            let chunkSize = min(bufferSize, remaining)
                            var chunk = [UInt8](repeating: 0, count: chunkSize)
                            let read = archive_read_data(a, &chunk, chunkSize)
                            if read <= 0 { break }
                            data.append(chunk, count: read)
                            remaining -= read
                        }
                        if remaining == 0 {
                            if let dict = try? PropertyListSerialization.propertyList(from: data, options: [], format: nil) as? [String: Any] {
                                return dict
                            }
                        }
                    }
                }
            }
        }
        return nil
    }
    public static func extractIcon(ipaPath: String, infoDict: [String: Any]) -> UIImage? {
        var iconName: String?
        if let icons = infoDict["CFBundleIcons"] as? [String: Any],
           let primary = icons["CFBundlePrimaryIcon"] as? [String: Any] {
            if let files = primary["CFBundleIconFiles"] as? [String], let last = files.last {
                iconName = last
            }
        }
        guard let baseName = iconName else { return nil }
        let a = archive_read_new()
        _ = archive_read_support_format_all(a)
        _ = archive_read_support_filter_all(a)
        let openResult = ipaPath.withCString { cPath in
            archive_read_open_filename(a, cPath, 10240)
        }
        guard openResult == 0 else {
            _ = archive_read_free(a)
            return nil
        }
        var entry: OpaquePointer?
        var bestMatch: String?
        var bestMatchSize: Int64 = 0
        defer {
            _ = archive_read_close(a)
            _ = archive_read_free(a)
        }
        while archive_read_next_header(a, &entry) == 0 {
            if let cName = archive_entry_pathname(entry) {
                let name = String(cString: cName)
                if name.contains("Payload/") && name.hasSuffix(".png") {
                    let fileName = (name as NSString).lastPathComponent
                    if fileName.hasPrefix(baseName) || fileName == baseName + ".png" || fileName.contains(baseName) {
                        let size = archive_entry_size(entry)
                        if size > bestMatchSize {
                            bestMatch = name
                            bestMatchSize = size
                        }
                    }
                }
            }
        }
        guard let match = bestMatch else { return nil }
        let a2 = archive_read_new()
        _ = archive_read_support_format_all(a2)
        _ = archive_read_support_filter_all(a2)
        let openResult2 = ipaPath.withCString { cPath in
            archive_read_open_filename(a2, cPath, 10240)
        }
        guard openResult2 == 0 else {
            _ = archive_read_free(a2)
            return nil
        }
        defer {
            _ = archive_read_close(a2)
            _ = archive_read_free(a2)
        }
        var entry2: OpaquePointer?
        while archive_read_next_header(a2, &entry2) == 0 {
            if let cName = archive_entry_pathname(entry2) {
                let name = String(cString: cName)
                if name == match {
                    let size = archive_entry_size(entry2)
                    if size > 0 {
                        var data = Data()
                        var remaining = Int(size)
                        let bufferSize = 8192
                        while remaining > 0 {
                            let chunkSize = min(bufferSize, remaining)
                            var chunk = [UInt8](repeating: 0, count: chunkSize)
                            let read = archive_read_data(a2, &chunk, chunkSize)
                            if read <= 0 { break }
                            data.append(chunk, count: read)
                            remaining -= read
                        }
                        if remaining == 0 {
                            return UIImage(data: data)
                        }
                    }
                }
            }
        }
        return nil
    }
    public static func downloadIPA(url: URL, progress: @escaping (Double) -> Void, completion: @escaping (String?, Error?) -> Void) {
        final class TaskBox {
            var id: Int = 0
        }
        let box = TaskBox()
        let task = URLSession.shared.downloadTask(with: url) { localURL, response, error in
            downloadObservations.removeValue(forKey: box.id)
            if let error = error {
                completion(nil, error)
                return
            }
            guard let localURL = localURL else {
                completion(nil, NSError(domain: "Download", code: -1))
                return
            }
            let tmpPath = NSTemporaryDirectory().appending(UUID().uuidString).appending(".ipa")
            do {
                try FileManager.default.moveItem(at: localURL, to: URL(fileURLWithPath: tmpPath))
                completion(tmpPath, nil)
            } catch {
                completion(nil, error)
            }
        }
        box.id = task.taskIdentifier
        let observation = task.progress.observe(\.fractionCompleted) { p, _ in
            DispatchQueue.main.async { progress(p.fractionCompleted) }
        }
        downloadObservations[task.taskIdentifier] = observation
        task.resume()
    }
    public static func installIPA(path: String, force: Bool, useInstalldMethod: Bool, skipUICache: Bool, entitlements: [String: Any]? = nil) throws {
        if let entitlements = entitlements, !entitlements.isEmpty {
            let patchedIPA = try repackIPAWithEntitlements(ipaPath: path, entitlements: entitlements)
            defer { try? FileManager.default.removeItem(atPath: patchedIPA) }
            try runInstall(ipaPath: patchedIPA, force: force, useInstalldMethod: useInstalldMethod, skipUICache: skipUICache)
        } else {
            try runInstall(ipaPath: path, force: force, useInstalldMethod: useInstalldMethod, skipUICache: skipUICache)
        }
    }
    private static func runInstall(ipaPath: String, force: Bool, useInstalldMethod: Bool, skipUICache: Bool) throws {
        var args = [TrollStoreCommands.install]
        if useInstalldMethod { args.append("installd") }
        else { args.append("custom") }
        if force { args.append("force") }
        if skipUICache { args.append("skip-uicache") }
        args.append(ipaPath)
        let ret = try RootHelper.execute(args: args)
        if ret != 0 { throw TrollStoreInstallError(code: ret) }
    }
    private static func repackIPAWithEntitlements(ipaPath: String, entitlements: [String: Any]) throws -> String {
        let fm = FileManager.default
        let workDir = NSTemporaryDirectory().appending(UUID().uuidString)
        try fm.createDirectory(atPath: workDir, withIntermediateDirectories: true)
        let unzipRet = try RootHelper.runProcess("/usr/bin/unzip", ["-o", ipaPath, "-d", workDir], captureOutput: false).0
        if unzipRet != 0 {
            try? fm.removeItem(atPath: workDir)
            throw TrollStoreInstallError(code: 168)
        }
        let payloadPath = (workDir as NSString).appendingPathComponent("Payload")
        guard let payloadContents = try? fm.contentsOfDirectory(atPath: payloadPath) else {
            try? fm.removeItem(atPath: workDir)
            throw TrollStoreInstallError(code: 167)
        }
        guard let appName = payloadContents.first(where: { $0.hasSuffix(".app") }) else {
            try? fm.removeItem(atPath: workDir)
            throw TrollStoreInstallError(code: 167)
        }
        let appPath = (payloadPath as NSString).appendingPathComponent(appName)
        let infoPlistPath = (appPath as NSString).appendingPathComponent("Info.plist")
        guard let infoDict = NSDictionary(contentsOfFile: infoPlistPath) as? [String: Any],
              let executable = infoDict["CFBundleExecutable"] as? String else {
            try? fm.removeItem(atPath: workDir)
            throw TrollStoreInstallError(code: 176)
        }
        let binaryPath = (appPath as NSString).appendingPathComponent(executable)
        if !fm.fileExists(atPath: binaryPath) {
            try? fm.removeItem(atPath: workDir)
            throw TrollStoreInstallError(code: 174)
        }
        let entitlementsData = try PropertyListSerialization.data(fromPropertyList: entitlements, format: .xml, options: 0)
        let entitlementsPath = (workDir as NSString).appendingPathComponent("entitlements.plist")
        try entitlementsData.write(to: URL(fileURLWithPath: entitlementsPath))
        let ldidPath = (Bundle.main.bundlePath as NSString).appendingPathComponent(TrollStorePaths.ldidName)
        let ldidRet = try RootHelper.runProcess(ldidPath, ["-S\(entitlementsPath)", binaryPath], captureOutput: false).0
        if ldidRet != 0 {
            try? fm.removeItem(atPath: workDir)
            throw TrollStoreInstallError(code: 175)
        }
        let repackedIPA = NSTemporaryDirectory().appending(UUID().uuidString).appending(".ipa")
        let zipRet = try RootHelper.runProcess("/usr/bin/zip", ["-qr", repackedIPA, "Payload"], workingDirectory: workDir, captureOutput: false).0
        try? fm.removeItem(atPath: workDir)
        if zipRet != 0 {
            throw TrollStoreInstallError(code: 168)
        }
        return repackedIPA
    }
    public static func uninstallApp(bundleId: String, useCustomMethod: Bool) throws {
        var args = [TrollStoreCommands.uninstall]
        if useCustomMethod { args.append("custom") }
        else { args.append("installd") }
        args.append(bundleId)
        let ret = try RootHelper.execute(args: args)
        if ret != 0 { throw TrollStoreInstallError(code: ret) }
    }
    public static func enableJIT(bundleId: String) throws {
        let ret = try RootHelper.execute(args: [TrollStoreCommands.enableJIT, bundleId])
        if ret != 0 { throw TrollStoreInstallError(code: ret) }
    }
    public static func changeRegistration(appPath: String, isSystem: Bool) throws {
        let registration = isSystem ? "System" : "User"
        let ret = try RootHelper.execute(args: [TrollStoreCommands.modifyRegistration, appPath, registration])
        if ret != 0 { throw TrollStoreInstallError(code: ret) }
    }
    public static func dumpEntitlements(binaryPath: String) throws -> [String: Any] {
        let ldidPath = (Bundle.main.bundlePath as NSString).appendingPathComponent(TrollStorePaths.ldidName)
        let (ret, data) = try RootHelper.runProcess(ldidPath, ["-e", binaryPath], captureOutput: true)
        if ret != 0 { throw TrollStoreInstallError(code: 175) }
        if let dict = try? PropertyListSerialization.propertyList(from: data, options: [], format: nil) as? [String: Any] {
            return dict
        }
        return [:]
    }
    public static func setEntitlements(binaryPath: String, entitlements: [String: Any]) throws {
        let data = try PropertyListSerialization.data(fromPropertyList: entitlements, format: .xml, options: 0)
        let tmpPath = NSTemporaryDirectory().appending(UUID().uuidString).appending(".plist")
        try data.write(to: URL(fileURLWithPath: tmpPath))
        defer { try? FileManager.default.removeItem(atPath: tmpPath) }
        let ldidPath = (Bundle.main.bundlePath as NSString).appendingPathComponent(TrollStorePaths.ldidName)
        let (ret, _) = try RootHelper.runProcess(ldidPath, ["-S\(tmpPath)", binaryPath], captureOutput: false)
        if ret != 0 { throw TrollStoreInstallError(code: 175) }
    }
}
