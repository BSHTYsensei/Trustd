import Foundation
import Darwin

public struct TrollStoreInstallError: Error, LocalizedError {
public let code: Int32
public var errorDescription: String? {
return TrollStoreInstallError.description(for: code)
}
public static func description(for code: Int32) -> String {
switch code {
case 166: return NSLocalizedString("Error_166", comment: "")
case 167: return NSLocalizedString("Error_167", comment: "")
case 168: return NSLocalizedString("Error_168", comment: "")
case 170: return NSLocalizedString("Error_170", comment: "")
case 171: return NSLocalizedString("Error_171", comment: "")
case 172: return NSLocalizedString("Error_172", comment: "")
case 173: return NSLocalizedString("Error_173", comment: "")
case 175: return NSLocalizedString("Error_175", comment: "")
case 178: return NSLocalizedString("Error_178", comment: "")
case 180: return NSLocalizedString("Error_180", comment: "")
case 181: return NSLocalizedString("Error_181", comment: "")
case 182: return NSLocalizedString("Error_182", comment: "")
case 184: return NSLocalizedString("Error_184", comment: "")
case 185: return NSLocalizedString("Error_185", comment: "")
default: return NSLocalizedString("Error_Unknown", comment: "")
}
}
}

public func dumpEntitlements(binaryPath: String) -> [String: Any]? {
    let ldidPath = (Bundle.main.bundlePath as NSString).appendingPathComponent("ldid")
    var argv: [UnsafeMutablePointer<CChar>?] = [strdup(ldidPath), strdup("-e"), strdup(binaryPath)]
    argv.append(nil)
    defer {
        for ptr in argv {
            if let p = ptr { free(p) }
        }
    }
    var pipefd: [Int32] = [0, 0]
    if pipe(&pipefd) != 0 { return nil }
    var pid: pid_t = 0
    var action: posix_spawn_file_actions_t? = nil
    posix_spawn_file_actions_init(&action)
    posix_spawn_file_actions_adddup2(&action, pipefd[1], 1)
    posix_spawn_file_actions_addclose(&action, pipefd[0])
    let spawnResult = argv.withUnsafeMutableBufferPointer { buffer -> Int32 in
        return posix_spawn(&pid, ldidPath, &action, nil, buffer.baseAddress, nil)
    }
    close(pipefd[1])
    if spawnResult != 0 {
        posix_spawn_file_actions_destroy(&action)
        close(pipefd[0])
        return nil
    }
    var data = Data()
    var buffer = [UInt8](repeating: 0, count: 4096)
    while true {
        let bytesRead = read(pipefd[0], &buffer, buffer.count)
        if bytesRead <= 0 { break }
        data.append(buffer, count: bytesRead)
    }
    close(pipefd[0])
    var status: Int32 = 0
    waitpid(pid, &status, 0)
    posix_spawn_file_actions_destroy(&action)
    if let dict = try? PropertyListSerialization.propertyList(from: data, options: [], format: nil) as? [String: Any] {
        return dict
    }
    return nil
}

public func setEntitlements(binaryPath: String, entitlements: [String: Any]) throws {
    let entitlementsData = try PropertyListSerialization.data(fromPropertyList: entitlements, format: .xml, options: 0)
    let tempPath = NSTemporaryDirectory().appending(UUID().uuidString).appending(".plist")
    try entitlementsData.write(to: URL(fileURLWithPath: tempPath))
    let ret = try RootHelper.ldid(args: ["-S\(tempPath)", binaryPath])
    try? FileManager.default.removeItem(atPath: tempPath)
    if ret != 0 { throw TrollStoreInstallError(code: 175) }
}

public func setEntitlementsForApp(appPath: String, entitlements: [String: Any]) throws {
    let fm = FileManager.default
    guard let enumerator = fm.enumerator(atPath: appPath) else { return }
    while let element = enumerator.nextObject() as? String {
        if (element as NSString).lastPathComponent == "Info.plist" {
            let infoPlistPath = (appPath as NSString).appendingPathComponent(element)
            guard let infoDict = NSDictionary(contentsOfFile: infoPlistPath) as? [String: Any] else { continue }
            guard let executable = infoDict["CFBundleExecutable"] as? String, !executable.isEmpty else { continue }
            let packageType = infoDict["CFBundlePackageType"] as? String
            if packageType == "FMWK" { continue }
            let binaryDir = (infoPlistPath as NSString).deletingLastPathComponent
            let binaryPath = (binaryDir as NSString).appendingPathComponent(executable)
            if fm.fileExists(atPath: binaryPath) {
                try setEntitlements(binaryPath: binaryPath, entitlements: entitlements)
            }
        }
    }
}

public func getTrollStoreAppPath() -> String {
    return Bundle.main.bundlePath
}
