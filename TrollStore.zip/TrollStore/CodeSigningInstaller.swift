import Foundation
import Darwin

public struct TrollStoreInstallError: Error, LocalizedError {
    public let code: Int32
    public var errorDescription: String? {
        return NSLocalizedString("Error_\(code)", comment: "")
    }
}

public func dumpEntitlements(binaryPath: String) -> [String: Any]? {
    let ldidPath = (Bundle.main.bundlePath as NSString).appendingPathComponent("ldid")
    var argv: [UnsafeMutablePointer<CChar>?] = [strdup(ldidPath), strdup("-e"), strdup(binaryPath)]
    argv.append(nil)
    defer {
        for ptr in argv {
            if let p = ptr { free(p) }
        }
    }
    var pipefd: [Int32] = [0, 0]
    if pipe(&pipefd) != 0 { return nil }
    var pid: pid_t = 0
    var action: posix_spawn_file_actions_t
    posix_spawn_file_actions_init(&action)
    posix_spawn_file_actions_adddup2(&action, pipefd[1], 1)
    posix_spawn_file_actions_addclose(&action, pipefd[0])
    let spawnResult = argv.withUnsafeMutableBufferPointer { buffer -> Int32 in
        return posix_spawn(&pid, ldidPath, &action, nil, buffer.baseAddress, nil)
    }
    close(pipefd[1])
    if spawnResult != 0 {
        posix_spawn_file_actions_destroy(&action)
        close(pipefd[0])
        return nil
    }
    var data = Data()
    var buffer = [UInt8](repeating: 0, count: 4096)
    while true {
        let bytesRead = read(pipefd[0], &buffer, buffer.count)
        if bytesRead <= 0 { break }
        data.append(buffer, count: bytesRead)
    }
    close(pipefd[0])
    var status: Int32 = 0
    waitpid(pid, &status, 0)
    posix_spawn_file_actions_destroy(&action)
    if let dict = try? PropertyListSerialization.propertyList(from: data, options: [], format: nil) as? [String: Any] {
        return dict
    }
    return nil
}

public func setEntitlements(binaryPath: String, entitlements: [String: Any]) throws {
    let entitlementsData = try PropertyListSerialization.data(fromPropertyList: entitlements, format: .xml, options: 0)
    let tempPath = NSTemporaryDirectory().appending(UUID().uuidString).appending(".plist")
    try entitlementsData.write(to: URL(fileURLWithPath: tempPath))
    let ret = try RootHelper.ldid(args: ["-S\(tempPath)", binaryPath])
    try? FileManager.default.removeItem(atPath: tempPath)
    if ret != 0 { throw TrollStoreInstallError(code: 175) }
}

public func setEntitlementsForApp(appPath: String, entitlements: [String: Any]) throws {
    let fm = FileManager.default
    guard let enumerator = fm.enumerator(atPath: appPath) else { return }
    while let element = enumerator.nextObject() as? String {
        if (element as NSString).lastPathComponent == "Info.plist" {
            let infoPlistPath = (appPath as NSString).appendingPathComponent(element)
            guard let infoDict = NSDictionary(contentsOfFile: infoPlistPath) as? [String: Any] else { continue }
            guard let executable = infoDict["CFBundleExecutable"] as? String, !executable.isEmpty else { continue }
            let packageType = infoDict["CFBundlePackageType"] as? String
            if packageType == "FMWK" { continue }
            let binaryDir = (infoPlistPath as NSString).deletingLastPathComponent
            let binaryPath = (binaryDir as NSString).appendingPathComponent(executable)
            if fm.fileExists(atPath: binaryPath) {
                try setEntitlements(binaryPath: binaryPath, entitlements: entitlements)
            }
        }
    }
}

public func getTrollStoreAppPath() -> String {
    return Bundle.main.bundlePath
}
