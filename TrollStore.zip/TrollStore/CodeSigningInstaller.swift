import Foundation
import Darwin

enum TrollStorePaths {
    static let rootPath = "/var/containers/Bundle/TrollStore"
    static let applicationsPath = "/var/containers/Bundle/TrollStore/Applications"
    static let activeMarker = ".TrollStore"
    static let inactiveMarker = ".TrollStoreInactive"
    static let ldidName = "ldid"
    static let helperName = "trollstorehelper"
    static let extraEntitlementsName = "entitlements.plist"
}

enum TrollStoreCommands {
    static let install = "install"
    static let uninstall = "uninstall"
    static let refresh = "refresh"
    static let refreshAll = "refresh-all"
    static let urlScheme = "url-scheme"
    static let respring = "respring"
    static let enableJIT = "enable-jit"
    static let modifyRegistration = "modify-registration"
    static let installTrollStore = "install-trollstore"
    static let uninstallTrollStore = "uninstall-trollstore"
    static let installPersistenceHelper = "install-persistence-helper"
}

enum TrollStoreDefaults {
    static let installationMethod = "installationMethod"
    static let uninstallationMethod = "uninstallationMethod"
    static let installAlertConfiguration = "installAlertConfiguration"
    static let autoInitLdid = "autoInitLdid"
    static let urlSchemeEnabled = "urlSchemeEnabled"
}

public struct TrollStoreInstallError: Error, LocalizedError {
    public let code: Int32
    public var errorDescription: String? {
        return TrollStoreInstallError.description(for: code)
    }
    public static func description(for code: Int32) -> String {
        switch code {
        case 166: return NSLocalizedString("Error_166", comment: "")
        case 167: return NSLocalizedString("Error_167", comment: "")
        case 168: return NSLocalizedString("Error_168", comment: "")
        case 169: return NSLocalizedString("Error_169", comment: "")
        case 170: return NSLocalizedString("Error_170", comment: "")
        case 171: return NSLocalizedString("Error_171", comment: "")
        case 172: return NSLocalizedString("Error_172", comment: "")
        case 173: return NSLocalizedString("Error_173", comment: "")
        case 174: return NSLocalizedString("Error_174", comment: "")
        case 175: return NSLocalizedString("Error_175", comment: "")
        case 176: return NSLocalizedString("Error_176", comment: "")
        case 177: return NSLocalizedString("Error_177", comment: "")
        case 178: return NSLocalizedString("Error_178", comment: "")
        case 179: return NSLocalizedString("Error_179", comment: "")
        case 180: return NSLocalizedString("Error_180", comment: "")
        case 181: return NSLocalizedString("Error_181", comment: "")
        case 182: return NSLocalizedString("Error_182", comment: "")
        case 183: return NSLocalizedString("Error_183", comment: "")
        case 184: return NSLocalizedString("Error_184", comment: "")
        case 185: return NSLocalizedString("Error_185", comment: "")
        default: return NSLocalizedString("Error_Unknown", comment: "")
        }
    }
}

public class RootHelper {
    public static func execute(args: [String]) throws -> Int32 {
        let helperPath = (Bundle.main.bundlePath as NSString).appendingPathComponent(TrollStorePaths.helperName)
        return try runProcess(helperPath, args, captureOutput: false).0
    }

    public static func executeCapturingOutput(args: [String]) throws -> (Int32, Data) {
        let helperPath = (Bundle.main.bundlePath as NSString).appendingPathComponent(TrollStorePaths.helperName)
        return try runProcess(helperPath, args, captureOutput: true)
    }

    private static func runProcess(_ executable: String, _ args: [String], captureOutput: Bool) throws -> (Int32, Data) {
        var argv: [UnsafeMutablePointer<CChar>?] = [strdup(executable)]
        argv.append(contentsOf: args.map { strdup($0) })
        argv.append(nil)
        defer {
            for ptr in argv {
                if let p = ptr { free(p) }
            }
        }

        var pipefd: [Int32] = [0, 0]
        var action: posix_spawn_file_actions_t? = nil
        posix_spawn_file_actions_init(&action)

        if captureOutput {
            if pipe(&pipefd) != 0 {
                posix_spawn_file_actions_destroy(&action)
                throw TrollStoreInstallError(code: -1)
            }
            posix_spawn_file_actions_adddup2(&action, pipefd[1], 1)
            posix_spawn_file_actions_addclose(&action, pipefd[0])
        }

        var pid: pid_t = 0
        let spawnResult = argv.withUnsafeMutableBufferPointer { buffer -> Int32 in
            return posix_spawn(&pid, executable, &action, nil, buffer.baseAddress, nil)
        }

        if captureOutput {
            close(pipefd[1])
        }

        if spawnResult != 0 {
            if captureOutput { close(pipefd[0]) }
            posix_spawn_file_actions_destroy(&action)
            throw TrollStoreInstallError(code: spawnResult)
        }

        var data = Data()
        if captureOutput {
            var buffer = [UInt8](repeating: 0, count: 4096)
            while true {
                let bytesRead = read(pipefd[0], &buffer, buffer.count)
                if bytesRead <= 0 { break }
                data.append(buffer, count: bytesRead)
            }
            close(pipefd[0])
        }

        var status: Int32 = 0
        waitpid(pid, &status, 0)
        posix_spawn_file_actions_destroy(&action)

        let exited = (status & 0x7f) == 0
        if !exited {
            throw TrollStoreInstallError(code: -1)
        }
        return (Int32((status >> 8) & 0xff), data)
    }
}

public class InstallationManager {
    public static func installIPA(path: String, force: Bool, useInstalldMethod: Bool, skipUICache: Bool) throws {
        var args = [TrollStoreCommands.install]
        if useInstalldMethod { args.append("installd") }
        if force { args.append("force") }
        if skipUICache { args.append("skip-uicache") }
        args.append(path)
        let ret = try RootHelper.execute(args: args)
        if ret != 0 { throw TrollStoreInstallError(code: ret) }
    }

    public static func uninstallApp(bundleId: String, useCustomMethod: Bool) throws {
        var args = [TrollStoreCommands.uninstall]
        if useCustomMethod { args.append("custom") }
        args.append(bundleId)
        let ret = try RootHelper.execute(args: args)
        if ret != 0 { throw TrollStoreInstallError(code: ret) }
    }

    public static func enableJIT(bundleId: String) throws {
        let ret = try RootHelper.execute(args: [TrollStoreCommands.enableJIT, bundleId])
        if ret != 0 { throw TrollStoreInstallError(code: ret) }
    }

    public static func changeRegistration(appPath: String, isSystem: Bool) throws {
        let registration = isSystem ? "System" : "User"
        let ret = try RootHelper.execute(args: [TrollStoreCommands.modifyRegistration, appPath, registration])
        if ret != 0 { throw TrollStoreInstallError(code: ret) }
    }

    public static func writeExtraEntitlements(appPath: String, entitlements: [String: Any]) throws {
        let data = try PropertyListSerialization.data(fromPropertyList: entitlements, format: .xml, options: 0)
        let target = (appPath as NSString).appendingPathComponent(TrollStorePaths.extraEntitlementsName)
        try data.write(to: URL(fileURLWithPath: target))
    }

    public static func clearExtraEntitlements(appPath: String) {
        let target = (appPath as NSString).appendingPathComponent(TrollStorePaths.extraEntitlementsName)
        try? FileManager.default.removeItem(atPath: target)
    }
}