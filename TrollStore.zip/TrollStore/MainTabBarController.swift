import UIKit
import SwiftUI

public class MainTabBarController: UITabBarController {
    public override func viewDidLoad() {
        super.viewDidLoad()

        let appListViewController = AppListViewController()
        appListViewController.title = NSLocalizedString("Apps", comment: "")

        let settingsHostingController = UIHostingController(rootView: SettingsView())
        settingsHostingController.title = NSLocalizedString("Settings", comment: "")

        let appNavigationController = UINavigationController(rootViewController: appListViewController)
        let settingsNavigationController = UINavigationController(rootViewController: settingsHostingController)

        appNavigationController.navigationBar.prefersLargeTitles = true
        settingsNavigationController.navigationBar.prefersLargeTitles = true

        appNavigationController.tabBarItem = UITabBarItem(
            title: NSLocalizedString("Apps", comment: ""),
            image: UIImage(systemName: "square.stack.3d.up.fill"),
            selectedImage: nil
        )

        settingsNavigationController.tabBarItem = UITabBarItem(
            title: NSLocalizedString("Settings", comment: ""),
            image: UIImage(systemName: "gear"),
            selectedImage: nil
        )

        viewControllers = [
            appNavigationController,
            settingsNavigationController
        ]
    }
}
