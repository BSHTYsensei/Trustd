import UIKit
import SwiftUI

public class MainTabBarController: UITabBarController {
    public override func viewDidLoad() {
        super.viewDidLoad()
        
        let appListViewController = AppListViewController()
        appListViewController.title = NSLocalizedString("Apps", comment: "")
        
        let settingsHostingController = UIHostingController(rootView: SettingsView())
        settingsHostingController.title = NSLocalizedString("Settings", comment: "")
        
        let appNavigationController = UINavigationController(rootViewController: appListViewController)
        let settingsNavigationController = UINavigationController(rootViewController: settingsHostingController)
        
        appNavigationController.tabBarItem.image = UIImage(systemName: "square.stack.3d.up.fill")
        settingsNavigationController.tabBarItem.image = UIImage(systemName: "gear")
        
        viewControllers = [appNavigationController, settingsNavigationController]
    }
}
