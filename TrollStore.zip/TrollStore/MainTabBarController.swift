import UIKit
import SwiftUI

public class MainTabBarController: UITabBarController {
    public override func viewDidLoad() {
        super.viewDidLoad()
        let appearance = UITabBarAppearance()
        appearance.configureWithTransparentBackground()
        appearance.backgroundEffect = UIBlurEffect(style: .systemUltraThinMaterial)
        appearance.backgroundColor = .clear
        appearance.shadowColor = .clear
        tabBar.standardAppearance = appearance
        if #available(iOS 15.0, *) {
            tabBar.scrollEdgeAppearance = appearance
        }
        let appListViewController = AppListViewController()
        appListViewController.title = NSLocalizedString("Apps", comment: "")
        let settingsHostingController = UIHostingController(rootView: SettingsView())
        settingsHostingController.title = NSLocalizedString("Settings", comment: "")
        let appNavigationController = UINavigationController(rootViewController: appListViewController)
        let settingsNavigationController = UINavigationController(rootViewController: settingsHostingController)
        appNavigationController.tabBarItem.image = UIImage(systemName: "square.stack.3d.up.fill")
        settingsNavigationController.tabBarItem.image = UIImage(systemName: "gear")
        viewControllers = [appNavigationController, settingsNavigationController]
    }
}
