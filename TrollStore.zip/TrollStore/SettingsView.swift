import SwiftUI
import Darwin

public class LdidManager {
    public static func initializeLdid() {
        let ldidPath = (getTrollStoreAppPath() as NSString).appendingPathComponent("ldid")
        let fm = FileManager.default
        if fm.fileExists(atPath: ldidPath) && fm.isExecutableFile(atPath: ldidPath) {
            return
        }
        if let bundleLdid = Bundle.main.path(forResource: "ldid", ofType: nil) {
            try? fm.copyItem(atPath: bundleLdid, toPath: ldidPath)
            chmod(ldidPath, 0o755)
        }
    }
}

struct SettingsView: View {
    @AppStorage("autoInitLdid") var autoInitLdid = false
    @AppStorage("urlSchemeEnabled") var urlSchemeEnabled = false
    @AppStorage("installAlertConfiguration") var installAlertConfiguration = 0
    @AppStorage("installationMethod") var installationMethod = 1
    @AppStorage("uninstallationMethod") var uninstallationMethod = 0
    
    @State private var showUninstallAlert = false
    @State private var showPersistenceHelperPicker = false
    @State private var showErrorAlert = false
    @State private var errorMessage = ""
    
    var body: some View {
        List {
            Section(NSLocalizedString("Installation", comment: "")) {
                Picker(NSLocalizedString("Installation_Method", comment: ""), selection: $installationMethod) {
                    Text(NSLocalizedString("Custom", comment: "")).tag(1)
                    Text("installd").tag(0)
                }
                
                Picker(NSLocalizedString("Uninstallation_Method", comment: ""), selection: $uninstallationMethod) {
                    Text(NSLocalizedString("Custom", comment: "")).tag(1)
                    Text("installd").tag(0)
                }
                
                Picker(NSLocalizedString("Install_Confirmation", comment: ""), selection: $installAlertConfiguration) {
                    Text(NSLocalizedString("Always", comment: "")).tag(0)
                    Text(NSLocalizedString("Only_Remote", comment: "")).tag(1)
                    Text(NSLocalizedString("Never", comment: "")).tag(2)
                }
                
                Toggle(NSLocalizedString("URL_Scheme", comment: ""), isOn: $urlSchemeEnabled)
                    .onChange(of: urlSchemeEnabled) { newValue in
                        executeHelperCommand(args: ["url-scheme", newValue ? "enable" : "disable"])
                    }
                
                Toggle(NSLocalizedString("Auto_Init_Ldid", comment: ""), isOn: $autoInitLdid)
            }
            
            Section(NSLocalizedString("Utilities", comment: "")) {
                Button(NSLocalizedString("Refresh_App_Registrations", comment: "")) {
                    executeHelperCommand(args: ["refresh"])
                }
                
                Button(NSLocalizedString("Rebuild_Icon_Cache", comment: "")) {
                    executeHelperCommand(args: ["refresh-all"])
                }
                
                Button(NSLocalizedString("Respring", comment: "")) {
                    executeHelperCommand(args: ["respring"])
                }
            }
            
            Section(NSLocalizedString("Persistence", comment: "")) {
                Button(NSLocalizedString("Install_Persistence_Helper", comment: "")) {
                    showPersistenceHelperPicker = true
                }
            }
            
            Section {
                Button(NSLocalizedString("Uninstall_TrollStore", comment: ""), role: .destructive) {
                    showUninstallAlert = true
                }
            }
        }
        .navigationTitle(NSLocalizedString("Settings", comment: ""))
        .onAppear {
            if autoInitLdid {
                LdidManager.initializeLdid()
            }
        }
        .alert(NSLocalizedString("Confirm_Uninstall", comment: ""), isPresented: $showUninstallAlert) {
            Button(NSLocalizedString("Cancel", comment: ""), role: .cancel) { }
            Button(NSLocalizedString("Uninstall", comment: ""), role: .destructive) {
                executeHelperCommand(args: ["uninstall-trollstore"])
            }
        }
        .confirmationDialog(NSLocalizedString("Select_System_App", comment: ""), isPresented: $showPersistenceHelperPicker, titleVisibility: .visible) {
            Button("Tips") {
                executeHelperCommand(args: ["install-persistence-helper", "com.apple.tips"])
            }
            Button("Shortcuts") {
                executeHelperCommand(args: ["install-persistence-helper", "com.apple.shortcuts"])
            }
            Button(NSLocalizedString("Cancel", comment: ""), role: .cancel) { }
        }
        .alert(NSLocalizedString("Error", comment: ""), isPresented: $showErrorAlert) {
            Button(NSLocalizedString("Close", comment: ""), role: .cancel) { }
        } message: {
            Text(errorMessage)
        }
    }
    
    private func executeHelperCommand(args: [String]) {
        let helperPath = (getTrollStoreAppPath() as NSString).appendingPathComponent("trollstorehelper")
        var argv: [UnsafeMutablePointer<CChar>?] = [strdup(helperPath)]
        argv.append(contentsOf: args.map { strdup($0) })
        argv.append(nil)
        defer {
            for ptr in argv {
                if let p = ptr { free(p) }
            }
        }
        
        var pid: pid_t = 0
        var status: Int32 = 0
        let spawnResult = argv.withUnsafeMutableBufferPointer { buffer -> Int32 in
            return posix_spawn(&pid, helperPath, nil, nil, buffer.baseAddress, nil)
        }
        
        if spawnResult != 0 {
            errorMessage = NSLocalizedString("Spawn_Failed", comment: "")
            showErrorAlert = true
            return
        }
        
        waitpid(pid, &status, 0)
        if !WIFEXITED(status) || WEXITSTATUS(status) != 0 {
            errorMessage = String(format: NSLocalizedString("Command_Failed_Code", comment: ""), WEXITSTATUS(status))
            showErrorAlert = true
        }
    }
}
