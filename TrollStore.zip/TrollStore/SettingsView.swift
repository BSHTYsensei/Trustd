import SwiftUI
import Foundation
import Darwin

public class LdidManager {
    public static func ldidPath() -> String {
        return (Bundle.main.bundlePath as NSString).appendingPathComponent(TrollStorePaths.ldidName)
    }
    public static func isInstalled() -> Bool {
        let path = ldidPath()
        let fm = FileManager.default
        return fm.fileExists(atPath: path) && fm.isExecutableFile(atPath: path)
    }
    public static func initializeLdid() {
        let ldidPath = ldidPath()
        let fm = FileManager.default
        if fm.fileExists(atPath: ldidPath) && fm.isExecutableFile(atPath: ldidPath) {
            return
        }
        if let bundleLdid = Bundle.main.path(forResource: TrollStorePaths.ldidName, ofType: nil) {
            if (try? fm.copyItem(atPath: bundleLdid, toPath: ldidPath)) != nil {
                _ = chmod(ldidPath, 0o755)
            }
        }
    }
}

struct PersistenceAppCandidate: Identifiable, Equatable {
    let id: String
    let name: String
    let bundleIdentifier: String
}

struct OptionSelectionView: View {
    let title: String
    @Binding var selection: Int
    let options: [(Int, String)]
    var body: some View {
        List {
            ForEach(options, id: \.0) { option in
                Button(action: {
                    selection = option.0
                }) {
                    HStack {
                        Text(option.1)
                            .foregroundStyle(.primary)
                        Spacer()
                        if selection == option.0 {
                            Image(systemName: "checkmark")
                                .foregroundStyle(.blue)
                        }
                    }
                    .contentShape(Rectangle())
                }
            }
        }
        .listStyle(.insetGrouped)
        .scrollContentBackground(.hidden)
        .background(.ultraThinMaterial)
        .navigationTitle(title)
        .navigationBarTitleDisplayMode(.inline)
    }
}

struct InstallAlertConfigurationView: View {
    @Binding var selection: Int
    var body: some View {
        OptionSelectionView(
            title: NSLocalizedString("Show Install Confirmation Alert", comment: ""),
            selection: $selection,
            options: [
                (0, NSLocalizedString("Always (Recommended)", comment: "")),
                (1, NSLocalizedString("Only on Remote URL Installs", comment: "")),
                (2, NSLocalizedString("Never (Not Recommeded)", comment: ""))
            ]
        )
    }
}

struct AdvancedSettingsView: View {
    @AppStorage(TrollStoreDefaults.installationMethod) var installationMethod = 1
    @AppStorage(TrollStoreDefaults.uninstallationMethod) var uninstallationMethod = 0
    private var installationMethodTitle: String {
        return installationMethod == 1 ? NSLocalizedString("Custom", comment: "") : "installd"
    }
    private var uninstallationMethodTitle: String {
        return uninstallationMethod == 1 ? NSLocalizedString("Custom", comment: "") : "installd"
    }
    var body: some View {
        List {
            Section(header: Text(NSLocalizedString("Installation", comment: "")).foregroundStyle(.secondary), footer: Text(NSLocalizedString("Choose whether apps are installed using installd or the custom method.", comment: "")).foregroundStyle(.secondary)) {
                NavigationLink(destination: OptionSelectionView(
                    title: NSLocalizedString("Installation Method", comment: ""),
                    selection: $installationMethod,
                    options: [
                        (0, "installd"),
                        (1, NSLocalizedString("Custom", comment: ""))
                    ]
                )) {
                    HStack {
                        Text(NSLocalizedString("Installation Method", comment: ""))
                            .foregroundStyle(.primary)
                        Spacer()
                        Text(installationMethodTitle)
                            .foregroundStyle(.secondary)
                    }
                }
            }
            Section(header: Text(NSLocalizedString("Uninstallation", comment: "")).foregroundStyle(.secondary), footer: Text(NSLocalizedString("Choose whether apps are uninstalled using installd or the custom method.", comment: "")).foregroundStyle(.secondary)) {
                NavigationLink(destination: OptionSelectionView(
                    title: NSLocalizedString("Uninstallation Method", comment: ""),
                    selection: $uninstallationMethod,
                    options: [
                        (0, "installd"),
                        (1, NSLocalizedString("Custom", comment: ""))
                    ]
                )) {
                    HStack {
                        Text(NSLocalizedString("Uninstallation Method", comment: ""))
                            .foregroundStyle(.primary)
                        Spacer()
                        Text(uninstallationMethodTitle)
                            .foregroundStyle(.secondary)
                    }
                }
            }
        }
        .listStyle(.insetGrouped)
        .scrollContentBackground(.hidden)
        .background(.ultraThinMaterial)
        .navigationTitle(NSLocalizedString("Advanced", comment: ""))
        .navigationBarTitleDisplayMode(.inline)
    }
}

struct SettingsView: View {
    @AppStorage(TrollStoreDefaults.autoInitLdid) var autoInitLdid = false
    @AppStorage(TrollStoreDefaults.installAlertConfiguration) var installAlertConfiguration = 0
    @AppStorage(TrollStoreDefaults.uninstallationMethod) var uninstallationMethod = 0
    @State private var urlSchemeEnabled = UserDefaults.standard.bool(forKey: TrollStoreDefaults.urlSchemeEnabled)
    @State private var devModeEnabled = true
    @State private var inactiveAppPaths: [String] = []
    @State private var ldidInstalled = LdidManager.isInstalled()
    @State private var installedPersistenceApp: PersistenceAppCandidate? = nil
    @State private var persistenceCandidates: [PersistenceAppCandidate] = []
    @State private var showUninstallAlert = false
    @State private var showPersistenceHelperPicker = false
    @State private var showErrorAlert = false
    @State private var showURLSchemeRebuildAlert = false
    @State private var showRebootRequiredAlert = false
    @State private var showTransferAlert = false
    @State private var showTransferErrorAlert = false
    @State private var errorTitle = NSLocalizedString("Error", comment: "")
    @State private var errorMessage = ""
    @State private var transferErrorMessage = ""
    @State private var transferErrorLog = ""
    
    private var urlSchemeBinding: Binding<Bool> {
        return Binding<Bool>(get: {
            urlSchemeEnabled
        }, set: { newValue in
            urlSchemeEnabled = newValue
            UserDefaults.standard.set(newValue, forKey: TrollStoreDefaults.urlSchemeEnabled)
            executeHelperCommand(args: ["url-scheme", newValue ? "enable" : "disable"])
            showURLSchemeRebuildAlert = true
        })
    }
    
    private var appName: String {
        return Bundle.main.object(forInfoDictionaryKey: "CFBundleDisplayName") as? String ?? Bundle.main.object(forInfoDictionaryKey: "CFBundleName") as? String ?? "TrollStore"
    }
    
    private var appVersion: String {
        return Bundle.main.object(forInfoDictionaryKey: "CFBundleShortVersionString") as? String ?? ""
    }
    
    private var otherFooter: String {
        if appVersion.isEmpty {
            return appName
        }
        return appName + " " + appVersion
    }
    
    private var utilitiesFooter: String {
        return NSLocalizedString("If an app does not immediately appear after installation, respring here and it should appear afterwards.", comment: "")
    }
    
    private var ldidVersion: String? {
        let versionPath = (Bundle.main.bundlePath as NSString).appendingPathComponent("ldid.version")
        guard let data = try? Data(contentsOf: URL(fileURLWithPath: versionPath)) else { return nil }
        return String(data: data, encoding: .utf8)
    }
    
    private var signingFooter: String {
        if ldidInstalled {
            return NSLocalizedString("ldid is installed and allows TrollStore to install unsigned IPA files.", comment: "")
        }
        return NSLocalizedString("In order for TrollStore to be able to install unsigned IPAs, ldid has to be installed using this button. It can't be directly included in TrollStore because of licensing issues.", comment: "")
    }
    
    private var standalonePersistenceInstalled: Bool {
        return FileManager.default.fileExists(atPath: "/Applications/TrollStorePersistenceHelper.app")
    }
    
    private var persistenceFooter: String {
        if standalonePersistenceInstalled {
            return NSLocalizedString("When iOS rebuilds the icon cache, all TrollStore apps including TrollStore itself will be reverted to \"User\" state and either disappear or no longer launch. If that happens, you can use the TrollHelper app on the home screen to refresh the app registrations, which will make them work again.", comment: "")
        }
        if let helper = installedPersistenceApp {
            return String(format: NSLocalizedString("When iOS rebuilds the icon cache, all TrollStore apps including TrollStore itself will be reverted to \"User\" state and either disappear or no longer launch. If that happens, you can use the persistence helper installed into %@ to refresh the app registrations, which will make them work again.", comment: ""), helper.name)
        }
        return NSLocalizedString("When iOS rebuilds the icon cache, all TrollStore apps including TrollStore itself will be reverted to \"User\" state and either disappear or no longer launch. The only way to have persistence in a rootless environment is to replace a system application, here you can select a system app to replace with a persistence helper that can be used to refresh the registrations of all TrollStore related apps in case they disappear or no longer launch.", comment: "")
    }
    
    private var securityFooter: String {
        return NSLocalizedString("The URL Scheme, when enabled, will allow apps and websites to trigger TrollStore installations through the apple-magnifier://install?url=<IPA_URL> URL scheme and enable JIT through the apple-magnifier://enable-jit?bundle-id=<BUNDLE_ID> URL scheme.", comment: "")
    }
    
    private var installAlertConfigurationTitle: String {
        switch installAlertConfiguration {
        case 0:
            return NSLocalizedString("Always (Recommended)", comment: "")
        case 1:
            return NSLocalizedString("Only on Remote URL Installs", comment: "")
        default:
            return NSLocalizedString("Never (Not Recommeded)", comment: "")
        }
    }
    
    private var transferAppsTitle: String {
        let count = inactiveAppPaths.count
        if count == 1 {
            return NSLocalizedString("Transfer 1 App", comment: "")
        }
        return String(format: NSLocalizedString("Transfer %d Apps", comment: ""), count)
    }
    
    private var transferAppsMessage: String {
        let count = inactiveAppPaths.count
        if count == 1 {
            return NSLocalizedString("This option will transfer 1 app from other TrollStore to TrollStore. Continue?", comment: "")
        }
        return String(format: NSLocalizedString("This option will transfer %d apps from other TrollStore to TrollStore. Continue?", comment: ""), count)
    }
    
    var body: some View {
        List {
            if #available(iOS 16, *), !devModeEnabled {
                Section(header: Text(NSLocalizedString("Developer Mode", comment: "")).foregroundStyle(.secondary), footer: Text(NSLocalizedString("Some apps require developer mode enabled to launch. This requires a reboot to take effect.", comment: "")).foregroundStyle(.secondary)) {
                    Button(NSLocalizedString("Enable Developer Mode", comment: "")) {
                        enableDeveloperMode()
                    }
                    .foregroundStyle(.primary)
                }
            }
            Section(header: Text(NSLocalizedString("Utilities", comment: "")).foregroundStyle(.secondary), footer: Text(utilitiesFooter).foregroundStyle(.secondary)) {
                Button(NSLocalizedString("Respring", comment: "")) {
                    executeHelperCommand(args: ["respring"])
                }
                .foregroundStyle(.primary)
                Button(NSLocalizedString("Refresh App Registrations", comment: "")) {
                    executeHelperCommand(args: ["refresh"])
                }
                .foregroundStyle(.primary)
                Button(NSLocalizedString("Rebuild Icon Cache", comment: "")) {
                    executeHelperCommand(args: ["refresh-all"])
                }
                .foregroundStyle(.primary)
                if !inactiveAppPaths.isEmpty {
                    Button(transferAppsTitle) {
                        showTransferAlert = true
                    }
                    .foregroundStyle(.primary)
                }
            }
            Section(header: Text(NSLocalizedString("Signing", comment: "")).foregroundStyle(.secondary), footer: Text(signingFooter).foregroundStyle(.secondary)) {
                if ldidInstalled {
                    if let version = ldidVersion {
                        Text(NSLocalizedString("ldid: Installed", comment: "") + " (" + version + ")")
                            .foregroundStyle(.primary)
                    } else {
                        Text(NSLocalizedString("ldid: Installed", comment: ""))
                            .foregroundStyle(.primary)
                    }
                } else {
                    Button(NSLocalizedString("Install ldid", comment: "")) {
                        LdidManager.initializeLdid()
                        ldidInstalled = LdidManager.isInstalled()
                    }
                    .foregroundStyle(.primary)
                }
            }
            Section(header: Text(NSLocalizedString("Persistence", comment: "")).foregroundStyle(.secondary), footer: Text(persistenceFooter).foregroundStyle(.secondary)) {
                if standalonePersistenceInstalled {
                    Text(NSLocalizedString("Helper Installed as Standalone App", comment: ""))
                        .foregroundStyle(.primary)
                } else if let helper = installedPersistenceApp {
                    Text(String(format: NSLocalizedString("Helper Installed into %@", comment: ""), helper.name))
                        .foregroundStyle(.primary)
                    Button(NSLocalizedString("Uninstall Persistence Helper", comment: ""), role: .destructive) {
                        uninstallPersistenceHelper()
                    }
                } else {
                    Button(NSLocalizedString("Install Persistence Helper", comment: "")) {
                        showPersistenceHelperPicker = true
                    }
                    .foregroundStyle(.primary)
                }
            }
            Section {
                NavigationLink(destination: AdvancedSettingsView()) {
                    Text(NSLocalizedString("Advanced", comment: ""))
                        .foregroundStyle(.primary)
                }
            }
            Section(header: Text(NSLocalizedString("Security", comment: "")).foregroundStyle(.secondary), footer: Text(securityFooter).foregroundStyle(.secondary)) {
                Toggle(NSLocalizedString("URL Scheme Enabled", comment: ""), isOn: urlSchemeBinding)
                    .foregroundStyle(.primary)
                NavigationLink(destination: InstallAlertConfigurationView(selection: $installAlertConfiguration)) {
                    HStack {
                        Text(NSLocalizedString("Show Install Confirmation Alert", comment: ""))
                            .foregroundStyle(.primary)
                        Spacer()
                        Text(installAlertConfigurationTitle)
                            .foregroundStyle(.secondary)
                    }
                }
            }
            Section(header: Text(""), footer: Text(otherFooter).foregroundStyle(.secondary)) {
                Button(NSLocalizedString("Uninstall TrollStore", comment: ""), role: .destructive) {
                    showUninstallAlert = true
                }
            }
        }
        .listStyle(.insetGrouped)
        .scrollContentBackground(.hidden)
        .background(.ultraThinMaterial)
        .navigationTitle(NSLocalizedString("Settings", comment: ""))
        .navigationBarTitleDisplayMode(.large)
        .onAppear {
            if autoInitLdid {
                LdidManager.initializeLdid()
            }
            reloadDynamicSettings()
        }
        .alert(NSLocalizedString("URL Scheme Changed", comment: ""), isPresented: $showURLSchemeRebuildAlert) {
            Button(NSLocalizedString("Rebuild Now", comment: "")) {
                executeHelperCommand(args: ["refresh-all"])
            }
            Button(NSLocalizedString("Rebuild Later", comment: ""), role: .cancel) { }
        } message: {
            Text(NSLocalizedString("In order to properly apply the change of the URL scheme setting, rebuilding the icon cache is needed.", comment: ""))
        }
        .alert(NSLocalizedString("Reboot Required", comment: ""), isPresented: $showRebootRequiredAlert) {
            Button(NSLocalizedString("Reboot Now", comment: "")) {
                executeHelperCommand(args: ["reboot"])
            }
            Button(NSLocalizedString("Close", comment: ""), role: .cancel) {
                reloadDeveloperMode()
            }
        } message: {
            Text(NSLocalizedString("After rebooting, select \"Turn On\" to enable developer mode.", comment: ""))
        }
        .alert(NSLocalizedString("Transfer Apps", comment: ""), isPresented: $showTransferAlert) {
            Button(NSLocalizedString("Transfer", comment: "")) {
                transferApps()
            }
            Button(NSLocalizedString("Cancel", comment: ""), role: .cancel) { }
        } message: {
            Text(transferAppsMessage)
        }
        .alert(NSLocalizedString("Transfer Failed", comment: ""), isPresented: $showTransferErrorAlert) {
            Button(NSLocalizedString("Copy Debug Log", comment: "")) {
                UIPasteboard.general.string = transferErrorLog
            }
            Button(NSLocalizedString("Close", comment: ""), role: .cancel) { }
        } message: {
            Text(transferErrorMessage)
        }
        .alert(NSLocalizedString("Confirm Uninstall", comment: ""), isPresented: $showUninstallAlert) {
            Button(NSLocalizedString("Cancel", comment: ""), role: .cancel) { }
            Button(NSLocalizedString("Uninstall", comment: ""), role: .destructive) {
                uninstallTrollStore()
            }
        }
        .confirmationDialog(NSLocalizedString("Select App", comment: ""), isPresented: $showPersistenceHelperPicker, titleVisibility: .visible) {
            ForEach(persistenceCandidates) { candidate in
                Button(candidate.name) {
                    installPersistenceHelper(bundleIdentifier: candidate.bundleIdentifier)
                }
            }
            if persistenceCandidates.isEmpty {
                Button("Tips") {
                    installPersistenceHelper(bundleIdentifier: "com.apple.tips")
                }
                Button("Shortcuts") {
                    installPersistenceHelper(bundleIdentifier: "com.apple.shortcuts")
                }
            }
            Button(NSLocalizedString("Cancel", comment: ""), role: .cancel) { }
        } message: {
            Text(NSLocalizedString("Select a system app to install the TrollStore Persistence Helper into. The normal function of the app will not be available, so it is recommended to pick something useless like the Tips app.", comment: ""))
        }
        .alert(errorTitle, isPresented: $showErrorAlert) {
            Button(NSLocalizedString("Close", comment: ""), role: .cancel) { }
        } message: {
            Text(errorMessage)
        }
    }
    
    private func reloadDynamicSettings() {
        ldidInstalled = LdidManager.isInstalled()
        inactiveAppPaths = inactiveAppBundlePaths()
        reloadDeveloperMode()
        reloadPersistenceState()
    }
    
    private func reloadDeveloperMode() {
        if #available(iOS 16, *) {
            DispatchQueue.global(qos: .userInitiated).async {
                let ret = (try? RootHelper.execute(args: ["check-dev-mode"])) ?? -1
                DispatchQueue.main.async {
                    devModeEnabled = (ret == 0)
                }
            }
        } else {
            devModeEnabled = true
        }
    }
    
    private func enableDeveloperMode() {
        DispatchQueue.global(qos: .userInitiated).async {
            let ret = (try? RootHelper.execute(args: ["arm-dev-mode"])) ?? -1
            DispatchQueue.main.async {
                if ret == 0 {
                    showRebootRequiredAlert = true
                } else {
                    errorTitle = String(format: NSLocalizedString("Error %d", comment: ""), ret)
                    errorMessage = NSLocalizedString("Failed to enable developer mode.", comment: "")
                    showErrorAlert = true
                }
            }
        }
    }
    
    private func transferApps() {
        DispatchQueue.global(qos: .userInitiated).async {
            var ret: Int32 = -1
            var logData = Data()
            if let result = try? RootHelper.executeCapturingOutput(args: ["transfer-apps"]) {
                ret = result.0
                logData = result.1
            }
            DispatchQueue.main.async {
                inactiveAppPaths = inactiveAppBundlePaths()
                if ret != 0 {
                    transferErrorLog = String(data: logData, encoding: .utf8) ?? ""
                    let count = inactiveAppPaths.count
                    if count == 1 {
                        transferErrorMessage = NSLocalizedString("Failed to transfer 1 app", comment: "")
                    } else {
                        transferErrorMessage = String(format: NSLocalizedString("Failed to transfer %d apps", comment: ""), count)
                    }
                    showTransferErrorAlert = true
                }
            }
        }
    }
    
    private func uninstallTrollStore() {
        var args = ["uninstall-trollstore"]
        if uninstallationMethod == 1 {
            args.append("custom")
        }
        executeHelperCommand(args: args)
    }
    
    private func installPersistenceHelper(bundleIdentifier: String) {
        executeHelperCommand(args: ["install-persistence-helper", bundleIdentifier])
        reloadPersistenceState()
    }
    
    private func uninstallPersistenceHelper() {
        executeHelperCommand(args: ["uninstall-persistence-helper"])
        reloadPersistenceState()
    }
    
    private func reloadPersistenceState() {
        DispatchQueue.global(qos: .userInitiated).async {
            let helper = installedPersistenceHelper()
            let candidates = persistenceAppCandidates()
            DispatchQueue.main.async {
                installedPersistenceApp = helper
                persistenceCandidates = candidates
            }
        }
    }
    
    private func installedPersistenceHelper() -> PersistenceAppCandidate? {
        let fm = FileManager.default
        for proxy in installedApplicationProxies() {
            let installed = boolValue(proxy, key: "installed")
            let restricted = boolValue(proxy, key: "restricted")
            let bundleIdentifier = stringValue(proxy, key: "bundleIdentifier")
            if !installed || restricted || bundleIdentifier.isEmpty {
                continue
            }
            let signaturePath = "/System/Library/AppSignatures/" + bundleIdentifier
            guard fm.fileExists(atPath: signaturePath) else {
                continue
            }
            if let bundleURL = urlValue(proxy, key: "bundleURL") {
                let markerURL = bundleURL.deletingLastPathComponent().appendingPathComponent(TrollStorePaths.activeMarker)
                if (try? markerURL.checkResourceIsReachable()) ?? false {
                    let name = stringValue(proxy, key: "localizedName")
                    return PersistenceAppCandidate(
                        id: bundleIdentifier,
                        name: name.isEmpty ? bundleIdentifier : name,
                        bundleIdentifier: bundleIdentifier
                    )
                }
            }
        }
        return nil
    }
    
    private func persistenceAppCandidates() -> [PersistenceAppCandidate] {
        let fm = FileManager.default
        var candidates: [PersistenceAppCandidate] = []
        for proxy in installedApplicationProxies() {
            let installed = boolValue(proxy, key: "installed")
            let restricted = boolValue(proxy, key: "restricted")
            let bundleIdentifier = stringValue(proxy, key: "bundleIdentifier")
            if !installed || restricted || bundleIdentifier.isEmpty {
                continue
            }
            let signaturePath = "/System/Library/AppSignatures/" + bundleIdentifier
            guard fm.fileExists(atPath: signaturePath) else {
                continue
            }
            if let bundleURL = urlValue(proxy, key: "bundleURL") {
                let markerURL = bundleURL.deletingLastPathComponent().appendingPathComponent(TrollStorePaths.activeMarker)
                let reachable = (try? markerURL.checkResourceIsReachable()) ?? false
                if !reachable {
                    let name = stringValue(proxy, key: "localizedName")
                    candidates.append(
                        PersistenceAppCandidate(
                            id: bundleIdentifier,
                            name: name.isEmpty ? bundleIdentifier : name,
                            bundleIdentifier: bundleIdentifier
                        )
                    )
                }
            }
        }
        return candidates.sorted {
            $0.name.localizedStandardCompare($1.name) == .orderedAscending
        }
    }
    
    private func installedApplicationProxies() -> [NSObject] {
        var apps: [NSObject] = []
        guard let cls = NSClassFromString("LSApplicationWorkspace") as? NSObject.Type,
              let workspace = cls.perform(NSSelectorFromString("defaultWorkspace"))?.takeUnretainedValue() as? NSObject else {
            return apps
        }
        let sel = NSSelectorFromString("enumerateApplicationsOfType:block:")
        guard workspace.responds(to: sel) else { return apps }
        typealias BlockType = @convention(block) (NSObject) -> Void
        let block: BlockType = { proxy in
            apps.append(proxy)
        }
        let imp = workspace.method(for: sel)
        typealias Fn = @convention(c) (NSObject, Selector, UInt, BlockType) -> Void
        let fn = unsafeBitCast(imp, to: Fn.self)
        fn(workspace, sel, 0, block)
        fn(workspace, sel, 1, block)
        return apps
    }
    
    private func boolValue(_ proxy: NSObject, key: String) -> Bool {
        guard proxy.responds(to: NSSelectorFromString(key)) else { return false }
        return (proxy.value(forKey: key) as? NSNumber)?.boolValue ?? false
    }
    
    private func stringValue(_ proxy: NSObject, key: String) -> String {
        guard proxy.responds(to: NSSelectorFromString(key)) else { return "" }
        return (proxy.value(forKey: key) as? String) ?? ""
    }
    
    private func urlValue(_ proxy: NSObject, key: String) -> URL? {
        guard proxy.responds(to: NSSelectorFromString(key)) else { return nil }
        return proxy.value(forKey: key) as? URL
    }
    
    private func inactiveAppBundlePaths() -> [String] {
        let fm = FileManager.default
        let appsRoot = TrollStorePaths.applicationsPath
        var paths: [String] = []
        guard let containerDirs = try? fm.contentsOfDirectory(atPath: appsRoot) else {
            return paths
        }
        for containerDir in containerDirs {
            let containerPath = (appsRoot as NSString).appendingPathComponent(containerDir)
            var isDir: ObjCBool = false
            guard fm.fileExists(atPath: containerPath, isDirectory: &isDir), isDir.boolValue else {
                continue
            }
            let inactiveMarker = (containerPath as NSString).appendingPathComponent(TrollStorePaths.inactiveMarker)
            if fm.fileExists(atPath: inactiveMarker) {
                if let appPath = findAppPath(in: containerPath) {
                    paths.append(appPath)
                }
            }
        }
        return paths
    }
    
    private func findAppPath(in containerPath: String) -> String? {
        let fm = FileManager.default
        guard let contents = try? fm.contentsOfDirectory(atPath: containerPath) else {
            return nil
        }
        for item in contents {
            if item.hasSuffix(".app") {
                let appPath = (containerPath as NSString).appendingPathComponent(item)
                var isDir: ObjCBool = false
                if fm.fileExists(atPath: appPath, isDirectory: &isDir) && isDir.boolValue {
                    return appPath
                }
            }
        }
        return nil
    }
    
    private func executeHelperCommand(args: [String]) {
        do {
            let ret = try RootHelper.execute(args: args)
            if ret != 0 {
                errorTitle = String(format: NSLocalizedString("Error %d", comment: ""), Int(ret))
                errorMessage = NSLocalizedString("Command failed.", comment: "")
                showErrorAlert = true
            }
        } catch {
            errorTitle = NSLocalizedString("Error", comment: "")
            errorMessage = NSLocalizedString("Failed to spawn helper.", comment: "")
            showErrorAlert = true
        }
    }
}
