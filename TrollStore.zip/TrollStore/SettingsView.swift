import SwiftUI
import Darwin

public class LdidManager {
    public static func initializeLdid() {
        let ldidPath = (Bundle.main.bundlePath as NSString).appendingPathComponent(TrollStorePaths.ldidName)
        let fm = FileManager.default
        if fm.fileExists(atPath: ldidPath) && fm.isExecutableFile(atPath: ldidPath) {
            return
        }
        if let bundleLdid = Bundle.main.path(forResource: TrollStorePaths.ldidName, ofType: nil) {
            try? fm.copyItem(atPath: bundleLdid, toPath: ldidPath)
            chmod(ldidPath, 0o755)
        }
    }
}

struct SettingsView: View {
    @AppStorage(TrollStoreDefaults.autoInitLdid) var autoInitLdid = false
    @AppStorage(TrollStoreDefaults.urlSchemeEnabled) var urlSchemeEnabled = false
    @AppStorage(TrollStoreDefaults.installAlertConfiguration) var installAlertConfiguration = 0
    @AppStorage(TrollStoreDefaults.installationMethod) var installationMethod = 1
    @AppStorage(TrollStoreDefaults.uninstallationMethod) var uninstallationMethod = 0
    @State private var showUninstallAlert = false
    @State private var showPersistenceHelperPicker = false
    @State private var showErrorAlert = false
    @State private var errorMessage = ""

    var body: some View {
        List {
            Section(NSLocalizedString("Installation", comment: "")) {
                Picker(NSLocalizedString("Installation_Method", comment: ""), selection: $installationMethod) {
                    Text(NSLocalizedString("Custom", comment: "")).tag(1)
                    Text("installd").tag(0)
                }
                Picker(NSLocalizedString("Uninstallation_Method", comment: ""), selection: $uninstallationMethod) {
                    Text(NSLocalizedString("Custom", comment: "")).tag(1)
                    Text("installd").tag(0)
                }
                Picker(NSLocalizedString("Install_Confirmation", comment: ""), selection: $installAlertConfiguration) {
                    Text(NSLocalizedString("Always", comment: "")).tag(0)
                    Text(NSLocalizedString("Only_Remote", comment: "")).tag(1)
                    Text(NSLocalizedString("Never", comment: "")).tag(2)
                }
                Toggle(NSLocalizedString("URL_Scheme", comment: ""), isOn: $urlSchemeEnabled)
                    .onChange(of: urlSchemeEnabled) { newValue in
                        executeHelperCommand(args: [TrollStoreCommands.urlScheme, newValue ? "enable" : "disable"])
                    }
                Toggle(NSLocalizedString("Auto_Init_Ldid", comment: ""), isOn: $autoInitLdid)
            }
            Section(NSLocalizedString("Utilities", comment: "")) {
                Button(NSLocalizedString("Refresh_App_Registrations", comment: "")) {
                    executeHelperCommand(args: [TrollStoreCommands.refresh])
                }
                Button(NSLocalizedString("Rebuild_Icon_Cache", comment: "")) {
                    executeHelperCommand(args: [TrollStoreCommands.refreshAll])
                }
                Button(NSLocalizedString("Respring", comment: "")) {
                    executeHelperCommand(args: [TrollStoreCommands.respring])
                }
            }
            Section(NSLocalizedString("Persistence", comment: "")) {
                Button(NSLocalizedString("Install_Persistence_Helper", comment: "")) {
                    showPersistenceHelperPicker = true
                }
            }
            Section {
                Button(NSLocalizedString("Uninstall_TrollStore", comment: ""), role: .destructive) {
                    showUninstallAlert = true
                }
            }
        }
        .navigationTitle(NSLocalizedString("Settings", comment: ""))
        .onAppear {
            if autoInitLdid {
                LdidManager.initializeLdid()
            }
        }
        .alert(NSLocalizedString("Confirm_Uninstall", comment: ""), isPresented: $showUninstallAlert) {
            Button(NSLocalizedString("Cancel", comment: ""), role: .cancel) { }
            Button(NSLocalizedString("Uninstall", comment: ""), role: .destructive) {
                executeHelperCommand(args: [TrollStoreCommands.uninstallTrollStore])
            }
        }
        .confirmationDialog(NSLocalizedString("Select_System_App", comment: ""), isPresented: $showPersistenceHelperPicker, titleVisibility: .visible) {
            Button("Tips") {
                executeHelperCommand(args: [TrollStoreCommands.installPersistenceHelper, "com.apple.tips"])
            }
            Button("Shortcuts") {
                executeHelperCommand(args: [TrollStoreCommands.installPersistenceHelper, "com.apple.shortcuts"])
            }
            Button(NSLocalizedString("Cancel", comment: ""), role: .cancel) { }
        }
        .alert(NSLocalizedString("Error", comment: ""), isPresented: $showErrorAlert) {
            Button(NSLocalizedString("Close", comment: ""), role: .cancel) { }
        } message: {
            Text(errorMessage)
        }
    }

    private func executeHelperCommand(args: [String]) {
        do {
            let ret = try RootHelper.execute(args: args)
            if ret != 0 {
                errorMessage = String(format: NSLocalizedString("Command_Failed_Code", comment: ""), ret)
                showErrorAlert = true
            }
        } catch {
            errorMessage = NSLocalizedString("Spawn_Failed", comment: "")
            showErrorAlert = true
        }
    }
}