import SwiftUI
import Foundation
import Darwin

public class LdidManager {
    public static func ldidPath() -> String {
        return (Bundle.main.bundlePath as NSString).appendingPathComponent(TrollStorePaths.ldidName)
    }

    public static func isInstalled() -> Bool {
        let path = ldidPath()
        let fm = FileManager.default
        return fm.fileExists(atPath: path) && fm.isExecutableFile(atPath: path)
    }

    public static func initializeLdid() {
        let ldidPath = ldidPath()
        let fm = FileManager.default
        if fm.fileExists(atPath: ldidPath) && fm.isExecutableFile(atPath: ldidPath) {
            return
        }
        if let bundleLdid = Bundle.main.path(forResource: TrollStorePaths.ldidName, ofType: nil) {
            if (try? fm.copyItem(atPath: bundleLdid, toPath: ldidPath)) != nil {
                _ = chmod(ldidPath, 0o755)
            }
        }
    }
}

struct AdvancedSettingsView: View {
    @AppStorage(TrollStoreDefaults.installationMethod) var installationMethod = 1
    @AppStorage(TrollStoreDefaults.uninstallationMethod) var uninstallationMethod = 0
    @AppStorage(TrollStoreDefaults.autoInitLdid) var autoInitLdid = false

    var body: some View {
        List {
            Section(header: Text(NSLocalizedString("Installation", comment: ""))) {
                Picker(NSLocalizedString("Installation Method", comment: ""), selection: $installationMethod) {
                    Text(NSLocalizedString("Custom", comment: "")).tag(1)
                    Text("installd").tag(0)
                }

                Picker(NSLocalizedString("Uninstallation Method", comment: ""), selection: $uninstallationMethod) {
                    Text(NSLocalizedString("Custom", comment: "")).tag(1)
                    Text("installd").tag(0)
                }

                Toggle(NSLocalizedString("Auto Init ldid", comment: ""), isOn: $autoInitLdid)
            }
        }
        .listStyle(.insetGrouped)
        .navigationTitle(NSLocalizedString("Advanced", comment: ""))
        .navigationBarTitleDisplayMode(.inline)
    }
}

struct SettingsView: View {
    @AppStorage(TrollStoreDefaults.autoInitLdid) var autoInitLdid = false
    @AppStorage(TrollStoreDefaults.installAlertConfiguration) var installAlertConfiguration = 0
    @AppStorage(TrollStoreDefaults.uninstallationMethod) var uninstallationMethod = 0

    @State private var urlSchemeEnabled = Bundle.main.object(forInfoDictionaryKey: "CFBundleURLTypes") != nil
    @State private var devModeEnabled = true
    @State private var inactiveAppPaths: [String] = []
    @State private var ldidInstalled = LdidManager.isInstalled()

    @State private var showUninstallAlert = false
    @State private var showPersistenceHelperPicker = false
    @State private var showErrorAlert = false
    @State private var showURLSchemeRebuildAlert = false
    @State private var showRebootRequiredAlert = false
    @State private var showTransferAlert = false

    @State private var errorTitle = NSLocalizedString("Error", comment: "")
    @State private var errorMessage = ""

    private var urlSchemeBinding: Binding<Bool> {
        return Binding<Bool>(get: {
            urlSchemeEnabled
        }, set: { newValue in
            urlSchemeEnabled = newValue
            executeHelperCommand(args: [TrollStoreCommands.urlScheme, newValue ? "enable" : "disable"])
            showURLSchemeRebuildAlert = true
        })
    }

    private var appName: String {
        return Bundle.main.object(forInfoDictionaryKey: "CFBundleDisplayName") as? String ?? Bundle.main.object(forInfoDictionaryKey: "CFBundleName") as? String ?? "TrollStore"
    }

    private var appVersion: String {
        return Bundle.main.object(forInfoDictionaryKey: "CFBundleShortVersionString") as? String ?? ""
    }

    private var utilitiesFooter: String {
        return NSLocalizedString("If an app does not immediately appear after installation, respring here and it should appear afterwards.", comment: "")
    }

    private var ldidVersion: String? {
        let versionPath = (Bundle.main.bundlePath as NSString).appendingPathComponent("ldid.version")
        guard let data = try? Data(contentsOf: URL(fileURLWithPath: versionPath)) else { return nil }
        return String(data: data, encoding: .utf8)
    }

    private var signingFooter: String {
        if ldidInstalled {
            return NSLocalizedString("ldid is installed and allows TrollStore to install unsigned IPA files.", comment: "")
        }
        return NSLocalizedString("In order for TrollStore to be able to install unsigned IPAs, ldid has to be installed using this button. It can't be directly included in TrollStore because of licensing issues.", comment: "")
    }

    private var standalonePersistenceInstalled: Bool {
        return FileManager.default.fileExists(atPath: "/Applications/TrollStorePersistenceHelper.app")
    }

    private var persistenceFooter: String {
        if standalonePersistenceInstalled {
            return NSLocalizedString("When iOS rebuilds the icon cache, all TrollStore apps including TrollStore itself will be reverted to \"User\" state and either disappear or no longer launch. If that happens, you can use the TrollHelper app on the home screen to refresh the app registrations, which will make them work again.", comment: "")
        }
        return NSLocalizedString("When iOS rebuilds the icon cache, all TrollStore apps including TrollStore itself will be reverted to \"User\" state and either disappear or no longer launch. The only way to have persistence in a rootless environment is to replace a system application, here you can select a system app to replace with a persistence helper that can be used to refresh the registrations of all TrollStore related apps in case they disappear or no longer launch.", comment: "")
    }

    private var securityFooter: String {
        return NSLocalizedString("The URL Scheme, when enabled, will allow apps and websites to trigger TrollStore installations through the apple-magnifier://install?url=<IPA_URL> URL scheme and enable JIT through the apple-magnifier://enable-jit?bundle-id=<BUNDLE_ID> URL scheme.", comment: "")
    }

    private var otherFooter: String {
        let titleLine = appVersion.isEmpty ? appName : appName + " " + appVersion
        return titleLine + "\n\n© 2022-2026 Lars Fröder (opa334)\n\nTrollStore is NOT for piracy!\n\nCredits:\nGoogle TAG, @alfiecg_dev: CoreTrust bug\n@lunotech11, @SerenaKit, @tylinux, @TheRealClarity, @dhinakg, @khanhduytran0: Various contributions\n@ProcursusTeam: uicache, ldid\n@cstar_ow: uicache\n@saurik: ldid"
    }

    private var transferAppsTitle: String {
        let count = inactiveAppPaths.count
        if count == 1 {
            return NSLocalizedString("Transfer 1 App", comment: "")
        }
        return String(format: NSLocalizedString("Transfer %d Apps", comment: ""), count)
    }

    private var transferAppsMessage: String {
        let count = inactiveAppPaths.count
        if count == 1 {
            return NSLocalizedString("This option will transfer 1 app from other TrollStore to TrollStore. Continue?", comment: "")
        }
        return String(format: NSLocalizedString("This option will transfer %d apps from other TrollStore to TrollStore. Continue?", comment: ""), count)
    }

    var body: some View {
        List {
            if #available(iOS 16, *), !devModeEnabled {
                Section(header: Text(NSLocalizedString("Developer Mode", comment: "")), footer: Text(NSLocalizedString("Some apps require developer mode enabled to launch. This requires a reboot to take effect.", comment: ""))) {
                    Button(NSLocalizedString("Enable Developer Mode", comment: "")) {
                        enableDeveloperMode()
                    }
                }
            }

            Section(header: Text(NSLocalizedString("Utilities", comment: "")), footer: Text(utilitiesFooter)) {
                Button(NSLocalizedString("Respring", comment: "")) {
                    executeHelperCommand(args: [TrollStoreCommands.respring])
                }

                Button(NSLocalizedString("Refresh App Registrations", comment: "")) {
                    executeHelperCommand(args: [TrollStoreCommands.refresh])
                }

                Button(NSLocalizedString("Rebuild Icon Cache", comment: "")) {
                    executeHelperCommand(args: [TrollStoreCommands.refreshAll])
                }

                if !inactiveAppPaths.isEmpty {
                    Button(transferAppsTitle) {
                        showTransferAlert = true
                    }
                }
            }

            Section(header: Text(NSLocalizedString("Signing", comment: "")), footer: Text(signingFooter)) {
                if ldidInstalled {
                    if let version = ldidVersion {
                        Text(NSLocalizedString("ldid: Installed", comment: "") + " (" + version + ")")
                    } else {
                        Text(NSLocalizedString("ldid: Installed", comment: ""))
                    }
                } else {
                    Button(NSLocalizedString("Install ldid", comment: "")) {
                        LdidManager.initializeLdid()
                        ldidInstalled = LdidManager.isInstalled()
                    }
                }
            }

            Section(header: Text(NSLocalizedString("Persistence", comment: "")), footer: Text(persistenceFooter)) {
                if standalonePersistenceInstalled {
                    Text(NSLocalizedString("Helper Installed as Standalone App", comment: ""))
                } else {
                    Button(NSLocalizedString("Install Persistence Helper", comment: "")) {
                        showPersistenceHelperPicker = true
                    }
                }
            }

            Section(header: Text(NSLocalizedString("Security", comment: "")), footer: Text(securityFooter)) {
                Toggle(NSLocalizedString("URL Scheme Enabled", comment: ""), isOn: urlSchemeBinding)

                Picker(NSLocalizedString("Show Install Confirmation Alert", comment: ""), selection: $installAlertConfiguration) {
                    Text(NSLocalizedString("Always (Recommended)", comment: "")).tag(0)
                    Text(NSLocalizedString("Only on Remote URL Installs", comment: "")).tag(1)
                    Text(NSLocalizedString("Never (Not Recommeded)", comment: "")).tag(2)
                }
            }

            Section(header: Text(""), footer: Text(otherFooter)) {
                NavigationLink(destination: AdvancedSettingsView()) {
                    Text(NSLocalizedString("Advanced", comment: ""))
                }

                Button(NSLocalizedString("Uninstall TrollStore", comment: ""), role: .destructive) {
                    showUninstallAlert = true
                }
            }
        }
        .listStyle(.insetGrouped)
        .navigationTitle(NSLocalizedString("Settings", comment: ""))
        .navigationBarTitleDisplayMode(.large)
        .onAppear {
            if autoInitLdid {
                LdidManager.initializeLdid()
            }
            reloadDynamicSettings()
        }
        .alert(NSLocalizedString("URL Scheme Changed", comment: ""), isPresented: $showURLSchemeRebuildAlert) {
            Button(NSLocalizedString("Rebuild Now", comment: "")) {
                executeHelperCommand(args: [TrollStoreCommands.refreshAll])
            }
            Button(NSLocalizedString("Rebuild Later", comment: ""), role: .cancel) { }
        } message: {
            Text(NSLocalizedString("In order to properly apply the change of the URL scheme setting, rebuilding the icon cache is needed.", comment: ""))
        }
        .alert(NSLocalizedString("Reboot Required", comment: ""), isPresented: $showRebootRequiredAlert) {
            Button(NSLocalizedString("Reboot Now", comment: "")) {
                executeHelperCommand(args: ["reboot"])
            }
            Button(NSLocalizedString("Close", comment: ""), role: .cancel) {
                reloadDeveloperMode()
            }
        } message: {
            Text(NSLocalizedString("After rebooting, select \"Turn On\" to enable developer mode.", comment: ""))
        }
        .alert(NSLocalizedString("Transfer Apps", comment: ""), isPresented: $showTransferAlert) {
            Button(NSLocalizedString("Transfer", comment: "")) {
                transferApps()
            }
            Button(NSLocalizedString("Cancel", comment: ""), role: .cancel) { }
        } message: {
            Text(transferAppsMessage)
        }
        .alert(NSLocalizedString("Confirm Uninstall", comment: ""), isPresented: $showUninstallAlert) {
            Button(NSLocalizedString("Cancel", comment: ""), role: .cancel) { }
            Button(NSLocalizedString("Uninstall", comment: ""), role: .destructive) {
                uninstallTrollStore()
            }
        }
        .confirmationDialog(NSLocalizedString("Select App", comment: ""), isPresented: $showPersistenceHelperPicker, titleVisibility: .visible) {
            Button("Tips") {
                executeHelperCommand(args: [TrollStoreCommands.installPersistenceHelper, "com.apple.tips"])
                reloadDynamicSettings()
            }
            Button("Shortcuts") {
                executeHelperCommand(args: [TrollStoreCommands.installPersistenceHelper, "com.apple.shortcuts"])
                reloadDynamicSettings()
            }
            Button(NSLocalizedString("Cancel", comment: ""), role: .cancel) { }
        } message: {
            Text(NSLocalizedString("Select a system app to install the TrollStore Persistence Helper into. The normal function of the app will not be available, so it is recommended to pick something useless like the Tips app.", comment: ""))
        }
        .alert(errorTitle, isPresented: $showErrorAlert) {
            Button(NSLocalizedString("Close", comment: ""), role: .cancel) { }
        } message: {
            Text(errorMessage)
        }
    }

    private func reloadDynamicSettings() {
        ldidInstalled = LdidManager.isInstalled()
        inactiveAppPaths = inactiveAppBundlePaths()
        reloadDeveloperMode()
    }

    private func reloadDeveloperMode() {
        if #available(iOS 16, *) {
            DispatchQueue.global(qos: .userInitiated).async {
                let ret = (try? RootHelper.execute(args: ["check-dev-mode"])) ?? -1
                DispatchQueue.main.async {
                    devModeEnabled = (ret == 0)
                }
            }
        } else {
            devModeEnabled = true
        }
    }

    private func enableDeveloperMode() {
        DispatchQueue.global(qos: .userInitiated).async {
            let ret = (try? RootHelper.execute(args: ["arm-dev-mode"])) ?? -1
            DispatchQueue.main.async {
                if ret == 0 {
                    showRebootRequiredAlert = true
                } else {
                    errorTitle = String(format: NSLocalizedString("Error %d", comment: ""), ret)
                    errorMessage = NSLocalizedString("Failed to enable developer mode.", comment: "")
                    showErrorAlert = true
                }
            }
        }
    }

    private func transferApps() {
        DispatchQueue.global(qos: .userInitiated).async {
            let ret = (try? RootHelper.execute(args: ["transfer-apps"])) ?? -1
            DispatchQueue.main.async {
                inactiveAppPaths = inactiveAppBundlePaths()
                if ret != 0 {
                    errorTitle = NSLocalizedString("Transfer Failed", comment: "")
                    let count = inactiveAppPaths.count
                    if count == 1 {
                        errorMessage = NSLocalizedString("Failed to transfer 1 app", comment: "")
                    } else {
                        errorMessage = String(format: NSLocalizedString("Failed to transfer %d apps", comment: ""), count)
                    }
                    showErrorAlert = true
                }
            }
        }
    }

    private func uninstallTrollStore() {
        var args = [TrollStoreCommands.uninstallTrollStore]
        if uninstallationMethod == 1 {
            args.append("custom")
        }
        executeHelperCommand(args: args)
    }

    private func inactiveAppBundlePaths() -> [String] {
        let fm = FileManager.default
        let appsRoot = TrollStorePaths.applicationsPath
        var paths: [String] = []

        guard let containerDirs = try? fm.contentsOfDirectory(atPath: appsRoot) else {
            return paths
        }

        for containerDir in containerDirs {
            let containerPath = (appsRoot as NSString).appendingPathComponent(containerDir)
            var isDir: ObjCBool = false

            guard fm.fileExists(atPath: containerPath, isDirectory: &isDir), isDir.boolValue else {
                continue
            }

            let inactiveMarker = (containerPath as NSString).appendingPathComponent(TrollStorePaths.inactiveMarker)
            if fm.fileExists(atPath: inactiveMarker) {
                if let appPath = findAppPath(in: containerPath) {
                    paths.append(appPath)
                }
            }
        }

        return paths
    }

    private func findAppPath(in containerPath: String) -> String? {
        let fm = FileManager.default
        guard let contents = try? fm.contentsOfDirectory(atPath: containerPath) else { return nil }

        for item in contents {
            if item.hasSuffix(".app") {
                let appPath = (containerPath as NSString).appendingPathComponent(item)
                var isDir: ObjCBool = false
                if fm.fileExists(atPath: appPath, isDirectory: &isDir) && isDir.boolValue {
                    return appPath
                }
            }
        }

        return nil
    }

    private func executeHelperCommand(args: [String]) {
        do {
            let ret = try RootHelper.execute(args: args)
            if ret != 0 {
                errorTitle = String(format: NSLocalizedString("Error %d", comment: ""), Int(ret))
                errorMessage = NSLocalizedString("Command failed.", comment: "")
                showErrorAlert = true
            }
        } catch {
            errorTitle = NSLocalizedString("Error", comment: "")
            errorMessage = NSLocalizedString("Failed to spawn helper.", comment: "")
            showErrorAlert = true
        }
    }
}
