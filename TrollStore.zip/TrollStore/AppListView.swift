import UIKit
import Foundation
public class AppListViewController: UIViewController {
private let tableView = UITableView(frame: .zero, style: .plain)
private let refreshControl = UIRefreshControl()
private var installedApps: [TrollStoreAppInfo] = []
private let dataSource = AppListDataSource()
public override func viewDidLoad() {
     super.viewDidLoad()
     title = NSLocalizedString("Apps", comment: "")
     view.backgroundColor = .systemBackground
     setupTableView()
     setupNavigationBar()
     loadApps()
 }
 public override func viewWillAppear(_ animated: Bool) {
     super.viewWillAppear(animated)
     loadApps()
 }
 private func setupTableView() {
     tableView.translatesAutoresizingMaskIntoConstraints = false
     tableView.dataSource = dataSource
     tableView.delegate = dataSource
     tableView.register(AppListCell.self, forCellReuseIdentifier: AppListCell.reuseIdentifier)
     tableView.rowHeight = 80
     tableView.refreshControl = refreshControl
     refreshControl.addTarget(self, action: #selector(loadApps), for: .valueChanged)
     view.addSubview(tableView)
     NSLayoutConstraint.activate([
         tableView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
         tableView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
         tableView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
         tableView.bottomAnchor.constraint(equalTo: view.bottomAnchor)
     ])
     dataSource.onCellAction = { [weak self] action, appInfo in
         self?.handleCellAction(action, for: appInfo)
     }
 }
 private func setupNavigationBar() {
     let installButton = UIBarButtonItem(barButtonSystemItem: .add, target: self, action: #selector(installAppTapped))
     navigationItem.rightBarButtonItem = installButton
 }
 @objc private func loadApps() {
     DispatchQueue.global(qos: .userInitiated).async { [weak self] in
         let apps = InstalledAppsManager.fetchInstalledApps()
         DispatchQueue.main.async {
             self?.installedApps = apps
             self?.dataSource.apps = apps
             self?.tableView.reloadData()
             self?.refreshControl.endRefreshing()
         }
     }
 }
 @objc private func installAppTapped() {
     let picker = UIDocumentPickerViewController(forOpeningContentTypes: [.item])
     picker.delegate = self
     picker.allowsMultipleSelection = false
     present(picker, animated: true)
 }
 private func handleCellAction(_ action: AppCellAction, for appInfo: TrollStoreAppInfo) {
     switch action {
     case .open:
         openApp(appInfo)
     case .uninstall:
         confirmUninstall(appInfo)
     case .enableJIT:
         enableJIT(appInfo)
     case .changeRegistration:
         changeRegistration(appInfo)
     case .editEntitlements:
         editEntitlements(appInfo)
     }
 }
 private func openApp(_ appInfo: TrollStoreAppInfo) {
     let workspace = LSApplicationWorkspaceProxy.defaultWorkspace()
     _ = workspace?.openApplication(withBundleID: appInfo.bundleIdentifier)
 }
 private func confirmUninstall(_ appInfo: TrollStoreAppInfo) {
     let alert = UIAlertController(
         title: NSLocalizedString("Uninstall_App", comment: ""),
         message: String(format: NSLocalizedString("Uninstall_App_Message", comment: ""), appInfo.displayName),
         preferredStyle: .alert
     )
     let cancelAction = UIAlertAction(title: NSLocalizedString("Cancel", comment: ""), style: .cancel)
     let uninstallAction = UIAlertAction(title: NSLocalizedString("Uninstall", comment: ""), style: .destructive) { [weak self] _ in
         self?.uninstallApp(appInfo)
     }
     alert.addAction(cancelAction)
     alert.addAction(uninstallAction)
     present(alert, animated: true)
 }
 private func uninstallApp(_ appInfo: TrollStoreAppInfo) {
     InstallationProgressController.show(on: self)
     DispatchQueue.global(qos: .userInitiated).async { [weak self] in
         do {
             try UIAppManager.uninstallApp(bundleId: appInfo.bundleIdentifier)
             DispatchQueue.main.async {
                 InstallationProgressController.hide()
                 self?.loadApps()
             }
         } catch {
             DispatchQueue.main.async {
                 InstallationProgressController.hide()
                 ErrorHandler.showError(error, on: self)
             }
         }
     }
 }
 private func enableJIT(_ appInfo: TrollStoreAppInfo) {
     InstallationProgressController.show(on: self, message: NSLocalizedString("Enabling_JIT", comment: ""))
     DispatchQueue.global(qos: .userInitiated).async { [weak self] in
         do {
             try UIAppManager.enableJIT(bundleId: appInfo.bundleIdentifier)
             DispatchQueue.main.async {
                 InstallationProgressController.hide()
                 ErrorHandler.showSuccess(on: self, message: NSLocalizedString("JIT_Enabled", comment: ""))
             }
         } catch {
             DispatchQueue.main.async {
                 InstallationProgressController.hide()
                 ErrorHandler.showError(error, on: self)
             }
         }
     }
 }
 private func changeRegistration(_ appInfo: TrollStoreAppInfo) {
     let alert = UIAlertController(
         title: NSLocalizedString("Change_Registration", comment: ""),
         message: nil,
         preferredStyle: .actionSheet
     )
     let systemAction = UIAlertAction(title: NSLocalizedString("System", comment: ""), style: .default) { [weak self] _ in
         self?.setRegistration(appInfo, isSystem: true)
     }
     let userAction = UIAlertAction(title: NSLocalizedString("User", comment: ""), style: .default) { [weak self] _ in
         self?.setRegistration(appInfo, isSystem: false)
     }
     let cancelAction = UIAlertAction(title: NSLocalizedString("Cancel", comment: ""), style: .cancel)
     alert.addAction(systemAction)
     alert.addAction(userAction)
     alert.addAction(cancelAction)
     if let popover = alert.popoverPresentationController {
         popover.sourceView = self.view
         popover.sourceRect = CGRect(x: self.view.bounds.midX, y: self.view.bounds.midY, width: 0, height: 0)
     }
     present(alert, animated: true)
 }
 private func setRegistration(_ appInfo: TrollStoreAppInfo, isSystem: Bool) {
     InstallationProgressController.show(on: self)
     DispatchQueue.global(qos: .userInitiated).async { [weak self] in
         do {
             try UIAppManager.changeRegistration(appPath: appInfo.appPath, isSystem: isSystem)
             DispatchQueue.main.async {
                 InstallationProgressController.hide()
                 self?.loadApps()
             }
         } catch {
             DispatchQueue.main.async {
                 InstallationProgressController.hide()
                 ErrorHandler.showError(error, on: self)
             }
         }
     }
 }
 private func editEntitlements(_ appInfo: TrollStoreAppInfo) {
     let editor = EntitlementsTreeViewController(appInfo: appInfo)
     navigationController?.pushViewController(editor, animated: true)
 }
}
extension AppListViewController: UIDocumentPickerDelegate {
public func documentPicker(_ controller: UIDocumentPickerViewController, didPickDocumentsAt urls: [URL]) {
guard let url = urls.first else { return }
_ = url.startAccessingSecurityScopedResource()
defer { url.stopAccessingSecurityScopedResource() }
let tempPath = NSTemporaryDirectory().appending(UUID().uuidString).appending(".ipa")
do {
try FileManager.default.copyItem(at: url, to: URL(fileURLWithPath: tempPath))
installIPAFromFile(path: tempPath)
} catch {
ErrorHandler.showError(error, on: self)
}
}
private func installIPAFromFile(path: String) {
     InstallationProgressController.show(on: self)
     DispatchQueue.global(qos: .userInitiated).async { [weak self] in
         do {
             try installIPA(path: path, force: false, useInstalldMethod: false, skipUICache: false)
             DispatchQueue.main.async {
                 InstallationProgressController.hide()
                 self?.loadApps()
                 try? FileManager.default.removeItem(atPath: path)
             }
         } catch let error as TrollStoreInstallError {
             DispatchQueue.main.async {
                 InstallationProgressController.hide()
                 if error.code == 171 {
                     self?.showForceInstallAlert(path: path, error: error)
                 } else {
                     ErrorHandler.showError(error, on: self)
                 }
                 try? FileManager.default.removeItem(atPath: path)
             }
         } catch {
             DispatchQueue.main.async {
                 InstallationProgressController.hide()
                 ErrorHandler.showError(error, on: self)
                 try? FileManager.default.removeItem(atPath: path)
             }
         }
     }
 }
 private func showForceInstallAlert(path: String, error: TrollStoreInstallError) {
     let alert = UIAlertController(
         title: NSLocalizedString("Install_Error", comment: ""),
         message: error.errorDescription,
         preferredStyle: .alert
     )
     let closeAction = UIAlertAction(title: NSLocalizedString("Close", comment: ""), style: .cancel)
     let forceAction = UIAlertAction(title: NSLocalizedString("Force_Install", comment: ""), style: .destructive) { [weak self] _ in
         self?.forceInstallIPA(path: path)
     }
     alert.addAction(closeAction)
     alert.addAction(forceAction)
     present(alert, animated: true)
 }
 private func forceInstallIPA(path: String) {
     InstallationProgressController.show(on: self)
     DispatchQueue.global(qos: .userInitiated).async { [weak self] in
         do {
             try installIPA(path: path, force: true, useInstalldMethod: false, skipUICache: false)
             DispatchQueue.main.async {
                 InstallationProgressController.hide()
                 self?.loadApps()
                 try? FileManager.default.removeItem(atPath: path)
             }
         } catch {
             DispatchQueue.main.async {
                 InstallationProgressController.hide()
                 ErrorHandler.showError(error, on: self)
                 try? FileManager.default.removeItem(atPath: path)
             }
         }
     }
 }
}
public struct TrollStoreAppInfo {
public let displayName: String
public let bundleIdentifier: String
public let appPath: String
public let icon: UIImage?
public let isSystemRegistered: Bool
}
public enum AppCellAction {
case open
case uninstall
case enableJIT
case changeRegistration
case editEntitlements
}
private class AppListDataSource: NSObject, UITableViewDataSource, UITableViewDelegate {
var apps: [TrollStoreAppInfo] = []
var onCellAction: ((AppCellAction, TrollStoreAppInfo) -> Void)?
func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
     return apps.count
 }
 func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
     let cell = tableView.dequeueReusableCell(withIdentifier: AppListCell.reuseIdentifier, for: indexPath) as! AppListCell
     let app = apps[indexPath.row]
     cell.configure(with: app)
     cell.onOpen = { [weak self] in
         self?.onCellAction?(.open, app)
     }
     cell.onMoreActions = { [weak self, weak tableView] in
         self?.showActionsMenu(for: app, at: tableView, indexPath: indexPath)
     }
     return cell
 }
 func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
     tableView.deselectRow(at: indexPath, animated: true)
     let app = apps[indexPath.row]
     onCellAction?(.open, app)
 }
 func tableView(_ tableView: UITableView, contextMenuConfigurationForRowAt indexPath: IndexPath, point: CGPoint) -> UIContextMenuConfiguration? {
     let app = apps[indexPath.row]
     return UIContextMenuConfiguration(identifier: nil, previewProvider: nil) { _ in
         let openAction = UIAction(title: NSLocalizedString("Open", comment: ""), image: UIImage(systemName: "play")) { [weak self] _ in
             self?.onCellAction?(.open, app)
         }
         let jitAction = UIAction(title: NSLocalizedString("Enable_JIT", comment: ""), image: UIImage(systemName: "bolt")) { [weak self] _ in
             self?.onCellAction?(.enableJIT, app)
         }
         let registrationAction = UIAction(title: NSLocalizedString("Change_Registration", comment: ""), image: UIImage(systemName: "arrow.triangle.2.circlepath")) { [weak self] _ in
             self?.onCellAction?(.changeRegistration, app)
         }
         let entitlementsAction = UIAction(title: NSLocalizedString("Edit_Entitlements", comment: ""), image: UIImage(systemName: "doc.text")) { [weak self] _ in
             self?.onCellAction?(.editEntitlements, app)
         }
         let uninstallAction = UIAction(title: NSLocalizedString("Uninstall", comment: ""), image: UIImage(systemName: "trash"), attributes: .destructive) { [weak self] _ in
             self?.onCellAction?(.uninstall, app)
         }
         return UIMenu(title: "", children: [openAction, jitAction, registrationAction, entitlementsAction, uninstallAction])
     }
 }
 private func showActionsMenu(for app: TrollStoreAppInfo, at tableView: UITableView?, indexPath: IndexPath) {
     guard let tableView = tableView, let cell = tableView.cellForRow(at: indexPath) else { return }
     let alert = UIAlertController(title: nil, message: nil, preferredStyle: .actionSheet)
     let openAction = UIAlertAction(title: NSLocalizedString("Open", comment: ""), style: .default) { [weak self] _ in
         self?.onCellAction?(.open, app)
     }
     let jitAction = UIAlertAction(title: NSLocalizedString("Enable_JIT", comment: ""), style: .default) { [weak self] _ in
         self?.onCellAction?(.enableJIT, app)
     }
     let registrationAction = UIAlertAction(title: NSLocalizedString("Change_Registration", comment: ""), style: .default) { [weak self] _ in
         self?.onCellAction?(.changeRegistration, app)
     }
     let entitlementsAction = UIAlertAction(title: NSLocalizedString("Edit_Entitlements", comment: ""), style: .default) { [weak self] _ in
         self?.onCellAction?(.editEntitlements, app)
     }
     let uninstallAction = UIAlertAction(title: NSLocalizedString("Uninstall", comment: ""), style: .destructive) { [weak self] _ in
         self?.onCellAction?(.uninstall, app)
     }
     let cancelAction = UIAlertAction(title: NSLocalizedString("Cancel", comment: ""), style: .cancel)
     alert.addAction(openAction)
     alert.addAction(jitAction)
     alert.addAction(registrationAction)
     alert.addAction(entitlementsAction)
     alert.addAction(uninstallAction)
     alert.addAction(cancelAction)
     if let popover = alert.popoverPresentationController {
         popover.sourceView = cell
         popover.sourceRect = cell.bounds
     }
     tableView.window?.rootViewController?.present(alert, animated: true)
 }
}
private class AppListCell: UITableViewCell {
static let reuseIdentifier = "AppListCell"
private let iconImageView = UIImageView()
private let nameLabel = UILabel()
private let bundleIdLabel = UILabel()
private let registrationBadge = UILabel()
private let moreButton = UIButton(type: .detailDisclosure)
var onOpen: (() -> Void)?
var onMoreActions: (() -> Void)?
override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
     super.init(style: style, reuseIdentifier: reuseIdentifier)
     setupUI()
 }
 required init?(coder: NSCoder) {
     fatalError("init(coder:) has not been implemented")
 }
 private func setupUI() {
     iconImageView.translatesAutoresizingMaskIntoConstraints = false
     iconImageView.contentMode = .scaleAspectFit
     iconImageView.layer.cornerRadius = 12
     iconImageView.layer.masksToBounds = true
     contentView.addSubview(iconImageView)
     nameLabel.translatesAutoresizingMaskIntoConstraints = false
     nameLabel.font = .systemFont(ofSize: 16, weight: .semibold)
     nameLabel.textColor = .label
     contentView.addSubview(nameLabel)
     bundleIdLabel.translatesAutoresizingMaskIntoConstraints = false
     bundleIdLabel.font = .systemFont(ofSize: 13)
     bundleIdLabel.textColor = .secondaryLabel
     contentView.addSubview(bundleIdLabel)
     registrationBadge.translatesAutoresizingMaskIntoConstraints = false
     registrationBadge.font = .systemFont(ofSize: 11, weight: .medium)
     registrationBadge.textAlignment = .center
     registrationBadge.layer.cornerRadius = 4
     registrationBadge.layer.masksToBounds = true
     contentView.addSubview(registrationBadge)
     moreButton.translatesAutoresizingMaskIntoConstraints = false
     moreButton.addTarget(self, action: #selector(moreButtonTapped), for: .touchUpInside)
     contentView.addSubview(moreButton)
     NSLayoutConstraint.activate([
         iconImageView.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 16),
         iconImageView.centerYAnchor.constraint(equalTo: contentView.centerYAnchor),
         iconImageView.widthAnchor.constraint(equalToConstant: 50),
         iconImageView.heightAnchor.constraint(equalToConstant: 50),
         nameLabel.leadingAnchor.constraint(equalTo: iconImageView.trailingAnchor, constant: 12),
         nameLabel.topAnchor.constraint(equalTo: iconImageView.topAnchor, constant: 2),
         nameLabel.trailingAnchor.constraint(lessThanOrEqualTo: moreButton.leadingAnchor, constant: -8),
         bundleIdLabel.leadingAnchor.constraint(equalTo: nameLabel.leadingAnchor),
         bundleIdLabel.topAnchor.constraint(equalTo: nameLabel.bottomAnchor, constant: 2),
         bundleIdLabel.trailingAnchor.constraint(equalTo: nameLabel.trailingAnchor),
         registrationBadge.leadingAnchor.constraint(equalTo: nameLabel.leadingAnchor),
         registrationBadge.topAnchor.constraint(equalTo: bundleIdLabel.bottomAnchor, constant: 4),
         registrationBadge.widthAnchor.constraint(greaterThanOrEqualToConstant: 50),
         registrationBadge.heightAnchor.constraint(equalToConstant: 18),
         moreButton.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -16),
         moreButton.centerYAnchor.constraint(equalTo: contentView.centerYAnchor),
         moreButton.widthAnchor.constraint(equalToConstant: 30),
         moreButton.heightAnchor.constraint(equalToConstant: 30)
     ])
 }
 func configure(with app: TrollStoreAppInfo) {
     iconImageView.image = app.icon ?? UIImage(systemName: "app")
     nameLabel.text = app.displayName
     bundleIdLabel.text = app.bundleIdentifier
     if app.isSystemRegistered {
         registrationBadge.text = NSLocalizedString("System", comment: "")
         registrationBadge.backgroundColor = .systemGreen
         registrationBadge.textColor = .white
     } else {
         registrationBadge.text = NSLocalizedString("User", comment: "")
         registrationBadge.backgroundColor = .systemGray
         registrationBadge.textColor = .white
     }
 }
 @objc private func moreButtonTapped() {
     onMoreActions?()
 }
}
public class InstallationProgressController {
private static var overlayView: UIView?
private static var activityIndicator: UIActivityIndicatorView?
private static var messageLabel: UILabel?
public static func show(on viewController: UIViewController, message: String? = nil) {
     guard overlayView == nil else { return }
     let overlay = UIView(frame: viewController.view.bounds)
     overlay.backgroundColor = UIColor.black.withAlphaComponent(0.4)
     overlay.autoresizingMask = [.flexibleWidth, .flexibleHeight]
     let containerView = UIView()
     containerView.translatesAutoresizingMaskIntoConstraints = false
     containerView.backgroundColor = .systemBackground
     containerView.layer.cornerRadius = 12
     containerView.layer.shadowColor = UIColor.black.cgColor
     containerView.layer.shadowOpacity = 0.3
     containerView.layer.shadowRadius = 8
     containerView.layer.shadowOffset = CGSize(width: 0, height: 2)
     overlay.addSubview(containerView)
     let indicator = UIActivityIndicatorView(style: .large)
     indicator.translatesAutoresizingMaskIntoConstraints = false
     indicator.startAnimating()
     containerView.addSubview(indicator)
     let label = UILabel()
     label.translatesAutoresizingMaskIntoConstraints = false
     label.font = .systemFont(ofSize: 16, weight: .medium)
     label.textColor = .label
     label.textAlignment = .center
     label.text = message ?? NSLocalizedString("Installing", comment: "")
     containerView.addSubview(label)
     NSLayoutConstraint.activate([
         containerView.centerXAnchor.constraint(equalTo: overlay.centerXAnchor),
         containerView.centerYAnchor.constraint(equalTo: overlay.centerYAnchor),
         containerView.widthAnchor.constraint(equalToConstant: 200),
         containerView.heightAnchor.constraint(equalToConstant: 120),
         indicator.centerXAnchor.constraint(equalTo: containerView.centerXAnchor),
         indicator.topAnchor.constraint(equalTo: containerView.topAnchor, constant: 20),
         label.leadingAnchor.constraint(equalTo: containerView.leadingAnchor, constant: 16),
         label.trailingAnchor.constraint(equalTo: containerView.trailingAnchor, constant: -16),
         label.topAnchor.constraint(equalTo: indicator.bottomAnchor, constant: 12)
     ])
     viewController.view.addSubview(overlay)
     overlayView = overlay
     activityIndicator = indicator
     messageLabel = label
 }
 public static func hide() {
     overlayView?.removeFromSuperview()
     overlayView = nil
     activityIndicator = nil
     messageLabel = nil
 }
 public static func update(message: String) {
     messageLabel?.text = message
 }
}
public class ErrorHandler {
public static func showError(_ error: Error, on viewController: UIViewController?) {
let alert = UIAlertController(
title: NSLocalizedString("Error", comment: ""),
message: error.localizedDescription,
preferredStyle: .alert
)
if let trollError = error as? TrollStoreInstallError {
alert.title = String(format: NSLocalizedString("Install_Error_Code", comment: ""), trollError.code)
let copyLogAction = UIAlertAction(title: NSLocalizedString("Copy_Debug_Log", comment: ""), style: .default) { _ in
UIPasteboard.general.string = "Error Code: \(trollError.code)\n\(trollError.errorDescription ?? "Unknown error")"
}
alert.addAction(copyLogAction)
}
let closeAction = UIAlertAction(title: NSLocalizedString("Close", comment: ""), style: .default)
alert.addAction(closeAction)
viewController?.present(alert, animated: true)
}
public static func showSuccess(on viewController: UIViewController?, message: String) {
    let alert = UIAlertController(
        title: NSLocalizedString("Success", comment: ""),
        message: message,
        preferredStyle: .alert
    )
    let closeAction = UIAlertAction(title: NSLocalizedString("Close", comment: ""), style: .default)
    alert.addAction(closeAction)
    viewController?.present(alert, animated: true)
}
}
public class EntitlementsTreeViewController: UIViewController {
private let tableView = UITableView(frame: .zero, style: .insetGrouped)
private let appInfo: TrollStoreAppInfo
private var entitlements: [String: Any] = [:]
private var flattenedItems: [EntitlementTreeItem] = []
public init(appInfo: TrollStoreAppInfo) {
     self.appInfo = appInfo
     super.init(nibName: nil, bundle: nil)
 }
 required init?(coder: NSCoder) {
     fatalError("init(coder:) has not been implemented")
 }
 public override func viewDidLoad() {
     super.viewDidLoad()
     title = NSLocalizedString("Edit_Entitlements", comment: "")
     view.backgroundColor = .systemGroupedBackground
     setupTableView()
     loadEntitlements()
 }
 private func setupTableView() {
     tableView.translatesAutoresizingMaskIntoConstraints = false
     tableView.dataSource = self
     tableView.delegate = self
     tableView.register(EntitlementTreeCell.self, forCellReuseIdentifier: EntitlementTreeCell.reuseIdentifier)
     view.addSubview(tableView)
     NSLayoutConstraint.activate([
         tableView.topAnchor.constraint(equalTo: view.topAnchor),
         tableView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
         tableView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
         tableView.bottomAnchor.constraint(equalTo: view.bottomAnchor)
     ])
 }
 private func loadEntitlements() {
     DispatchQueue.global(qos: .userInitiated).async { [weak self] in
         guard let self = self else { return }
         let mainBinaryPath = InstalledAppsManager.getMainBinaryPath(for: self.appInfo.appPath)
         let ent = dumpEntitlements(binaryPath: mainBinaryPath) ?? [:]
         DispatchQueue.main.async {
             self.entitlements = ent
             self.flattenedItems = self.flattenEntitlements(ent)
             self.tableView.reloadData()
         }
     }
 }
 private func flattenEntitlements(_ dict: [String: Any], depth: Int = 0, parentKey: String = "") -> [EntitlementTreeItem] {
     var items: [EntitlementTreeItem] = []
     for (key, value) in dict {
         let fullKey = parentKey.isEmpty ? key : "\(parentKey).\(key)"
         if let nestedDict = value as? [String: Any] {
             let parentItem = EntitlementTreeItem(key: key, value: "[Dictionary]", depth: depth, isExpanded: false, hasChildren: true)
             items.append(parentItem)
             items.append(contentsOf: flattenEntitlements(nestedDict, depth: depth + 1, parentKey: fullKey))
         } else if let array = value as? [Any] {
             let parentItem = EntitlementTreeItem(key: key, value: "[Array: \(array.count)]", depth: depth, isExpanded: false, hasChildren: true)
             items.append(parentItem)
             for (index, element) in array.enumerated() {
                 if let nestedDict = element as? [String: Any] {
                     items.append(contentsOf: flattenEntitlements(nestedDict, depth: depth + 1, parentKey: "\(fullKey)[\(index)]"))
                 } else {
                     let item = EntitlementTreeItem(key: "[\(index)]", value: "\(element)", depth: depth + 1, isExpanded: false, hasChildren: false)
                     items.append(item)
                 }
             }
         } else {
             let item = EntitlementTreeItem(key: key, value: "\(value)", depth: depth, isExpanded: false, hasChildren: false)
             items.append(item)
         }
     }
     return items
 }
}
extension EntitlementsTreeViewController: UITableViewDataSource, UITableViewDelegate {
public func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
return flattenedItems.count
}
public func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
    let cell = tableView.dequeueReusableCell(withIdentifier: EntitlementTreeCell.reuseIdentifier, for: indexPath) as! EntitlementTreeCell
    let item = flattenedItems[indexPath.row]
    cell.configure(with: item)
    return cell
}
public func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
    tableView.deselectRow(at: indexPath, animated: true)
}
}
private struct EntitlementTreeItem {
let key: String
let value: String
let depth: Int
let isExpanded: Bool
let hasChildren: Bool
}
private class EntitlementTreeCell: UITableViewCell {
static let reuseIdentifier = "EntitlementTreeCell"
private let keyLabel = UILabel()
private let valueLabel = UILabel()
private let expandIndicator = UIImageView()
override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
     super.init(style: style, reuseIdentifier: reuseIdentifier)
     setupUI()
 }
 required init?(coder: NSCoder) {
     fatalError("init(coder:) has not been implemented")
 }
 private func setupUI() {
     keyLabel.translatesAutoresizingMaskIntoConstraints = false
     keyLabel.font = .systemFont(ofSize: 14, weight: .medium)
     keyLabel.textColor = .label
     contentView.addSubview(keyLabel)
     valueLabel.translatesAutoresizingMaskIntoConstraints = false
     valueLabel.font = .systemFont(ofSize: 12)
     valueLabel.textColor = .secondaryLabel
     valueLabel.numberOfLines = 0
     contentView.addSubview(valueLabel)
     expandIndicator.translatesAutoresizingMaskIntoConstraints = false
     expandIndicator.contentMode = .scaleAspectFit
     contentView.addSubview(expandIndicator)
     NSLayoutConstraint.activate([
         expandIndicator.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 8),
         expandIndicator.centerYAnchor.constraint(equalTo: contentView.centerYAnchor),
         expandIndicator.widthAnchor.constraint(equalToConstant: 20),
         expandIndicator.heightAnchor.constraint(equalToConstant: 20),
         keyLabel.leadingAnchor.constraint(equalTo: expandIndicator.trailingAnchor, constant: 8),
         keyLabel.topAnchor.constraint(equalTo: contentView.topAnchor, constant: 8),
         keyLabel.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -16),
         valueLabel.leadingAnchor.constraint(equalTo: keyLabel.leadingAnchor),
         valueLabel.topAnchor.constraint(equalTo: keyLabel.bottomAnchor, constant: 2),
         valueLabel.trailingAnchor.constraint(equalTo: keyLabel.trailingAnchor),
         valueLabel.bottomAnchor.constraint(equalTo: contentView.bottomAnchor, constant: -8)
     ])
 }
 func configure(with item: EntitlementTreeItem) {
     keyLabel.text = item.key
     valueLabel.text = item.value
     let indent = CGFloat(item.depth * 20)
     keyLabel.transform = CGAffineTransform(translationX: indent, y: 0)
     valueLabel.transform = CGAffineTransform(translationX: indent, y: 0)
     if item.hasChildren {
         expandIndicator.image = UIImage(systemName: item.isExpanded ? "chevron.down" : "chevron.right")
         expandIndicator.tintColor = .systemBlue
     } else {
         expandIndicator.image = nil
     }
 }
}
private class InstalledAppsManager {
static func fetchInstalledApps() -> [TrollStoreAppInfo] {
var apps: [TrollStoreAppInfo] = []
let fm = FileManager.default
let appsPath = "/var/containers/Bundle/Application"
guard let contents = try? fm.contentsOfDirectory(atPath: appsPath) else { return apps }
for item in contents {
let appContainerPath = (appsPath as NSString).appendingPathComponent(item)
var isDir: ObjCBool = false
if fm.fileExists(atPath: appContainerPath, isDirectory: &isDir) && isDir.boolValue {
let markerPath = (appContainerPath as NSString).appendingPathComponent(".TrollStore")
if fm.fileExists(atPath: markerPath) {
if let appPath = findAppPath(in: appContainerPath) {
if let appInfo = parseAppInfo(from: appPath) {
apps.append(appInfo)
}
}
}
}
}
return apps.sorted { $0.displayName < $1.displayName }
}
private static func findAppPath(in containerPath: String) -> String? {
     let fm = FileManager.default
     guard let contents = try? fm.contentsOfDirectory(atPath: containerPath) else { return nil }
     for item in contents {
         if item.hasSuffix(".app") {
             let appPath = (containerPath as NSString).appendingPathComponent(item)
             var isDir: ObjCBool = false
             if fm.fileExists(atPath: appPath, isDirectory: &isDir) && isDir.boolValue {
                 return appPath
             }
         }
     }
     return nil
 }
 private static func parseAppInfo(from appPath: String) -> TrollStoreAppInfo? {
     let infoPlistPath = (appPath as NSString).appendingPathComponent("Info.plist")
     guard let infoDict = NSDictionary(contentsOfFile: infoPlistPath) as? [String: Any] else { return nil }
     let displayName = (infoDict["CFBundleDisplayName"] as? String) ?? (infoDict["CFBundleName"] as? String) ?? "Unknown"
     let bundleId = (infoDict["CFBundleIdentifier"] as? String) ?? ""
     let icon = loadAppIcon(from: appPath, infoDict: infoDict)
     let isSystem = isSystemRegistered(appPath: appPath)
     return TrollStoreAppInfo(
         displayName: displayName,
         bundleIdentifier: bundleId,
         appPath: appPath,
         icon: icon,
         isSystemRegistered: isSystem
     )
 }
 private static func loadAppIcon(from appPath: String, infoDict: [String: Any]) -> UIImage? {
     if let iconFiles = infoDict["CFBundleIcons"] as? [String: Any],
        let primaryIcon = iconFiles["CFBundlePrimaryIcon"] as? [String: Any],
        let iconFilesArray = primaryIcon["CFBundleIconFiles"] as? [String],
        let iconName = iconFilesArray.first {
         let iconPath = (appPath as NSString).appendingPathComponent(iconName)
         let extensions = ["", ".png", "@2x.png", "@3x.png"]
         for ext in extensions {
             let fullPath = iconPath + ext
             if let image = UIImage(contentsOfFile: fullPath) {
                 return image
             }
         }
     }
     return nil
 }
 private static func isSystemRegistered(appPath: String) -> Bool {
     let containerPath = (appPath as NSString).deletingLastPathComponent
     let markerPath = (containerPath as NSString).appendingPathComponent(".TrollStore")
     return FileManager.default.fileExists(atPath: markerPath)
 }
 static func getMainBinaryPath(for appPath: String) -> String {
     let infoPlistPath = (appPath as NSString).appendingPathComponent("Info.plist")
     guard let infoDict = NSDictionary(contentsOfFile: infoPlistPath) as? [String: Any],
           let executable = infoDict["CFBundleExecutable"] as? String else {
         return appPath
     }
     return (appPath as NSString).appendingPathComponent(executable)
 }
}
private class UIAppManager {
static func uninstallApp(bundleId: String) throws {
let ret = c_uninstallAppById(bundleId as NSString, 0)
if ret != 0 {
throw TrollStoreInstallError(code: ret)
}
}
static func enableJIT(bundleId: String) throws {
     let ret = c_enableJIT(bundleId as NSString)
     if ret != 0 {
         throw TrollStoreInstallError(code: ret)
     }
 }
 static func changeRegistration(appPath: String, isSystem: Bool) throws {
     let registration = isSystem ? "System" : "User"
     let ret = spawnRootHelper(args: ["modify-registration", appPath, registration])
     if ret != 0 {
         throw TrollStoreInstallError(code: Int32(ret))
     }
 }
 private static func spawnRootHelper(args: [String]) -> Int {
     let helperPath = "/var/containers/Bundle/Application/TrollStore.app/trollstorehelper"
     var argv: [UnsafeMutablePointer<CChar>?] = [strdup(helperPath)]
     argv.append(contentsOf: args.map { strdup($0) })
     argv.append(nil)
     defer {
         for ptr in argv {
             if let p = ptr { free(p) }
         }
     }
     var pid: pid_t = 0
     var status: Int32 = 0
     let spawnResult = argv.withUnsafeMutableBufferPointer { buffer -> Int32 in
         return posix_spawn(&pid, helperPath, nil, nil, buffer.baseAddress, nil)
     }
     if spawnResult != 0 { return -1 }
     waitpid(pid, &status, 0)
     let exited = (status & 0x7f) == 0
     let exitCode = Int((status >> 8) & 0xff)
     return exited ? exitCode : -1
 }
}
@_silgen_name("uninstallAppById")
private func c_uninstallAppById(appId: NSString, _ useCustomMethod: Int8) -> Int32
@_silgen_name("enableJIT")
private func c_enableJIT(appId: NSString) -> Int32
private class LSApplicationWorkspaceProxy {
private static var shared: LSApplicationWorkspaceProxy?
static func defaultWorkspace() -> LSApplicationWorkspaceProxy? {
if shared == nil {
shared = LSApplicationWorkspaceProxy()
}
return shared
}
func openApplication(withBundleID bundleID: String) -> Bool {
guard let cls = NSClassFromString("LSApplicationWorkspace") as? NSObject.Type else { return false }
let workspace: AnyObject? = cls.perform(NSSelectorFromString("defaultWorkspace"))?.takeUnretainedValue()
if let ws = workspace {
let selector = NSSelectorFromString("openApplicationWithBundleID:")
if ws.responds(to: selector) {
_ = ws.perform(selector, with: bundleID)
return true
}
}
return false
}
}
