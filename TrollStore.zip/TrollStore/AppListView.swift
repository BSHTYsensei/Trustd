import UIKit
import Foundation
import UniformTypeIdentifiers

public class AppListViewController: UIViewController {
    private let tableView = UITableView(frame: .zero, style: .insetGrouped)
    private let refreshControl = UIRefreshControl()
    private let searchController = UISearchController(searchResultsController: nil)
    private let dataSource = AppListDataSource()

    public override func viewDidLoad() {
        super.viewDidLoad()
        title = NSLocalizedString("Apps", comment: "")
        view.backgroundColor = .systemGroupedBackground
        navigationItem.largeTitleDisplayMode = .always
        setupTableView()
        setupNavigationBar()
        setupSearch()
        setupNotifications()
        loadApps()
    }

    public override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        loadApps()
    }

    private func setupTableView() {
        tableView.translatesAutoresizingMaskIntoConstraints = false
        tableView.dataSource = dataSource
        tableView.delegate = dataSource
        tableView.register(AppListCell.self, forCellReuseIdentifier: AppListCell.reuseIdentifier)
        tableView.estimatedRowHeight = 84
        tableView.rowHeight = UITableView.automaticDimension
        tableView.backgroundColor = .clear
        tableView.refreshControl = refreshControl
        refreshControl.addTarget(self, action: #selector(loadApps), for: .valueChanged)
        view.addSubview(tableView)
        NSLayoutConstraint.activate([
            tableView.topAnchor.constraint(equalTo: view.topAnchor),
            tableView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            tableView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            tableView.bottomAnchor.constraint(equalTo: view.bottomAnchor)
        ])
        dataSource.onReload = { [weak self] in
            self?.tableView.reloadData()
        }
        dataSource.onCellAction = { [weak self] action, appInfo in
            self?.handleCellAction(action, for: appInfo)
        }
        dataSource.onShowDetail = { [weak self] app in
            let detailVC = AppDetailViewController(appInfo: app)
            detailVC.onAction = { action in
                self?.handleCellAction(action, for: app)
            }
            self?.navigationController?.pushViewController(detailVC, animated: true)
        }
    }

    private func setupNavigationBar() {
        let appearance = UINavigationBarAppearance()
        appearance.configureWithTransparentBackground()
        appearance.backgroundEffect = UIBlurEffect(style: .systemUltraThinMaterial)
        appearance.backgroundColor = .clear
        appearance.shadowColor = .clear
        navigationController?.navigationBar.standardAppearance = appearance
        navigationController?.navigationBar.scrollEdgeAppearance = appearance
        navigationController?.navigationBar.compactAppearance = appearance
        let installAction = UIAction(title: NSLocalizedString("Install IPA File", comment: "")) { [weak self] _ in
            self?.installAppTapped()
        }
        let installMenu = UIMenu(children: [installAction])
        let installButton = UIBarButtonItem(image: UIImage(systemName: "plus"), menu: installMenu)
        let sortMenu = UIMenu(title: "", children: [
            UIAction(title: NSLocalizedString("Name Ascending", comment: "")) { [weak self] _ in self?.dataSource.sortApps(by: .nameAsc) },
            UIAction(title: NSLocalizedString("Name Descending", comment: "")) { [weak self] _ in self?.dataSource.sortApps(by: .nameDesc) },
            UIAction(title: NSLocalizedString("Install Date", comment: "")) { [weak self] _ in self?.dataSource.sortApps(by: .date) },
            UIAction(title: NSLocalizedString("Size", comment: "")) { [weak self] _ in self?.dataSource.sortApps(by: .size) }
        ])
        let sortButton = UIBarButtonItem(image: UIImage(systemName: "arrow.up.arrow.down"), menu: sortMenu)
        navigationItem.rightBarButtonItem = installButton
        navigationItem.leftBarButtonItem = sortButton
    }

    private func setupSearch() {
        searchController.searchResultsUpdater = dataSource
        searchController.obscuresBackgroundDuringPresentation = false
        searchController.searchBar.placeholder = NSLocalizedString("Search", comment: "")
        navigationItem.searchController = searchController
        definesPresentationContext = true
    }

    private func setupNotifications() {
        NotificationCenter.default.addObserver(self, selector: #selector(handleRemoteInstall(_:)), name: NSNotification.Name("TrollStoreRemoteInstall"), object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(handleEnableJIT(_:)), name: NSNotification.Name("TrollStoreEnableJIT"), object: nil)
    }

    @objc private func loadApps() {
        DispatchQueue.global(qos: .userInitiated).async { [weak self] in
            let apps = AppManager.getInstalledApps()
            DispatchQueue.main.async {
                self?.dataSource.allApps = apps
                self?.dataSource.applyFilterAndSort()
                self?.refreshControl.endRefreshing()
            }
        }
    }

    @objc private func installAppTapped() {
        let picker = UIDocumentPickerViewController(forOpeningContentTypes: [.item])
        picker.delegate = self
        picker.allowsMultipleSelection = false
        present(picker, animated: true)
    }

    @objc private func handleRemoteInstall(_ notification: Notification) {
        guard let urlString = notification.object as? String, let url = URL(string: urlString) else { return }
        InstallationProgressController.show(on: self, message: NSLocalizedString("Downloading", comment: ""))
        InstallationManager.downloadIPA(url: url, progress: { _ in }, completion: { [weak self] path, error in
            InstallationProgressController.hide()
            if let path = path {
                self?.installIPAFromFile(path: path, isRemote: true)
            } else if let error = error {
                ErrorHandler.showError(error, on: self)
            }
        })
    }

    @objc private func handleEnableJIT(_ notification: Notification) {
        guard let bundleId = notification.object as? String else { return }
        InstallationProgressController.show(on: self, message: NSLocalizedString("Enabling JIT", comment: ""))
        DispatchQueue.global(qos: .userInitiated).async { [weak self] in
            do {
                try InstallationManager.enableJIT(bundleId: bundleId)
                DispatchQueue.main.async {
                    InstallationProgressController.hide()
                    ErrorHandler.showSuccess(on: self, message: NSLocalizedString("JIT Enabled", comment: ""))
                }
            } catch {
                DispatchQueue.main.async {
                    InstallationProgressController.hide()
                    ErrorHandler.showError(error, on: self)
                }
            }
        }
    }

    private func handleCellAction(_ action: AppCellAction, for appInfo: TrollStoreAppInfo) {
        switch action {
        case .open:
            _ = AppManager.openApp(bundleId: appInfo.bundleIdentifier)
        case .uninstall:
            confirmUninstall(appInfo)
        case .enableJIT:
            enableJIT(appInfo)
        case .changeRegistration:
            changeRegistration(appInfo)
        case .editEntitlements:
            editEntitlements(appInfo)
        }
    }

    private func confirmUninstall(_ appInfo: TrollStoreAppInfo) {
        let alert = UIAlertController(
            title: NSLocalizedString("Uninstall App", comment: ""),
            message: String(format: NSLocalizedString("Are you sure you want to uninstall %@?", comment: ""), appInfo.displayName),
            preferredStyle: .alert
        )
        let cancelAction = UIAlertAction(title: NSLocalizedString("Cancel", comment: ""), style: .cancel)
        let uninstallAction = UIAlertAction(title: NSLocalizedString("Uninstall", comment: ""), style: .destructive) { [weak self] _ in
            self?.uninstallApp(appInfo)
        }
        alert.addAction(cancelAction)
        alert.addAction(uninstallAction)
        present(alert, animated: true)
    }

    private func uninstallApp(_ appInfo: TrollStoreAppInfo) {
        InstallationProgressController.show(on: self)
        let useCustom = UserDefaults.standard.integer(forKey: TrollStoreDefaults.uninstallationMethod) == 1
        DispatchQueue.global(qos: .userInitiated).async { [weak self] in
            do {
                try InstallationManager.uninstallApp(bundleId: appInfo.bundleIdentifier, useCustomMethod: useCustom)
                DispatchQueue.main.async {
                    InstallationProgressController.hide()
                    self?.loadApps()
                }
            } catch {
                DispatchQueue.main.async {
                    InstallationProgressController.hide()
                    ErrorHandler.showError(error, on: self)
                }
            }
        }
    }

    private func enableJIT(_ appInfo: TrollStoreAppInfo) {
        InstallationProgressController.show(on: self, message: NSLocalizedString("Enabling JIT", comment: ""))
        DispatchQueue.global(qos: .userInitiated).async { [weak self] in
            do {
                try InstallationManager.enableJIT(bundleId: appInfo.bundleIdentifier)
                DispatchQueue.main.async {
                    InstallationProgressController.hide()
                    ErrorHandler.showSuccess(on: self, message: NSLocalizedString("JIT Enabled", comment: ""))
                }
            } catch {
                DispatchQueue.main.async {
                    InstallationProgressController.hide()
                    ErrorHandler.showError(error, on: self)
                }
            }
        }
    }

    private func changeRegistration(_ appInfo: TrollStoreAppInfo) {
        let alert = UIAlertController(
            title: NSLocalizedString("Change Registration", comment: ""),
            message: nil,
            preferredStyle: .actionSheet
        )
        let systemAction = UIAlertAction(title: NSLocalizedString("System", comment: ""), style: .default) { [weak self] _ in
            self?.setRegistration(appInfo, isSystem: true)
        }
        let userAction = UIAlertAction(title: NSLocalizedString("User", comment: ""), style: .default) { [weak self] _ in
            self?.setRegistration(appInfo, isSystem: false)
        }
        let cancelAction = UIAlertAction(title: NSLocalizedString("Cancel", comment: ""), style: .cancel)
        alert.addAction(systemAction)
        alert.addAction(userAction)
        alert.addAction(cancelAction)
        if let popover = alert.popoverPresentationController {
            popover.sourceView = self.view
            popover.sourceRect = CGRect(x: self.view.bounds.midX, y: self.view.bounds.midY, width: 0, height: 0)
        }
        present(alert, animated: true)
    }

    private func setRegistration(_ appInfo: TrollStoreAppInfo, isSystem: Bool) {
        InstallationProgressController.show(on: self)
        DispatchQueue.global(qos: .userInitiated).async { [weak self] in
            do {
                try InstallationManager.changeRegistration(appPath: appInfo.appPath, isSystem: isSystem)
                DispatchQueue.main.async {
                    InstallationProgressController.hide()
                    self?.loadApps()
                }
            } catch {
                DispatchQueue.main.async {
                    InstallationProgressController.hide()
                    ErrorHandler.showError(error, on: self)
                }
            }
        }
    }

    private func editEntitlements(_ appInfo: TrollStoreAppInfo) {
        let infoPlistPath = (appInfo.appPath as NSString).appendingPathComponent("Info.plist")
        guard let infoDict = NSDictionary(contentsOfFile: infoPlistPath) as? [String: Any],
              let executable = infoDict["CFBundleExecutable"] as? String else { return }
        let binaryPath = (appInfo.appPath as NSString).appendingPathComponent(executable)
        let editor = EntitlementsTreeViewController(appInfo: appInfo, binaryPath: binaryPath)
        navigationController?.pushViewController(editor, animated: true)
    }
}

extension AppListViewController: UIDocumentPickerDelegate {
    public func documentPicker(_ controller: UIDocumentPickerViewController, didPickDocumentsAt urls: [URL]) {
        guard let url = urls.first else { return }
        _ = url.startAccessingSecurityScopedResource()
        defer { url.stopAccessingSecurityScopedResource() }
        let tempPath = NSTemporaryDirectory().appending(UUID().uuidString).appending(".ipa")
        do {
            try FileManager.default.copyItem(at: url, to: URL(fileURLWithPath: tempPath))
            installIPAFromFile(path: tempPath, isRemote: false)
        } catch {
            ErrorHandler.showError(error, on: self)
        }
    }

    private func installIPAFromFile(path: String, isRemote: Bool) {
        let config = UserDefaults.standard.integer(forKey: TrollStoreDefaults.installAlertConfiguration)
        var shouldShowAlert = true
        if config == 2 { shouldShowAlert = false }
        else if config == 1 && !isRemote { shouldShowAlert = false }
        if shouldShowAlert {
            guard let infoDict = InstallationManager.parseIPA(path: path) else {
                ErrorHandler.showError(TrollStoreInstallError(code: 167), on: self)
                try? FileManager.default.removeItem(atPath: path)
                return
            }
            let name = (infoDict["CFBundleDisplayName"] as? String) ?? (infoDict["CFBundleName"] as? String) ?? "App"
            let version = (infoDict["CFBundleShortVersionString"] as? String) ?? "1.0"
            let bundleId = (infoDict["CFBundleIdentifier"] as? String) ?? ""
            let size = (try? FileManager.default.attributesOfItem(atPath: path)[.size] as? UInt64) ?? 0
            let sizeStr = ByteCountFormatter.string(fromByteCount: Int64(size), countStyle: .file)
            let message = String(format: "Version: %@\nBundle ID: %@\nSize: %@", version, bundleId, sizeStr)
            let alert = UIAlertController(title: name, message: message, preferredStyle: .alert)
            let installAction = UIAlertAction(title: NSLocalizedString("Install", comment: ""), style: .default) { [weak self] _ in
                self?.performInstall(path: path)
            }
            let cancelAction = UIAlertAction(title: NSLocalizedString("Cancel", comment: ""), style: .cancel) { _ in
                try? FileManager.default.removeItem(atPath: path)
            }
            alert.addAction(installAction)
            alert.addAction(cancelAction)
            present(alert, animated: true)
        } else {
            performInstall(path: path)
        }
    }

    private func performInstall(path: String) {
        InstallationProgressController.show(on: self)
        let useInstalld = UserDefaults.standard.integer(forKey: TrollStoreDefaults.installationMethod) == 0
        DispatchQueue.global(qos: .userInitiated).async { [weak self] in
            do {
                try InstallationManager.installIPA(path: path, force: false, useInstalldMethod: useInstalld, skipUICache: false)
                DispatchQueue.main.async {
                    InstallationProgressController.hide()
                    self?.loadApps()
                    try? FileManager.default.removeItem(atPath: path)
                }
            } catch let error as TrollStoreInstallError {
                DispatchQueue.main.async {
                    InstallationProgressController.hide()
                    if error.code == 171 {
                        self?.showForceInstallAlert(path: path, error: error)
                    } else {
                        ErrorHandler.showError(error, on: self)
                    }
                    try? FileManager.default.removeItem(atPath: path)
                }
            } catch {
                DispatchQueue.main.async {
                    InstallationProgressController.hide()
                    ErrorHandler.showError(error, on: self)
                    try? FileManager.default.removeItem(atPath: path)
                }
            }
        }
    }

    private func showForceInstallAlert(path: String, error: TrollStoreInstallError) {
        let alert = UIAlertController(
            title: NSLocalizedString("Install Error", comment: ""),
            message: error.errorDescription,
            preferredStyle: .alert
        )
        let closeAction = UIAlertAction(title: NSLocalizedString("Close", comment: ""), style: .cancel)
        let forceAction = UIAlertAction(title: NSLocalizedString("Force Install", comment: ""), style: .destructive) { [weak self] _ in
            self?.forceInstallIPA(path: path)
        }
        alert.addAction(closeAction)
        alert.addAction(forceAction)
        present(alert, animated: true)
    }

    private func forceInstallIPA(path: String) {
        InstallationProgressController.show(on: self)
        let useInstalld = UserDefaults.standard.integer(forKey: TrollStoreDefaults.installationMethod) == 0
        DispatchQueue.global(qos: .userInitiated).async { [weak self] in
            do {
                try InstallationManager.installIPA(path: path, force: true, useInstalldMethod: useInstalld, skipUICache: false)
                DispatchQueue.main.async {
                    InstallationProgressController.hide()
                    self?.loadApps()
                    try? FileManager.default.removeItem(atPath: path)
                }
            } catch {
                DispatchQueue.main.async {
                    InstallationProgressController.hide()
                    ErrorHandler.showError(error, on: self)
                    try? FileManager.default.removeItem(atPath: path)
                }
            }
        }
    }
}

public enum AppCellAction {
    case open
    case uninstall
    case enableJIT
    case changeRegistration
    case editEntitlements
}

private class AppListDataSource: NSObject, UITableViewDataSource, UITableViewDelegate, UISearchResultsUpdating {
    var allApps: [TrollStoreAppInfo] = []
    var filteredApps: [TrollStoreAppInfo] = []
    var searchText: String = ""
    var sortType: SortType = .nameAsc

    enum SortType {
        case nameAsc, nameDesc, date, size
    }

    var onReload: (() -> Void)?
    var onCellAction: ((AppCellAction, TrollStoreAppInfo) -> Void)?
    var onShowDetail: ((TrollStoreAppInfo) -> Void)?

    func updateSearchResults(for searchController: UISearchController) {
        searchText = searchController.searchBar.text ?? ""
        applyFilterAndSort()
    }

    func applyFilterAndSort() {
        if searchText.isEmpty {
            filteredApps = allApps
        } else {
            filteredApps = allApps.filter { $0.displayName.localizedCaseInsensitiveContains(searchText) || $0.bundleIdentifier.localizedCaseInsensitiveContains(searchText) }
        }
        switch sortType {
        case .nameAsc:
            filteredApps.sort { $0.displayName.localizedStandardCompare($1.displayName) == .orderedAscending }
        case .nameDesc:
            filteredApps.sort { $0.displayName.localizedStandardCompare($1.displayName) == .orderedDescending }
        case .date:
            filteredApps.sort { $0.creationDate > $1.creationDate }
        case .size:
            filteredApps.sort { $0.size > $1.size }
        }
        onReload?()
    }

    func sortApps(by type: SortType) {
        sortType = type
        applyFilterAndSort()
    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return filteredApps.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: AppListCell.reuseIdentifier, for: indexPath) as! AppListCell
        let app = filteredApps[indexPath.row]
        cell.configure(with: app)
        cell.onMoreActions = { [weak self, weak tableView] in
            self?.showActionsMenu(for: app, at: tableView, indexPath: indexPath)
        }
        return cell
    }

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        let app = filteredApps[indexPath.row]
        onShowDetail?(app)
    }

    func tableView(_ tableView: UITableView, contextMenuConfigurationForRowAt indexPath: IndexPath, point: CGPoint) -> UIContextMenuConfiguration? {
        let app = filteredApps[indexPath.row]
        return UIContextMenuConfiguration(identifier: nil, previewProvider: nil) { _ in
            let openAction = UIAction(title: NSLocalizedString("Open", comment: ""), image: UIImage(systemName: "play")) { [weak self] _ in
                self?.onCellAction?(.open, app)
            }
            let jitAction = UIAction(title: NSLocalizedString("Enable JIT", comment: ""), image: UIImage(systemName: "bolt")) { [weak self] _ in
                self?.onCellAction?(.enableJIT, app)
            }
            let registrationAction = UIAction(title: NSLocalizedString("Change Registration", comment: ""), image: UIImage(systemName: "arrow.triangle.2.circlepath")) { [weak self] _ in
                self?.onCellAction?(.changeRegistration, app)
            }
            let entitlementsAction = UIAction(title: NSLocalizedString("Edit Entitlements", comment: ""), image: UIImage(systemName: "doc.text")) { [weak self] _ in
                self?.onCellAction?(.editEntitlements, app)
            }
            let uninstallAction = UIAction(title: NSLocalizedString("Uninstall", comment: ""), image: UIImage(systemName: "trash"), attributes: .destructive) { [weak self] _ in
                self?.onCellAction?(.uninstall, app)
            }
            return UIMenu(title: "", children: [openAction, jitAction, registrationAction, entitlementsAction, uninstallAction])
        }
    }

    private func showActionsMenu(for app: TrollStoreAppInfo, at tableView: UITableView?, indexPath: IndexPath) {
        guard let tableView = tableView, let cell = tableView.cellForRow(at: indexPath) else { return }
        let alert = UIAlertController(title: nil, message: nil, preferredStyle: .actionSheet)
        let openAction = UIAlertAction(title: NSLocalizedString("Open", comment: ""), style: .default) { [weak self] _ in
            self?.onCellAction?(.open, app)
        }
        let jitAction = UIAlertAction(title: NSLocalizedString("Enable JIT", comment: ""), style: .default) { [weak self] _ in
            self?.onCellAction?(.enableJIT, app)
        }
        let registrationAction = UIAlertAction(title: NSLocalizedString("Change Registration", comment: ""), style: .default) { [weak self] _ in
            self?.onCellAction?(.changeRegistration, app)
        }
        let entitlementsAction = UIAlertAction(title: NSLocalizedString("Edit Entitlements", comment: ""), style: .default) { [weak self] _ in
            self?.onCellAction?(.editEntitlements, app)
        }
        let uninstallAction = UIAlertAction(title: NSLocalizedString("Uninstall", comment: ""), style: .destructive) { [weak self] _ in
            self?.onCellAction?(.uninstall, app)
        }
        let cancelAction = UIAlertAction(title: NSLocalizedString("Cancel", comment: ""), style: .cancel)
        alert.addAction(openAction)
        alert.addAction(jitAction)
        alert.addAction(registrationAction)
        alert.addAction(entitlementsAction)
        alert.addAction(uninstallAction)
        alert.addAction(cancelAction)
        if let popover = alert.popoverPresentationController {
            popover.sourceView = cell
            popover.sourceRect = cell.bounds
        }
        tableView.window?.rootViewController?.present(alert, animated: true)
    }
}

private class AppListCell: UITableViewCell {
    static let reuseIdentifier = "AppListCell"
    private let iconImageView = UIImageView()
    private let nameLabel = UILabel()
    private let bundleIdLabel = UILabel()
    private let registrationBadge = UILabel()
    private let moreButton = UIButton(type: .system)
    var onMoreActions: (() -> Void)?

    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        setupUI()
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    private func setupUI() {
        backgroundColor = .clear
        contentView.backgroundColor = .clear
        let blurEffect = UIBlurEffect(style: .systemUltraThinMaterial)
        let bgView = UIVisualEffectView(effect: blurEffect)
        bgView.layer.cornerRadius = 14
        bgView.layer.cornerCurve = .continuous
        bgView.clipsToBounds = true
        bgView.layer.borderWidth = 0.5
        bgView.layer.borderColor = UIColor.white.withAlphaComponent(0.18).cgColor
        backgroundView = bgView

        let selBgView = UIVisualEffectView(effect: UIBlurEffect(style: .systemThinMaterial))
        selBgView.layer.cornerRadius = 14
        selBgView.layer.cornerCurve = .continuous
        selBgView.clipsToBounds = true
        selectedBackgroundView = selBgView

        iconImageView.translatesAutoresizingMaskIntoConstraints = false
        iconImageView.contentMode = .scaleAspectFill
        iconImageView.layer.cornerRadius = 12
        iconImageView.layer.cornerCurve = .continuous
        iconImageView.layer.masksToBounds = true
        iconImageView.tintColor = .label
        contentView.addSubview(iconImageView)

        nameLabel.translatesAutoresizingMaskIntoConstraints = false
        nameLabel.font = .systemFont(ofSize: 17, weight: .semibold)
        nameLabel.textColor = .label
        contentView.addSubview(nameLabel)

        bundleIdLabel.translatesAutoresizingMaskIntoConstraints = false
        bundleIdLabel.font = .systemFont(ofSize: 13)
        bundleIdLabel.textColor = .secondaryLabel
        contentView.addSubview(bundleIdLabel)

        registrationBadge.translatesAutoresizingMaskIntoConstraints = false
        registrationBadge.font = .systemFont(ofSize: 11, weight: .semibold)
        registrationBadge.textAlignment = .center
        registrationBadge.layer.cornerRadius = 4
        registrationBadge.layer.cornerCurve = .continuous
        registrationBadge.layer.masksToBounds = true
        contentView.addSubview(registrationBadge)

        moreButton.translatesAutoresizingMaskIntoConstraints = false
        let configuration = UIImage.SymbolConfiguration(pointSize: 18, weight: .medium)
        moreButton.setImage(UIImage(systemName: "ellipsis", withConfiguration: configuration), for: .normal)
        moreButton.tintColor = .systemBlue
        moreButton.addTarget(self, action: #selector(moreButtonTapped), for: .touchUpInside)
        contentView.addSubview(moreButton)

        NSLayoutConstraint.activate([
            iconImageView.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 20),
            iconImageView.centerYAnchor.constraint(equalTo: contentView.centerYAnchor),
            iconImageView.widthAnchor.constraint(equalToConstant: 50),
            iconImageView.heightAnchor.constraint(equalToConstant: 50),
            nameLabel.leadingAnchor.constraint(equalTo: iconImageView.trailingAnchor, constant: 16),
            nameLabel.topAnchor.constraint(equalTo: contentView.topAnchor, constant: 12),
            nameLabel.trailingAnchor.constraint(lessThanOrEqualTo: moreButton.leadingAnchor, constant: -12),
            bundleIdLabel.leadingAnchor.constraint(equalTo: nameLabel.leadingAnchor),
            bundleIdLabel.topAnchor.constraint(equalTo: nameLabel.bottomAnchor, constant: 2),
            bundleIdLabel.trailingAnchor.constraint(equalTo: nameLabel.trailingAnchor),
            registrationBadge.leadingAnchor.constraint(equalTo: nameLabel.leadingAnchor),
            registrationBadge.topAnchor.constraint(equalTo: bundleIdLabel.bottomAnchor, constant: 4),
            registrationBadge.bottomAnchor.constraint(equalTo: contentView.bottomAnchor, constant: -12),
            registrationBadge.widthAnchor.constraint(greaterThanOrEqualToConstant: 44),
            registrationBadge.heightAnchor.constraint(equalToConstant: 16),
            moreButton.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -16),
            moreButton.centerYAnchor.constraint(equalTo: contentView.centerYAnchor),
            moreButton.widthAnchor.constraint(equalToConstant: 36),
            moreButton.heightAnchor.constraint(equalToConstant: 36)
        ])
    }

    override func traitCollectionDidChange(_ previousTraitCollection: UITraitCollection?) {
        super.traitCollectionDidChange(previousTraitCollection)
        if traitCollection.userInterfaceStyle == .dark {
            backgroundView?.layer.borderColor = UIColor.white.withAlphaComponent(0.08).cgColor
        } else {
            backgroundView?.layer.borderColor = UIColor.white.withAlphaComponent(0.18).cgColor
        }
    }

    func configure(with app: TrollStoreAppInfo) {
        iconImageView.image = app.icon ?? UIImage(systemName: "app")
        nameLabel.text = app.displayName
        bundleIdLabel.text = app.bundleIdentifier
        if app.isSystemRegistered {
            registrationBadge.text = NSLocalizedString("System", comment: "")
            registrationBadge.backgroundColor = .systemGreen
            registrationBadge.textColor = .white
        } else {
            registrationBadge.text = NSLocalizedString("User", comment: "")
            registrationBadge.backgroundColor = .systemGray
            registrationBadge.textColor = .white
        }
    }

    @objc private func moreButtonTapped() {
        onMoreActions?()
    }
}

class AppDetailViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    private let appInfo: TrollStoreAppInfo
    private let tableView = UITableView(frame: .zero, style: .insetGrouped)
    private var entitlements: [String: Any] = [:]
    var onAction: ((AppCellAction) -> Void)?

    init(appInfo: TrollStoreAppInfo) {
        self.appInfo = appInfo
        super.init(nibName: nil, bundle: nil)
    }

    required init?(coder: NSCoder) { fatalError() }

    override func viewDidLoad() {
        super.viewDidLoad()
        title = appInfo.displayName
        view.backgroundColor = .systemGroupedBackground
        tableView.dataSource = self
        tableView.delegate = self
        tableView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(tableView)
        NSLayoutConstraint.activate([
            tableView.topAnchor.constraint(equalTo: view.topAnchor),
            tableView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            tableView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            tableView.bottomAnchor.constraint(equalTo: view.bottomAnchor)
        ])
        let infoPlistPath = (appInfo.appPath as NSString).appendingPathComponent("Info.plist")
        if let infoDict = NSDictionary(contentsOfFile: infoPlistPath) as? [String: Any],
           let executable = infoDict["CFBundleExecutable"] as? String {
            let binaryPath = (appInfo.appPath as NSString).appendingPathComponent(executable)
            DispatchQueue.global(qos: .userInitiated).async { [weak self] in
                let ent = (try? InstallationManager.dumpEntitlements(binaryPath: binaryPath)) ?? [:]
                DispatchQueue.main.async {
                    self?.entitlements = ent
                    self?.tableView.reloadData()
                }
            }
        }
    }

    func numberOfSections(in tableView: UITableView) -> Int { return 4 }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if section == 0 { return 4 }
        if section == 1 { return 4 }
        if section == 2 { return entitlements.count }
        if section == 3 { return 1 }
        return 0
    }

    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        if section == 0 { return NSLocalizedString("Info", comment: "") }
        if section == 1 { return NSLocalizedString("Actions", comment: "") }
        if section == 2 { return NSLocalizedString("Entitlements", comment: "") }
        return nil
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell") ?? UITableViewCell(style: .value1, reuseIdentifier: "Cell")
        if indexPath.section == 0 {
            if indexPath.row == 0 {
                cell.textLabel?.text = NSLocalizedString("Bundle ID", comment: "")
                cell.detailTextLabel?.text = appInfo.bundleIdentifier
            } else if indexPath.row == 1 {
                cell.textLabel?.text = NSLocalizedString("Registration", comment: "")
                cell.detailTextLabel?.text = appInfo.isSystemRegistered ? NSLocalizedString("System", comment: "") : NSLocalizedString("User", comment: "")
            } else if indexPath.row == 2 {
                cell.textLabel?.text = NSLocalizedString("Path", comment: "")
                cell.detailTextLabel?.text = appInfo.appPath
            } else {
                cell.textLabel?.text = NSLocalizedString("Size", comment: "")
                cell.detailTextLabel?.text = ByteCountFormatter.string(fromByteCount: Int64(appInfo.size), countStyle: .file)
            }
            cell.selectionStyle = .none
            cell.textLabel?.textColor = .secondaryLabel
            cell.detailTextLabel?.textColor = .label
            return cell
        } else if indexPath.section == 1 {
            if indexPath.row == 0 {
                cell.textLabel?.text = NSLocalizedString("Open", comment: "")
                cell.textLabel?.textColor = .systemBlue
            } else if indexPath.row == 1 {
                cell.textLabel?.text = NSLocalizedString("Enable JIT", comment: "")
                cell.textLabel?.textColor = .systemBlue
            } else if indexPath.row == 2 {
                cell.textLabel?.text = NSLocalizedString("Change Registration", comment: "")
                cell.textLabel?.textColor = .systemBlue
            } else {
                cell.textLabel?.text = NSLocalizedString("Uninstall", comment: "")
                cell.textLabel?.textColor = .systemRed
            }
        } else if indexPath.section == 2 {
            let keys = entitlements.keys.sorted()
            let key = keys[indexPath.row]
            cell.textLabel?.text = key
            cell.detailTextLabel?.text = String(describing: entitlements[key] ?? "")
        } else if indexPath.section == 3 {
            cell.textLabel?.text = NSLocalizedString("Edit Entitlements", comment: "")
            cell.textLabel?.textColor = .systemBlue
        }
        return cell
    }

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        if indexPath.section == 1 {
            if indexPath.row == 0 { onAction?(.open) }
            else if indexPath.row == 1 { onAction?(.enableJIT) }
            else if indexPath.row == 2 { onAction?(.changeRegistration) }
            else if indexPath.row == 3 { onAction?(.uninstall) }
        } else if indexPath.section == 3 {
            onAction?(.editEntitlements)
        }
    }
}

public class InstallationProgressController {
    private static var overlayView: UIView?
    public static func show(on viewController: UIViewController, message: String? = nil) {
        guard overlayView == nil else { return }
        let overlay = UIView(frame: viewController.view.bounds)
        overlay.backgroundColor = UIColor.black.withAlphaComponent(0.4)
        overlay.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        let containerView = UIVisualEffectView(effect: UIBlurEffect(style: .systemThickMaterial))
        containerView.translatesAutoresizingMaskIntoConstraints = false
        containerView.layer.cornerRadius = 16
        containerView.layer.cornerCurve = .continuous
        containerView.clipsToBounds = true
        containerView.layer.borderWidth = 0.5
        containerView.layer.borderColor = UIColor.white.withAlphaComponent(0.18).cgColor
        overlay.addSubview(containerView)
        let indicator = UIActivityIndicatorView(style: .large)
        indicator.translatesAutoresizingMaskIntoConstraints = false
        indicator.startAnimating()
        containerView.contentView.addSubview(indicator)
        let label = UILabel()
        label.translatesAutoresizingMaskIntoConstraints = false
        label.font = .systemFont(ofSize: 16, weight: .medium)
        label.textColor = .label
        label.textAlignment = .center
        label.text = message ?? NSLocalizedString("Installing", comment: "")
        containerView.contentView.addSubview(label)
        NSLayoutConstraint.activate([
            containerView.centerXAnchor.constraint(equalTo: overlay.centerXAnchor),
            containerView.centerYAnchor.constraint(equalTo: overlay.centerYAnchor),
            containerView.widthAnchor.constraint(equalToConstant: 200),
            containerView.heightAnchor.constraint(equalToConstant: 120),
            indicator.centerXAnchor.constraint(equalTo: containerView.centerXAnchor),
            indicator.topAnchor.constraint(equalTo: containerView.topAnchor, constant: 20),
            label.leadingAnchor.constraint(equalTo: containerView.leadingAnchor, constant: 16),
            label.trailingAnchor.constraint(equalTo: containerView.trailingAnchor, constant: -16),
            label.topAnchor.constraint(equalTo: indicator.bottomAnchor, constant: 12)
        ])
        viewController.view.addSubview(overlay)
        overlayView = overlay
    }
    public static func hide() {
        overlayView?.removeFromSuperview()
        overlayView = nil
    }
}

public class ErrorHandler {
    public static func showError(_ error: Error, on viewController: UIViewController?) {
        let alert = UIAlertController(
            title: NSLocalizedString("Error", comment: ""),
            message: error.localizedDescription,
            preferredStyle: .alert
        )
        if let trollError = error as? TrollStoreInstallError {
            alert.title = String(format: NSLocalizedString("Error %d", comment: ""), trollError.code)
            let unknownError = NSLocalizedString("Unknown Error", comment: "")
            let copyLogAction = UIAlertAction(title: NSLocalizedString("Copy Debug Log", comment: ""), style: .default) { _ in
                UIPasteboard.general.string = "Error Code: " + String(trollError.code) + "\n " + (trollError.errorDescription ?? unknownError)
            }
            alert.addAction(copyLogAction)
        }
        let closeAction = UIAlertAction(title: NSLocalizedString("Close", comment: ""), style: .default)
        alert.addAction(closeAction)
        viewController?.present(alert, animated: true)
    }
    public static func showSuccess(on viewController: UIViewController?, message: String) {
        let alert = UIAlertController(
            title: NSLocalizedString("Success", comment: ""),
            message: message,
            preferredStyle: .alert
        )
        let closeAction = UIAlertAction(title: NSLocalizedString("Close", comment: ""), style: .default)
        alert.addAction(closeAction)
        viewController?.present(alert, animated: true)
    }
}

private class EntitlementNode: NSObject {
    var key: String
    var value: Any?
    var isDictionary: Bool
    var isArray: Bool
    var children: [EntitlementNode]
    weak var parent: EntitlementNode?
    init(key: String, value: Any?) {
        self.key = key
        self.value = value
        if value is [String: Any] {
            self.isDictionary = true
            self.isArray = false
        } else if value is [Any] {
            self.isDictionary = false
            self.isArray = true
        } else {
            self.isDictionary = false
            self.isArray = false
        }
        self.children = []
        super.init()
        if let dict = value as? [String: Any] {
            for k in dict.keys.sorted() {
                let child = EntitlementNode(key: k, value: dict[k])
                child.parent = self
                self.children.append(child)
            }
        } else if let array = value as? [Any] {
            for (index, element) in array.enumerated() {
                let childKey = "[" + String(index) + "]"
                let child = EntitlementNode(key: childKey, value: element)
                child.parent = self
                self.children.append(child)
            }
        }
    }
    func rebuildChildren() {
        var newChildren: [EntitlementNode] = []
        if let dict = value as? [String: Any] {
            for k in dict.keys.sorted() {
                let child = EntitlementNode(key: k, value: dict[k])
                child.parent = self
                newChildren.append(child)
            }
        } else if let array = value as? [Any] {
            for (index, element) in array.enumerated() {
                let childKey = "[" + String(index) + "]"
                let child = EntitlementNode(key: childKey, value: element)
                child.parent = self
                newChildren.append(child)
            }
        }
        children = newChildren
    }
}

private enum EntitlementValueType: Int, CaseIterable {
    case string, boolean, number, dictionary, array, data, date
    var name: String {
        switch self {
        case .string: return "String"
        case .boolean: return "Boolean"
        case .number: return "Number"
        case .dictionary: return "Dictionary"
        case .array: return "Array"
        case .data: return "Data"
        case .date: return "Date"
        }
    }
    static func from(_ value: Any?) -> EntitlementValueType {
        guard let v = value else { return .string }
        if v is Bool { return .boolean }
        if v is Int || v is Double || v is Float { return .number }
        if v is [String: Any] { return .dictionary }
        if v is [Any] { return .array }
        if v is Data { return .data }
        if v is Date { return .date }
        return .string
    }
}

public class EntitlementsTreeViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    private var treeView: UITableView!
    private let appInfo: TrollStoreAppInfo
    private let binaryPath: String
    private var entitlements: [String: Any] = [:]
    private var rootNodes: [EntitlementNode] = []
    private var visibleNodes: [(node: EntitlementNode, level: Int)] = []
    private var expandedNodes: Set<ObjectIdentifier> = []
    public init(appInfo: TrollStoreAppInfo, binaryPath: String) {
        self.appInfo = appInfo
        self.binaryPath = binaryPath
        super.init(nibName: nil, bundle: nil)
    }
    required init?(coder: NSCoder) { fatalError() }
    public override func viewDidLoad() {
        super.viewDidLoad()
        title = NSLocalizedString("Edit Entitlements", comment: "")
        view.backgroundColor = .systemGroupedBackground
        navigationItem.rightBarButtonItems = [
            UIBarButtonItem(barButtonSystemItem: .save, target: self, action: #selector(saveTapped)),
            UIBarButtonItem(barButtonSystemItem: .add, target: self, action: #selector(addTapped))
        ]
        treeView = UITableView(frame: view.bounds, style: .insetGrouped)
        treeView.translatesAutoresizingMaskIntoConstraints = false
        treeView.dataSource = self
        treeView.delegate = self
        treeView.register(UITableViewCell.self, forCellReuseIdentifier: "Cell")
        view.addSubview(treeView)
        NSLayoutConstraint.activate([
            treeView.topAnchor.constraint(equalTo: view.topAnchor),
            treeView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            treeView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            treeView.bottomAnchor.constraint(equalTo: view.bottomAnchor)
        ])
        loadEntitlements()
    }
    private func loadEntitlements() {
        DispatchQueue.global(qos: .userInitiated).async { [weak self] in
            guard let self = self else { return }
            let ent = (try? InstallationManager.dumpEntitlements(binaryPath: self.binaryPath)) ?? [:]
            DispatchQueue.main.async {
                self.entitlements = ent
                self.rebuildRootNodes()
                self.rebuildVisibleNodes()
                self.treeView.reloadData()
            }
        }
    }
    private func rebuildRootNodes() {
        var nodes: [EntitlementNode] = []
        for key in entitlements.keys.sorted() {
            nodes.append(EntitlementNode(key: key, value: entitlements[key]))
        }
        rootNodes = nodes
    }
    private func rebuildVisibleNodes() {
        visibleNodes.removeAll()
        for node in rootNodes {
            flattenNode(node, level: 0)
        }
    }
    private func flattenNode(_ node: EntitlementNode, level: Int) {
        visibleNodes.append((node, level))
        if expandedNodes.contains(ObjectIdentifier(node)) {
            for child in node.children {
                flattenNode(child, level: level + 1)
            }
        }
    }
    @objc private func saveTapped() {
        do {
            try InstallationManager.setEntitlements(binaryPath: binaryPath, entitlements: entitlements)
            let alert = UIAlertController(title: NSLocalizedString("Success", comment: ""), message: NSLocalizedString("Entitlements Saved", comment: ""), preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: NSLocalizedString("Close", comment: ""), style: .default) { [weak self] _ in
                self?.navigationController?.popViewController(animated: true)
            })
            present(alert, animated: true)
        } catch {
            ErrorHandler.showError(error, on: self)
        }
    }
    @objc private func addTapped() {
        let alert = UIAlertController(title: NSLocalizedString("Add Key", comment: ""), message: nil, preferredStyle: .alert)
        alert.addTextField { tf in tf.placeholder = "Key" }
        alert.addAction(UIAlertAction(title: NSLocalizedString("Cancel", comment: ""), style: .cancel))
        alert.addAction(UIAlertAction(title: NSLocalizedString("Add", comment: ""), style: .default) { [weak self] _ in
            guard let self = self else { return }
            guard let key = alert.textFields?.first?.text, !key.isEmpty else { return }
            self.entitlements[key] = ""
            self.rebuildRootNodes()
            self.rebuildVisibleNodes()
            self.treeView.reloadData()
        })
        present(alert, animated: true)
    }
    public func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return visibleNodes.count
    }
    public func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath)
        let item = visibleNodes[indexPath.row]
        cell.textLabel?.text = item.node.key
        cell.indentationLevel = item.level
        cell.indentationWidth = 20
        if item.node.isDictionary || item.node.isArray {
            cell.accessoryType = .disclosureIndicator
            cell.detailTextLabel?.text = item.node.isDictionary ? "[Dictionary]" : "[Array]"
        } else {
            cell.accessoryType = .none
            if let v = item.node.value {
                if let b = v as? Bool { cell.detailTextLabel?.text = b ? "true" : "false" }
                else { cell.detailTextLabel?.text = String(describing: v) }
            } else {
                cell.detailTextLabel?.text = ""
            }
        }
        return cell
    }
    public func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        let item = visibleNodes[indexPath.row]
        if item.node.isDictionary || item.node.isArray {
            let id = ObjectIdentifier(item.node)
            if expandedNodes.contains(id) {
                expandedNodes.remove(id)
            } else {
                expandedNodes.insert(id)
            }
            rebuildVisibleNodes()
            treeView.reloadData()
        } else {
            editNodeValue(item.node)
        }
    }
    public func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            let item = visibleNodes[indexPath.row]
            deleteNode(item.node)
        }
    }
    private func editNodeValue(_ node: EntitlementNode) {
        let type = EntitlementValueType.from(node.value)
        switch type {
        case .boolean:
            node.value = !((node.value as? Bool) ?? false)
            applyNodeChange(node)
        case .string:
            promptString(node: node)
        case .number:
            promptNumber(node: node)
        default: break
        }
    }
    private func promptString(node: EntitlementNode) {
        let alert = UIAlertController(title: node.key, message: nil, preferredStyle: .alert)
        alert.addTextField { tf in tf.text = node.value as? String }
        alert.addAction(UIAlertAction(title: NSLocalizedString("Cancel", comment: ""), style: .cancel))
        alert.addAction(UIAlertAction(title: NSLocalizedString("Save", comment: ""), style: .default) { [weak self] _ in
            guard let self = self else { return }
            node.value = alert.textFields?.first?.text ?? ""
            self.applyNodeChange(node)
        })
        present(alert, animated: true)
    }
    private func promptNumber(node: EntitlementNode) {
        let alert = UIAlertController(title: node.key, message: nil, preferredStyle: .alert)
        alert.addTextField { tf in
            tf.keyboardType = .numbersAndPunctuation
            tf.text = String(describing: node.value ?? 0)
        }
        alert.addAction(UIAlertAction(title: NSLocalizedString("Cancel", comment: ""), style: .cancel))
        alert.addAction(UIAlertAction(title: NSLocalizedString("Save", comment: ""), style: .default) { [weak self] _ in
            guard let self = self else { return }
            let text = alert.textFields?.first?.text ?? "0"
            if let intVal = Int(text) { node.value = intVal }
            else if let doubleVal = Double(text) { node.value = doubleVal }
            else { node.value = 0 }
            self.applyNodeChange(node)
        })
        present(alert, animated: true)
    }
    private func applyNodeChange(_ node: EntitlementNode) {
        if let parent = node.parent {
            if let dict = parent.value as? [String: Any] {
                var mutable = dict
                mutable[node.key] = node.value
                parent.value = mutable
                parent.rebuildChildren()
            } else if let array = parent.value as? [Any] {
                var mutable = array
                if let index = Int(node.key.replacingOccurrences(of: "[", with: "").replacingOccurrences(of: "]", with: "")), index < mutable.count {
                    mutable[index] = node.value ?? ""
                    parent.value = mutable
                    parent.rebuildChildren()
                }
            }
        } else {
            entitlements[node.key] = node.value
            rebuildRootNodes()
        }
        rebuildVisibleNodes()
        treeView.reloadData()
    }
    private func deleteNode(_ node: EntitlementNode) {
        if let parent = node.parent {
            if let dict = parent.value as? [String: Any] {
                var mutable = dict
                mutable.removeValue(forKey: node.key)
                parent.value = mutable
                parent.rebuildChildren()
            } else if let array = parent.value as? [Any] {
                var mutable = array
                if let index = Int(node.key.replacingOccurrences(of: "[", with: "").replacingOccurrences(of: "]", with: "")), index < mutable.count {
                    mutable.remove(at: index)
                    parent.value = mutable
                    parent.rebuildChildren()
                }
            }
        } else {
            entitlements.removeValue(forKey: node.key)
            rebuildRootNodes()
        }
        rebuildVisibleNodes()
        treeView.reloadData()
    }
}
