import UIKit
import Foundation

public class AppListViewController: UIViewController {
    private let tableView = UITableView(frame: .zero, style: .plain)
    private let refreshControl = UIRefreshControl()
    private var installedApps: [TrollStoreAppInfo] = []
    private let dataSource = AppListDataSource()

    public override func viewDidLoad() {
        super.viewDidLoad()
        title = NSLocalizedString("Apps", comment: "")
        view.backgroundColor = .systemBackground
        setupTableView()
        setupNavigationBar()
        loadApps()
    }

    public override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        loadApps()
    }

    private func setupTableView() {
        tableView.translatesAutoresizingMaskIntoConstraints = false
        tableView.dataSource = dataSource
        tableView.delegate = dataSource
        tableView.register(AppListCell.self, forCellReuseIdentifier: AppListCell.reuseIdentifier)
        tableView.rowHeight = 80
        tableView.refreshControl = refreshControl
        refreshControl.addTarget(self, action: #selector(loadApps), for: .valueChanged)
        view.addSubview(tableView)
        NSLayoutConstraint.activate([
            tableView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
            tableView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            tableView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            tableView.bottomAnchor.constraint(equalTo: view.bottomAnchor)
        ])
        dataSource.onCellAction = { [weak self] action, appInfo in
            self?.handleCellAction(action, for: appInfo)
        }
    }

    private func setupNavigationBar() {
        let installButton = UIBarButtonItem(barButtonSystemItem: .add, target: self, action: #selector(installAppTapped))
        navigationItem.rightBarButtonItem = installButton
    }

    @objc private func loadApps() {
        DispatchQueue.global(qos: .userInitiated).async { [weak self] in
            let apps = AppManager.getInstalledApps()
            DispatchQueue.main.async {
                self?.installedApps = apps
                self?.dataSource.apps = apps
                self?.tableView.reloadData()
                self?.refreshControl.endRefreshing()
            }
        }
    }

    @objc private func installAppTapped() {
        let picker = UIDocumentPickerViewController(forOpeningContentTypes: [.item])
        picker.delegate = self
        picker.allowsMultipleSelection = false
        present(picker, animated: true)
    }

    private func handleCellAction(_ action: AppCellAction, for appInfo: TrollStoreAppInfo) {
        switch action {
        case .open:
            _ = AppManager.openApp(bundleId: appInfo.bundleIdentifier)
        case .uninstall:
            confirmUninstall(appInfo)
        case .enableJIT:
            enableJIT(appInfo)
        case .changeRegistration:
            changeRegistration(appInfo)
        case .editEntitlements:
            editEntitlements(appInfo)
        }
    }

    private func confirmUninstall(_ appInfo: TrollStoreAppInfo) {
        let alert = UIAlertController(
            title: NSLocalizedString("Uninstall_App", comment: ""),
            message: String(format: NSLocalizedString("Uninstall_App_Message", comment: ""), appInfo.displayName),
            preferredStyle: .alert
        )
        let cancelAction = UIAlertAction(title: NSLocalizedString("Cancel", comment: ""), style: .cancel)
        let uninstallAction = UIAlertAction(title: NSLocalizedString("Uninstall", comment: ""), style: .destructive) { [weak self] _ in
            self?.uninstallApp(appInfo)
        }
        alert.addAction(cancelAction)
        alert.addAction(uninstallAction)
        present(alert, animated: true)
    }

    private func uninstallApp(_ appInfo: TrollStoreAppInfo) {
        InstallationProgressController.show(on: self)
        DispatchQueue.global(qos: .userInitiated).async { [weak self] in
            do {
                try InstallationManager.uninstallApp(bundleId: appInfo.bundleIdentifier, useCustomMethod: false)
                DispatchQueue.main.async {
                    InstallationProgressController.hide()
                    self?.loadApps()
                }
            } catch {
                DispatchQueue.main.async {
                    InstallationProgressController.hide()
                    ErrorHandler.showError(error, on: self)
                }
            }
        }
    }

    private func enableJIT(_ appInfo: TrollStoreAppInfo) {
        InstallationProgressController.show(on: self, message: NSLocalizedString("Enabling_JIT", comment: ""))
        DispatchQueue.global(qos: .userInitiated).async { [weak self] in
            do {
                try InstallationManager.enableJIT(bundleId: appInfo.bundleIdentifier)
                DispatchQueue.main.async {
                    InstallationProgressController.hide()
                    ErrorHandler.showSuccess(on: self, message: NSLocalizedString("JIT_Enabled", comment: ""))
                }
            } catch {
                DispatchQueue.main.async {
                    InstallationProgressController.hide()
                    ErrorHandler.showError(error, on: self)
                }
            }
        }
    }

    private func changeRegistration(_ appInfo: TrollStoreAppInfo) {
        let alert = UIAlertController(
            title: NSLocalizedString("Change_Registration", comment: ""),
            message: nil,
            preferredStyle: .actionSheet
        )
        let systemAction = UIAlertAction(title: NSLocalizedString("System", comment: ""), style: .default) { [weak self] _ in
            self?.setRegistration(appInfo, isSystem: true)
        }
        let userAction = UIAlertAction(title: NSLocalizedString("User", comment: ""), style: .default) { [weak self] _ in
            self?.setRegistration(appInfo, isSystem: false)
        }
        let cancelAction = UIAlertAction(title: NSLocalizedString("Cancel", comment: ""), style: .cancel)
        alert.addAction(systemAction)
        alert.addAction(userAction)
        alert.addAction(cancelAction)
        if let popover = alert.popoverPresentationController {
            popover.sourceView = self.view
            popover.sourceRect = CGRect(x: self.view.bounds.midX, y: self.view.bounds.midY, width: 0, height: 0)
        }
        present(alert, animated: true)
    }

    private func setRegistration(_ appInfo: TrollStoreAppInfo, isSystem: Bool) {
        InstallationProgressController.show(on: self)
        DispatchQueue.global(qos: .userInitiated).async { [weak self] in
            do {
                try InstallationManager.changeRegistration(appPath: appInfo.appPath, isSystem: isSystem)
                DispatchQueue.main.async {
                    InstallationProgressController.hide()
                    self?.loadApps()
                }
            } catch {
                DispatchQueue.main.async {
                    InstallationProgressController.hide()
                    ErrorHandler.showError(error, on: self)
                }
            }
        }
    }

    private func editEntitlements(_ appInfo: TrollStoreAppInfo) {
        let infoPlistPath = (appInfo.appPath as NSString).appendingPathComponent("Info.plist")
        guard let infoDict = NSDictionary(contentsOfFile: infoPlistPath) as? [String: Any],
              let executable = infoDict["CFBundleExecutable"] as? String else { return }
        let binaryPath = (appInfo.appPath as NSString).appendingPathComponent(executable)
        let editor = EntitlementsTreeViewController(appInfo: appInfo, binaryPath: binaryPath)
        navigationController?.pushViewController(editor, animated: true)
    }
}

extension AppListViewController: UIDocumentPickerDelegate {
    public func documentPicker(_ controller: UIDocumentPickerViewController, didPickDocumentsAt urls: [URL]) {
        guard let url = urls.first else { return }
        _ = url.startAccessingSecurityScopedResource()
        defer { url.stopAccessingSecurityScopedResource() }
        let tempPath = NSTemporaryDirectory().appending(UUID().uuidString).appending(".ipa")
        do {
            try FileManager.default.copyItem(at: url, to: URL(fileURLWithPath: tempPath))
            installIPAFromFile(path: tempPath)
        } catch {
            ErrorHandler.showError(error, on: self)
        }
    }

    private func installIPAFromFile(path: String) {
        InstallationProgressController.show(on: self)
        DispatchQueue.global(qos: .userInitiated).async { [weak self] in
            do {
                try InstallationManager.installIPA(path: path, force: false, useInstalldMethod: false, skipUICache: false)
                DispatchQueue.main.async {
                    InstallationProgressController.hide()
                    self?.loadApps()
                    try? FileManager.default.removeItem(atPath: path)
                }
            } catch let error as TrollStoreInstallError {
                DispatchQueue.main.async {
                    InstallationProgressController.hide()
                    if error.code == 171 {
                        self?.showForceInstallAlert(path: path, error: error)
                    } else {
                        ErrorHandler.showError(error, on: self)
                    }
                    try? FileManager.default.removeItem(atPath: path)
                }
            } catch {
                DispatchQueue.main.async {
                    InstallationProgressController.hide()
                    ErrorHandler.showError(error, on: self)
                    try? FileManager.default.removeItem(atPath: path)
                }
            }
        }
    }

    private func showForceInstallAlert(path: String, error: TrollStoreInstallError) {
        let alert = UIAlertController(
            title: NSLocalizedString("Install_Error", comment: ""),
            message: error.errorDescription,
            preferredStyle: .alert
        )
        let closeAction = UIAlertAction(title: NSLocalizedString("Close", comment: ""), style: .cancel)
        let forceAction = UIAlertAction(title: NSLocalizedString("Force_Install", comment: ""), style: .destructive) { [weak self] _ in
            self?.forceInstallIPA(path: path)
        }
        alert.addAction(closeAction)
        alert.addAction(forceAction)
        present(alert, animated: true)
    }

    private func forceInstallIPA(path: String) {
        InstallationProgressController.show(on: self)
        DispatchQueue.global(qos: .userInitiated).async { [weak self] in
            do {
                try InstallationManager.installIPA(path: path, force: true, useInstalldMethod: false, skipUICache: false)
                DispatchQueue.main.async {
                    InstallationProgressController.hide()
                    self?.loadApps()
                    try? FileManager.default.removeItem(atPath: path)
                }
            } catch {
                DispatchQueue.main.async {
                    InstallationProgressController.hide()
                    ErrorHandler.showError(error, on: self)
                    try? FileManager.default.removeItem(atPath: path)
                }
            }
        }
    }
}

public enum AppCellAction {
    case open
    case uninstall
    case enableJIT
    case changeRegistration
    case editEntitlements
}

private class AppListDataSource: NSObject, UITableViewDataSource, UITableViewDelegate {
    var apps: [TrollStoreAppInfo] = []
    var onCellAction: ((AppCellAction, TrollStoreAppInfo) -> Void)?

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return apps.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: AppListCell.reuseIdentifier, for: indexPath) as! AppListCell
        let app = apps[indexPath.row]
        cell.configure(with: app)
        cell.onMoreActions = { [weak self, weak tableView] in
            self?.showActionsMenu(for: app, at: tableView, indexPath: indexPath)
        }
        return cell
    }

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        let app = apps[indexPath.row]
        onCellAction?(.open, app)
    }

    func tableView(_ tableView: UITableView, contextMenuConfigurationForRowAt indexPath: IndexPath, point: CGPoint) -> UIContextMenuConfiguration? {
        let app = apps[indexPath.row]
        return UIContextMenuConfiguration(identifier: nil, previewProvider: nil) { _ in
            let openAction = UIAction(title: NSLocalizedString("Open", comment: ""), image: UIImage(systemName: "play")) { [weak self] _ in
                self?.onCellAction?(.open, app)
            }
            let jitAction = UIAction(title: NSLocalizedString("Enable_JIT", comment: ""), image: UIImage(systemName: "bolt")) { [weak self] _ in
                self?.onCellAction?(.enableJIT, app)
            }
            let registrationAction = UIAction(title: NSLocalizedString("Change_Registration", comment: ""), image: UIImage(systemName: "arrow.triangle.2.circlepath")) { [weak self] _ in
                self?.onCellAction?(.changeRegistration, app)
            }
            let entitlementsAction = UIAction(title: NSLocalizedString("Edit_Entitlements", comment: ""), image: UIImage(systemName: "doc.text")) { [weak self] _ in
                self?.onCellAction?(.editEntitlements, app)
            }
            let uninstallAction = UIAction(title: NSLocalizedString("Uninstall", comment: ""), image: UIImage(systemName: "trash"), attributes: .destructive) { [weak self] _ in
                self?.onCellAction?(.uninstall, app)
            }
            return UIMenu(title: "", children: [openAction, jitAction, registrationAction, entitlementsAction, uninstallAction])
        }
    }

    private func showActionsMenu(for app: TrollStoreAppInfo, at tableView: UITableView?, indexPath: IndexPath) {
        guard let tableView = tableView, let cell = tableView.cellForRow(at: indexPath) else { return }
        let alert = UIAlertController(title: nil, message: nil, preferredStyle: .actionSheet)
        let openAction = UIAlertAction(title: NSLocalizedString("Open", comment: ""), style: .default) { [weak self] _ in
            self?.onCellAction?(.open, app)
        }
        let jitAction = UIAlertAction(title: NSLocalizedString("Enable_JIT", comment: ""), style: .default) { [weak self] _ in
            self?.onCellAction?(.enableJIT, app)
        }
        let registrationAction = UIAlertAction(title: NSLocalizedString("Change_Registration", comment: ""), style: .default) { [weak self] _ in
            self?.onCellAction?(.changeRegistration, app)
        }
        let entitlementsAction = UIAlertAction(title: NSLocalizedString("Edit_Entitlements", comment: ""), style: .default) { [weak self] _ in
            self?.onCellAction?(.editEntitlements, app)
        }
        let uninstallAction = UIAlertAction(title: NSLocalizedString("Uninstall", comment: ""), style: .destructive) { [weak self] _ in
            self?.onCellAction?(.uninstall, app)
        }
        let cancelAction = UIAlertAction(title: NSLocalizedString("Cancel", comment: ""), style: .cancel)
        alert.addAction(openAction)
        alert.addAction(jitAction)
        alert.addAction(registrationAction)
        alert.addAction(entitlementsAction)
        alert.addAction(uninstallAction)
        alert.addAction(cancelAction)
        if let popover = alert.popoverPresentationController {
            popover.sourceView = cell
            popover.sourceRect = cell.bounds
        }
        tableView.window?.rootViewController?.present(alert, animated: true)
    }
}

private class AppListCell: UITableViewCell {
    static let reuseIdentifier = "AppListCell"
    private let iconImageView = UIImageView()
    private let nameLabel = UILabel()
    private let bundleIdLabel = UILabel()
    private let registrationBadge = UILabel()
    private let moreButton = UIButton(type: .detailDisclosure)
    var onMoreActions: (() -> Void)?

    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        setupUI()
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    private func setupUI() {
        iconImageView.translatesAutoresizingMaskIntoConstraints = false
        iconImageView.contentMode = .scaleAspectFit
        iconImageView.layer.cornerRadius = 12
        iconImageView.layer.masksToBounds = true
        contentView.addSubview(iconImageView)

        nameLabel.translatesAutoresizingMaskIntoConstraints = false
        nameLabel.font = .systemFont(ofSize: 16, weight: .semibold)
        nameLabel.textColor = .label
        contentView.addSubview(nameLabel)

        bundleIdLabel.translatesAutoresizingMaskIntoConstraints = false
        bundleIdLabel.font = .systemFont(ofSize: 13)
        bundleIdLabel.textColor = .secondaryLabel
        contentView.addSubview(bundleIdLabel)

        registrationBadge.translatesAutoresizingMaskIntoConstraints = false
        registrationBadge.font = .systemFont(ofSize: 11, weight: .medium)
        registrationBadge.textAlignment = .center
        registrationBadge.layer.cornerRadius = 4
        registrationBadge.layer.masksToBounds = true
        contentView.addSubview(registrationBadge)

        moreButton.translatesAutoresizingMaskIntoConstraints = false
        moreButton.addTarget(self, action: #selector(moreButtonTapped), for: .touchUpInside)
        contentView.addSubview(moreButton)

        NSLayoutConstraint.activate([
            iconImageView.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 16),
            iconImageView.centerYAnchor.constraint(equalTo: contentView.centerYAnchor),
            iconImageView.widthAnchor.constraint(equalToConstant: 50),
            iconImageView.heightAnchor.constraint(equalToConstant: 50),

            nameLabel.leadingAnchor.constraint(equalTo: iconImageView.trailingAnchor, constant: 12),
            nameLabel.topAnchor.constraint(equalTo: iconImageView.topAnchor, constant: 2),
            nameLabel.trailingAnchor.constraint(lessThanOrEqualTo: moreButton.leadingAnchor, constant: -8),

            bundleIdLabel.leadingAnchor.constraint(equalTo: nameLabel.leadingAnchor),
            bundleIdLabel.topAnchor.constraint(equalTo: nameLabel.bottomAnchor, constant: 2),
            bundleIdLabel.trailingAnchor.constraint(equalTo: nameLabel.trailingAnchor),

            registrationBadge.leadingAnchor.constraint(equalTo: nameLabel.leadingAnchor),
            registrationBadge.topAnchor.constraint(equalTo: bundleIdLabel.bottomAnchor, constant: 4),
            registrationBadge.widthAnchor.constraint(greaterThanOrEqualToConstant: 50),
            registrationBadge.heightAnchor.constraint(equalToConstant: 18),

            moreButton.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -16),
            moreButton.centerYAnchor.constraint(equalTo: contentView.centerYAnchor),
            moreButton.widthAnchor.constraint(equalToConstant: 30),
            moreButton.heightAnchor.constraint(equalToConstant: 30)
        ])
    }

    func configure(with app: TrollStoreAppInfo) {
        iconImageView.image = app.icon ?? UIImage(systemName: "app")
        nameLabel.text = app.displayName
        bundleIdLabel.text = app.bundleIdentifier
        if app.isSystemRegistered {
            registrationBadge.text = NSLocalizedString("System", comment: "")
            registrationBadge.backgroundColor = .systemGreen
            registrationBadge.textColor = .white
        } else {
            registrationBadge.text = NSLocalizedString("User", comment: "")
            registrationBadge.backgroundColor = .systemGray
            registrationBadge.textColor = .white
        }
    }

    @objc private func moreButtonTapped() {
        onMoreActions?()
    }
}

public class InstallationProgressController {
    private static var overlayView: UIView?

    public static func show(on viewController: UIViewController, message: String? = nil) {
        guard overlayView == nil else { return }
        let overlay = UIView(frame: viewController.view.bounds)
        overlay.backgroundColor = UIColor.black.withAlphaComponent(0.4)
        overlay.autoresizingMask = [.flexibleWidth, .flexibleHeight]

        let containerView = UIView()
        containerView.translatesAutoresizingMaskIntoConstraints = false
        containerView.backgroundColor = .systemBackground
        containerView.layer.cornerRadius = 12
        overlay.addSubview(containerView)

        let indicator = UIActivityIndicatorView(style: .large)
        indicator.translatesAutoresizingMaskIntoConstraints = false
        indicator.startAnimating()
        containerView.addSubview(indicator)

        let label = UILabel()
        label.translatesAutoresizingMaskIntoConstraints = false
        label.font = .systemFont(ofSize: 16, weight: .medium)
        label.textColor = .label
        label.textAlignment = .center
        label.text = message ?? NSLocalizedString("Installing", comment: "")
        containerView.addSubview(label)

        NSLayoutConstraint.activate([
            containerView.centerXAnchor.constraint(equalTo: overlay.centerXAnchor),
            containerView.centerYAnchor.constraint(equalTo: overlay.centerYAnchor),
            containerView.widthAnchor.constraint(equalToConstant: 200),
            containerView.heightAnchor.constraint(equalToConstant: 120),

            indicator.centerXAnchor.constraint(equalTo: containerView.centerXAnchor),
            indicator.topAnchor.constraint(equalTo: containerView.topAnchor, constant: 20),

            label.leadingAnchor.constraint(equalTo: containerView.leadingAnchor, constant: 16),
            label.trailingAnchor.constraint(equalTo: containerView.trailingAnchor, constant: -16),
            label.topAnchor.constraint(equalTo: indicator.bottomAnchor, constant: 12)
        ])

        viewController.view.addSubview(overlay)
        overlayView = overlay
    }

    public static func hide() {
        overlayView?.removeFromSuperview()
        overlayView = nil
    }
}

public class ErrorHandler {
    public static func showError(_ error: Error, on viewController: UIViewController?) {
        let alert = UIAlertController(
            title: NSLocalizedString("Error", comment: ""),
            message: error.localizedDescription,
            preferredStyle: .alert
        )
        if let trollError = error as? TrollStoreInstallError {
            alert.title = String(format: NSLocalizedString("Install_Error_Code", comment: ""), trollError.code)
            let copyLogAction = UIAlertAction(title: NSLocalizedString("Copy_Debug_Log", comment: ""), style: .default) { _ in
                UIPasteboard.general.string = "Error Code: \(trollError.code)\n\(trollError.errorDescription ?? "Unknown error")"
            }
            alert.addAction(copyLogAction)
        }
        let closeAction = UIAlertAction(title: NSLocalizedString("Close", comment: ""), style: .default)
        alert.addAction(closeAction)
        viewController?.present(alert, animated: true)
    }

    public static func showSuccess(on viewController: UIViewController?, message: String) {
        let alert = UIAlertController(
            title: NSLocalizedString("Success", comment: ""),
            message: message,
            preferredStyle: .alert
        )
        let closeAction = UIAlertAction(title: NSLocalizedString("Close", comment: ""), style: .default)
        alert.addAction(closeAction)
        viewController?.present(alert, animated: true)
    }
}

private class EntitlementNode: NSObject {
    var key: String
    var value: Any?
    var isDictionary: Bool
    var isArray: Bool
    var children: [EntitlementNode]
    weak var parent: EntitlementNode?

    init(key: String, value: Any?) {
        self.key = key
        self.value = value
        if let dict = value as? [String: Any] {
            self.isDictionary = true
            self.isArray = false
            var children: [EntitlementNode] = []
            for k in dict.keys.sorted() {
                let child = EntitlementNode(key: k, value: dict[k])
                child.parent = self
                children.append(child)
            }
            self.children = children
        } else if let array = value as? [Any] {
            self.isDictionary = false
            self.isArray = true
            var children: [EntitlementNode] = []
            for (index, element) in array.enumerated() {
                let child = EntitlementNode(key: "[\(index)]", value: element)
                child.parent = self
                children.append(child)
            }
            self.children = children
        } else {
            self.isDictionary = false
            self.isArray = false
            self.children = []
        }
    }

    func rebuildChildren() {
        var newChildren: [EntitlementNode] = []
        if let dict = value as? [String: Any] {
            for k in dict.keys.sorted() {
                let child = EntitlementNode(key: k, value: dict[k])
                child.parent = self
                newChildren.append(child)
            }
        } else if let array = value as? [Any] {
            for (index, element) in array.enumerated() {
                let child = EntitlementNode(key: "[\(index)]", value: element)
                child.parent = self
                newChildren.append(child)
            }
        }
        children = newChildren
    }
}

private enum EntitlementValueType: Int, CaseIterable {
    case string
    case boolean
    case number
    case dictionary
    case array
    case data
    case date

    var name: String {
        switch self {
        case .string: return "String"
        case .boolean: return "Boolean"
        case .number: return "Number"
        case .dictionary: return "Dictionary"
        case .array: return "Array"
        case .data: return "Data"
        case .date: return "Date"
        }
    }

    static func from(_ value: Any?) -> EntitlementValueType {
        guard let v = value else { return .string }
        if v is Bool { return .boolean }
        if v is Int || v is Double || v is Float { return .number }
        if v is [String: Any] { return .dictionary }
        if v is [Any] { return .array }
        if v is Data { return .data }
        if v is Date { return .date }
        return .string
    }
}

public class EntitlementsTreeViewController: UIViewController, RATreeViewDataSource, RATreeViewDelegate {
    private var treeView: RATreeView!
    private let appInfo: TrollStoreAppInfo
    private let binaryPath: String
    private var entitlements: [String: Any] = [:]
    private var rootNodes: [EntitlementNode] = []

    public init(appInfo: TrollStoreAppInfo, binaryPath: String) {
        self.appInfo = appInfo
        self.binaryPath = binaryPath
        super.init(nibName: nil, bundle: nil)
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    public override func viewDidLoad() {
        super.viewDidLoad()
        title = NSLocalizedString("Edit_Entitlements", comment: "")
        view.backgroundColor = .systemGroupedBackground
        navigationItem.rightBarButtonItems = [
            UIBarButtonItem(barButtonSystemItem: .save, target: self, action: #selector(saveTapped)),
            UIBarButtonItem(barButtonSystemItem: .add, target: self, action: #selector(addTapped))
        ]

        treeView = RATreeView(frame: view.bounds)
        treeView.translatesAutoresizingMaskIntoConstraints = false
        treeView.dataSource = self
        treeView.delegate = self
        treeView.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        treeView.register(UITableViewCell.self, forCellReuseIdentifier: "Cell")
        view.addSubview(treeView)

        NSLayoutConstraint.activate([
            treeView.topAnchor.constraint(equalTo: view.topAnchor),
            treeView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            treeView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            treeView.bottomAnchor.constraint(equalTo: view.bottomAnchor)
        ])

        loadEntitlements()
    }

    private func loadEntitlements() {
        DispatchQueue.global(qos: .userInitiated).async { [weak self] in
            guard let self = self else { return }
            let ent = (try? InstallationManager.dumpEntitlements(binaryPath: self.binaryPath)) ?? [:]
            DispatchQueue.main.async {
                self.entitlements = ent
                self.rebuildRootNodes()
                self.treeView.reloadData()
            }
        }
    }

    private func rebuildRootNodes() {
        var nodes: [EntitlementNode] = []
        for key in entitlements.keys.sorted() {
            nodes.append(EntitlementNode(key: key, value: entitlements[key]))
        }
        rootNodes = nodes
    }

    @objc private func saveTapped() {
        do {
            try InstallationManager.setEntitlements(binaryPath: binaryPath, entitlements: entitlements)
            let alert = UIAlertController(title: NSLocalizedString("Success", comment: ""), message: NSLocalizedString("Entitlements_Saved", comment: ""), preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: NSLocalizedString("Close", comment: ""), style: .default) { [weak self] _ in
                self?.navigationController?.popViewController(animated: true)
            })
            present(alert, animated: true)
        } catch {
            ErrorHandler.showError(error, on: self)
        }
    }

    @objc private func addTapped() {
        let typeAlert = UIAlertController(title: NSLocalizedString("Add_Key", comment: ""), message: NSLocalizedString("Select_Type", comment: ""), preferredStyle: .actionSheet)
        for type in EntitlementValueType.allCases {
            typeAlert.addAction(UIAlertAction(title: type.name, style: .default) { [weak self] _ in
                self?.promptForKey(type: type)
            })
        }
        typeAlert.addAction(UIAlertAction(title: NSLocalizedString("Cancel", comment: ""), style: .cancel))
        if let popover = typeAlert.popoverPresentationController {
            popover.barButtonItem = navigationItem.rightBarButtonItems?.first
        }
        present(typeAlert, animated: true)
    }

    private func promptForKey(type: EntitlementValueType) {
        let alert = UIAlertController(title: NSLocalizedString("Add_Key", comment: ""), message: nil, preferredStyle: .alert)
        alert.addTextField { tf in
            tf.placeholder = "Key"
        }
        alert.addAction(UIAlertAction(title: NSLocalizedString("Cancel", comment: ""), style: .cancel))
        alert.addAction(UIAlertAction(title: NSLocalizedString("Add", comment: ""), style: .default) { [weak self] _ in
            guard let self = self else { return }
            guard let key = alert.textFields?.first?.text, !key.isEmpty else { return }
            let defaultValue = self.defaultValueForType(type)
            self.entitlements[key] = defaultValue
            self.rebuildRootNodes()
            self.treeView.reloadData()
        })
        present(alert, animated: true)
    }

    private func defaultValueForType(_ type: EntitlementValueType) -> Any {
        switch type {
        case .string: return ""
        case .boolean: return true
        case .number: return 0
        case .dictionary: return [String: Any]()
        case .array: return [Any]()
        case .data: return Data()
        case .date: return Date()
        }
    }

    private func parentDictionary(for node: EntitlementNode) -> NSMutableDictionary? {
        guard let parent = node.parent else { return entitlements as NSMutableDictionary }
        if let dict = parent.value as? [String: Any] {
            return dict as NSMutableDictionary
        }
        return nil
    }

    private func editNodeValue(_ node: EntitlementNode) {
        let type = EntitlementValueType.from(node.value)
        switch type {
        case .boolean:
            node.value = !((node.value as? Bool) ?? false)
            applyNodeChange(node)
        case .string:
            promptString(node: node)
        case .number:
            promptNumber(node: node)
        case .dictionary, .array:
            return
        case .data:
            return
        case .date:
            promptDate(node: node)
        }
    }

    private func promptString(node: EntitlementNode) {
        let alert = UIAlertController(title: node.key, message: nil, preferredStyle: .alert)
        alert.addTextField { tf in
            tf.text = node.value as? String
        }
        alert.addAction(UIAlertAction(title: NSLocalizedString("Cancel", comment: ""), style: .cancel))
        alert.addAction(UIAlertAction(title: NSLocalizedString("Save", comment: ""), style: .default) { [weak self] _ in
            guard let self = self else { return }
            node.value = alert.textFields?.first?.text ?? ""
            self.applyNodeChange(node)
        })
        present(alert, animated: true)
    }

    private func promptNumber(node: EntitlementNode) {
        let alert = UIAlertController(title: node.key, message: nil, preferredStyle: .alert)
        alert.addTextField { tf in
            tf.keyboardType = .numbersAndPunctuation
            tf.text = "\(node.value ?? 0)"
        }
        alert.addAction(UIAlertAction(title: NSLocalizedString("Cancel", comment: ""), style: .cancel))
        alert.addAction(UIAlertAction(title: NSLocalizedString("Save", comment: ""), style: .default) { [weak self] _ in
            guard let self = self else { return }
            let text = alert.textFields?.first?.text ?? "0"
            if let intVal = Int(text) {
                node.value = intVal
            } else if let doubleVal = Double(text) {
                node.value = doubleVal
            } else {
                node.value = 0
            }
            self.applyNodeChange(node)
        })
        present(alert, animated: true)
    }

    private func promptDate(node: EntitlementNode) {
        let alert = UIAlertController(title: node.key, message: nil, preferredStyle: .alert)
        alert.addTextField { tf in
            tf.text = "\(node.value ?? Date())"
        }
        alert.addAction(UIAlertAction(title: NSLocalizedString("Cancel", comment: ""), style: .cancel))
        alert.addAction(UIAlertAction(title: NSLocalizedString("Save", comment: ""), style: .default) { [weak self] _ in
            guard let self = self else { return }
            node.value = Date()
            self.applyNodeChange(node)
        })
        present(alert, animated: true)
    }

    private func applyNodeChange(_ node: EntitlementNode) {
        if let parent = node.parent {
            if let dict = parent.value as? [String: Any] {
                var mutable = dict
                mutable[node.key] = node.value
                parent.value = mutable
                parent.rebuildChildren()
            } else if let array = parent.value as? [Any] {
                var mutable = array
                if let index = Int(node.key.replacingOccurrences(of: "[", with: "").replacingOccurrences(of: "]", with: "")), index < mutable.count {
                    mutable[index] = node.value ?? ""
                    parent.value = mutable
                    parent.rebuildChildren()
                }
            }
        } else {
            entitlements[node.key] = node.value
            rebuildRootNodes()
        }
        treeView.reloadData()
    }

    private func deleteNode(_ node: EntitlementNode) {
        if let parent = node.parent {
            if let dict = parent.value as? [String: Any] {
                var mutable = dict
                mutable.removeValue(forKey: node.key)
                parent.value = mutable
                parent.rebuildChildren()
            } else if let array = parent.value as? [Any] {
                var mutable = array
                if let index = Int(node.key.replacingOccurrences(of: "[", with: "").replacingOccurrences(of: "]", with: "")), index < mutable.count {
                    mutable.remove(at: index)
                    parent.value = mutable
                    parent.rebuildChildren()
                }
            }
        } else {
            entitlements.removeValue(forKey: node.key)
            rebuildRootNodes()
        }
        treeView.reloadData()
    }

    public func treeView(_ treeView: RATreeView, numberOfChildrenOfItem item: Any?) -> Int {
        if let node = item as? EntitlementNode {
            return node.children.count
        }
        return rootNodes.count
    }

    public func treeView(_ treeView: RATreeView, child index: Int, ofItem item: Any?) -> Any {
        if let node = item as? EntitlementNode {
            return node.children[index]
        }
        return rootNodes[index]
    }

    public func treeView(_ treeView: RATreeView, isItemExpandable item: Any) -> Bool {
        if let node = item as? EntitlementNode {
            return node.isDictionary || node.isArray
        }
        return false
    }

    public func treeView(_ treeView: RATreeView, cellForItem item: Any) -> UITableViewCell {
        let cell = treeView.dequeueReusableCell(withIdentifier: "Cell") ?? UITableViewCell(style: .subtitle, reuseIdentifier: "Cell")
        if let node = item as? EntitlementNode {
            cell.textLabel?.text = node.key
            if node.isDictionary {
                cell.detailTextLabel?.text = "[Dictionary]"
            } else if node.isArray {
                cell.detailTextLabel?.text = "[Array]"
            } else if let v = node.value {
                if let b = v as? Bool {
                    cell.detailTextLabel?.text = b ? "true" : "false"
                } else {
                    cell.detailTextLabel?.text = "\(v)"
                }
            } else {
                cell.detailTextLabel?.text = ""
            }
        }
        return cell
    }

    public func treeView(_ treeView: RATreeView, heightForRowForItem item: Any) -> CGFloat {
        return 50
    }

    public func treeView(_ treeView: RATreeView, didSelectRowForItem item: Any) {
        guard let node = item as? EntitlementNode else { return }
        if node.isDictionary || node.isArray {
            return
        }
        editNodeValue(node)
    }

    public func treeView(_ treeView: RATreeView, commitEditingStyle editingStyle: UITableViewCell.EditingStyle, forRowForItem item: Any) {
        guard editingStyle == .delete else { return }
        guard let node = item as? EntitlementNode else { return }
        deleteNode(node)
    }
}