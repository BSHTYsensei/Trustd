import UIKit

@main
class TrollStoreApp: UIResponder, UIApplicationDelegate {
    var window: UIWindow?

    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        window = UIWindow(frame: UIScreen.main.bounds)
        window?.rootViewController = MainTabBarController()
        window?.makeKeyAndVisible()
        return true
    }

    func application(_ app: UIApplication, open url: URL, options: [UIApplication.OpenURLOptionsKey: Any] = [:]) -> Bool {
        guard let components = URLComponents(url: url, resolvingAgainstBaseURL: false) else { return false }
        if components.host == "install" {
            if let urlParam = components.queryItems?.first(where: { $0.name == "url" })?.value {
                NotificationCenter.default.post(name: NSNotification.Name("TrollStoreRemoteInstall"), object: urlParam)
            }
        } else if components.host == "enable-jit" {
            if let bundleId = components.queryItems?.first(where: { $0.name == "bundle-id" })?.value {
                NotificationCenter.default.post(name: NSNotification.Name("TrollStoreEnableJIT"), object: bundleId)
            }
        }
        return true
    }
}
