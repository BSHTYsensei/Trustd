import UIKit
import SwiftUI
import Foundation
import Darwin
import UniformTypeIdentifiers

// MARK: - CodeSigningInstaller.swift


@_silgen_name("archive_read_new")
func archive_read_new() -> OpaquePointer?
@_silgen_name("archive_read_support_format_all")
func archive_read_support_format_all(_ a: OpaquePointer?) -> Int32
@_silgen_name("archive_read_support_filter_all")
func archive_read_support_filter_all(_ a: OpaquePointer?) -> Int32
@_silgen_name("archive_read_open_filename")
func archive_read_open_filename(_ a: OpaquePointer?, _ filename: UnsafePointer<CChar>?, _ block_size: Int) -> Int32
@_silgen_name("archive_read_next_header")
func archive_read_next_header(_ a: OpaquePointer?, _ entry: UnsafeMutablePointer<OpaquePointer?>?) -> Int32
@_silgen_name("archive_entry_pathname")
func archive_entry_pathname(_ entry: OpaquePointer?) -> UnsafePointer<CChar>?
@_silgen_name("archive_entry_size")
func archive_entry_size(_ entry: OpaquePointer?) -> Int64
@_silgen_name("archive_read_data")
func archive_read_data(_ a: OpaquePointer?, _ buff: UnsafeMutableRawPointer?, _ size: Int) -> Int
@_silgen_name("archive_read_close")
func archive_read_close(_ a: OpaquePointer?) -> Int32
@_silgen_name("archive_read_free")
func archive_read_free(_ a: OpaquePointer?) -> Int32

enum TrollStorePaths {
    static let rootPath = "/var/containers/Bundle/TrollStore"
    static let applicationsPath = "/var/containers/Bundle/TrollStore/Applications"
    static let activeMarker = ".TrollStore"
    static let inactiveMarker = ".TrollStoreInactive"
    static let ldidName = "ldid"
    static let helperName = "trollstorehelper"
    static let trollHelperName = "TrollHelper"
    static let extraEntitlementsName = "entitlements.plist"
}

enum NativeBinary {
    case ldid
    case trollstorehelper
    case trollHelper

    var resourceName: String {
        switch self {
        case .ldid: return TrollStorePaths.ldidName
        case .trollstorehelper: return TrollStorePaths.helperName
        case .trollHelper: return TrollStorePaths.trollHelperName
        }
    }
}

enum NativeBinaryManager {
    private static let lock = NSLock()

    static func path(for binary: NativeBinary) -> String {
        let name = binary.resourceName
        if let path = Bundle.main.path(forResource: name, ofType: nil) {
            return path
        }
        return (Bundle.main.bundlePath as NSString).appendingPathComponent(name)
    }

    static func exists(_ binary: NativeBinary) -> Bool {
        FileManager.default.isExecutableFile(atPath: path(for: binary))
    }

    static func prepare(_ binary: NativeBinary) throws -> String {
        lock.lock()
        defer { lock.unlock() }

        let path = path(for: binary)
        guard FileManager.default.fileExists(atPath: path) else {
            throw TrollStoreInstallError(code: -2)
        }

        var statInfo = stat()
        guard stat(path, &statInfo) == 0 else {
            throw TrollStoreInstallError(code: -2)
        }

        let mode = statInfo.st_mode & 0o777
        if mode & 0o111 == 0 {
            guard chmod(path, 0o755) == 0 else {
                throw TrollStoreInstallError(code: -2)
            }
        }
        return path
    }

    static func ldidPath() throws -> String {
        try prepare(.ldid)
    }

    static func helperPath() throws -> String {
        try prepare(.trollstorehelper)
    }

    static func trollHelperPath() throws -> String {
        try prepare(.trollHelper)
    }
}

enum TrollStoreCommands {
    static let install = "install"
    static let uninstall = "uninstall"
    static let refresh = "refresh"
    static let refreshAll = "refresh-all"
    static let urlScheme = "url-scheme"
    static let respring = "respring"
    static let enableJIT = "enable-jit"
    static let modifyRegistration = "modify-registration"
    static let installTrollStore = "install-trollstore"
    static let uninstallTrollStore = "uninstall-trollstore"
    static let installPersistenceHelper = "install-persistence-helper"
}

enum TrollStoreDefaults {
    static let installationMethod = "installationMethod"
    static let uninstallationMethod = "uninstallationMethod"
    static let installAlertConfiguration = "installAlertConfiguration"
    static let autoInitLdid = "autoInitLdid"
    static let urlSchemeEnabled = "urlSchemeEnabled"
}

public struct TrollStoreInstallError: Error, LocalizedError {
    public let code: Int32
    public var errorDescription: String? {
        return TrollStoreInstallError.description(for: code)
    }
    public static func description(for code: Int32) -> String {
        switch code {
        case 166: return NSLocalizedString("Error_166", comment: "")
        case 167: return NSLocalizedString("Error_167", comment: "")
        case 168: return NSLocalizedString("Error_168", comment: "")
        case 169: return NSLocalizedString("Error_169", comment: "")
        case 170: return NSLocalizedString("Error_170", comment: "")
        case 171: return NSLocalizedString("Error_171", comment: "")
        case 172: return NSLocalizedString("Error_172", comment: "")
        case 173: return NSLocalizedString("Error_173", comment: "")
        case 174: return NSLocalizedString("Error_174", comment: "")
        case 175: return NSLocalizedString("Error_175", comment: "")
        case 176: return NSLocalizedString("Error_176", comment: "")
        case 177: return NSLocalizedString("Error_177", comment: "")
        case 178: return NSLocalizedString("Error_178", comment: "")
        case 179: return NSLocalizedString("Error_179", comment: "")
        case 180: return NSLocalizedString("Error_180", comment: "")
        case 181: return NSLocalizedString("Error_181", comment: "")
        case 182: return NSLocalizedString("Error_182", comment: "")
        case 183: return NSLocalizedString("Error_183", comment: "")
        case 184: return NSLocalizedString("Error_184", comment: "")
        case 185: return NSLocalizedString("Error_185", comment: "")
        default: return NSLocalizedString("Error_Unknown", comment: "")
        }
    }
}

public class RootHelper {
    private static let spawnLock = NSLock()
    public static func execute(args: [String]) throws -> Int32 {
        let helperPath = try NativeBinaryManager.helperPath()
        return try runProcess(helperPath, args, captureOutput: false).0
    }
    public static func executeCapturingOutput(args: [String]) throws -> (Int32, Data) {
        let helperPath = try NativeBinaryManager.helperPath()
        return try runProcess(helperPath, args, captureOutput: true)
    }
    public static func runProcess(_ executable: String, _ args: [String], workingDirectory: String? = nil, captureOutput: Bool) throws -> (Int32, Data) {
        spawnLock.lock()
        defer { spawnLock.unlock() }
        var argv: [UnsafeMutablePointer<CChar>?] = [strdup(executable)]
        argv.append(contentsOf: args.map { strdup($0) })
        argv.append(nil)
        defer {
            for ptr in argv {
                if let p = ptr { free(p) }
            }
        }
        var pipefd: [Int32] = [0, 0]
        var action: posix_spawn_file_actions_t? = nil
        _ = posix_spawn_file_actions_init(&action)
        defer { _ = posix_spawn_file_actions_destroy(&action) }
        var previousDirectory: String? = nil
        if let wd = workingDirectory {
            previousDirectory = FileManager.default.currentDirectoryPath
            _ = FileManager.default.changeCurrentDirectoryPath(wd)
        }
        if captureOutput {
            if pipe(&pipefd) != 0 {
                if let prev = previousDirectory { _ = FileManager.default.changeCurrentDirectoryPath(prev) }
                throw TrollStoreInstallError(code: -1)
            }
            _ = posix_spawn_file_actions_adddup2(&action, pipefd[1], 1)
            _ = posix_spawn_file_actions_addclose(&action, pipefd[0])
        }
        var pid: pid_t = 0
        let spawnResult = argv.withUnsafeMutableBufferPointer { buffer -> Int32 in
            return posix_spawn(&pid, executable, &action, nil, buffer.baseAddress, nil)
        }
        if let prev = previousDirectory {
            _ = FileManager.default.changeCurrentDirectoryPath(prev)
        }
        if captureOutput {
            _ = close(pipefd[1])
        }
        if spawnResult != 0 {
            if captureOutput { _ = close(pipefd[0]) }
            throw TrollStoreInstallError(code: spawnResult)
        }
        var data = Data()
        if captureOutput {
            var buffer = [UInt8](repeating: 0, count: 4096)
            while true {
                let bytesRead = read(pipefd[0], &buffer, buffer.count)
                if bytesRead <= 0 { break }
                data.append(buffer, count: bytesRead)
            }
            _ = close(pipefd[0])
        }
        var status: Int32 = 0
        _ = waitpid(pid, &status, 0)
        let exited = (status & 0x7f) == 0
        if !exited {
            throw TrollStoreInstallError(code: -1)
        }
        return (Int32((status >> 8) & 0xff), data)
    }
}

public class InstallationManager {
    private static var downloadObservations: [Int: NSKeyValueObservation] = [:]
    public static func parseIPA(path: String) -> [String: Any]? {
        let a = archive_read_new()
        _ = archive_read_support_format_all(a)
        _ = archive_read_support_filter_all(a)
        let openResult = path.withCString { cPath in
            archive_read_open_filename(a, cPath, 10240)
        }
        guard openResult == 0 else {
            _ = archive_read_free(a)
            return nil
        }
        var entry: OpaquePointer?
        defer {
            _ = archive_read_close(a)
            _ = archive_read_free(a)
        }
        while archive_read_next_header(a, &entry) == 0 {
            if let cName = archive_entry_pathname(entry) {
                let name = String(cString: cName)
                if name.hasSuffix(".app/Info.plist") && name.contains("Payload/") {
                    let size = archive_entry_size(entry)
                    if size > 0 {
                        var data = Data()
                        var remaining = Int(size)
                        let bufferSize = 8192
                        while remaining > 0 {
                            let chunkSize = min(bufferSize, remaining)
                            var chunk = [UInt8](repeating: 0, count: chunkSize)
                            let read = archive_read_data(a, &chunk, chunkSize)
                            if read <= 0 { break }
                            data.append(chunk, count: read)
                            remaining -= read
                        }
                        if remaining == 0 {
                            if let dict = try? PropertyListSerialization.propertyList(from: data, options: [], format: nil) as? [String: Any] {
                                return dict
                            }
                        }
                    }
                }
            }
        }
        return nil
    }
    public static func extractIcon(ipaPath: String, infoDict: [String: Any]) -> UIImage? {
        var iconName: String?
        if let icons = infoDict["CFBundleIcons"] as? [String: Any],
           let primary = icons["CFBundlePrimaryIcon"] as? [String: Any] {
            if let files = primary["CFBundleIconFiles"] as? [String], let last = files.last {
                iconName = last
            }
        }
        guard let baseName = iconName else { return nil }
        let a = archive_read_new()
        _ = archive_read_support_format_all(a)
        _ = archive_read_support_filter_all(a)
        let openResult = ipaPath.withCString { cPath in
            archive_read_open_filename(a, cPath, 10240)
        }
        guard openResult == 0 else {
            _ = archive_read_free(a)
            return nil
        }
        var entry: OpaquePointer?
        var bestMatch: String?
        var bestMatchSize: Int64 = 0
        defer {
            _ = archive_read_close(a)
            _ = archive_read_free(a)
        }
        while archive_read_next_header(a, &entry) == 0 {
            if let cName = archive_entry_pathname(entry) {
                let name = String(cString: cName)
                if name.contains("Payload/") && name.hasSuffix(".png") {
                    let fileName = (name as NSString).lastPathComponent
                    if fileName.hasPrefix(baseName) || fileName == baseName + ".png" || fileName.contains(baseName) {
                        let size = archive_entry_size(entry)
                        if size > bestMatchSize {
                            bestMatch = name
                            bestMatchSize = size
                        }
                    }
                }
            }
        }
        guard let match = bestMatch else { return nil }
        let a2 = archive_read_new()
        _ = archive_read_support_format_all(a2)
        _ = archive_read_support_filter_all(a2)
        let openResult2 = ipaPath.withCString { cPath in
            archive_read_open_filename(a2, cPath, 10240)
        }
        guard openResult2 == 0 else {
            _ = archive_read_free(a2)
            return nil
        }
        defer {
            _ = archive_read_close(a2)
            _ = archive_read_free(a2)
        }
        var entry2: OpaquePointer?
        while archive_read_next_header(a2, &entry2) == 0 {
            if let cName = archive_entry_pathname(entry2) {
                let name = String(cString: cName)
                if name == match {
                    let size = archive_entry_size(entry2)
                    if size > 0 {
                        var data = Data()
                        var remaining = Int(size)
                        let bufferSize = 8192
                        while remaining > 0 {
                            let chunkSize = min(bufferSize, remaining)
                            var chunk = [UInt8](repeating: 0, count: chunkSize)
                            let read = archive_read_data(a2, &chunk, chunkSize)
                            if read <= 0 { break }
                            data.append(chunk, count: read)
                            remaining -= read
                        }
                        if remaining == 0 {
                            return UIImage(data: data)
                        }
                    }
                }
            }
        }
        return nil
    }
    public static func downloadIPA(url: URL, progress: @escaping (Double) -> Void, completion: @escaping (String?, Error?) -> Void) {
        let task = URLSession.shared.downloadTask(with: url) { localURL, response, error in
            if let error = error {
                completion(nil, error)
                return
            }
            guard let localURL = localURL else {
                completion(nil, NSError(domain: "Download", code: -1))
                return
            }
            let tmpPath = NSTemporaryDirectory().appending(UUID().uuidString).appending(".ipa")
            do {
                try FileManager.default.moveItem(at: localURL, to: URL(fileURLWithPath: tmpPath))
                completion(tmpPath, nil)
            } catch {
                completion(nil, error)
            }
        }
        let observation = task.progress.observe(\.fractionCompleted) { p, _ in
            DispatchQueue.main.async { progress(p.fractionCompleted) }
        }
        downloadObservations[task.taskIdentifier] = observation
        task.resume()
    }
    public static func installIPA(path: String, force: Bool, useInstalldMethod: Bool, skipUICache: Bool, entitlements: [String: Any]? = nil) throws {
        if let entitlements = entitlements, !entitlements.isEmpty {
            let patchedIPA = try repackIPAWithEntitlements(ipaPath: path, entitlements: entitlements)
            defer { try? FileManager.default.removeItem(atPath: patchedIPA) }
            try runInstall(ipaPath: patchedIPA, force: force, useInstalldMethod: useInstalldMethod, skipUICache: skipUICache)
        } else {
            try runInstall(ipaPath: path, force: force, useInstalldMethod: useInstalldMethod, skipUICache: skipUICache)
        }
    }
    private static func runInstall(ipaPath: String, force: Bool, useInstalldMethod: Bool, skipUICache: Bool) throws {
        var args = [TrollStoreCommands.install]
        if useInstalldMethod { args.append("installd") }
        else { args.append("custom") }
        if force { args.append("force") }
        if skipUICache { args.append("skip-uicache") }
        args.append(ipaPath)
        let ret = try RootHelper.execute(args: args)
        if ret != 0 { throw TrollStoreInstallError(code: ret) }
    }
    private static func repackIPAWithEntitlements(ipaPath: String, entitlements: [String: Any]) throws -> String {
        let fm = FileManager.default
        let workDir = NSTemporaryDirectory().appending(UUID().uuidString)
        try fm.createDirectory(atPath: workDir, withIntermediateDirectories: true)
        let unzipRet = try RootHelper.runProcess("/usr/bin/unzip", ["-o", ipaPath, "-d", workDir], captureOutput: false).0
        if unzipRet != 0 {
            try? fm.removeItem(atPath: workDir)
            throw TrollStoreInstallError(code: 168)
        }
        let payloadPath = (workDir as NSString).appendingPathComponent("Payload")
        guard let payloadContents = try? fm.contentsOfDirectory(atPath: payloadPath) else {
            try? fm.removeItem(atPath: workDir)
            throw TrollStoreInstallError(code: 167)
        }
        guard let appName = payloadContents.first(where: { $0.hasSuffix(".app") }) else {
            try? fm.removeItem(atPath: workDir)
            throw TrollStoreInstallError(code: 167)
        }
        let appPath = (payloadPath as NSString).appendingPathComponent(appName)
        let infoPlistPath = (appPath as NSString).appendingPathComponent("Info.plist")
        guard let infoDict = NSDictionary(contentsOfFile: infoPlistPath) as? [String: Any],
              let executable = infoDict["CFBundleExecutable"] as? String else {
            try? fm.removeItem(atPath: workDir)
            throw TrollStoreInstallError(code: 176)
        }
        let binaryPath = (appPath as NSString).appendingPathComponent(executable)
        if !fm.fileExists(atPath: binaryPath) {
            try? fm.removeItem(atPath: workDir)
            throw TrollStoreInstallError(code: 174)
        }
        let entitlementsData = try PropertyListSerialization.data(fromPropertyList: entitlements, format: .xml, options: 0)
        let entitlementsPath = (workDir as NSString).appendingPathComponent("entitlements.plist")
        try entitlementsData.write(to: URL(fileURLWithPath: entitlementsPath))
        let ldidPath = LdidManager.ldidPath()
        let ldidRet = try RootHelper.runProcess(ldidPath, ["-S\(entitlementsPath)", binaryPath], captureOutput: false).0
        if ldidRet != 0 {
            try? fm.removeItem(atPath: workDir)
            throw TrollStoreInstallError(code: 175)
        }
        let repackedIPA = NSTemporaryDirectory().appending(UUID().uuidString).appending(".ipa")
        let zipRet = try RootHelper.runProcess("/usr/bin/zip", ["-qr", repackedIPA, "Payload"], workingDirectory: workDir, captureOutput: false).0
        try? fm.removeItem(atPath: workDir)
        if zipRet != 0 {
            throw TrollStoreInstallError(code: 168)
        }
        return repackedIPA
    }
    public static func uninstallApp(bundleId: String, useCustomMethod: Bool) throws {
        var args = [TrollStoreCommands.uninstall]
        if useCustomMethod { args.append("custom") }
        else { args.append("installd") }
        args.append(bundleId)
        let ret = try RootHelper.execute(args: args)
        if ret != 0 { throw TrollStoreInstallError(code: ret) }
    }
    public static func enableJIT(bundleId: String) throws {
        let ret = try RootHelper.execute(args: [TrollStoreCommands.enableJIT, bundleId])
        if ret != 0 { throw TrollStoreInstallError(code: ret) }
    }
    public static func changeRegistration(appPath: String, isSystem: Bool) throws {
        let registration = isSystem ? "System" : "User"
        let ret = try RootHelper.execute(args: [TrollStoreCommands.modifyRegistration, appPath, registration])
        if ret != 0 { throw TrollStoreInstallError(code: ret) }
    }
    public static func dumpEntitlements(binaryPath: String) throws -> [String: Any] {
        let ldidPath = LdidManager.ldidPath()
        let (ret, data) = try RootHelper.runProcess(ldidPath, ["-e", binaryPath], captureOutput: true)
        if ret != 0 { throw TrollStoreInstallError(code: 175) }
        if let dict = try? PropertyListSerialization.propertyList(from: data, options: [], format: nil) as? [String: Any] {
            return dict
        }
        return [:]
    }
    public static func setEntitlements(binaryPath: String, entitlements: [String: Any]) throws {
        let data = try PropertyListSerialization.data(fromPropertyList: entitlements, format: .xml, options: 0)
        let tmpPath = NSTemporaryDirectory().appending(UUID().uuidString).appending(".plist")
        try data.write(to: URL(fileURLWithPath: tmpPath))
        defer { try? FileManager.default.removeItem(atPath: tmpPath) }
        let ldidPath = LdidManager.ldidPath()
        let (ret, _) = try RootHelper.runProcess(ldidPath, ["-S\(tmpPath)", binaryPath], captureOutput: false)
        if ret != 0 { throw TrollStoreInstallError(code: 175) }
    }
}

// MARK: - AppManager.swift


public struct TrollStoreAppInfo {
    public let displayName: String
    public let bundleIdentifier: String
    public let appPath: String
    public let icon: UIImage?
    public let isSystemRegistered: Bool
    public let size: UInt64
    public let creationDate: Date
}

public class AppManager {
    private static let iconCache = NSCache<NSString, UIImage>()
    public static func getInstalledApps() -> [TrollStoreAppInfo] {
        var apps: [TrollStoreAppInfo] = []
        let fm = FileManager.default
        let appsRoot = TrollStorePaths.applicationsPath
        guard let containerDirs = try? fm.contentsOfDirectory(atPath: appsRoot) else { return apps }
        for containerDir in containerDirs {
            let containerPath = (appsRoot as NSString).appendingPathComponent(containerDir)
            var isDir: ObjCBool = false
            if fm.fileExists(atPath: containerPath, isDirectory: &isDir) && isDir.boolValue {
                if let appPath = findAppPath(in: containerPath) {
                    if let info = parseAppInfo(from: appPath, containerPath: containerPath) {
                        apps.append(info)
                    }
                }
            }
        }
        return apps
    }
    public static func openApp(bundleId: String) -> Bool {
        guard let cls = NSClassFromString("LSApplicationWorkspace") as? NSObject.Type else { return false }
        guard let workspace = cls.perform(NSSelectorFromString("defaultWorkspace"))?.takeUnretainedValue() as? NSObject else { return false }
        let selector = NSSelectorFromString("openApplicationWithBundleID:")
        guard workspace.responds(to: selector) else { return false }
        _ = workspace.perform(selector, with: bundleId)
        return true
    }
    private static func findAppPath(in containerPath: String) -> String? {
        let fm = FileManager.default
        guard let contents = try? fm.contentsOfDirectory(atPath: containerPath) else { return nil }
        for item in contents {
            if item.hasSuffix(".app") {
                let appPath = (containerPath as NSString).appendingPathComponent(item)
                var isDir: ObjCBool = false
                if fm.fileExists(atPath: appPath, isDirectory: &isDir) && isDir.boolValue {
                    return appPath
                }
            }
        }
        return nil
    }
    private static func parseAppInfo(from appPath: String, containerPath: String) -> TrollStoreAppInfo? {
        let fm = FileManager.default
        let infoPlistPath = (appPath as NSString).appendingPathComponent("Info.plist")
        guard let infoDict = NSDictionary(contentsOfFile: infoPlistPath) as? [String: Any] else { return nil }
        let displayName = (infoDict["CFBundleDisplayName"] as? String) ?? (infoDict["CFBundleName"] as? String) ?? ((appPath as NSString).lastPathComponent as NSString).deletingPathExtension
        let bundleId = (infoDict["CFBundleIdentifier"] as? String) ?? ""
        let icon = loadAppIcon(from: appPath, infoDict: infoDict, bundleId: bundleId)
        let isSystem = isSystemRegistered(containerPath: containerPath)
        let attributes = try? fm.attributesOfItem(atPath: appPath)
        let size = attributes?[.size] as? UInt64 ?? 0
        let creationDate = attributes?[.creationDate] as? Date ?? Date.distantPast
        return TrollStoreAppInfo(
            displayName: displayName,
            bundleIdentifier: bundleId,
            appPath: appPath,
            icon: icon,
            isSystemRegistered: isSystem,
            size: size,
            creationDate: creationDate
        )
    }
    private static func isSystemRegistered(containerPath: String) -> Bool {
        let marker = (containerPath as NSString).appendingPathComponent(TrollStorePaths.activeMarker)
        let inactive = (containerPath as NSString).appendingPathComponent(TrollStorePaths.inactiveMarker)
        let fm = FileManager.default
        if fm.fileExists(atPath: inactive) { return false }
        return fm.fileExists(atPath: marker)
    }
    private static func loadAppIcon(from appPath: String, infoDict: [String: Any], bundleId: String) -> UIImage? {
        let key = bundleId as NSString
        if let cached = iconCache.object(forKey: key) {
            return cached
        }
        var iconName: String?
        if let icons = infoDict["CFBundleIcons"] as? [String: Any],
           let primary = icons["CFBundlePrimaryIcon"] as? [String: Any] {
            if let name = primary["CFBundleIconName"] as? String {
                iconName = name
            } else if let files = primary["CFBundleIconFiles"] as? [String], let first = files.first, let last = files.last {
                iconName = first.commonPrefix(with: last)
            }
        }
        if iconName == nil, let icons = infoDict["CFBundleIcons~ipad"] as? [String: Any],
           let primary = icons["CFBundlePrimaryIcon"] as? [String: Any] {
            if let name = primary["CFBundleIconName"] as? String {
                iconName = name
            } else if let files = primary["CFBundleIconFiles"] as? [String], let first = files.first, let last = files.last {
                iconName = first.commonPrefix(with: last)
            }
        }
        guard let baseName = iconName else { return nil }
        let fm = FileManager.default
        guard let contents = try? fm.contentsOfDirectory(atPath: appPath) else { return nil }
        var candidates: [String] = []
        for item in contents {
            if item.hasPrefix(baseName) && (item.hasSuffix(".png") || (item as NSString).pathExtension.isEmpty) {
                candidates.append(item)
            }
        }
        candidates.sort()
        for candidate in candidates.reversed() {
            let fullPath = (appPath as NSString).appendingPathComponent(candidate)
            if let image = UIImage(contentsOfFile: fullPath) {
                iconCache.setObject(image, forKey: key)
                return image
            }
        }
        return nil
    }
}

// MARK: - AppListView.swift


public class AppListViewController: UIViewController {
    private let tableView = UITableView(frame: .zero, style: .insetGrouped)
    private let refreshControl = UIRefreshControl()
    private let searchController = UISearchController(searchResultsController: nil)
    private let dataSource = AppListDataSource()

    public override func viewDidLoad() {
        super.viewDidLoad()
        title = NSLocalizedString("Apps", comment: "")
        view.backgroundColor = .systemGroupedBackground
        navigationItem.largeTitleDisplayMode = .always
        setupTableView()
        setupNavigationBar()
        setupSearch()
        setupNotifications()
        loadApps()
    }

    public override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        loadApps()
    }

    private func setupTableView() {
        tableView.translatesAutoresizingMaskIntoConstraints = false
        tableView.dataSource = dataSource
        tableView.delegate = dataSource
        tableView.register(AppListCell.self, forCellReuseIdentifier: AppListCell.reuseIdentifier)
        tableView.estimatedRowHeight = 84
        tableView.rowHeight = UITableView.automaticDimension
        tableView.backgroundColor = .clear
        tableView.refreshControl = refreshControl
        refreshControl.addTarget(self, action: #selector(loadApps), for: .valueChanged)
        view.addSubview(tableView)
        NSLayoutConstraint.activate([
            tableView.topAnchor.constraint(equalTo: view.topAnchor),
            tableView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            tableView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            tableView.bottomAnchor.constraint(equalTo: view.bottomAnchor)
        ])
        dataSource.onReload = { [weak self] in
            self?.tableView.reloadData()
        }
        dataSource.onCellAction = { [weak self] action, appInfo in
            self?.handleCellAction(action, for: appInfo)
        }
        dataSource.onShowDetail = { [weak self] app in
            let detailVC = AppDetailViewController(appInfo: app)
            detailVC.onAction = { action in
                self?.handleCellAction(action, for: app)
            }
            self?.navigationController?.pushViewController(detailVC, animated: true)
        }
    }

    private func setupNavigationBar() {
        let appearance = UINavigationBarAppearance()
        appearance.configureWithTransparentBackground()
        appearance.backgroundEffect = UIBlurEffect(style: .systemUltraThinMaterial)
        appearance.backgroundColor = .clear
        appearance.shadowColor = .clear
        navigationController?.navigationBar.standardAppearance = appearance
        navigationController?.navigationBar.scrollEdgeAppearance = appearance
        navigationController?.navigationBar.compactAppearance = appearance
        let installAction = UIAction(title: NSLocalizedString("Install IPA File", comment: "")) { [weak self] _ in
            self?.installAppTapped()
        }
        let installMenu = UIMenu(children: [installAction])
        let installButton = UIBarButtonItem(image: UIImage(systemName: "plus"), menu: installMenu)
        let sortMenu = UIMenu(title: "", children: [
            UIAction(title: NSLocalizedString("Name Ascending", comment: "")) { [weak self] _ in self?.dataSource.sortApps(by: .nameAsc) },
            UIAction(title: NSLocalizedString("Name Descending", comment: "")) { [weak self] _ in self?.dataSource.sortApps(by: .nameDesc) },
            UIAction(title: NSLocalizedString("Install Date", comment: "")) { [weak self] _ in self?.dataSource.sortApps(by: .date) },
            UIAction(title: NSLocalizedString("Size", comment: "")) { [weak self] _ in self?.dataSource.sortApps(by: .size) }
        ])
        let sortButton = UIBarButtonItem(image: UIImage(systemName: "arrow.up.arrow.down"), menu: sortMenu)
        navigationItem.rightBarButtonItem = installButton
        navigationItem.leftBarButtonItem = sortButton
    }

    private func setupSearch() {
        searchController.searchResultsUpdater = dataSource
        searchController.obscuresBackgroundDuringPresentation = false
        searchController.searchBar.placeholder = NSLocalizedString("Search", comment: "")
        navigationItem.searchController = searchController
        definesPresentationContext = true
    }

    private func setupNotifications() {
        NotificationCenter.default.addObserver(self, selector: #selector(handleRemoteInstall(_:)), name: NSNotification.Name("TrollStoreRemoteInstall"), object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(handleEnableJIT(_:)), name: NSNotification.Name("TrollStoreEnableJIT"), object: nil)
    }

    @objc private func loadApps() {
        DispatchQueue.global(qos: .userInitiated).async { [weak self] in
            let apps = AppManager.getInstalledApps()
            DispatchQueue.main.async {
                self?.dataSource.allApps = apps
                self?.dataSource.applyFilterAndSort()
                self?.refreshControl.endRefreshing()
            }
        }
    }

    @objc private func installAppTapped() {
        let picker = UIDocumentPickerViewController(forOpeningContentTypes: [.item])
        picker.delegate = self
        picker.allowsMultipleSelection = false
        present(picker, animated: true)
    }

    @objc private func handleRemoteInstall(_ notification: Notification) {
        guard let urlString = notification.object as? String, let url = URL(string: urlString) else { return }
        InstallationProgressController.show(on: self, message: NSLocalizedString("Downloading", comment: ""))
        InstallationManager.downloadIPA(url: url, progress: { _ in }, completion: { [weak self] path, error in
            InstallationProgressController.hide()
            if let path = path {
                self?.installIPAFromFile(path: path, isRemote: true)
            } else if let error = error {
                ErrorHandler.showError(error, on: self)
            }
        })
    }

    @objc private func handleEnableJIT(_ notification: Notification) {
        guard let bundleId = notification.object as? String else { return }
        InstallationProgressController.show(on: self, message: NSLocalizedString("Enabling JIT", comment: ""))
        DispatchQueue.global(qos: .userInitiated).async { [weak self] in
            do {
                try InstallationManager.enableJIT(bundleId: bundleId)
                DispatchQueue.main.async {
                    InstallationProgressController.hide()
                    ErrorHandler.showSuccess(on: self, message: NSLocalizedString("JIT Enabled", comment: ""))
                }
            } catch {
                DispatchQueue.main.async {
                    InstallationProgressController.hide()
                    ErrorHandler.showError(error, on: self)
                }
            }
        }
    }

    private func handleCellAction(_ action: AppCellAction, for appInfo: TrollStoreAppInfo) {
        switch action {
        case .open:
            _ = AppManager.openApp(bundleId: appInfo.bundleIdentifier)
        case .uninstall:
            confirmUninstall(appInfo)
        case .enableJIT:
            enableJIT(appInfo)
        case .changeRegistration:
            changeRegistration(appInfo)
        case .editEntitlements:
            editEntitlements(appInfo)
        }
    }

    private func confirmUninstall(_ appInfo: TrollStoreAppInfo) {
        let alert = UIAlertController(
            title: NSLocalizedString("Uninstall App", comment: ""),
            message: String(format: NSLocalizedString("Are you sure you want to uninstall %@?", comment: ""), appInfo.displayName),
            preferredStyle: .alert
        )
        let cancelAction = UIAlertAction(title: NSLocalizedString("Cancel", comment: ""), style: .cancel)
        let uninstallAction = UIAlertAction(title: NSLocalizedString("Uninstall", comment: ""), style: .destructive) { [weak self] _ in
            self?.uninstallApp(appInfo)
        }
        alert.addAction(cancelAction)
        alert.addAction(uninstallAction)
        present(alert, animated: true)
    }

    private func uninstallApp(_ appInfo: TrollStoreAppInfo) {
        InstallationProgressController.show(on: self)
        let useCustom = UserDefaults.standard.integer(forKey: TrollStoreDefaults.uninstallationMethod) == 1
        DispatchQueue.global(qos: .userInitiated).async { [weak self] in
            do {
                try InstallationManager.uninstallApp(bundleId: appInfo.bundleIdentifier, useCustomMethod: useCustom)
                DispatchQueue.main.async {
                    InstallationProgressController.hide()
                    self?.loadApps()
                }
            } catch {
                DispatchQueue.main.async {
                    InstallationProgressController.hide()
                    ErrorHandler.showError(error, on: self)
                }
            }
        }
    }

    private func enableJIT(_ appInfo: TrollStoreAppInfo) {
        InstallationProgressController.show(on: self, message: NSLocalizedString("Enabling JIT", comment: ""))
        DispatchQueue.global(qos: .userInitiated).async { [weak self] in
            do {
                try InstallationManager.enableJIT(bundleId: appInfo.bundleIdentifier)
                DispatchQueue.main.async {
                    InstallationProgressController.hide()
                    ErrorHandler.showSuccess(on: self, message: NSLocalizedString("JIT Enabled", comment: ""))
                }
            } catch {
                DispatchQueue.main.async {
                    InstallationProgressController.hide()
                    ErrorHandler.showError(error, on: self)
                }
            }
        }
    }

    private func changeRegistration(_ appInfo: TrollStoreAppInfo) {
        let alert = UIAlertController(
            title: NSLocalizedString("Change Registration", comment: ""),
            message: nil,
            preferredStyle: .actionSheet
        )
        let systemAction = UIAlertAction(title: NSLocalizedString("System", comment: ""), style: .default) { [weak self] _ in
            self?.setRegistration(appInfo, isSystem: true)
        }
        let userAction = UIAlertAction(title: NSLocalizedString("User", comment: ""), style: .default) { [weak self] _ in
            self?.setRegistration(appInfo, isSystem: false)
        }
        let cancelAction = UIAlertAction(title: NSLocalizedString("Cancel", comment: ""), style: .cancel)
        alert.addAction(systemAction)
        alert.addAction(userAction)
        alert.addAction(cancelAction)
        if let popover = alert.popoverPresentationController {
            popover.sourceView = self.view
            popover.sourceRect = CGRect(x: self.view.bounds.midX, y: self.view.bounds.midY, width: 0, height: 0)
        }
        present(alert, animated: true)
    }

    private func setRegistration(_ appInfo: TrollStoreAppInfo, isSystem: Bool) {
        InstallationProgressController.show(on: self)
        DispatchQueue.global(qos: .userInitiated).async { [weak self] in
            do {
                try InstallationManager.changeRegistration(appPath: appInfo.appPath, isSystem: isSystem)
                DispatchQueue.main.async {
                    InstallationProgressController.hide()
                    self?.loadApps()
                }
            } catch {
                DispatchQueue.main.async {
                    InstallationProgressController.hide()
                    ErrorHandler.showError(error, on: self)
                }
            }
        }
    }

    private func editEntitlements(_ appInfo: TrollStoreAppInfo) {
        let infoPlistPath = (appInfo.appPath as NSString).appendingPathComponent("Info.plist")
        guard let infoDict = NSDictionary(contentsOfFile: infoPlistPath) as? [String: Any],
              let executable = infoDict["CFBundleExecutable"] as? String else { return }
        let binaryPath = (appInfo.appPath as NSString).appendingPathComponent(executable)
        let editor = EntitlementsTreeViewController(appInfo: appInfo, binaryPath: binaryPath)
        navigationController?.pushViewController(editor, animated: true)
    }
}

extension AppListViewController: UIDocumentPickerDelegate {
    public func documentPicker(_ controller: UIDocumentPickerViewController, didPickDocumentsAt urls: [URL]) {
        guard let url = urls.first else { return }
        _ = url.startAccessingSecurityScopedResource()
        defer { url.stopAccessingSecurityScopedResource() }
        let tempPath = NSTemporaryDirectory().appending(UUID().uuidString).appending(".ipa")
        do {
            try FileManager.default.copyItem(at: url, to: URL(fileURLWithPath: tempPath))
            installIPAFromFile(path: tempPath, isRemote: false)
        } catch {
            ErrorHandler.showError(error, on: self)
        }
    }

    private func installIPAFromFile(path: String, isRemote: Bool) {
        let config = UserDefaults.standard.integer(forKey: TrollStoreDefaults.installAlertConfiguration)
        var shouldShowAlert = true
        if config == 2 { shouldShowAlert = false }
        else if config == 1 && !isRemote { shouldShowAlert = false }
        if shouldShowAlert {
            guard let infoDict = InstallationManager.parseIPA(path: path) else {
                ErrorHandler.showError(TrollStoreInstallError(code: 167), on: self)
                try? FileManager.default.removeItem(atPath: path)
                return
            }
            let name = (infoDict["CFBundleDisplayName"] as? String) ?? (infoDict["CFBundleName"] as? String) ?? NSLocalizedString("App", comment: "Fallback application name")
            let version = (infoDict["CFBundleShortVersionString"] as? String) ?? "1.0"
            let bundleId = (infoDict["CFBundleIdentifier"] as? String) ?? ""
            let size = (try? FileManager.default.attributesOfItem(atPath: path)[.size] as? UInt64) ?? 0
            let sizeStr = ByteCountFormatter.string(fromByteCount: Int64(size), countStyle: .file)
            let messageFormat = NSLocalizedString("Version: %@\nBundle ID: %@\nSize: %@", comment: "IPA installation confirmation details")
            let message = String(format: messageFormat, version, bundleId, sizeStr)
            let alert = UIAlertController(title: name, message: message, preferredStyle: .alert)
            let installAction = UIAlertAction(title: NSLocalizedString("Install", comment: ""), style: .default) { [weak self] _ in
                self?.performInstall(path: path)
            }
            let cancelAction = UIAlertAction(title: NSLocalizedString("Cancel", comment: ""), style: .cancel) { _ in
                try? FileManager.default.removeItem(atPath: path)
            }
            alert.addAction(installAction)
            alert.addAction(cancelAction)
            present(alert, animated: true)
        } else {
            performInstall(path: path)
        }
    }

    private func performInstall(path: String) {
        InstallationProgressController.show(on: self)
        let useInstalld = UserDefaults.standard.integer(forKey: TrollStoreDefaults.installationMethod) == 0
        DispatchQueue.global(qos: .userInitiated).async { [weak self] in
            do {
                try InstallationManager.installIPA(path: path, force: false, useInstalldMethod: useInstalld, skipUICache: false)
                DispatchQueue.main.async {
                    InstallationProgressController.hide()
                    self?.loadApps()
                    try? FileManager.default.removeItem(atPath: path)
                }
            } catch let error as TrollStoreInstallError {
                DispatchQueue.main.async {
                    InstallationProgressController.hide()
                    if error.code == 171 {
                        self?.showForceInstallAlert(path: path, error: error)
                    } else {
                        ErrorHandler.showError(error, on: self)
                    }
                    try? FileManager.default.removeItem(atPath: path)
                }
            } catch {
                DispatchQueue.main.async {
                    InstallationProgressController.hide()
                    ErrorHandler.showError(error, on: self)
                    try? FileManager.default.removeItem(atPath: path)
                }
            }
        }
    }

    private func showForceInstallAlert(path: String, error: TrollStoreInstallError) {
        let alert = UIAlertController(
            title: NSLocalizedString("Install Error", comment: ""),
            message: error.errorDescription,
            preferredStyle: .alert
        )
        let closeAction = UIAlertAction(title: NSLocalizedString("Close", comment: ""), style: .cancel)
        let forceAction = UIAlertAction(title: NSLocalizedString("Force Install", comment: ""), style: .destructive) { [weak self] _ in
            self?.forceInstallIPA(path: path)
        }
        alert.addAction(closeAction)
        alert.addAction(forceAction)
        present(alert, animated: true)
    }

    private func forceInstallIPA(path: String) {
        InstallationProgressController.show(on: self)
        let useInstalld = UserDefaults.standard.integer(forKey: TrollStoreDefaults.installationMethod) == 0
        DispatchQueue.global(qos: .userInitiated).async { [weak self] in
            do {
                try InstallationManager.installIPA(path: path, force: true, useInstalldMethod: useInstalld, skipUICache: false)
                DispatchQueue.main.async {
                    InstallationProgressController.hide()
                    self?.loadApps()
                    try? FileManager.default.removeItem(atPath: path)
                }
            } catch {
                DispatchQueue.main.async {
                    InstallationProgressController.hide()
                    ErrorHandler.showError(error, on: self)
                    try? FileManager.default.removeItem(atPath: path)
                }
            }
        }
    }
}

public enum AppCellAction {
    case open
    case uninstall
    case enableJIT
    case changeRegistration
    case editEntitlements
}

private class AppListDataSource: NSObject, UITableViewDataSource, UITableViewDelegate, UISearchResultsUpdating {
    var allApps: [TrollStoreAppInfo] = []
    var filteredApps: [TrollStoreAppInfo] = []
    var searchText: String = ""
    var sortType: SortType = .nameAsc

    enum SortType {
        case nameAsc, nameDesc, date, size
    }

    var onReload: (() -> Void)?
    var onCellAction: ((AppCellAction, TrollStoreAppInfo) -> Void)?
    var onShowDetail: ((TrollStoreAppInfo) -> Void)?

    func updateSearchResults(for searchController: UISearchController) {
        searchText = searchController.searchBar.text ?? ""
        applyFilterAndSort()
    }

    func applyFilterAndSort() {
        if searchText.isEmpty {
            filteredApps = allApps
        } else {
            filteredApps = allApps.filter { $0.displayName.localizedCaseInsensitiveContains(searchText) || $0.bundleIdentifier.localizedCaseInsensitiveContains(searchText) }
        }
        switch sortType {
        case .nameAsc:
            filteredApps.sort { $0.displayName.localizedStandardCompare($1.displayName) == .orderedAscending }
        case .nameDesc:
            filteredApps.sort { $0.displayName.localizedStandardCompare($1.displayName) == .orderedDescending }
        case .date:
            filteredApps.sort { $0.creationDate > $1.creationDate }
        case .size:
            filteredApps.sort { $0.size > $1.size }
        }
        onReload?()
    }

    func sortApps(by type: SortType) {
        sortType = type
        applyFilterAndSort()
    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return filteredApps.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: AppListCell.reuseIdentifier, for: indexPath) as! AppListCell
        let app = filteredApps[indexPath.row]
        cell.configure(with: app)
        cell.onMoreActions = { [weak self, weak tableView] in
            self?.showActionsMenu(for: app, at: tableView, indexPath: indexPath)
        }
        return cell
    }

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        let app = filteredApps[indexPath.row]
        onShowDetail?(app)
    }

    func tableView(_ tableView: UITableView, contextMenuConfigurationForRowAt indexPath: IndexPath, point: CGPoint) -> UIContextMenuConfiguration? {
        let app = filteredApps[indexPath.row]
        return UIContextMenuConfiguration(identifier: nil, previewProvider: nil) { _ in
            let openAction = UIAction(title: NSLocalizedString("Open", comment: ""), image: UIImage(systemName: "play")) { [weak self] _ in
                self?.onCellAction?(.open, app)
            }
            let jitAction = UIAction(title: NSLocalizedString("Enable JIT", comment: ""), image: UIImage(systemName: "bolt")) { [weak self] _ in
                self?.onCellAction?(.enableJIT, app)
            }
            let registrationAction = UIAction(title: NSLocalizedString("Change Registration", comment: ""), image: UIImage(systemName: "arrow.triangle.2.circlepath")) { [weak self] _ in
                self?.onCellAction?(.changeRegistration, app)
            }
            let entitlementsAction = UIAction(title: NSLocalizedString("Edit Entitlements", comment: ""), image: UIImage(systemName: "doc.text")) { [weak self] _ in
                self?.onCellAction?(.editEntitlements, app)
            }
            let uninstallAction = UIAction(title: NSLocalizedString("Uninstall", comment: ""), image: UIImage(systemName: "trash"), attributes: .destructive) { [weak self] _ in
                self?.onCellAction?(.uninstall, app)
            }
            return UIMenu(title: "", children: [openAction, jitAction, registrationAction, entitlementsAction, uninstallAction])
        }
    }

    private func showActionsMenu(for app: TrollStoreAppInfo, at tableView: UITableView?, indexPath: IndexPath) {
        guard let tableView = tableView, let cell = tableView.cellForRow(at: indexPath) else { return }
        let alert = UIAlertController(title: nil, message: nil, preferredStyle: .actionSheet)
        let openAction = UIAlertAction(title: NSLocalizedString("Open", comment: ""), style: .default) { [weak self] _ in
            self?.onCellAction?(.open, app)
        }
        let jitAction = UIAlertAction(title: NSLocalizedString("Enable JIT", comment: ""), style: .default) { [weak self] _ in
            self?.onCellAction?(.enableJIT, app)
        }
        let registrationAction = UIAlertAction(title: NSLocalizedString("Change Registration", comment: ""), style: .default) { [weak self] _ in
            self?.onCellAction?(.changeRegistration, app)
        }
        let entitlementsAction = UIAlertAction(title: NSLocalizedString("Edit Entitlements", comment: ""), style: .default) { [weak self] _ in
            self?.onCellAction?(.editEntitlements, app)
        }
        let uninstallAction = UIAlertAction(title: NSLocalizedString("Uninstall", comment: ""), style: .destructive) { [weak self] _ in
            self?.onCellAction?(.uninstall, app)
        }
        let cancelAction = UIAlertAction(title: NSLocalizedString("Cancel", comment: ""), style: .cancel)
        alert.addAction(openAction)
        alert.addAction(jitAction)
        alert.addAction(registrationAction)
        alert.addAction(entitlementsAction)
        alert.addAction(uninstallAction)
        alert.addAction(cancelAction)
        if let popover = alert.popoverPresentationController {
            popover.sourceView = cell
            popover.sourceRect = cell.bounds
        }
        tableView.window?.rootViewController?.present(alert, animated: true)
    }
}

private class AppListCell: UITableViewCell {
    static let reuseIdentifier = "AppListCell"
    private let iconImageView = UIImageView()
    private let nameLabel = UILabel()
    private let bundleIdLabel = UILabel()
    private let registrationBadge = UILabel()
    private let moreButton = UIButton(type: .system)
    var onMoreActions: (() -> Void)?

    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        setupUI()
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    private func setupUI() {
        backgroundColor = .clear
        contentView.backgroundColor = .clear
        let blurEffect = UIBlurEffect(style: .systemUltraThinMaterial)
        let bgView = UIVisualEffectView(effect: blurEffect)
        bgView.layer.cornerRadius = 14
        bgView.layer.cornerCurve = .continuous
        bgView.clipsToBounds = true
        bgView.layer.borderWidth = 0.5
        bgView.layer.borderColor = UIColor.white.withAlphaComponent(0.18).cgColor
        backgroundView = bgView

        let selBgView = UIVisualEffectView(effect: UIBlurEffect(style: .systemThinMaterial))
        selBgView.layer.cornerRadius = 14
        selBgView.layer.cornerCurve = .continuous
        selBgView.clipsToBounds = true
        selectedBackgroundView = selBgView

        iconImageView.translatesAutoresizingMaskIntoConstraints = false
        iconImageView.contentMode = .scaleAspectFill
        iconImageView.layer.cornerRadius = 12
        iconImageView.layer.cornerCurve = .continuous
        iconImageView.layer.masksToBounds = true
        iconImageView.tintColor = .label
        contentView.addSubview(iconImageView)

        nameLabel.translatesAutoresizingMaskIntoConstraints = false
        nameLabel.font = .systemFont(ofSize: 17, weight: .semibold)
        nameLabel.textColor = .label
        contentView.addSubview(nameLabel)

        bundleIdLabel.translatesAutoresizingMaskIntoConstraints = false
        bundleIdLabel.font = .systemFont(ofSize: 13)
        bundleIdLabel.textColor = .secondaryLabel
        contentView.addSubview(bundleIdLabel)

        registrationBadge.translatesAutoresizingMaskIntoConstraints = false
        registrationBadge.font = .systemFont(ofSize: 11, weight: .semibold)
        registrationBadge.textAlignment = .center
        registrationBadge.layer.cornerRadius = 4
        registrationBadge.layer.cornerCurve = .continuous
        registrationBadge.layer.masksToBounds = true
        contentView.addSubview(registrationBadge)

        moreButton.translatesAutoresizingMaskIntoConstraints = false
        let configuration = UIImage.SymbolConfiguration(pointSize: 18, weight: .medium)
        moreButton.setImage(UIImage(systemName: "ellipsis", withConfiguration: configuration), for: .normal)
        moreButton.tintColor = .systemBlue
        moreButton.addTarget(self, action: #selector(moreButtonTapped), for: .touchUpInside)
        contentView.addSubview(moreButton)

        NSLayoutConstraint.activate([
            iconImageView.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 20),
            iconImageView.centerYAnchor.constraint(equalTo: contentView.centerYAnchor),
            iconImageView.widthAnchor.constraint(equalToConstant: 50),
            iconImageView.heightAnchor.constraint(equalToConstant: 50),
            nameLabel.leadingAnchor.constraint(equalTo: iconImageView.trailingAnchor, constant: 16),
            nameLabel.topAnchor.constraint(equalTo: contentView.topAnchor, constant: 12),
            nameLabel.trailingAnchor.constraint(lessThanOrEqualTo: moreButton.leadingAnchor, constant: -12),
            bundleIdLabel.leadingAnchor.constraint(equalTo: nameLabel.leadingAnchor),
            bundleIdLabel.topAnchor.constraint(equalTo: nameLabel.bottomAnchor, constant: 2),
            bundleIdLabel.trailingAnchor.constraint(equalTo: nameLabel.trailingAnchor),
            registrationBadge.leadingAnchor.constraint(equalTo: nameLabel.leadingAnchor),
            registrationBadge.topAnchor.constraint(equalTo: bundleIdLabel.bottomAnchor, constant: 4),
            registrationBadge.bottomAnchor.constraint(equalTo: contentView.bottomAnchor, constant: -12),
            registrationBadge.widthAnchor.constraint(greaterThanOrEqualToConstant: 44),
            registrationBadge.heightAnchor.constraint(equalToConstant: 16),
            moreButton.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -16),
            moreButton.centerYAnchor.constraint(equalTo: contentView.centerYAnchor),
            moreButton.widthAnchor.constraint(equalToConstant: 36),
            moreButton.heightAnchor.constraint(equalToConstant: 36)
        ])
    }

    override func traitCollectionDidChange(_ previousTraitCollection: UITraitCollection?) {
        super.traitCollectionDidChange(previousTraitCollection)
        if traitCollection.userInterfaceStyle == .dark {
            backgroundView?.layer.borderColor = UIColor.white.withAlphaComponent(0.08).cgColor
        } else {
            backgroundView?.layer.borderColor = UIColor.white.withAlphaComponent(0.18).cgColor
        }
    }

    func configure(with app: TrollStoreAppInfo) {
        iconImageView.image = app.icon ?? UIImage(systemName: "app")
        nameLabel.text = app.displayName
        bundleIdLabel.text = app.bundleIdentifier
        if app.isSystemRegistered {
            registrationBadge.text = NSLocalizedString("System", comment: "")
            registrationBadge.backgroundColor = .systemGreen
            registrationBadge.textColor = .white
        } else {
            registrationBadge.text = NSLocalizedString("User", comment: "")
            registrationBadge.backgroundColor = .systemGray
            registrationBadge.textColor = .white
        }
    }

    @objc private func moreButtonTapped() {
        onMoreActions?()
    }
}

class AppDetailViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    private let appInfo: TrollStoreAppInfo
    private let tableView = UITableView(frame: .zero, style: .insetGrouped)
    private var entitlements: [String: Any] = [:]
    var onAction: ((AppCellAction) -> Void)?

    init(appInfo: TrollStoreAppInfo) {
        self.appInfo = appInfo
        super.init(nibName: nil, bundle: nil)
    }

    required init?(coder: NSCoder) { fatalError() }

    override func viewDidLoad() {
        super.viewDidLoad()
        title = appInfo.displayName
        view.backgroundColor = .systemGroupedBackground
        tableView.dataSource = self
        tableView.delegate = self
        tableView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(tableView)
        NSLayoutConstraint.activate([
            tableView.topAnchor.constraint(equalTo: view.topAnchor),
            tableView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            tableView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            tableView.bottomAnchor.constraint(equalTo: view.bottomAnchor)
        ])
        let infoPlistPath = (appInfo.appPath as NSString).appendingPathComponent("Info.plist")
        if let infoDict = NSDictionary(contentsOfFile: infoPlistPath) as? [String: Any],
           let executable = infoDict["CFBundleExecutable"] as? String {
            let binaryPath = (appInfo.appPath as NSString).appendingPathComponent(executable)
            DispatchQueue.global(qos: .userInitiated).async { [weak self] in
                let ent = (try? InstallationManager.dumpEntitlements(binaryPath: binaryPath)) ?? [:]
                DispatchQueue.main.async {
                    self?.entitlements = ent
                    self?.tableView.reloadData()
                }
            }
        }
    }

    func numberOfSections(in tableView: UITableView) -> Int { return 4 }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if section == 0 { return 4 }
        if section == 1 { return 4 }
        if section == 2 { return entitlements.count }
        if section == 3 { return 1 }
        return 0
    }

    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        if section == 0 { return NSLocalizedString("Info", comment: "") }
        if section == 1 { return NSLocalizedString("Actions", comment: "") }
        if section == 2 { return NSLocalizedString("Entitlements", comment: "") }
        return nil
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell") ?? UITableViewCell(style: .value1, reuseIdentifier: "Cell")
        if indexPath.section == 0 {
            if indexPath.row == 0 {
                cell.textLabel?.text = NSLocalizedString("Bundle ID", comment: "")
                cell.detailTextLabel?.text = appInfo.bundleIdentifier
            } else if indexPath.row == 1 {
                cell.textLabel?.text = NSLocalizedString("Registration", comment: "")
                cell.detailTextLabel?.text = appInfo.isSystemRegistered ? NSLocalizedString("System", comment: "") : NSLocalizedString("User", comment: "")
            } else if indexPath.row == 2 {
                cell.textLabel?.text = NSLocalizedString("Path", comment: "")
                cell.detailTextLabel?.text = appInfo.appPath
            } else {
                cell.textLabel?.text = NSLocalizedString("Size", comment: "")
                cell.detailTextLabel?.text = ByteCountFormatter.string(fromByteCount: Int64(appInfo.size), countStyle: .file)
            }
            cell.selectionStyle = .none
            cell.textLabel?.textColor = .secondaryLabel
            cell.detailTextLabel?.textColor = .label
            return cell
        } else if indexPath.section == 1 {
            if indexPath.row == 0 {
                cell.textLabel?.text = NSLocalizedString("Open", comment: "")
                cell.textLabel?.textColor = .systemBlue
            } else if indexPath.row == 1 {
                cell.textLabel?.text = NSLocalizedString("Enable JIT", comment: "")
                cell.textLabel?.textColor = .systemBlue
            } else if indexPath.row == 2 {
                cell.textLabel?.text = NSLocalizedString("Change Registration", comment: "")
                cell.textLabel?.textColor = .systemBlue
            } else {
                cell.textLabel?.text = NSLocalizedString("Uninstall", comment: "")
                cell.textLabel?.textColor = .systemRed
            }
        } else if indexPath.section == 2 {
            let keys = entitlements.keys.sorted()
            let key = keys[indexPath.row]
            cell.textLabel?.text = key
            cell.detailTextLabel?.text = String(describing: entitlements[key] ?? "")
        } else if indexPath.section == 3 {
            cell.textLabel?.text = NSLocalizedString("Edit Entitlements", comment: "")
            cell.textLabel?.textColor = .systemBlue
        }
        return cell
    }

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        if indexPath.section == 1 {
            if indexPath.row == 0 { onAction?(.open) }
            else if indexPath.row == 1 { onAction?(.enableJIT) }
            else if indexPath.row == 2 { onAction?(.changeRegistration) }
            else if indexPath.row == 3 { onAction?(.uninstall) }
        } else if indexPath.section == 3 {
            onAction?(.editEntitlements)
        }
    }
}

public class InstallationProgressController {
    private static var overlayView: UIView?
    public static func show(on viewController: UIViewController, message: String? = nil) {
        guard overlayView == nil else { return }
        let overlay = UIView(frame: viewController.view.bounds)
        overlay.backgroundColor = UIColor.black.withAlphaComponent(0.4)
        overlay.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        let containerView = UIVisualEffectView(effect: UIBlurEffect(style: .systemThickMaterial))
        containerView.translatesAutoresizingMaskIntoConstraints = false
        containerView.layer.cornerRadius = 16
        containerView.layer.cornerCurve = .continuous
        containerView.clipsToBounds = true
        containerView.layer.borderWidth = 0.5
        containerView.layer.borderColor = UIColor.white.withAlphaComponent(0.18).cgColor
        overlay.addSubview(containerView)
        let indicator = UIActivityIndicatorView(style: .large)
        indicator.translatesAutoresizingMaskIntoConstraints = false
        indicator.startAnimating()
        containerView.contentView.addSubview(indicator)
        let label = UILabel()
        label.translatesAutoresizingMaskIntoConstraints = false
        label.font = .systemFont(ofSize: 16, weight: .medium)
        label.textColor = .label
        label.textAlignment = .center
        label.text = message ?? NSLocalizedString("Installing", comment: "")
        containerView.contentView.addSubview(label)
        NSLayoutConstraint.activate([
            containerView.centerXAnchor.constraint(equalTo: overlay.centerXAnchor),
            containerView.centerYAnchor.constraint(equalTo: overlay.centerYAnchor),
            containerView.widthAnchor.constraint(equalToConstant: 200),
            containerView.heightAnchor.constraint(equalToConstant: 120),
            indicator.centerXAnchor.constraint(equalTo: containerView.centerXAnchor),
            indicator.topAnchor.constraint(equalTo: containerView.topAnchor, constant: 20),
            label.leadingAnchor.constraint(equalTo: containerView.leadingAnchor, constant: 16),
            label.trailingAnchor.constraint(equalTo: containerView.trailingAnchor, constant: -16),
            label.topAnchor.constraint(equalTo: indicator.bottomAnchor, constant: 12)
        ])
        viewController.view.addSubview(overlay)
        overlayView = overlay
    }
    public static func hide() {
        overlayView?.removeFromSuperview()
        overlayView = nil
    }
}

public class ErrorHandler {
    public static func showError(_ error: Error, on viewController: UIViewController?) {
        let alert = UIAlertController(
            title: NSLocalizedString("Error", comment: ""),
            message: error.localizedDescription,
            preferredStyle: .alert
        )
        if let trollError = error as? TrollStoreInstallError {
            alert.title = String(format: NSLocalizedString("Error %d", comment: ""), trollError.code)
            let unknownError = NSLocalizedString("Unknown Error", comment: "")
            let copyLogAction = UIAlertAction(title: NSLocalizedString("Copy Debug Log", comment: ""), style: .default) { _ in
                UIPasteboard.general.string = "Error Code: " + String(trollError.code) + "\n " + (trollError.errorDescription ?? unknownError)
            }
            alert.addAction(copyLogAction)
        }
        let closeAction = UIAlertAction(title: NSLocalizedString("Close", comment: ""), style: .default)
        alert.addAction(closeAction)
        viewController?.present(alert, animated: true)
    }
    public static func showSuccess(on viewController: UIViewController?, message: String) {
        let alert = UIAlertController(
            title: NSLocalizedString("Success", comment: ""),
            message: message,
            preferredStyle: .alert
        )
        let closeAction = UIAlertAction(title: NSLocalizedString("Close", comment: ""), style: .default)
        alert.addAction(closeAction)
        viewController?.present(alert, animated: true)
    }
}

private class EntitlementNode: NSObject {
    var key: String
    var value: Any?
    var isDictionary: Bool
    var isArray: Bool
    var children: [EntitlementNode]
    weak var parent: EntitlementNode?
    init(key: String, value: Any?) {
        self.key = key
        self.value = value
        if value is [String: Any] {
            self.isDictionary = true
            self.isArray = false
        } else if value is [Any] {
            self.isDictionary = false
            self.isArray = true
        } else {
            self.isDictionary = false
            self.isArray = false
        }
        self.children = []
        super.init()
        if let dict = value as? [String: Any] {
            for k in dict.keys.sorted() {
                let child = EntitlementNode(key: k, value: dict[k])
                child.parent = self
                self.children.append(child)
            }
        } else if let array = value as? [Any] {
            for (index, element) in array.enumerated() {
                let childKey = "[" + String(index) + "]"
                let child = EntitlementNode(key: childKey, value: element)
                child.parent = self
                self.children.append(child)
            }
        }
    }
    func rebuildChildren() {
        var newChildren: [EntitlementNode] = []
        if let dict = value as? [String: Any] {
            for k in dict.keys.sorted() {
                let child = EntitlementNode(key: k, value: dict[k])
                child.parent = self
                newChildren.append(child)
            }
        } else if let array = value as? [Any] {
            for (index, element) in array.enumerated() {
                let childKey = "[" + String(index) + "]"
                let child = EntitlementNode(key: childKey, value: element)
                child.parent = self
                newChildren.append(child)
            }
        }
        children = newChildren
    }
}

private enum EntitlementValueType: Int, CaseIterable {
    case string, boolean, number, dictionary, array, data, date
    var name: String {
        switch self {
        case .string: return "String"
        case .boolean: return "Boolean"
        case .number: return "Number"
        case .dictionary: return "Dictionary"
        case .array: return "Array"
        case .data: return "Data"
        case .date: return "Date"
        }
    }
    static func from(_ value: Any?) -> EntitlementValueType {
        guard let v = value else { return .string }
        if v is Bool { return .boolean }
        if v is Int || v is Double || v is Float { return .number }
        if v is [String: Any] { return .dictionary }
        if v is [Any] { return .array }
        if v is Data { return .data }
        if v is Date { return .date }
        return .string
    }
}

public class EntitlementsTreeViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    private var treeView: UITableView!
    private let appInfo: TrollStoreAppInfo
    private let binaryPath: String
    private var entitlements: [String: Any] = [:]
    private var rootNodes: [EntitlementNode] = []
    private var visibleNodes: [(node: EntitlementNode, level: Int)] = []
    private var expandedNodes: Set<ObjectIdentifier> = []
    public init(appInfo: TrollStoreAppInfo, binaryPath: String) {
        self.appInfo = appInfo
        self.binaryPath = binaryPath
        super.init(nibName: nil, bundle: nil)
    }
    required init?(coder: NSCoder) { fatalError() }
    public override func viewDidLoad() {
        super.viewDidLoad()
        title = NSLocalizedString("Edit Entitlements", comment: "")
        view.backgroundColor = .systemGroupedBackground
        navigationItem.rightBarButtonItems = [
            UIBarButtonItem(barButtonSystemItem: .save, target: self, action: #selector(saveTapped)),
            UIBarButtonItem(barButtonSystemItem: .add, target: self, action: #selector(addTapped))
        ]
        treeView = UITableView(frame: view.bounds, style: .insetGrouped)
        treeView.translatesAutoresizingMaskIntoConstraints = false
        treeView.dataSource = self
        treeView.delegate = self
        treeView.register(UITableViewCell.self, forCellReuseIdentifier: "Cell")
        view.addSubview(treeView)
        NSLayoutConstraint.activate([
            treeView.topAnchor.constraint(equalTo: view.topAnchor),
            treeView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            treeView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            treeView.bottomAnchor.constraint(equalTo: view.bottomAnchor)
        ])
        loadEntitlements()
    }
    private func loadEntitlements() {
        DispatchQueue.global(qos: .userInitiated).async { [weak self] in
            guard let self = self else { return }
            let ent = (try? InstallationManager.dumpEntitlements(binaryPath: self.binaryPath)) ?? [:]
            DispatchQueue.main.async {
                self.entitlements = ent
                self.rebuildRootNodes()
                self.rebuildVisibleNodes()
                self.treeView.reloadData()
            }
        }
    }
    private func rebuildRootNodes() {
        var nodes: [EntitlementNode] = []
        for key in entitlements.keys.sorted() {
            nodes.append(EntitlementNode(key: key, value: entitlements[key]))
        }
        rootNodes = nodes
    }
    private func rebuildVisibleNodes() {
        visibleNodes.removeAll()
        for node in rootNodes {
            flattenNode(node, level: 0)
        }
    }
    private func flattenNode(_ node: EntitlementNode, level: Int) {
        visibleNodes.append((node, level))
        if expandedNodes.contains(ObjectIdentifier(node)) {
            for child in node.children {
                flattenNode(child, level: level + 1)
            }
        }
    }
    @objc private func saveTapped() {
        do {
            try InstallationManager.setEntitlements(binaryPath: binaryPath, entitlements: entitlements)
            let alert = UIAlertController(title: NSLocalizedString("Success", comment: ""), message: NSLocalizedString("Entitlements Saved", comment: ""), preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: NSLocalizedString("Close", comment: ""), style: .default) { [weak self] _ in
                self?.navigationController?.popViewController(animated: true)
            })
            present(alert, animated: true)
        } catch {
            ErrorHandler.showError(error, on: self)
        }
    }
    @objc private func addTapped() {
        let alert = UIAlertController(title: NSLocalizedString("Add Key", comment: ""), message: nil, preferredStyle: .alert)
        alert.addTextField { tf in tf.placeholder = NSLocalizedString("Key", comment: "Entitlement key input placeholder") }
        alert.addAction(UIAlertAction(title: NSLocalizedString("Cancel", comment: ""), style: .cancel))
        alert.addAction(UIAlertAction(title: NSLocalizedString("Add", comment: ""), style: .default) { [weak self] _ in
            guard let self = self else { return }
            guard let key = alert.textFields?.first?.text, !key.isEmpty else { return }
            self.entitlements[key] = ""
            self.rebuildRootNodes()
            self.rebuildVisibleNodes()
            self.treeView.reloadData()
        })
        present(alert, animated: true)
    }
    public func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return visibleNodes.count
    }
    public func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath)
        let item = visibleNodes[indexPath.row]
        cell.textLabel?.text = item.node.key
        cell.indentationLevel = item.level
        cell.indentationWidth = 20
        if item.node.isDictionary || item.node.isArray {
            cell.accessoryType = .disclosureIndicator
            cell.detailTextLabel?.text = item.node.isDictionary ? NSLocalizedString("[Dictionary]", comment: "Entitlements tree dictionary marker") : NSLocalizedString("[Array]", comment: "Entitlements tree array marker")
        } else {
            cell.accessoryType = .none
            if let v = item.node.value {
                if let b = v as? Bool { cell.detailTextLabel?.text = b ? NSLocalizedString("true", comment: "Boolean entitlement value") : NSLocalizedString("false", comment: "Boolean entitlement value") }
                else { cell.detailTextLabel?.text = String(describing: v) }
            } else {
                cell.detailTextLabel?.text = ""
            }
        }
        return cell
    }
    public func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        let item = visibleNodes[indexPath.row]
        if item.node.isDictionary || item.node.isArray {
            let id = ObjectIdentifier(item.node)
            if expandedNodes.contains(id) {
                expandedNodes.remove(id)
            } else {
                expandedNodes.insert(id)
            }
            rebuildVisibleNodes()
            treeView.reloadData()
        } else {
            editNodeValue(item.node)
        }
    }
    public func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            let item = visibleNodes[indexPath.row]
            deleteNode(item.node)
        }
    }
    private func editNodeValue(_ node: EntitlementNode) {
        let type = EntitlementValueType.from(node.value)
        switch type {
        case .boolean:
            node.value = !((node.value as? Bool) ?? false)
            applyNodeChange(node)
        case .string:
            promptString(node: node)
        case .number:
            promptNumber(node: node)
        default: break
        }
    }
    private func promptString(node: EntitlementNode) {
        let alert = UIAlertController(title: node.key, message: nil, preferredStyle: .alert)
        alert.addTextField { tf in tf.text = node.value as? String }
        alert.addAction(UIAlertAction(title: NSLocalizedString("Cancel", comment: ""), style: .cancel))
        alert.addAction(UIAlertAction(title: NSLocalizedString("Save", comment: ""), style: .default) { [weak self] _ in
            guard let self = self else { return }
            node.value = alert.textFields?.first?.text ?? ""
            self.applyNodeChange(node)
        })
        present(alert, animated: true)
    }
    private func promptNumber(node: EntitlementNode) {
        let alert = UIAlertController(title: node.key, message: nil, preferredStyle: .alert)
        alert.addTextField { tf in
            tf.keyboardType = .numbersAndPunctuation
            tf.text = String(describing: node.value ?? 0)
        }
        alert.addAction(UIAlertAction(title: NSLocalizedString("Cancel", comment: ""), style: .cancel))
        alert.addAction(UIAlertAction(title: NSLocalizedString("Save", comment: ""), style: .default) { [weak self] _ in
            guard let self = self else { return }
            let text = alert.textFields?.first?.text ?? "0"
            if let intVal = Int(text) { node.value = intVal }
            else if let doubleVal = Double(text) { node.value = doubleVal }
            else { node.value = 0 }
            self.applyNodeChange(node)
        })
        present(alert, animated: true)
    }
    private func applyNodeChange(_ node: EntitlementNode) {
        if let parent = node.parent {
            if let dict = parent.value as? [String: Any] {
                var mutable = dict
                mutable[node.key] = node.value
                parent.value = mutable
                parent.rebuildChildren()
            } else if let array = parent.value as? [Any] {
                var mutable = array
                if let index = Int(node.key.replacingOccurrences(of: "[", with: "").replacingOccurrences(of: "]", with: "")), index < mutable.count {
                    mutable[index] = node.value ?? ""
                    parent.value = mutable
                    parent.rebuildChildren()
                }
            }
        } else {
            entitlements[node.key] = node.value
            rebuildRootNodes()
        }
        rebuildVisibleNodes()
        treeView.reloadData()
    }
    private func deleteNode(_ node: EntitlementNode) {
        if let parent = node.parent {
            if let dict = parent.value as? [String: Any] {
                var mutable = dict
                mutable.removeValue(forKey: node.key)
                parent.value = mutable
                parent.rebuildChildren()
            } else if let array = parent.value as? [Any] {
                var mutable = array
                if let index = Int(node.key.replacingOccurrences(of: "[", with: "").replacingOccurrences(of: "]", with: "")), index < mutable.count {
                    mutable.remove(at: index)
                    parent.value = mutable
                    parent.rebuildChildren()
                }
            }
        } else {
            entitlements.removeValue(forKey: node.key)
            rebuildRootNodes()
        }
        rebuildVisibleNodes()
        treeView.reloadData()
    }
}

// MARK: - SettingsView.swift


public class LdidManager {
    public static func ldidPath() -> String {
        return NativeBinaryManager.path(for: .ldid)
    }

    public static func isInstalled() -> Bool {
        return NativeBinaryManager.exists(.ldid)
    }

    public static func prepare() throws -> String {
        try NativeBinaryManager.ldidPath()
    }
}

enum TrollHelperManager {
    static var path: String? {
        let path = NativeBinaryManager.path(for: .trollHelper)
        return FileManager.default.fileExists(atPath: path) ? path : nil
    }

    static var isAvailable: Bool {
        guard let path else { return false }
        return FileManager.default.isExecutableFile(atPath: path)
    }
}

struct PersistenceAppCandidate: Identifiable, Equatable {
    let id: String
    let name: String
    let bundleIdentifier: String
}

struct OptionSelectionView: View {
    let title: String
    @Binding var selection: Int
    let options: [(Int, String)]
    var body: some View {
        List {
            ForEach(options, id: \.0) { option in
                Button(action: {
                    selection = option.0
                }) {
                    HStack {
                        Text(option.1)
                            .foregroundColor(.primary)
                        Spacer()
                        if selection == option.0 {
                            Image(systemName: "checkmark")
                                .foregroundColor(.blue)
                        }
                    }
                    .contentShape(Rectangle())
                }
                .buttonStyle(.plain)
            }
        }
        .listStyle(.insetGrouped)
        .trollStoreGlassListBackground()
        .navigationTitle(title)
        .navigationBarTitleDisplayMode(.inline)
    }
}

struct InstallAlertConfigurationView: View {
    @Binding var selection: Int
    var body: some View {
        OptionSelectionView(
            title: NSLocalizedString("Show Install Confirmation Alert", comment: ""),
            selection: $selection,
            options: [
                (0, NSLocalizedString("Always (Recommended)", comment: "")),
                (1, NSLocalizedString("Only on Remote URL Installs", comment: "")),
                (2, NSLocalizedString("Never (Not Recommeded)", comment: ""))
            ]
        )
    }
}

struct AdvancedSettingsView: View {
    @AppStorage(TrollStoreDefaults.installationMethod) var installationMethod = 1
    @AppStorage(TrollStoreDefaults.uninstallationMethod) var uninstallationMethod = 0
    private var installationMethodTitle: String {
        return installationMethod == 1 ? NSLocalizedString("Custom", comment: "") : "installd"
    }
    private var uninstallationMethodTitle: String {
        return uninstallationMethod == 1 ? NSLocalizedString("Custom", comment: "") : "installd"
    }
    var body: some View {
        List {
            Section(header: Text(NSLocalizedString("Installation", comment: "")), footer: Text(NSLocalizedString("Choose whether apps are installed using installd or the custom method.", comment: ""))) {
                NavigationLink(destination: OptionSelectionView(
                    title: NSLocalizedString("Installation Method", comment: ""),
                    selection: $installationMethod,
                    options: [
                        (0, "installd"),
                        (1, NSLocalizedString("Custom", comment: ""))
                    ]
                )) {
                    HStack {
                        Text(NSLocalizedString("Installation Method", comment: ""))
                        Spacer()
                        Text(installationMethodTitle)
                            .foregroundColor(.secondary)
                    }
                }
            }
            Section(header: Text(NSLocalizedString("Uninstallation", comment: "")), footer: Text(NSLocalizedString("Choose whether apps are uninstalled using installd or the custom method.", comment: ""))) {
                NavigationLink(destination: OptionSelectionView(
                    title: NSLocalizedString("Uninstallation Method", comment: ""),
                    selection: $uninstallationMethod,
                    options: [
                        (0, "installd"),
                        (1, NSLocalizedString("Custom", comment: ""))
                    ]
                )) {
                    HStack {
                        Text(NSLocalizedString("Uninstallation Method", comment: ""))
                        Spacer()
                        Text(uninstallationMethodTitle)
                            .foregroundColor(.secondary)
                    }
                }
            }
        }
        .listStyle(.insetGrouped)
        .trollStoreGlassListBackground()
        .navigationTitle(NSLocalizedString("Advanced", comment: ""))
        .navigationBarTitleDisplayMode(.inline)
    }
}

struct SettingsView: View {
    @AppStorage(TrollStoreDefaults.autoInitLdid) var autoInitLdid = false
    @AppStorage(TrollStoreDefaults.installAlertConfiguration) var installAlertConfiguration = 0
    @AppStorage(TrollStoreDefaults.uninstallationMethod) var uninstallationMethod = 0
    @State private var urlSchemeEnabled = UserDefaults.standard.bool(forKey: TrollStoreDefaults.urlSchemeEnabled)
    @State private var devModeEnabled = true
    @State private var inactiveAppPaths: [String] = []
    @State private var ldidInstalled = LdidManager.isInstalled()
    @State private var installedPersistenceApp: PersistenceAppCandidate? = nil
    @State private var persistenceCandidates: [PersistenceAppCandidate] = []
    @State private var showUninstallAlert = false
    @State private var showPersistenceHelperPicker = false
    @State private var showErrorAlert = false
    @State private var showURLSchemeRebuildAlert = false
    @State private var showRebootRequiredAlert = false
    @State private var showTransferAlert = false
    @State private var showTransferErrorAlert = false
    @State private var errorTitle = NSLocalizedString("Error", comment: "")
    @State private var errorMessage = ""
    @State private var transferErrorMessage = ""
    @State private var transferErrorLog = ""
    
    private var urlSchemeBinding: Binding<Bool> {
        return Binding<Bool>(get: {
            urlSchemeEnabled
        }, set: { newValue in
            urlSchemeEnabled = newValue
            UserDefaults.standard.set(newValue, forKey: TrollStoreDefaults.urlSchemeEnabled)
            executeHelperCommand(args: ["url-scheme", newValue ? "enable" : "disable"])
            showURLSchemeRebuildAlert = true
        })
    }
    
    private var appName: String {
        return Bundle.main.object(forInfoDictionaryKey: "CFBundleDisplayName") as? String ?? Bundle.main.object(forInfoDictionaryKey: "CFBundleName") as? String ?? "TrollStore"
    }
    
    private var appVersion: String {
        return Bundle.main.object(forInfoDictionaryKey: "CFBundleShortVersionString") as? String ?? ""
    }
    
    private var otherFooter: String {
        if appVersion.isEmpty {
            return appName
        }
        return appName + " " + appVersion
    }
    
    private var utilitiesFooter: String {
        return NSLocalizedString("If an app does not immediately appear after installation, respring here and it should appear afterwards.", comment: "")
    }
    
    private var ldidVersion: String? {
        let versionPath = Bundle.main.path(forResource: "ldid", ofType: "version") ?? (Bundle.main.bundlePath as NSString).appendingPathComponent("ldid.version")
        guard let data = try? Data(contentsOf: URL(fileURLWithPath: versionPath)) else { return nil }
        return String(data: data, encoding: .utf8)
    }
    
    private var signingFooter: String {
        return NSLocalizedString("Using the bundled custom ldid binary for signing and entitlement operations.", comment: "")
    }
    
    private var standalonePersistenceInstalled: Bool {
        return FileManager.default.fileExists(atPath: "/Applications/TrollStorePersistenceHelper.app")
    }
    
    private var persistenceFooter: String {
        if standalonePersistenceInstalled {
            return NSLocalizedString("persistence_footer_standalone", comment: "")
        }
        if let helper = installedPersistenceApp {
            return String(format: NSLocalizedString("persistence_footer_installed", comment: ""), helper.name)
        }
        return NSLocalizedString("persistence_footer_default", comment: "")
    }
    
    private var securityFooter: String {
        return NSLocalizedString("security_footer", comment: "")
    }
    
    private var installAlertConfigurationTitle: String {
        switch installAlertConfiguration {
        case 0:
            return NSLocalizedString("Always (Recommended)", comment: "")
        case 1:
            return NSLocalizedString("Only on Remote URL Installs", comment: "")
        default:
            return NSLocalizedString("Never (Not Recommeded)", comment: "")
        }
    }
    
    private var transferAppsTitle: String {
        let count = inactiveAppPaths.count
        if count == 1 {
            return NSLocalizedString("Transfer 1 App", comment: "")
        }
        return String(format: NSLocalizedString("Transfer %d Apps", comment: ""), count)
    }
    
    private var transferAppsMessage: String {
        let count = inactiveAppPaths.count
        if count == 1 {
            return NSLocalizedString("This option will transfer 1 app from other TrollStore to TrollStore. Continue?", comment: "")
        }
        return String(format: NSLocalizedString("This option will transfer %d apps from other TrollStore to TrollStore. Continue?", comment: ""), count)
    }
    
    var body: some View {
        List {
            if #available(iOS 16, *), !devModeEnabled {
                Section(header: Text(NSLocalizedString("Developer Mode", comment: "")), footer: Text(NSLocalizedString("Some apps require developer mode enabled to launch. This requires a reboot to take effect.", comment: ""))) {
                    Button(NSLocalizedString("Enable Developer Mode", comment: "")) {
                        enableDeveloperMode()
                    }
                }
            }
            Section(header: Text(NSLocalizedString("Utilities", comment: "")), footer: Text(utilitiesFooter)) {
                Button(NSLocalizedString("Respring", comment: "")) {
                    executeHelperCommand(args: ["respring"])
                }
                Button(NSLocalizedString("Refresh App Registrations", comment: "")) {
                    executeHelperCommand(args: ["refresh"])
                }
                Button(NSLocalizedString("Rebuild Icon Cache", comment: "")) {
                    executeHelperCommand(args: ["refresh-all"])
                }
                if !inactiveAppPaths.isEmpty {
                    Button(transferAppsTitle) {
                        showTransferAlert = true
                    }
                }
            }
            Section(header: Text(NSLocalizedString("Signing", comment: "")), footer: Text(signingFooter)) {
                if let version = ldidVersion {
                    Text(NSLocalizedString("ldid: Built-in", comment: "") + " (" + version + ")")
                } else {
                    Text(NSLocalizedString("ldid: Built-in", comment: ""))
                }
            }
            Section(header: Text(NSLocalizedString("Persistence", comment: "")), footer: Text(persistenceFooter)) {
                if standalonePersistenceInstalled {
                    Text(NSLocalizedString("Helper Installed as Standalone App", comment: ""))
                } else if let helper = installedPersistenceApp {
                    Text(String(format: NSLocalizedString("Helper Installed into %@", comment: ""), helper.name))
                    Button(NSLocalizedString("Uninstall Persistence Helper", comment: ""), role: .destructive) {
                        uninstallPersistenceHelper()
                    }
                } else {
                    Button(NSLocalizedString("Install Persistence Helper", comment: "")) {
                        showPersistenceHelperPicker = true
                    }
                }
            }
            Section {
                NavigationLink(destination: AdvancedSettingsView()) {
                    Text(NSLocalizedString("Advanced", comment: ""))
                }
            }
            Section(header: Text(NSLocalizedString("Security", comment: "")), footer: Text(securityFooter)) {
                Toggle(NSLocalizedString("URL Scheme Enabled", comment: ""), isOn: urlSchemeBinding)
                NavigationLink(destination: InstallAlertConfigurationView(selection: $installAlertConfiguration)) {
                    HStack {
                        Text(NSLocalizedString("Show Install Confirmation Alert", comment: ""))
                        Spacer()
                        Text(installAlertConfigurationTitle)
                            .foregroundColor(.secondary)
                    }
                }
            }
            Section(header: Text(""), footer: Text(otherFooter)) {
                Button(NSLocalizedString("Uninstall TrollStore", comment: ""), role: .destructive) {
                    showUninstallAlert = true
                }
            }
        }
        .listStyle(.insetGrouped)
        .trollStoreGlassListBackground()
        .navigationTitle(NSLocalizedString("Settings", comment: ""))
        .navigationBarTitleDisplayMode(.large)
        .onAppear {
            reloadDynamicSettings()
        }
        .alert(NSLocalizedString("URL Scheme Changed", comment: ""), isPresented: $showURLSchemeRebuildAlert) {
            Button(NSLocalizedString("Rebuild Now", comment: "")) {
                executeHelperCommand(args: ["refresh-all"])
            }
            Button(NSLocalizedString("Rebuild Later", comment: ""), role: .cancel) { }
        } message: {
            Text(NSLocalizedString("In order to properly apply the change of the URL scheme setting, rebuilding the icon cache is needed.", comment: ""))
        }
        .alert(NSLocalizedString("Reboot Required", comment: ""), isPresented: $showRebootRequiredAlert) {
            Button(NSLocalizedString("Reboot Now", comment: "")) {
                executeHelperCommand(args: ["reboot"])
            }
            Button(NSLocalizedString("Close", comment: ""), role: .cancel) {
                reloadDeveloperMode()
            }
        } message: {
            Text(NSLocalizedString("After rebooting, select \"Turn On\" to enable developer mode.", comment: ""))
        }
        .alert(NSLocalizedString("Transfer Apps", comment: ""), isPresented: $showTransferAlert) {
            Button(NSLocalizedString("Transfer", comment: "")) {
                transferApps()
            }
            Button(NSLocalizedString("Cancel", comment: ""), role: .cancel) { }
        } message: {
            Text(transferAppsMessage)
        }
        .alert(NSLocalizedString("Transfer Failed", comment: ""), isPresented: $showTransferErrorAlert) {
            Button(NSLocalizedString("Copy Debug Log", comment: "")) {
                UIPasteboard.general.string = transferErrorLog
            }
            Button(NSLocalizedString("Close", comment: ""), role: .cancel) { }
        } message: {
            Text(transferErrorMessage)
        }
        .alert(NSLocalizedString("Confirm Uninstall", comment: ""), isPresented: $showUninstallAlert) {
            Button(NSLocalizedString("Cancel", comment: ""), role: .cancel) { }
            Button(NSLocalizedString("Uninstall", comment: ""), role: .destructive) {
                uninstallTrollStore()
            }
        }
        .confirmationDialog(NSLocalizedString("Select App", comment: ""), isPresented: $showPersistenceHelperPicker, titleVisibility: .visible) {
            ForEach(persistenceCandidates) { candidate in
                Button(candidate.name) {
                    installPersistenceHelper(bundleIdentifier: candidate.bundleIdentifier)
                }
            }
            if persistenceCandidates.isEmpty {
                Button(NSLocalizedString("Tips", comment: "")) {
                    installPersistenceHelper(bundleIdentifier: "com.apple.tips")
                }
                Button(NSLocalizedString("Shortcuts", comment: "")) {
                    installPersistenceHelper(bundleIdentifier: "com.apple.shortcuts")
                }
            }
            Button(NSLocalizedString("Cancel", comment: ""), role: .cancel) { }
        } message: {
            Text(NSLocalizedString("persistence_picker_message", comment: ""))
        }
        .alert(errorTitle, isPresented: $showErrorAlert) {
            Button(NSLocalizedString("Close", comment: ""), role: .cancel) { }
        } message: {
            Text(errorMessage)
        }
    }
    
    private func reloadDynamicSettings() {
        inactiveAppPaths = inactiveAppBundlePaths()
        reloadDeveloperMode()
        reloadPersistenceState()
    }
    
    private func reloadDeveloperMode() {
        if #available(iOS 16, *) {
            DispatchQueue.global(qos: .userInitiated).async {
                let ret = (try? RootHelper.execute(args: ["check-dev-mode"])) ?? -1
                DispatchQueue.main.async {
                    devModeEnabled = (ret == 0)
                }
            }
        } else {
            devModeEnabled = true
        }
    }
    
    private func enableDeveloperMode() {
        DispatchQueue.global(qos: .userInitiated).async {
            let ret = (try? RootHelper.execute(args: ["arm-dev-mode"])) ?? -1
            DispatchQueue.main.async {
                if ret == 0 {
                    showRebootRequiredAlert = true
                } else {
                    errorTitle = String(format: NSLocalizedString("Error %d", comment: ""), ret)
                    errorMessage = NSLocalizedString("Failed to enable developer mode.", comment: "")
                    showErrorAlert = true
                }
            }
        }
    }
    
    private func transferApps() {
        DispatchQueue.global(qos: .userInitiated).async {
            var ret: Int32 = -1
            var logData = Data()
            if let result = try? RootHelper.executeCapturingOutput(args: ["transfer-apps"]) {
                ret = result.0
                logData = result.1
            }
            DispatchQueue.main.async {
                inactiveAppPaths = inactiveAppBundlePaths()
                if ret != 0 {
                    transferErrorLog = String(data: logData, encoding: .utf8) ?? ""
                    let count = inactiveAppPaths.count
                    if count == 1 {
                        transferErrorMessage = NSLocalizedString("Failed to transfer 1 app", comment: "")
                    } else {
                        transferErrorMessage = String(format: NSLocalizedString("Failed to transfer %d apps", comment: ""), count)
                    }
                    showTransferErrorAlert = true
                }
            }
        }
    }
    
    private func uninstallTrollStore() {
        var args = ["uninstall-trollstore"]
        if uninstallationMethod == 1 {
            args.append("custom")
        }
        executeHelperCommand(args: args)
    }
    
    private func installPersistenceHelper(bundleIdentifier: String) {
        executeHelperCommand(args: ["install-persistence-helper", bundleIdentifier])
        reloadPersistenceState()
    }
    
    private func uninstallPersistenceHelper() {
        executeHelperCommand(args: ["uninstall-persistence-helper"])
        reloadPersistenceState()
    }
    
    private func reloadPersistenceState() {
        DispatchQueue.global(qos: .userInitiated).async {
            let helper = installedPersistenceHelper()
            let candidates = persistenceAppCandidates()
            DispatchQueue.main.async {
                installedPersistenceApp = helper
                persistenceCandidates = candidates
            }
        }
    }
    
    private func installedPersistenceHelper() -> PersistenceAppCandidate? {
        let fm = FileManager.default
        for proxy in installedApplicationProxies() {
            let installed = boolValue(proxy, key: "installed")
            let restricted = boolValue(proxy, key: "restricted")
            let bundleIdentifier = stringValue(proxy, key: "bundleIdentifier")
            if !installed || restricted || bundleIdentifier.isEmpty {
                continue
            }
            let signaturePath = "/System/Library/AppSignatures/" + bundleIdentifier
            guard fm.fileExists(atPath: signaturePath) else {
                continue
            }
            if let bundleURL = urlValue(proxy, key: "bundleURL") {
                let markerURL = bundleURL.deletingLastPathComponent().appendingPathComponent(TrollStorePaths.activeMarker)
                if (try? markerURL.checkResourceIsReachable()) ?? false {
                    let name = stringValue(proxy, key: "localizedName")
                    return PersistenceAppCandidate(
                        id: bundleIdentifier,
                        name: name.isEmpty ? bundleIdentifier : name,
                        bundleIdentifier: bundleIdentifier
                    )
                }
            }
        }
        return nil
    }
    
    private func persistenceAppCandidates() -> [PersistenceAppCandidate] {
        let fm = FileManager.default
        var candidates: [PersistenceAppCandidate] = []
        for proxy in installedApplicationProxies() {
            let installed = boolValue(proxy, key: "installed")
            let restricted = boolValue(proxy, key: "restricted")
            let bundleIdentifier = stringValue(proxy, key: "bundleIdentifier")
            if !installed || restricted || bundleIdentifier.isEmpty {
                continue
            }
            let signaturePath = "/System/Library/AppSignatures/" + bundleIdentifier
            guard fm.fileExists(atPath: signaturePath) else {
                continue
            }
            if let bundleURL = urlValue(proxy, key: "bundleURL") {
                let markerURL = bundleURL.deletingLastPathComponent().appendingPathComponent(TrollStorePaths.activeMarker)
                let reachable = (try? markerURL.checkResourceIsReachable()) ?? false
                if !reachable {
                    let name = stringValue(proxy, key: "localizedName")
                    candidates.append(
                        PersistenceAppCandidate(
                            id: bundleIdentifier,
                            name: name.isEmpty ? bundleIdentifier : name,
                            bundleIdentifier: bundleIdentifier
                        )
                    )
                }
            }
        }
        return candidates.sorted {
            $0.name.localizedStandardCompare($1.name) == .orderedAscending
        }
    }
    
    private func installedApplicationProxies() -> [NSObject] {
        var apps: [NSObject] = []
        guard let cls = NSClassFromString("LSApplicationWorkspace") as? NSObject.Type,
              let workspace = cls.perform(NSSelectorFromString("defaultWorkspace"))?.takeUnretainedValue() as? NSObject else {
            return apps
        }
        let sel = NSSelectorFromString("enumerateApplicationsOfType:block:")
        guard workspace.responds(to: sel) else { return apps }
        typealias BlockType = @convention(block) (NSObject) -> Void
        let block: BlockType = { proxy in
            apps.append(proxy)
        }
        let imp = workspace.method(for: sel)
        typealias Fn = @convention(c) (NSObject, Selector, UInt, BlockType) -> Void
        let fn = unsafeBitCast(imp, to: Fn.self)
        fn(workspace, sel, 0, block)
        fn(workspace, sel, 1, block)
        return apps
    }
    
    private func boolValue(_ proxy: NSObject, key: String) -> Bool {
        guard proxy.responds(to: NSSelectorFromString(key)) else { return false }
        return (proxy.value(forKey: key) as? NSNumber)?.boolValue ?? false
    }
    
    private func stringValue(_ proxy: NSObject, key: String) -> String {
        guard proxy.responds(to: NSSelectorFromString(key)) else { return "" }
        return (proxy.value(forKey: key) as? String) ?? ""
    }
    
    private func urlValue(_ proxy: NSObject, key: String) -> URL? {
        guard proxy.responds(to: NSSelectorFromString(key)) else { return nil }
        return proxy.value(forKey: key) as? URL
    }
    
    private func inactiveAppBundlePaths() -> [String] {
        let fm = FileManager.default
        let appsRoot = TrollStorePaths.applicationsPath
        var paths: [String] = []
        guard let containerDirs = try? fm.contentsOfDirectory(atPath: appsRoot) else {
            return paths
        }
        for containerDir in containerDirs {
            let containerPath = (appsRoot as NSString).appendingPathComponent(containerDir)
            var isDir: ObjCBool = false
            guard fm.fileExists(atPath: containerPath, isDirectory: &isDir), isDir.boolValue else {
                continue
            }
            let inactiveMarker = (containerPath as NSString).appendingPathComponent(TrollStorePaths.inactiveMarker)
            if fm.fileExists(atPath: inactiveMarker) {
                if let appPath = findAppPath(in: containerPath) {
                    paths.append(appPath)
                }
            }
        }
        return paths
    }
    
    private func findAppPath(in containerPath: String) -> String? {
        let fm = FileManager.default
        guard let contents = try? fm.contentsOfDirectory(atPath: containerPath) else {
            return nil
        }
        for item in contents {
            if item.hasSuffix(".app") {
                let appPath = (containerPath as NSString).appendingPathComponent(item)
                var isDir: ObjCBool = false
                if fm.fileExists(atPath: appPath, isDirectory: &isDir) && isDir.boolValue {
                    return appPath
                }
            }
        }
        return nil
    }
    
    private func executeHelperCommand(args: [String]) {
        do {
            let ret = try RootHelper.execute(args: args)
            if ret != 0 {
                errorTitle = String(format: NSLocalizedString("Error %d", comment: ""), Int(ret))
                errorMessage = NSLocalizedString("Command failed.", comment: "")
                showErrorAlert = true
            }
        } catch {
            errorTitle = NSLocalizedString("Error", comment: "")
            errorMessage = NSLocalizedString("Failed to spawn helper.", comment: "")
            showErrorAlert = true
        }
    }
}



// MARK: - Glass UI Helpers

private struct TrollStoreGlassBackground: View {
    var body: some View {
        ZStack {
            Color(uiColor: .systemBackground)
            Rectangle()
                .fill(.ultraThinMaterial)
                .ignoresSafeArea()
        }
    }
}

private extension View {
    @ViewBuilder
    func trollStoreGlassListBackground() -> some View {
        if #available(iOS 16.0, *) {
            self
                .scrollContentBackground(.hidden)
                .background(TrollStoreGlassBackground())
        } else {
            self
        }
    }
}


// MARK: - MainTabBarController

public final class MainTabBarController: UITabBarController {
    public override func viewDidLoad() {
        super.viewDidLoad()
        configureAppearance()

        let apps = AppListViewController()
        apps.title = NSLocalizedString("Apps", comment: "")

        let settings = UIHostingController(rootView: SettingsView())
        settings.view.backgroundColor = .clear
        settings.title = NSLocalizedString("Settings", comment: "")

        let appsNavigation = UINavigationController(rootViewController: apps)
        let settingsNavigation = UINavigationController(rootViewController: settings)

        appsNavigation.navigationBar.prefersLargeTitles = true
        settingsNavigation.navigationBar.prefersLargeTitles = true

        appsNavigation.tabBarItem = UITabBarItem(
            title: NSLocalizedString("Apps", comment: ""),
            image: UIImage(systemName: "square.stack.3d.up"),
            selectedImage: UIImage(systemName: "square.stack.3d.up.fill")
        )
        settingsNavigation.tabBarItem = UITabBarItem(
            title: NSLocalizedString("Settings", comment: ""),
            image: UIImage(systemName: "gearshape"),
            selectedImage: UIImage(systemName: "gearshape.fill")
        )

        viewControllers = [appsNavigation, settingsNavigation]
    }

    private func configureAppearance() {
        let navigationAppearance = UINavigationBarAppearance()
        navigationAppearance.configureWithTransparentBackground()
        navigationAppearance.backgroundEffect = UIBlurEffect(style: .systemUltraThinMaterial)
        navigationAppearance.backgroundColor = UIColor.systemBackground.withAlphaComponent(0.18)
        navigationAppearance.shadowColor = .clear

        UINavigationBar.appearance().standardAppearance = navigationAppearance
        UINavigationBar.appearance().scrollEdgeAppearance = navigationAppearance
        UINavigationBar.appearance().compactAppearance = navigationAppearance

        let tabAppearance = UITabBarAppearance()
        tabAppearance.configureWithTransparentBackground()
        tabAppearance.backgroundEffect = UIBlurEffect(style: .systemUltraThinMaterial)
        tabAppearance.backgroundColor = UIColor.systemBackground.withAlphaComponent(0.16)
        tabAppearance.shadowColor = .clear

        tabBar.standardAppearance = tabAppearance
        if #available(iOS 15.0, *) {
            tabBar.scrollEdgeAppearance = tabAppearance
        }
    }
}



// MARK: - Application Entry

@main
public final class TrollStoreApp: UIResponder, UIApplicationDelegate {
    public var window: UIWindow?

    public func application(
        _ application: UIApplication,
        didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]? = nil
    ) -> Bool {
        let window = UIWindow(frame: UIScreen.main.bounds)
        window.rootViewController = MainTabBarController()
        self.window = window
        window.makeKeyAndVisible()
        return true
    }

    public func application(
        _ app: UIApplication,
        open url: URL,
        options: [UIApplication.OpenURLOptionsKey: Any] = [:]
    ) -> Bool {
        guard let components = URLComponents(url: url, resolvingAgainstBaseURL: false) else {
            return false
        }

        switch components.host {
        case "install":
            if let value = components.queryItems?.first(where: { $0.name == "url" })?.value {
                NotificationCenter.default.post(
                    name: NSNotification.Name("TrollStoreRemoteInstall"),
                    object: value
                )
            }
        case "enable-jit":
            if let bundleId = components.queryItems?.first(where: { $0.name == "bundle-id" })?.value {
                NotificationCenter.default.post(
                    name: NSNotification.Name("TrollStoreEnableJIT"),
                    object: bundleId
                )
            }
        default:
            break
        }

        return true
    }
}

