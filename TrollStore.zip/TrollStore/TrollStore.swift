import UIKit
import SwiftUI
import Foundation
import Darwin
import UniformTypeIdentifiers

// MARK: - CodeSigningInstaller.swift


@_silgen_name("archive_read_new")
func archive_read_new() -> OpaquePointer?
@_silgen_name("archive_read_support_format_all")
func archive_read_support_format_all(_ a: OpaquePointer?) -> Int32
@_silgen_name("archive_read_support_filter_all")
func archive_read_support_filter_all(_ a: OpaquePointer?) -> Int32
@_silgen_name("archive_read_open_filename")
func archive_read_open_filename(_ a: OpaquePointer?, _ filename: UnsafePointer<CChar>?, _ block_size: Int) -> Int32
@_silgen_name("archive_read_next_header")
func archive_read_next_header(_ a: OpaquePointer?, _ entry: UnsafeMutablePointer<OpaquePointer?>?) -> Int32
@_silgen_name("archive_entry_pathname")
func archive_entry_pathname(_ entry: OpaquePointer?) -> UnsafePointer<CChar>?
@_silgen_name("archive_entry_size")
func archive_entry_size(_ entry: OpaquePointer?) -> Int64
@_silgen_name("archive_read_data")
func archive_read_data(_ a: OpaquePointer?, _ buff: UnsafeMutableRawPointer?, _ size: Int) -> Int
@_silgen_name("archive_read_close")
func archive_read_close(_ a: OpaquePointer?) -> Int32
@_silgen_name("archive_read_free")
func archive_read_free(_ a: OpaquePointer?) -> Int32

enum TrollStorePaths {
    static let rootPath = "/var/containers/Bundle/TrollStore"
    static let applicationsPath = "/var/containers/Bundle/TrollStore/Applications"
    static let activeMarker = ".TrollStore"
    static let inactiveMarker = ".TrollStoreInactive"
    static let ldidName = "ldid"
    static let helperName = "trollstorehelper"
    static let trollHelperName = "TrollHelper"
    static let extraEntitlementsName = "entitlements.plist"
}

enum NativeBinary {
    case ldid
    case trollstorehelper
    case trollHelper

    var resourceName: String {
        switch self {
        case .ldid: return TrollStorePaths.ldidName
        case .trollstorehelper: return TrollStorePaths.helperName
        case .trollHelper: return TrollStorePaths.trollHelperName
        }
    }
}

enum NativeBinaryManager {
    private static let lock = NSLock()

    static func path(for binary: NativeBinary) -> String {
        let name = binary.resourceName
        if let path = Bundle.main.path(forResource: name, ofType: nil) {
            return path
        }
        return (Bundle.main.bundlePath as NSString).appendingPathComponent(name)
    }

    static func exists(_ binary: NativeBinary) -> Bool {
        FileManager.default.isExecutableFile(atPath: path(for: binary))
    }

    static func prepare(_ binary: NativeBinary) throws -> String {
        lock.lock()
        defer { lock.unlock() }

        let path = path(for: binary)
        guard FileManager.default.fileExists(atPath: path) else {
            throw TrollStoreInstallError(code: -2)
        }

        var statInfo = stat()
        guard stat(path, &statInfo) == 0 else {
            throw TrollStoreInstallError(code: -2)
        }

        let mode = statInfo.st_mode & 0o777
        if mode & 0o111 == 0 {
            guard chmod(path, 0o755) == 0 else {
                throw TrollStoreInstallError(code: -2)
            }
        }
        return path
    }

    static func ldidPath() throws -> String {
        try prepare(.ldid)
    }

    static func helperPath() throws -> String {
        try prepare(.trollstorehelper)
    }

    static func trollHelperPath() throws -> String {
        try prepare(.trollHelper)
    }
}

enum TrollStoreCommands {
    static let install = "install"
    static let uninstall = "uninstall"
    static let refresh = "refresh"
    static let refreshAll = "refresh-all"
    static let urlScheme = "url-scheme"
    static let respring = "respring"
    static let enableJIT = "enable-jit"
    static let modifyRegistration = "modify-registration"
    static let installTrollStore = "install-trollstore"
    static let uninstallTrollStore = "uninstall-trollstore"
    static let installPersistenceHelper = "install-persistence-helper"
}

enum TrollStoreDefaults {
    static let installationMethod = "installationMethod"
    static let uninstallationMethod = "uninstallationMethod"
    static let installAlertConfiguration = "installAlertConfiguration"
    static let autoInitLdid = "autoInitLdid"
    static let urlSchemeEnabled = "urlSchemeEnabled"
}

public struct TrollStoreInstallError: Error, LocalizedError {
    public let code: Int32
    public var errorDescription: String? {
        return TrollStoreInstallError.description(for: code)
    }
    public static func description(for code: Int32) -> String {
        switch code {
        case 166: return TSLocalized("Error_166", comment: "")
        case 167: return TSLocalized("Error_167", comment: "")
        case 168: return TSLocalized("Error_168", comment: "")
        case 169: return TSLocalized("Error_169", comment: "")
        case 170: return TSLocalized("Error_170", comment: "")
        case 171: return TSLocalized("Error_171", comment: "")
        case 172: return TSLocalized("Error_172", comment: "")
        case 173: return TSLocalized("Error_173", comment: "")
        case 174: return TSLocalized("Error_174", comment: "")
        case 175: return TSLocalized("Error_175", comment: "")
        case 176: return TSLocalized("Error_176", comment: "")
        case 177: return TSLocalized("Error_177", comment: "")
        case 178: return TSLocalized("Error_178", comment: "")
        case 179: return TSLocalized("Error_179", comment: "")
        case 180: return TSLocalized("Error_180", comment: "")
        case 181: return TSLocalized("Error_181", comment: "")
        case 182: return TSLocalized("Error_182", comment: "")
        case 183: return TSLocalized("Error_183", comment: "")
        case 184: return TSLocalized("Error_184", comment: "")
        case 185: return TSLocalized("Error_185", comment: "")
        default: return TSLocalized("Error_Unknown", comment: "")
        }
    }
}

public class RootHelper {
    private static let spawnLock = NSLock()
    public static func execute(args: [String]) throws -> Int32 {
        let helperPath = try NativeBinaryManager.helperPath()
        return try runProcess(helperPath, args, captureOutput: false).0
    }
    public static func executeCapturingOutput(args: [String]) throws -> (Int32, Data) {
        let helperPath = try NativeBinaryManager.helperPath()
        return try runProcess(helperPath, args, captureOutput: true)
    }
    public static func runProcess(_ executable: String, _ args: [String], workingDirectory: String? = nil, captureOutput: Bool) throws -> (Int32, Data) {
        spawnLock.lock()
        defer { spawnLock.unlock() }
        var argv: [UnsafeMutablePointer<CChar>?] = [strdup(executable)]
        argv.append(contentsOf: args.map { strdup($0) })
        argv.append(nil)
        defer {
            for ptr in argv {
                if let p = ptr { free(p) }
            }
        }
        var pipefd: [Int32] = [0, 0]
        var action: posix_spawn_file_actions_t? = nil
        _ = posix_spawn_file_actions_init(&action)
        defer { _ = posix_spawn_file_actions_destroy(&action) }
        var previousDirectory: String? = nil
        if let wd = workingDirectory {
            previousDirectory = FileManager.default.currentDirectoryPath
            _ = FileManager.default.changeCurrentDirectoryPath(wd)
        }
        if captureOutput {
            if pipe(&pipefd) != 0 {
                if let prev = previousDirectory { _ = FileManager.default.changeCurrentDirectoryPath(prev) }
                throw TrollStoreInstallError(code: -1)
            }
            _ = posix_spawn_file_actions_adddup2(&action, pipefd[1], 1)
            _ = posix_spawn_file_actions_addclose(&action, pipefd[0])
        }
        var pid: pid_t = 0
        let spawnResult = argv.withUnsafeMutableBufferPointer { buffer -> Int32 in
            return posix_spawn(&pid, executable, &action, nil, buffer.baseAddress, nil)
        }
        if let prev = previousDirectory {
            _ = FileManager.default.changeCurrentDirectoryPath(prev)
        }
        if captureOutput {
            _ = close(pipefd[1])
        }
        if spawnResult != 0 {
            if captureOutput { _ = close(pipefd[0]) }
            throw TrollStoreInstallError(code: spawnResult)
        }
        var data = Data()
        if captureOutput {
            var buffer = [UInt8](repeating: 0, count: 4096)
            while true {
                let bytesRead = read(pipefd[0], &buffer, buffer.count)
                if bytesRead <= 0 { break }
                data.append(buffer, count: bytesRead)
            }
            _ = close(pipefd[0])
        }
        var status: Int32 = 0
        _ = waitpid(pid, &status, 0)
        let exited = (status & 0x7f) == 0
        if !exited {
            throw TrollStoreInstallError(code: -1)
        }
        return (Int32((status >> 8) & 0xff), data)
    }
}

public class InstallationManager {
    private static var downloadObservations: [Int: NSKeyValueObservation] = [:]
    public static func parseIPA(path: String) -> [String: Any]? {
        let a = archive_read_new()
        _ = archive_read_support_format_all(a)
        _ = archive_read_support_filter_all(a)
        let openResult = path.withCString { cPath in
            archive_read_open_filename(a, cPath, 10240)
        }
        guard openResult == 0 else {
            _ = archive_read_free(a)
            return nil
        }
        var entry: OpaquePointer?
        defer {
            _ = archive_read_close(a)
            _ = archive_read_free(a)
        }
        while archive_read_next_header(a, &entry) == 0 {
            if let cName = archive_entry_pathname(entry) {
                let name = String(cString: cName)
                if name.hasSuffix(".app/Info.plist") && name.contains("Payload/") {
                    let size = archive_entry_size(entry)
                    if size > 0 {
                        var data = Data()
                        var remaining = Int(size)
                        let bufferSize = 8192
                        while remaining > 0 {
                            let chunkSize = min(bufferSize, remaining)
                            var chunk = [UInt8](repeating: 0, count: chunkSize)
                            let read = archive_read_data(a, &chunk, chunkSize)
                            if read <= 0 { break }
                            data.append(chunk, count: read)
                            remaining -= read
                        }
                        if remaining == 0 {
                            if let dict = try? PropertyListSerialization.propertyList(from: data, options: [], format: nil) as? [String: Any] {
                                return dict
                            }
                        }
                    }
                }
            }
        }
        return nil
    }
    public static func extractIcon(ipaPath: String, infoDict: [String: Any]) -> UIImage? {
        var iconName: String?
        if let icons = infoDict["CFBundleIcons"] as? [String: Any],
           let primary = icons["CFBundlePrimaryIcon"] as? [String: Any] {
            if let files = primary["CFBundleIconFiles"] as? [String], let last = files.last {
                iconName = last
            }
        }
        guard let baseName = iconName else { return nil }
        let a = archive_read_new()
        _ = archive_read_support_format_all(a)
        _ = archive_read_support_filter_all(a)
        let openResult = ipaPath.withCString { cPath in
            archive_read_open_filename(a, cPath, 10240)
        }
        guard openResult == 0 else {
            _ = archive_read_free(a)
            return nil
        }
        var entry: OpaquePointer?
        var bestMatch: String?
        var bestMatchSize: Int64 = 0
        defer {
            _ = archive_read_close(a)
            _ = archive_read_free(a)
        }
        while archive_read_next_header(a, &entry) == 0 {
            if let cName = archive_entry_pathname(entry) {
                let name = String(cString: cName)
                if name.contains("Payload/") && name.hasSuffix(".png") {
                    let fileName = (name as NSString).lastPathComponent
                    if fileName.hasPrefix(baseName) || fileName == baseName + ".png" || fileName.contains(baseName) {
                        let size = archive_entry_size(entry)
                        if size > bestMatchSize {
                            bestMatch = name
                            bestMatchSize = size
                        }
                    }
                }
            }
        }
        guard let match = bestMatch else { return nil }
        let a2 = archive_read_new()
        _ = archive_read_support_format_all(a2)
        _ = archive_read_support_filter_all(a2)
        let openResult2 = ipaPath.withCString { cPath in
            archive_read_open_filename(a2, cPath, 10240)
        }
        guard openResult2 == 0 else {
            _ = archive_read_free(a2)
            return nil
        }
        defer {
            _ = archive_read_close(a2)
            _ = archive_read_free(a2)
        }
        var entry2: OpaquePointer?
        while archive_read_next_header(a2, &entry2) == 0 {
            if let cName = archive_entry_pathname(entry2) {
                let name = String(cString: cName)
                if name == match {
                    let size = archive_entry_size(entry2)
                    if size > 0 {
                        var data = Data()
                        var remaining = Int(size)
                        let bufferSize = 8192
                        while remaining > 0 {
                            let chunkSize = min(bufferSize, remaining)
                            var chunk = [UInt8](repeating: 0, count: chunkSize)
                            let read = archive_read_data(a2, &chunk, chunkSize)
                            if read <= 0 { break }
                            data.append(chunk, count: read)
                            remaining -= read
                        }
                        if remaining == 0 {
                            return UIImage(data: data)
                        }
                    }
                }
            }
        }
        return nil
    }
    public static func downloadIPA(url: URL, progress: @escaping (Double) -> Void, completion: @escaping (String?, Error?) -> Void) {
        let task = URLSession.shared.downloadTask(with: url) { localURL, response, error in
            if let error = error {
                completion(nil, error)
                return
            }
            guard let localURL = localURL else {
                completion(nil, NSError(domain: "Download", code: -1))
                return
            }
            let tmpPath = NSTemporaryDirectory().appending(UUID().uuidString).appending(".ipa")
            do {
                try FileManager.default.moveItem(at: localURL, to: URL(fileURLWithPath: tmpPath))
                completion(tmpPath, nil)
            } catch {
                completion(nil, error)
            }
        }
        let observation = task.progress.observe(\.fractionCompleted) { p, _ in
            DispatchQueue.main.async { progress(p.fractionCompleted) }
        }
        downloadObservations[task.taskIdentifier] = observation
        task.resume()
    }
    public static func installIPA(path: String, force: Bool, useInstalldMethod: Bool, skipUICache: Bool, entitlements: [String: Any]? = nil) throws {
        if let entitlements = entitlements, !entitlements.isEmpty {
            let patchedIPA = try repackIPAWithEntitlements(ipaPath: path, entitlements: entitlements)
            defer { try? FileManager.default.removeItem(atPath: patchedIPA) }
            try runInstall(ipaPath: patchedIPA, force: force, useInstalldMethod: useInstalldMethod, skipUICache: skipUICache)
        } else {
            try runInstall(ipaPath: path, force: force, useInstalldMethod: useInstalldMethod, skipUICache: skipUICache)
        }
    }
    private static func runInstall(ipaPath: String, force: Bool, useInstalldMethod: Bool, skipUICache: Bool) throws {
        var args = [TrollStoreCommands.install]
        if useInstalldMethod { args.append("installd") }
        else { args.append("custom") }
        if force { args.append("force") }
        if skipUICache { args.append("skip-uicache") }
        args.append(ipaPath)
        let ret = try RootHelper.execute(args: args)
        if ret != 0 { throw TrollStoreInstallError(code: ret) }
    }
    private static func repackIPAWithEntitlements(ipaPath: String, entitlements: [String: Any]) throws -> String {
        let fm = FileManager.default
        let workDir = NSTemporaryDirectory().appending(UUID().uuidString)
        try fm.createDirectory(atPath: workDir, withIntermediateDirectories: true)
        let unzipRet = try RootHelper.runProcess("/usr/bin/unzip", ["-o", ipaPath, "-d", workDir], captureOutput: false).0
        if unzipRet != 0 {
            try? fm.removeItem(atPath: workDir)
            throw TrollStoreInstallError(code: 168)
        }
        let payloadPath = (workDir as NSString).appendingPathComponent("Payload")
        guard let payloadContents = try? fm.contentsOfDirectory(atPath: payloadPath) else {
            try? fm.removeItem(atPath: workDir)
            throw TrollStoreInstallError(code: 167)
        }
        guard let appName = payloadContents.first(where: { $0.hasSuffix(".app") }) else {
            try? fm.removeItem(atPath: workDir)
            throw TrollStoreInstallError(code: 167)
        }
        let appPath = (payloadPath as NSString).appendingPathComponent(appName)
        let infoPlistPath = (appPath as NSString).appendingPathComponent("Info.plist")
        guard let infoDict = NSDictionary(contentsOfFile: infoPlistPath) as? [String: Any],
              let executable = infoDict["CFBundleExecutable"] as? String else {
            try? fm.removeItem(atPath: workDir)
            throw TrollStoreInstallError(code: 176)
        }
        let binaryPath = (appPath as NSString).appendingPathComponent(executable)
        if !fm.fileExists(atPath: binaryPath) {
            try? fm.removeItem(atPath: workDir)
            throw TrollStoreInstallError(code: 174)
        }
        let entitlementsData = try PropertyListSerialization.data(fromPropertyList: entitlements, format: .xml, options: 0)
        let entitlementsPath = (workDir as NSString).appendingPathComponent("entitlements.plist")
        try entitlementsData.write(to: URL(fileURLWithPath: entitlementsPath))
        let ldidPath = LdidManager.ldidPath()
        let ldidRet = try RootHelper.runProcess(ldidPath, ["-S\(entitlementsPath)", binaryPath], captureOutput: false).0
        if ldidRet != 0 {
            try? fm.removeItem(atPath: workDir)
            throw TrollStoreInstallError(code: 175)
        }
        let repackedIPA = NSTemporaryDirectory().appending(UUID().uuidString).appending(".ipa")
        let zipRet = try RootHelper.runProcess("/usr/bin/zip", ["-qr", repackedIPA, "Payload"], workingDirectory: workDir, captureOutput: false).0
        try? fm.removeItem(atPath: workDir)
        if zipRet != 0 {
            throw TrollStoreInstallError(code: 168)
        }
        return repackedIPA
    }
    public static func uninstallApp(bundleId: String, useCustomMethod: Bool) throws {
        var args = [TrollStoreCommands.uninstall]
        if useCustomMethod { args.append("custom") }
        else { args.append("installd") }
        args.append(bundleId)
        let ret = try RootHelper.execute(args: args)
        if ret != 0 { throw TrollStoreInstallError(code: ret) }
    }
    public static func enableJIT(bundleId: String) throws {
        let ret = try RootHelper.execute(args: [TrollStoreCommands.enableJIT, bundleId])
        if ret != 0 { throw TrollStoreInstallError(code: ret) }
    }
    public static func changeRegistration(appPath: String, isSystem: Bool) throws {
        let registration = isSystem ? "System" : "User"
        let ret = try RootHelper.execute(args: [TrollStoreCommands.modifyRegistration, appPath, registration])
        if ret != 0 { throw TrollStoreInstallError(code: ret) }
    }
    public static func dumpEntitlements(binaryPath: String) throws -> [String: Any] {
        let ldidPath = LdidManager.ldidPath()
        let (ret, data) = try RootHelper.runProcess(ldidPath, ["-e", binaryPath], captureOutput: true)
        if ret != 0 { throw TrollStoreInstallError(code: 175) }
        if let dict = try? PropertyListSerialization.propertyList(from: data, options: [], format: nil) as? [String: Any] {
            return dict
        }
        return [:]
    }
    public static func setEntitlements(binaryPath: String, entitlements: [String: Any]) throws {
        let data = try PropertyListSerialization.data(fromPropertyList: entitlements, format: .xml, options: 0)
        let tmpPath = NSTemporaryDirectory().appending(UUID().uuidString).appending(".plist")
        try data.write(to: URL(fileURLWithPath: tmpPath))
        defer { try? FileManager.default.removeItem(atPath: tmpPath) }
        let ldidPath = LdidManager.ldidPath()
        let (ret, _) = try RootHelper.runProcess(ldidPath, ["-S\(tmpPath)", binaryPath], captureOutput: false)
        if ret != 0 { throw TrollStoreInstallError(code: 175) }
    }
}

// MARK: - AppManager.swift


public struct TrollStoreAppInfo {
    public let displayName: String
    public let bundleIdentifier: String
    public let appPath: String
    public let icon: UIImage?
    public let isSystemRegistered: Bool
    public let size: UInt64
    public let creationDate: Date
}

public class AppManager {
    private static let iconCache = NSCache<NSString, UIImage>()
    public static func getInstalledApps() -> [TrollStoreAppInfo] {
        var apps: [TrollStoreAppInfo] = []
        let fm = FileManager.default
        let appsRoot = TrollStorePaths.applicationsPath
        guard let containerDirs = try? fm.contentsOfDirectory(atPath: appsRoot) else { return apps }
        for containerDir in containerDirs {
            let containerPath = (appsRoot as NSString).appendingPathComponent(containerDir)
            var isDir: ObjCBool = false
            if fm.fileExists(atPath: containerPath, isDirectory: &isDir) && isDir.boolValue {
                if let appPath = findAppPath(in: containerPath) {
                    if let info = parseAppInfo(from: appPath, containerPath: containerPath) {
                        apps.append(info)
                    }
                }
            }
        }
        return apps
    }
    public static func openApp(bundleId: String) -> Bool {
        guard let cls = NSClassFromString("LSApplicationWorkspace") as? NSObject.Type else { return false }
        guard let workspace = cls.perform(NSSelectorFromString("defaultWorkspace"))?.takeUnretainedValue() as? NSObject else { return false }
        let selector = NSSelectorFromString("openApplicationWithBundleID:")
        guard workspace.responds(to: selector) else { return false }
        _ = workspace.perform(selector, with: bundleId)
        return true
    }
    private static func findAppPath(in containerPath: String) -> String? {
        let fm = FileManager.default
        guard let contents = try? fm.contentsOfDirectory(atPath: containerPath) else { return nil }
        for item in contents {
            if item.hasSuffix(".app") {
                let appPath = (containerPath as NSString).appendingPathComponent(item)
                var isDir: ObjCBool = false
                if fm.fileExists(atPath: appPath, isDirectory: &isDir) && isDir.boolValue {
                    return appPath
                }
            }
        }
        return nil
    }
    private static func parseAppInfo(from appPath: String, containerPath: String) -> TrollStoreAppInfo? {
        let fm = FileManager.default
        let infoPlistPath = (appPath as NSString).appendingPathComponent("Info.plist")
        guard let infoDict = NSDictionary(contentsOfFile: infoPlistPath) as? [String: Any] else { return nil }
        let displayName = (infoDict["CFBundleDisplayName"] as? String) ?? (infoDict["CFBundleName"] as? String) ?? ((appPath as NSString).lastPathComponent as NSString).deletingPathExtension
        let bundleId = (infoDict["CFBundleIdentifier"] as? String) ?? ""
        let icon = loadAppIcon(from: appPath, infoDict: infoDict, bundleId: bundleId)
        let isSystem = isSystemRegistered(containerPath: containerPath)
        let attributes = try? fm.attributesOfItem(atPath: appPath)
        let size = attributes?[.size] as? UInt64 ?? 0
        let creationDate = attributes?[.creationDate] as? Date ?? Date.distantPast
        return TrollStoreAppInfo(
            displayName: displayName,
            bundleIdentifier: bundleId,
            appPath: appPath,
            icon: icon,
            isSystemRegistered: isSystem,
            size: size,
            creationDate: creationDate
        )
    }
    private static func isSystemRegistered(containerPath: String) -> Bool {
        let marker = (containerPath as NSString).appendingPathComponent(TrollStorePaths.activeMarker)
        let inactive = (containerPath as NSString).appendingPathComponent(TrollStorePaths.inactiveMarker)
        let fm = FileManager.default
        if fm.fileExists(atPath: inactive) { return false }
        return fm.fileExists(atPath: marker)
    }
    private static func loadAppIcon(from appPath: String, infoDict: [String: Any], bundleId: String) -> UIImage? {
        let key = bundleId as NSString
        if let cached = iconCache.object(forKey: key) {
            return cached
        }
        var iconName: String?
        if let icons = infoDict["CFBundleIcons"] as? [String: Any],
           let primary = icons["CFBundlePrimaryIcon"] as? [String: Any] {
            if let name = primary["CFBundleIconName"] as? String {
                iconName = name
            } else if let files = primary["CFBundleIconFiles"] as? [String], let first = files.first, let last = files.last {
                iconName = first.commonPrefix(with: last)
            }
        }
        if iconName == nil, let icons = infoDict["CFBundleIcons~ipad"] as? [String: Any],
           let primary = icons["CFBundlePrimaryIcon"] as? [String: Any] {
            if let name = primary["CFBundleIconName"] as? String {
                iconName = name
            } else if let files = primary["CFBundleIconFiles"] as? [String], let first = files.first, let last = files.last {
                iconName = first.commonPrefix(with: last)
            }
        }
        guard let baseName = iconName else { return nil }
        let fm = FileManager.default
        guard let contents = try? fm.contentsOfDirectory(atPath: appPath) else { return nil }
        var candidates: [String] = []
        for item in contents {
            if item.hasPrefix(baseName) && (item.hasSuffix(".png") || (item as NSString).pathExtension.isEmpty) {
                candidates.append(item)
            }
        }
        candidates.sort()
        for candidate in candidates.reversed() {
            let fullPath = (appPath as NSString).appendingPathComponent(candidate)
            if let image = UIImage(contentsOfFile: fullPath) {
                iconCache.setObject(image, forKey: key)
                return image
            }
        }
        return nil
    }
}

// MARK: - AppListView.swift


public class AppListViewController: UIViewController {
    private let tableView = UITableView(frame: .zero, style: .insetGrouped)
    private let refreshControl = UIRefreshControl()
    private let searchController = UISearchController(searchResultsController: nil)
    private let dataSource = AppListDataSource()

    public override func viewDidLoad() {
        super.viewDidLoad()
        title = TSLocalized("Apps", comment: "")
        view.backgroundColor = .systemGroupedBackground
        navigationItem.largeTitleDisplayMode = .always
        setupTableView()
        setupNavigationBar()
        setupSearch()
        setupNotifications()
        loadApps()
    }

    public override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        loadApps()
    }

    private func setupTableView() {
        tableView.translatesAutoresizingMaskIntoConstraints = false
        tableView.dataSource = dataSource
        tableView.delegate = dataSource
        tableView.register(AppListCell.self, forCellReuseIdentifier: AppListCell.reuseIdentifier)
        tableView.estimatedRowHeight = 84
        tableView.rowHeight = UITableView.automaticDimension
        tableView.backgroundColor = .clear
        tableView.refreshControl = refreshControl
        refreshControl.addTarget(self, action: #selector(loadApps), for: .valueChanged)
        view.addSubview(tableView)
        NSLayoutConstraint.activate([
            tableView.topAnchor.constraint(equalTo: view.topAnchor),
            tableView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            tableView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            tableView.bottomAnchor.constraint(equalTo: view.bottomAnchor)
        ])
        dataSource.onReload = { [weak self] in
            self?.tableView.reloadData()
        }
        dataSource.onCellAction = { [weak self] action, appInfo in
            self?.handleCellAction(action, for: appInfo)
        }
        dataSource.onShowDetail = { [weak self] app in
            let detailVC = AppDetailViewController(appInfo: app)
            detailVC.onAction = { action in
                self?.handleCellAction(action, for: app)
            }
            self?.navigationController?.pushViewController(detailVC, animated: true)
        }
    }

    private func setupNavigationBar() {
        let appearance = UINavigationBarAppearance()
        appearance.configureWithTransparentBackground()
        appearance.backgroundEffect = UIBlurEffect(style: .systemUltraThinMaterial)
        appearance.backgroundColor = .clear
        appearance.shadowColor = .clear
        navigationController?.navigationBar.standardAppearance = appearance
        navigationController?.navigationBar.scrollEdgeAppearance = appearance
        navigationController?.navigationBar.compactAppearance = appearance
        let installAction = UIAction(title: TSLocalized("Install IPA File", comment: "")) { [weak self] _ in
            self?.installAppTapped()
        }
        let installMenu = UIMenu(children: [installAction])
        let installButton = UIBarButtonItem(image: UIImage(systemName: "plus"), menu: installMenu)
        let sortMenu = UIMenu(title: "", children: [
            UIAction(title: TSLocalized("Name Ascending", comment: "")) { [weak self] _ in self?.dataSource.sortApps(by: .nameAsc) },
            UIAction(title: TSLocalized("Name Descending", comment: "")) { [weak self] _ in self?.dataSource.sortApps(by: .nameDesc) },
            UIAction(title: TSLocalized("Install Date", comment: "")) { [weak self] _ in self?.dataSource.sortApps(by: .date) },
            UIAction(title: TSLocalized("Size", comment: "")) { [weak self] _ in self?.dataSource.sortApps(by: .size) }
        ])
        let sortButton = UIBarButtonItem(image: UIImage(systemName: "arrow.up.arrow.down"), menu: sortMenu)
        navigationItem.rightBarButtonItem = installButton
        navigationItem.leftBarButtonItem = sortButton
    }

    private func setupSearch() {
        searchController.searchResultsUpdater = dataSource
        searchController.obscuresBackgroundDuringPresentation = false
        searchController.searchBar.placeholder = TSLocalized("Search", comment: "")
        navigationItem.searchController = searchController
        definesPresentationContext = true
    }

    private func setupNotifications() {
        NotificationCenter.default.addObserver(self, selector: #selector(handleRemoteInstall(_:)), name: NSNotification.Name("TrollStoreRemoteInstall"), object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(handleEnableJIT(_:)), name: NSNotification.Name("TrollStoreEnableJIT"), object: nil)
    }

    @objc private func loadApps() {
        DispatchQueue.global(qos: .userInitiated).async { [weak self] in
            let apps = AppManager.getInstalledApps()
            DispatchQueue.main.async {
                self?.dataSource.allApps = apps
                self?.dataSource.applyFilterAndSort()
                self?.refreshControl.endRefreshing()
            }
        }
    }

    @objc private func installAppTapped() {
        let picker = UIDocumentPickerViewController(forOpeningContentTypes: [.item])
        picker.delegate = self
        picker.allowsMultipleSelection = false
        present(picker, animated: true)
    }

    @objc private func handleRemoteInstall(_ notification: Notification) {
        guard let urlString = notification.object as? String, let url = URL(string: urlString) else { return }
        InstallationProgressController.show(on: self, message: TSLocalized("Downloading", comment: ""))
        InstallationManager.downloadIPA(url: url, progress: { _ in }, completion: { [weak self] path, error in
            InstallationProgressController.hide()
            if let path = path {
                self?.installIPAFromFile(path: path, isRemote: true)
            } else if let error = error {
                ErrorHandler.showError(error, on: self)
            }
        })
    }

    @objc private func handleEnableJIT(_ notification: Notification) {
        guard let bundleId = notification.object as? String else { return }
        InstallationProgressController.show(on: self, message: TSLocalized("Enabling JIT", comment: ""))
        DispatchQueue.global(qos: .userInitiated).async { [weak self] in
            do {
                try InstallationManager.enableJIT(bundleId: bundleId)
                DispatchQueue.main.async {
                    InstallationProgressController.hide()
                    ErrorHandler.showSuccess(on: self, message: TSLocalized("JIT Enabled", comment: ""))
                }
            } catch {
                DispatchQueue.main.async {
                    InstallationProgressController.hide()
                    ErrorHandler.showError(error, on: self)
                }
            }
        }
    }

    private func handleCellAction(_ action: AppCellAction, for appInfo: TrollStoreAppInfo) {
        switch action {
        case .open:
            _ = AppManager.openApp(bundleId: appInfo.bundleIdentifier)
        case .uninstall:
            confirmUninstall(appInfo)
        case .enableJIT:
            enableJIT(appInfo)
        case .changeRegistration:
            changeRegistration(appInfo)
        case .editEntitlements:
            editEntitlements(appInfo)
        }
    }

    private func confirmUninstall(_ appInfo: TrollStoreAppInfo) {
        let alert = UIAlertController(
            title: TSLocalized("Uninstall App", comment: ""),
            message: String(format: TSLocalized("Are you sure you want to uninstall %@?", comment: ""), appInfo.displayName),
            preferredStyle: .alert
        )
        let cancelAction = UIAlertAction(title: TSLocalized("Cancel", comment: ""), style: .cancel)
        let uninstallAction = UIAlertAction(title: TSLocalized("Uninstall", comment: ""), style: .destructive) { [weak self] _ in
            self?.uninstallApp(appInfo)
        }
        alert.addAction(cancelAction)
        alert.addAction(uninstallAction)
        present(alert, animated: true)
    }

    private func uninstallApp(_ appInfo: TrollStoreAppInfo) {
        InstallationProgressController.show(on: self)
        let useCustom = UserDefaults.standard.integer(forKey: TrollStoreDefaults.uninstallationMethod) == 1
        DispatchQueue.global(qos: .userInitiated).async { [weak self] in
            do {
                try InstallationManager.uninstallApp(bundleId: appInfo.bundleIdentifier, useCustomMethod: useCustom)
                DispatchQueue.main.async {
                    InstallationProgressController.hide()
                    self?.loadApps()
                }
            } catch {
                DispatchQueue.main.async {
                    InstallationProgressController.hide()
                    ErrorHandler.showError(error, on: self)
                }
            }
        }
    }

    private func enableJIT(_ appInfo: TrollStoreAppInfo) {
        InstallationProgressController.show(on: self, message: TSLocalized("Enabling JIT", comment: ""))
        DispatchQueue.global(qos: .userInitiated).async { [weak self] in
            do {
                try InstallationManager.enableJIT(bundleId: appInfo.bundleIdentifier)
                DispatchQueue.main.async {
                    InstallationProgressController.hide()
                    ErrorHandler.showSuccess(on: self, message: TSLocalized("JIT Enabled", comment: ""))
                }
            } catch {
                DispatchQueue.main.async {
                    InstallationProgressController.hide()
                    ErrorHandler.showError(error, on: self)
                }
            }
        }
    }

    private func changeRegistration(_ appInfo: TrollStoreAppInfo) {
        let alert = UIAlertController(
            title: TSLocalized("Change Registration", comment: ""),
            message: nil,
            preferredStyle: .actionSheet
        )
        let systemAction = UIAlertAction(title: TSLocalized("System", comment: ""), style: .default) { [weak self] _ in
            self?.setRegistration(appInfo, isSystem: true)
        }
        let userAction = UIAlertAction(title: TSLocalized("User", comment: ""), style: .default) { [weak self] _ in
            self?.setRegistration(appInfo, isSystem: false)
        }
        let cancelAction = UIAlertAction(title: TSLocalized("Cancel", comment: ""), style: .cancel)
        alert.addAction(systemAction)
        alert.addAction(userAction)
        alert.addAction(cancelAction)
        if let popover = alert.popoverPresentationController {
            popover.sourceView = self.view
            popover.sourceRect = CGRect(x: self.view.bounds.midX, y: self.view.bounds.midY, width: 0, height: 0)
        }
        present(alert, animated: true)
    }

    private func setRegistration(_ appInfo: TrollStoreAppInfo, isSystem: Bool) {
        InstallationProgressController.show(on: self)
        DispatchQueue.global(qos: .userInitiated).async { [weak self] in
            do {
                try InstallationManager.changeRegistration(appPath: appInfo.appPath, isSystem: isSystem)
                DispatchQueue.main.async {
                    InstallationProgressController.hide()
                    self?.loadApps()
                }
            } catch {
                DispatchQueue.main.async {
                    InstallationProgressController.hide()
                    ErrorHandler.showError(error, on: self)
                }
            }
        }
    }

    private func editEntitlements(_ appInfo: TrollStoreAppInfo) {
        let infoPlistPath = (appInfo.appPath as NSString).appendingPathComponent("Info.plist")
        guard let infoDict = NSDictionary(contentsOfFile: infoPlistPath) as? [String: Any],
              let executable = infoDict["CFBundleExecutable"] as? String else { return }
        let binaryPath = (appInfo.appPath as NSString).appendingPathComponent(executable)
        let editor = EntitlementsTreeViewController(appInfo: appInfo, binaryPath: binaryPath)
        navigationController?.pushViewController(editor, animated: true)
    }
}

extension AppListViewController: UIDocumentPickerDelegate {
    public func documentPicker(_ controller: UIDocumentPickerViewController, didPickDocumentsAt urls: [URL]) {
        guard let url = urls.first else { return }
        _ = url.startAccessingSecurityScopedResource()
        defer { url.stopAccessingSecurityScopedResource() }
        let tempPath = NSTemporaryDirectory().appending(UUID().uuidString).appending(".ipa")
        do {
            try FileManager.default.copyItem(at: url, to: URL(fileURLWithPath: tempPath))
            installIPAFromFile(path: tempPath, isRemote: false)
        } catch {
            ErrorHandler.showError(error, on: self)
        }
    }

    private func installIPAFromFile(path: String, isRemote: Bool) {
        let config = UserDefaults.standard.integer(forKey: TrollStoreDefaults.installAlertConfiguration)
        var shouldShowAlert = true
        if config == 2 { shouldShowAlert = false }
        else if config == 1 && !isRemote { shouldShowAlert = false }
        if shouldShowAlert {
            guard let infoDict = InstallationManager.parseIPA(path: path) else {
                ErrorHandler.showError(TrollStoreInstallError(code: 167), on: self)
                try? FileManager.default.removeItem(atPath: path)
                return
            }
            let name = (infoDict["CFBundleDisplayName"] as? String) ?? (infoDict["CFBundleName"] as? String) ?? TSLocalized("App", comment: "Fallback application name")
            let version = (infoDict["CFBundleShortVersionString"] as? String) ?? "1.0"
            let bundleId = (infoDict["CFBundleIdentifier"] as? String) ?? ""
            let size = (try? FileManager.default.attributesOfItem(atPath: path)[.size] as? UInt64) ?? 0
            let sizeStr = ByteCountFormatter.string(fromByteCount: Int64(size), countStyle: .file)
            let messageFormat = TSLocalized("Version: %@\nBundle ID: %@\nSize: %@", comment: "IPA installation confirmation details")
            let message = String(format: messageFormat, version, bundleId, sizeStr)
            let alert = UIAlertController(title: name, message: message, preferredStyle: .alert)
            let installAction = UIAlertAction(title: TSLocalized("Install", comment: ""), style: .default) { [weak self] _ in
                self?.performInstall(path: path)
            }
            let cancelAction = UIAlertAction(title: TSLocalized("Cancel", comment: ""), style: .cancel) { _ in
                try? FileManager.default.removeItem(atPath: path)
            }
            alert.addAction(installAction)
            alert.addAction(cancelAction)
            present(alert, animated: true)
        } else {
            performInstall(path: path)
        }
    }

    private func performInstall(path: String) {
        InstallationProgressController.show(on: self)
        let useInstalld = UserDefaults.standard.integer(forKey: TrollStoreDefaults.installationMethod) == 0
        DispatchQueue.global(qos: .userInitiated).async { [weak self] in
            do {
                try InstallationManager.installIPA(path: path, force: false, useInstalldMethod: useInstalld, skipUICache: false)
                DispatchQueue.main.async {
                    InstallationProgressController.hide()
                    self?.loadApps()
                    try? FileManager.default.removeItem(atPath: path)
                }
            } catch let error as TrollStoreInstallError {
                DispatchQueue.main.async {
                    InstallationProgressController.hide()
                    if error.code == 171 {
                        self?.showForceInstallAlert(path: path, error: error)
                    } else {
                        ErrorHandler.showError(error, on: self)
                    }
                    try? FileManager.default.removeItem(atPath: path)
                }
            } catch {
                DispatchQueue.main.async {
                    InstallationProgressController.hide()
                    ErrorHandler.showError(error, on: self)
                    try? FileManager.default.removeItem(atPath: path)
                }
            }
        }
    }

    private func showForceInstallAlert(path: String, error: TrollStoreInstallError) {
        let alert = UIAlertController(
            title: TSLocalized("Install Error", comment: ""),
            message: error.errorDescription,
            preferredStyle: .alert
        )
        let closeAction = UIAlertAction(title: TSLocalized("Close", comment: ""), style: .cancel)
        let forceAction = UIAlertAction(title: TSLocalized("Force Install", comment: ""), style: .destructive) { [weak self] _ in
            self?.forceInstallIPA(path: path)
        }
        alert.addAction(closeAction)
        alert.addAction(forceAction)
        present(alert, animated: true)
    }

    private func forceInstallIPA(path: String) {
        InstallationProgressController.show(on: self)
        let useInstalld = UserDefaults.standard.integer(forKey: TrollStoreDefaults.installationMethod) == 0
        DispatchQueue.global(qos: .userInitiated).async { [weak self] in
            do {
                try InstallationManager.installIPA(path: path, force: true, useInstalldMethod: useInstalld, skipUICache: false)
                DispatchQueue.main.async {
                    InstallationProgressController.hide()
                    self?.loadApps()
                    try? FileManager.default.removeItem(atPath: path)
                }
            } catch {
                DispatchQueue.main.async {
                    InstallationProgressController.hide()
                    ErrorHandler.showError(error, on: self)
                    try? FileManager.default.removeItem(atPath: path)
                }
            }
        }
    }
}

public enum AppCellAction {
    case open
    case uninstall
    case enableJIT
    case changeRegistration
    case editEntitlements
}

private class AppListDataSource: NSObject, UITableViewDataSource, UITableViewDelegate, UISearchResultsUpdating {
    var allApps: [TrollStoreAppInfo] = []
    var filteredApps: [TrollStoreAppInfo] = []
    var searchText: String = ""
    var sortType: SortType = .nameAsc

    enum SortType {
        case nameAsc, nameDesc, date, size
    }

    var onReload: (() -> Void)?
    var onCellAction: ((AppCellAction, TrollStoreAppInfo) -> Void)?
    var onShowDetail: ((TrollStoreAppInfo) -> Void)?

    func updateSearchResults(for searchController: UISearchController) {
        searchText = searchController.searchBar.text ?? ""
        applyFilterAndSort()
    }

    func applyFilterAndSort() {
        if searchText.isEmpty {
            filteredApps = allApps
        } else {
            filteredApps = allApps.filter { $0.displayName.localizedCaseInsensitiveContains(searchText) || $0.bundleIdentifier.localizedCaseInsensitiveContains(searchText) }
        }
        switch sortType {
        case .nameAsc:
            filteredApps.sort { $0.displayName.localizedStandardCompare($1.displayName) == .orderedAscending }
        case .nameDesc:
            filteredApps.sort { $0.displayName.localizedStandardCompare($1.displayName) == .orderedDescending }
        case .date:
            filteredApps.sort { $0.creationDate > $1.creationDate }
        case .size:
            filteredApps.sort { $0.size > $1.size }
        }
        onReload?()
    }

    func sortApps(by type: SortType) {
        sortType = type
        applyFilterAndSort()
    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return filteredApps.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: AppListCell.reuseIdentifier, for: indexPath) as! AppListCell
        let app = filteredApps[indexPath.row]
        cell.configure(with: app)
        cell.onMoreActions = { [weak self, weak tableView] in
            self?.showActionsMenu(for: app, at: tableView, indexPath: indexPath)
        }
        return cell
    }

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        let app = filteredApps[indexPath.row]
        onShowDetail?(app)
    }

    func tableView(_ tableView: UITableView, contextMenuConfigurationForRowAt indexPath: IndexPath, point: CGPoint) -> UIContextMenuConfiguration? {
        let app = filteredApps[indexPath.row]
        return UIContextMenuConfiguration(identifier: nil, previewProvider: nil) { _ in
            let openAction = UIAction(title: TSLocalized("Open", comment: ""), image: UIImage(systemName: "play")) { [weak self] _ in
                self?.onCellAction?(.open, app)
            }
            let jitAction = UIAction(title: TSLocalized("Enable JIT", comment: ""), image: UIImage(systemName: "bolt")) { [weak self] _ in
                self?.onCellAction?(.enableJIT, app)
            }
            let registrationAction = UIAction(title: TSLocalized("Change Registration", comment: ""), image: UIImage(systemName: "arrow.triangle.2.circlepath")) { [weak self] _ in
                self?.onCellAction?(.changeRegistration, app)
            }
            let entitlementsAction = UIAction(title: TSLocalized("Edit Entitlements", comment: ""), image: UIImage(systemName: "doc.text")) { [weak self] _ in
                self?.onCellAction?(.editEntitlements, app)
            }
            let uninstallAction = UIAction(title: TSLocalized("Uninstall", comment: ""), image: UIImage(systemName: "trash"), attributes: .destructive) { [weak self] _ in
                self?.onCellAction?(.uninstall, app)
            }
            return UIMenu(title: "", children: [openAction, jitAction, registrationAction, entitlementsAction, uninstallAction])
        }
    }

    private func showActionsMenu(for app: TrollStoreAppInfo, at tableView: UITableView?, indexPath: IndexPath) {
        guard let tableView = tableView, let cell = tableView.cellForRow(at: indexPath) else { return }
        let alert = UIAlertController(title: nil, message: nil, preferredStyle: .actionSheet)
        let openAction = UIAlertAction(title: TSLocalized("Open", comment: ""), style: .default) { [weak self] _ in
            self?.onCellAction?(.open, app)
        }
        let jitAction = UIAlertAction(title: TSLocalized("Enable JIT", comment: ""), style: .default) { [weak self] _ in
            self?.onCellAction?(.enableJIT, app)
        }
        let registrationAction = UIAlertAction(title: TSLocalized("Change Registration", comment: ""), style: .default) { [weak self] _ in
            self?.onCellAction?(.changeRegistration, app)
        }
        let entitlementsAction = UIAlertAction(title: TSLocalized("Edit Entitlements", comment: ""), style: .default) { [weak self] _ in
            self?.onCellAction?(.editEntitlements, app)
        }
        let uninstallAction = UIAlertAction(title: TSLocalized("Uninstall", comment: ""), style: .destructive) { [weak self] _ in
            self?.onCellAction?(.uninstall, app)
        }
        let cancelAction = UIAlertAction(title: TSLocalized("Cancel", comment: ""), style: .cancel)
        alert.addAction(openAction)
        alert.addAction(jitAction)
        alert.addAction(registrationAction)
        alert.addAction(entitlementsAction)
        alert.addAction(uninstallAction)
        alert.addAction(cancelAction)
        if let popover = alert.popoverPresentationController {
            popover.sourceView = cell
            popover.sourceRect = cell.bounds
        }
        tableView.window?.rootViewController?.present(alert, animated: true)
    }
}

private class AppListCell: UITableViewCell {
    static let reuseIdentifier = "AppListCell"
    private let iconImageView = UIImageView()
    private let nameLabel = UILabel()
    private let bundleIdLabel = UILabel()
    private let registrationBadge = UILabel()
    private let moreButton = UIButton(type: .system)
    var onMoreActions: (() -> Void)?

    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        setupUI()
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    private func setupUI() {
        backgroundColor = .clear
        contentView.backgroundColor = .clear
        let bgView = TrollStoreGlassView()
        bgView.cornerRadius = 16
        bgView.intensity = 0.82
        backgroundView = bgView

        let selBgView = TrollStoreGlassView()
        selBgView.cornerRadius = 16
        selBgView.intensity = 1.0
        selectedBackgroundView = selBgView

        iconImageView.translatesAutoresizingMaskIntoConstraints = false
        iconImageView.contentMode = .scaleAspectFill
        iconImageView.layer.cornerRadius = 12
        iconImageView.layer.cornerCurve = .continuous
        iconImageView.layer.masksToBounds = true
        iconImageView.tintColor = .label
        contentView.addSubview(iconImageView)

        nameLabel.translatesAutoresizingMaskIntoConstraints = false
        nameLabel.font = .systemFont(ofSize: 17, weight: .semibold)
        nameLabel.textColor = .label
        contentView.addSubview(nameLabel)

        bundleIdLabel.translatesAutoresizingMaskIntoConstraints = false
        bundleIdLabel.font = .systemFont(ofSize: 13)
        bundleIdLabel.textColor = .secondaryLabel
        contentView.addSubview(bundleIdLabel)

        registrationBadge.translatesAutoresizingMaskIntoConstraints = false
        registrationBadge.font = .systemFont(ofSize: 11, weight: .semibold)
        registrationBadge.textAlignment = .center
        registrationBadge.layer.cornerRadius = 4
        registrationBadge.layer.cornerCurve = .continuous
        registrationBadge.layer.masksToBounds = true
        contentView.addSubview(registrationBadge)

        moreButton.translatesAutoresizingMaskIntoConstraints = false
        let configuration = UIImage.SymbolConfiguration(pointSize: 18, weight: .medium)
        moreButton.setImage(UIImage(systemName: "ellipsis", withConfiguration: configuration), for: .normal)
        moreButton.tintColor = .systemBlue
        moreButton.addTarget(self, action: #selector(moreButtonTapped), for: .touchUpInside)
        contentView.addSubview(moreButton)

        NSLayoutConstraint.activate([
            iconImageView.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 20),
            iconImageView.centerYAnchor.constraint(equalTo: contentView.centerYAnchor),
            iconImageView.widthAnchor.constraint(equalToConstant: 50),
            iconImageView.heightAnchor.constraint(equalToConstant: 50),
            nameLabel.leadingAnchor.constraint(equalTo: iconImageView.trailingAnchor, constant: 16),
            nameLabel.topAnchor.constraint(equalTo: contentView.topAnchor, constant: 12),
            nameLabel.trailingAnchor.constraint(lessThanOrEqualTo: moreButton.leadingAnchor, constant: -12),
            bundleIdLabel.leadingAnchor.constraint(equalTo: nameLabel.leadingAnchor),
            bundleIdLabel.topAnchor.constraint(equalTo: nameLabel.bottomAnchor, constant: 2),
            bundleIdLabel.trailingAnchor.constraint(equalTo: nameLabel.trailingAnchor),
            registrationBadge.leadingAnchor.constraint(equalTo: nameLabel.leadingAnchor),
            registrationBadge.topAnchor.constraint(equalTo: bundleIdLabel.bottomAnchor, constant: 4),
            registrationBadge.bottomAnchor.constraint(equalTo: contentView.bottomAnchor, constant: -12),
            registrationBadge.widthAnchor.constraint(greaterThanOrEqualToConstant: 44),
            registrationBadge.heightAnchor.constraint(equalToConstant: 16),
            moreButton.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -16),
            moreButton.centerYAnchor.constraint(equalTo: contentView.centerYAnchor),
            moreButton.widthAnchor.constraint(equalToConstant: 36),
            moreButton.heightAnchor.constraint(equalToConstant: 36)
        ])
    }

    override func traitCollectionDidChange(_ previousTraitCollection: UITraitCollection?) {
        super.traitCollectionDidChange(previousTraitCollection)
        if traitCollection.userInterfaceStyle == .dark {
            backgroundView?.layer.borderColor = UIColor.white.withAlphaComponent(0.08).cgColor
        } else {
            backgroundView?.layer.borderColor = UIColor.white.withAlphaComponent(0.18).cgColor
        }
    }

    func configure(with app: TrollStoreAppInfo) {
        iconImageView.image = app.icon ?? UIImage(systemName: "app")
        nameLabel.text = app.displayName
        bundleIdLabel.text = app.bundleIdentifier
        if app.isSystemRegistered {
            registrationBadge.text = TSLocalized("System", comment: "")
            registrationBadge.backgroundColor = .systemGreen
            registrationBadge.textColor = .white
        } else {
            registrationBadge.text = TSLocalized("User", comment: "")
            registrationBadge.backgroundColor = .systemGray
            registrationBadge.textColor = .white
        }
    }

    @objc private func moreButtonTapped() {
        onMoreActions?()
    }
}

class AppDetailViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    private let appInfo: TrollStoreAppInfo
    private let tableView = UITableView(frame: .zero, style: .insetGrouped)
    private var entitlements: [String: Any] = [:]
    var onAction: ((AppCellAction) -> Void)?

    init(appInfo: TrollStoreAppInfo) {
        self.appInfo = appInfo
        super.init(nibName: nil, bundle: nil)
    }

    required init?(coder: NSCoder) { fatalError() }

    override func viewDidLoad() {
        super.viewDidLoad()
        title = appInfo.displayName
        view.backgroundColor = .systemGroupedBackground
        tableView.dataSource = self
        tableView.delegate = self
        tableView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(tableView)
        NSLayoutConstraint.activate([
            tableView.topAnchor.constraint(equalTo: view.topAnchor),
            tableView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            tableView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            tableView.bottomAnchor.constraint(equalTo: view.bottomAnchor)
        ])
        let infoPlistPath = (appInfo.appPath as NSString).appendingPathComponent("Info.plist")
        if let infoDict = NSDictionary(contentsOfFile: infoPlistPath) as? [String: Any],
           let executable = infoDict["CFBundleExecutable"] as? String {
            let binaryPath = (appInfo.appPath as NSString).appendingPathComponent(executable)
            DispatchQueue.global(qos: .userInitiated).async { [weak self] in
                let ent = (try? InstallationManager.dumpEntitlements(binaryPath: binaryPath)) ?? [:]
                DispatchQueue.main.async {
                    self?.entitlements = ent
                    self?.tableView.reloadData()
                }
            }
        }
    }

    func numberOfSections(in tableView: UITableView) -> Int { return 4 }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if section == 0 { return 4 }
        if section == 1 { return 4 }
        if section == 2 { return entitlements.count }
        if section == 3 { return 1 }
        return 0
    }

    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        if section == 0 { return TSLocalized("Info", comment: "") }
        if section == 1 { return TSLocalized("Actions", comment: "") }
        if section == 2 { return TSLocalized("Entitlements", comment: "") }
        return nil
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell") ?? UITableViewCell(style: .value1, reuseIdentifier: "Cell")
        if indexPath.section == 0 {
            if indexPath.row == 0 {
                cell.textLabel?.text = TSLocalized("Bundle ID", comment: "")
                cell.detailTextLabel?.text = appInfo.bundleIdentifier
            } else if indexPath.row == 1 {
                cell.textLabel?.text = TSLocalized("Registration", comment: "")
                cell.detailTextLabel?.text = appInfo.isSystemRegistered ? TSLocalized("System", comment: "") : TSLocalized("User", comment: "")
            } else if indexPath.row == 2 {
                cell.textLabel?.text = TSLocalized("Path", comment: "")
                cell.detailTextLabel?.text = appInfo.appPath
            } else {
                cell.textLabel?.text = TSLocalized("Size", comment: "")
                cell.detailTextLabel?.text = ByteCountFormatter.string(fromByteCount: Int64(appInfo.size), countStyle: .file)
            }
            cell.selectionStyle = .none
            cell.textLabel?.textColor = .secondaryLabel
            cell.detailTextLabel?.textColor = .label
            return cell
        } else if indexPath.section == 1 {
            if indexPath.row == 0 {
                cell.textLabel?.text = TSLocalized("Open", comment: "")
                cell.textLabel?.textColor = .systemBlue
            } else if indexPath.row == 1 {
                cell.textLabel?.text = TSLocalized("Enable JIT", comment: "")
                cell.textLabel?.textColor = .systemBlue
            } else if indexPath.row == 2 {
                cell.textLabel?.text = TSLocalized("Change Registration", comment: "")
                cell.textLabel?.textColor = .systemBlue
            } else {
                cell.textLabel?.text = TSLocalized("Uninstall", comment: "")
                cell.textLabel?.textColor = .systemRed
            }
        } else if indexPath.section == 2 {
            let keys = entitlements.keys.sorted()
            let key = keys[indexPath.row]
            cell.textLabel?.text = key
            cell.detailTextLabel?.text = String(describing: entitlements[key] ?? "")
        } else if indexPath.section == 3 {
            cell.textLabel?.text = TSLocalized("Edit Entitlements", comment: "")
            cell.textLabel?.textColor = .systemBlue
        }
        return cell
    }

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        if indexPath.section == 1 {
            if indexPath.row == 0 { onAction?(.open) }
            else if indexPath.row == 1 { onAction?(.enableJIT) }
            else if indexPath.row == 2 { onAction?(.changeRegistration) }
            else if indexPath.row == 3 { onAction?(.uninstall) }
        } else if indexPath.section == 3 {
            onAction?(.editEntitlements)
        }
    }
}

public class InstallationProgressController {
    private static var overlayView: UIView?
    public static func show(on viewController: UIViewController, message: String? = nil) {
        guard overlayView == nil else { return }
        let overlay = UIView(frame: viewController.view.bounds)
        overlay.backgroundColor = UIColor.black.withAlphaComponent(0.4)
        overlay.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        let containerView = TrollStoreGlassContainer()
        containerView.translatesAutoresizingMaskIntoConstraints = false
        containerView.glass.cornerRadius = 20
        containerView.glass.intensity = 1.0
        overlay.addSubview(containerView)
        let indicator = UIActivityIndicatorView(style: .large)
        indicator.translatesAutoresizingMaskIntoConstraints = false
        indicator.startAnimating()
        containerView.content.addSubview(indicator)
        let label = UILabel()
        label.translatesAutoresizingMaskIntoConstraints = false
        label.font = .systemFont(ofSize: 16, weight: .medium)
        label.textColor = .label
        label.textAlignment = .center
        label.text = message ?? TSLocalized("Installing", comment: "")
        containerView.content.addSubview(label)
        NSLayoutConstraint.activate([
            containerView.centerXAnchor.constraint(equalTo: overlay.centerXAnchor),
            containerView.centerYAnchor.constraint(equalTo: overlay.centerYAnchor),
            containerView.widthAnchor.constraint(equalToConstant: 200),
            containerView.heightAnchor.constraint(equalToConstant: 120),
            indicator.centerXAnchor.constraint(equalTo: containerView.centerXAnchor),
            indicator.topAnchor.constraint(equalTo: containerView.topAnchor, constant: 20),
            label.leadingAnchor.constraint(equalTo: containerView.leadingAnchor, constant: 16),
            label.trailingAnchor.constraint(equalTo: containerView.trailingAnchor, constant: -16),
            label.topAnchor.constraint(equalTo: indicator.bottomAnchor, constant: 12)
        ])
        viewController.view.addSubview(overlay)
        overlayView = overlay
    }
    public static func hide() {
        overlayView?.removeFromSuperview()
        overlayView = nil
    }
}

public class ErrorHandler {
    public static func showError(_ error: Error, on viewController: UIViewController?) {
        let alert = UIAlertController(
            title: TSLocalized("Error", comment: ""),
            message: error.localizedDescription,
            preferredStyle: .alert
        )
        if let trollError = error as? TrollStoreInstallError {
            alert.title = String(format: TSLocalized("Error %d", comment: ""), trollError.code)
            let unknownError = TSLocalized("Unknown Error", comment: "")
            let copyLogAction = UIAlertAction(title: TSLocalized("Copy Debug Log", comment: ""), style: .default) { _ in
                UIPasteboard.general.string = "Error Code: " + String(trollError.code) + "\n " + (trollError.errorDescription ?? unknownError)
            }
            alert.addAction(copyLogAction)
        }
        let closeAction = UIAlertAction(title: TSLocalized("Close", comment: ""), style: .default)
        alert.addAction(closeAction)
        viewController?.present(alert, animated: true)
    }
    public static func showSuccess(on viewController: UIViewController?, message: String) {
        let alert = UIAlertController(
            title: TSLocalized("Success", comment: ""),
            message: message,
            preferredStyle: .alert
        )
        let closeAction = UIAlertAction(title: TSLocalized("Close", comment: ""), style: .default)
        alert.addAction(closeAction)
        viewController?.present(alert, animated: true)
    }
}

private class EntitlementNode: NSObject {
    var key: String
    var value: Any?
    var isDictionary: Bool
    var isArray: Bool
    var children: [EntitlementNode]
    weak var parent: EntitlementNode?
    init(key: String, value: Any?) {
        self.key = key
        self.value = value
        if value is [String: Any] {
            self.isDictionary = true
            self.isArray = false
        } else if value is [Any] {
            self.isDictionary = false
            self.isArray = true
        } else {
            self.isDictionary = false
            self.isArray = false
        }
        self.children = []
        super.init()
        if let dict = value as? [String: Any] {
            for k in dict.keys.sorted() {
                let child = EntitlementNode(key: k, value: dict[k])
                child.parent = self
                self.children.append(child)
            }
        } else if let array = value as? [Any] {
            for (index, element) in array.enumerated() {
                let childKey = "[" + String(index) + "]"
                let child = EntitlementNode(key: childKey, value: element)
                child.parent = self
                self.children.append(child)
            }
        }
    }
    func rebuildChildren() {
        var newChildren: [EntitlementNode] = []
        if let dict = value as? [String: Any] {
            for k in dict.keys.sorted() {
                let child = EntitlementNode(key: k, value: dict[k])
                child.parent = self
                newChildren.append(child)
            }
        } else if let array = value as? [Any] {
            for (index, element) in array.enumerated() {
                let childKey = "[" + String(index) + "]"
                let child = EntitlementNode(key: childKey, value: element)
                child.parent = self
                newChildren.append(child)
            }
        }
        children = newChildren
    }
}

private enum EntitlementValueType: Int, CaseIterable {
    case string, boolean, number, dictionary, array, data, date
    var name: String {
        switch self {
        case .string: return "String"
        case .boolean: return "Boolean"
        case .number: return "Number"
        case .dictionary: return "Dictionary"
        case .array: return "Array"
        case .data: return "Data"
        case .date: return "Date"
        }
    }
    static func from(_ value: Any?) -> EntitlementValueType {
        guard let v = value else { return .string }
        if v is Bool { return .boolean }
        if v is Int || v is Double || v is Float { return .number }
        if v is [String: Any] { return .dictionary }
        if v is [Any] { return .array }
        if v is Data { return .data }
        if v is Date { return .date }
        return .string
    }
}

public class EntitlementsTreeViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    private var treeView: UITableView!
    private let appInfo: TrollStoreAppInfo
    private let binaryPath: String
    private var entitlements: [String: Any] = [:]
    private var rootNodes: [EntitlementNode] = []
    private var visibleNodes: [(node: EntitlementNode, level: Int)] = []
    private var expandedNodes: Set<ObjectIdentifier> = []
    public init(appInfo: TrollStoreAppInfo, binaryPath: String) {
        self.appInfo = appInfo
        self.binaryPath = binaryPath
        super.init(nibName: nil, bundle: nil)
    }
    required init?(coder: NSCoder) { fatalError() }
    public override func viewDidLoad() {
        super.viewDidLoad()
        title = TSLocalized("Edit Entitlements", comment: "")
        view.backgroundColor = .systemGroupedBackground
        navigationItem.rightBarButtonItems = [
            UIBarButtonItem(barButtonSystemItem: .save, target: self, action: #selector(saveTapped)),
            UIBarButtonItem(barButtonSystemItem: .add, target: self, action: #selector(addTapped))
        ]
        treeView = UITableView(frame: view.bounds, style: .insetGrouped)
        treeView.translatesAutoresizingMaskIntoConstraints = false
        treeView.dataSource = self
        treeView.delegate = self
        treeView.register(UITableViewCell.self, forCellReuseIdentifier: "Cell")
        view.addSubview(treeView)
        NSLayoutConstraint.activate([
            treeView.topAnchor.constraint(equalTo: view.topAnchor),
            treeView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            treeView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            treeView.bottomAnchor.constraint(equalTo: view.bottomAnchor)
        ])
        loadEntitlements()
    }
    private func loadEntitlements() {
        DispatchQueue.global(qos: .userInitiated).async { [weak self] in
            guard let self = self else { return }
            let ent = (try? InstallationManager.dumpEntitlements(binaryPath: self.binaryPath)) ?? [:]
            DispatchQueue.main.async {
                self.entitlements = ent
                self.rebuildRootNodes()
                self.rebuildVisibleNodes()
                self.treeView.reloadData()
            }
        }
    }
    private func rebuildRootNodes() {
        var nodes: [EntitlementNode] = []
        for key in entitlements.keys.sorted() {
            nodes.append(EntitlementNode(key: key, value: entitlements[key]))
        }
        rootNodes = nodes
    }
    private func rebuildVisibleNodes() {
        visibleNodes.removeAll()
        for node in rootNodes {
            flattenNode(node, level: 0)
        }
    }
    private func flattenNode(_ node: EntitlementNode, level: Int) {
        visibleNodes.append((node, level))
        if expandedNodes.contains(ObjectIdentifier(node)) {
            for child in node.children {
                flattenNode(child, level: level + 1)
            }
        }
    }
    @objc private func saveTapped() {
        do {
            try InstallationManager.setEntitlements(binaryPath: binaryPath, entitlements: entitlements)
            let alert = UIAlertController(title: TSLocalized("Success", comment: ""), message: TSLocalized("Entitlements Saved", comment: ""), preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: TSLocalized("Close", comment: ""), style: .default) { [weak self] _ in
                self?.navigationController?.popViewController(animated: true)
            })
            present(alert, animated: true)
        } catch {
            ErrorHandler.showError(error, on: self)
        }
    }
    @objc private func addTapped() {
        let alert = UIAlertController(title: TSLocalized("Add Key", comment: ""), message: nil, preferredStyle: .alert)
        alert.addTextField { tf in tf.placeholder = TSLocalized("Key", comment: "Entitlement key input placeholder") }
        alert.addAction(UIAlertAction(title: TSLocalized("Cancel", comment: ""), style: .cancel))
        alert.addAction(UIAlertAction(title: TSLocalized("Add", comment: ""), style: .default) { [weak self] _ in
            guard let self = self else { return }
            guard let key = alert.textFields?.first?.text, !key.isEmpty else { return }
            self.entitlements[key] = ""
            self.rebuildRootNodes()
            self.rebuildVisibleNodes()
            self.treeView.reloadData()
        })
        present(alert, animated: true)
    }
    public func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return visibleNodes.count
    }
    public func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath)
        let item = visibleNodes[indexPath.row]
        cell.textLabel?.text = item.node.key
        cell.indentationLevel = item.level
        cell.indentationWidth = 20
        if item.node.isDictionary || item.node.isArray {
            cell.accessoryType = .disclosureIndicator
            cell.detailTextLabel?.text = item.node.isDictionary ? TSLocalized("[Dictionary]", comment: "Entitlements tree dictionary marker") : TSLocalized("[Array]", comment: "Entitlements tree array marker")
        } else {
            cell.accessoryType = .none
            if let v = item.node.value {
                if let b = v as? Bool { cell.detailTextLabel?.text = b ? TSLocalized("true", comment: "Boolean entitlement value") : TSLocalized("false", comment: "Boolean entitlement value") }
                else { cell.detailTextLabel?.text = String(describing: v) }
            } else {
                cell.detailTextLabel?.text = ""
            }
        }
        return cell
    }
    public func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        let item = visibleNodes[indexPath.row]
        if item.node.isDictionary || item.node.isArray {
            let id = ObjectIdentifier(item.node)
            if expandedNodes.contains(id) {
                expandedNodes.remove(id)
            } else {
                expandedNodes.insert(id)
            }
            rebuildVisibleNodes()
            treeView.reloadData()
        } else {
            editNodeValue(item.node)
        }
    }
    public func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            let item = visibleNodes[indexPath.row]
            deleteNode(item.node)
        }
    }
    private func editNodeValue(_ node: EntitlementNode) {
        let type = EntitlementValueType.from(node.value)
        switch type {
        case .boolean:
            node.value = !((node.value as? Bool) ?? false)
            applyNodeChange(node)
        case .string:
            promptString(node: node)
        case .number:
            promptNumber(node: node)
        default: break
        }
    }
    private func promptString(node: EntitlementNode) {
        let alert = UIAlertController(title: node.key, message: nil, preferredStyle: .alert)
        alert.addTextField { tf in tf.text = node.value as? String }
        alert.addAction(UIAlertAction(title: TSLocalized("Cancel", comment: ""), style: .cancel))
        alert.addAction(UIAlertAction(title: TSLocalized("Save", comment: ""), style: .default) { [weak self] _ in
            guard let self = self else { return }
            node.value = alert.textFields?.first?.text ?? ""
            self.applyNodeChange(node)
        })
        present(alert, animated: true)
    }
    private func promptNumber(node: EntitlementNode) {
        let alert = UIAlertController(title: node.key, message: nil, preferredStyle: .alert)
        alert.addTextField { tf in
            tf.keyboardType = .numbersAndPunctuation
            tf.text = String(describing: node.value ?? 0)
        }
        alert.addAction(UIAlertAction(title: TSLocalized("Cancel", comment: ""), style: .cancel))
        alert.addAction(UIAlertAction(title: TSLocalized("Save", comment: ""), style: .default) { [weak self] _ in
            guard let self = self else { return }
            let text = alert.textFields?.first?.text ?? "0"
            if let intVal = Int(text) { node.value = intVal }
            else if let doubleVal = Double(text) { node.value = doubleVal }
            else { node.value = 0 }
            self.applyNodeChange(node)
        })
        present(alert, animated: true)
    }
    private func applyNodeChange(_ node: EntitlementNode) {
        if let parent = node.parent {
            if let dict = parent.value as? [String: Any] {
                var mutable = dict
                mutable[node.key] = node.value
                parent.value = mutable
                parent.rebuildChildren()
            } else if let array = parent.value as? [Any] {
                var mutable = array
                if let index = Int(node.key.replacingOccurrences(of: "[", with: "").replacingOccurrences(of: "]", with: "")), index < mutable.count {
                    mutable[index] = node.value ?? ""
                    parent.value = mutable
                    parent.rebuildChildren()
                }
            }
        } else {
            entitlements[node.key] = node.value
            rebuildRootNodes()
        }
        rebuildVisibleNodes()
        treeView.reloadData()
    }
    private func deleteNode(_ node: EntitlementNode) {
        if let parent = node.parent {
            if let dict = parent.value as? [String: Any] {
                var mutable = dict
                mutable.removeValue(forKey: node.key)
                parent.value = mutable
                parent.rebuildChildren()
            } else if let array = parent.value as? [Any] {
                var mutable = array
                if let index = Int(node.key.replacingOccurrences(of: "[", with: "").replacingOccurrences(of: "]", with: "")), index < mutable.count {
                    mutable.remove(at: index)
                    parent.value = mutable
                    parent.rebuildChildren()
                }
            }
        } else {
            entitlements.removeValue(forKey: node.key)
            rebuildRootNodes()
        }
        rebuildVisibleNodes()
        treeView.reloadData()
    }
}

// MARK: - SettingsView.swift


public class LdidManager {
    public static func ldidPath() -> String {
        return NativeBinaryManager.path(for: .ldid)
    }

    public static func isInstalled() -> Bool {
        return NativeBinaryManager.exists(.ldid)
    }

    public static func prepare() throws -> String {
        try NativeBinaryManager.ldidPath()
    }
}

enum TrollHelperManager {
    static var path: String? {
        let path = NativeBinaryManager.path(for: .trollHelper)
        return FileManager.default.fileExists(atPath: path) ? path : nil
    }

    static var isAvailable: Bool {
        guard let path else { return false }
        return FileManager.default.isExecutableFile(atPath: path)
    }
}

struct PersistenceAppCandidate: Identifiable, Equatable {
    let id: String
    let name: String
    let bundleIdentifier: String
}

struct OptionSelectionView: View {
    let title: String
    @Binding var selection: Int
    let options: [(Int, String)]
    var body: some View {
        List {
            ForEach(options, id: \.0) { option in
                Button(action: {
                    selection = option.0
                }) {
                    HStack {
                        Text(option.1)
                            .foregroundColor(.primary)
                        Spacer()
                        if selection == option.0 {
                            Image(systemName: "checkmark")
                                .foregroundColor(.blue)
                        }
                    }
                    .contentShape(Rectangle())
                }
                .buttonStyle(.plain)
            }
        }
        .listStyle(.insetGrouped)
        .trollStoreGlassListBackground()
        .navigationTitle(title)
        .navigationBarTitleDisplayMode(.inline)
    }
}

struct InstallAlertConfigurationView: View {
    @Binding var selection: Int
    var body: some View {
        OptionSelectionView(
            title: TSLocalized("Show Install Confirmation Alert", comment: ""),
            selection: $selection,
            options: [
                (0, TSLocalized("Always (Recommended)", comment: "")),
                (1, TSLocalized("Only on Remote URL Installs", comment: "")),
                (2, TSLocalized("Never (Not Recommeded)", comment: ""))
            ]
        )
    }
}

struct AdvancedSettingsView: View {
    @AppStorage(TrollStoreDefaults.installationMethod) var installationMethod = 1
    @AppStorage(TrollStoreDefaults.uninstallationMethod) var uninstallationMethod = 0
    private var installationMethodTitle: String {
        return installationMethod == 1 ? TSLocalized("Custom", comment: "") : "installd"
    }
    private var uninstallationMethodTitle: String {
        return uninstallationMethod == 1 ? TSLocalized("Custom", comment: "") : "installd"
    }
    var body: some View {
        List {
            Section(header: Text(TSLocalized("Installation", comment: "")), footer: Text(TSLocalized("Choose whether apps are installed using installd or the custom method.", comment: ""))) {
                NavigationLink(destination: OptionSelectionView(
                    title: TSLocalized("Installation Method", comment: ""),
                    selection: $installationMethod,
                    options: [
                        (0, "installd"),
                        (1, TSLocalized("Custom", comment: ""))
                    ]
                )) {
                    HStack {
                        Text(TSLocalized("Installation Method", comment: ""))
                        Spacer()
                        Text(installationMethodTitle)
                            .foregroundColor(.secondary)
                    }
                }
            }
            Section(header: Text(TSLocalized("Uninstallation", comment: "")), footer: Text(TSLocalized("Choose whether apps are uninstalled using installd or the custom method.", comment: ""))) {
                NavigationLink(destination: OptionSelectionView(
                    title: TSLocalized("Uninstallation Method", comment: ""),
                    selection: $uninstallationMethod,
                    options: [
                        (0, "installd"),
                        (1, TSLocalized("Custom", comment: ""))
                    ]
                )) {
                    HStack {
                        Text(TSLocalized("Uninstallation Method", comment: ""))
                        Spacer()
                        Text(uninstallationMethodTitle)
                            .foregroundColor(.secondary)
                    }
                }
            }
        }
        .listStyle(.insetGrouped)
        .trollStoreGlassListBackground()
        .navigationTitle(TSLocalized("Advanced", comment: ""))
        .navigationBarTitleDisplayMode(.inline)
    }
}

struct SettingsView: View {
    @AppStorage(TrollStoreDefaults.autoInitLdid) var autoInitLdid = false
    @AppStorage(TrollStoreDefaults.installAlertConfiguration) var installAlertConfiguration = 0
    @AppStorage(TrollStoreDefaults.uninstallationMethod) var uninstallationMethod = 0
    @State private var urlSchemeEnabled = UserDefaults.standard.bool(forKey: TrollStoreDefaults.urlSchemeEnabled)
    @State private var devModeEnabled = true
    @State private var inactiveAppPaths: [String] = []
    @State private var ldidInstalled = LdidManager.isInstalled()
    @State private var installedPersistenceApp: PersistenceAppCandidate? = nil
    @State private var persistenceCandidates: [PersistenceAppCandidate] = []
    @State private var showUninstallAlert = false
    @State private var showPersistenceHelperPicker = false
    @State private var showErrorAlert = false
    @State private var showURLSchemeRebuildAlert = false
    @State private var showRebootRequiredAlert = false
    @State private var showTransferAlert = false
    @State private var showTransferErrorAlert = false
    @State private var errorTitle = TSLocalized("Error", comment: "")
    @State private var errorMessage = ""
    @State private var transferErrorMessage = ""
    @State private var transferErrorLog = ""
    
    private var urlSchemeBinding: Binding<Bool> {
        return Binding<Bool>(get: {
            urlSchemeEnabled
        }, set: { newValue in
            urlSchemeEnabled = newValue
            UserDefaults.standard.set(newValue, forKey: TrollStoreDefaults.urlSchemeEnabled)
            executeHelperCommand(args: ["url-scheme", newValue ? "enable" : "disable"])
            showURLSchemeRebuildAlert = true
        })
    }
    
    private var appName: String {
        return Bundle.main.object(forInfoDictionaryKey: "CFBundleDisplayName") as? String ?? Bundle.main.object(forInfoDictionaryKey: "CFBundleName") as? String ?? "TrollStore"
    }
    
    private var appVersion: String {
        return Bundle.main.object(forInfoDictionaryKey: "CFBundleShortVersionString") as? String ?? ""
    }
    
    private var otherFooter: String {
        if appVersion.isEmpty {
            return appName
        }
        return appName + " " + appVersion
    }
    
    private var utilitiesFooter: String {
        return TSLocalized("If an app does not immediately appear after installation, respring here and it should appear afterwards.", comment: "")
    }
    
    private var ldidVersion: String? {
        let versionPath = Bundle.main.path(forResource: "ldid", ofType: "version") ?? (Bundle.main.bundlePath as NSString).appendingPathComponent("ldid.version")
        guard let data = try? Data(contentsOf: URL(fileURLWithPath: versionPath)) else { return nil }
        return String(data: data, encoding: .utf8)
    }
    
    private var signingFooter: String {
        return TSLocalized("Using the bundled custom ldid binary for signing and entitlement operations.", comment: "")
    }
    
    private var standalonePersistenceInstalled: Bool {
        return FileManager.default.fileExists(atPath: "/Applications/TrollStorePersistenceHelper.app")
    }
    
    private var persistenceFooter: String {
        if standalonePersistenceInstalled {
            return TSLocalized("persistence_footer_standalone", comment: "")
        }
        if let helper = installedPersistenceApp {
            return String(format: TSLocalized("persistence_footer_installed", comment: ""), helper.name)
        }
        return TSLocalized("persistence_footer_default", comment: "")
    }
    
    private var securityFooter: String {
        return TSLocalized("security_footer", comment: "")
    }
    
    private var installAlertConfigurationTitle: String {
        switch installAlertConfiguration {
        case 0:
            return TSLocalized("Always (Recommended)", comment: "")
        case 1:
            return TSLocalized("Only on Remote URL Installs", comment: "")
        default:
            return TSLocalized("Never (Not Recommeded)", comment: "")
        }
    }
    
    private var transferAppsTitle: String {
        let count = inactiveAppPaths.count
        if count == 1 {
            return TSLocalized("Transfer 1 App", comment: "")
        }
        return String(format: TSLocalized("Transfer %d Apps", comment: ""), count)
    }
    
    private var transferAppsMessage: String {
        let count = inactiveAppPaths.count
        if count == 1 {
            return TSLocalized("This option will transfer 1 app from other TrollStore to TrollStore. Continue?", comment: "")
        }
        return String(format: TSLocalized("This option will transfer %d apps from other TrollStore to TrollStore. Continue?", comment: ""), count)
    }
    
    var body: some View {
        List {
            if #available(iOS 16, *), !devModeEnabled {
                Section(header: Text(TSLocalized("Developer Mode", comment: "")), footer: Text(TSLocalized("Some apps require developer mode enabled to launch. This requires a reboot to take effect.", comment: ""))) {
                    Button(TSLocalized("Enable Developer Mode", comment: "")) {
                        enableDeveloperMode()
                    }
                }
            }
            Section(header: Text(TSLocalized("Utilities", comment: "")), footer: Text(utilitiesFooter)) {
                Button(TSLocalized("Respring", comment: "")) {
                    executeHelperCommand(args: ["respring"])
                }
                Button(TSLocalized("Refresh App Registrations", comment: "")) {
                    executeHelperCommand(args: ["refresh"])
                }
                Button(TSLocalized("Rebuild Icon Cache", comment: "")) {
                    executeHelperCommand(args: ["refresh-all"])
                }
                if !inactiveAppPaths.isEmpty {
                    Button(transferAppsTitle) {
                        showTransferAlert = true
                    }
                }
            }
            Section(header: Text(TSLocalized("Signing", comment: "")), footer: Text(signingFooter)) {
                if let version = ldidVersion {
                    Text(TSLocalized("ldid: Built-in", comment: "") + " (" + version + ")")
                } else {
                    Text(TSLocalized("ldid: Built-in", comment: ""))
                }
            }
            Section(header: Text(TSLocalized("Persistence", comment: "")), footer: Text(persistenceFooter)) {
                if standalonePersistenceInstalled {
                    Text(TSLocalized("Helper Installed as Standalone App", comment: ""))
                } else if let helper = installedPersistenceApp {
                    Text(String(format: TSLocalized("Helper Installed into %@", comment: ""), helper.name))
                    Button(TSLocalized("Uninstall Persistence Helper", comment: ""), role: .destructive) {
                        uninstallPersistenceHelper()
                    }
                } else {
                    Button(TSLocalized("Install Persistence Helper", comment: "")) {
                        showPersistenceHelperPicker = true
                    }
                }
            }
            Section {
                NavigationLink(destination: AdvancedSettingsView()) {
                    Text(TSLocalized("Advanced", comment: ""))
                }
            }
            Section(header: Text(TSLocalized("Security", comment: "")), footer: Text(securityFooter)) {
                Toggle(TSLocalized("URL Scheme Enabled", comment: ""), isOn: urlSchemeBinding)
                NavigationLink(destination: InstallAlertConfigurationView(selection: $installAlertConfiguration)) {
                    HStack {
                        Text(TSLocalized("Show Install Confirmation Alert", comment: ""))
                        Spacer()
                        Text(installAlertConfigurationTitle)
                            .foregroundColor(.secondary)
                    }
                }
            }
            Section(header: Text(""), footer: Text(otherFooter)) {
                Button(TSLocalized("Uninstall TrollStore", comment: ""), role: .destructive) {
                    showUninstallAlert = true
                }
            }
        }
        .listStyle(.insetGrouped)
        .trollStoreGlassListBackground()
        .navigationTitle(TSLocalized("Settings", comment: ""))
        .navigationBarTitleDisplayMode(.large)
        .onAppear {
            reloadDynamicSettings()
        }
        .alert(TSLocalized("URL Scheme Changed", comment: ""), isPresented: $showURLSchemeRebuildAlert) {
            Button(TSLocalized("Rebuild Now", comment: "")) {
                executeHelperCommand(args: ["refresh-all"])
            }
            Button(TSLocalized("Rebuild Later", comment: ""), role: .cancel) { }
        } message: {
            Text(TSLocalized("In order to properly apply the change of the URL scheme setting, rebuilding the icon cache is needed.", comment: ""))
        }
        .alert(TSLocalized("Reboot Required", comment: ""), isPresented: $showRebootRequiredAlert) {
            Button(TSLocalized("Reboot Now", comment: "")) {
                executeHelperCommand(args: ["reboot"])
            }
            Button(TSLocalized("Close", comment: ""), role: .cancel) {
                reloadDeveloperMode()
            }
        } message: {
            Text(TSLocalized("After rebooting, select \"Turn On\" to enable developer mode.", comment: ""))
        }
        .alert(TSLocalized("Transfer Apps", comment: ""), isPresented: $showTransferAlert) {
            Button(TSLocalized("Transfer", comment: "")) {
                transferApps()
            }
            Button(TSLocalized("Cancel", comment: ""), role: .cancel) { }
        } message: {
            Text(transferAppsMessage)
        }
        .alert(TSLocalized("Transfer Failed", comment: ""), isPresented: $showTransferErrorAlert) {
            Button(TSLocalized("Copy Debug Log", comment: "")) {
                UIPasteboard.general.string = transferErrorLog
            }
            Button(TSLocalized("Close", comment: ""), role: .cancel) { }
        } message: {
            Text(transferErrorMessage)
        }
        .alert(TSLocalized("Confirm Uninstall", comment: ""), isPresented: $showUninstallAlert) {
            Button(TSLocalized("Cancel", comment: ""), role: .cancel) { }
            Button(TSLocalized("Uninstall", comment: ""), role: .destructive) {
                uninstallTrollStore()
            }
        }
        .confirmationDialog(TSLocalized("Select App", comment: ""), isPresented: $showPersistenceHelperPicker, titleVisibility: .visible) {
            ForEach(persistenceCandidates) { candidate in
                Button(candidate.name) {
                    installPersistenceHelper(bundleIdentifier: candidate.bundleIdentifier)
                }
            }
            if persistenceCandidates.isEmpty {
                Button(TSLocalized("Tips", comment: "")) {
                    installPersistenceHelper(bundleIdentifier: "com.apple.tips")
                }
                Button(TSLocalized("Shortcuts", comment: "")) {
                    installPersistenceHelper(bundleIdentifier: "com.apple.shortcuts")
                }
            }
            Button(TSLocalized("Cancel", comment: ""), role: .cancel) { }
        } message: {
            Text(TSLocalized("persistence_picker_message", comment: ""))
        }
        .alert(errorTitle, isPresented: $showErrorAlert) {
            Button(TSLocalized("Close", comment: ""), role: .cancel) { }
        } message: {
            Text(errorMessage)
        }
    }
    
    private func reloadDynamicSettings() {
        inactiveAppPaths = inactiveAppBundlePaths()
        reloadDeveloperMode()
        reloadPersistenceState()
    }
    
    private func reloadDeveloperMode() {
        if #available(iOS 16, *) {
            DispatchQueue.global(qos: .userInitiated).async {
                let ret = (try? RootHelper.execute(args: ["check-dev-mode"])) ?? -1
                DispatchQueue.main.async {
                    devModeEnabled = (ret == 0)
                }
            }
        } else {
            devModeEnabled = true
        }
    }
    
    private func enableDeveloperMode() {
        DispatchQueue.global(qos: .userInitiated).async {
            let ret = (try? RootHelper.execute(args: ["arm-dev-mode"])) ?? -1
            DispatchQueue.main.async {
                if ret == 0 {
                    showRebootRequiredAlert = true
                } else {
                    errorTitle = String(format: TSLocalized("Error %d", comment: ""), ret)
                    errorMessage = TSLocalized("Failed to enable developer mode.", comment: "")
                    showErrorAlert = true
                }
            }
        }
    }
    
    private func transferApps() {
        DispatchQueue.global(qos: .userInitiated).async {
            var ret: Int32 = -1
            var logData = Data()
            if let result = try? RootHelper.executeCapturingOutput(args: ["transfer-apps"]) {
                ret = result.0
                logData = result.1
            }
            DispatchQueue.main.async {
                inactiveAppPaths = inactiveAppBundlePaths()
                if ret != 0 {
                    transferErrorLog = String(data: logData, encoding: .utf8) ?? ""
                    let count = inactiveAppPaths.count
                    if count == 1 {
                        transferErrorMessage = TSLocalized("Failed to transfer 1 app", comment: "")
                    } else {
                        transferErrorMessage = String(format: TSLocalized("Failed to transfer %d apps", comment: ""), count)
                    }
                    showTransferErrorAlert = true
                }
            }
        }
    }
    
    private func uninstallTrollStore() {
        var args = ["uninstall-trollstore"]
        if uninstallationMethod == 1 {
            args.append("custom")
        }
        executeHelperCommand(args: args)
    }
    
    private func installPersistenceHelper(bundleIdentifier: String) {
        executeHelperCommand(args: ["install-persistence-helper", bundleIdentifier])
        reloadPersistenceState()
    }
    
    private func uninstallPersistenceHelper() {
        executeHelperCommand(args: ["uninstall-persistence-helper"])
        reloadPersistenceState()
    }
    
    private func reloadPersistenceState() {
        DispatchQueue.global(qos: .userInitiated).async {
            let helper = installedPersistenceHelper()
            let candidates = persistenceAppCandidates()
            DispatchQueue.main.async {
                installedPersistenceApp = helper
                persistenceCandidates = candidates
            }
        }
    }
    
    private func installedPersistenceHelper() -> PersistenceAppCandidate? {
        let fm = FileManager.default
        for proxy in installedApplicationProxies() {
            let installed = boolValue(proxy, key: "installed")
            let restricted = boolValue(proxy, key: "restricted")
            let bundleIdentifier = stringValue(proxy, key: "bundleIdentifier")
            if !installed || restricted || bundleIdentifier.isEmpty {
                continue
            }
            let signaturePath = "/System/Library/AppSignatures/" + bundleIdentifier
            guard fm.fileExists(atPath: signaturePath) else {
                continue
            }
            if let bundleURL = urlValue(proxy, key: "bundleURL") {
                let markerURL = bundleURL.deletingLastPathComponent().appendingPathComponent(TrollStorePaths.activeMarker)
                if (try? markerURL.checkResourceIsReachable()) ?? false {
                    let name = stringValue(proxy, key: "localizedName")
                    return PersistenceAppCandidate(
                        id: bundleIdentifier,
                        name: name.isEmpty ? bundleIdentifier : name,
                        bundleIdentifier: bundleIdentifier
                    )
                }
            }
        }
        return nil
    }
    
    private func persistenceAppCandidates() -> [PersistenceAppCandidate] {
        let fm = FileManager.default
        var candidates: [PersistenceAppCandidate] = []
        for proxy in installedApplicationProxies() {
            let installed = boolValue(proxy, key: "installed")
            let restricted = boolValue(proxy, key: "restricted")
            let bundleIdentifier = stringValue(proxy, key: "bundleIdentifier")
            if !installed || restricted || bundleIdentifier.isEmpty {
                continue
            }
            let signaturePath = "/System/Library/AppSignatures/" + bundleIdentifier
            guard fm.fileExists(atPath: signaturePath) else {
                continue
            }
            if let bundleURL = urlValue(proxy, key: "bundleURL") {
                let markerURL = bundleURL.deletingLastPathComponent().appendingPathComponent(TrollStorePaths.activeMarker)
                let reachable = (try? markerURL.checkResourceIsReachable()) ?? false
                if !reachable {
                    let name = stringValue(proxy, key: "localizedName")
                    candidates.append(
                        PersistenceAppCandidate(
                            id: bundleIdentifier,
                            name: name.isEmpty ? bundleIdentifier : name,
                            bundleIdentifier: bundleIdentifier
                        )
                    )
                }
            }
        }
        return candidates.sorted {
            $0.name.localizedStandardCompare($1.name) == .orderedAscending
        }
    }
    
    private func installedApplicationProxies() -> [NSObject] {
        var apps: [NSObject] = []
        guard let cls = NSClassFromString("LSApplicationWorkspace") as? NSObject.Type,
              let workspace = cls.perform(NSSelectorFromString("defaultWorkspace"))?.takeUnretainedValue() as? NSObject else {
            return apps
        }
        let sel = NSSelectorFromString("enumerateApplicationsOfType:block:")
        guard workspace.responds(to: sel) else { return apps }
        typealias BlockType = @convention(block) (NSObject) -> Void
        let block: BlockType = { proxy in
            apps.append(proxy)
        }
        let imp = workspace.method(for: sel)
        typealias Fn = @convention(c) (NSObject, Selector, UInt, BlockType) -> Void
        let fn = unsafeBitCast(imp, to: Fn.self)
        fn(workspace, sel, 0, block)
        fn(workspace, sel, 1, block)
        return apps
    }
    
    private func boolValue(_ proxy: NSObject, key: String) -> Bool {
        guard proxy.responds(to: NSSelectorFromString(key)) else { return false }
        return (proxy.value(forKey: key) as? NSNumber)?.boolValue ?? false
    }
    
    private func stringValue(_ proxy: NSObject, key: String) -> String {
        guard proxy.responds(to: NSSelectorFromString(key)) else { return "" }
        return (proxy.value(forKey: key) as? String) ?? ""
    }
    
    private func urlValue(_ proxy: NSObject, key: String) -> URL? {
        guard proxy.responds(to: NSSelectorFromString(key)) else { return nil }
        return proxy.value(forKey: key) as? URL
    }
    
    private func inactiveAppBundlePaths() -> [String] {
        let fm = FileManager.default
        let appsRoot = TrollStorePaths.applicationsPath
        var paths: [String] = []
        guard let containerDirs = try? fm.contentsOfDirectory(atPath: appsRoot) else {
            return paths
        }
        for containerDir in containerDirs {
            let containerPath = (appsRoot as NSString).appendingPathComponent(containerDir)
            var isDir: ObjCBool = false
            guard fm.fileExists(atPath: containerPath, isDirectory: &isDir), isDir.boolValue else {
                continue
            }
            let inactiveMarker = (containerPath as NSString).appendingPathComponent(TrollStorePaths.inactiveMarker)
            if fm.fileExists(atPath: inactiveMarker) {
                if let appPath = findAppPath(in: containerPath) {
                    paths.append(appPath)
                }
            }
        }
        return paths
    }
    
    private func findAppPath(in containerPath: String) -> String? {
        let fm = FileManager.default
        guard let contents = try? fm.contentsOfDirectory(atPath: containerPath) else {
            return nil
        }
        for item in contents {
            if item.hasSuffix(".app") {
                let appPath = (containerPath as NSString).appendingPathComponent(item)
                var isDir: ObjCBool = false
                if fm.fileExists(atPath: appPath, isDirectory: &isDir) && isDir.boolValue {
                    return appPath
                }
            }
        }
        return nil
    }
    
    private func executeHelperCommand(args: [String]) {
        do {
            let ret = try RootHelper.execute(args: args)
            if ret != 0 {
                errorTitle = String(format: TSLocalized("Error %d", comment: ""), Int(ret))
                errorMessage = TSLocalized("Command failed.", comment: "")
                showErrorAlert = true
            }
        } catch {
            errorTitle = TSLocalized("Error", comment: "")
            errorMessage = TSLocalized("Failed to spawn helper.", comment: "")
            showErrorAlert = true
        }
    }
}



// MARK: - Built-in Localization

private enum TrollStoreLocalization {
    static let chinese: [String: String] = [
        "Actions": "操作", "Add": "添加", "Add Key": "添加键", "Advanced": "高级",
        "After rebooting, select \"Turn On\" to enable developer mode.": "重启后，选择“打开”以启用开发者模式。",
        "Always (Recommended)": "始终显示（推荐）", "App": "应用", "Apps": "应用",
        "Are you sure you want to uninstall %@?": "确定要卸载 %@ 吗？", "Bundle ID": "Bundle ID",
        "Cancel": "取消", "Change Registration": "更改注册方式", "Choose whether apps are installed using installd or the custom method.": "选择使用 installd 还是自定义方式安装应用。",
        "Choose whether apps are uninstalled using installd or the custom method.": "选择使用 installd 还是自定义方式卸载应用。",
        "Close": "关闭", "Command failed.": "命令执行失败。", "Confirm Uninstall": "确认卸载",
        "Copy Debug Log": "复制调试日志", "Custom": "自定义", "Developer Mode": "开发者模式",
        "Downloading": "正在下载", "Edit Entitlements": "编辑 Entitlements", "Enable Developer Mode": "启用开发者模式",
        "Enable JIT": "启用 JIT", "Enabling JIT": "正在启用 JIT", "Entitlements": "Entitlements",
        "Entitlements Saved": "Entitlements 已保存", "Error": "错误", "Error %d": "错误 %d",
        "Error_166": "操作失败：错误码 166", "Error_167": "IPA 无效或无法解析。", "Error_168": "重新打包 IPA 失败。",
        "Error_169": "安装失败：应用已存在或目标无效。", "Error_170": "安装失败。", "Error_171": "卸载失败。",
        "Error_172": "刷新应用注册失败。", "Error_173": "操作失败。", "Error_174": "权限不足或操作被拒绝。",
        "Error_175": "签名或 Entitlements 操作失败。", "Error_176": "持久化助手操作失败。", "Error_177": "应用注册失败。",
        "Error_178": "文件操作失败。", "Error_179": "辅助工具执行失败。", "Error_180": "操作超时。",
        "Error_181": "目标应用不存在。", "Error_182": "无法读取应用信息。", "Error_183": "无法写入应用信息。",
        "Error_184": "操作失败。", "Error_185": "未知安装错误。", "Error_Unknown": "未知错误。",
        "Failed to enable developer mode.": "启用开发者模式失败。", "Failed to spawn helper.": "无法启动辅助工具。",
        "Failed to transfer %d apps": "转移 %d 个应用失败", "Failed to transfer 1 app": "转移 1 个应用失败",
        "Force Install": "强制安装", "Helper Installed as Standalone App": "助手已作为独立应用安装",
        "Helper Installed into %@": "助手已安装到 %@", "If an app does not immediately appear after installation, respring here and it should appear afterwards.": "如果应用安装后没有立即出现，请在此处 Respring，之后应用应该会显示。",
        "In order to properly apply the change of the URL scheme setting, rebuilding the icon cache is needed.": "要正确应用 URL Scheme 设置的更改，需要重建图标缓存。",
        "Info": "信息", "Install": "安装", "Install Date": "安装日期", "Install Error": "安装错误",
        "Install IPA File": "安装 IPA 文件", "Install Persistence Helper": "安装持久化助手", "Installation": "安装",
        "Installation Method": "安装方式", "Installing": "正在安装", "JIT Enabled": "JIT 已启用",
        "Key": "键", "Name Ascending": "名称升序", "Name Descending": "名称降序",
        "Never (Not Recommeded)": "从不显示（不推荐）", "Only on Remote URL Installs": "仅远程 URL 安装时显示",
        "Open": "打开", "Path": "路径", "Persistence": "持久化", "Reboot Now": "立即重启",
        "Reboot Required": "需要重启", "Rebuild Icon Cache": "重建图标缓存", "Rebuild Later": "稍后重建",
        "Rebuild Now": "立即重建", "Refresh App Registrations": "刷新应用注册", "Registration": "注册方式",
        "Respring": "Respring", "Save": "保存", "Search": "搜索", "Security": "安全",
        "Select App": "选择应用", "Settings": "设置", "Shortcuts": "快捷方式", "Show Install Confirmation Alert": "显示安装确认提示",
        "Signing": "签名", "Size": "大小", "Some apps require developer mode enabled to launch. This requires a reboot to take effect.": "部分应用需要启用开发者模式才能启动。启用后需要重启才能生效。",
        "Success": "成功", "System": "系统", "This option will transfer %d apps from other TrollStore to TrollStore. Continue?": "此选项会将其他 TrollStore 中的 %d 个应用转移到当前 TrollStore。继续吗？",
        "This option will transfer 1 app from other TrollStore to TrollStore. Continue?": "此选项会将其他 TrollStore 中的 1 个应用转移到当前 TrollStore。继续吗？",
        "Tips": "提示", "Transfer": "转移", "Transfer %d Apps": "转移 %d 个应用", "Transfer 1 App": "转移 1 个应用",
        "Transfer Apps": "转移应用", "Transfer Failed": "转移失败", "URL Scheme Changed": "URL Scheme 已更改",
        "URL Scheme Enabled": "启用 URL Scheme", "Uninstall": "卸载", "Uninstall App": "卸载应用",
        "Uninstall Persistence Helper": "卸载持久化助手", "Uninstall TrollStore": "卸载 TrollStore", "Uninstallation": "卸载",
        "Uninstallation Method": "卸载方式", "Unknown Error": "未知错误", "User": "用户",
        "Using the bundled custom ldid binary for signing and entitlement operations.": "使用内置自定义 ldid 二进制文件执行签名和 Entitlements 操作。",
        "Utilities": "实用工具", "Version: %@\\nBundle ID: %@\\nSize: %@": "版本：%@\\nBundle ID：%@\\n大小：%@",
        "[Array]": "[数组]", "[Dictionary]": "[字典]", "false": "假", "true": "真",
        "ldid: Built-in": "ldid：内置", "persistence_footer_default": "安装持久化助手以提高 TrollStore 的持久性。",
        "persistence_footer_installed": "持久化助手已安装。", "persistence_footer_standalone": "持久化助手已作为独立应用安装。",
        "persistence_picker_message": "选择一个应用来安装持久化助手。", "security_footer": "这些选项控制 URL Scheme 和安装确认提示。"
    ]

    static func localized(_ key: String) -> String {
        let language = Locale.preferredLanguages.first?.lowercased() ?? ""
        if language.hasPrefix("zh") {
            return chinese[key] ?? key
        }
        return key
    }
}

private func TSLocalized(_ key: String, comment: String = "") -> String {
    TrollStoreLocalization.localized(key)
}

// MARK: - Custom Glass UI

private final class TrollStoreGlassView: UIView {
    private let blurView = UIVisualEffectView(effect: UIBlurEffect(style: .systemUltraThinMaterial))
    private let tintView = UIView()
    private let gradientLayer = CAGradientLayer()
    private let highlightLayer = CAGradientLayer()
    private let borderLayer = CAShapeLayer()
    private let shineLayer = CAGradientLayer()

    var intensity: CGFloat = 1.0 { didSet { updateAppearance() } }
    var cornerRadius: CGFloat = 22 { didSet { setNeedsLayout() } }

    override init(frame: CGRect) {
        super.init(frame: frame)
        isOpaque = false
        clipsToBounds = false

        blurView.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        blurView.isUserInteractionEnabled = false
        addSubview(blurView)

        tintView.isUserInteractionEnabled = false
        tintView.backgroundColor = UIColor.systemBackground.withAlphaComponent(0.12)
        tintView.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        addSubview(tintView)

        gradientLayer.colors = [
            UIColor.white.withAlphaComponent(0.13).cgColor,
            UIColor.white.withAlphaComponent(0.035).cgColor,
            UIColor.black.withAlphaComponent(0.045).cgColor
        ]
        gradientLayer.locations = [0, 0.42, 1]
        gradientLayer.startPoint = CGPoint(x: 0.12, y: 0)
        gradientLayer.endPoint = CGPoint(x: 0.92, y: 1)
        layer.addSublayer(gradientLayer)

        highlightLayer.colors = [
            UIColor.white.withAlphaComponent(0.20).cgColor,
            UIColor.white.withAlphaComponent(0.0).cgColor
        ]
        highlightLayer.locations = [0, 1]
        highlightLayer.startPoint = CGPoint(x: 0.05, y: 0.0)
        highlightLayer.endPoint = CGPoint(x: 0.95, y: 0.55)
        layer.addSublayer(highlightLayer)

        shineLayer.colors = [
            UIColor.white.withAlphaComponent(0.0).cgColor,
            UIColor.white.withAlphaComponent(0.08).cgColor,
            UIColor.white.withAlphaComponent(0.0).cgColor
        ]
        shineLayer.locations = [0.35, 0.5, 0.65]
        shineLayer.startPoint = CGPoint(x: 0, y: 0)
        shineLayer.endPoint = CGPoint(x: 1, y: 1)
        layer.addSublayer(shineLayer)

        borderLayer.fillColor = UIColor.clear.cgColor
        borderLayer.strokeColor = UIColor.white.withAlphaComponent(0.24).cgColor
        borderLayer.lineWidth = 0.8
        layer.addSublayer(borderLayer)

        layer.shadowColor = UIColor.black.cgColor
        layer.shadowOpacity = 0.14
        layer.shadowRadius = 16
        layer.shadowOffset = CGSize(width: 0, height: 7)
        updateAppearance()
    }

    required init?(coder: NSCoder) { fatalError("init(coder:) has not been implemented") }

    override func layoutSubviews() {
        super.layoutSubviews()
        blurView.frame = bounds
        tintView.frame = bounds
        gradientLayer.frame = bounds
        highlightLayer.frame = CGRect(x: 0, y: 0, width: bounds.width, height: bounds.height * 0.72)
        shineLayer.frame = bounds
        let path = UIBezierPath(roundedRect: bounds.insetBy(dx: 0.4, dy: 0.4), cornerRadius: cornerRadius)
        borderLayer.path = path.cgPath
        layer.cornerRadius = cornerRadius
        blurView.layer.cornerRadius = cornerRadius
        tintView.layer.cornerRadius = cornerRadius
        blurView.clipsToBounds = true
        tintView.clipsToBounds = true
        layer.shadowPath = UIBezierPath(roundedRect: bounds, cornerRadius: cornerRadius).cgPath
    }

    private func updateAppearance() {
        let a = max(0, min(1, intensity))
        tintView.backgroundColor = UIColor.systemBackground.withAlphaComponent(0.07 + 0.10 * a)
        gradientLayer.opacity = Float(0.65 + 0.35 * a)
        highlightLayer.opacity = Float(0.55 + 0.45 * a)
        shineLayer.opacity = Float(a)
        borderLayer.strokeColor = UIColor.white.withAlphaComponent(0.17 + 0.10 * a).cgColor
    }
}

private final class TrollStoreGlassContainer: UIView {
    let glass = TrollStoreGlassView()
    let content = UIView()

    override init(frame: CGRect) {
        super.init(frame: frame)
        backgroundColor = .clear
        glass.translatesAutoresizingMaskIntoConstraints = false
        content.translatesAutoresizingMaskIntoConstraints = false
        addSubview(glass)
        addSubview(content)
        NSLayoutConstraint.activate([
            glass.leadingAnchor.constraint(equalTo: leadingAnchor), glass.trailingAnchor.constraint(equalTo: trailingAnchor),
            glass.topAnchor.constraint(equalTo: topAnchor), glass.bottomAnchor.constraint(equalTo: bottomAnchor),
            content.leadingAnchor.constraint(equalTo: leadingAnchor), content.trailingAnchor.constraint(equalTo: trailingAnchor),
            content.topAnchor.constraint(equalTo: topAnchor), content.bottomAnchor.constraint(equalTo: bottomAnchor)
        ])
    }

    required init?(coder: NSCoder) { fatalError("init(coder:) has not been implemented") }
}

private struct TrollStoreGlassBackground: UIViewRepresentable {
    func makeUIView(context: Context) -> TrollStoreGlassView {
        let view = TrollStoreGlassView()
        view.cornerRadius = 0
        view.intensity = 0.92
        return view
    }

    func updateUIView(_ uiView: TrollStoreGlassView, context: Context) {}
}

private extension View {
    @ViewBuilder
    func trollStoreGlassListBackground() -> some View {
        if #available(iOS 16.0, *) {
            self.scrollContentBackground(.hidden).background(TrollStoreGlassBackground().ignoresSafeArea())
        } else {
            self.background(TrollStoreGlassBackground().ignoresSafeArea())
        }
    }
}

// MARK: - Glass Navigation Containers

private final class TrollStoreNavigationController: UINavigationController {
    private let glassView = TrollStoreGlassView()

    override func viewDidLoad() {
        super.viewDidLoad()
        glassView.cornerRadius = 0
        glassView.intensity = 0.90
        glassView.translatesAutoresizingMaskIntoConstraints = false
        navigationBar.addSubview(glassView)
        navigationBar.sendSubviewToBack(glassView)
        NSLayoutConstraint.activate([
            glassView.leadingAnchor.constraint(equalTo: navigationBar.leadingAnchor),
            glassView.trailingAnchor.constraint(equalTo: navigationBar.trailingAnchor),
            glassView.topAnchor.constraint(equalTo: navigationBar.topAnchor),
            glassView.bottomAnchor.constraint(equalTo: navigationBar.bottomAnchor)
        ])
    }
}

// MARK: - MainTabBarController

public final class MainTabBarController: UITabBarController {
    public override func viewDidLoad() {
        super.viewDidLoad()
        configureAppearance()

        let apps = AppListViewController()
        apps.title = TSLocalized("Apps", comment: "")

        let settings = UIHostingController(rootView: SettingsView())
        settings.view.backgroundColor = .clear
        settings.title = TSLocalized("Settings", comment: "")

        let appsNavigation = TrollStoreNavigationController(rootViewController: apps)
        let settingsNavigation = TrollStoreNavigationController(rootViewController: settings)

        appsNavigation.navigationBar.prefersLargeTitles = true
        settingsNavigation.navigationBar.prefersLargeTitles = true

        appsNavigation.tabBarItem = UITabBarItem(
            title: TSLocalized("Apps", comment: ""),
            image: UIImage(systemName: "square.stack.3d.up"),
            selectedImage: UIImage(systemName: "square.stack.3d.up.fill")
        )
        settingsNavigation.tabBarItem = UITabBarItem(
            title: TSLocalized("Settings", comment: ""),
            image: UIImage(systemName: "gearshape"),
            selectedImage: UIImage(systemName: "gearshape.fill")
        )

        viewControllers = [appsNavigation, settingsNavigation]
    }

    private func configureAppearance() {
        let navigationAppearance = UINavigationBarAppearance()
        navigationAppearance.configureWithTransparentBackground()
        navigationAppearance.backgroundEffect = nil
        navigationAppearance.backgroundColor = .clear
        navigationAppearance.shadowColor = .clear

        UINavigationBar.appearance().standardAppearance = navigationAppearance
        UINavigationBar.appearance().scrollEdgeAppearance = navigationAppearance
        UINavigationBar.appearance().compactAppearance = navigationAppearance

        let tabAppearance = UITabBarAppearance()
        tabAppearance.configureWithTransparentBackground()
        tabAppearance.backgroundEffect = nil
        tabAppearance.backgroundColor = .clear
        tabAppearance.shadowColor = .clear

        tabBar.standardAppearance = tabAppearance
        if #available(iOS 15.0, *) {
            tabBar.scrollEdgeAppearance = tabAppearance
        }

        let tabGlass = TrollStoreGlassView()
        tabGlass.cornerRadius = 0
        tabGlass.intensity = 0.96
        tabGlass.translatesAutoresizingMaskIntoConstraints = false
        tabBar.addSubview(tabGlass)
        tabBar.sendSubviewToBack(tabGlass)
        NSLayoutConstraint.activate([
            tabGlass.leadingAnchor.constraint(equalTo: tabBar.leadingAnchor),
            tabGlass.trailingAnchor.constraint(equalTo: tabBar.trailingAnchor),
            tabGlass.topAnchor.constraint(equalTo: tabBar.topAnchor),
            tabGlass.bottomAnchor.constraint(equalTo: tabBar.bottomAnchor)
        ])
    }
}



// MARK: - Application Entry

@main
public final class TrollStoreApp: UIResponder, UIApplicationDelegate {
    public var window: UIWindow?

    public func application(
        _ application: UIApplication,
        didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]? = nil
    ) -> Bool {
        let window = UIWindow(frame: UIScreen.main.bounds)
        window.rootViewController = MainTabBarController()
        self.window = window
        window.makeKeyAndVisible()
        return true
    }

    public func application(
        _ app: UIApplication,
        open url: URL,
        options: [UIApplication.OpenURLOptionsKey: Any] = [:]
    ) -> Bool {
        guard let components = URLComponents(url: url, resolvingAgainstBaseURL: false) else {
            return false
        }

        switch components.host {
        case "install":
            if let value = components.queryItems?.first(where: { $0.name == "url" })?.value {
                NotificationCenter.default.post(
                    name: NSNotification.Name("TrollStoreRemoteInstall"),
                    object: value
                )
            }
        case "enable-jit":
            if let bundleId = components.queryItems?.first(where: { $0.name == "bundle-id" })?.value {
                NotificationCenter.default.post(
                    name: NSNotification.Name("TrollStoreEnableJIT"),
                    object: bundleId
                )
            }
        default:
            break
        }

        return true
    }
}

