#import <stdio.h>
#import "unarchive.h"
@import Foundation;
#import "uicache.h"
#import <sys/stat.h>
#import <dlfcn.h>
#import <spawn.h>
#import <objc/runtime.h>
#import <TSUtil.h>
#import <sys/utsname.h>
#import <mach-o/loader.h>
#import <mach-o/fat.h>
#import "devmode.h"
#import "jit.h"
#ifndef EMBEDDED_ROOT_HELPER
#import "codesign.h"
#import "coretrust_bug.h"
#import "FAT.h"
#import "MachO.h"
#import "FileStream.h"
#import "Host.h"
#endif

#import <SpringBoardServices/SpringBoardServices.h>
#import <FrontBoardServices/FBSSystemService.h>
#import <Security/Security.h>
#import <libroot.h>

#ifdef EMBEDDED_ROOT_HELPER
#define MAIN_NAME rootHelperMain
#else
#define MAIN_NAME main
#endif

void cleanRestrictions(void);

extern mach_msg_return_t SBReloadIconForIdentifier(mach_port_t machport, const char* identifier);
@interface SBSHomeScreenService : NSObject
- (void)reloadIcons;
@end
extern NSString* BKSActivateForEventOptionTypeBackgroundContentFetching;
extern NSString* BKSOpenApplicationOptionKeyActivateForEvent;

extern void BKSTerminateApplicationForReasonAndReportWithDescription(NSString *bundleID, int reasonID, bool report, NSString *description);

#define kCFPreferencesNoContainer CFSTR("kCFPreferencesNoContainer")

typedef CFPropertyListRef (*_CFPreferencesCopyValueWithContainerType)(CFStringRef key, CFStringRef applicationID, CFStringRef userName, CFStringRef hostName, CFStringRef containerPath);
typedef void (*_CFPreferencesSetValueWithContainerType)(CFStringRef key, CFPropertyListRef value, CFStringRef applicationID, CFStringRef userName, CFStringRef hostName, CFStringRef containerPath);
typedef Boolean (*_CFPreferencesSynchronizeWithContainerType)(CFStringRef applicationID, CFStringRef userName, CFStringRef hostName, CFStringRef containerPath);
typedef CFArrayRef (*_CFPreferencesCopyKeyListWithContainerType)(CFStringRef applicationID, CFStringRef userName, CFStringRef hostName, CFStringRef containerPath);
typedef CFDictionaryRef (*_CFPreferencesCopyMultipleWithContainerType)(CFArrayRef keysToFetch, CFStringRef applicationID, CFStringRef userName, CFStringRef hostName, CFStringRef containerPath);

BOOL _installPersistenceHelper(LSApplicationProxy* appProxy, NSString* sourcePersistenceHelper, NSString* sourceRootHelper);

NSArray<LSApplicationProxy*>* applicationsWithGroupId(NSString* groupId)
{
	LSEnumerator* enumerator = [LSEnumerator enumeratorForApplicationProxiesWithOptions:0];
	enumerator.predicate = [NSPredicate predicateWithFormat:@"groupContainerURLs[%@] != nil", groupId];
	return enumerator.allObjects;
}

NSSet<NSString*>* systemURLSchemes(void)
{
	LSEnumerator* enumerator = [LSEnumerator enumeratorForApplicationProxiesWithOptions:0];

	NSMutableSet* systemURLSchemesSet = [NSMutableSet new];
	LSApplicationProxy* proxy;
	while(proxy = [enumerator nextObject])
	{
		if(isRemovableSystemApp(proxy.bundleIdentifier) || ![proxy.bundleURL.path hasPrefix:@"/private/var/containers"])
		{
			for(NSString* claimedURLScheme in proxy.claimedURLSchemes)
			{
				if([claimedURLScheme isKindOfClass:NSString.class])
				{
					[systemURLSchemesSet addObject:claimedURLScheme.lowercaseString];
				}
			}
		}
	}

	return systemURLSchemesSet.copy;
}

NSSet<NSString*>* immutableAppBundleIdentifiers(void)
{
	NSMutableSet* systemAppIdentifiers = [NSMutableSet new];

	LSEnumerator* enumerator = [LSEnumerator enumeratorForApplicationProxiesWithOptions:0];
	LSApplicationProxy* appProxy;
	while(appProxy = [enumerator nextObject])
	{
		if(appProxy.installed)
		{
			if(![appProxy.bundleURL.path hasPrefix:@"/private/var/containers"])
			{
				[systemAppIdentifiers addObject:appProxy.bundleIdentifier.lowercaseString];
			}
		}
	}

	return systemAppIdentifiers.copy;
}

NSDictionary* infoDictionaryForAppPath(NSString* appPath)
{
	if(!appPath) return nil;
	NSString* infoPlistPath = [appPath stringByAppendingPathComponent:@"Info.plist"];
	return [NSDictionary dictionaryWithContentsOfFile:infoPlistPath];
}

NSString* appIdForAppPath(NSString* appPath)
{
	if(!appPath) return nil;
	return infoDictionaryForAppPath(appPath)[@"CFBundleIdentifier"];
}

NSString* appMainExecutablePathForAppPath(NSString* appPath)
{
	if(!appPath) return nil;
	return [appPath stringByAppendingPathComponent:infoDictionaryForAppPath(appPath)[@"CFBundleExecutable"]];
}

NSString* appPathForAppId(NSString* appId)
{
	if(!appId) return nil;
	for(NSString* appPath in trollStoreInstalledAppBundlePaths())
	{
		if([appIdForAppPath(appPath) isEqualToString:appId])
		{
			return appPath;
		}
	}
	return nil;
}

NSString* findAppNameInBundlePath(NSString* bundlePath)
{
	NSArray* bundleItems = [[NSFileManager defaultManager] contentsOfDirectoryAtPath:bundlePath error:nil];
	for(NSString* bundleItem in bundleItems)
	{
		if([bundleItem.pathExtension isEqualToString:@"app"])
		{
			return bundleItem;
		}
	}
	return nil;
}

NSString* findAppPathInBundlePath(NSString* bundlePath)
{
	NSString* appName = findAppNameInBundlePath(bundlePath);
	if(!appName) return nil;
	return [bundlePath stringByAppendingPathComponent:appName];
}

NSURL* findAppURLInBundleURL(NSURL* bundleURL)
{
	NSString* appName = findAppNameInBundlePath(bundleURL.path);
	if(!appName) return nil;
	return [bundleURL URLByAppendingPathComponent:appName];
}

BOOL isMachoFile(NSString* filePath)
{
	FILE* file = fopen(filePath.fileSystemRepresentation, "r");
	if(!file) return NO;

	fseek(file, 0, SEEK_SET);
	uint32_t magic;
	fread(&magic, sizeof(uint32_t), 1, file);
	fclose(file);

	return magic == FAT_MAGIC || magic == FAT_CIGAM || magic == MH_MAGIC_64 || magic == MH_CIGAM_64;
}

void fixPermissionsOfAppBundle(NSString* appBundlePath)
{
	NSURL* fileURL;
	NSDirectoryEnumerator *enumerator = [[NSFileManager defaultManager] enumeratorAtURL:[NSURL fileURLWithPath:appBundlePath] includingPropertiesForKeys:nil options:0 errorHandler:nil];
	while(fileURL = [enumerator nextObject])
	{
		NSString* filePath = fileURL.path;

		BOOL isDir;
		[[NSFileManager defaultManager] fileExistsAtPath:fileURL.path isDirectory:&isDir];

		chown(filePath.fileSystemRepresentation, 33, 33);

		if(isDir || isMachoFile(filePath))
		{
			chmod(filePath.fileSystemRepresentation, 0755);
		}
		else
		{
			chmod(filePath.fileSystemRepresentation, 0644);
		}
	}
}

NSArray* TSURLScheme(void)
{
	return @[
		@{
			@"CFBundleURLName" : @"com.apple.Magnifier",
			@"CFBundleURLSchemes" : @[
				@"apple-magnifier"
			]
		}
	];
}

BOOL getTSURLSchemeState(NSString* customAppPath)
{
	NSString* pathToUse = customAppPath ?: trollStoreAppPath();

	NSDictionary* trollStoreInfoDict = infoDictionaryForAppPath(pathToUse);
	return (BOOL)trollStoreInfoDict[@"CFBundleURLTypes"];
}

void setTSURLSchemeState(BOOL newState, NSString* customAppPath)
{
	NSString* tsAppPath = trollStoreAppPath();
	NSString* pathToUse = customAppPath ?: tsAppPath;
	if(newState != getTSURLSchemeState(pathToUse))
	{
		NSDictionary* trollStoreInfoDict = infoDictionaryForAppPath(pathToUse);
		NSMutableDictionary* trollStoreInfoDictM = trollStoreInfoDict.mutableCopy;
		if(newState)
		{
			trollStoreInfoDictM[@"CFBundleURLTypes"] = TSURLScheme();
		}
		else
		{
			[trollStoreInfoDictM removeObjectForKey:@"CFBundleURLTypes"];
		}
		NSString* outPath = [pathToUse stringByAppendingPathComponent:@"Info.plist"];
		[trollStoreInfoDictM.copy writeToURL:[NSURL fileURLWithPath:outPath] error:nil];
	}
}

#ifdef TROLLSTORE_LITE

BOOL isLdidInstalled(void)
{
	return YES;
}

NSString *getLdidPath(void)
{
	return JBROOT_PATH(@"/usr/bin/ldid");
}

#else

void installLdid(NSString* ldidToCopyPath, NSString* ldidVersion)
{
	if(![[NSFileManager defaultManager] fileExistsAtPath:ldidToCopyPath]) return;

	NSString* ldidPath = [trollStoreAppPath() stringByAppendingPathComponent:@"ldid"];
	NSString* ldidVersionPath = [trollStoreAppPath() stringByAppendingPathComponent:@"ldid.version"];

	if([[NSFileManager defaultManager] fileExistsAtPath:ldidPath])
	{
		[[NSFileManager defaultManager] removeItemAtPath:ldidPath error:nil];
	}

	[[NSFileManager defaultManager] copyItemAtPath:ldidToCopyPath toPath:ldidPath error:nil];

	NSData* ldidVersionData = [ldidVersion dataUsingEncoding:NSUTF8StringEncoding];
	[ldidVersionData writeToFile:ldidVersionPath atomically:YES];

	chmod(ldidPath.fileSystemRepresentation, 0755);
	chmod(ldidVersionPath.fileSystemRepresentation, 0644);
}

BOOL isLdidInstalled(void)
{
	NSString* ldidPath = [trollStoreAppPath() stringByAppendingPathComponent:@"ldid"];
	return [[NSFileManager defaultManager] fileExistsAtPath:ldidPath];
}

NSString *getLdidPath(void)
{
	return [trollStoreAppPath() stringByAppendingPathComponent:@"ldid"];
}

#endif

int runLdid(NSArray* args, NSString** output, NSString** errorOutput)
{
	NSString* ldidPath = getLdidPath();
	NSMutableArray* argsM = args.mutableCopy ?: [NSMutableArray new];
	[argsM insertObject:ldidPath.lastPathComponent atIndex:0];

	NSUInteger argCount = [argsM count];
	char **argsC = (char **)malloc((argCount + 1) * sizeof(char*));

	for (NSUInteger i = 0; i < argCount; i++)
	{
		argsC[i] = strdup([[argsM objectAtIndex:i] UTF8String]);
	}
	argsC[argCount] = NULL;

	posix_spawn_file_actions_t action;
	posix_spawn_file_actions_init(&action);

	int outErr[2];
	pipe(outErr);
	posix_spawn_file_actions_adddup2(&action, outErr[1], STDERR_FILENO);
	posix_spawn_file_actions_addclose(&action, outErr[0]);

	int out[2];
	pipe(out);
	posix_spawn_file_actions_adddup2(&action, out[1], STDOUT_FILENO);
	posix_spawn_file_actions_addclose(&action, out[0]);

	pid_t task_pid;
	int status = -200;
	int spawnError = posix_spawn(&task_pid, [ldidPath fileSystemRepresentation], &action, NULL, (char* const*)argsC, NULL);
	for (NSUInteger i = 0; i < argCount; i++)
	{
		free(argsC[i]);
	}
	free(argsC);

	if(spawnError != 0)
	{
		return spawnError;
	}

	do
	{
		if (waitpid(task_pid, &status, 0) != -1) {
		} else
		{
			return -222;
		}
	} while (!WIFEXITED(status) && !WIFSIGNALED(status));

	close(outErr[1]);
	close(out[1]);

	NSString* ldidOutput = getNSStringFromFile(out[0]);
	if(output)
	{
		*output = ldidOutput;
	}

	NSString* ldidErrorOutput = getNSStringFromFile(outErr[0]);
	if(errorOutput)
	{
		*errorOutput = ldidErrorOutput;
	}

	return WEXITSTATUS(status);
}

BOOL codeCertChainContainsFakeAppStoreExtensions(SecStaticCodeRef codeRef)
{
	if(codeRef == NULL) return NO;

	CFDictionaryRef signingInfo = NULL;
	OSStatus result;
	result = SecCodeCopySigningInformation(codeRef, kSecCSSigningInformation, &signingInfo);
	if(result != errSecSuccess) return NO;

	CFArrayRef certificates = CFDictionaryGetValue(signingInfo, kSecCodeInfoCertificates);
	if(certificates == NULL || CFArrayGetCount(certificates) == 0) return NO;

	SecPolicyRef appleAppStorePolicy = SecPolicyCreateWithProperties(kSecPolicyAppleiPhoneApplicationSigning, NULL);
	SecTrustRef trust = NULL;
	SecTrustCreateWithCertificates(certificates, appleAppStorePolicy, &trust);

	if(SecTrustEvaluateWithError(trust, nil))
	{
		CFRelease(trust);
		CFRelease(appleAppStorePolicy);
		CFRelease(signingInfo);
		return NO;
	}

	CFRelease(appleAppStorePolicy);

	SecPolicyRef appleProfileSignedPolicy = SecPolicyCreateWithProperties(kSecPolicyAppleiPhoneProfileApplicationSigning, NULL);
	if(SecTrustSetPolicies(trust, appleProfileSignedPolicy) != errSecSuccess)
	{
		CFRelease(trust);
		CFRelease(signingInfo);
		return NO;
	}

	if(SecTrustEvaluateWithError(trust, nil))
	{
		CFRelease(trust);
		CFRelease(appleProfileSignedPolicy);
		CFRelease(signingInfo);
		return NO;
	}

	CFRelease(appleProfileSignedPolicy);

	if(CFArrayGetCount(certificates) != 3)
	{
		CFRelease(signingInfo);
		return NO;
	}

	SecPolicyRef customRootPolicy = SecPolicyCreateWithProperties(kSecPolicyAppleCodeSigning, NULL);
	SecPolicySetOptionsValue(customRootPolicy, CFSTR("LeafMarkerOid"), CFSTR("1.2.840.113635.100.6.1.3"));

	if(SecTrustSetPolicies(trust, customRootPolicy) != errSecSuccess)
	{
		CFRelease(trust);
		CFRelease(signingInfo);
		return NO;
	}

	SecTrustSetAnchorCertificates(trust, certificates);

	BOOL evaluatesToCustomAnchor = SecTrustEvaluateWithError(trust, nil);

	CFRelease(trust);
	CFRelease(customRootPolicy);
	CFRelease(signingInfo);

	return evaluatesToCustomAnchor;
}

BOOL isSameFile(NSString *path1, NSString *path2)
{
	struct stat sb1;
	struct stat sb2;
	stat(path1.fileSystemRepresentation, &sb1);
	stat(path2.fileSystemRepresentation, &sb2);
	return sb1.st_ino == sb2.st_ino;
}

#ifdef EMBEDDED_ROOT_HELPER
int signApp(NSString* appPath)
{
	return -1;
}
#else
int signAdhoc(NSString *filePath, NSDictionary *entitlements)
{
	if(!isLdidInstalled()) return 173;

	NSString *entitlementsPath = nil;
	NSString *signArg = @"-s";
	if(entitlements)
	{
		NSData *entitlementsXML = [NSPropertyListSerialization dataWithPropertyList:entitlements format:NSPropertyListXMLFormat_v1_0 options:0 error:nil];
		if (entitlementsXML) {
			entitlementsPath = [[NSTemporaryDirectory() stringByAppendingPathComponent:[NSUUID UUID].UUIDString] stringByAppendingPathExtension:@"plist"];
			[entitlementsXML writeToFile:entitlementsPath atomically:NO];
			signArg = [@"-S" stringByAppendingString:entitlementsPath];
		}
	}
	int ldidRet = runLdid(@[signArg, filePath], nil, nil);
	if (entitlementsPath) {
		[[NSFileManager defaultManager] removeItemAtPath:entitlementsPath error:nil];
	}

	if(ldidRet == 0)
	{
		return 0;
	}
	else
	{
		return 175;
	}
}

int signApp(NSString* appPath)
{
	NSDictionary* appInfoDict = infoDictionaryForAppPath(appPath);
	if(!appInfoDict) return 172;

	NSString* mainExecutablePath = appMainExecutablePathForAppPath(appPath);
	if(!mainExecutablePath) return 176;

	if(![[NSFileManager defaultManager] fileExistsAtPath:mainExecutablePath]) return 174;

#ifndef TROLLSTORE_LITE
	EXPLOIT_TYPE declaredPreAppliedExploitType = getDeclaredExploitTypeFromInfoDictionary(appInfoDict);
	if(isPlatformVulnerableToExploitType(declaredPreAppliedExploitType))
	{
		return 0;
	}
	else if (declaredPreAppliedExploitType != 0)
	{
	}

	if(isPlatformVulnerableToExploitType(EXPLOIT_TYPE_CUSTOM_ROOT_CERTIFICATE_V1))
	{
		SecStaticCodeRef codeRef = getStaticCodeRef(mainExecutablePath);
		if(codeRef != NULL)
		{
			if(codeCertChainContainsFakeAppStoreExtensions(codeRef))
			{
				CFRelease(codeRef);
				return 0;
			}

			CFRelease(codeRef);
		}
	}

	BOOL requiresDevMode = NO;
#endif

	BOOL hasAdditionalEncryptedBinaries = NO;

	NSURL* fileURL;
	NSDirectoryEnumerator *enumerator;

	NSMutableArray<NSDictionary*>* mainBinaryEntries = [NSMutableArray new];

	enumerator = [[NSFileManager defaultManager] enumeratorAtURL:[NSURL fileURLWithPath:appPath] includingPropertiesForKeys:nil options:0 errorHandler:nil];
	while(fileURL = [enumerator nextObject])
	{
		NSString *filePath = fileURL.path;
		if ([filePath.lastPathComponent isEqualToString:@"Info.plist"]) {
			NSDictionary *infoDict = [NSDictionary dictionaryWithContentsOfFile:filePath];
			if (!infoDict) continue;
			NSString *bundleId = infoDict[@"CFBundleIdentifier"];
			NSString *bundleExecutable = infoDict[@"CFBundleExecutable"];
			if (!bundleId || !bundleExecutable) continue;
			if ([bundleId isEqualToString:@""] || [bundleExecutable isEqualToString:@""]) continue;
			NSString *bundleMainExecutablePath = [[filePath stringByDeletingLastPathComponent] stringByAppendingPathComponent:bundleExecutable];
			if (![[NSFileManager defaultManager] fileExistsAtPath:bundleMainExecutablePath]) continue;

			NSString *packageType = infoDict[@"CFBundlePackageType"];

			if ([packageType isEqualToString:@"FMWK"]) continue;

			NSMutableDictionary *entitlementsToUse = dumpEntitlementsFromBinaryAtPath(bundleMainExecutablePath).mutableCopy;
			if (isSameFile(bundleMainExecutablePath, mainExecutablePath)) {
				if (!entitlementsToUse) {
					entitlementsToUse = @{
						@"application-identifier" : @"TROLLTROLL.*",
						@"com.apple.developer.team-identifier" : @"TROLLTROLL",
						@"get-task-allow" : (__bridge id)kCFBooleanTrue,
						@"keychain-access-groups" : @[
							@"TROLLTROLL.*",
							@"com.apple.token"
						],
					}.mutableCopy;
				}
			}

			if (!entitlementsToUse) entitlementsToUse = [NSMutableDictionary new];

#ifndef TROLLSTORE_LITE
			if (@available(iOS 16, *)){
				if (!requiresDevMode) {
					for (NSString* restrictedEntitlementKey in @[
						@"get-task-allow",
						@"task_for_pid-allow",
						@"com.apple.system-task-ports",
						@"com.apple.system-task-ports.control",
						@"com.apple.system-task-ports.token.control",
						@"com.apple.private.cs.debugger"
					]) {
						NSObject *restrictedEntitlement = entitlementsToUse[restrictedEntitlementKey];
						if (restrictedEntitlement && [restrictedEntitlement isKindOfClass:[NSNumber class]] && [(NSNumber *)restrictedEntitlement boolValue]) {
							requiresDevMode = YES;
						}
					}
				}
			}

			NSObject *containerRequiredO = entitlementsToUse[@"com.apple.private.security.container-required"];
			BOOL containerRequired = YES;
			if (containerRequiredO && [containerRequiredO isKindOfClass:[NSNumber class]]) {
				containerRequired = [(NSNumber *)containerRequiredO boolValue];
			}
			else if (containerRequiredO && [containerRequiredO isKindOfClass:[NSString class]]) {
				containerRequired = NO;
			}

			if (containerRequired) {
				NSObject *noContainerO = entitlementsToUse[@"com.apple.private.security.no-container"];
				BOOL noContainer = NO;
				if (noContainerO && [noContainerO isKindOfClass:[NSNumber class]]) {
					noContainer = [(NSNumber *)noContainerO boolValue];
				}
				NSObject *noSandboxO = entitlementsToUse[@"com.apple.private.security.no-sandbox"];
				BOOL noSandbox = NO;
				if (noSandboxO && [noSandboxO isKindOfClass:[NSNumber class]]) {
					noSandbox = [(NSNumber *)noSandboxO boolValue];
				}
				if (!noContainer && !noSandbox) {
					entitlementsToUse[@"com.apple.private.security.container-required"] = bundleId;
				}
			}
#else
			entitlementsToUse[@"jb.pmap_cs.custom_trust"] = @"PMAP_CS_APP_STORE";
#endif

			[mainBinaryEntries addObject:@{
				@"path" : bundleMainExecutablePath,
				@"entitlements" : entitlementsToUse.copy
			}];
		}
	}

	__block int signError = 0;
	dispatch_apply(mainBinaryEntries.count, dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^(size_t i) {
		NSDictionary* entry = mainBinaryEntries[i];
		int r = signAdhoc(entry[@"path"], entry[@"entitlements"]);
		if (r != 0) {
			@synchronized (mainBinaryEntries) {
				if (signError == 0) signError = r;
			}
		}
	});
	if (signError != 0) return signError;

	int r = signAdhoc(appPath, nil);
	if (r != 0) return r;

#ifndef TROLLSTORE_LITE
	NSMutableArray<NSString*>* machoPaths = [NSMutableArray new];
	enumerator = [[NSFileManager defaultManager] enumeratorAtURL:[NSURL fileURLWithPath:appPath] includingPropertiesForKeys:nil options:0 errorHandler:nil];
	while(fileURL = [enumerator nextObject])
	{
		NSString *filePath = fileURL.path;
		FAT *fat = fat_init_from_path(filePath.fileSystemRepresentation);
		if (fat) {
			MachO *machoForExtraction = fat_find_preferred_slice(fat);
			if (machoForExtraction) [machoPaths addObject:filePath];
			fat_free(fat);
		}
	}

	__block int bypassError = 0;
	__block BOOL encryptedMain = NO;
	__block BOOL additionalEncrypted = NO;
	dispatch_apply(machoPaths.count, dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^(size_t i) {
		NSString* filePath = machoPaths[i];
		FAT *fat = fat_init_from_path(filePath.fileSystemRepresentation);
		if (!fat) return;
		MachO *machoForExtraction = fat_find_preferred_slice(fat);
		if (!machoForExtraction) { fat_free(fat); return; }

		NSString *tmpPath = [NSTemporaryDirectory() stringByAppendingPathComponent:[NSUUID UUID].UUIDString];
		MemoryStream *sliceStream = macho_get_stream(machoForExtraction);
		MemoryStream *sliceOutStream = file_stream_init_from_path(tmpPath.fileSystemRepresentation, 0, 0, FILE_STREAM_FLAG_WRITABLE | FILE_STREAM_FLAG_AUTO_EXPAND);
		if (sliceOutStream) {
			memory_stream_copy_data(sliceStream, 0, sliceOutStream, 0, memory_stream_get_size(sliceStream));
			memory_stream_free(sliceOutStream);

			int br = apply_coretrust_bypass(tmpPath.fileSystemRepresentation);
			if (br == 0) {
				[[NSFileManager defaultManager] removeItemAtPath:filePath error:nil];
				[[NSFileManager defaultManager] moveItemAtPath:tmpPath toPath:filePath error:nil];
			}
			else if (br == 2) {
				if (isSameFile(filePath, mainExecutablePath)) {
					@synchronized (machoPaths) {
						encryptedMain = YES;
						bypassError = 180;
					}
				}
				else {
					@synchronized (machoPaths) {
						additionalEncrypted = YES;
					}
				}
			}
			else if (br != 3) {
				@synchronized (machoPaths) {
					if (bypassError == 0) bypassError = 185;
				}
			}
		}
		fat_free(fat);
	});

	if (encryptedMain) return 180;
	if (bypassError != 0) return bypassError;
	if (additionalEncrypted) hasAdditionalEncryptedBinaries = YES;

	if (requiresDevMode) return 182;
#else
	enumerator = [[NSFileManager defaultManager] enumeratorAtURL:[NSURL fileURLWithPath:appPath] includingPropertiesForKeys:nil options:0 errorHandler:nil];
	while(fileURL = [enumerator nextObject])
	{
		NSString *filePath = fileURL.path;
		FAT *fat = fat_init_from_path(filePath.fileSystemRepresentation);
		if (fat) {
			MachO *macho = fat_find_preferred_slice(fat);
			if (macho) {
				if (macho_is_encrypted(macho)) {
					if (isSameFile(filePath, mainExecutablePath)) {
						fat_free(fat);
						return 180;
					}
					else {
						hasAdditionalEncryptedBinaries = YES;
					}
				}
			}
			fat_free(fat);
		}
	}
#endif

	if (hasAdditionalEncryptedBinaries) {
		return 184;
	}

	return 0;
}
#endif

void applyPatchesToInfoDictionary(NSString* appPath)
{
	NSURL* appURL = [NSURL fileURLWithPath:appPath];
	NSURL* infoPlistURL = [appURL URLByAppendingPathComponent:@"Info.plist"];
	NSMutableDictionary* infoDictM = [[NSDictionary dictionaryWithContentsOfURL:infoPlistURL error:nil] mutableCopy];
	if(!infoDictM) return;

	infoDictM[@"SBAppUsesLocalNotifications"] = @1;

	NSSet* appleSchemes = systemURLSchemes();
	NSArray* CFBundleURLTypes = infoDictM[@"CFBundleURLTypes"];
	if([CFBundleURLTypes isKindOfClass:[NSArray class]])
	{
		NSMutableArray* CFBundleURLTypesM = [NSMutableArray new];

		for(NSDictionary* URLType in CFBundleURLTypes)
		{
			if(![URLType isKindOfClass:[NSDictionary class]]) continue;

			NSMutableDictionary* modifiedURLType = URLType.mutableCopy;
			NSArray* URLSchemes = URLType[@"CFBundleURLSchemes"];
			if(URLSchemes)
			{
				NSMutableSet* URLSchemesSet = [NSMutableSet setWithArray:URLSchemes];
				for(NSString* existingURLScheme in [URLSchemesSet copy])
				{
					if(![existingURLScheme isKindOfClass:[NSString class]])
					{
						[URLSchemesSet removeObject:existingURLScheme];
						continue;
					}

					if([appleSchemes containsObject:existingURLScheme.lowercaseString])
					{
						[URLSchemesSet removeObject:existingURLScheme];
					}
				}
				modifiedURLType[@"CFBundleURLSchemes"] = [URLSchemesSet allObjects];
			}
			[CFBundleURLTypesM addObject:modifiedURLType.copy];
		}

		infoDictM[@"CFBundleURLTypes"] = CFBundleURLTypesM.copy;
	}

	[infoDictM writeToURL:infoPlistURL error:nil];
}

int installApp(NSString* appPackagePath, BOOL sign, BOOL force, BOOL isTSUpdate, BOOL useInstalldMethod, BOOL skipUICache)
{
	NSString* appPayloadPath = [appPackagePath stringByAppendingPathComponent:@"Payload"];

	NSString* appBundleToInstallPath = findAppPathInBundlePath(appPayloadPath);
	if(!appBundleToInstallPath) return 167;

	NSString* appId = appIdForAppPath(appBundleToInstallPath);
	if(!appId) return 176;

	if(([appId.lowercaseString isEqualToString:@"com.opa334.trollstore"] && !isTSUpdate) || [immutableAppBundleIdentifiers() containsObject:appId.lowercaseString])
	{
		return 179;
	}

	if(!infoDictionaryForAppPath(appBundleToInstallPath)) return 172;

	if(!isTSUpdate)
	{
		applyPatchesToInfoDictionary(appBundleToInstallPath);
	}

	BOOL requiresDevMode = NO;
	BOOL hasAdditionalEncryptedBinaries = NO;

	if(sign)
	{
		int signRet = signApp(appBundleToInstallPath);
		if(signRet != 0) {
			if (signRet == 182) {
				requiresDevMode = YES;
			} else if (signRet == 184) {
				hasAdditionalEncryptedBinaries = YES;
			} else {
				return signRet;
			}
		};
	}

	MCMAppContainer* appContainer = [MCMAppContainer containerWithIdentifier:appId createIfNecessary:NO existed:nil error:nil];
	if(appContainer)
	{
		NSURL* bundleContainerURL = appContainer.url;
		NSURL* appBundleURL = findAppURLInBundleURL(bundleContainerURL);

		NSURL* trollStoreMarkURL = [bundleContainerURL URLByAppendingPathComponent:TS_ACTIVE_MARKER];
		if(appBundleURL && ![trollStoreMarkURL checkResourceIsReachableAndReturnError:nil] && !force)
		{
			return 171;
		}
		else if (appBundleURL) {
			NSURL *otherMarkerURL = [bundleContainerURL URLByAppendingPathComponent:TS_INACTIVE_MARKER];
			if ([otherMarkerURL checkResourceIsReachableAndReturnError:nil]) {
				[[NSFileManager defaultManager] removeItemAtURL:otherMarkerURL error:nil];
			}
		}

		if(!isTSUpdate)
		{
			BKSTerminateApplicationForReasonAndReportWithDescription(appId, 5, false, @"TrollStore - App updated");
		}

		if(appBundleURL)
		{
			[[NSFileManager defaultManager] removeItemAtURL:appBundleURL error:nil];
		}

		NSString* newAppBundlePath = [bundleContainerURL.path stringByAppendingPathComponent:appBundleToInstallPath.lastPathComponent];

		NSError* copyError;
		BOOL suc = [[NSFileManager defaultManager] copyItemAtPath:appBundleToInstallPath toPath:newAppBundlePath error:&copyError];
		if(!suc)
		{
			return 178;
		}
	}
	else
	{
		BOOL systemMethodSuccessful = NO;
		if(useInstalldMethod)
		{
			NSError* tmpCopyError;
			NSString* lsAppPackageTmpCopy = [NSTemporaryDirectory() stringByAppendingPathComponent:[NSUUID UUID].UUIDString];
			if(![[NSFileManager defaultManager] copyItemAtPath:appPackagePath toPath:lsAppPackageTmpCopy error:&tmpCopyError])
			{
				return 170;
			}

			NSError* installError;
			@try
			{
				systemMethodSuccessful = [[LSApplicationWorkspace defaultWorkspace] installApplication:[NSURL fileURLWithPath:lsAppPackageTmpCopy] withOptions:@{
					LSInstallTypeKey : @1,
					@"PackageType" : @"Placeholder"
				} error:&installError];
			}
			@catch(NSException* e)
			{
				systemMethodSuccessful = NO;
			}

			[[NSFileManager defaultManager] removeItemAtPath:lsAppPackageTmpCopy error:nil];
		}

		if(!systemMethodSuccessful)
		{
			NSError* mcmError;
			appContainer = [MCMAppContainer containerWithIdentifier:appId createIfNecessary:YES existed:nil error:&mcmError];

			if(!appContainer || mcmError)
			{
				return 170;
			}

			NSString* newAppBundlePath = [appContainer.url.path stringByAppendingPathComponent:appBundleToInstallPath.lastPathComponent];

			NSError* copyError;
			BOOL suc = [[NSFileManager defaultManager] copyItemAtPath:appBundleToInstallPath toPath:newAppBundlePath error:&copyError];
			if(!suc)
			{
				return 178;
			}
		}
	}

	appContainer = [MCMAppContainer containerWithIdentifier:appId createIfNecessary:NO existed:nil error:nil];

	NSURL* trollStoreMarkURL = [appContainer.url URLByAppendingPathComponent:TS_ACTIVE_MARKER];
	if(![[NSFileManager defaultManager] fileExistsAtPath:trollStoreMarkURL.path])
	{
		NSError* creationError;
		NSData* emptyData = [NSData data];
		BOOL marked = [emptyData writeToURL:trollStoreMarkURL options:0 error:&creationError];
		if(!marked)
		{
			return 177;
		}
	}

	NSURL* updatedAppURL = findAppURLInBundleURL(appContainer.url);
	fixPermissionsOfAppBundle(updatedAppURL.path);
	if (!skipUICache) {
		if (!registerPath(updatedAppURL.path, 0, !shouldRegisterAsUserByDefault())) {
			[[NSFileManager defaultManager] removeItemAtURL:appContainer.url error:nil];
			return 181;
		}
	}

	if (requiresDevMode) {
		BOOL alreadyEnabled = NO;
		if (armDeveloperMode(&alreadyEnabled)) {
			if (!alreadyEnabled) {
				return 182;
			}
		} else {
			return 183;
		}
	}

	if (hasAdditionalEncryptedBinaries) {
		return 184;
	}

	return 0;
}

int uninstallApp(NSString* appPath, NSString* appId, BOOL useCustomMethod)
{
	BOOL deleteSuc = NO;
	if(!appId && appPath)
	{
		deleteSuc = [[NSFileManager defaultManager] removeItemAtPath:[appPath stringByDeletingLastPathComponent] error:nil];
		registerPath(appPath, YES, YES);
		return 0;
	}

	if(appId)
	{
		LSApplicationProxy* appProxy = [LSApplicationProxy applicationProxyForIdentifier:appId];

		if (appProxy.dataContainerURL) {
			[[NSFileManager defaultManager] removeItemAtURL:appProxy.dataContainerURL error:nil];
		}

		[[appProxy groupContainerURLs] enumerateKeysAndObjectsUsingBlock:^(NSString* groupId, NSURL* groupURL, BOOL* stop)
		{
			NSArray<LSApplicationProxy*>* appsWithGroup = applicationsWithGroupId(groupId);
			if(appsWithGroup.count > 1)
			{
				return;
			}

			[[NSFileManager defaultManager] removeItemAtURL:groupURL error:nil];
		}];

		for(LSPlugInKitProxy* pluginProxy in appProxy.plugInKitPlugins)
		{
			NSURL* pluginURL = pluginProxy.dataContainerURL;
			if(pluginURL)
			{
				[[NSFileManager defaultManager] removeItemAtURL:pluginURL error:nil];
			}
		}

		BOOL systemMethodSuccessful = NO;
		if(!useCustomMethod)
		{
			systemMethodSuccessful = [[LSApplicationWorkspace defaultWorkspace] uninstallApplication:appId withOptions:nil];
		}

		if(!systemMethodSuccessful)
		{
			deleteSuc = [[NSFileManager defaultManager] removeItemAtPath:[appPath stringByDeletingLastPathComponent] error:nil];
			registerPath(appPath, YES, YES);
		}
		else
		{
			deleteSuc = systemMethodSuccessful;
		}
	}

	if(deleteSuc)
	{
		cleanRestrictions();
		return 0;
	}
	else
	{
		return 1;
	}
}

int uninstallAppByPath(NSString* appPath, BOOL useCustomMethod)
{
	if(!appPath) return 1;

	NSString* standardizedAppPath = appPath.stringByStandardizingPath;

	if(![standardizedAppPath hasPrefix:@"/var/containers/Bundle/Application/"] && standardizedAppPath.pathComponents.count == 5)
	{
		return 1;
	}

	NSString* appId = appIdForAppPath(standardizedAppPath);
	return uninstallApp(appPath, appId, useCustomMethod);
}

int uninstallAppById(NSString* appId, BOOL useCustomMethod)
{
	if(!appId) return 1;
	NSString* appPath = appPathForAppId(appId);
	if(!appPath) return 1;
	return uninstallApp(appPath, appId, useCustomMethod);
}

int installIpa(NSString* ipaPath, BOOL force, BOOL useInstalldMethod, BOOL skipUICache)
{
	cleanRestrictions();

	if(![[NSFileManager defaultManager] fileExistsAtPath:ipaPath]) return 166;

	BOOL suc = NO;
	NSString* tmpPackagePath = [NSTemporaryDirectory() stringByAppendingPathComponent:[NSUUID UUID].UUIDString];

	suc = [[NSFileManager defaultManager] createDirectoryAtPath:tmpPackagePath withIntermediateDirectories:NO attributes:nil error:nil];
	if(!suc) return 1;

	int extractRet = extract(ipaPath, tmpPackagePath);
	if(extractRet != 0)
	{
		[[NSFileManager defaultManager] removeItemAtPath:tmpPackagePath error:nil];
		return 168;
	}

	int ret = installApp(tmpPackagePath, YES, force, NO, useInstalldMethod, skipUICache);

	[[NSFileManager defaultManager] removeItemAtPath:tmpPackagePath error:nil];

	return ret;
}

void uninstallAllApps(BOOL useCustomMethod)
{
	for(NSString* appPath in trollStoreInstalledAppBundlePaths())
	{
		uninstallAppById(appIdForAppPath(appPath), useCustomMethod);
	}
}

int uninstallTrollStore(BOOL unregister)
{
	NSString* trollStore = trollStorePath();
	if(![[NSFileManager defaultManager] fileExistsAtPath:trollStore]) return NO;

	if(unregister)
	{
		registerPath(trollStoreAppPath(), YES, YES);
	}

	return [[NSFileManager defaultManager] removeItemAtPath:trollStore error:nil];
}

int installTrollStore(NSString* pathToTar)
{
	_CFPreferencesSetValueWithContainerType _CFPreferencesSetValueWithContainer = (_CFPreferencesSetValueWithContainerType)dlsym(RTLD_DEFAULT, "_CFPreferencesSetValueWithContainer");
	_CFPreferencesSynchronizeWithContainerType _CFPreferencesSynchronizeWithContainer = (_CFPreferencesSynchronizeWithContainerType)dlsym(RTLD_DEFAULT, "_CFPreferencesSynchronizeWithContainer");
	_CFPreferencesSetValueWithContainer(CFSTR("SBShowNonDefaultSystemApps"), kCFBooleanTrue, CFSTR("com.apple.springboard"), CFSTR("mobile"), kCFPreferencesAnyHost, kCFPreferencesNoContainer);
	_CFPreferencesSynchronizeWithContainer(CFSTR("com.apple.springboard"), CFSTR("mobile"), kCFPreferencesAnyHost, kCFPreferencesNoContainer);

	if(![[NSFileManager defaultManager] fileExistsAtPath:pathToTar]) return 1;
	if(![pathToTar.pathExtension isEqualToString:@"tar"]) return 1;

	NSString* tmpPackagePath = [NSTemporaryDirectory() stringByAppendingPathComponent:[NSUUID UUID].UUIDString];
	NSString* tmpPayloadPath = [tmpPackagePath stringByAppendingPathComponent:@"Payload"];
	BOOL suc = [[NSFileManager defaultManager] createDirectoryAtPath:tmpPayloadPath withIntermediateDirectories:YES attributes:nil error:nil];
	if(!suc) return 1;

	int extractRet = extract(pathToTar, tmpPayloadPath);
	if(extractRet != 0)
	{
		[[NSFileManager defaultManager] removeItemAtPath:tmpPackagePath error:nil];
		return 169;
	}

	NSString* tmpTrollStorePath = [tmpPayloadPath stringByAppendingPathComponent:@"TrollStore.app"];
	if(![[NSFileManager defaultManager] fileExistsAtPath:tmpTrollStorePath]) return 1;

	NSString* toInstallInfoPlistPath = [tmpTrollStorePath stringByAppendingPathComponent:@"Info.plist"];
	if(![[NSFileManager defaultManager] fileExistsAtPath:toInstallInfoPlistPath]) return 1;

	NSDictionary* toInstallInfoDict = [NSDictionary dictionaryWithContentsOfFile:toInstallInfoPlistPath];
	NSString* toInstallVersion = toInstallInfoDict[@"CFBundleVersion"];

	NSComparisonResult result = [@"1.5.0" compare:toInstallVersion options:NSNumericSearch];
	if(result != NSOrderedDescending)
	{
		NSString* existingLdidPath = [trollStoreAppPath() stringByAppendingPathComponent:@"ldid"];
		NSString* existingLdidVersionPath = [trollStoreAppPath() stringByAppendingPathComponent:@"ldid.version"];
		if([[NSFileManager defaultManager] fileExistsAtPath:existingLdidPath])
		{
			NSString* tmpLdidPath = [tmpTrollStorePath stringByAppendingPathComponent:@"ldid"];
			if(![[NSFileManager defaultManager] fileExistsAtPath:tmpLdidPath])
			{
				[[NSFileManager defaultManager] copyItemAtPath:existingLdidPath toPath:tmpLdidPath error:nil];
			}
		}
		if([[NSFileManager defaultManager] fileExistsAtPath:existingLdidVersionPath])
		{
			NSString* tmpLdidVersionPath = [tmpTrollStorePath stringByAppendingPathComponent:@"ldid.version"];
			if(![[NSFileManager defaultManager] fileExistsAtPath:tmpLdidVersionPath])
			{
				[[NSFileManager defaultManager] copyItemAtPath:existingLdidVersionPath toPath:tmpLdidVersionPath error:nil];
			}
		}
	}

	if(!getTSURLSchemeState(nil))
	{
		setTSURLSchemeState(NO, tmpTrollStorePath);
	}

	LSApplicationProxy* persistenceHelperApp = findPersistenceHelperApp(PERSISTENCE_HELPER_TYPE_SYSTEM);
	if(persistenceHelperApp)
	{
		NSString* trollStorePersistenceHelper = [tmpTrollStorePath stringByAppendingPathComponent:@"PersistenceHelper"];
		NSString* trollStoreRootHelper = [tmpTrollStorePath stringByAppendingPathComponent:@"trollstorehelper"];
		_installPersistenceHelper(persistenceHelperApp, trollStorePersistenceHelper, trollStoreRootHelper);
	}

	int ret = installApp(tmpPackagePath, NO, YES, YES, YES, NO);
	[[NSFileManager defaultManager] removeItemAtPath:tmpPackagePath error:nil];
	return ret;
}

void refreshAppRegistrations(BOOL system)
{
	registerPath(trollStoreAppPath(), NO, system);

	for(NSString* appPath in trollStoreInstalledAppBundlePaths())
	{
		registerPath(appPath, NO, system);
	}
}

BOOL _installPersistenceHelper(LSApplicationProxy* appProxy, NSString* sourcePersistenceHelper, NSString* sourceRootHelper)
{
	NSString* executablePath = appProxy.canonicalExecutablePath;
	NSString* bundlePath = appProxy.bundleURL.path;
	if(!executablePath)
	{
		NSBundle* appBundle = [NSBundle bundleWithPath:bundlePath];
		executablePath = [bundlePath stringByAppendingPathComponent:[appBundle objectForInfoDictionaryKey:@"CFBundleExecutable"]];
	}

	NSString* markPath = [bundlePath stringByAppendingPathComponent:@".TrollStorePersistenceHelper"];
	NSString* rootHelperPath = [bundlePath stringByAppendingPathComponent:@"trollstorehelper"];

	if([[NSFileManager defaultManager] fileExistsAtPath:markPath] && [[NSFileManager defaultManager] fileExistsAtPath:executablePath])
	{
		[[NSFileManager defaultManager] removeItemAtPath:executablePath error:nil];
	}

	if([[NSFileManager defaultManager] fileExistsAtPath:rootHelperPath])
	{
		[[NSFileManager defaultManager] removeItemAtPath:rootHelperPath error:nil];
	}

	if(![[NSFileManager defaultManager] copyItemAtPath:sourcePersistenceHelper toPath:executablePath error:nil])
	{
		return NO;
	}

	chmod(executablePath.fileSystemRepresentation, 0755);
	chown(executablePath.fileSystemRepresentation, 33, 33);

	NSError* error;
	if(![[NSFileManager defaultManager] copyItemAtPath:sourceRootHelper toPath:rootHelperPath error:&error])
	{
	}

	chmod(rootHelperPath.fileSystemRepresentation, 0755);
	chown(rootHelperPath.fileSystemRepresentation, 0, 0);

	if(![[NSFileManager defaultManager] fileExistsAtPath:markPath])
	{
		[[NSFileManager defaultManager] createFileAtPath:markPath contents:[NSData data] attributes:nil];
	}

	return YES;
}

void installPersistenceHelper(NSString* systemAppId, NSString *persistenceHelperBinary, NSString *rootHelperBinary)
{
	if(findPersistenceHelperApp(PERSISTENCE_HELPER_TYPE_ALL)) return;

	if (persistenceHelperBinary == nil) {
		persistenceHelperBinary = [trollStoreAppPath() stringByAppendingPathComponent:@"PersistenceHelper"];
	}
	if (rootHelperBinary == nil) {
		rootHelperBinary = [trollStoreAppPath() stringByAppendingPathComponent:@"trollstorehelper"];
	}
	LSApplicationProxy* appProxy = [LSApplicationProxy applicationProxyForIdentifier:systemAppId];
	if(!appProxy || ![appProxy.bundleType isEqualToString:@"System"]) return;

	NSString* executablePath = appProxy.canonicalExecutablePath;
	NSString* bundlePath = appProxy.bundleURL.path;
	NSString* backupPath = [bundlePath stringByAppendingPathComponent:[[executablePath lastPathComponent] stringByAppendingString:@"_TROLLSTORE_BACKUP"]];

	if([[NSFileManager defaultManager] fileExistsAtPath:backupPath]) return;

	if(![[NSFileManager defaultManager] moveItemAtPath:executablePath toPath:backupPath error:nil]) return;

	if(!_installPersistenceHelper(appProxy, persistenceHelperBinary, rootHelperBinary))
	{
		[[NSFileManager defaultManager] moveItemAtPath:backupPath toPath:executablePath error:nil];
		return;
	}

	BKSTerminateApplicationForReasonAndReportWithDescription(systemAppId, 5, false, @"TrollStore - Reload persistence helper");
}

void unregisterUserPersistenceHelper()
{
	LSApplicationProxy* userAppProxy = findPersistenceHelperApp(PERSISTENCE_HELPER_TYPE_USER);
	if(userAppProxy)
	{
		NSString* markPath = [userAppProxy.bundleURL.path stringByAppendingPathComponent:@".TrollStorePersistenceHelper"];
		[[NSFileManager defaultManager] removeItemAtPath:markPath error:nil];
	}
}

void uninstallPersistenceHelper(void)
{
	LSApplicationProxy* systemAppProxy = findPersistenceHelperApp(PERSISTENCE_HELPER_TYPE_SYSTEM);
	if(systemAppProxy)
	{
		NSString* executablePath = systemAppProxy.canonicalExecutablePath;
		NSString* bundlePath = systemAppProxy.bundleURL.path;
		NSString* backupPath = [bundlePath stringByAppendingPathComponent:[[executablePath lastPathComponent] stringByAppendingString:@"_TROLLSTORE_BACKUP"]];
		if(![[NSFileManager defaultManager] fileExistsAtPath:backupPath]) return;

		NSString* helperPath = [bundlePath stringByAppendingPathComponent:@"trollstorehelper"];
		NSString* markPath = [bundlePath stringByAppendingPathComponent:@".TrollStorePersistenceHelper"];

		[[NSFileManager defaultManager] removeItemAtPath:executablePath error:nil];
		[[NSFileManager defaultManager] removeItemAtPath:markPath error:nil];
		[[NSFileManager defaultManager] removeItemAtPath:helperPath error:nil];

		[[NSFileManager defaultManager] moveItemAtPath:backupPath toPath:executablePath error:nil];

		BKSTerminateApplicationForReasonAndReportWithDescription(systemAppProxy.bundleIdentifier, 5, false, @"TrollStore - Reload persistence helper");
	}

	LSApplicationProxy* userAppProxy = findPersistenceHelperApp(PERSISTENCE_HELPER_TYPE_USER);
	if(userAppProxy)
	{
		unregisterUserPersistenceHelper();
	}
}

void registerUserPersistenceHelper(NSString* userAppId)
{
	if(findPersistenceHelperApp(PERSISTENCE_HELPER_TYPE_ALL)) return;

	LSApplicationProxy* appProxy = [LSApplicationProxy applicationProxyForIdentifier:userAppId];
	if(!appProxy || ![appProxy.bundleType isEqualToString:@"User"]) return;

	NSString* markPath = [appProxy.bundleURL.path stringByAppendingPathComponent:@".TrollStorePersistenceHelper"];
	[[NSFileManager defaultManager] createFileAtPath:markPath contents:[NSData data] attributes:nil];
}

void cleanRestrictions(void)
{
	NSString* clientTruthPath = @"/private/var/containers/Shared/SystemGroup/systemgroup.com.apple.configurationprofiles/Library/ConfigurationProfiles/ClientTruth.plist";
	NSURL* clientTruthURL = [NSURL fileURLWithPath:clientTruthPath];
	NSDictionary* clientTruthDictionary = [NSDictionary dictionaryWithContentsOfURL:clientTruthURL];

	if(!clientTruthDictionary) return;

	NSArray* valuesArr;

	NSDictionary* lsdAppRemoval = clientTruthDictionary[@"com.apple.lsd.appremoval"];
	if(lsdAppRemoval && [lsdAppRemoval isKindOfClass:NSDictionary.class])
	{
		NSDictionary* clientRestrictions = lsdAppRemoval[@"clientRestrictions"];
		if(clientRestrictions && [clientRestrictions isKindOfClass:NSDictionary.class])
		{
			NSDictionary* unionDict = clientRestrictions[@"union"];
			if(unionDict && [unionDict isKindOfClass:NSDictionary.class])
			{
				NSDictionary* removedSystemAppBundleIDs = unionDict[@"removedSystemAppBundleIDs"];
				if(removedSystemAppBundleIDs && [removedSystemAppBundleIDs isKindOfClass:NSDictionary.class])
				{
					valuesArr = removedSystemAppBundleIDs[@"values"];
				}
			}
		}
	}

	if(!valuesArr || !valuesArr.count) return;

	NSMutableArray* valuesArrM = valuesArr.mutableCopy;
	__block BOOL changed = NO;

	[valuesArrM enumerateObjectsWithOptions:NSEnumerationReverse usingBlock:^(NSString* value, NSUInteger idx, BOOL *stop)
	{
		if(!isRemovableSystemApp(value))
		{
			[valuesArrM removeObjectAtIndex:idx];
			changed = YES;
		}
	}];

	if(!changed) return;

	NSMutableDictionary* clientTruthDictionaryM = (__bridge_transfer NSMutableDictionary*)CFPropertyListCreateDeepCopy(kCFAllocatorDefault, (__bridge CFDictionaryRef)clientTruthDictionary, kCFPropertyListMutableContainersAndLeaves);

	clientTruthDictionaryM[@"com.apple.lsd.appremoval"][@"clientRestrictions"][@"union"][@"removedSystemAppBundleIDs"][@"values"] = valuesArrM;

	[clientTruthDictionaryM writeToURL:clientTruthURL error:nil];

	killall(@"profiled", NO);
}

NSDictionary* dumpEntitlementsFromBinary(NSString* binaryPath)
{
	if(!binaryPath) return nil;
	if(![[NSFileManager defaultManager] fileExistsAtPath:binaryPath]) return nil;
	return dumpEntitlementsFromBinaryAtPath(binaryPath);
}

int TSRootHelperSetEntitlementsForBinary(NSString* binaryPath, NSDictionary* entitlements)
{
	if(!binaryPath) return 1;
	if(![[NSFileManager defaultManager] fileExistsAtPath:binaryPath]) return 1;
	if(!entitlements) entitlements = @{};

	int r = signAdhoc(binaryPath, entitlements);
	if(r != 0) return r;

	FAT* fat = fat_init_from_path(binaryPath.fileSystemRepresentation);
	if(!fat) return 0;

	MachO* macho = fat_find_preferred_slice(fat);
	if(!macho) { fat_free(fat); return 0; }

	NSString* tmpPath = [NSTemporaryDirectory() stringByAppendingPathComponent:[NSUUID UUID].UUIDString];
	MemoryStream* sliceStream = macho_get_stream(macho);
	MemoryStream* sliceOutStream = file_stream_init_from_path(tmpPath.fileSystemRepresentation, 0, 0, FILE_STREAM_FLAG_WRITABLE | FILE_STREAM_FLAG_AUTO_EXPAND);
	if(sliceOutStream)
	{
		memory_stream_copy_data(sliceStream, 0, sliceOutStream, 0, memory_stream_get_size(sliceStream));
		memory_stream_free(sliceOutStream);
		int br = apply_coretrust_bypass(tmpPath.fileSystemRepresentation);
		if(br == 0)
		{
			[[NSFileManager defaultManager] removeItemAtPath:binaryPath error:nil];
			[[NSFileManager defaultManager] moveItemAtPath:tmpPath toPath:binaryPath error:nil];
		}
		else if(br == 2)
		{
			fat_free(fat);
			return 180;
		}
		else if(br != 3)
		{
			fat_free(fat);
			return 185;
		}
	}
	fat_free(fat);
	return 0;
}

int TSRootHelperSetEntitlementsForApp(NSString* appPath, NSDictionary* entitlements)
{
	if(!appPath) return 1;
	if(![[NSFileManager defaultManager] fileExistsAtPath:appPath]) return 1;

	NSDictionary* appInfoDict = infoDictionaryForAppPath(appPath);
	if(!appInfoDict) return 172;

	NSString* mainExecutablePath = appMainExecutablePathForAppPath(appPath);
	if(!mainExecutablePath) return 176;
	if(![[NSFileManager defaultManager] fileExistsAtPath:mainExecutablePath]) return 174;

	NSMutableDictionary* ents = entitlements.mutableCopy;
	if(!ents) ents = [NSMutableDictionary new];

	NSObject* containerRequiredO = ents[@"com.apple.private.security.container-required"];
	BOOL containerRequired = YES;
	if(containerRequiredO && [containerRequiredO isKindOfClass:[NSNumber class]])
	{
		containerRequired = [(NSNumber*)containerRequiredO boolValue];
	}
	else if(containerRequiredO && [containerRequiredO isKindOfClass:[NSString class]])
	{
		containerRequired = NO;
	}
	if(containerRequired)
	{
		NSObject* noContainerO = ents[@"com.apple.private.security.no-container"];
		BOOL noContainer = NO;
		if(noContainerO && [noContainerO isKindOfClass:[NSNumber class]])
		{
			noContainer = [(NSNumber*)noContainerO boolValue];
		}
		NSObject* noSandboxO = ents[@"com.apple.private.security.no-sandbox"];
		BOOL noSandbox = NO;
		if(noSandboxO && [noSandboxO isKindOfClass:[NSNumber class]])
		{
			noSandbox = [(NSNumber*)noSandboxO boolValue];
		}
		if(!noContainer && !noSandbox)
		{
			ents[@"com.apple.private.security.container-required"] = appIdForAppPath(appPath);
		}
	}

	int r = TSRootHelperSetEntitlementsForBinary(mainExecutablePath, ents.copy);
	if(r != 0) return r;

	NSDirectoryEnumerator* enumerator = [[NSFileManager defaultManager] enumeratorAtURL:[NSURL fileURLWithPath:appPath] includingPropertiesForKeys:nil options:0 errorHandler:nil];
	NSURL* fileURL;
	while(fileURL = [enumerator nextObject])
	{
		NSString* filePath = fileURL.path;
		if([filePath isEqualToString:mainExecutablePath]) continue;
		if(![filePath.lastPathComponent isEqualToString:@"Info.plist"]) continue;
		NSDictionary* infoDict = [NSDictionary dictionaryWithContentsOfFile:filePath];
		if(!infoDict) continue;
		NSString* bundleId = infoDict[@"CFBundleIdentifier"];
		NSString* bundleExecutable = infoDict[@"CFBundleExecutable"];
		if(!bundleId || !bundleExecutable) continue;
		NSString* bundleMainExecutablePath = [[filePath stringByDeletingLastPathComponent] stringByAppendingPathComponent:bundleExecutable];
		if(![[NSFileManager defaultManager] fileExistsAtPath:bundleMainExecutablePath]) continue;
		NSDictionary* pluginEnts = dumpEntitlementsFromBinaryAtPath(bundleMainExecutablePath);
		if(!pluginEnts) pluginEnts = @{};
		NSMutableDictionary* pluginEntsM = pluginEnts.mutableCopy;
		pluginEntsM[@"com.apple.private.security.container-required"] = bundleId;
		int pr = TSRootHelperSetEntitlementsForBinary(bundleMainExecutablePath, pluginEntsM.copy);
		if(pr != 0) return pr;
	}

	fixPermissionsOfAppBundle(appPath);
	return 0;
}

int MAIN_NAME(int argc, char *argv[], char *envp[])
{
	@autoreleasepool {
		if(argc <= 1) return -1;

		if(getuid() != 0)
		{
			return -1;
		}

		NSMutableArray* args = [NSMutableArray new];
		for (int i = 1; i < argc; i++)
		{
			[args addObject:[NSString stringWithUTF8String:argv[i]]];
		}

		int ret = 0;
		NSString* cmd = args.firstObject;
		if([cmd isEqualToString:@"install"])
		{
			if(args.count < 2) return -3;
			BOOL useInstalldMethod = [args containsObject:@"installd"];
			BOOL force = [args containsObject:@"force"];
			BOOL skipUICache = [args containsObject:@"skip-uicache"];
			NSString* ipaPath = args.lastObject;
			ret = installIpa(ipaPath, force, useInstalldMethod, skipUICache);
		}
		else if([cmd isEqualToString:@"uninstall"])
		{
			if(args.count < 2) return -3;
			BOOL useCustomMethod = [args containsObject:@"custom"];
			NSString* appId = args.lastObject;
			ret = uninstallAppById(appId, useCustomMethod);
		}
		else if([cmd isEqualToString:@"uninstall-path"])
		{
			if(args.count < 2) return -3;
			BOOL useCustomMethod = [args containsObject:@"custom"];
			NSString* appPath = args.lastObject;
			ret = uninstallAppByPath(appPath, useCustomMethod);
		}
		else if([cmd isEqualToString:@"refresh"])
		{
			refreshAppRegistrations(!shouldRegisterAsUserByDefault());
		}
		else if([cmd isEqualToString:@"refresh-all"])
		{
			cleanRestrictions();
			[[NSFileManager defaultManager] removeItemAtPath:@"/var/containers/Shared/SystemGroup/systemgroup.com.apple.lsd.iconscache/Library/Caches/com.apple.IconsCache" error:nil];
			[[LSApplicationWorkspace defaultWorkspace] _LSPrivateRebuildApplicationDatabasesForSystemApps:YES internal:YES user:YES];
			if (!shouldRegisterAsUserByDefault()) refreshAppRegistrations(YES);
			killall(@"backboardd", YES);
		}
		else if([cmd isEqualToString:@"url-scheme"])
		{
			if(args.count < 2) return -3;
			NSString* modifyArg = args.lastObject;
			BOOL newState = [modifyArg isEqualToString:@"enable"];
			if(newState == YES || [modifyArg isEqualToString:@"disable"])
			{
				setTSURLSchemeState(newState, nil);
			}
		}
		else if([cmd isEqualToString:@"reboot"])
		{
			[[FBSSystemService sharedService] reboot];
			sleep(1);
		}
		else if([cmd isEqualToString:@"respring"])
		{
			respring();
		}
		else if([cmd isEqualToString:@"enable-jit"])
		{
			if(args.count < 2) return -3;
			NSString* userAppId = args.lastObject;
			ret = enableJIT(userAppId);
		}
		else if([cmd isEqualToString:@"modify-registration"])
		{
			if(args.count < 3) return -3;
			NSString* appPath = args[1];
			NSString* newRegistration = args[2];

			NSString* trollStoreMark = [[appPath stringByDeletingLastPathComponent] stringByAppendingPathComponent:TS_ACTIVE_MARKER];
			if([[NSFileManager defaultManager] fileExistsAtPath:trollStoreMark])
			{
				registerPath(appPath, NO, [newRegistration isEqualToString:@"System"]);
			}
		}
		else if ([cmd isEqualToString:@"transfer-apps"])
		{
			bool oneFailed = false;
			for (NSString *appBundlePath in trollStoreInactiveInstalledAppBundlePaths()) {
				NSString *tmpPath = [NSTemporaryDirectory() stringByAppendingPathComponent:[NSUUID UUID].UUIDString];
				if (![[NSFileManager defaultManager] createDirectoryAtPath:tmpPath withIntermediateDirectories:YES attributes:nil error:nil]) return -3;

				NSString *tmpAppPath = [tmpPath stringByAppendingPathComponent:appBundlePath.lastPathComponent];
				if (![[NSFileManager defaultManager] copyItemAtPath:appBundlePath toPath:tmpAppPath error:nil]) {
					[[NSFileManager defaultManager] removeItemAtPath:tmpPath error:nil];
					oneFailed = true;
					continue;
				}

				int signRet = signApp(tmpAppPath);

				if (signRet == 0 || signRet == 182 || signRet == 184) {
					[[NSFileManager defaultManager] removeItemAtPath:appBundlePath error:nil];
					[[NSFileManager defaultManager] moveItemAtPath:tmpAppPath toPath:appBundlePath error:nil];
					[[NSFileManager defaultManager] removeItemAtPath:tmpPath error:nil];
				}
				else {
					[[NSFileManager defaultManager] removeItemAtPath:tmpPath error:nil];
					oneFailed = true;
					continue;
				}

				fixPermissionsOfAppBundle(appBundlePath);

				NSString *containerPath = [appBundlePath stringByDeletingLastPathComponent];
				NSString *activeMarkerPath = [containerPath stringByAppendingPathComponent:TS_ACTIVE_MARKER];
				NSString *inactiveMarkerPath = [containerPath stringByAppendingPathComponent:TS_INACTIVE_MARKER];

				NSData* emptyData = [NSData data];
				[emptyData writeToFile:activeMarkerPath options:0 error:nil];

				[[NSFileManager defaultManager] removeItemAtPath:inactiveMarkerPath error:nil];

				registerPath(appBundlePath, 0, !shouldRegisterAsUserByDefault());
			}
			if (oneFailed) ret = -1;
		}
		else if([cmd isEqualToString:@"dump-entitlements"])
		{
			if(args.count < 2) return -3;
			NSString* binaryPath = args.lastObject;
			NSDictionary* ents = dumpEntitlementsFromBinary(binaryPath);
			if(ents)
			{
				NSData* data = [NSPropertyListSerialization dataWithPropertyList:ents format:NSPropertyListXMLFormat_v1_0 options:0 error:nil];
				if(data)
				{
					fwrite(data.bytes, 1, data.length, stdout);
				}
			}
		}
		else if([cmd isEqualToString:@"set-entitlements-binary"])
		{
			if(args.count < 3) return -3;
			NSString* binaryPath = args[1];
			NSString* plistPath = args[2];
			NSDictionary* ents = [NSDictionary dictionaryWithContentsOfFile:plistPath];
			if(!ents) return -4;
			ret = TSRootHelperSetEntitlementsForBinary(binaryPath, ents);
		}
		else if([cmd isEqualToString:@"set-entitlements-app"])
		{
			if(args.count < 3) return -3;
			NSString* appPath = args[1];
			NSString* plistPath = args[2];
			NSDictionary* ents = [NSDictionary dictionaryWithContentsOfFile:plistPath];
			if(!ents) return -4;
			ret = TSRootHelperSetEntitlementsForApp(appPath, ents);
		}
#ifndef TROLLSTORE_LITE
		else if([cmd isEqualToString:@"install-trollstore"])
		{
			if(args.count < 2) return -3;
			NSString* tsTar = args.lastObject;
			ret = installTrollStore(tsTar);
		}
		else if([cmd isEqualToString:@"uninstall-trollstore"])
		{
			if(![args containsObject:@"preserve-apps"])
			{
				uninstallAllApps([args containsObject:@"custom"]);
			}
			uninstallTrollStore(YES);
		}
		else if([cmd isEqualToString:@"install-ldid"])
		{
			if(args.count < 3) return -3;
			NSString* ldidPath = args[1];
			NSString* ldidVersion = args[2];
			installLdid(ldidPath, ldidVersion);
		}
		else if([cmd isEqualToString:@"install-persistence-helper"])
		{
			if(args.count < 2) return -3;
			NSString* systemAppId = args[1];
			NSString* persistenceHelperBinary;
			NSString* rootHelperBinary;
			if (args.count == 4) {
				persistenceHelperBinary = args[2];
				rootHelperBinary = args[3];
			}

			installPersistenceHelper(systemAppId, persistenceHelperBinary, rootHelperBinary);
		}
		else if([cmd isEqualToString:@"uninstall-persistence-helper"])
		{
			uninstallPersistenceHelper();
		}
		else if([cmd isEqualToString:@"register-user-persistence-helper"])
		{
			if(args.count < 2) return -3;
			NSString* userAppId = args.lastObject;
			registerUserPersistenceHelper(userAppId);
		}
		else if([cmd isEqualToString:@"check-dev-mode"])
		{
			ret = !checkDeveloperMode();
		}
		else if([cmd isEqualToString:@"arm-dev-mode"])
		{
			ret = !armDeveloperMode(NULL);
		}
#endif

		return ret;
	}
}