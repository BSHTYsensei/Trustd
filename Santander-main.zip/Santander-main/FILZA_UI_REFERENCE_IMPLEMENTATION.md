# Filza-style browser UI implementation notes

This pass uses the user's `逆向.zip` archive as the reference (not `逆向2.zip`).

## Reverse-engineering evidence used

- `TGDirectoryInfoView.h`: list-mode directory footer has `fileSystemLabel`, `itemsLabel`, `spaceLabel`, `lockImage`, a delegate, and setters for filesystem, item-count, and disk-usage information.
- `TGInfoFooterCollectionReusableView.h`: grid mode has a matching collection reusable footer with the same four information elements.
- `TIGIBrowserView.h`: the browser owns both list and grid footer objects, a top toolbar, current filesystem/read-only state, current item-count and disk-space values, and footer-size/content-inset layout methods.
- `ListViewRowCell.h`: the classic list cell has independent name, detail/date, size, permissions, and icon views.
- `FileAttributes.h` / `FileItem.h`: file information includes type, size, dates, owner/group, permissions, and file attributes.

The archive is static class/header analysis; it does not contain a captured live Filza screen session. The implementation therefore follows the documented class structure and property/method surface rather than claiming a pixel-perfect copy of an unavailable live build.

## Santander implementation

- `SantanderDirectoryInfoFooterView` mirrors the four footer values. In list mode it is assigned to `UITableView.tableFooterView`, so it appears immediately after the last file and scrolls with the directory contents; it is no longer pinned to the screen bottom or layered over the last rows. In grid mode it remains a `UICollectionView` section footer.
- The 62-point footer shows filesystem/device, file/folder/hidden counts, used/free storage, and a read-only/writable lock indicator. Its three text lines use compact but readable type, and tapping it opens a detailed filesystem page (mount point, capacity, block size, inode counts, and directory counts).
- `SantanderFileListCell` mirrors Filza's separate name/detail/size/permissions/icon fields but uses direct frame layout rather than per-row `UIStackView` and Auto Layout constraints. The permission text is a POSIX mode string such as `drwxr-xr-x`.
- The list header provides search and Name/Date/Size sorting plus a grid-view shortcut, with the active sort and direction indicated inline.
- The properties page additionally shows owner UID, group GID, rwx matrix, special permission bits, parent directory, and octal POSIX mode.

The lock state uses the mounted filesystem's read-only flag and the current app process's directory write access. This is a local UI capability indicator; it does not claim that a privileged helper can override a permission denied by the app process.

## Performance and compatibility changes

- Name and type sorting no longer retrieve file sizes or timestamps for every row. Size and date sort modes fetch only the resource key required by the selected sort.
- Directory enumeration prefetches the URL resource keys used to initialize each `Path`; `Path.init` uses the prefetched directory bit and only falls back to `fileExists` if it is unavailable.
- Metadata presentation performs one `lstat` per requested entry and derives file type, size, modification time, and POSIX permissions from that result. It no longer enumerates each child directory just to display a folder count or performs duplicate attribute/resource-value queries while scrolling.
- Date and byte formatters are shared behind a small lock; metadata work is limited to three concurrent workers. Completion notifications are coalesced into a batch so a burst of rows does not trigger one table reload per file.
- Grid entrance animations were removed; metadata completion updates visible grid cells in place.
- The Makefile's minimum deployment target remains iOS 14.0. The redesign uses UIKit APIs available at that deployment level; APIs with later availability remain guarded by `#available` checks.

The reverse-engineering archive contains static class/header evidence, not a live Filza runtime capture. This is a structure-matched implementation, not a claim of pixel-perfect equivalence. A full Xcode build and on-device frame-time test are still required before calling performance verified.
