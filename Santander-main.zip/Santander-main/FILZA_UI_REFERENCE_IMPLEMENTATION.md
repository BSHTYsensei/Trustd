# Filza-style browser UI implementation notes

This pass uses the user's `逆向.zip` archive as the reference (not `逆向2.zip`).

## Reverse-engineering evidence used

- `TGDirectoryInfoView.h`: list-mode directory footer has `fileSystemLabel`, `itemsLabel`, `spaceLabel`, `lockImage`, a delegate, and setters for filesystem, item-count, and disk-usage information.
- `TGInfoFooterCollectionReusableView.h`: grid mode has a matching collection reusable footer with the same four information elements.
- `TIGIBrowserView.h`: the browser owns both list and grid footer objects, a top toolbar, current filesystem/read-only state, current item-count and disk-space values, and footer-size/content-inset layout methods.
- `ListViewRowCell.h`: the classic list cell has independent name, detail/date, size, permissions, and icon views.
- `FileAttributes.h` / `FileItem.h`: file information includes type, size, dates, owner/group, permissions, and file attributes.

The archive is static class/header analysis; it does not contain a captured live Filza screen session. The implementation therefore follows the documented class structure and property/method surface rather than claiming a pixel-perfect copy of an unavailable live build.

## Santander implementation

- `SantanderDirectoryInfoFooterView` mirrors the four footer values. In list mode it is pinned to the bottom of the browser's own table viewport, while the table reserves bottom inset so the last row remains reachable. In grid mode it is a `UICollectionView` section footer.
- The footer shows filesystem/device, file/folder/hidden counts, used/free storage, and a bottom-aligned read-only/writable lock indicator. Tapping it opens a detailed filesystem page (mount point, capacity, block size, inode counts, and directory counts).
- `SantanderFileListCell` mirrors Filza's separate name/detail/size/permissions/icon fields. The permission text is a POSIX mode string such as `drwxr-xr-x`.
- The list header provides search and Name/Date/Size sorting plus a grid-view shortcut.
- The properties page additionally shows owner UID, group GID, rwx matrix, special permission bits, parent directory, and octal POSIX mode.

The lock state uses the mounted filesystem's read-only flag and the current app process's directory write access. This is a local UI capability indicator; it does not claim that a privileged helper can override a permission denied by the app process.
