# Filza-style browser UI implementation notes

This revision uses only `逆向.zip` as the Filza reference. `逆向2.zip` was not read or merged.

## Reverse-engineering evidence

- `TIGIBrowserView.h` shows the core browser is a UIKit view coordinating a `UITableView`, a `UICollectionView`, a top toolbar, and separate list/grid directory-info footers.
- `ListViewRowCell.h` is a real `UITableViewCell` subclass with icon, name, detail, size, and permissions fields.
- `TGDirectoryInfoView.h` exposes filesystem, item-count, disk-space, and lock state.
- `TGInfoFooterCollectionReusableView.h` confirms that grid mode uses a collection reusable footer.
- These are static class/interface findings. The archive contains no live Filza capture, so this is a structure-guided rebuild rather than a claim of pixel-perfect reproduction.

## Rebuilt browser architecture

- The primary browser remains `UITableViewController` with the standard `UITableView` data-source/delegate path. The main list cell now subclasses the native `UITableViewCell` subtitle style. It uses UIKit's built-in icon/text/detail layout rather than per-cell `UIStackView` trees or custom constraint graphs. Metadata is compactly composed into the secondary line.
- Search remains a system `UISearchController`. Search, sorting, selection, create, paste, grid, and terminal actions are exposed through the standard navigation-bar `UIBarButtonItem` / `UIMenu` surface. The separate custom horizontal header has been removed.
- The list directory-info view is assigned through `UITableView.tableFooterView`, so it follows the last file and scrolls with the content. It is not pinned to the visible bottom edge and does not cover rows. The view uses simple frame layout and readable 11–12 pt UIKit labels (70 pt total height).
- Grid mode remains a standard `UICollectionView` + `UICollectionViewFlowLayout`; its information footer reuses the same `UICollectionReusableView` class.
- The first directory read starts from `viewDidLoad` on a background queue and is guarded against duplicate starts. The table keeps a native UIKit loading indicator visible until the background read actually completes; only then is it removed and replaced by rows or an explicit empty/permission state. This fixes the prior startup lifecycle bug where an early empty-state pass cleared the loading view before enumeration finished, leaving a blank first screen. Global search is excluded from normal directory loading/footer setup.
- The first install defaults to Filza's classic light appearance; an explicitly saved system/dark preference remains respected. This prevents a device-wide dark appearance from becoming the accidental first-run default.

## Stability and performance guardrails

- No SwiftUI view is used for the primary file browser. The main browser uses UIKit controllers, UIKit table/collection views, system navigation bars/toolbars, and standard cells.
- Cell configuration does not perform synchronous recursive directory scans. Icons and metadata continue through the existing caches/background queues.
- The list uses one `displayedRows` model and one `reloadData()` update path. Directory monitoring and asynchronous loads are generation-checked before touching the visible table.
- The status footer is a native table footer; there is no overlay subview, z-position pinning, or artificial bottom content inset.
- Minimum deployment target remains iOS 14.0. APIs introduced after iOS 14 remain protected by availability checks.

## Validation limits

Swift parser checks, source guardrails, plist validation, and ZIP integrity checks can be run in this environment. A complete iOS UIKit type-check/build, code signing, launch test, and scroll-performance test require Xcode, the Apple iOS SDK, and a real/simulated iOS device. Those device-level checks are not represented as completed here.
