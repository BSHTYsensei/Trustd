import Foundation
import Darwin
import ArgumentParser
import ImageIO
import ObjectiveC
import UIKit
import libarchive

extension URL: ExpressibleByArgument {
    public init?(argument: String) {
        self.init(fileURLWithPath: argument)
    }
}

struct StringError: LocalizedError, CustomStringConvertible {
    let description: String

    init(_ description: String) {
        self.description = description
    }

    var errorDescription: String? {
        description
    }
}

struct CodableRendition {
    let renditionName: String
    let itemData: Data?
}

private enum HelperCoreUIRuntime {
    static let coreUIHandle = dlopen(
        "/System/Library/PrivateFrameworks/CoreUI.framework/CoreUI",
        RTLD_LAZY | RTLD_LOCAL
    )

    static func method(_ receiver: AnyObject, _ selector: Selector) -> Method? {
        guard let cls = object_getClass(receiver) else { return nil }
        return class_getInstanceMethod(cls, selector)
    }

    private static func isCompatible(
        _ method: Method,
        argumentCount: Int,
        returnTypes: Set<Character>,
        argumentTypes: [Set<Character>] = []
    ) -> Bool {
        guard method_getNumberOfArguments(method) == UInt32(argumentCount) else { return false }
        var returnBuffer = [CChar](repeating: 0, count: 32)
        method_getReturnType(method, &returnBuffer, returnBuffer.count)
        let qualifiers: Set<Character> = ["r", "n", "N", "o", "O", "R", "V"]
        guard let returnCode = String(cString: returnBuffer).first(where: { !qualifiers.contains($0) }),
              returnTypes.contains(returnCode) else { return false }

        var selfBuffer = [CChar](repeating: 0, count: 8)
        var commandBuffer = [CChar](repeating: 0, count: 8)
        method_getArgumentType(method, 0, &selfBuffer, selfBuffer.count)
        method_getArgumentType(method, 1, &commandBuffer, commandBuffer.count)
        guard String(cString: selfBuffer).first == "@",
              String(cString: commandBuffer).first == ":" else { return false }

        guard argumentTypes.isEmpty || argumentTypes.count == argumentCount - 2 else { return false }
        for (index, accepted) in argumentTypes.enumerated() {
            var buffer = [CChar](repeating: 0, count: 16)
            method_getArgumentType(method, UInt32(index + 2), &buffer, buffer.count)
            guard let code = String(cString: buffer).first(where: { !qualifiers.contains($0) }),
                  accepted.contains(code) else { return false }
        }
        return true
    }

    static func object(_ receiver: AnyObject, _ selector: Selector) -> AnyObject? {
        guard let method = method(receiver, selector),
              isCompatible(method, argumentCount: 2, returnTypes: ["@", "#"]) else { return nil }
        typealias Function = @convention(c) (AnyObject, Selector) -> Unmanaged<AnyObject>?
        let function = unsafeBitCast(method_getImplementation(method), to: Function.self)
        return function(receiver, selector)?.takeUnretainedValue()
    }

    static func object(_ receiver: AnyObject, _ selector: Selector, _ argument: AnyObject?) -> AnyObject? {
        guard let method = method(receiver, selector),
              isCompatible(method, argumentCount: 3, returnTypes: ["@", "#"], argumentTypes: [["@"]]) else { return nil }
        typealias Function = @convention(c) (AnyObject, Selector, AnyObject?) -> Unmanaged<AnyObject>?
        let function = unsafeBitCast(method_getImplementation(method), to: Function.self)
        return function(receiver, selector, argument)?.takeUnretainedValue()
    }

    static func data(_ receiver: AnyObject, _ selector: Selector) -> Data? {
        guard let value = object(receiver, selector) else { return nil }
        if let data = value as? Data { return data }
        if let data = value as? NSData { return data as Data }
        return nil
    }

    static func int64(_ receiver: AnyObject, _ selector: Selector) -> Int64? {
        guard let method = method(receiver, selector),
              isCompatible(method, argumentCount: 2, returnTypes: ["q", "Q", "l", "L", "i", "I"]) else { return nil }
        typealias Function = @convention(c) (AnyObject, Selector) -> Int64
        let function = unsafeBitCast(method_getImplementation(method), to: Function.self)
        return function(receiver, selector)
    }

    static func image(_ receiver: AnyObject, _ selector: Selector) -> CGImage? {
        guard let method = method(receiver, selector),
              isCompatible(method, argumentCount: 2, returnTypes: ["@", "#", "^"]) else { return nil }
        typealias Function = @convention(c) (AnyObject, Selector) -> Unmanaged<CGImage>?
        let function = unsafeBitCast(method_getImplementation(method), to: Function.self)
        return function(receiver, selector)?.takeUnretainedValue()
    }

    static func block(_ receiver: AnyObject, _ selector: Selector, _ callback: @escaping (AnyObject) -> Void) {
        guard let method = method(receiver, selector),
              isCompatible(method, argumentCount: 3, returnTypes: ["v"], argumentTypes: [["@", "?"]]) else { return }
        typealias Block = @convention(block) (AnyObject) -> Void
        let block: Block = { object in callback(object) }
        let blockObject = unsafeBitCast(block, to: AnyObject.self)
        typealias Function = @convention(c) (AnyObject, Selector, AnyObject) -> Void
        let function = unsafeBitCast(method_getImplementation(method), to: Function.self)
        function(receiver, selector, blockObject)
    }

    static func allocateAndInitialize(className: String, initializer: Selector, argument: AnyObject) -> AnyObject? {
        _ = coreUIHandle
        guard let cls = NSClassFromString(className),
              let allocated = object(cls as AnyObject, NSSelectorFromString("alloc")) else {
            return nil
        }
        return object(allocated, initializer, argument)
    }
}

final class AssetCatalogWrapper {
    static let shared = AssetCatalogWrapper()

    private init() {}

    func renditions(forCarArchive url: URL) throws -> [CodableRendition] {
        guard FileManager.default.fileExists(atPath: url.path) else {
            throw StringError("Asset catalog does not exist: \(url.path)")
        }

        guard let catalog =
                HelperCoreUIRuntime.allocateAndInitialize(
                    className: "CUICatalog",
                    initializer: NSSelectorFromString("initWithURL:"),
                    argument: url as NSURL
                )
                ?? HelperCoreUIRuntime.allocateAndInitialize(
                    className: "CUICatalog",
                    initializer: NSSelectorFromString("initWithContentsOfURL:"),
                    argument: url as NSURL
                ) else {
            throw StringError("CoreUI CUICatalog is unavailable on this OS.")
        }

        var result: [CodableRendition] = []
        HelperCoreUIRuntime.block(
            catalog,
            Selector(("enumerateNamedLookupsUsingBlock:"))
        ) { lookup in
            let lookupName = HelperCoreUIRuntime.object(lookup, Selector(("name"))) as? String
                ?? "Unnamed Asset"
            let rendition = HelperCoreUIRuntime.object(lookup, Selector(("rendition"))) ?? lookup
            let key = HelperCoreUIRuntime.object(lookup, Selector(("key")))
            let isIcon: Bool
            if let key {
                isIcon = HelperCoreUIRuntime.int64(key, Selector(("themeElement"))) == 85
                    && HelperCoreUIRuntime.int64(key, Selector(("themePart"))) == 220
            } else {
                isIcon = false
            }
            let renditionName = isIcon
                ? (HelperCoreUIRuntime.object(rendition, Selector(("name"))) as? String ?? lookupName)
                : lookupName

            let itemData =
                HelperCoreUIRuntime.data(rendition, Selector(("srcData")))
                ?? HelperCoreUIRuntime.data(rendition, NSSelectorFromString("data"))
                ?? Self.imageData(rendition)

            result.append(CodableRendition(renditionName: renditionName, itemData: itemData))
        }
        return result
    }

    private static func imageData(_ rendition: AnyObject) -> Data? {
        if let image = HelperCoreUIRuntime.image(rendition, Selector(("uncroppedImage"))) {
            return UIImage(cgImage: image).pngData()
        }

        guard let data = HelperCoreUIRuntime.data(rendition, NSSelectorFromString("data")) else {
            return nil
        }

        if let source = CGImageSourceCreateWithData(data as CFData, nil),
           let image = CGImageSourceCreateImageAtIndex(source, 0, nil) {
            return UIImage(cgImage: image).pngData()
        }

        guard let provider = CGDataProvider(data: data as CFData),
              let document = CGPDFDocument(provider),
              let page = document.page(at: 1) else {
            return nil
        }

        let rect = page.getBoxRect(.mediaBox)
        let width = max(1, Int(rect.width.rounded(.up)))
        let height = max(1, Int(rect.height.rounded(.up)))
        guard let colorSpace = CGColorSpace(name: CGColorSpace.sRGB),
              let context = CGContext(
                data: nil,
                width: width,
                height: height,
                bitsPerComponent: 8,
                bytesPerRow: 0,
                space: colorSpace,
                bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue
              ),
              let image = {
                  context.drawPDFPage(page)
                  return context.makeImage()
              }() else {
            return nil
        }
        return UIImage(cgImage: image).pngData()
    }
}

final class Compression {
    enum FormatType: String, CaseIterable, CustomStringConvertible, Codable {
        case zip
        case tar
        case tarGzip = "tar.gz"
        case tarBzip2 = "tar.bz2"
        case tarXz = "tar.xz"
        case tarZstd = "tar.zst"
        case tarLz4 = "tar.lz4"
        case sevenZip = "7z"
        case cpio
        case ar
        case iso9660 = "iso"
        case mtree
        case warc
        case xar
        case gzip = "gz"
        case bzip2 = "bz2"
        case xz
        case zstd = "zst"
        case lz4

        var description: String { rawValue.uppercased() }

        var isStandaloneStream: Bool {
            switch self {
            case .gzip, .bzip2, .xz, .zstd, .lz4: return true
            default: return false
            }
        }
    }

    static let shared = Compression()

    private init() {}

    func compress(paths: [URL], outputPath: URL, format: FormatType) throws {
        guard !paths.isEmpty else { throw StringError("No input paths were supplied.") }
        try FileManager.default.createDirectory(at: outputPath.deletingLastPathComponent(), withIntermediateDirectories: true)

        guard let writer = archive_write_new() else { throw StringError("libarchive could not create an archive writer.") }
        var writerOpened = false
        defer {
            if writerOpened { _ = archive_write_close(writer) }
            _ = archive_write_free(writer)
        }

        let formatStatus: Int32
        func requireFilter(_ status: Int32) throws {
            guard status >= ARCHIVE_OK else { throw Self.archiveError(writer, operation: "enable compression filter") }
        }
        if format.isStandaloneStream {
            guard paths.count == 1 else { throw StringError("Single-stream compression accepts exactly one input file.") }
            var info = stat()
            guard lstat(paths[0].path, &info) == 0,
                  (info.st_mode & mode_t(S_IFMT)) == mode_t(S_IFREG) else {
                throw StringError("Single-stream compression requires one regular file.")
            }
            switch format {
            case .gzip: try requireFilter(archive_write_add_filter_gzip(writer))
            case .bzip2: try requireFilter(archive_write_add_filter_bzip2(writer))
            case .xz: try requireFilter(archive_write_add_filter_xz(writer))
            case .zstd: try requireFilter(archive_write_add_filter_zstd(writer))
            case .lz4: try requireFilter(archive_write_add_filter_lz4(writer))
            default: break
            }
            formatStatus = archive_write_set_format_raw(writer)
        } else {
            switch format {
            case .zip:
                formatStatus = archive_write_set_format_zip(writer)
            case .tar:
                formatStatus = archive_write_set_format_pax_restricted(writer)
            case .tarGzip:
                try requireFilter(archive_write_add_filter_gzip(writer))
                formatStatus = archive_write_set_format_pax_restricted(writer)
            case .tarBzip2:
                try requireFilter(archive_write_add_filter_bzip2(writer))
                formatStatus = archive_write_set_format_pax_restricted(writer)
            case .tarXz:
                try requireFilter(archive_write_add_filter_xz(writer))
                formatStatus = archive_write_set_format_pax_restricted(writer)
            case .tarZstd:
                try requireFilter(archive_write_add_filter_zstd(writer))
                formatStatus = archive_write_set_format_pax_restricted(writer)
            case .tarLz4:
                try requireFilter(archive_write_add_filter_lz4(writer))
                formatStatus = archive_write_set_format_pax_restricted(writer)
            case .sevenZip:
                formatStatus = archive_write_set_format_7zip(writer)
            case .cpio:
                formatStatus = archive_write_set_format_cpio_newc(writer)
            case .ar:
                formatStatus = archive_write_set_format_ar_bsd(writer)
            case .iso9660:
                formatStatus = archive_write_set_format_iso9660(writer)
            case .mtree:
                formatStatus = archive_write_set_format_mtree(writer)
            case .warc:
                formatStatus = archive_write_set_format_warc(writer)
            case .xar:
                formatStatus = archive_write_set_format_xar(writer)
            case .gzip, .bzip2, .xz, .zstd, .lz4:
                throw StringError("Unsupported standalone compression mode.")
            }
        }
        guard formatStatus >= ARCHIVE_OK else { throw Self.archiveError(writer, operation: "set output format") }
        guard archive_write_open_filename(writer, outputPath.path) == ARCHIVE_OK else {
            throw Self.archiveError(writer, operation: "open output archive")
        }
        writerOpened = true

        var members = Set<String>()
        for input in paths {
            let source = URL(fileURLWithPath: input.path).standardizedFileURL
            guard source.path != outputPath.standardizedFileURL.path else {
                throw StringError("The output archive cannot also be an input file.")
            }
            try Self.append(source, memberPath: source.lastPathComponent, writer: writer, members: &members)
        }

        guard archive_write_close(writer) == ARCHIVE_OK else {
            writerOpened = false
            throw Self.archiveError(writer, operation: "finish output archive")
        }
        writerOpened = false
    }

    func listArchive(path: URL) throws -> [String] {
        guard let reader = archive_read_new() else { throw StringError("libarchive could not create an archive reader.") }
        defer {
            _ = archive_read_close(reader)
            _ = archive_read_free(reader)
        }
        guard archive_read_support_format_all(reader) >= ARCHIVE_OK,
              archive_read_support_filter_all(reader) >= ARCHIVE_OK else {
            throw Self.archiveError(reader, operation: "enable archive readers")
        }
        let rawCompressedInput = Self.isStandaloneCompressedStream(path)
        if rawCompressedInput && archive_read_support_format_raw(reader) < ARCHIVE_OK {
            throw Self.archiveError(reader, operation: "enable single-stream reader")
        }
        guard archive_read_open_filename(reader, path.path, 64 * 1024) == ARCHIVE_OK else {
            throw Self.archiveError(reader, operation: "open archive")
        }
        var entries: [String] = []
        while true {
            var entry: OpaquePointer?
            let status = archive_read_next_header(reader, &entry)
            if status == ARCHIVE_EOF { break }
            guard status == ARCHIVE_OK, let entry else { throw Self.archiveError(reader, operation: "read archive index") }
            guard let pathname = archive_entry_pathname(entry) else { throw StringError("Archive entry has no path.") }
            let name: String
            if rawCompressedInput && entries.isEmpty {
                name = path.deletingPathExtension().lastPathComponent
            } else {
                name = try Self.safeRelativePath(String(cString: pathname))
            }
            let fileType = archive_entry_filetype(entry)
            let displayName = fileType == mode_t(S_IFDIR) ? name + "/" : name
            entries.append(displayName)
            _ = archive_read_data_skip(reader)
        }
        return entries
    }

    func extractEntry(path: URL, entry requestedEntry: String, to destination: URL) throws {
        let target = try Self.safeRelativePath(requestedEntry)
        guard let reader = archive_read_new() else { throw StringError("libarchive could not create an archive reader.") }
        defer {
            _ = archive_read_close(reader)
            _ = archive_read_free(reader)
        }
        guard archive_read_support_format_all(reader) >= ARCHIVE_OK,
              archive_read_support_filter_all(reader) >= ARCHIVE_OK else {
            throw Self.archiveError(reader, operation: "enable archive readers")
        }
        let rawCompressedInput = Self.isStandaloneCompressedStream(path)
        if rawCompressedInput && archive_read_support_format_raw(reader) < ARCHIVE_OK {
            throw Self.archiveError(reader, operation: "enable single-stream reader")
        }
        guard archive_read_open_filename(reader, path.path, 64 * 1024) == ARCHIVE_OK else {
            throw Self.archiveError(reader, operation: "open archive")
        }
        var sawRawEntry = false
        while true {
            var item: OpaquePointer?
            let status = archive_read_next_header(reader, &item)
            if status == ARCHIVE_EOF { break }
            guard status == ARCHIVE_OK, let item else { throw Self.archiveError(reader, operation: "scan archive entries") }
            guard let pathname = archive_entry_pathname(item) else { throw StringError("Archive entry has no path.") }
            let candidate: String
            if rawCompressedInput && !sawRawEntry {
                candidate = path.deletingPathExtension().lastPathComponent
                sawRawEntry = true
            } else {
                do { candidate = try Self.safeRelativePath(String(cString: pathname)) }
                catch { _ = archive_read_data_skip(reader); continue }
            }
            guard candidate == target else { _ = archive_read_data_skip(reader); continue }
            guard archive_entry_filetype(item) == mode_t(S_IFREG) else {
                throw StringError("Only regular files can be opened directly from an archive.")
            }
            try FileManager.default.createDirectory(at: destination.deletingLastPathComponent(), withIntermediateDirectories: true)
            let fd = open(destination.path, O_WRONLY | O_CREAT | O_EXCL | O_CLOEXEC | O_NOFOLLOW, mode_t(0o600))
            guard fd >= 0 else { throw StringError("Unable to create extracted file: \(String(cString: strerror(errno)))") }
            defer { _ = close(fd) }
            var buffer = [UInt8](repeating: 0, count: 128 * 1024)
            while true {
                let rawCount = buffer.withUnsafeMutableBytes { raw in
                    archive_read_data(reader, raw.baseAddress, raw.count)
                }
                if rawCount == 0 { break }
                guard rawCount > 0 else { throw Self.archiveError(reader, operation: "read archived file data") }
                let count = Int(rawCount)
                let chunk = Data(buffer.prefix(count))
                try chunk.withUnsafeBytes { raw in
                    guard let base = raw.baseAddress else { return }
                    var offset = 0
                    while offset < raw.count {
                        let written = Darwin.write(fd, base.advanced(by: offset), raw.count - offset)
                        if written > 0 { offset += written }
                        else if written < 0 && errno == EINTR { continue }
                        else { throw StringError("Unable to write extracted file: \(String(cString: strerror(errno)))") }
                    }
                }
            }
            _ = fchmod(fd, mode_t(0o600))
            return
        }
        throw StringError("The requested archive entry was not found: \(requestedEntry)")
    }

    func extract(path: URL, to destination: URL) throws {
        try FileManager.default.createDirectory(at: destination, withIntermediateDirectories: true)
        if Self.isStandaloneCompressedStream(path) {
            let entryName = path.deletingPathExtension().lastPathComponent
            guard !entryName.isEmpty else { throw StringError("Unable to determine the extracted filename.") }
            try extractEntry(path: path, entry: entryName, to: destination.appendingPathComponent(entryName))
            return
        }
        let destinationRoot = destination.standardizedFileURL.path
        guard let reader = archive_read_new() else { throw StringError("libarchive could not create an archive reader.") }
        defer {
            _ = archive_read_close(reader)
            _ = archive_read_free(reader)
        }
        guard archive_read_support_format_all(reader) >= ARCHIVE_OK,
              archive_read_support_filter_all(reader) >= ARCHIVE_OK else {
            throw Self.archiveError(reader, operation: "enable archive readers")
        }
        guard archive_read_open_filename(reader, path.path, 64 * 1024) == ARCHIVE_OK else {
            throw Self.archiveError(reader, operation: "open input archive")
        }

        guard let disk = archive_write_disk_new() else { throw StringError("libarchive could not create an extraction writer.") }
        defer {
            _ = archive_write_close(disk)
            _ = archive_write_free(disk)
        }
        let extractionOptions = Int32(
            ARCHIVE_EXTRACT_TIME |
            ARCHIVE_EXTRACT_PERM |
            ARCHIVE_EXTRACT_ACL |
            ARCHIVE_EXTRACT_FFLAGS |
            ARCHIVE_EXTRACT_XATTR |
            ARCHIVE_EXTRACT_SECURE_SYMLINKS |
            ARCHIVE_EXTRACT_SECURE_NODOTDOT |
            ARCHIVE_EXTRACT_UNLINK
        )
        guard archive_write_disk_set_options(disk, extractionOptions) == ARCHIVE_OK else {
            throw Self.archiveError(disk, operation: "configure extraction")
        }

        while true {
            var entry: OpaquePointer?
            let status = archive_read_next_header(reader, &entry)
            if status == ARCHIVE_EOF { break }
            guard status == ARCHIVE_OK, let entry else { throw Self.archiveError(reader, operation: "read archive entry") }
            guard let sourcePath = archive_entry_pathname(entry) else { throw StringError("Archive entry has no path.") }
            let relativePath = try Self.safeRelativePath(String(cString: sourcePath))
            let targetURL = URL(fileURLWithPath: relativePath, relativeTo: destination.standardizedFileURL).standardizedFileURL
            let targetPath = targetURL.path
            guard targetPath == destinationRoot || targetPath.hasPrefix(destinationRoot + "/") else {
                throw StringError("Archive entry escapes the extraction directory.")
            }
            try Self.validateLinks(entry, relativePath: relativePath, destinationRoot: destinationRoot)
            targetPath.withCString { archive_entry_set_pathname(entry, $0) }
            if let hardLink = archive_entry_hardlink(entry) {
                let hardRelative = try Self.safeRelativePath(String(cString: hardLink))
                let hardURL = URL(fileURLWithPath: hardRelative, relativeTo: destination.standardizedFileURL).standardizedFileURL
                guard hardURL.path.hasPrefix(destinationRoot + "/") else { throw StringError("Archive hard link escapes the extraction directory.") }
                hardURL.path.withCString { archive_entry_set_hardlink(entry, $0) }
            }
            guard archive_write_header(disk, entry) >= ARCHIVE_OK else {
                throw Self.archiveError(disk, operation: "create extracted entry")
            }
            while true {
                var block: UnsafeRawPointer?
                var blockSize = 0
                var offset: Int64 = 0
                let readStatus = archive_read_data_block(reader, &block, &blockSize, &offset)
                if readStatus == ARCHIVE_EOF { break }
                guard readStatus == ARCHIVE_OK else { throw Self.archiveError(reader, operation: "read entry data") }
                guard let block else { throw StringError("libarchive returned an empty data block.") }
                let writeStatus = archive_write_data_block(disk, block, blockSize, offset)
                guard writeStatus == ARCHIVE_OK else { throw Self.archiveError(disk, operation: "write extracted data") }
            }
            guard archive_write_finish_entry(disk) >= ARCHIVE_OK else {
                throw Self.archiveError(disk, operation: "finish extracted entry")
            }
        }
    }

    private static func append(_ url: URL, memberPath: String, writer: OpaquePointer, members: inout Set<String>) throws {
        let name = try safeRelativePath(memberPath)
        guard members.insert(name).inserted else { throw StringError("Two input paths produce the same archive entry: \(name)") }
        var info = stat()
        guard lstat(url.path, &info) == 0 else { throw StringError("Unable to inspect \(url.path): \(String(cString: strerror(errno)))") }
        let fileType = info.st_mode & mode_t(S_IFMT)
        guard fileType == mode_t(S_IFREG) || fileType == mode_t(S_IFDIR) || fileType == mode_t(S_IFLNK) else {
            throw StringError("Unsupported file type in archive input: \(url.path)")
        }
        guard let entry = archive_entry_new() else { throw StringError("libarchive could not create an archive entry.") }
        defer { archive_entry_free(entry) }
        name.withCString { archive_entry_set_pathname(entry, $0) }
        archive_entry_set_filetype(entry, UInt32(fileType))
        archive_entry_set_perm(entry, info.st_mode & mode_t(0o7777))
        archive_entry_set_uid(entry, Int64(info.st_uid))
        archive_entry_set_gid(entry, Int64(info.st_gid))
        archive_entry_set_mtime(entry, time_t(info.st_mtimespec.tv_sec), Int(info.st_mtimespec.tv_nsec))
        archive_entry_set_size(entry, fileType == mode_t(S_IFREG) ? Int64(info.st_size) : 0)

        if fileType == mode_t(S_IFLNK) {
            let linkTarget = try readLink(url.path)
            linkTarget.withCString { archive_entry_set_symlink(entry, $0) }
        }

        guard archive_write_header(writer, entry) >= ARCHIVE_OK else {
            throw archiveError(writer, operation: "write archive entry \(name)")
        }

        if fileType == mode_t(S_IFREG) {
            let fd = open(url.path, O_RDONLY | O_CLOEXEC | O_NOFOLLOW)
            guard fd >= 0 else { throw StringError("Unable to open \(url.path): \(String(cString: strerror(errno)))") }
            defer { _ = close(fd) }
            var openedInfo = stat()
            guard fstat(fd, &openedInfo) == 0,
                  (openedInfo.st_mode & mode_t(S_IFMT)) == mode_t(S_IFREG) else {
                throw StringError("Archive input changed during compression: \(url.path)")
            }
            var buffer = [UInt8](repeating: 0, count: 128 * 1024)
            while true {
                let amount = read(fd, &buffer, buffer.count)
                if amount == 0 { break }
                if amount < 0 {
                    if errno == EINTR { continue }
                    throw StringError("Unable to read \(url.path): \(String(cString: strerror(errno)))")
                }
                var offset = 0
                while offset < amount {
                    let written = buffer.withUnsafeBytes { raw in
                        archive_write_data(writer, raw.baseAddress!.advanced(by: offset), amount - offset)
                    }
                    guard written > 0 else { throw archiveError(writer, operation: "write data for \(name)") }
                    offset += Int(written)
                }
            }
        } else if fileType == mode_t(S_IFDIR) {
            let childNames = try FileManager.default.contentsOfDirectory(atPath: url.path).sorted()
            for childName in childNames {
                try append(url.appendingPathComponent(childName), memberPath: name + "/" + childName, writer: writer, members: &members)
            }
        }
        guard archive_write_finish_entry(writer) >= ARCHIVE_OK else {
            throw archiveError(writer, operation: "finish archive entry \(name)")
        }
    }

    private static func safeRelativePath(_ path: String) throws -> String {
        guard !path.isEmpty, !path.hasPrefix("/"), !path.contains("\0") else {
            throw StringError("Archive paths must be non-empty relative paths.")
        }
        let components = path.split(separator: "/", omittingEmptySubsequences: true)
        guard !components.isEmpty, !components.contains("..") else {
            throw StringError("Archive path contains a parent-directory traversal.")
        }
        let cleaned = components.filter { $0 != "." }.joined(separator: "/")
        guard !cleaned.isEmpty else { throw StringError("Archive path resolves to an empty path.") }
        return cleaned
    }

    private static func validateLinks(_ entry: OpaquePointer, relativePath: String, destinationRoot: String) throws {
        let parentComponents = URL(fileURLWithPath: relativePath).deletingLastPathComponent().path
            .split(separator: "/", omittingEmptySubsequences: true)
            .map(String.init)
        if let link = archive_entry_symlink(entry) {
            let target = String(cString: link)
            guard !target.hasPrefix("/") else { throw StringError("Absolute symbolic links are not allowed in archive extraction.") }
            var components = parentComponents
            for component in target.split(separator: "/", omittingEmptySubsequences: true) {
                if component == "." { continue }
                if component == ".." {
                    guard !components.isEmpty else { throw StringError("Symbolic link target escapes the extraction directory.") }
                    components.removeLast()
                } else {
                    components.append(String(component))
                }
            }
            let resolved = components.joined(separator: "/")
            let targetURL = URL(fileURLWithPath: resolved, relativeTo: URL(fileURLWithPath: destinationRoot, isDirectory: true)).standardizedFileURL
            guard targetURL.path == destinationRoot || targetURL.path.hasPrefix(destinationRoot + "/") else {
                throw StringError("Symbolic link target escapes the extraction directory.")
            }
        }
    }

    private static func readLink(_ path: String) throws -> String {
        var buffer = [CChar](repeating: 0, count: 4096)
        let amount = path.withCString { pointer in
            readlink(pointer, &buffer, buffer.count)
        }
        guard amount >= 0, amount < buffer.count else { throw StringError("Unable to read symbolic link target: \(path)") }
        return String(decoding: buffer.prefix(amount).map { UInt8(bitPattern: $0) }, as: UTF8.self)
    }

    private static func isStandaloneCompressedStream(_ path: URL) -> Bool {
        let lowerPath = path.path.lowercased()
        let archiveSuffixes = [".tar.gz", ".tgz", ".tar.bz2", ".tbz", ".tbz2", ".tar.xz", ".txz", ".tar.lzma", ".tar.z", ".taz", ".tar.zst", ".tzst", ".tar.lz4", ".tlz4"]
        if archiveSuffixes.contains(where: lowerPath.hasSuffix) { return false }
        return ["gz", "z", "bz2", "bz", "xz", "lzma", "zst", "zstd", "lz4"].contains(path.pathExtension.lowercased())
    }

    private static func archiveError(_ archive: OpaquePointer, operation: String) -> StringError {
        let message = archive_error_string(archive).map { String(cString: $0) } ?? "unknown libarchive error"
        return StringError("libarchive failed to \(operation): \(message)")
    }
}

extension Compression.FormatType: ExpressibleByArgument {
    public init?(argument: String) {
        guard let value = Self(rawValue: argument.lowercased()) else { return nil }
        self = value
    }
}
private enum HelperFileOperations {
    struct PlannedItem {
        let source: URL
        let destination: URL
    }

    struct FileIdentity: Equatable {
        let device: UInt64
        let inode: UInt64
        let type: UInt32
    }

    static func identity(of url: URL) throws -> FileIdentity? {
        var info = stat()
        guard lstat(url.path, &info) == 0 else {
            if errno == ENOENT { return nil }
            throw StringError("Unable to inspect \(url.path): \(String(cString: strerror(errno)))")
        }
        return FileIdentity(
            device: UInt64(info.st_dev),
            inode: UInt64(info.st_ino),
            type: UInt32(info.st_mode & mode_t(S_IFMT))
        )
    }

    static func uniqueTemporaryURL(in directory: URL, purpose: String) throws -> URL {
        try requireDirectory(directory)
        for _ in 0..<8 {
            let name = ".santander-\(purpose)-\(UUID().uuidString).tmp"
            let candidate = directory.appendingPathComponent(name, isDirectory: false)
            if try !fileExistsWithoutFollowingLinks(candidate) { return candidate }
        }
        throw StringError("Unable to allocate a unique temporary path in \(directory.path).")
    }

    static func fileExistsWithoutFollowingLinks(_ url: URL) throws -> Bool {
        var info = stat()
        if lstat(url.path, &info) == 0 { return true }
        if errno == ENOENT { return false }
        throw StringError("Unable to inspect \(url.path): \(String(cString: strerror(errno)))")
    }

    static func requireDirectory(_ url: URL) throws {
        var info = stat()
        guard lstat(url.path, &info) == 0 else {
            throw StringError("Destination directory is unavailable: \(url.path): \(String(cString: strerror(errno)))")
        }
        guard (info.st_mode & mode_t(S_IFMT)) == mode_t(S_IFDIR) else {
            throw StringError("Destination must be a real directory: \(url.path)")
        }
    }

    static func isDescendant(_ candidate: URL, of parent: URL) -> Bool {
        let parentPath = parent.standardizedFileURL.path
        let candidatePath = candidate.standardizedFileURL.path
        return candidatePath == parentPath || candidatePath.hasPrefix(parentPath == "/" ? "/" : parentPath + "/")
    }

    static func plan(_ paths: [URL], destination: URL) throws -> [PlannedItem] {
        guard !paths.isEmpty else { throw StringError("No source paths were supplied.") }
        try requireDirectory(destination)

        var seenSources = Set<String>()
        var seenNames = Set<String>()
        var result: [PlannedItem] = []
        result.reserveCapacity(paths.count)

        for source in paths {
            let normalizedSource = source.standardizedFileURL
            guard !normalizedSource.path.isEmpty, normalizedSource.path != "/dev/null" else {
                throw StringError("Invalid source path: \(source.path)")
            }
            let sourceKey = normalizedSource.path
            guard seenSources.insert(sourceKey).inserted else {
                throw StringError("Duplicate source path: \(source.path)")
            }
            guard try fileExistsWithoutFollowingLinks(normalizedSource) else {
                throw StringError("Source does not exist: \(source.path)")
            }

            let name = normalizedSource.lastPathComponent
            guard !name.isEmpty, name != ".", name != ".." else {
                throw StringError("Source has an invalid final path component: \(source.path)")
            }
            guard seenNames.insert(name).inserted else {
                throw StringError("Two source items have the same name and cannot be placed in one directory: \(name)")
            }

            let target = destination.standardizedFileURL.appendingPathComponent(name, isDirectory: false)
            guard target.path != sourceKey else {
                throw StringError("Source and destination are the same item: \(source.path)")
            }
            guard !(try fileExistsWithoutFollowingLinks(target)) else {
                throw StringError("Destination already exists: \(target.path)")
            }

            var sourceInfo = stat()
            guard lstat(sourceKey, &sourceInfo) == 0 else {
                throw StringError("Unable to inspect source \(source.path): \(String(cString: strerror(errno)))")
            }
            if (sourceInfo.st_mode & mode_t(S_IFMT)) == mode_t(S_IFDIR), isDescendant(destination, of: normalizedSource) {
                throw StringError("A directory cannot be copied or moved into itself: \(source.path)")
            }
            result.append(PlannedItem(source: normalizedSource, destination: target))
        }
        return result
    }

    static func executeBatch(
        _ plan: [PlannedItem],
        operation: String,
        perform: (PlannedItem) throws -> Void,
        rollback: (PlannedItem) throws -> Void
    ) throws {
        var completed: [(item: PlannedItem, identity: FileIdentity)] = []
        do {
            for item in plan {
                try perform(item)
                guard let identity = try identity(of: item.destination) else {
                    throw StringError("\(operation) did not create the expected destination: \(item.destination.path)")
                }
                completed.append((item, identity))
            }
        } catch {
            let originalError = error.localizedDescription
            var rollbackErrors: [String] = []
            for completedItem in completed.reversed() {
                do {
                    let currentIdentity = try identity(of: completedItem.item.destination)
                    guard currentIdentity == completedItem.identity else {
                        throw StringError("Destination changed after \(operation); it was left untouched.")
                    }
                    try rollback(completedItem.item)
                } catch {
                    rollbackErrors.append("\(completedItem.item.destination.path): \(error.localizedDescription)")
                }
            }
            if rollbackErrors.isEmpty {
                throw StringError("\(operation) failed; completed items were rolled back. \(originalError)")
            }
            throw StringError("\(operation) failed: \(originalError). Rollback was incomplete: \(rollbackErrors.joined(separator: "; "))")
        }
    }
}

struct Delete: ParsableCommand {
    @Argument var paths: [URL]

    func run() throws {
        guard !paths.isEmpty else { throw StringError("No items were selected for deletion.") }
        var seen = Set<String>()
        let normalized = paths.map { $0.standardizedFileURL }
        for path in normalized {
            let key = path.path
            guard key != "/" else { throw StringError("Refusing to delete the filesystem root.") }
            guard seen.insert(key).inserted else { throw StringError("Duplicate deletion target: \(key)") }
            guard try HelperFileOperations.fileExistsWithoutFollowingLinks(path) else {
                throw StringError("Item does not exist: \(path.path)")
            }
        }
        for (index, path) in normalized.enumerated() {
            for other in normalized.dropFirst(index + 1) {
                if HelperFileOperations.isDescendant(path, of: other) || HelperFileOperations.isDescendant(other, of: path) {
                    throw StringError("Delete selection contains both a directory and one of its descendants: \(path.path), \(other.path)")
                }
            }
        }
        for path in normalized { try FileManager.default.removeItem(at: path) }
    }
}

private enum HelperFileTraversal {
    static func isSymbolicLink(_ url: URL) throws -> Bool {
        var info = stat()
        guard lstat(url.path, &info) == 0 else {
            throw StringError("\(url.path): \(String(cString: strerror(errno)))")
        }
        return (info.st_mode & mode_t(S_IFMT)) == mode_t(S_IFLNK)
    }

    static func paths(root: URL, recursive: Bool) throws -> [URL] {
        var rootInfo = stat()
        guard lstat(root.path, &rootInfo) == 0 else {
            throw StringError("\(root.path): \(String(cString: strerror(errno)))")
        }

        let rootType = rootInfo.st_mode & mode_t(S_IFMT)
        guard recursive, rootType == mode_t(S_IFDIR) else { return [root] }

        var result = [root]
        var pendingDirectories = [root]
        var visited = Set<String>([root.standardizedFileURL.path])

        while let directory = pendingDirectories.popLast() {
            let names: [String]
            do {
                names = try FileManager.default.contentsOfDirectory(atPath: directory.path).sorted()
            } catch {
                throw StringError("Unable to enumerate \(directory.path): \(error.localizedDescription)")
            }

            for name in names {
                let child = directory.appendingPathComponent(name, isDirectory: false)
                var info = stat()
                guard lstat(child.path, &info) == 0 else {
                    if errno == ENOENT { continue } // The entry disappeared during a live traversal.
                    throw StringError("\(child.path): \(String(cString: strerror(errno)))")
                }

                result.append(child)
                let type = info.st_mode & mode_t(S_IFMT)
                guard type == mode_t(S_IFDIR) else { continue } // Never descend through symlinks.
                let key = child.standardizedFileURL.path
                if visited.insert(key).inserted { pendingDirectories.append(child) }
            }
        }
        return result
    }
}

private enum HelperFileFlags {
    static let masks: [String: UInt32] = [
        "UF_NODUMP": 0x00000001,
        "UF_IMMUTABLE": 0x00000002,
        "UF_APPEND": 0x00000004,
        "UF_OPAQUE": 0x00000008,
        "UF_COMPRESSED": 0x00000020,
        "UF_TRACKED": 0x00000040,
        "UF_DATAVAULT": 0x00000080,
        "UF_HIDDEN": 0x00008000,
        "SF_ARCHIVED": 0x00010000,
        "SF_IMMUTABLE": 0x00020000,
        "SF_APPEND": 0x00040000,
        "SF_RESTRICTED": 0x00080000,
        "SF_NOUNLINK": 0x00100000
    ]

    static func update(path: URL, flagName: String, enabled: Bool) throws {
        guard let mask = masks[flagName] else {
            throw StringError("Unsupported file flag: \(flagName)")
        }
        guard try !HelperFileTraversal.isSymbolicLink(path) else { return }
        var info = stat()
        guard lstat(path.path, &info) == 0 else {
            throw StringError("\(path.path): \(String(cString: strerror(errno)))")
        }
        let current = UInt32(info.st_flags)
        let next = enabled ? (current | mask) : (current & ~mask)
        guard chflags(path.path, next) == 0 else {
            throw StringError("\(path.path): \(String(cString: strerror(errno)))")
        }
    }
}

private enum HelperExtendedAttributes {
    static func names(at path: URL) throws -> [String] {
        let size = path.path.withCString { listxattr($0, nil, 0, XATTR_NOFOLLOW) }
        guard size >= 0 else {
            throw StringError("Unable to list extended attributes: \(String(cString: strerror(errno)))")
        }
        guard size > 0 else { return [] }
        var buffer = [CChar](repeating: 0, count: size)
        let actual = path.path.withCString { pointer in
            buffer.withUnsafeMutableBufferPointer { listxattr(pointer, $0.baseAddress, $0.count, XATTR_NOFOLLOW) }
        }
        guard actual >= 0 else {
            throw StringError("Unable to list extended attributes: \(String(cString: strerror(errno)))")
        }
        let bytes = Data(buffer.prefix(actual).map { UInt8(bitPattern: $0) })
        return bytes.split(separator: 0).compactMap { String(data: Data($0), encoding: .utf8) }
    }

    static func data(at path: URL, name: String) throws -> Data {
        let size = path.path.withCString { pathPointer in
            name.withCString { namePointer in getxattr(pathPointer, namePointer, nil, 0, 0, XATTR_NOFOLLOW) }
        }
        guard size >= 0 else {
            throw StringError("Unable to read extended attribute \(name): \(String(cString: strerror(errno)))")
        }
        if size == 0 { return Data() }
        var data = Data(count: size)
        let actual = data.withUnsafeMutableBytes { buffer in
            path.path.withCString { pathPointer in
                name.withCString { namePointer in
                    getxattr(pathPointer, namePointer, buffer.baseAddress, size, 0, XATTR_NOFOLLOW)
                }
            }
        }
        guard actual >= 0 else {
            throw StringError("Unable to read extended attribute \(name): \(String(cString: strerror(errno)))")
        }
        if actual < data.count { data = data.prefix(actual) }
        return data
    }

    static func set(_ data: Data, at path: URL, name: String) throws {
        let result = data.withUnsafeBytes { buffer in
            path.path.withCString { pathPointer in
                name.withCString { namePointer in
                    setxattr(pathPointer, namePointer, buffer.baseAddress, data.count, 0, XATTR_NOFOLLOW)
                }
            }
        }
        guard result == 0 else {
            throw StringError("Unable to write extended attribute \(name): \(String(cString: strerror(errno)))")
        }
    }

    static func remove(at path: URL, name: String) throws {
        let result = path.path.withCString { pathPointer in
            name.withCString { namePointer in removexattr(pathPointer, namePointer, XATTR_NOFOLLOW) }
        }
        guard result == 0 else {
            throw StringError("Unable to remove extended attribute \(name): \(String(cString: strerror(errno)))")
        }
    }
}

struct Create: ParsableCommand {
    @Option var directories: [URL] = []
    @Option var files: [URL] = []

    func run() throws {
        for dir in directories {
            try FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
        }
        for file in files {
            let descriptor = open(file.path, O_WRONLY | O_CREAT | O_CLOEXEC, 0o644)
            guard descriptor >= 0 else {
                throw StringError("Failed to create \(file.path): \(String(cString: strerror(errno)))")
            }
            close(descriptor)
        }
    }
}

struct Move: ParsableCommand {
    @Argument var paths: [URL]
    @Option var destination: URL

    func run() throws {
        let plan = try HelperFileOperations.plan(paths, destination: destination)
        try HelperFileOperations.executeBatch(plan, operation: "Move") { item in
            let staging = try HelperFileOperations.uniqueTemporaryURL(
                in: item.destination.deletingLastPathComponent(), purpose: "move"
            )
            do {
                try FileManager.default.moveItem(at: item.source, to: staging)
            } catch let stagingError {
                if (try? HelperFileOperations.fileExistsWithoutFollowingLinks(staging)) == true {
                    if (try? HelperFileOperations.fileExistsWithoutFollowingLinks(item.source)) == true {
                        try? FileManager.default.removeItem(at: staging)
                    } else {
                        try? FileManager.default.moveItem(at: staging, to: item.source)
                    }
                }
                throw stagingError
            }
            do {
                try FileManager.default.moveItem(at: staging, to: item.destination)
            } catch let finalMoveError {
                do {
                    guard try !HelperFileOperations.fileExistsWithoutFollowingLinks(item.source) else {
                        throw StringError("Source path was recreated; staged data remains at \(staging.path).")
                    }
                    try FileManager.default.moveItem(at: staging, to: item.source)
                } catch let restoreError {
                    throw StringError("Move failed: \(finalMoveError.localizedDescription). Source restore failed: \(restoreError.localizedDescription). Staged data: \(staging.path)")
                }
                throw finalMoveError
            }
        } rollback: { item in
            guard try !HelperFileOperations.fileExistsWithoutFollowingLinks(item.source) else {
                throw StringError("Cannot roll back move because the source path was recreated.")
            }
            try FileManager.default.moveItem(at: item.destination, to: item.source)
        }
    }
}

struct Copy: ParsableCommand {
    @Argument var paths: [URL]
    @Option var destination: URL

    func run() throws {
        let plan = try HelperFileOperations.plan(paths, destination: destination)
        try HelperFileOperations.executeBatch(plan, operation: "Copy") { item in
            let staging = try HelperFileOperations.uniqueTemporaryURL(
                in: item.destination.deletingLastPathComponent(), purpose: "copy"
            )
            do {
                try FileManager.default.copyItem(at: item.source, to: staging)
                try FileManager.default.moveItem(at: staging, to: item.destination)
            } catch let copyError {
                if (try? HelperFileOperations.fileExistsWithoutFollowingLinks(staging)) == true {
                    try? FileManager.default.removeItem(at: staging)
                }
                throw copyError
            }
        } rollback: { item in
            try FileManager.default.removeItem(at: item.destination)
        }
    }
}

struct Rename: ParsableCommand {
    @Argument var path: URL
    @Argument var destination: URL

    func run() throws {
        let source = path.standardizedFileURL
        let target = destination.standardizedFileURL
        guard source.path != target.path else { return }
        guard try HelperFileOperations.fileExistsWithoutFollowingLinks(source) else {
            throw StringError("Source does not exist: \(source.path)")
        }
        try HelperFileOperations.requireDirectory(target.deletingLastPathComponent())
        guard try !HelperFileOperations.fileExistsWithoutFollowingLinks(target) else {
            throw StringError("Destination already exists: \(target.path)")
        }
        var info = stat()
        guard lstat(source.path, &info) == 0 else { throw StringError("Unable to inspect source: \(source.path)") }
        if (info.st_mode & mode_t(S_IFMT)) == mode_t(S_IFDIR), HelperFileOperations.isDescendant(target, of: source) {
            throw StringError("A directory cannot be renamed into itself.")
        }
        try FileManager.default.moveItem(at: source, to: target)
    }
}

struct Link: ParsableCommand {
    @Argument var paths: [URL]
    @Option var destination: URL

    func run() throws {
        let plan = try HelperFileOperations.plan(paths, destination: destination)
        try HelperFileOperations.executeBatch(plan, operation: "Create symbolic links") { item in
            let staging = try HelperFileOperations.uniqueTemporaryURL(
                in: item.destination.deletingLastPathComponent(), purpose: "link"
            )
            do {
                try FileManager.default.createSymbolicLink(at: staging, withDestinationURL: item.source)
                try FileManager.default.moveItem(at: staging, to: item.destination)
            } catch let linkError {
                if (try? HelperFileOperations.fileExistsWithoutFollowingLinks(staging)) == true {
                    try? FileManager.default.removeItem(at: staging)
                }
                throw linkError
            }
        } rollback: { item in
            try FileManager.default.removeItem(at: item.destination)
        }
    }
}

struct SetPermissions: ParsableCommand {
    @Argument var path: URL
    @Argument var permissions: Int
    @Flag var recursive = false

    func run() throws {
        guard permissions >= 0 && permissions <= 0o7777 else {
            throw StringError("Permissions must be between 0000 and 7777")
        }
        var targets = try HelperFileTraversal.paths(root: path, recursive: recursive)
        if recursive { targets.reverse() }
        for target in targets {
            guard try !HelperFileTraversal.isSymbolicLink(target) else { continue }
            guard chmod(target.path, mode_t(permissions)) == 0 else {
                throw StringError("Unable to change permissions for \(target.path): \(String(cString: strerror(errno)))")
            }
        }
    }
}

struct SetOwnerOrGroup: ParsableCommand {
    @Argument var path: URL
    @Option(name: .long) var ownerName: String?
    @Option(name: .long) var groupName: String?
    @Option(name: .long) var ownerID: Int32?
    @Option(name: .long) var groupID: Int32?
    @Flag var recursive = false

    func run() throws {
        guard ownerName != nil || groupName != nil || ownerID != nil || groupID != nil else {
            throw StringError("Specify an owner or group")
        }
        guard !(ownerName != nil && ownerID != nil), !(groupName != nil && groupID != nil) else {
            throw StringError("Specify either the owner/group name or its ID, not both")
        }
        if let ownerID, ownerID < 0 {
            throw StringError("Owner ID must be a non-negative integer.")
        }
        if let groupID, groupID < 0 {
            throw StringError("Group ID must be a non-negative integer.")
        }

        var uid = uid_t.max
        var gid = gid_t.max
        if let ownerID { uid = uid_t(UInt32(bitPattern: ownerID)) }
        if let groupID { gid = gid_t(UInt32(bitPattern: groupID)) }
        if let ownerName {
            let entry = ownerName.withCString { getpwnam($0) }
            guard let entry else { throw StringError("Unknown user: \(ownerName)") }
            uid = entry.pointee.pw_uid
        }
        if let groupName {
            let entry = groupName.withCString { getgrnam($0) }
            guard let entry else { throw StringError("Unknown group: \(groupName)") }
            gid = entry.pointee.gr_gid
        }

        var targets = try HelperFileTraversal.paths(root: path, recursive: recursive)
        if recursive { targets.reverse() }
        for target in targets {
            guard lchown(target.path, uid, gid) == 0 else {
                throw StringError("Unable to change owner/group for \(target.path): \(String(cString: strerror(errno)))")
            }
        }
    }
}

struct SetLocked: ParsableCommand {
    @Argument var path: URL
    @Argument var enabled: Int
    @Flag var recursive = false

    func run() throws {
        guard enabled == 0 || enabled == 1 else {
            throw StringError("set-locked requires 0 or 1")
        }
        guard try !HelperFileTraversal.isSymbolicLink(path) else {
            throw StringError("Changing file flags on symbolic links is not supported.")
        }
        var targets = try HelperFileTraversal.paths(root: path, recursive: recursive)
        if recursive && enabled == 1 { targets.reverse() }
        for target in targets {
            try HelperFileFlags.update(path: target, flagName: "UF_IMMUTABLE", enabled: enabled == 1)
        }
    }
}

struct SetFileFlag: ParsableCommand {
    @Argument var path: URL
    @Argument var flag: String
    @Argument var enabled: Int
    @Flag var recursive = false

    func run() throws {
        guard enabled == 0 || enabled == 1 else {
            throw StringError("set-file-flag requires 0 or 1")
        }
        guard try !HelperFileTraversal.isSymbolicLink(path) else {
            throw StringError("Changing file flags on symbolic links is not supported.")
        }
        var targets = try HelperFileTraversal.paths(root: path, recursive: recursive)
        if recursive && enabled == 1 { targets.reverse() }
        for target in targets {
            try HelperFileFlags.update(path: target, flagName: flag, enabled: enabled == 1)
        }
    }
}

struct ListExtendedAttributes: ParsableCommand {
    @Argument var path: URL

    func run() throws {
        let values = try HelperExtendedAttributes.names(at: path)
        if !values.isEmpty {
            FileHandle.standardOutput.write(Data((values.joined(separator: "\n") + "\n").utf8))
        }
    }
}

struct GetExtendedAttribute: ParsableCommand {
    @Argument var path: URL
    @Argument var name: String

    func run() throws {
        let data = try HelperExtendedAttributes.data(at: path, name: name)
        FileHandle.standardOutput.write(Data(data.base64EncodedString().utf8))
    }
}

struct SetExtendedAttribute: ParsableCommand {
    @Argument var path: URL
    @Argument var name: String

    func run() throws {
        let data = FileHandle.standardInput.readDataToEndOfFile()
        try HelperExtendedAttributes.set(data, at: path, name: name)
    }
}

struct RemoveExtendedAttribute: ParsableCommand {
    @Argument var path: URL
    @Argument var name: String

    func run() throws {
        try HelperExtendedAttributes.remove(at: path, name: name)
    }
}

struct ReplaceFile: ParsableCommand {
    @Argument var staged: URL
    @Argument var destination: URL

    func run() throws {
        var sourceInfo = stat()
        guard lstat(staged.path, &sourceInfo) == 0,
              (sourceInfo.st_mode & mode_t(S_IFMT)) == mode_t(S_IFREG) else {
            throw StringError("Replacement source must be a regular file.")
        }

        var targetInfo = stat()
        let targetExists = lstat(destination.path, &targetInfo) == 0
        if !targetExists && errno != ENOENT {
            throw StringError("Unable to inspect replacement destination: \(String(cString: strerror(errno)))")
        }
        if targetExists {
            guard (targetInfo.st_mode & mode_t(S_IFMT)) == mode_t(S_IFREG) else {
                throw StringError("Replacement destination must be a regular file, not a directory or symbolic link.")
            }
            let existingFlags = UInt32(targetInfo.st_flags)
            let blockingMask = HelperFileFlags.masks["UF_IMMUTABLE"]! |
                HelperFileFlags.masks["UF_APPEND"]! |
                HelperFileFlags.masks["SF_IMMUTABLE"]! |
                HelperFileFlags.masks["SF_APPEND"]! |
                HelperFileFlags.masks["SF_RESTRICTED"]! |
                HelperFileFlags.masks["SF_NOUNLINK"]!
            guard (existingFlags & blockingMask) == 0 else {
                throw StringError("Destination has immutable, append-only, restricted, or no-unlink file flags.")
            }

            for name in try HelperExtendedAttributes.names(at: destination) {
                let value = try HelperExtendedAttributes.data(at: destination, name: name)
                try HelperExtendedAttributes.set(value, at: staged, name: name)
            }
            guard chown(staged.path, targetInfo.st_uid, targetInfo.st_gid) == 0 else {
                throw StringError("Unable to preserve file owner/group: \(String(cString: strerror(errno)))")
            }
            guard chmod(staged.path, targetInfo.st_mode & 0o7777) == 0 else {
                throw StringError("Unable to preserve file permissions: \(String(cString: strerror(errno)))")
            }
        }

        guard rename(staged.path, destination.path) == 0 else {
            throw StringError("Atomic file replacement failed: \(String(cString: strerror(errno)))")
        }
        if targetExists {
            let supportedMask = HelperFileFlags.masks.values.reduce(UInt32(0), |)
            let restorableFlags = UInt32(targetInfo.st_flags) & supportedMask
            if restorableFlags != 0, chflags(destination.path, restorableFlags) != 0 {
                throw StringError("File was replaced, but one or more original file flags could not be restored: \(String(cString: strerror(errno)))")
            }
        }
    }
}

struct WriteData: ParsableCommand {
    @Argument var path: URL

    func run() throws {
        let data = FileHandle.standardInput.readDataToEndOfFile()
        try data.write(to: path, options: .atomic)
    }
}

struct WriteString: ParsableCommand {
    @Argument var string: String
    @Option var path: URL

    func run() throws {
        try string.write(to: path, atomically: true, encoding: .utf8)
    }
}

struct SnapshotCreate: ParsableCommand {
    static let configuration = CommandConfiguration(commandName: "snapshot-create")
    func run() throws { try ManagedSnapshotStore.create() }
}

struct SnapshotList: ParsableCommand {
    static let configuration = CommandConfiguration(commandName: "snapshot-list")
    func run() throws { try ManagedSnapshotStore.list() }
}

struct SnapshotRestore: ParsableCommand {
    static let configuration = CommandConfiguration(commandName: "snapshot-restore")
    @Argument var name: String
    func run() throws { try ManagedSnapshotStore.restore(name) }
}

struct SnapshotDelete: ParsableCommand {
    static let configuration = CommandConfiguration(commandName: "snapshot-delete")
    @Argument var name: String
    func run() throws { try ManagedSnapshotStore.delete(name) }
}

struct Compress: ParsableCommand {
    @Option var paths: [URL]
    @Option var destination: URL
    @Option var format: Compression.FormatType = .zip

    func run() throws {
        try Compression.shared.compress(paths: paths, outputPath: destination, format: format)
    }
}

struct Decompress: ParsableCommand {
    @Argument var path: URL
    @Option var destination: URL

    func run() throws {
        try Compression.shared.extract(path: path, to: destination)
    }
}

struct ListArchive: ParsableCommand {
    @Argument var path: URL

    func run() throws {
        let data = try JSONSerialization.data(withJSONObject: Compression.shared.listArchive(path: path), options: [.fragmentsAllowed])
        FileHandle.standardOutput.write(data)
        FileHandle.standardOutput.write(Data([10]))
    }
}

struct ExtractArchiveEntry: ParsableCommand {
    @Argument var path: URL
    @Option var entry: String
    @Option var destination: URL

    func run() throws {
        try Compression.shared.extractEntry(path: path, entry: entry, to: destination)
    }
}

struct ExtractCatalog: ParsableCommand {
    @Argument var path: URL
    @Option var destination: URL

    func run() throws {
        let renditions = try AssetCatalogWrapper.shared.renditions(forCarArchive: path)
        try FileManager.default.createDirectory(at: destination, withIntermediateDirectories: true)

        var failures: [String] = []
        var writtenNames = Set<String>()
        for rendition in renditions {
            guard let data = rendition.itemData else { continue }
            let name = rendition.renditionName
            let isSafeName = !name.isEmpty
                && name != "."
                && name != ".."
                && !name.contains("/")
                && !name.contains("\\")
                && !name.contains("\0")
            guard isSafeName, writtenNames.insert(name).inserted else {
                failures.append("Skipped unsafe or duplicate asset name: \(name)")
                continue
            }
            let destinationURL = destination.appendingPathComponent(name, isDirectory: false)
            do {
                guard try !HelperFileOperations.fileExistsWithoutFollowingLinks(destinationURL) else {
                    throw StringError("Destination already exists")
                }
                try data.write(to: destinationURL, options: .atomic)
            } catch {
                failures.append("\(name): \(error.localizedDescription)")
            }
        }

        if !failures.isEmpty {
            throw StringError(failures.joined(separator: "\n"))
        }
    }
}

struct GetContents: ParsableCommand {
    @Argument var path: URL

    func run() throws {
        let contents = try FileManager.default.contentsOfDirectory(at: path, includingPropertiesForKeys: nil)
        var output = Data()
        for item in contents {
            output.append(contentsOf: item.path.utf8)
            output.append(0)
        }
        FileHandle.standardOutput.write(output)
    }
}

struct Identity: ParsableCommand {
    static let configuration = CommandConfiguration(commandName: "identity")

    func run() throws {
        print("uid=\(getuid()) euid=\(geteuid()) gid=\(getgid()) egid=\(getegid())")
    }
}

struct Mount: ParsableCommand {
    @Argument var source: URL
    @Argument var target: URL
    @Option var filesystemType: String?
    @Flag var readOnly = false

    func run() throws {
        try FileManager.default.createDirectory(at: target, withIntermediateDirectories: true)
        let executable = try Self.executable(named: "mount")
        var arguments = [source.path, target.path]
        if let filesystemType {
            arguments = ["-t", filesystemType] + arguments
        }
        if readOnly {
            arguments.insert("-o", at: 0)
            arguments.insert("ro", at: 1)
        }
        try RootProcess.run(executable: executable, arguments: arguments)
    }

    static func executable(named name: String) throws -> String {
        let candidates = [
            "/var/jb/sbin/\(name)",
            "/var/jb/usr/sbin/\(name)",
            "/sbin/\(name)",
            "/usr/sbin/\(name)"
        ]
        if let path = candidates.first(where: { FileManager.default.isExecutableFile(atPath: $0) }) {
            return path
        }
        throw StringError("\(name) executable was not found")
    }
}

struct Unmount: ParsableCommand {
    @Argument var target: URL
    @Flag var force = false

    func run() throws {
        let executable = try Mount.executable(named: "umount")
        var arguments = [target.path]
        if force {
            arguments.insert("-f", at: 0)
        }
        try RootProcess.run(executable: executable, arguments: arguments)
    }
}

enum RootProcess {
    static func run(executable: String, arguments: [String]) throws {
        let argvStrings = [executable] + arguments
        let argv = argvStrings.map { strdup($0) } + [nil]
        defer {
            for item in argv {
                if let item { free(item) }
            }
        }

        var pipeFD: [Int32] = [0, 0]
        guard pipe(&pipeFD) == 0 else {
            throw StringError("Unable to create process pipe: \(String(cString: strerror(errno)))")
        }
        defer {
            close(pipeFD[0])
            close(pipeFD[1])
        }

        var actions: posix_spawn_file_actions_t?
        guard posix_spawn_file_actions_init(&actions) == 0 else {
            throw StringError("Unable to initialize process actions")
        }
        defer { posix_spawn_file_actions_destroy(&actions) }

        posix_spawn_file_actions_adddup2(&actions, pipeFD[1], STDOUT_FILENO)
        posix_spawn_file_actions_adddup2(&actions, pipeFD[1], STDERR_FILENO)
        posix_spawn_file_actions_addclose(&actions, pipeFD[0])

        var pid: pid_t = 0
        let status = argv.withUnsafeBufferPointer { arguments in
            posix_spawn(&pid, executable, &actions, nil, arguments.baseAddress, nil)
        }
        close(pipeFD[1])
        pipeFD[1] = -1
        guard status == 0 else {
            throw StringError("Unable to start \(executable): \(String(cString: strerror(status)))")
        }

        let output = FileHandle(fileDescriptor: pipeFD[0], closeOnDealloc: false).readDataToEndOfFile()
        var processStatus: Int32 = 0
        guard waitpid(pid, &processStatus, 0) == pid else {
            throw StringError("Unable to wait for \(executable): \(String(cString: strerror(errno)))")
        }

        let message = String(data: output, encoding: .utf8)?.trimmingCharacters(in: .whitespacesAndNewlines)

        let encodedStatus = UInt32(bitPattern: processStatus)
        if encodedStatus & 0x7f == 0 {
            let code = (encodedStatus >> 8) & 0xff
            guard code == 0 else {
                let suffix = message.map { ": \($0)" } ?? ""
                throw StringError("\(executable) exited with status \(code)\(suffix)")
            }
        } else {
            throw StringError("\(executable) terminated unexpectedly")
        }
    }
}

private enum ManagedSnapshotStore {
    static let directoryPath = "/private/var/mobile/Library/Santander/Snapshots"
    static let directoryURL = URL(fileURLWithPath: directoryPath, isDirectory: true)
    private static let immutableMask: UInt32 = 0x00000002 | 0x00020000 | 0x00080000
    private static let ignoredFilesystems: Set<String> = ["devfs", "procfs", "fdesc", "autofs", "volfs", "nullfs", "mtmfs", "nfs", "smbfs", "webdav"]

    private struct MountEntry {
        let path: String
        let filesystem: String
        let readOnly: Bool
    }

    static func list() throws {
        try ensureDirectory()
        let names = try FileManager.default.contentsOfDirectory(atPath: directoryPath)
            .filter { isManagedName($0) }
            .filter { isTrustedArchive(directoryURL.appendingPathComponent($0)) }
            .sorted(by: >)
        if !names.isEmpty {
            FileHandle.standardOutput.write(Data((names.joined(separator: "\n") + "\n").utf8))
        }
    }

    static func create() throws {
        try ensureDirectory()
        let formatter = DateFormatter()
        formatter.locale = Locale(identifier: "en_US_POSIX")
        formatter.timeZone = TimeZone(secondsFromGMT: 0)
        formatter.dateFormat = "yyyyMMdd-HHmmss"
        let timestamp = formatter.string(from: Date())
        let finalURL = directoryURL.appendingPathComponent("\(timestamp).tar.gz")
        guard !FileManager.default.fileExists(atPath: finalURL.path) else {
            throw StringError("A snapshot already exists for this second. Wait a moment and retry.")
        }

        let temporaryURL = directoryURL.appendingPathComponent(".creating-\(UUID().uuidString).tar.gz")
        let listURL = directoryURL.appendingPathComponent(".list-\(UUID().uuidString)")
        let listFD = open(listURL.path, O_WRONLY | O_CREAT | O_EXCL | O_CLOEXEC, mode_t(0o600))
        guard listFD >= 0 else {
            throw StringError("Unable to create snapshot file list: \(String(cString: strerror(errno)))")
        }
        let listHandle = FileHandle(fileDescriptor: listFD, closeOnDealloc: true)
        defer {
            try? listHandle.close()
            _ = unlink(listURL.path)
            _ = unlink(temporaryURL.path)
        }

        let mounts = try mountedFilesystems()
        let roots = selectedRoots(from: mounts)
        guard !roots.isEmpty else {
            throw StringError("No writable filesystem mount could be safely archived.")
        }

        var buffered = Data()
        buffered.reserveCapacity(256 * 1024)
        var archivedPathCount = 0
        let excludedMounts = Set(mounts.filter { $0.readOnly || Self.ignoredFilesystems.contains($0.filesystem) }.map(\.path))
        let skipPrefixes = [directoryPath, "/var/mobile/Library/Santander/Snapshots"]

        func flushBuffer() throws {
            guard !buffered.isEmpty else { return }
            try listHandle.write(contentsOf: buffered)
            buffered.removeAll(keepingCapacity: true)
        }

        for root in roots {
            var pending = [URL(fileURLWithPath: root, isDirectory: true)]
            var visitedDirectories = Set<String>()
            while let current = pending.popLast() {
                let path = current.standardizedFileURL.path
                if path != root && excludedMounts.contains(path) { continue }
                if skipPrefixes.contains(where: { path == $0 || path.hasPrefix($0 + "/") }) { continue }
                if visitedDirectories.contains(path) { continue }

                var info = stat()
                guard lstat(path, &info) == 0 else {
                    if errno == ENOENT || errno == ENOTDIR { continue }
                    continue
                }
                let flags = UInt32(info.st_flags)
                if (flags & immutableMask) != 0 { continue }
                let type = info.st_mode & mode_t(S_IFMT)
                if type == mode_t(S_IFBLK) || type == mode_t(S_IFCHR) || type == mode_t(S_IFIFO) || type == mode_t(S_IFSOCK) { continue }

                
                if path != root {
                    buffered.append(contentsOf: path.utf8)
                    buffered.append(0)
                    archivedPathCount += 1
                    if buffered.count >= 256 * 1024 { try flushBuffer() }
                }

                if type == mode_t(S_IFDIR), type != mode_t(S_IFLNK) {
                    visitedDirectories.insert(path)
                    let children: [String]
                    do {
                        children = try FileManager.default.contentsOfDirectory(atPath: path).sorted(by: >)
                    } catch {
                        continue
                    }
                    for name in children {
                        let child = current.appendingPathComponent(name, isDirectory: false)
                        if excludedMounts.contains(child.standardizedFileURL.path) { continue }
                        pending.append(child)
                    }
                }
            }
        }
        try flushBuffer()
        try listHandle.synchronize()
        try listHandle.close()
        guard archivedPathCount > 0 else {
            throw StringError("The writable filesystem scan did not find any eligible entries.")
        }

        let tar = try findTar()
        let listArgs = ["--null", "-T", listURL.path]
        let basicArgs = ["-c", "-z", "-p", "-P", "-f", temporaryURL.path] + listArgs
        
        do {
            try RootProcess.run(executable: tar, arguments: ["-c", "-z", "-p", "-P", "--xattrs", "--fflags", "-f", temporaryURL.path] + listArgs)
        } catch {
            let message = String(describing: error).lowercased()
            if message.contains("option") || message.contains("usage") || message.contains("illegal") {
                _ = unlink(temporaryURL.path)
                try RootProcess.run(executable: tar, arguments: basicArgs)
            } else {
                throw error
            }
        }

        let archiveFD = open(temporaryURL.path, O_RDONLY | O_CLOEXEC)
        guard archiveFD >= 0 else {
            throw StringError("Snapshot archive was not created.")
        }
        defer { _ = close(archiveFD) }
        guard fchown(archiveFD, 0, 0) == 0, fchmod(archiveFD, mode_t(0o600)) == 0 else {
            throw StringError("Unable to secure the snapshot archive: \(String(cString: strerror(errno)))")
        }
        guard rename(temporaryURL.path, finalURL.path) == 0 else {
            throw StringError("Unable to finalize the snapshot archive: \(String(cString: strerror(errno)))")
        }
        fputs("Saved \(timestamp).tar.gz (\(archivedPathCount) entries)\n", stdout)
    }

    static func restore(_ name: String) throws {
        try ensureDirectory()
        guard isManagedName(name) else { throw StringError("Invalid snapshot name.") }
        let archiveURL = directoryURL.appendingPathComponent(name)
        guard isTrustedArchive(archiveURL) else { throw StringError("Snapshot is missing, not root-owned, or not a regular file.") }
        let tar = try findTar()
        do {
            try RootProcess.run(executable: tar, arguments: ["-x", "-z", "-p", "-P", "--xattrs", "--fflags", "-f", archiveURL.path, "-C", "/"])
        } catch {
            let message = String(describing: error).lowercased()
            if message.contains("option") || message.contains("usage") || message.contains("illegal") {
                try RootProcess.run(executable: tar, arguments: ["-x", "-z", "-p", "-P", "-f", archiveURL.path, "-C", "/"])
            } else {
                throw error
            }
        }
    }

    static func delete(_ name: String) throws {
        try ensureDirectory()
        guard isManagedName(name) else { throw StringError("Invalid snapshot name.") }
        let archiveURL = directoryURL.appendingPathComponent(name)
        guard isTrustedArchive(archiveURL) else { throw StringError("Snapshot is missing, not root-owned, or not a regular file.") }
        guard unlink(archiveURL.path) == 0 else {
            throw StringError("Unable to delete snapshot: \(String(cString: strerror(errno)))")
        }
    }

    private static func ensureDirectory() throws {
        var info = stat()
        if lstat(directoryPath, &info) == 0 {
            guard (info.st_mode & mode_t(S_IFMT)) == mode_t(S_IFDIR),
                  info.st_uid == 0,
                  (UInt32(info.st_flags) & immutableMask) == 0 else {
                throw StringError("Snapshot directory is not a trusted root-owned directory.")
            }
        } else {
            guard errno == ENOENT else { throw StringError("Unable to inspect snapshot directory.") }
            try FileManager.default.createDirectory(at: directoryURL, withIntermediateDirectories: true)
            guard chown(directoryPath, 0, 0) == 0, chmod(directoryPath, mode_t(0o700)) == 0 else {
                throw StringError("Unable to secure snapshot directory: \(String(cString: strerror(errno)))")
            }
        }
        guard chmod(directoryPath, mode_t(0o700)) == 0 else {
            throw StringError("Unable to secure snapshot directory: \(String(cString: strerror(errno)))")
        }
    }

    private static func isManagedName(_ name: String) -> Bool {
        guard name.count == 22, name.hasSuffix(".tar.gz"), !name.contains("/"), !name.contains("..") else { return false }
        let stamp = String(name.prefix(15))
        guard stamp.count == 15, stamp[stamp.index(stamp.startIndex, offsetBy: 8)] == "-" else { return false }
        let digits = stamp.replacingOccurrences(of: "-", with: "")
        return digits.count == 14 && digits.allSatisfy(\.isNumber)
    }

    private static func isTrustedArchive(_ url: URL) -> Bool {
        var info = stat()
        guard lstat(url.path, &info) == 0,
              (info.st_mode & mode_t(S_IFMT)) == mode_t(S_IFREG),
              info.st_uid == 0,
              (UInt32(info.st_flags) & immutableMask) == 0 else { return false }
        return true
    }

    private static func fixedCString<T>(_ value: T) -> String {
        var storage = value
        return withUnsafeBytes(of: &storage) { bytes in
            guard let baseAddress = bytes.baseAddress else { return "" }
            return String(cString: baseAddress.assumingMemoryBound(to: CChar.self))
        }
    }

    private static func mountedFilesystems() throws -> [MountEntry] {
        var buffer: UnsafeMutablePointer<statfs>?
        let count = getmntinfo(&buffer, MNT_NOWAIT)
        guard count > 0, let buffer else {
            throw StringError("Unable to inspect mounted filesystems: \(String(cString: strerror(errno)))")
        }
        var result: [MountEntry] = []
        result.reserveCapacity(Int(count))
        for index in 0..<Int(count) {
            let mount = buffer[index]
            let mountedPath = Self.fixedCString(mount.f_mntonname)
            let filesystem = Self.fixedCString(mount.f_fstypename)
            let path = URL(fileURLWithPath: mountedPath).standardizedFileURL.path
            let readOnly = (UInt32(mount.f_flags) & UInt32(MNT_RDONLY)) != 0
            result.append(MountEntry(path: path, filesystem: filesystem, readOnly: readOnly))
        }
        return result
    }

    private static func selectedRoots(from mounts: [MountEntry]) -> [String] {
        let writable = mounts.filter { !$0.readOnly && !ignoredFilesystems.contains($0.filesystem) }
            .sorted { $0.path.count < $1.path.count }
        if writable.contains(where: { $0.path == "/" }) { return ["/"] }
        var roots: [String] = []
        for mount in writable {
            if roots.contains(where: { mount.path == $0 || mount.path.hasPrefix($0 == "/" ? "/" : $0 + "/") }) { continue }
            roots.append(mount.path)
        }
        return roots
    }

    private static func findTar() throws -> String {
        let candidates = ["/usr/bin/tar", "/bin/tar", "/var/jb/usr/bin/tar", "/var/jb/bin/tar", "/usr/bin/bsdtar", "/var/jb/usr/bin/bsdtar"]
        if let item = candidates.first(where: { FileManager.default.isExecutableFile(atPath: $0) }) { return item }
        throw StringError("No tar/bsdtar executable is available to create snapshots.")
    }
}

private enum SantanderHelperDaemon {
    private static let maxRequestSize = 1_048_576
    private static let maxInputLength: UInt64 = 2_147_483_648
    private static let maxResponseLength: UInt64 = 64 * 1024 * 1024
    private static let permittedCommands: Set<String> = [
        "create", "delete", "move", "copy", "link", "rename", "set-owner-or-group",
        "set-permissions", "set-locked", "set-file-flag", "list-extended-attributes",
        "get-extended-attribute", "set-extended-attribute", "remove-extended-attribute",
        "compress", "decompress", "list-archive", "extract-archive-entry", "extract-catalog", "write-data", "write-string",
        "get-contents", "identity", "mount", "unmount", "replace-file", "snapshot-create", "snapshot-list",
        "snapshot-restore", "snapshot-delete", "session-stop"
    ]
    private static let stopLock = NSLock()
    private static var stopRequested = false
    private static let clientSlots = DispatchSemaphore(value: 4)

    static func run(socketPath: String, parentPID: pid_t) throws {
        guard getuid() == 0, geteuid() == 0, getgid() == 0, getegid() == 0 else {
            throw StringError("SantanderHelper was not launched as root by TrollStore spawnRoot.")
        }
        guard parentPID > 0, getppid() == parentPID, socketPath.hasPrefix("/var/tmp/com.Antoine.Santander."), socketPath.hasSuffix(".sock") else {
            throw StringError("Invalid SantanderHelper session identity.")
        }
        stopLock.lock()
        stopRequested = false
        stopLock.unlock()
        _ = unlink(socketPath)
        let server = socket(AF_UNIX, SOCK_STREAM, 0)
        guard server >= 0 else { throw StringError("Unable to create helper socket: \(String(cString: strerror(errno)))") }
        _ = fcntl(server, F_SETFD, FD_CLOEXEC)
        var noSignal: Int32 = 1
        _ = setsockopt(server, SOL_SOCKET, SO_NOSIGPIPE, &noSignal, socklen_t(MemoryLayout<Int32>.size))
        defer { _ = close(server); _ = unlink(socketPath) }
        var address = try socketAddress(for: socketPath)
        let bindResult = withUnsafePointer(to: &address) { pointer in
            pointer.withMemoryRebound(to: sockaddr.self, capacity: 1) { bind(server, $0, socklen_t(MemoryLayout<sockaddr_un>.size)) }
        }
        guard bindResult == 0 else { throw StringError("Unable to bind helper socket: \(String(cString: strerror(errno)))") }
        guard chown(socketPath, 0, 501) == 0, chmod(socketPath, mode_t(0o660)) == 0, listen(server, 16) == 0 else {
            throw StringError("Unable to publish helper socket: \(String(cString: strerror(errno)))")
        }

        _ = fcntl(server, F_SETFL, O_NONBLOCK)
        while !isStopRequested() {
            if getppid() != parentPID || kill(parentPID, 0) != 0 { break }
            let client = accept(server, nil, nil)
            if client < 0 {
                if errno == EINTR { continue }
                if errno == EAGAIN || errno == EWOULDBLOCK { usleep(150_000); continue }
                throw StringError("Helper socket accept failed: \(String(cString: strerror(errno)))")
            }
            _ = fcntl(client, F_SETFD, FD_CLOEXEC)
            clientSlots.wait()
            DispatchQueue.global(qos: .userInitiated).async {
                defer { clientSlots.signal() }
                handle(client)
            }
        }
    }

    private static func requestStop() {
        stopLock.lock()
        stopRequested = true
        stopLock.unlock()
    }

    private static func isStopRequested() -> Bool {
        stopLock.lock()
        defer { stopLock.unlock() }
        return stopRequested
    }

    private static func socketAddress(for path: String) throws -> sockaddr_un {
        var address = sockaddr_un()
        address.sun_family = sa_family_t(AF_UNIX)
        let bytes = Array(path.utf8)
        guard bytes.count < MemoryLayout.size(ofValue: address.sun_path) else { throw StringError("Helper socket path is too long.") }
        withUnsafeMutableBytes(of: &address.sun_path) { raw in
            for (index, byte) in bytes.enumerated() { raw[index] = byte }
            raw[bytes.count] = 0
        }
        return address
    }

    private static func handle(_ client: Int32) {
        defer { _ = close(client) }
        var noSignal: Int32 = 1
        _ = setsockopt(client, SOL_SOCKET, SO_NOSIGPIPE, &noSignal, socklen_t(MemoryLayout<Int32>.size))
        guard isAuthorizedClient(client) else { return }
        var stdoutPath = ""
        var stderrPath = ""
        var stdoutFD: Int32 = -1
        var stderrFD: Int32 = -1
        var inputPipe: [Int32] = [-1, -1]
        defer {
            if stdoutFD >= 0 { _ = close(stdoutFD) }
            if stderrFD >= 0 { _ = close(stderrFD) }
            for fd in inputPipe where fd >= 0 { _ = close(fd) }
            if !stdoutPath.isEmpty { _ = unlink(stdoutPath) }
            if !stderrPath.isEmpty { _ = unlink(stderrPath) }
        }

        do {
            let length = UInt64(try readNetworkUInt32(client))
            guard length > 0, length <= UInt64(maxRequestSize) else { throw StringError("Invalid helper request size.") }
            let requestData = try readExactly(client, count: Int(length))
            guard let object = try JSONSerialization.jsonObject(with: requestData) as? [String: Any],
                  let arguments = object["arguments"] as? [String],
                  let command = arguments.first,
                  permittedCommands.contains(command),
                  !arguments.contains("--daemon"),
                  !arguments.contains("--session-daemon") else { throw StringError("Rejected helper command.") }
            let inputLength = try readNetworkUInt64(client)
            if inputLength != UInt64.max && inputLength > maxInputLength { throw StringError("Helper input is too large.") }
            if command == "session-stop" {
                var header = Data()
                header.appendNetworkUInt32(0)
                header.appendNetworkUInt64(0)
                header.appendNetworkUInt64(0)
                try writeAll(client, data: header)
                requestStop()
                return
            }

            var outTemplate = Array("/var/tmp/santander-helper-out.XXXXXX".utf8CString)
            var errTemplate = Array("/var/tmp/santander-helper-err.XXXXXX".utf8CString)
            stdoutFD = outTemplate.withUnsafeMutableBufferPointer { mkstemp($0.baseAddress!) }
            stderrFD = errTemplate.withUnsafeMutableBufferPointer { mkstemp($0.baseAddress!) }
            guard stdoutFD >= 0, stderrFD >= 0 else { throw StringError("Unable to create temporary helper output files.") }
            _ = fcntl(stdoutFD, F_SETFD, FD_CLOEXEC)
            _ = fcntl(stderrFD, F_SETFD, FD_CLOEXEC)
            stdoutPath = String(cString: outTemplate)
            stderrPath = String(cString: errTemplate)
            _ = fchmod(stdoutFD, mode_t(0o600)); _ = fchmod(stderrFD, mode_t(0o600))

            guard pipe(&inputPipe) == 0 else { throw StringError("Unable to create helper input pipe.") }
            var actions: posix_spawn_file_actions_t?
            guard posix_spawn_file_actions_init(&actions) == 0 else { throw StringError("Unable to create helper child process actions.") }
            defer { _ = posix_spawn_file_actions_destroy(&actions) }
            _ = posix_spawn_file_actions_adddup2(&actions, inputPipe[0], STDIN_FILENO)
            _ = posix_spawn_file_actions_adddup2(&actions, stdoutFD, STDOUT_FILENO)
            _ = posix_spawn_file_actions_adddup2(&actions, stderrFD, STDERR_FILENO)
            _ = posix_spawn_file_actions_addclose(&actions, inputPipe[1])
            _ = posix_spawn_file_actions_addclose(&actions, stdoutFD)
            _ = posix_spawn_file_actions_addclose(&actions, stderrFD)

            let executable = CommandLine.arguments.first ?? "/usr/libexec/SantanderHelper"
            let argStrings = [executable] + arguments
            let argv = argStrings.map { strdup($0) } + [nil]
            defer { for item in argv { if let item { free(item) } } }
            var child: pid_t = 0
            let spawnStatus = argv.withUnsafeBufferPointer { posix_spawn(&child, executable, &actions, nil, $0.baseAddress, environ) }
            guard spawnStatus == 0 else { throw StringError("Unable to launch helper command: \(String(cString: strerror(spawnStatus)))") }

            _ = close(inputPipe[0]); inputPipe[0] = -1
            if inputLength == UInt64.max {
                _ = close(inputPipe[1]); inputPipe[1] = -1
            } else {
                var remaining = inputLength
                while remaining > 0 {
                    let amount = Int(min(remaining, 64 * 1024))
                    let chunk = try readExactly(client, count: amount)
                    try writeAll(inputPipe[1], data: chunk)
                    remaining -= UInt64(chunk.count)
                }
                _ = close(inputPipe[1]); inputPipe[1] = -1
            }

            var waitStatus: Int32 = 0
            var waited: pid_t
            repeat { waited = waitpid(child, &waitStatus, 0) } while waited < 0 && errno == EINTR
            guard waited == child else { throw StringError("Unable to wait for helper command.") }
            let resultCode: Int32 = (waitStatus & 0x7f) == 0 ? Int32((waitStatus >> 8) & 0xff) : -1
            var outInfo = stat(); var errInfo = stat()
            guard fstat(stdoutFD, &outInfo) == 0, fstat(stderrFD, &errInfo) == 0 else { throw StringError("Unable to read helper output metadata.") }
            var outLength = UInt64(max(0, outInfo.st_size))
            var errLength = UInt64(max(0, errInfo.st_size))
            if outLength > maxResponseLength || errLength > maxResponseLength {
                let message = Data("Helper output exceeds the 64 MiB response limit; use a streaming file operation instead.".utf8)
                _ = ftruncate(stdoutFD, 0)
                _ = ftruncate(stderrFD, 0)
                _ = lseek(stderrFD, 0, SEEK_SET)
                try writeAll(stderrFD, data: message)
                outLength = 0
                errLength = UInt64(message.count)
                var header = Data()
                header.appendNetworkUInt32(UInt32(bitPattern: -1))
                header.appendNetworkUInt64(outLength)
                header.appendNetworkUInt64(errLength)
                try writeAll(client, data: header)
                try writeAll(client, data: message)
                return
            }
            var header = Data()
            header.appendNetworkUInt32(UInt32(bitPattern: resultCode))
            header.appendNetworkUInt64(outLength)
            header.appendNetworkUInt64(errLength)
            try writeAll(client, data: header)
            guard lseek(stdoutFD, 0, SEEK_SET) >= 0, lseek(stderrFD, 0, SEEK_SET) >= 0 else { throw StringError("Unable to seek helper output.") }
            try streamFile(stdoutFD, length: outLength, to: client)
            try streamFile(stderrFD, length: errLength, to: client)
        } catch {
            
            return
        }
    }

    private static func isAuthorizedClient(_ fd: Int32) -> Bool {
        var uid: uid_t = 0
        var gid: gid_t = 0
        guard getpeereid(fd, &uid, &gid) == 0, uid == 501 else { return false }
        var peerPID: pid_t = 0
        var peerLength = socklen_t(MemoryLayout<pid_t>.size)
        guard getsockopt(fd, SOL_LOCAL, LOCAL_PEERPID, &peerPID, &peerLength) == 0, peerPID > 0 else { return false }
        typealias ProcPIDPath = @convention(c) (pid_t, UnsafeMutablePointer<CChar>, UInt32) -> Int32
        guard let handle = dlopen("/usr/lib/libproc.dylib", RTLD_NOW),
              let symbol = dlsym(handle, "proc_pidpath") else { return false }
        let procPIDPath = unsafeBitCast(symbol, to: ProcPIDPath.self)
        var pathBuffer = [CChar](repeating: 0, count: 1024)
        let count = pathBuffer.withUnsafeMutableBufferPointer { procPIDPath(peerPID, $0.baseAddress!, UInt32($0.count)) }
        guard count > 0 else { return false }
        let executablePath = String(cString: pathBuffer)
        let bundlePath = URL(fileURLWithPath: executablePath).deletingLastPathComponent().path
        return Bundle(path: bundlePath)?.bundleIdentifier == "com.Antoine.Santander"
    }

    private static func readNetworkUInt32(_ fd: Int32) throws -> UInt32 {
        let data = try readExactly(fd, count: 4)
        return data.reduce(UInt32(0)) { ($0 << 8) | UInt32($1) }
    }

    private static func readNetworkUInt64(_ fd: Int32) throws -> UInt64 {
        let data = try readExactly(fd, count: 8)
        return data.reduce(UInt64(0)) { ($0 << 8) | UInt64($1) }
    }

    private static func readExactly(_ fd: Int32, count: Int) throws -> Data {
        var result = Data(count: count)
        var received = 0
        try result.withUnsafeMutableBytes { (raw: UnsafeMutableRawBufferPointer) in
            guard let base = raw.baseAddress else { throw StringError("Invalid read buffer.") }
            while received < count {
                let amount = Darwin.read(fd, base.advanced(by: received), count - received)
                if amount > 0 { received += amount }
                else if amount < 0 && errno == EINTR { continue }
                else { throw StringError("Unable to read helper request.") }
            }
        }
        return result
    }

    private static func writeAll(_ fd: Int32, data: Data) throws {
        try data.withUnsafeBytes { (raw: UnsafeRawBufferPointer) in
            guard let base = raw.baseAddress else { return }
            var offset = 0
            while offset < raw.count {
                let amount = Darwin.write(fd, base.advanced(by: offset), raw.count - offset)
                if amount > 0 { offset += amount }
                else if amount < 0 && errno == EINTR { continue }
                else { throw StringError("Unable to write helper response.") }
            }
        }
    }

    private static func streamFile(_ inputFD: Int32, length: UInt64, to outputFD: Int32) throws {
        var remaining = length
        var buffer = [UInt8](repeating: 0, count: 64 * 1024)
        while remaining > 0 {
            let amount = Int(min(remaining, UInt64(buffer.count)))
            let count = Darwin.read(inputFD, &buffer, amount)
            if count > 0 {
                try Data(buffer[0..<count]).withUnsafeBytes { raw in
                    guard let base = raw.baseAddress else { return }
                    var offset = 0
                    while offset < count {
                        let written = Darwin.write(outputFD, base.advanced(by: offset), count - offset)
                        if written > 0 { offset += written }
                        else if written < 0 && errno == EINTR { continue }
                        else { throw StringError("Unable to stream helper output.") }
                    }
                }
                remaining -= UInt64(count)
            } else if count < 0 && errno == EINTR {
                continue
            } else {
                throw StringError("Unexpected end of helper output.")
            }
        }
    }
}

private extension Data {
    mutating func appendNetworkUInt32(_ value: UInt32) {
        var network = value.bigEndian
        Swift.withUnsafeBytes(of: &network) { append(contentsOf: $0) }
    }
    mutating func appendNetworkUInt64(_ value: UInt64) {
        var network = value.bigEndian
        Swift.withUnsafeBytes(of: &network) { append(contentsOf: $0) }
    }
}

@main
struct SantanderHelper {
    private static func parentExecutablePath() -> String? {
        typealias ProcPIDPath = @convention(c) (pid_t, UnsafeMutablePointer<CChar>, UInt32) -> Int32
        let handles = [
            dlopen("/usr/lib/libproc.dylib", RTLD_NOW),
            dlopen(nil, RTLD_NOW)
        ]

        var symbol: UnsafeMutableRawPointer?
        for handle in handles {
            guard let handle else { continue }
            if let resolved = dlsym(handle, "proc_pidpath") {
                symbol = resolved
                break
            }
        }
        guard let symbol else { return nil }

        let procPIDPath = unsafeBitCast(symbol, to: ProcPIDPath.self)
        var buffer = [CChar](repeating: 0, count: 1024)
        let result = buffer.withUnsafeMutableBufferPointer { buffer in
            guard let baseAddress = buffer.baseAddress else { return Int32(0) }
            return procPIDPath(getppid(), baseAddress, UInt32(buffer.count))
        }
        guard result > 0 else { return nil }
        return String(cString: buffer)
    }

    static func main() {
        let startupArguments = Array(CommandLine.arguments.dropFirst())
        if startupArguments.first == "--session-daemon" {
            guard let socketIndex = startupArguments.firstIndex(of: "--socket"),
                  socketIndex + 1 < startupArguments.count,
                  let parentIndex = startupArguments.firstIndex(of: "--parent-pid"),
                  parentIndex + 1 < startupArguments.count,
                  let parentValue = Int32(startupArguments[parentIndex + 1]) else {
                fputs("Invalid helper session arguments\n", stderr)
                exit(64)
            }
            do {
                try SantanderHelperDaemon.run(socketPath: startupArguments[socketIndex + 1], parentPID: parentValue)
            } catch {
                fputs("SantanderHelper session: \(error.localizedDescription)\n", stderr)
                exit(1)
            }
            return
        }

        guard let parentPath = parentExecutablePath() else { exit(-1) }
        let parentName = URL(fileURLWithPath: parentPath).lastPathComponent
        guard ["Santander", "AppSantander", "SantanderHelper"].contains(parentName) else { exit(-1) }
        // The long-lived session daemon is restarted by the installed helper path;
        // the initial spawnRoot child is launched by Santander/AppSantander directly.
        if parentName == "SantanderHelper" {
            let isBundledHelper = parentPath.contains("/Santander.app/SantanderHelper")
                || parentPath.contains("/AppSantander.app/SantanderHelper")
            let isInstalledHelper = parentPath == "/usr/libexec/SantanderHelper"
                || parentPath == "/var/jb/usr/libexec/SantanderHelper"
            guard isBundledHelper || isInstalledHelper else { exit(-1) }
        }

        guard getuid() == 0, geteuid() == 0, getgid() == 0, getegid() == 0 else {
            fputs("SantanderHelper must be launched with TrollStore spawnRoot; self-elevation is not supported.\n", stderr)
            exit(EXIT_FAILURE)
        }

        struct Program: ParsableCommand {
            static let configuration = CommandConfiguration(
                subcommands: [
                    Create.self,
                    Delete.self,
                    Move.self,
                    Copy.self,
                    Link.self,
                    Rename.self,
                    SetOwnerOrGroup.self,
                    SetPermissions.self,
                    SetLocked.self,
                    SetFileFlag.self,
                    ListExtendedAttributes.self,
                    GetExtendedAttribute.self,
                    SetExtendedAttribute.self,
                    RemoveExtendedAttribute.self,
                    SnapshotCreate.self,
                    SnapshotList.self,
                    SnapshotRestore.self,
                    SnapshotDelete.self,
                    Compress.self,
                    Decompress.self,
                    ListArchive.self,
                    ExtractArchiveEntry.self,
                    ExtractCatalog.self,
                    WriteData.self,
                    ReplaceFile.self,
                    WriteString.self,
                    GetContents.self,
                    Identity.self,
                    Mount.self,
                    Unmount.self
                ]
            )
        }

        do {
            var command = try Program.parseAsRoot(nil)
            try command.run()
        } catch {
            fputs(error.localizedDescription + "\n", stderr)
            exit(-1)
        }
    }
}
