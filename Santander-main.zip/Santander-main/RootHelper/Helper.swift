import Foundation
import Darwin
import ArgumentParser
import CompressionWrapper
import AssetCatalogWrapper

extension URL: ExpressibleByArgument {
    public init?(argument: String) {
        self.init(fileURLWithPath: argument)
    }
}

struct StringError: LocalizedError, CustomStringConvertible {
    let description: String

    init(_ description: String) {
        self.description = description
    }

    var errorDescription: String? {
        description
    }
}

extension Compression.FormatType: ExpressibleByArgument {
    public init?(argument: String) {
        switch argument {
        case "zip":
            self = .zip
        case "tar":
            self = .tar
        default:
            return nil
        }
    }
}

struct Delete: ParsableCommand {
    @Argument var paths: [URL]

    func run() throws {
        for path in paths {
            try FileManager.default.removeItem(at: path)
        }
    }
}

struct SetOwnerOrGroup: ParsableCommand {
    @Argument var path: URL
    @Option var groupName: String?
    @Option var ownerName: String?
    @Option var groupID: Int32?
    @Option var ownerID: Int32?

    func run() throws {
        var attributes: [FileAttributeKey: Any] = [:]
        if let groupName {
            attributes[.groupOwnerAccountName] = groupName
        }
        if let ownerName {
            attributes[.ownerAccountName] = ownerName
        }
        if let groupID {
            attributes[.groupOwnerAccountID] = NSNumber(value: groupID)
        }
        if let ownerID {
            attributes[.ownerAccountID] = NSNumber(value: ownerID)
        }
        guard !attributes.isEmpty else {
            throw StringError("No owner or group change was requested")
        }
        try FileManager.default.setAttributes(attributes, ofItemAtPath: path.path)
    }
}

struct Create: ParsableCommand {
    @Option var directories: [URL] = []
    @Option var files: [URL] = []

    func run() throws {
        for dir in directories {
            try FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
        }
        for file in files {
            let descriptor = open(file.path, O_WRONLY | O_CREAT | O_CLOEXEC, 0o644)
            guard descriptor >= 0 else {
                throw StringError("Failed to create \(file.path): \(String(cString: strerror(errno)))")
            }
            close(descriptor)
        }
    }
}

struct Move: ParsableCommand {
    @Argument var paths: [URL]
    @Option var destination: URL

    func run() throws {
        for path in paths {
            try FileManager.default.moveItem(at: path, to: destination.appendingPathComponent(path.lastPathComponent))
        }
    }
}

struct Copy: ParsableCommand {
    @Argument var paths: [URL]
    @Option var destination: URL

    func run() throws {
        for path in paths {
            try FileManager.default.copyItem(at: path, to: destination.appendingPathComponent(path.lastPathComponent))
        }
    }
}

struct Rename: ParsableCommand {
    @Argument var path: URL
    @Argument var destination: URL

    func run() throws {
        try FileManager.default.moveItem(at: path, to: destination)
    }
}

struct Link: ParsableCommand {
    @Argument var paths: [URL]
    @Option var destination: URL

    func run() throws {
        for path in paths {
            try FileManager.default.createSymbolicLink(
                at: destination.appendingPathComponent(path.lastPathComponent),
                withDestinationURL: path
            )
        }
    }
}

struct SetPermissions: ParsableCommand {
    @Argument var path: URL
    @Argument var permissions: Int

    func run() throws {
        guard permissions >= 0 && permissions <= 0o7777 else {
            throw StringError("Permissions must be between 0000 and 7777")
        }
        try FileManager.default.setAttributes([.posixPermissions: permissions], ofItemAtPath: path.path)
    }
}

struct WriteData: ParsableCommand {
    @Argument var path: URL

    func run() throws {
        let data = FileHandle.standardInput.readDataToEndOfFile()
        try data.write(to: path, options: .atomic)
    }
}

struct WriteString: ParsableCommand {
    @Argument var string: String
    @Option var path: URL

    func run() throws {
        try string.write(to: path, atomically: true, encoding: .utf8)
    }
}

struct Compress: ParsableCommand {
    @Option var paths: [URL]
    @Option var destination: URL
    @Option var format: Compression.FormatType = .zip

    func run() throws {
        try Compression.shared.compress(paths: paths, outputPath: destination, format: format)
    }
}

struct Decompress: ParsableCommand {
    @Argument var path: URL
    @Option var destination: URL

    func run() throws {
        try Compression.shared.extract(path: path, to: destination)
    }
}

struct ExtractCatalog: ParsableCommand {
    @Argument var path: URL
    @Option var destination: URL

    func run() throws {
        let (_, renditions) = try AssetCatalogWrapper.shared.renditions(forCarArchive: path)
        let codable = renditions.flatMap(\.renditions).toCodable()
        try FileManager.default.createDirectory(at: destination, withIntermediateDirectories: true)

        var failures: [String] = []
        for rendition in codable {
            guard let data = rendition.itemData else {
                continue
            }
            let destinationURL = destination.appendingPathComponent(rendition.renditionName)
            do {
                try data.write(to: destinationURL, options: .atomic)
            } catch {
                failures.append("\(rendition.renditionName): \(error.localizedDescription)")
            }
        }

        if !failures.isEmpty {
            throw StringError(failures.joined(separator: "\n"))
        }
    }
}

struct GetContents: ParsableCommand {
    @Argument var path: URL

    func run() throws {
        let contents = try FileManager.default.contentsOfDirectory(at: path, includingPropertiesForKeys: nil)
        fputs(contents.map(\.path).joined(separator: "\n"), stdout)
    }
}

struct Mount: ParsableCommand {
    @Argument var source: URL
    @Argument var target: URL
    @Option var filesystemType: String?
    @Flag var readOnly = false

    func run() throws {
        try FileManager.default.createDirectory(at: target, withIntermediateDirectories: true)
        let executable = try Self.executable(named: "mount")
        var arguments = [source.path, target.path]
        if let filesystemType {
            arguments = ["-t", filesystemType] + arguments
        }
        if readOnly {
            arguments.insert("-o", at: 0)
            arguments.insert("ro", at: 1)
        }
        try RootProcess.run(executable: executable, arguments: arguments)
    }

    static func executable(named name: String) throws -> String {
        let candidates = [
            "/var/jb/sbin/\(name)",
            "/var/jb/usr/sbin/\(name)",
            "/sbin/\(name)",
            "/usr/sbin/\(name)"
        ]
        if let path = candidates.first(where: { FileManager.default.isExecutableFile(atPath: $0) }) {
            return path
        }
        throw StringError("\(name) executable was not found")
    }
}

struct Unmount: ParsableCommand {
    @Argument var target: URL
    @Flag var force = false

    func run() throws {
        let executable = try Mount.executable(named: "umount")
        var arguments = [target.path]
        if force {
            arguments.insert("-f", at: 0)
        }
        try RootProcess.run(executable: executable, arguments: arguments)
    }
}

enum RootProcess {
    static func run(executable: String, arguments: [String]) throws {
        let argvStrings = [executable] + arguments
        var argv = argvStrings.map { strdup($0) } + [nil]
        defer {
            for item in argv {
                if let item { free(item) }
            }
        }

        var pipeFD: [Int32] = [0, 0]
        guard pipe(&pipeFD) == 0 else {
            throw StringError("Unable to create process pipe: \(String(cString: strerror(errno)))")
        }
        defer {
            close(pipeFD[0])
            close(pipeFD[1])
        }

        var actions: posix_spawn_file_actions_t?
        guard posix_spawn_file_actions_init(&actions) == 0 else {
            throw StringError("Unable to initialize process actions")
        }
        defer { posix_spawn_file_actions_destroy(&actions) }

        posix_spawn_file_actions_adddup2(&actions, pipeFD[1], STDOUT_FILENO)
        posix_spawn_file_actions_adddup2(&actions, pipeFD[1], STDERR_FILENO)
        posix_spawn_file_actions_addclose(&actions, pipeFD[0])

        var pid: pid_t = 0
        let status = argv.withUnsafeBufferPointer { arguments in
            posix_spawn(&pid, executable, &actions, nil, arguments.baseAddress, nil)
        }
        close(pipeFD[1])
        pipeFD[1] = -1
        guard status == 0 else {
            throw StringError("Unable to start \(executable): \(String(cString: strerror(status)))")
        }

        let output = FileHandle(fileDescriptor: pipeFD[0], closeOnDealloc: false).readDataToEndOfFile()
        var processStatus: Int32 = 0
        guard waitpid(pid, &processStatus, 0) == pid else {
            throw StringError("Unable to wait for \(executable): \(String(cString: strerror(errno)))")
        }

        let message = String(data: output, encoding: .utf8)?.trimmingCharacters(in: .whitespacesAndNewlines)

        if WIFEXITED(processStatus) {
            let code = WEXITSTATUS(processStatus)
            guard code == 0 else {
                let suffix = message.map { ": \($0)" } ?? ""
                throw StringError("\(executable) exited with status \(code)\(suffix)")
            }
        } else {
            throw StringError("\(executable) terminated unexpectedly")
        }
    }
}

@main
struct RootHelper {
    static func main() {
        var buffer = [CChar](repeating: 0, count: 1024)
        guard proc_pidpath(getppid(), &buffer, UInt32(buffer.count)) > 0 else {
            exit(-1)
        }

        let parentPath = String(cString: buffer)
        guard ["Santander", "AppSantander"].contains(URL(fileURLWithPath: parentPath).lastPathComponent) else {
            exit(-1)
        }

        guard setgid(0) == 0, setuid(0) == 0, getuid() == 0, geteuid() == 0 else {
            fputs("Root privileges were not obtained\n", stderr)
            exit(-1)
        }

        struct Program: ParsableCommand {
            static let configuration = CommandConfiguration(
                subcommands: [
                    Create.self,
                    Delete.self,
                    Move.self,
                    Copy.self,
                    Link.self,
                    Rename.self,
                    SetOwnerOrGroup.self,
                    SetPermissions.self,
                    Compress.self,
                    Decompress.self,
                    ExtractCatalog.self,
                    WriteData.self,
                    WriteString.self,
                    GetContents.self,
                    Mount.self,
                    Unmount.self
                ]
            )
        }

        do {
            var command = try Program.parseAsRoot(nil)
            try command.run()
        } catch {
            fputs(error.localizedDescription + "\n", stderr)
            exit(-1)
        }
    }
}
