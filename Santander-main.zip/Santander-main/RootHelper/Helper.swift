import Foundation
import Darwin
import ArgumentParser
import ImageIO
import ObjectiveC
import UIKit

extension URL: ExpressibleByArgument {
    public init?(argument: String) {
        self.init(fileURLWithPath: argument)
    }
}

struct StringError: LocalizedError, CustomStringConvertible {
    let description: String

    init(_ description: String) {
        self.description = description
    }

    var errorDescription: String? {
        description
    }
}

struct CodableRendition {
    let renditionName: String
    let itemData: Data?
}

private enum HelperCoreUIRuntime {
    static let coreUIHandle = dlopen(
        "/System/Library/PrivateFrameworks/CoreUI.framework/CoreUI",
        RTLD_LAZY | RTLD_LOCAL
    )

    static func method(_ receiver: AnyObject, _ selector: Selector) -> Method? {
        guard let cls = object_getClass(receiver) else { return nil }
        return class_getInstanceMethod(cls, selector)
    }

    static func object(_ receiver: AnyObject, _ selector: Selector) -> AnyObject? {
        guard let method = method(receiver, selector) else { return nil }
        typealias Function = @convention(c) (AnyObject, Selector) -> Unmanaged<AnyObject>?
        let function = unsafeBitCast(method_getImplementation(method), to: Function.self)
        return function(receiver, selector)?.takeUnretainedValue()
    }

    static func object(_ receiver: AnyObject, _ selector: Selector, _ argument: AnyObject?) -> AnyObject? {
        guard let method = method(receiver, selector) else { return nil }
        typealias Function = @convention(c) (AnyObject, Selector, AnyObject?) -> Unmanaged<AnyObject>?
        let function = unsafeBitCast(method_getImplementation(method), to: Function.self)
        return function(receiver, selector, argument)?.takeUnretainedValue()
    }

    static func data(_ receiver: AnyObject, _ selector: Selector) -> Data? {
        guard let value = object(receiver, selector) else { return nil }
        if let data = value as? Data { return data }
        if let data = value as? NSData { return data as Data }
        return nil
    }

    static func int64(_ receiver: AnyObject, _ selector: Selector) -> Int64? {
        guard let method = method(receiver, selector) else { return nil }
        typealias Function = @convention(c) (AnyObject, Selector) -> Int64
        let function = unsafeBitCast(method_getImplementation(method), to: Function.self)
        return function(receiver, selector)
    }

    static func image(_ receiver: AnyObject, _ selector: Selector) -> CGImage? {
        guard let method = method(receiver, selector) else { return nil }
        typealias Function = @convention(c) (AnyObject, Selector) -> Unmanaged<CGImage>?
        let function = unsafeBitCast(method_getImplementation(method), to: Function.self)
        return function(receiver, selector)?.takeUnretainedValue()
    }

    static func block(_ receiver: AnyObject, _ selector: Selector, _ callback: @escaping (AnyObject) -> Void) {
        guard let method = method(receiver, selector) else { return }
        typealias Block = @convention(block) (AnyObject) -> Void
        let block: Block = { object in callback(object) }
        let blockObject = unsafeBitCast(block, to: AnyObject.self)
        typealias Function = @convention(c) (AnyObject, Selector, AnyObject) -> Void
        let function = unsafeBitCast(method_getImplementation(method), to: Function.self)
        function(receiver, selector, blockObject)
    }

    static func allocateAndInitialize(className: String, initializer: Selector, argument: AnyObject) -> AnyObject? {
        _ = coreUIHandle
        guard let cls = NSClassFromString(className),
              let allocated = object(cls as AnyObject, NSSelectorFromString("alloc")) else {
            return nil
        }
        return object(allocated, initializer, argument)
    }
}

final class AssetCatalogWrapper {
    static let shared = AssetCatalogWrapper()

    private init() {}

    func renditions(forCarArchive url: URL) throws -> [CodableRendition] {
        guard FileManager.default.fileExists(atPath: url.path) else {
            throw StringError("Asset catalog does not exist: \(url.path)")
        }

        guard let catalog =
                HelperCoreUIRuntime.allocateAndInitialize(
                    className: "CUICatalog",
                    initializer: NSSelectorFromString("initWithURL:"),
                    argument: url as NSURL
                )
                ?? HelperCoreUIRuntime.allocateAndInitialize(
                    className: "CUICatalog",
                    initializer: NSSelectorFromString("initWithContentsOfURL:"),
                    argument: url as NSURL
                ) else {
            throw StringError("CoreUI CUICatalog is unavailable on this OS.")
        }

        var result: [CodableRendition] = []
        HelperCoreUIRuntime.block(
            catalog,
            Selector(("enumerateNamedLookupsUsingBlock:"))
        ) { lookup in
            let lookupName = HelperCoreUIRuntime.object(lookup, Selector(("name"))) as? String
                ?? "Unnamed Asset"
            let rendition = HelperCoreUIRuntime.object(lookup, Selector(("rendition"))) ?? lookup
            let key = HelperCoreUIRuntime.object(lookup, Selector(("key")))
            let isIcon: Bool
            if let key {
                isIcon = HelperCoreUIRuntime.int64(key, Selector(("themeElement"))) == 85
                    && HelperCoreUIRuntime.int64(key, Selector(("themePart"))) == 220
            } else {
                isIcon = false
            }
            let renditionName = isIcon
                ? (HelperCoreUIRuntime.object(rendition, Selector(("name"))) as? String ?? lookupName)
                : lookupName

            let itemData =
                HelperCoreUIRuntime.data(rendition, Selector(("srcData")))
                ?? HelperCoreUIRuntime.data(rendition, Selector(("data")))
                ?? Self.imageData(rendition)

            result.append(CodableRendition(renditionName: renditionName, itemData: itemData))
        }
        return result
    }

    private static func imageData(_ rendition: AnyObject) -> Data? {
        if let image = HelperCoreUIRuntime.image(rendition, Selector(("uncroppedImage"))) {
            return UIImage(cgImage: image).pngData()
        }

        guard let data = HelperCoreUIRuntime.data(rendition, Selector(("data"))) else {
            return nil
        }

        if let source = CGImageSourceCreateWithData(data as CFData, nil),
           let image = CGImageSourceCreateImageAtIndex(source, 0, nil) {
            return UIImage(cgImage: image).pngData()
        }

        guard let provider = CGDataProvider(data: data as CFData),
              let document = CGPDFDocument(provider),
              let page = document.page(at: 1) else {
            return nil
        }

        let rect = page.getBoxRect(.mediaBox)
        let width = max(1, Int(rect.width.rounded(.up)))
        let height = max(1, Int(rect.height.rounded(.up)))
        guard let colorSpace = CGColorSpace(name: CGColorSpace.sRGB),
              let context = CGContext(
                data: nil,
                width: width,
                height: height,
                bitsPerComponent: 8,
                bytesPerRow: 0,
                space: colorSpace,
                bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue
              ),
              let image = {
                  context.drawPDFPage(page)
                  return context.makeImage()
              }() else {
            return nil
        }
        return UIImage(cgImage: image).pngData()
    }
}

final class Compression {
    enum FormatType: String, CaseIterable, CustomStringConvertible, Codable {
        case zip
        case tar

        var description: String { rawValue.capitalized }
    }

    static let shared = Compression()
    private init() {}

    func compress(paths: [URL], outputPath: URL, format: FormatType) throws {
        guard !paths.isEmpty else {
            throw StringError("No input paths were supplied.")
        }
        try FileManager.default.createDirectory(
            at: outputPath.deletingLastPathComponent(),
            withIntermediateDirectories: true
        )

        switch format {
        case .zip:
            try RootProcess.run(
                executable: "/usr/bin/zip",
                arguments: ["-qry", outputPath.path] + paths.map(\.path)
            )
        case .tar:
            try RootProcess.run(
                executable: "/usr/bin/tar",
                arguments: ["-cf", outputPath.path] + paths.map(\.path)
            )
        }
    }

    func extract(path: URL, to destination: URL) throws {
        try FileManager.default.createDirectory(at: destination, withIntermediateDirectories: true)

        if path.path.lowercased().hasSuffix(".zip") {
            try RootProcess.run(
                executable: "/usr/bin/unzip",
                arguments: ["-o", path.path, "-d", destination.path]
            )
        } else {
            try RootProcess.run(
                executable: "/usr/bin/tar",
                arguments: ["-xf", path.path, "-C", destination.path]
            )
        }
    }
}

extension Compression.FormatType: ExpressibleByArgument {
    public init?(argument: String) {
        switch argument {
        case "zip":
            self = .zip
        case "tar":
            self = .tar
        default:
            return nil
        }
    }
}

struct Delete: ParsableCommand {
    @Argument var paths: [URL]

    func run() throws {
        for path in paths {
            try FileManager.default.removeItem(at: path)
        }
    }
}

struct SetOwnerOrGroup: ParsableCommand {
    @Argument var path: URL
    @Option var groupName: String?
    @Option var ownerName: String?
    @Option var groupID: Int32?
    @Option var ownerID: Int32?

    func run() throws {
        var attributes: [FileAttributeKey: Any] = [:]
        if let groupName {
            attributes[.groupOwnerAccountName] = groupName
        }
        if let ownerName {
            attributes[.ownerAccountName] = ownerName
        }
        if let groupID {
            attributes[.groupOwnerAccountID] = NSNumber(value: groupID)
        }
        if let ownerID {
            attributes[.ownerAccountID] = NSNumber(value: ownerID)
        }
        guard !attributes.isEmpty else {
            throw StringError("No owner or group change was requested")
        }
        try FileManager.default.setAttributes(attributes, ofItemAtPath: path.path)
    }
}

struct Create: ParsableCommand {
    @Option var directories: [URL] = []
    @Option var files: [URL] = []

    func run() throws {
        for dir in directories {
            try FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
        }
        for file in files {
            let descriptor = open(file.path, O_WRONLY | O_CREAT | O_CLOEXEC, 0o644)
            guard descriptor >= 0 else {
                throw StringError("Failed to create \(file.path): \(String(cString: strerror(errno)))")
            }
            close(descriptor)
        }
    }
}

struct Move: ParsableCommand {
    @Argument var paths: [URL]
    @Option var destination: URL

    func run() throws {
        for path in paths {
            try FileManager.default.moveItem(at: path, to: destination.appendingPathComponent(path.lastPathComponent))
        }
    }
}

struct Copy: ParsableCommand {
    @Argument var paths: [URL]
    @Option var destination: URL

    func run() throws {
        for path in paths {
            try FileManager.default.copyItem(at: path, to: destination.appendingPathComponent(path.lastPathComponent))
        }
    }
}

struct Rename: ParsableCommand {
    @Argument var path: URL
    @Argument var destination: URL

    func run() throws {
        try FileManager.default.moveItem(at: path, to: destination)
    }
}

struct Link: ParsableCommand {
    @Argument var paths: [URL]
    @Option var destination: URL

    func run() throws {
        for path in paths {
            try FileManager.default.createSymbolicLink(
                at: destination.appendingPathComponent(path.lastPathComponent),
                withDestinationURL: path
            )
        }
    }
}

struct SetPermissions: ParsableCommand {
    @Argument var path: URL
    @Argument var permissions: Int

    func run() throws {
        guard permissions >= 0 && permissions <= 0o7777 else {
            throw StringError("Permissions must be between 0000 and 7777")
        }
        try FileManager.default.setAttributes([.posixPermissions: permissions], ofItemAtPath: path.path)
    }
}

struct WriteData: ParsableCommand {
    @Argument var path: URL

    func run() throws {
        let data = FileHandle.standardInput.readDataToEndOfFile()
        try data.write(to: path, options: .atomic)
    }
}

struct WriteString: ParsableCommand {
    @Argument var string: String
    @Option var path: URL

    func run() throws {
        try string.write(to: path, atomically: true, encoding: .utf8)
    }
}

struct Compress: ParsableCommand {
    @Option var paths: [URL]
    @Option var destination: URL
    @Option var format: Compression.FormatType = .zip

    func run() throws {
        try Compression.shared.compress(paths: paths, outputPath: destination, format: format)
    }
}

struct Decompress: ParsableCommand {
    @Argument var path: URL
    @Option var destination: URL

    func run() throws {
        try Compression.shared.extract(path: path, to: destination)
    }
}

struct ExtractCatalog: ParsableCommand {
    @Argument var path: URL
    @Option var destination: URL

    func run() throws {
        let renditions = try AssetCatalogWrapper.shared.renditions(forCarArchive: path)
        try FileManager.default.createDirectory(at: destination, withIntermediateDirectories: true)

        var failures: [String] = []
        for rendition in renditions {
            guard let data = rendition.itemData else {
                continue
            }
            let destinationURL = destination.appendingPathComponent(rendition.renditionName)
            do {
                try data.write(to: destinationURL, options: .atomic)
            } catch {
                failures.append("\(rendition.renditionName): \(error.localizedDescription)")
            }
        }

        if !failures.isEmpty {
            throw StringError(failures.joined(separator: "\n"))
        }
    }
}

struct GetContents: ParsableCommand {
    @Argument var path: URL

    func run() throws {
        let contents = try FileManager.default.contentsOfDirectory(at: path, includingPropertiesForKeys: nil)
        fputs(contents.map(\.path).joined(separator: "\n"), stdout)
    }
}

struct Mount: ParsableCommand {
    @Argument var source: URL
    @Argument var target: URL
    @Option var filesystemType: String?
    @Flag var readOnly = false

    func run() throws {
        try FileManager.default.createDirectory(at: target, withIntermediateDirectories: true)
        let executable = try Self.executable(named: "mount")
        var arguments = [source.path, target.path]
        if let filesystemType {
            arguments = ["-t", filesystemType] + arguments
        }
        if readOnly {
            arguments.insert("-o", at: 0)
            arguments.insert("ro", at: 1)
        }
        try RootProcess.run(executable: executable, arguments: arguments)
    }

    static func executable(named name: String) throws -> String {
        let candidates = [
            "/var/jb/sbin/\(name)",
            "/var/jb/usr/sbin/\(name)",
            "/sbin/\(name)",
            "/usr/sbin/\(name)"
        ]
        if let path = candidates.first(where: { FileManager.default.isExecutableFile(atPath: $0) }) {
            return path
        }
        throw StringError("\(name) executable was not found")
    }
}

struct Unmount: ParsableCommand {
    @Argument var target: URL
    @Flag var force = false

    func run() throws {
        let executable = try Mount.executable(named: "umount")
        var arguments = [target.path]
        if force {
            arguments.insert("-f", at: 0)
        }
        try RootProcess.run(executable: executable, arguments: arguments)
    }
}

enum RootProcess {
    static func run(executable: String, arguments: [String]) throws {
        let argvStrings = [executable] + arguments
        var argv = argvStrings.map { strdup($0) } + [nil]
        defer {
            for item in argv {
                if let item { free(item) }
            }
        }

        var pipeFD: [Int32] = [0, 0]
        guard pipe(&pipeFD) == 0 else {
            throw StringError("Unable to create process pipe: \(String(cString: strerror(errno)))")
        }
        defer {
            close(pipeFD[0])
            close(pipeFD[1])
        }

        var actions: posix_spawn_file_actions_t?
        guard posix_spawn_file_actions_init(&actions) == 0 else {
            throw StringError("Unable to initialize process actions")
        }
        defer { posix_spawn_file_actions_destroy(&actions) }

        posix_spawn_file_actions_adddup2(&actions, pipeFD[1], STDOUT_FILENO)
        posix_spawn_file_actions_adddup2(&actions, pipeFD[1], STDERR_FILENO)
        posix_spawn_file_actions_addclose(&actions, pipeFD[0])

        var pid: pid_t = 0
        let status = argv.withUnsafeBufferPointer { arguments in
            posix_spawn(&pid, executable, &actions, nil, arguments.baseAddress, nil)
        }
        close(pipeFD[1])
        pipeFD[1] = -1
        guard status == 0 else {
            throw StringError("Unable to start \(executable): \(String(cString: strerror(status)))")
        }

        let output = FileHandle(fileDescriptor: pipeFD[0], closeOnDealloc: false).readDataToEndOfFile()
        var processStatus: Int32 = 0
        guard waitpid(pid, &processStatus, 0) == pid else {
            throw StringError("Unable to wait for \(executable): \(String(cString: strerror(errno)))")
        }

        let message = String(data: output, encoding: .utf8)?.trimmingCharacters(in: .whitespacesAndNewlines)

        let encodedStatus = UInt32(bitPattern: processStatus)
        if encodedStatus & 0x7f == 0 {
            let code = (encodedStatus >> 8) & 0xff
            guard code == 0 else {
                let suffix = message.map { ": \($0)" } ?? ""
                throw StringError("\(executable) exited with status \(code)\(suffix)")
            }
        } else {
            throw StringError("\(executable) terminated unexpectedly")
        }
    }
}

@main
struct RootHelper {
    private static func parentExecutablePath() -> String? {
        typealias ProcPIDPath = @convention(c) (pid_t, UnsafeMutablePointer<CChar>, UInt32) -> Int32
        let handles = [
            dlopen("/usr/lib/libproc.dylib", RTLD_NOW),
            dlopen(nil, RTLD_NOW)
        ]

        var symbol: UnsafeMutableRawPointer?
        for handle in handles {
            guard let handle else { continue }
            if let resolved = dlsym(handle, "proc_pidpath") {
                symbol = resolved
                break
            }
        }
        guard let symbol else { return nil }

        let procPIDPath = unsafeBitCast(symbol, to: ProcPIDPath.self)
        var buffer = [CChar](repeating: 0, count: 1024)
        let result = buffer.withUnsafeMutableBufferPointer { buffer in
            guard let baseAddress = buffer.baseAddress else { return Int32(0) }
            return procPIDPath(getppid(), baseAddress, UInt32(buffer.count))
        }
        guard result > 0 else { return nil }
        return String(cString: buffer)
    }

    static func main() {
        guard let parentPath = parentExecutablePath() else {
            exit(-1)
        }

        guard ["Santander", "AppSantander"].contains(URL(fileURLWithPath: parentPath).lastPathComponent) else {
            exit(-1)
        }

        guard setgid(0) == 0, setuid(0) == 0, getuid() == 0, geteuid() == 0 else {
            fputs("Root privileges were not obtained\n", stderr)
            exit(-1)
        }

        struct Program: ParsableCommand {
            static let configuration = CommandConfiguration(
                subcommands: [
                    Create.self,
                    Delete.self,
                    Move.self,
                    Copy.self,
                    Link.self,
                    Rename.self,
                    SetOwnerOrGroup.self,
                    SetPermissions.self,
                    Compress.self,
                    Decompress.self,
                    ExtractCatalog.self,
                    WriteData.self,
                    WriteString.self,
                    GetContents.self,
                    Mount.self,
                    Unmount.self
                ]
            )
        }

        do {
            var command = try Program.parseAsRoot(nil)
            try command.run()
        } catch {
            fputs(error.localizedDescription + "\n", stderr)
            exit(-1)
        }
    }
}
