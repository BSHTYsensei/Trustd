# Native UI transition and file-lock fix

- Replaced the bespoke over-full-screen action panel animator with a native `UISheetPresentationController` on iOS 15 and later. It retains the existing action icons, subtitles, destructive styles, selection checkmarks, and cancel handler while using the system sheet's presentation, drag, detent, and dismissal behavior.
- Kept a native `UIAlertController` action-sheet fallback for iOS 14.
- Removed the custom browser `UIViewControllerAnimatedTransitioning` implementation and its navigation-controller delegate installation. Opening and leaving directories now use the standard `UINavigationController` push/pop transition.
- Changed plist item type conversion to use the same system sheet and grouped the type/value table reloads into a single automatic batch update.
- Made the immutable/locked status row visible only for non-directory files. Directory permission screens continue to expose POSIX owner/group/other permissions, special bits, and recursive scope controls.
- `PathPermissions` now reports the lock flag as false for directories; the existing mutation guard continues to reject attempts to lock a directory.

Validation performed: Swift frontend syntax parse (`swiftc -frontend -parse -swift-version 5 Santander.swift`), source assertions for removed browser animator and directory-lock row behavior, and ZIP integrity. A full Xcode/iOS SDK build was not available in this environment.
