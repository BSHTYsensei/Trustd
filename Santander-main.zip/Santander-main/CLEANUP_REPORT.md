# Santander build and resource cleanup

## Build fix

- Added `showGridBrowserTabs()` to `SantanderGridViewController`, matching the list controller behavior and presenting the same tab manager as a page sheet.
- Updated the grid toolbar action to call the grid-local method.
- Marked imported-type conformances with Swift 6 `@retroactive` annotations to silence future-compatibility warnings.
- Changed the immutable sidebar item binding from `var` to `let`.

## Image cleanup

- Removed numeric root-level `Resources/*.png` AppIcon size exports. `Resources/AppIcon-source.png` remains and is used by Makefile to regenerate the current AppIcon asset catalog.
- Removed `Resources/Assets/extensions`, which duplicated the live `Resources/Assets/theme/extensions` PNG pack and was not loaded by current Swift sources.
- Removed `Resources/Assets/sharing`, which had no runtime references in the current app/helper target.
- Removed only top-level `theme/*.png` images not referenced by the current PNG icon loader, interface-symbol map, folder-theme selector, file-theme preview selector, or dynamic toolbar icon names.
- Kept all runtime-selected PNG packs under `theme/extensions`, `theme/colorful`, `theme/light`, `theme/folders`, and their `special` subfolders. These are selected by file extension or user preferences at runtime and must remain intact.

## Verification limits

- `swiftc -frontend -parse` is used to verify Swift syntax in this environment.
- Makefile shell syntax and resource-path checks are verified locally.
- A complete iOS arm64 typecheck/link requires Xcode 16.4 and the iOS SDK on the GitHub macOS runner; it has not been run in this container.


## Resource inventory after cleanup

- Runtime theme PNGs remaining: 734 files.
- The icon loader's 58 required top-level PNG names are present at a supported scale.
- Four selectable folder packs and three selectable file-icon packs were checked for their required PNGs.
- Removed old generated app-icon PNGs: 30.
- Removed redundant legacy extension PNGs: 247.
- Removed unused share-extension PNGs: 118.
- Removed unreferenced top-level theme PNGs: 279.
