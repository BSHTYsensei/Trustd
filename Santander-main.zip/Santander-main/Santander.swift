import AVFoundation
import AVKit
import CoreLocation
import CoreMedia
import Darwin
import Foundation
import ImageIO
import LocalAuthentication
import MapKit
import MediaPlayer
import ObjectiveC
import os
import PDFKit
import PhotosUI
import QuickLook
import UIKit
import UniformTypeIdentifiers


// MARK: - Self-contained PrivateKit / editor compatibility
//
// The original Santander project used NSAntoine/PrivateKits wrappers plus
// Runestone. Those modules are intentionally collapsed into this source file.
// Private Apple classes are resolved at runtime, while the editor surface uses
// UIKit/Foundation so no Swift Package/module is required at build time.

private enum SantanderRuntimeKit {
    static let coreUIHandle: UnsafeMutableRawPointer? = {
        let candidates = [
            "/System/Library/PrivateFrameworks/CoreUI.framework/CoreUI"
        ]
        for path in candidates where FileManager.default.fileExists(atPath: path) {
            if let handle = dlopen(path, RTLD_LAZY | RTLD_LOCAL) {
                return handle
            }
        }
        return nil
    }()

    static func method(_ receiver: AnyObject, _ selector: Selector) -> Method? {
        guard let cls = object_getClass(receiver) else { return nil }
        return class_getInstanceMethod(cls, selector)
    }

    static func object(_ receiver: AnyObject, _ selector: Selector) -> AnyObject? {
        guard let method = method(receiver, selector) else { return nil }
        typealias Fn = @convention(c) (AnyObject, Selector) -> Unmanaged<AnyObject>?
        let fn = unsafeBitCast(method_getImplementation(method), to: Fn.self)
        return fn(receiver, selector)?.takeUnretainedValue()
    }

    static func object(_ receiver: AnyObject, _ selector: Selector, _ arg: AnyObject?) -> AnyObject? {
        guard let method = method(receiver, selector) else { return nil }
        typealias Fn = @convention(c) (AnyObject, Selector, AnyObject?) -> Unmanaged<AnyObject>?
        let fn = unsafeBitCast(method_getImplementation(method), to: Fn.self)
        return fn(receiver, selector, arg)?.takeUnretainedValue()
    }

    static func object(_ receiver: AnyObject, _ selector: Selector, _ arg: AnyObject?, _ boolArg: Bool) -> AnyObject? {
        guard let method = method(receiver, selector) else { return nil }
        typealias Fn = @convention(c) (AnyObject, Selector, AnyObject?, Bool) -> Unmanaged<AnyObject>?
        let fn = unsafeBitCast(method_getImplementation(method), to: Fn.self)
        return fn(receiver, selector, arg, boolArg)?.takeUnretainedValue()
    }

    static func bool(_ receiver: AnyObject, _ selector: Selector, _ arg: AnyObject? = nil) -> Bool? {
        guard let method = method(receiver, selector) else { return nil }
        if arg == nil {
            typealias Fn = @convention(c) (AnyObject, Selector) -> Bool
            let fn = unsafeBitCast(method_getImplementation(method), to: Fn.self)
            return fn(receiver, selector)
        }
        typealias Fn = @convention(c) (AnyObject, Selector, AnyObject?) -> Bool
        let fn = unsafeBitCast(method_getImplementation(method), to: Fn.self)
        return fn(receiver, selector, arg)
    }

    static func int64(_ receiver: AnyObject, _ selector: Selector) -> Int64? {
        guard let method = method(receiver, selector) else { return nil }
        typealias Fn = @convention(c) (AnyObject, Selector) -> Int64
        let fn = unsafeBitCast(method_getImplementation(method), to: Fn.self)
        return fn(receiver, selector)
    }

    static func cgFloat(_ receiver: AnyObject, _ selector: Selector) -> CGFloat? {
        guard let method = method(receiver, selector) else { return nil }
        typealias Fn = @convention(c) (AnyObject, Selector) -> CGFloat
        let fn = unsafeBitCast(method_getImplementation(method), to: Fn.self)
        return fn(receiver, selector)
    }

    static func size(_ receiver: AnyObject, _ selector: Selector) -> CGSize? {
        guard let method = method(receiver, selector) else { return nil }
        typealias Fn = @convention(c) (AnyObject, Selector) -> CGSize
        let fn = unsafeBitCast(method_getImplementation(method), to: Fn.self)
        return fn(receiver, selector)
    }

    static func color(_ receiver: AnyObject, _ selector: Selector) -> CGColor? {
        guard let method = method(receiver, selector) else { return nil }
        typealias Fn = @convention(c) (AnyObject, Selector) -> Unmanaged<CGColor>?
        let fn = unsafeBitCast(method_getImplementation(method), to: Fn.self)
        return fn(receiver, selector)?.takeUnretainedValue()
    }

    static func image(_ receiver: AnyObject, _ selector: Selector) -> CGImage? {
        guard let method = method(receiver, selector) else { return nil }
        typealias Fn = @convention(c) (AnyObject, Selector) -> Unmanaged<CGImage>?
        let fn = unsafeBitCast(method_getImplementation(method), to: Fn.self)
        return fn(receiver, selector)?.takeUnretainedValue()
    }

    static func data(_ receiver: AnyObject, _ selector: Selector) -> Data? {
        guard let object = object(receiver, selector) else { return nil }
        if let data = object as? Data { return data }
        if let data = object as? NSData { return data as Data }
        return nil
    }

    static func block(_ receiver: AnyObject, _ selector: Selector, _ callback: @escaping (AnyObject) -> Void) {
        guard let method = method(receiver, selector) else { return }
        typealias Block = @convention(block) (AnyObject) -> Void
        let block: Block = { object in callback(object) }
        let blockObject = unsafeBitCast(block, to: AnyObject.self)
        typealias Fn = @convention(c) (AnyObject, Selector, AnyObject) -> Void
        let fn = unsafeBitCast(method_getImplementation(method), to: Fn.self)
        fn(receiver, selector, blockObject)
    }

    static func allocateAndInitialize(className: String, initializer: Selector, argument: AnyObject) -> AnyObject? {
        _ = coreUIHandle
        guard let cls = NSClassFromString(className),
              let allocated = object(cls as AnyObject, NSSelectorFromString("alloc")) else {
            return nil
        }
        return object(allocated, initializer, argument)
    }
}

final class CUIRenditionKey: Hashable, CustomStringConvertible {
    private let raw: AnyObject?
    let themeElement: Int64
    let themePart: Int64
    let themeIdiom: Int64
    let themeSubtype: Int64
    let themeDisplayGamut: Int64
    let themeAppearance: Int64

    init(raw: AnyObject?) {
        self.raw = raw

        func read(_ names: [String]) -> Int64 {
            guard let raw else { return 0 }
            for name in names {
                let selector = Selector((name))
                if let value = SantanderRuntimeKit.int64(raw, selector) {
                    return value
                }
                if let value = (raw as? NSObject)?.value(forKey: name) as? NSNumber {
                    return value.int64Value
                }
            }
            return 0
        }

        themeElement = read(["themeElement"])
        themePart = read(["themePart"])
        themeIdiom = read(["themeIdiom"])
        themeSubtype = read(["themeSubtype"])
        themeDisplayGamut = read(["themeDisplayGamut"])
        themeAppearance = read(["themeAppearance"])
    }

    func keyList() -> AnyObject? {
        guard let raw else { return nil }
        return SantanderRuntimeKit.object(raw, Selector(("keyList")))
            ?? raw
    }

    func hash(into hasher: inout Hasher) {
        hasher.combine(themeElement)
        hasher.combine(themePart)
        hasher.combine(themeIdiom)
        hasher.combine(themeSubtype)
        hasher.combine(themeDisplayGamut)
        hasher.combine(themeAppearance)
    }

    static func == (lhs: CUIRenditionKey, rhs: CUIRenditionKey) -> Bool {
        lhs.themeElement == rhs.themeElement &&
        lhs.themePart == rhs.themePart &&
        lhs.themeIdiom == rhs.themeIdiom &&
        lhs.themeSubtype == rhs.themeSubtype &&
        lhs.themeDisplayGamut == rhs.themeDisplayGamut &&
        lhs.themeAppearance == rhs.themeAppearance
    }

    var description: String {
        if let raw,
           let value = SantanderRuntimeKit.object(raw, NSSelectorFromString("description")) as? String {
            return value
        }
        return [
            themeElement, themePart, themeIdiom, themeSubtype,
            themeDisplayGamut, themeAppearance
        ].map(String.init).joined(separator: "/")
    }
}

final class CUIThemeRendition: Hashable {
    fileprivate let raw: AnyObject

    init(raw: AnyObject) {
        self.raw = raw
    }

    var classForCoder: AnyClass { type(of: raw) }

    func scale() -> CGFloat {
        SantanderRuntimeKit.cgFloat(raw, NSSelectorFromString("scale")) ?? 1.0
    }

    func unslicedSize() -> CGSize {
        SantanderRuntimeKit.size(raw, Selector(("unslicedSize"))) ?? .zero
    }

    func value(forKey key: String) -> Any? {
        let selector = Selector((key))
        if SantanderRuntimeKit.method(raw, selector) != nil {
            return SantanderRuntimeKit.object(raw, selector)
        }
        return (raw as? NSObject)?.value(forKey: key)
    }

    func data() -> Data? {
        SantanderRuntimeKit.data(raw, NSSelectorFromString("data"))
    }

    func srcData() -> Data? {
        SantanderRuntimeKit.data(raw, Selector(("srcData")))
    }

    func cgColor() -> Unmanaged<CGColor>? {
        guard let color = SantanderRuntimeKit.color(raw, Selector(("cgColor"))) else { return nil }
        return Unmanaged.passUnretained(color)
    }

    func uncroppedImage() -> Unmanaged<CGImage>? {
        guard let image = SantanderRuntimeKit.image(raw, Selector(("uncroppedImage"))) else { return nil }
        return Unmanaged.passUnretained(image)
    }

    func createImageFromPDFRendition(withScale scale: CGFloat) -> Unmanaged<CGImage>? {
        guard let data = data(),
              let provider = CGDataProvider(data: data as CFData),
              let document = CGPDFDocument(provider),
              let page = document.page(at: 1) else {
            return nil
        }

        let rect = page.getBoxRect(.mediaBox)
        let width = max(1.0, rect.width * scale)
        let height = max(1.0, rect.height * scale)
        guard let colorSpace = CGColorSpace(name: CGColorSpace.sRGB),
              let context = CGContext(
                data: nil,
                width: Int(width),
                height: Int(height),
                bitsPerComponent: 8,
                bytesPerRow: 0,
                space: colorSpace,
                bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue
              ) else {
            return nil
        }

        context.interpolationQuality = .high
        context.drawPDFPage(page)
        guard let image = context.makeImage() else { return nil }
        return Unmanaged.passRetained(image)
    }

    func name() -> String {
        SantanderRuntimeKit.object(raw, Selector(("name"))) as? String ?? ""
    }

    func key() -> CUIRenditionKey {
        CUIRenditionKey(raw: SantanderRuntimeKit.object(raw, Selector(("key"))))
    }

    static func == (lhs: CUIThemeRendition, rhs: CUIThemeRendition) -> Bool {
        lhs.raw === rhs.raw
    }

    func hash(into hasher: inout Hasher) {
        hasher.combine(ObjectIdentifier(raw))
    }
}

final class CUINamedLookup: Hashable {
    fileprivate let raw: AnyObject
    let name: String
    let renditionName: String
    let key: CUIRenditionKey
    let rendition: CUIThemeRendition

    init(raw: AnyObject) {
        self.raw = raw
        self.name = SantanderRuntimeKit.object(raw, Selector(("name"))) as? String
            ?? "Unnamed Asset"
        self.renditionName = SantanderRuntimeKit.object(raw, Selector(("renditionName"))) as? String
            ?? self.name
        self.key = CUIRenditionKey(raw: SantanderRuntimeKit.object(raw, Selector(("key"))))

        if let rendition = SantanderRuntimeKit.object(raw, Selector(("rendition"))) {
            self.rendition = CUIThemeRendition(raw: rendition)
        } else {
            self.rendition = CUIThemeRendition(raw: raw)
        }
    }

    static func == (lhs: CUINamedLookup, rhs: CUINamedLookup) -> Bool {
        lhs.name == rhs.name &&
        lhs.renditionName == rhs.renditionName &&
        lhs.key == rhs.key
    }

    func hash(into hasher: inout Hasher) {
        hasher.combine(name)
        hasher.combine(renditionName)
        hasher.combine(key)
    }
}

final class CUICatalog: NSObject {
    private let raw: AnyObject

    init(url: URL) throws {
        guard FileManager.default.fileExists(atPath: url.path) else {
            throw StringError("Asset catalog does not exist: \(url.path)")
        }

        guard let object =
                SantanderRuntimeKit.allocateAndInitialize(
                    className: "CUICatalog",
                    initializer: NSSelectorFromString("initWithURL:"),
                    argument: url as NSURL
                )
                ?? SantanderRuntimeKit.allocateAndInitialize(
                    className: "CUICatalog",
                    initializer: NSSelectorFromString("initWithContentsOfURL:"),
                    argument: url as NSURL
                ) else {
            throw StringError("CoreUI CUICatalog is unavailable on this OS.")
        }

        raw = object
        super.init()
    }

    func enumerateNamedLookups(_ block: @escaping (CUINamedLookup) -> Void) {
        SantanderRuntimeKit.block(raw, Selector(("enumerateNamedLookupsUsingBlock:"))) { object in
            block(CUINamedLookup(raw: object))
        }
    }

    func __getRenditionCollection() -> RenditionCollection {
        var grouped: [RenditionType: [Rendition]] = [:]
        enumerateNamedLookups { lookup in
            let rendition = Rendition(lookup)
            grouped[rendition.type, default: []].append(rendition)
        }

        return grouped.map { type, items in
            (
                type,
                items.sorted {
                    $0.name.localizedCaseInsensitiveCompare($1.name) == .orderedAscending
                }
            )
        }.sorted {
            $0.0.description.localizedCaseInsensitiveCompare($1.0.description) == .orderedAscending
        }
    }

    func removeItem(_ rendition: Rendition, fileURL: URL) throws {
        try SantanderAssetCatalogEditing.remove(rendition, fileURL: fileURL)
    }

    func editItem(
        _ item: Rendition,
        fileURL: URL,
        to newValue: Rendition.Representation,
        isAlphaAllowed: Bool = true
    ) throws {
        try SantanderAssetCatalogEditing.edit(
            item,
            fileURL: fileURL,
            to: newValue,
            isAlphaAllowed: isAlphaAllowed
        )
    }
}

typealias RenditionCollection = [(type: RenditionType, renditions: [Rendition])]

final class Rendition: Hashable {
    static let macCatalystSubtype: Int64 = 32401

    let cuiRend: CUIThemeRendition
    let namedLookup: CUINamedLookup
    let type: RenditionType
    let name: String

    lazy var representation: Representation? = Representation(self)
    lazy var image: CGImage? = getImage()

    init(_ namedLookup: CUINamedLookup) {
        self.cuiRend = namedLookup.rendition
        self.namedLookup = namedLookup
        self.type = RenditionType(namedLookup: namedLookup)
        self.name = type == .icon ? cuiRend.name() : namedLookup.name
    }

    private func getImage() -> CGImage? {
        if let image = cuiRend.uncroppedImage()?.takeUnretainedValue() {
            return image
        }

        if type == .pdf {
            return cuiRend.createImageFromPDFRendition(withScale: UIScreen.main.scale)?.takeUnretainedValue()
        }

        if let data = cuiRend.data(),
           let source = CGImageSourceCreateWithData(data as CFData, nil),
           let image = CGImageSourceCreateImageAtIndex(source, 0, nil) {
            return image
        }

        return nil
    }

    func makeDragItem() -> UIDragItem? {
        guard let image else { return nil }
        let uiImage = UIImage(cgImage: image)
        let provider = NSItemProvider(object: uiImage)
        let item = UIDragItem(itemProvider: provider)
        item.localObject = uiImage
        return item
    }

    static func == (lhs: Rendition, rhs: Rendition) -> Bool {
        lhs.name == rhs.name && lhs.type == rhs.type && lhs.namedLookup == rhs.namedLookup && lhs.cuiRend == rhs.cuiRend
    }

    func hash(into hasher: inout Hasher) {
        hasher.combine(name)
        hasher.combine(type)
        hasher.combine(namedLookup)
        hasher.combine(cuiRend)
    }

    enum Idiom: CustomStringConvertible {
        case universal, iphone, ipad, tv, watch, carPlay, macCatalyst, marketing

        init?(_ key: CUIRenditionKey) {
            if key.themeSubtype == Rendition.macCatalystSubtype {
                self = .macCatalyst
                return
            }
            switch key.themeIdiom {
            case 0: self = .universal
            case 1: self = .iphone
            case 2: self = .ipad
            case 3: self = .tv
            case 4: self = .carPlay
            case 5: self = .watch
            case 6: self = .marketing
            default: return nil
            }
        }

        var description: String {
            switch self {
            case .universal: return "Universal"
            case .iphone: return "iPhone"
            case .ipad: return "iPad"
            case .tv: return "TV"
            case .watch: return "Watch"
            case .carPlay: return "CarPlay"
            case .macCatalyst: return "Mac Catalyst"
            case .marketing: return "Marketing"
            }
        }
    }

    enum DisplayGamut: Int64, Hashable, CustomStringConvertible {
        case sRGB = 0
        case p3 = 1
        init?(_ key: CUIRenditionKey) { self.init(rawValue: key.themeDisplayGamut) }
        var description: String {
            switch self {
            case .sRGB: return "SRGB"
            case .p3: return "Display P3"
            }
        }
    }

    enum Appearance: Int64, CustomStringConvertible {
        case any = 0
        case dark = 1
        case highContrast = 2
        case highConstrastDark = 3
        case light = 4
        case highConstrastLight = 5

        init?(_ key: CUIRenditionKey) { self.init(rawValue: key.themeAppearance) }

        var description: String {
            switch self {
            case .any: return "Any"
            case .dark: return "Dark"
            case .highContrast: return "High Contrast"
            case .highConstrastDark: return "High Contrast Dark"
            case .light: return "Light"
            case .highConstrastLight: return "High Contrast Light"
            }
        }
    }

    enum Representation: Hashable {
        case color(CGColor)
        case image(CGImage)
        case rawData(Data)

        var uiView: UIView {
            switch self {
            case .color(let color):
                let view = UIView()
                view.backgroundColor = UIColor(cgColor: color)
                return view
            case .image(let image):
                let view = UIImageView(image: UIImage(cgImage: image))
                view.clipsToBounds = true
                view.contentMode = .scaleAspectFit
                return view
        case .rawData:
                return UIView()
            }
        }

        init?(_ rendition: Rendition) {
            if let color = rendition.cuiRend.cgColor()?.takeUnretainedValue() {
                self = .color(color)
            } else if let image = rendition.image {
                self = .image(image)
            } else if let data = rendition.cuiRend.data() {
                self = .rawData(data)
            } else {
                return nil
            }
        }
    }
}

enum RenditionType: Int, Codable, Hashable, CustomStringConvertible, CaseIterable {
    case image, icon, imageSet, multiSizeImageSet, pdf, color, svg, rawData, unknown

    init(namedLookup: CUINamedLookup) {
        let className = NSStringFromClass(namedLookup.rendition.classForCoder)
        switch className {
        case "_CUIRawPixelRendition":
            self = .image
        case "_CUIThemePixelRendition", "_CUIInternalLinkRendition":
            let key = namedLookup.key
            if key.themeElement == 85 && key.themePart == 220 {
                self = .icon
            } else if key.themeElement == 9 {
                self = .imageSet
            } else {
                self = .image
            }
        case "_CUIThemePDFRendition":
            self = .pdf
        case "_CUIThemeColorRendition":
            self = .color
        case "_CUIThemeSVGRendition":
            self = .svg
        case "_CUIThemeMultisizeImageSetRendition":
            self = .multiSizeImageSet
        case "_CUIRawDataRendition":
            self = .rawData
        default:
            self = .unknown
        }
    }

    var description: String {
        switch self {
        case .image: return "Image"
        case .icon: return "Icon"
        case .imageSet: return "Image Set"
        case .multiSizeImageSet: return "Multisize Image Set"
        case .pdf: return "PDF"
        case .color: return "Color"
        case .svg: return "SVG (Vector)"
        case .rawData: return "Raw Data"
        case .unknown: return "Unknown"
        }
    }

    var isEditable: Bool {
        switch self {
        case .image, .icon, .color: return true
        default: return false
        }
    }
}

final class AssetCatalogWrapper {
    static let shared = AssetCatalogWrapper()

    func renditions(forCarArchive url: URL) throws -> (CUICatalog, RenditionCollection) {
        let catalog = try CUICatalog(url: url)
        return (catalog, catalog.__getRenditionCollection())
    }
}

struct CodableRendition {
    let renditionName: String
    let itemData: Data?
}

extension Array where Element == Rendition {
    func toCodable() -> [CodableRendition] {
        map { rendition in
            let data = rendition.cuiRend.srcData()
                ?? rendition.cuiRend.data()
                ?? rendition.image.flatMap { UIImage(cgImage: $0).pngData() }
            return CodableRendition(renditionName: rendition.name, itemData: data)
        }
    }
}

// Best-effort CoreUI editor bridge. Reads stay functional even when write
// selectors differ between iOS releases; unsupported mutations return a
// descriptive error rather than crashing or silently damaging a .car file.
private enum SantanderAssetCatalogEditing {
    private static func storage(for fileURL: URL) -> AnyObject? {
        _ = SantanderRuntimeKit.coreUIHandle
        guard let cls = NSClassFromString("CUIMutableCommonAssetStorage"),
              let allocated = SantanderRuntimeKit.object(cls as AnyObject, NSSelectorFromString("alloc")) else {
            return nil
        }

        return SantanderRuntimeKit.object(
            allocated,
            Selector(("initWithPath:forWriting:")),
            fileURL.path as NSString,
            true
        )
    }

    static func remove(_ rendition: Rendition, fileURL: URL) throws {
        guard let storage = storage(for: fileURL) else {
            throw StringError("CoreUI asset writing is unavailable on this iOS version.")
        }
        let key = rendition.cuiRend.key().keyList() as AnyObject
        let selector = Selector(("removeAssetForKey:"))
        guard let method = SantanderRuntimeKit.method(storage, selector) else {
            throw StringError("CoreUI removeAssetForKey: is unavailable.")
        }

        typealias Fn = @convention(c) (AnyObject, Selector, AnyObject) -> Bool
        let fn = unsafeBitCast(method_getImplementation(method), to: Fn.self)
        guard fn(storage, selector, key) else {
            throw StringError("CoreUI failed to remove \(rendition.name).")
        }

        try flush(storage, fileURL: fileURL)
    }

    static func edit(
        _ item: Rendition,
        fileURL: URL,
        to newValue: Rendition.Representation,
        isAlphaAllowed: Bool
    ) throws {
        guard let storage = storage(for: fileURL) else {
            throw StringError("CoreUI asset writing is unavailable on this iOS version.")
        }
        let key = item.cuiRend.key().keyList() as AnyObject
        let selector = Selector(("setAsset:forKey:"))
        guard let method = SantanderRuntimeKit.method(storage, selector) else {
            throw StringError("CoreUI setAsset:forKey: is unavailable.")
        }

        switch newValue {
        case .color(let color):
            let asset = isAlphaAllowed ? color : UIColor(cgColor: color).withAlphaComponent(1).cgColor
            typealias Fn = @convention(c) (AnyObject, Selector, AnyObject, AnyObject) -> Bool
            let fn = unsafeBitCast(method_getImplementation(method), to: Fn.self)
            guard fn(storage, selector, asset, key) else {
                throw StringError("CoreUI failed to write \(item.name).")
            }
            try flush(storage, fileURL: fileURL)
        case .image(let image):
            let asset = image as AnyObject
            typealias Fn = @convention(c) (AnyObject, Selector, AnyObject, AnyObject) -> Bool
            let fn = unsafeBitCast(method_getImplementation(method), to: Fn.self)
            guard fn(storage, selector, asset, key) else {
                throw StringError("CoreUI failed to write \(item.name).")
            }
            try flush(storage, fileURL: fileURL)
        case .rawData(let data):
            let asset = data as NSData
            typealias Fn = @convention(c) (AnyObject, Selector, AnyObject, AnyObject) -> Bool
            let fn = unsafeBitCast(method_getImplementation(method), to: Fn.self)
            guard fn(storage, selector, asset, key) else {
                throw StringError("CoreUI failed to write raw data for \(item.name).")
            }
            try flush(storage, fileURL: fileURL)
        }
    }

    private static func flush(_ storage: AnyObject, fileURL: URL) throws {
        if SantanderRuntimeKit.method(storage, NSSelectorFromString("writeToPath:")) != nil {
            guard SantanderRuntimeKit.bool(storage, NSSelectorFromString("writeToPath:"), fileURL.path as NSString) == true else {
                throw StringError("CoreUI failed to save the asset catalog.")
            }
            return
        }
        if SantanderRuntimeKit.method(storage, NSSelectorFromString("writeToURL:")) != nil {
            guard SantanderRuntimeKit.bool(storage, NSSelectorFromString("writeToURL:"), fileURL as NSURL) == true else {
                throw StringError("CoreUI failed to save the asset catalog.")
            }
            return
        }
        if SantanderRuntimeKit.method(storage, Selector(("write"))) != nil {
            _ = SantanderRuntimeKit.object(storage, Selector(("write")))
            return
        }
        throw StringError("CoreUI storage does not expose a writable catalog method.")
    }
}

// MARK: - In-file compression compatibility

struct ArchiveOptions: OptionSet {
    var rawValue: Int32
    init(rawValue: Int32) { self.rawValue = rawValue }

    static let restoreOwner = ArchiveOptions(rawValue: 1 << 0)
    static let restorePermissions = ArchiveOptions(rawValue: 1 << 1)
    static let restoreTime = ArchiveOptions(rawValue: 1 << 2)
    static let dontOverwite = ArchiveOptions(rawValue: 1 << 3)
    static let unlink = ArchiveOptions(rawValue: 1 << 4)
    static let restoreACLs = ArchiveOptions(rawValue: 1 << 5)
    static let restoreFFLags = ArchiveOptions(rawValue: 1 << 6)
    static let restoreXattrs = ArchiveOptions(rawValue: 1 << 7)
    static let secureSymlinks = ArchiveOptions(rawValue: 1 << 8)
    static let secureNoDotDot = ArchiveOptions(rawValue: 1 << 9)
    static let dontCreateParentDirs = ArchiveOptions(rawValue: 1 << 10)
    static let sparse = ArchiveOptions(rawValue: 1 << 11)
    static let includeMacOSMetadata = ArchiveOptions(rawValue: 1 << 12)
    static let dontUseHFSCompression = ArchiveOptions(rawValue: 1 << 13)
    static let forceUseHFSCompression = ArchiveOptions(rawValue: 1 << 14)
    static let rejectAbsolutePaths = ArchiveOptions(rawValue: 1 << 15)
}

final class Compression {
    enum FormatType: CaseIterable, CustomStringConvertible {
        case zip
        case tar

        var fileExtension: String {
            switch self {
            case .zip: return "zip"
            case .tar: return "tar"
            }
        }

        var description: String {
            switch self {
            case .zip: return "Zip"
            case .tar: return "Tar"
            }
        }
    }

    static let shared = Compression()
    private init() {}

    func compress(
        paths: [URL],
        outputPath: URL,
        format: FormatType,
        progress: ((URL) -> Void)? = nil
    ) throws {
        guard !paths.isEmpty else {
            throw StringError("No input paths were supplied.")
        }

        try FileManager.default.createDirectory(
            at: outputPath.deletingLastPathComponent(),
            withIntermediateDirectories: true
        )

        switch format {
        case .zip:
            let result = try SantanderProcessRunner.run(
                "/usr/bin/zip",
                ["-qry", outputPath.path] + paths.map(\.path)
            )
            guard result.status == 0 else {
                throw StringError("zip failed: \(result.stderr)")
            }
        case .tar:
            let result = try SantanderProcessRunner.run(
                "/usr/bin/tar",
                ["-cf", outputPath.path] + paths.map(\.path)
            )
            guard result.status == 0 else {
                throw StringError("tar failed: \(result.stderr)")
            }
        }

        for path in paths {
            progress?(path)
        }
    }

    func extract(
        path compressedFile: URL,
        to destination: URL,
        options: ArchiveOptions = [.restoreTime, .restorePermissions, .restoreACLs, .restoreFFLags]
    ) throws {
        try FileManager.default.createDirectory(at: destination, withIntermediateDirectories: true)

        let lower = compressedFile.path.lowercased()
        if lower.hasSuffix(".zip") {
            let result = try SantanderProcessRunner.run(
                "/usr/bin/unzip",
                ["-o", compressedFile.path, "-d", destination.path]
            )
            guard result.status == 0 else {
                throw StringError("unzip failed: \(result.stderr)")
            }
            return
        }

        let result = try SantanderProcessRunner.run(
            "/usr/bin/tar",
            ["-xf", compressedFile.path, "-C", destination.path]
        )
        guard result.status == 0 else {
            throw StringError("tar failed: \(result.stderr)")
        }

        _ = options
    }
}

// MARK: - In-file NSTask compatibility

final class NSTask: NSObject {
    var executableURL: URL?
    var arguments: [String] = []
    var standardOutput: Any?
    var standardError: Any?
    private(set) var processIdentifier: pid_t = 0
    private(set) var terminationStatus: Int32 = 0
    private(set) var isRunning = false

    func launchAndReturnError() throws {
        guard let executableURL else {
            throw StringError("Executable URL is missing.")
        }

        var actions: posix_spawn_file_actions_t?
        guard posix_spawn_file_actions_init(&actions) == 0 else {
            throw StringError("Unable to initialize process actions.")
        }
        defer { _ = posix_spawn_file_actions_destroy(&actions) }

        var stdoutPipe: Pipe?
        var stderrPipe: Pipe?

        func addStream(_ stream: Any?, fd: Int32, pipeStore: inout Pipe?) throws {
            guard let pipe = stream as? Pipe else { return }
            pipeStore = pipe
            let childFD = pipe.fileHandleForWriting.fileDescriptor
            guard posix_spawn_file_actions_adddup2(&actions, childFD, fd) == 0 else {
                throw StringError("Unable to attach process output pipe.")
            }
        }

        try addStream(standardOutput, fd: STDOUT_FILENO, pipeStore: &stdoutPipe)
        try addStream(standardError, fd: STDERR_FILENO, pipeStore: &stderrPipe)

        var argv = [strdup(executableURL.path)]
        argv.append(contentsOf: arguments.map { strdup($0) })
        argv.append(nil)
        defer { for pointer in argv.compactMap({ $0 }) { free(pointer) } }

        var pid: pid_t = 0
        let result = argv.withUnsafeMutableBufferPointer { buffer in
            posix_spawn(&pid, executableURL.path, &actions, nil, buffer.baseAddress, environ)
        }
        guard result == 0 else {
            throw NSError(
                domain: NSPOSIXErrorDomain,
                code: Int(result),
                userInfo: [NSLocalizedDescriptionKey: String(cString: strerror(result))]
            )
        }

        processIdentifier = pid
        isRunning = true

        // Close the parent's write handles. The child owns its duplicated
        // descriptors; this allows the read side to observe EOF normally.
        stdoutPipe?.fileHandleForWriting.closeFile()
        stderrPipe?.fileHandleForWriting.closeFile()

        // Keep strong references until waitUntilExit() returns.
        _ = stdoutPipe
        _ = stderrPipe
    }

    func waitUntilExit() {
        guard processIdentifier > 0 else { return }
        var status: Int32 = 0
        _ = waitpid(processIdentifier, &status, 0)
        terminationStatus = status
        isRunning = false
    }

    func interrupt() {
        guard processIdentifier > 0, isRunning else { return }
        _ = kill(processIdentifier, SIGINT)
    }
}

private struct SantanderProcessResult {
    let status: Int32
    let stdout: String
    let stderr: String
}

private enum SantanderProcessRunner {
    static func run(_ executable: String, _ arguments: [String]) throws -> SantanderProcessResult {
        var stdoutPipe = [Int32](repeating: 0, count: 2)
        var stderrPipe = [Int32](repeating: 0, count: 2)
        guard pipe(&stdoutPipe) == 0 else {
            throw StringError("Unable to create stdout pipe.")
        }
        guard pipe(&stderrPipe) == 0 else {
            _ = close(stdoutPipe[0]); _ = close(stdoutPipe[1])
            throw StringError("Unable to create stderr pipe.")
        }

        var actions: posix_spawn_file_actions_t?
        guard posix_spawn_file_actions_init(&actions) == 0 else {
            _ = close(stdoutPipe[0]); _ = close(stdoutPipe[1])
            _ = close(stderrPipe[0]); _ = close(stderrPipe[1])
            throw StringError("Unable to initialize process actions.")
        }
        defer { _ = posix_spawn_file_actions_destroy(&actions) }

        _ = posix_spawn_file_actions_adddup2(&actions, stdoutPipe[1], STDOUT_FILENO)
        _ = posix_spawn_file_actions_adddup2(&actions, stderrPipe[1], STDERR_FILENO)
        _ = posix_spawn_file_actions_addclose(&actions, stdoutPipe[0])
        _ = posix_spawn_file_actions_addclose(&actions, stderrPipe[0])

        var argv = [strdup(executable)]
        argv.append(contentsOf: arguments.map { strdup($0) })
        argv.append(nil)
        defer { for pointer in argv.compactMap({ $0 }) { free(pointer) } }

        var pid: pid_t = 0
        let result = argv.withUnsafeMutableBufferPointer { buffer in
            posix_spawn(&pid, executable, &actions, nil, buffer.baseAddress, environ)
        }

        _ = close(stdoutPipe[1])
        _ = close(stderrPipe[1])

        guard result == 0 else {
            _ = close(stdoutPipe[0]); _ = close(stderrPipe[0])
            throw NSError(
                domain: NSPOSIXErrorDomain,
                code: Int(result),
                userInfo: [NSLocalizedDescriptionKey: String(cString: strerror(result))]
            )
        }

        let group = DispatchGroup()
        var stdoutData = Data()
        var stderrData = Data()

        func readAll(_ fd: Int32) -> Data {
            var data = Data()
            var buffer = [UInt8](repeating: 0, count: 16 * 1024)
            while true {
                let count = buffer.withUnsafeMutableBytes { rawBuffer -> Int in
                    guard let baseAddress = rawBuffer.baseAddress else { return 0 }
                    return read(fd, baseAddress, rawBuffer.count)
                }
                if count <= 0 { break }
                data.append(buffer, count: count)
            }
            return data
        }

        group.enter()
        DispatchQueue.global(qos: .utility).async {
            stdoutData = readAll(stdoutPipe[0])
            _ = close(stdoutPipe[0])
            group.leave()
        }

        group.enter()
        DispatchQueue.global(qos: .utility).async {
            stderrData = readAll(stderrPipe[0])
            _ = close(stderrPipe[0])
            group.leave()
        }

        var status: Int32 = 0
        _ = waitpid(pid, &status, 0)
        group.wait()

        return SantanderProcessResult(
            status: status,
            stdout: String(data: stdoutData, encoding: .utf8) ?? "",
            stderr: String(data: stderrData, encoding: .utf8) ?? ""
        )
    }
}

// MARK: - In-file Runestone-compatible search/editor surface

protocol CharacterPair {
    var leading: String { get }
    var trailing: String { get }
}

class Theme {}

struct TextViewState {
    let text: String
    let theme: AnyTheme
}

struct HighlightedRange {
    let range: NSRange
    let color: UIColor
}

struct SearchResult {
    let range: NSRange
}

struct SearchQuery {
    enum MatchMethod {
        case startsWith, endsWith, contains, fullWord, regularExpression
    }

    let text: String
    let matchMethod: MatchMethod
    let isCaseSensitive: Bool

    init(text: String, matchMethod: MatchMethod, isCaseSensitive: Bool) {
        self.text = text
        self.matchMethod = matchMethod
        self.isCaseSensitive = isCaseSensitive
    }

    func ranges(in source: String) -> [NSRange] {
        guard !text.isEmpty else { return [] }

        let nsSource = source as NSString
        let range = NSRange(location: 0, length: nsSource.length)
        let options: NSRegularExpression.Options = isCaseSensitive ? [] : [.caseInsensitive]

        if matchMethod == .regularExpression,
           let regex = try? NSRegularExpression(pattern: text, options: options) {
            return regex.matches(in: source, range: range).map(\.range)
        }

        let comparisonOptions: NSString.CompareOptions = isCaseSensitive ? [] : [.caseInsensitive]
        var result: [NSRange] = []
        var cursor = 0

        while cursor < nsSource.length {
            let found = nsSource.range(
                of: text,
                options: comparisonOptions,
                range: NSRange(location: cursor, length: nsSource.length - cursor)
            )
            guard found.location != NSNotFound else { break }

            func isBoundary(_ index: Int) -> Bool {
                if index <= 0 || index >= nsSource.length { return true }
                let left = nsSource.substring(with: NSRange(location: index - 1, length: 1))
                let right = nsSource.substring(with: NSRange(location: index, length: 1))
                let wordSet = CharacterSet.alphanumerics.union(.letters).union(.decimalDigits)
                let leftIsWord = left.rangeOfCharacter(from: wordSet) != nil
                let rightIsWord = right.rangeOfCharacter(from: wordSet) != nil
                return !(leftIsWord && rightIsWord)
            }

            let accepted: Bool
            switch matchMethod {
            case .contains:
                accepted = true
            case .startsWith:
                accepted = found.location == 0 || isBoundary(found.location)
            case .endsWith:
                accepted = NSMaxRange(found) == nsSource.length || isBoundary(NSMaxRange(found))
            case .fullWord:
                accepted = isBoundary(found.location) && isBoundary(NSMaxRange(found))
            case .regularExpression:
                accepted = true
            }

            if accepted {
                result.append(found)
            }

            cursor = max(NSMaxRange(found), cursor + 1)
        }

        return result
    }
}

final class TextView: UITextView, UITextViewDelegate {
    weak var editorDelegate: TextViewDelegate?
    var characterPairs: [CharacterPair] = []
    var showLineNumbers: Bool = false
    var isLineWrappingEnabled: Bool = true {
        didSet {
            textContainer.lineBreakMode = isLineWrappingEnabled ? .byWordWrapping : .byClipping
            textContainer.widthTracksTextView = isLineWrappingEnabled
        }
    }

    var highlightedRanges: [HighlightedRange] = [] {
        didSet { updateHighlightedRanges() }
    }

    override init(frame: CGRect, textContainer: NSTextContainer? = nil) {
        super.init(frame: frame, textContainer: textContainer)
        commonInit()
    }

    convenience init() {
        self.init(frame: .zero, textContainer: nil)
    }

    required init?(coder: NSCoder) {
        super.init(coder: coder)
        commonInit()
    }

    private func commonInit() {
        delegate = self
        font = .monospacedSystemFont(ofSize: 16, weight: .regular)
        autocorrectionType = .no
        autocapitalizationType = .none
        smartQuotesType = .no
        smartDashesType = .no
        backgroundColor = .clear
    }

    func setState(_ state: TextViewState) {
        let editable = isEditable
        isEditable = false
        text = state.text
        font = state.theme.font
        textColor = state.theme.textColor
        isEditable = editable
        textContainer.lineBreakMode = isLineWrappingEnabled ? .byWordWrapping : .byClipping
        textContainer.widthTracksTextView = isLineWrappingEnabled
        updateHighlightedRanges()
    }

    func goToLine(_ zeroBasedLine: Int) {
        let target = max(0, zeroBasedLine)
        let textString = text as NSString
        var line = 0
        var location = 0

        while line < target, location < textString.length {
            let newline = textString.range(
                of: "\n",
                options: [],
                range: NSRange(location: location, length: textString.length - location)
            )
            guard newline.location != NSNotFound else { break }
            location = NSMaxRange(newline)
            line += 1
        }

        selectedRange = NSRange(location: min(location, textString.length), length: 0)
        scrollRangeToVisible(selectedRange)
    }

    func search(for query: SearchQuery) -> [SearchResult] {
        query.ranges(in: text).map(SearchResult.init(range:))
    }

    func shiftLeft() {
        guard selectedRange.length > 0 else { return }
        let range = selectedRange
        let mutable = NSMutableString(string: text)
        mutable.replaceCharacters(in: range, with: "")
        text = mutable as String
        selectedRange = NSRange(location: range.location, length: 0)
    }

    func shiftRight() {
        guard selectedRange.length > 0 else { return }
        let range = selectedRange
        let mutable = NSMutableString(string: text)
        let selected = (text as NSString).substring(with: range)
        mutable.replaceCharacters(in: range, with: "    " + selected)
        text = mutable as String
        selectedRange = NSRange(location: range.location + 4, length: range.length)
    }

    private func updateHighlightedRanges() {
        guard !highlightedRanges.isEmpty else { return }
        let mutable = NSMutableAttributedString(string: text)
        mutable.addAttribute(.font, value: font ?? UIFont.monospacedSystemFont(ofSize: 16, weight: .regular),
                              range: NSRange(location: 0, length: mutable.length))
        for item in highlightedRanges where NSMaxRange(item.range) <= mutable.length {
            mutable.addAttribute(.backgroundColor, value: item.color, range: item.range)
        }
        let currentSelection = selectedRange
        attributedText = mutable
        selectedRange = NSRange(location: min(currentSelection.location, mutable.length), length: 0)
    }

    func textViewShouldBeginEditing(_ textView: UITextView) -> Bool {
        editorDelegate?.textViewShouldBeginEditing?(self) ?? true
    }

    func textViewShouldEndEditing(_ textView: UITextView) -> Bool {
        editorDelegate?.textViewShouldEndEditing?(self) ?? true
    }

    func textView(
        _ textView: UITextView,
        shouldChangeTextIn range: NSRange,
        replacementText text: String
    ) -> Bool {
        guard range.length == 0, text.count == 1, !characterPairs.isEmpty else {
            return true
        }

        guard let pair = characterPairs.first(where: { $0.leading == text }) else {
            return true
        }

        let insertionLocation = range.location
        let mutable = NSMutableString(string: self.text)
        mutable.insert(text + pair.trailing, at: insertionLocation)
        self.text = mutable as String
        selectedRange = NSRange(location: insertionLocation + text.utf16.count, length: 0)
        editorDelegate?.textViewDidChange(self)
        return false
    }

    func textViewDidChange(_ textView: UITextView) {
        editorDelegate?.textViewDidChange(self)
    }
}

@objc protocol TextViewDelegate: AnyObject {
    @objc optional func textViewShouldBeginEditing(_ textView: TextView) -> Bool
    @objc optional func textViewShouldEndEditing(_ textView: TextView) -> Bool
    func textViewDidChange(_ textView: TextView)
}

// MARK: - Applications compatibility layer
// ApplicationsWrapper is not part of the current build. Santander only needs a
// small subset of LaunchServices functionality, so keep the wrapper in-process
// and resolve the private objects/methods at runtime.
private enum SantanderObjCRuntime {
    // Make sure LaunchServices classes are present before querying them through Objective-C runtime.
    static let launchServicesHandle: UnsafeMutableRawPointer? = {
        let candidates = [
            "/System/Library/PrivateFrameworks/LaunchServices.framework/LaunchServices",
            "/System/Library/PrivateFrameworks/MobileCoreServices.framework/MobileCoreServices",
            "/System/Library/Frameworks/MobileCoreServices.framework/MobileCoreServices",
            "/System/Library/Frameworks/CoreServices.framework/CoreServices"
        ]

        for path in candidates where FileManager.default.fileExists(atPath: path) {
            if let handle = dlopen(path, RTLD_LAZY) {
                return handle
            }
        }
        return nil
    }()

    static func sendObject(
        to receiver: AnyObject,
        selector: Selector,
        argument: AnyObject? = nil
    ) -> AnyObject? {
        _ = launchServicesHandle
        guard let method = object_getClass(receiver).flatMap({ class_getInstanceMethod($0, selector) }) else {
            return nil
        }

        typealias Message = @convention(c) (AnyObject, Selector, AnyObject?) -> Unmanaged<AnyObject>?
        let function = unsafeBitCast(method_getImplementation(method), to: Message.self)
        return function(receiver, selector, argument)?.takeUnretainedValue()
    }

    static func sendObject(
        to receiver: AnyObject,
        selector: Selector
    ) -> AnyObject? {
        _ = launchServicesHandle
        guard let method = object_getClass(receiver).flatMap({ class_getInstanceMethod($0, selector) }) else {
            return nil
        }

        typealias Message = @convention(c) (AnyObject, Selector) -> Unmanaged<AnyObject>?
        let function = unsafeBitCast(method_getImplementation(method), to: Message.self)
        return function(receiver, selector)?.takeUnretainedValue()
    }

    static func sendObject(
        to receiver: AnyObject,
        selector: Selector,
        intArgument: Int32
    ) -> AnyObject? {
        _ = launchServicesHandle
        guard let method = object_getClass(receiver).flatMap({ class_getInstanceMethod($0, selector) }) else {
            return nil
        }

        typealias Message = @convention(c) (AnyObject, Selector, Int32) -> Unmanaged<AnyObject>?
        let function = unsafeBitCast(method_getImplementation(method), to: Message.self)
        return function(receiver, selector, intArgument)?.takeUnretainedValue()
    }

    static func sendBool(
        to receiver: AnyObject,
        selector: Selector,
        argument: AnyObject?
    ) -> Bool? {
        _ = launchServicesHandle
        guard let method = object_getClass(receiver).flatMap({ class_getInstanceMethod($0, selector) }) else {
            return nil
        }

        typealias Message = @convention(c) (AnyObject, Selector, AnyObject?) -> Bool
        let function = unsafeBitCast(method_getImplementation(method), to: Message.self)
        return function(receiver, selector, argument)
    }

    static func sendBool(
        to receiver: AnyObject,
        selector: Selector,
        firstArgument: AnyObject?,
        secondArgument: AnyObject?
    ) -> Bool? {
        _ = launchServicesHandle
        guard let method = object_getClass(receiver).flatMap({ class_getInstanceMethod($0, selector) }) else {
            return nil
        }

        typealias Message = @convention(c) (AnyObject, Selector, AnyObject?, AnyObject?) -> Bool
        let function = unsafeBitCast(method_getImplementation(method), to: Message.self)
        return function(receiver, selector, firstArgument, secondArgument)
    }
}

final class SantanderApplication {
    fileprivate let object: AnyObject

    init?(object: AnyObject) {
        guard object_isClass(object) == false else { return nil }
        self.object = object
    }

    var applicationIdentifier: String {
        stringValue(for: "applicationIdentifier") ?? stringValue(for: "bundleIdentifier") ?? ""
    }

    var localizedName: String {
        stringValue(for: "localizedName")
            ?? (SantanderObjCRuntime.sendObject(
                to: object,
                selector: Selector(("localizedNameForContext:")),
                argument: nil
            ) as? String)
            ?? applicationIdentifier
    }

    var applicationType: String? { stringValue(for: "applicationType") }
    var sdkVersion: String? { stringValue(for: "sdkVersion") }
    var teamID: String? { stringValue(for: "teamID") }

    var claimedURLSchemes: [String] {
        let selector = Selector(("claimedURLSchemes"))
        guard let value = SantanderObjCRuntime.sendObject(to: object, selector: selector) else {
            return []
        }

        if let array = value as? [String] { return array }
        if let set = value as? Set<String> { return Array(set) }
        if let nsArray = value as? NSArray { return nsArray.compactMap { $0 as? String } }
        if let nsSet = value as? NSSet { return nsSet.allObjects.compactMap { $0 as? String } }
        return []
    }

    var isDeletable: Bool { boolValue(for: "isDeletable") }
    var isBetaApp: Bool { boolValue(for: "isBetaApp") }
    var isRestricted: Bool { boolValue(for: "isRestricted") }
    var isContainerized: Bool { boolValue(for: "isContainerized") }

    func bundleURL() -> URL {
        urlValue(for: "bundleURL") ?? URL(fileURLWithPath: "")
    }

    func containerURL() -> URL {
        urlValue(for: "containerURL") ?? URL(fileURLWithPath: "")
    }

    func dataContainerURL() -> URL {
        urlValue(for: "dataContainerURL") ?? URL(fileURLWithPath: "")
    }

    var entitlements: [String: Any] {
        let selectorNames = ["entitlements", "_entitlements"]
        for name in selectorNames {
            guard let value = SantanderObjCRuntime.sendObject(to: object, selector: Selector((name))) else {
                continue
            }
            if let dictionary = value as? [String: Any] { return dictionary }
            if let dictionary = value as? NSDictionary {
                return dictionary.reduce(into: [String: Any]()) { partialResult, element in
                    if let key = element.key as? String { partialResult[key] = element.value }
                }
            }
        }
        return [:]
    }

    private func stringValue(for selectorName: String) -> String? {
        SantanderObjCRuntime.sendObject(to: object, selector: Selector((selectorName))) as? String
    }

    private func urlValue(for selectorName: String) -> URL? {
        guard let value = SantanderObjCRuntime.sendObject(to: object, selector: Selector((selectorName))) else {
            return nil
        }
        if let url = value as? URL { return url }
        if let url = value as? NSURL { return url as URL }
        return nil
    }

    private func boolValue(for selectorName: String) -> Bool {
        guard let method = object_getClass(object).flatMap({ class_getInstanceMethod($0, Selector((selectorName))) }) else {
            return false
        }
        typealias Message = @convention(c) (AnyObject, Selector) -> Bool
        let function = unsafeBitCast(method_getImplementation(method), to: Message.self)
        return function(object, Selector((selectorName)))
    }
}

private final class ApplicationsManager {
    static let shared = ApplicationsManager()

    private let cacheLock = NSLock()
    private var applicationsCache: [SantanderApplication] = []
    private var applicationsCacheDate = Date.distantPast
    private let cacheLifetime: TimeInterval = 2.0

    private init() {}

    func application(forBundleURL url: URL) -> SantanderApplication? {
        let proxyClass = NSClassFromString("LSApplicationProxy") as AnyObject?
        if let proxyClass,
           let object = SantanderObjCRuntime.sendObject(
                to: proxyClass,
                selector: Selector(("applicationProxyForBundleURL:")),
                argument: url as NSURL
           ),
           let app = SantanderApplication(object: object) {
            return app
        }

        return findApplication { Self.normalizedPath($0.bundleURL()) == Self.normalizedPath(url) }
    }

    func application(forContainerURL url: URL) -> SantanderApplication? {
        findApplication { Self.normalizedPath($0.containerURL()) == Self.normalizedPath(url) }
    }

    func application(forDataContainerURL url: URL) -> SantanderApplication? {
        findApplication { Self.normalizedPath($0.dataContainerURL()) == Self.normalizedPath(url) }
    }

    func icon(forApplication app: SantanderApplication) -> UIImage? {
        let selector = Selector(("iconDataForVariant:"))
        for variant in [2, 1, 0] {
            guard let dataObject = SantanderObjCRuntime.sendObject(
                to: app.object,
                selector: selector,
                intArgument: Int32(variant)
            ),
            let data = dataObject as? NSData,
            let image = UIImage(data: data as Data) else {
                continue
            }
            return image
        }
        return nil
    }

    func openApp(_ app: SantanderApplication) throws {
        guard let workspace = defaultWorkspace() else {
            throw Self.error("LSApplicationWorkspace is unavailable")
        }

        let selector = Selector(("openApplicationWithBundleID:"))
        guard let result = SantanderObjCRuntime.sendBool(
            to: workspace,
            selector: selector,
            argument: app.applicationIdentifier as NSString
        ) else {
            throw Self.error("LaunchServices does not expose openApplicationWithBundleID:")
        }
        guard result else {
            throw Self.error("LaunchServices failed to open \(app.applicationIdentifier)")
        }
    }

    func deleteApp(_ app: SantanderApplication) throws {
        guard let workspace = defaultWorkspace() else {
            throw Self.error("LSApplicationWorkspace is unavailable")
        }

        let selector = Selector(("uninstallApplication:withOptions:"))
        guard let result = SantanderObjCRuntime.sendBool(
            to: workspace,
            selector: selector,
            firstArgument: app.applicationIdentifier as NSString,
            secondArgument: nil
        ) else {
            throw Self.error("LaunchServices does not expose uninstallApplication:withOptions:")
        }
        guard result else {
            throw Self.error("LaunchServices failed to delete \(app.applicationIdentifier)")
        }
        invalidateCache()
    }

    func reload() {
        invalidateCache()
    }

    private func defaultWorkspace() -> AnyObject? {
        guard let workspaceClass = NSClassFromString("LSApplicationWorkspace") as AnyObject? else {
            return nil
        }
        return SantanderObjCRuntime.sendObject(to: workspaceClass, selector: Selector(("defaultWorkspace")))
    }

    private func allInstalledApplications() -> [SantanderApplication] {
        cacheLock.lock()
        let cached = applicationsCache
        let age = Date().timeIntervalSince(applicationsCacheDate)
        cacheLock.unlock()

        if !cached.isEmpty, age < cacheLifetime {
            return cached
        }

        guard let workspace = defaultWorkspace() else {
            return cached
        }

        let raw = SantanderObjCRuntime.sendObject(to: workspace, selector: Selector(("allInstalledApplications")))
            ?? SantanderObjCRuntime.sendObject(to: workspace, selector: Selector(("allApplications")))
        let rawObjects = (raw as? NSArray)?.compactMap { $0 as AnyObject } ?? []
        let applications = rawObjects.compactMap(SantanderApplication.init(object:))

        cacheLock.lock()
        applicationsCache = applications
        applicationsCacheDate = Date()
        cacheLock.unlock()
        return applications
    }

    private func findApplication(where predicate: (SantanderApplication) -> Bool) -> SantanderApplication? {
        allInstalledApplications().first(where: predicate)
    }

    private func invalidateCache() {
        cacheLock.lock()
        applicationsCache.removeAll(keepingCapacity: true)
        applicationsCacheDate = .distantPast
        cacheLock.unlock()
    }

    private static func normalizedPath(_ url: URL) -> String {
        url.standardizedFileURL.resolvingSymlinksInPath().path
    }

    private static func error(_ message: String) -> NSError {
        NSError(
            domain: "Santander.Applications",
            code: -1,
            userInfo: [NSLocalizedDescriptionKey: message]
        )
    }
}

private enum SantanderL10n {
    static var language: String {
        if let value = UserDefaults.standard.string(forKey: "SantanderLanguage") { return value }
        return Locale.preferredLanguages.first?.hasPrefix("zh") == true ? "zh-Hans" : "en"
    }

    static func setLanguage(_ value: String) {
        UserDefaults.standard.set(value, forKey: "SantanderLanguage")
    }

    static func t(_ value: String) -> String {
        guard language.hasPrefix("zh") else { return value }
        return table[value] ?? value
    }

    private static let table: [String: String] = [
        "Add": "添加", "Add Key": "添加键", "Add Value": "添加值", "Cancel": "取消", "Close": "关闭",
        "Save": "保存", "Done": "完成", "Edit": "编辑", "Delete": "删除", "Remove": "移除", "Rename": "重命名",
        "Copy": "复制", "Move": "移动", "Duplicate": "复制副本", "Paste": "粘贴", "Select": "选择",
        "Select All": "全选", "Deselect All": "取消全选", "Open": "打开", "Share": "分享", "Search": "搜索",
        "Info": "信息", "Path Info": "路径信息", "Permissions": "权限", "Owner": "所有者", "Group": "群组",
        "Other": "其他", "Read": "读取", "Write": "写入", "Execute": "执行", "Root": "root",
        "Mount": "挂载", "Unmount": "取消挂载", "Symbolic Link": "符号链接", "Create Symbolic Link": "创建符号链接",
        "Compress": "压缩", "Decompress": "解压", "Archive": "归档", "File": "文件", "Folder": "文件夹",
        "Directory": "目录", "String": "字符串", "Integer": "整数", "Real": "实数", "Boolean": "布尔值",
        "Date": "日期", "Data": "数据", "Array": "数组", "Dictionary": "字典", "Key": "键", "Value": "值",
        "Property List Viewer": "属性列表查看器", "Text Editor": "文本编辑器", "Text Editor Settings": "文本编辑器设置",
        "Image Viewer": "图片查看器", "Audio Player": "音频播放器", "Font Viewer": "字体查看器", "QuickLook": "快速查看",
        "Settings": "设置", "General": "通用", "Appearance": "外观", "Light": "浅色", "Dark": "深色", "Default": "默认",
        "Applications": "应用程序", "Documents": "文稿", "Downloads": "下载", "Library": "资源库", "Home": "主目录",
        "System": "系统", "Contents": "内容", "Items": "项目", "Name": "名称", "Size": "大小", "Modified": "修改时间",
        "Created": "创建时间", "Date modified": "修改日期", "Date created": "创建日期", "Executable": "可执行文件",
        "Entitlements": "权限声明", "Bundle ID": "Bundle ID", "App Info": "应用信息", "App name": "应用名称",
        "No Results": "无结果", "Input is empty": "输入为空", "Invalid Data": "数据无效", "Not implemented": "尚未实现",
        "Root Helper": "Root 助手", "Enabled": "已启用", "Disabled": "已停用",
        "Ascending": "升序", "Descending": "降序", "Alphabetical order": "按字母排序", "Grouped": "分组",
        "Plain": "纯文本", "Programming": "编程", "Font size": "字体大小", "Go to line": "跳转到行",
        "Search Method": "搜索方式", "Case Sensitive": "区分大小写", "Full Word": "完整单词", "Regex": "正则表达式",
        "Starts With": "开头匹配", "Ends With": "结尾匹配", "Contains": "包含", "Display hidden files": "显示隐藏文件",
        "Always show search bar": "始终显示搜索栏", "Show information button": "显示信息按钮", "Large navigation titles": "大标题导航",
        "Create": "创建", "New Group": "新建群组", "Duplicate Key": "重复键", "Remove bookmark": "移除书签",
        "RootHelper": "Root 助手", "Santander": "Santander"
    ]
}

private enum SantanderGlass {
    static var background: LegacyLiquidGlass.Configuration {
        var c = LLGlassPresets.clear
        c.backend = .legacy; c.quality = .medium; c.adaptiveQuality = true
        c.cornerRadius = 0; c.liveCapture = true; c.sharedSurface = true
        c.maxCapturePixels = 900_000; c.maxRenderScale = 2.0; c.morphing = false
        return c
    }

    static var cell: LegacyLiquidGlass.Configuration {
        var c = LLGlassPresets.liquidGlass
        c.backend = .legacy; c.quality = .high; c.adaptiveQuality = true
        c.cornerRadius = 16; c.liveCapture = true; c.sharedSurface = true
        c.maxCapturePixels = 600_000; c.maxRenderScale = 2.0; c.morphing = false
        return c
    }

    static var selectedCell: LegacyLiquidGlass.Configuration {
        var c = cell
        c.style = .prominent; c.tintStrength = 0.18; c.specularStrength = 0.40
        return c
    }

    static var search: LegacyLiquidGlass.Configuration {
        var c = LLGlassPresets.clear
        c.backend = .legacy; c.quality = .medium; c.adaptiveQuality = true
        c.cornerRadius = 12; c.maxCapturePixels = 500_000; c.maxRenderScale = 2.0
        return c
    }

    static var toolbar: LegacyLiquidGlass.Configuration {
        var c = LLGlassPresets.regular
        c.backend = .legacy; c.quality = .medium; c.adaptiveQuality = true
        c.cornerRadius = 0; c.shadowOpacity = 0; c.morphing = false
        c.maxCapturePixels = 700_000; c.maxRenderScale = 2.0
        return c
    }

    static func install(in view: UIView) {
        guard !view.subviews.contains(where: { $0 is LLGlassView && $0.tag == 0x53474C42 }) else { return }
        let glass = LLGlassView(configuration: background)
        glass.tag = 0x53474C42 // SGLB
        glass.translatesAutoresizingMaskIntoConstraints = false
        view.insertSubview(glass, at: 0)
        NSLayoutConstraint.activate([
            glass.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            glass.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            glass.topAnchor.constraint(equalTo: view.topAnchor),
            glass.bottomAnchor.constraint(equalTo: view.bottomAnchor)
        ])
    }

    static func style(_ controller: UIViewController) {
        controller.view.backgroundColor = .clear
        controller.view.isOpaque = false
        install(in: controller.view)
        if let table = controller as? UITableViewController { styleTable(table.tableView) }
        if let bar = controller.navigationController?.navigationBar { configureNavigationBar(bar) }
    }

    static func styleTable(_ table: UITableView) {
        table.backgroundColor = .clear
        table.backgroundView = nil
        table.separatorColor = UIColor.separator.withAlphaComponent(0.16)
    }

    static func styleCell(_ cell: UITableViewCell) {
        cell.backgroundColor = .clear
        if !(cell.backgroundView is LLGlassView) { cell.backgroundView = LLGlassView(configuration: cellConfig) }
        if !(cell.selectedBackgroundView is LLGlassView) { cell.selectedBackgroundView = LLGlassView(configuration: selectedCell) }
        cell.contentView.backgroundColor = .clear
        cell.contentView.layer.cornerCurve = .continuous
        cell.contentView.layer.cornerRadius = 16
    }

    private static var cellConfig: LegacyLiquidGlass.Configuration { cell }

    static func configureNavigationBar(_ navigationBar: UINavigationBar) {
        let appearance = UINavigationBarAppearance()
        appearance.configureWithTransparentBackground()
        appearance.backgroundEffect = nil
        appearance.backgroundColor = .clear
        appearance.shadowColor = .clear
        navigationBar.standardAppearance = appearance
        navigationBar.scrollEdgeAppearance = appearance
        navigationBar.compactAppearance = appearance
        navigationBar.tintColor = .label

        guard !navigationBar.subviews.contains(where: { $0 is LLGlassView && $0.tag == 0x53474C4E }) else { return }
        var c = background
        c.shadowOpacity = 0
        let glass = LLGlassView(configuration: c)
        glass.tag = 0x53474C4E // SGLN
        glass.translatesAutoresizingMaskIntoConstraints = false
        navigationBar.insertSubview(glass, at: 0)
        NSLayoutConstraint.activate([
            glass.leadingAnchor.constraint(equalTo: navigationBar.leadingAnchor),
            glass.trailingAnchor.constraint(equalTo: navigationBar.trailingAnchor),
            glass.topAnchor.constraint(equalTo: navigationBar.topAnchor),
            glass.bottomAnchor.constraint(equalTo: navigationBar.bottomAnchor)
        ])
    }
}

extension UIViewController {
    func applySantanderGlass() { SantanderGlass.style(self) }
}

private enum SantanderLocalization {
    static func install() {
        UILabel.appearance().textColor = .label
        UIButton.appearance().tintColor = .label
    }
}

@propertyWrapper
struct Storage<T> {
    let key: String
    let defaultValue: T

    init(key: String, defaultValue: T) {
        self.key = key
        self.defaultValue = defaultValue
    }

    var wrappedValue: T {
        get {
            return UserDefaults.standard.object(forKey: key) as? T ?? defaultValue
        }
        set {
            UserDefaults.standard.set(newValue, forKey: key)
        }
    }
}

@propertyWrapper
struct CodableStorage<T: Codable> {
    typealias ChangeHandler = ((T) -> ())

    let key: String
    let defaultValue: T
    var didChange: ChangeHandler?

    init(key: String, defaultValue: T, didChange: ChangeHandler?) {
        self.key = key
        self.defaultValue = defaultValue
        self.didChange = didChange
    }

    var wrappedValue: T {
        get {
            guard let data = UserDefaults.standard.data(forKey: key),
                  let decoded = try? JSONDecoder().decode(T.self, from: data) else {
                return defaultValue
            }
            return decoded
        }
        set {
            guard let encoded = try? JSONEncoder().encode(newValue) else {
                return
            }
            UserDefaults.standard.set(encoded, forKey: key)
            didChange?(newValue)
        }
    }
}

enum UserPreferences {
    @Storage(key: "UseLargeNavTitles", defaultValue: true)
    static var useLargeNavigationTitles: Bool

    @Storage(key: "BookmarksData", defaultValue: [])
    static private var _bookmarksData: [Data]

    static var bookmarks: Set<Path> {
        get {
            var dataArr = self._bookmarksData
            let arr: [Path] = dataArr.compactMap { data in
                var isStale: Bool = false
                guard let url = try? URL(resolvingBookmarkData: data, bookmarkDataIsStale: &isStale) else { return nil }
                if isStale, let indx = dataArr.firstIndex(of: data), let urlData = try? url.bookmarkData() {
                    dataArr[indx] = urlData
                    self._bookmarksData = dataArr
                }
                return Path(url: url)
            }
            return Set(arr)
        }
        set {
            _bookmarksData = newValue.compactMap { url in
                try? url.url.bookmarkData()
            }
            if displayRecentlyBookmarked {
                let bookmarks: [Path] = newValue.suffix(5)
                UIApplication.shared.setShortcutItems(intoURLs: bookmarks)
            }
        }
    }

    @Storage(key: "AlwaysShowSearchBar", defaultValue: true)
    static var alwaysShowSearchBar: Bool

    @Storage(key: "ShowInfoButton", defaultValue: false)
    static var showInfoButton: Bool

    @Storage(key: "LastOpenedPath", defaultValue: nil)
    static var lastOpenedPath: String?

    @Storage(key: "UseLastOpenedPathWhenLaunching", defaultValue: true)
    static var useLastOpenedPathWhenLaunching: Bool

    @Storage(key: "UserPreferredLaunchPath", defaultValue: nil)
    static var userPreferredLaunchPath: String?

    @Storage(key: "TextEditorWrapLines", defaultValue: true)
    static var wrapLines: Bool

    @Storage(key: "TextEditorShowLineCount", defaultValue: true)
    static var showLineCount: Bool

    @Storage(key: "TextEditorUseCharacterPairs", defaultValue: true)
    static var useCharacterPairs: Bool

    @Storage(key: "AudioVCSkipDuration", defaultValue: 15)
    static var skipDuration: Int

    @Storage(key: "AudioVCSpeed", defaultValue: 1)
    static var audioVCSpeed: Float

    @Storage(key: "displayHiddenFiles", defaultValue: true)
    static var displayHiddenFiles: Bool

    @Storage(key: "userIntefaceStyle", defaultValue: UIUserInterfaceStyle.unspecified.rawValue)
    static var preferredInterfaceStyle: Int

    @Storage(key: "userPreferredTableViewStyle", defaultValue: UITableView.Style.insetGrouped.rawValue)
    static var preferredTableViewStyle: Int

    @Storage(key: "FontViewerFontSize", defaultValue: 30)
    static var fontViewerFontSize: CGFloat

    @Storage(key: "AssetCatalogControllerLayoutMode", defaultValue: AssetCatalogViewController.LayoutMode.verical.rawValue)
    static var assetCatalogControllerLayoutMode: Int

    @Storage(key: "RootHelperEnabled", defaultValue: false)
    static var rootHelperIsEnabled: Bool

    @Storage(key: "DisplayRecentlyUsedPathsInAppShortcuts", defaultValue: true)
    static var displayRecentlyBookmarked: Bool

    @CodableStorage(key: "PathGroups", defaultValue: [.default], didChange: { groups in
        NotificationCenter.default.post(name: .pathGroupsDidChange, object: groups)
    })
    static var pathGroups: [PathGroup]

    static var launchPath: String? {
        useLastOpenedPathWhenLaunching ? lastOpenedPath : userPreferredLaunchPath
    }

    @CodableStorage(key: "TextEditorTheme", defaultValue: CodableTextEditorTheme(), didChange: nil)
    static var textEditorTheme: CodableTextEditorTheme

    @CodableStorage(key: "AppTintColor", defaultValue: CodableColor(.systemBlue), didChange: nil)
    static var appTintColor: CodableColor
}

struct PathGroup: Codable, Hashable {
    let name: String
    var paths: [URL]

    static let `default` = PathGroup(name: "Default", paths: [.root])

    func hash(into hasher: inout Hasher) {
        hasher.combine(name)
        hasher.combine(paths)
    }
}

protocol BaseLayoutAnchorSupporting {
    var leadingAnchor: NSLayoutXAxisAnchor { get }
    var trailingAnchor: NSLayoutXAxisAnchor { get }
    var topAnchor: NSLayoutYAxisAnchor { get }
    var bottomAnchor: NSLayoutYAxisAnchor { get }
}

extension UILayoutGuide: BaseLayoutAnchorSupporting {}
extension UIView: BaseLayoutAnchorSupporting {
    func constraintCompletely(to otherView: BaseLayoutAnchorSupporting) {
        NSLayoutConstraint.activate([
            self.leadingAnchor.constraint(equalTo: otherView.leadingAnchor),
            self.trailingAnchor.constraint(equalTo: otherView.trailingAnchor),
            self.topAnchor.constraint(equalTo: otherView.topAnchor),
            self.bottomAnchor.constraint(equalTo: otherView.bottomAnchor)
        ])
    }
}

enum PathType: CustomStringConvertible {
    case file, directory

    var description: String {
        switch self {
        case .file:
            return "file"
        case .directory:
            return "directory"
        }
    }
}

extension UIViewController {
    func presentAlertAndCreate(type: PathType, forURL url: URL) {
        let alert = UIAlertController(title: "New \(type.description)", message: nil, preferredStyle: .alert)
        alert.addTextField { textField in
            textField.placeholder = "name"
        }

        let createAction = UIAlertAction(title: SantanderL10n.t("Create"), style: .default) { _ in
            guard let name = alert.textFields?.first?.text, !name.isEmpty else {
                return
            }

            let urlToCreate = url.appendingPathComponent(name)
            do {
                switch type {
                case .file:
                    try FSOperation.perform(.createFile(files: [urlToCreate]), rootHelperConf: RootConf.shared)
                case .directory:
                    try FSOperation.perform(.createDirectory(directories: [urlToCreate]), rootHelperConf: RootConf.shared)
                }
            } catch {
                self.errorAlert(error, title: "Unable to create \(name)")
            }
        }

        alert.addAction(.cancel())
        alert.addAction(createAction)
        self.present(alert, animated: true)
    }
}

enum PathsSortMethods: String, CaseIterable, CustomStringConvertible {
    case alphabetically
    case size
    case type
    case dateCreated
    case dateModified
    case dateAccessed
    case dateAdded

    static var userPrefered: PathsSortMethods? {
        if let string = UserDefaults.standard.string(forKey: "SubPathsSortMode"), let sortMode = PathsSortMethods(rawValue: string) {
            return sortMode
        }
        return nil
    }

    var description: String {
        switch self {
        case .alphabetically:
            return "Alphabetical order"
        case .size:
            return "Size"
        case .type:
            return "Type"
        case .dateCreated:
            return "Date created"
        case .dateModified:
            return "Date modified"
        case .dateAccessed:
            return "Date accessed"
        case .dateAdded:
            return "Date Added"
        }
    }

    func sorting(URLs urls: [Path], sortOrder: SortOrder) -> [Path] {
        return urls.sorted { (first: Path, second: Path) in
            let ascending: Bool
            let firstURL = first.url
            let secondURL = second.url
            switch self {
            case .alphabetically:
                ascending = firstURL.lastPathComponent < secondURL.lastPathComponent
            case .size:
                ascending = firstURL.size > secondURL.size
            case .type:
                let firstType = firstURL.contentType?.identifier ?? ""
                let secondType = secondURL.contentType?.identifier ?? ""
                let typeComparison = firstType.localizedStandardCompare(secondType)
                if typeComparison != .orderedSame {
                    return sortOrder == .descending
                        ? typeComparison == .orderedDescending
                        : typeComparison == .orderedAscending
                }
                let firstName = firstURL.lastPathComponent
                let secondName = secondURL.lastPathComponent
                let nameComparison = firstName.localizedStandardCompare(secondName)
                return sortOrder == .descending
                    ? nameComparison == .orderedDescending
                    : nameComparison == .orderedAscending
            case .dateCreated:
                ascending = firstURL.creationDate > secondURL.creationDate
            case .dateModified:
                ascending =  firstURL.lastModifiedDate > secondURL.lastModifiedDate
            case .dateAccessed:
                ascending = firstURL.lastAccessedDate > secondURL.lastAccessedDate
            case .dateAdded:
                ascending = firstURL.addedToDirectoryDate > secondURL.addedToDirectoryDate
            }

            if sortOrder == .descending {
                return !ascending
            }

            return ascending
        }
    }
}

enum SortOrder: String, CaseIterable, CustomStringConvertible {
    case ascending, descending

    init(rawValue: String) {
        switch rawValue.lowercased() {
        case "ascending":
            self = .ascending
        case "descending":
            self = .descending
        default:
            self = .ascending
        }
    }

    static var userPreferred: SortOrder {
        guard let rawValue = UserDefaults.standard.string(forKey: "SortOrder") else {
            return .ascending
        }
        return self.init(rawValue: rawValue)
    }

    var description: String {
        switch self {
        case .ascending:
            return "Ascending"
        case .descending:
            return "Descending"
        }
    }

    var imageSymbolName: String {
        switch self {
        case .ascending:
            return "chevron.up"
        case .descending:
            return "chevron.down"
        }
    }

    func toggling() -> SortOrder {
        switch self {
        case .ascending:
            return .descending
        case .descending:
            return .ascending
        }
    }
}

struct Path: Hashable, ExpressibleByStringLiteral {
    static let resourceKeys: Set<URLResourceKey> = [.isDirectoryKey, .contentTypeKey]

    static let root: Path = "/"
    static let home: Path = Path(url: URL(fileURLWithPath: NSHomeDirectory()))

    var url: URL
    var lastPathComponent: String
    var isDirectory: Bool
    var contentType: UTType?

    lazy var size = _getSize()
    lazy var displayImage: UIImage? = _displayImage()

    static let iconsDictionary: [UTType: String] = [
        .text: "doc.text",
        .image: "photo",
        .audio: "waveform",
        .video: "play",
        .movie: "play",
        .executable: "terminal"
    ]

    static func isUType(_ type: UTType, ofAnotherType another: UTType) -> Bool {
        return type == another || type.isSubtype(of: another)
    }

    var path: String {
        url.path
    }

    var displayName: String {
        FileManager.default.displayName(atPath: url.path)
    }

    var pathExtension: String {
        return url.pathExtension
    }

    var containsAppUUIDSubpaths: Bool {
        return url.pathComponents.contains("Containers") || url.pathComponents.contains("containers")
    }

    func deletingLastPathComponent() -> Path {
        return Path(url: url.deletingLastPathComponent())
    }

    func deletingPathExtension() -> Path {
        return Path(url: url.deletingPathExtension())
    }

    func appendingPathExtension(_ ext: String) -> Path {
        return Path(url: url.appendingPathExtension(ext))
    }

    func appendingPathComponent(_ component: String) -> Path {
        return Path(url: url.appendingPathComponent(component))
    }

    func appendingPathComponent(_ component: String) -> URL {
        return url.appendingPathComponent(component)
    }

    var resolvedURL: URL {
        return (try? URL(resolvingAliasFileAt: url)) ?? url
    }

    var contents: [Path] {
        let urls = (try? FileManager.default.contentsOfDirectory(at: url, includingPropertiesForKeys: nil)) ?? []
        return urls.map { url in
            Path(url:url)
        }
    }

    var applicationItem: SantanderApplication? {
        if pathExtension == "app" {
            return ApplicationsManager.shared.application(forBundleURL: self.url)
        }
        return ApplicationsManager.shared.application(forContainerURL: self.url) ?? ApplicationsManager.shared.application(forDataContainerURL: self.url)
    }

    private func _getSize() -> Int? {
        if isDirectory {
            var _size: Int = 0
            for var content in contents {
                _size += content.size ?? 0
            }
            return _size
        }
        return try? url.resourceValues(forKeys: [.fileSizeKey]).fileSize
    }

    var isReadable: Bool {
        return FileManager.default.isReadableFile(atPath: url.path)
    }

    private func _displayImage() -> UIImage? {
        if isDirectory {
            return UIImage(systemName: "folder.fill")
        } else {
            guard let type = self.contentType, type != .data else {
                return UIImage(systemName: "doc")
            }
            let imageName = Self.iconsDictionary.first { (key, _) in
                Self.isUType(type, ofAnotherType: key)
            }
            return UIImage(systemName: imageName?.value ?? "doc")
        }
    }

    init(url: URL) {
        self.url = url
        self.lastPathComponent = url.lastPathComponent

        let resourceValues = try? url.resourceValues(forKeys: Self.resourceKeys)
        self.isDirectory = resourceValues?.isDirectory ?? false
        self.contentType = resourceValues?.contentType
    }

    init(stringLiteral value: StringLiteralType) {
        self.init(url: URL(fileURLWithPath: value))
    }
}

class ImageMetadata {
    let pixelWidth: Int?
    let pixelHeight: Int?

    var location: ImageLocation
    let exifInfo: ImageExifInfo?
    let cameraInfo: ImageCameraInfo?
    let dateTimeTaken: Date?

    var dictionary: [String: Any]

    func setProperties(toDictionary newDict: [String: Any], forFileURL fileURL: URL) -> Bool {
        guard let imageSource = CGImageSourceCreateWithURL(fileURL as CFURL, nil),
              let type = CGImageSourceGetType(imageSource),
              let dest = CGImageDestinationCreateWithURL(fileURL as CFURL, type, 1, nil)
        else {
            return false
        }

        CGImageDestinationAddImageFromSource(dest, imageSource, 0, newDict as CFDictionary)

        if CGImageDestinationFinalize(dest) {
            self.dictionary = newDict
            return true
        } else {
            return false
        }
    }

    convenience init?(fileURL: URL) {
        guard let imageSource = CGImageSourceCreateWithURL(fileURL as CFURL, nil),
              let dict = CGImageSourceCopyPropertiesAtIndex(imageSource, 0, nil) as? [String: Any] else {
            return nil
        }
        self.init(dictionary: dict)
    }

    init(dictionary dict: [String: Any]) {
        self.pixelWidth = dict[kCGImagePropertyPixelWidth as String] as? Int
        self.pixelHeight = dict[kCGImagePropertyPixelHeight as String] as? Int

        if let exifDict = dict[kCGImagePropertyExifDictionary as String] as? [String: Any] {
            self.exifInfo = ImageExifInfo(exifDict: exifDict)
        } else {
            self.exifInfo = nil
        }

        if let gpsDict = dict[kCGImagePropertyGPSDictionary as String] as? [String: Any] {
            let lat = gpsDict[kCGImagePropertyGPSLatitude as String] as? CLLocationDegrees
            let long = gpsDict[kCGImagePropertyGPSLongitude as String] as? CLLocationDegrees
            self.location = ImageLocation(lat: lat, long: long)
        } else {
            self.location = ImageLocation(lat: nil, long: nil)
        }

        if let tiffDict = dict[kCGImagePropertyTIFFDictionary as String] as? [String: Any] {
            self.cameraInfo = ImageCameraInfo(tiffDictionary: tiffDict)
            if let dateTime = tiffDict[kCGImagePropertyTIFFDateTime as String] as? String {
                self.dateTimeTaken = DateFormatter.EXIFDateFormatter.date(from: dateTime)
            } else {
                self.dateTimeTaken = nil
            }
        } else {
            self.cameraInfo = nil
            self.dateTimeTaken = nil
        }

        self.dictionary = dict
    }
}

struct ImageLocation {
    var lat: CLLocationDegrees?
    var long: CLLocationDegrees?

    var coordinate: CLLocationCoordinate2D? {
        guard let lat = lat, let long = long else {
            return nil
        }
        return CLLocationCoordinate2D(latitude: lat, longitude: long)
    }
}

struct ImageCameraInfo {
    let manufacturer: String?
    let model: String?
    let softwareVersion: String?

    init(tiffDictionary: [String: Any]) {
        self.manufacturer = tiffDictionary[kCGImagePropertyTIFFMake as String] as? String
        self.model = tiffDictionary[kCGImagePropertyTIFFModel as String] as? String
        self.softwareVersion = tiffDictionary[kCGImagePropertyTIFFSoftware as String] as? String
    }
}

struct ImageExifInfo {
    let apertureValue: Double?
    let brightnessValue: Double?
    let lensModel: String?
    let lensManufacturer: String?

    init(exifDict: [String: Any]) {
        self.apertureValue = exifDict[kCGImagePropertyExifApertureValue as String] as? Double
        self.brightnessValue = exifDict[kCGImagePropertyExifBrightnessValue as String] as? Double
        self.lensModel = exifDict[kCGImagePropertyExifLensModel as String] as? String
        self.lensManufacturer = exifDict[kCGImagePropertyExifLensMake as String] as? String
    }
}

enum DiffableDataSourceItem<Section: Hashable, Item: Hashable> {
    case section(Section)
    case item(Item)

    static func fromItems(_ items: [Item]) -> [DiffableDataSourceItem] {
        return items.map { item in
            return .item(item)
        }
    }
}

extension DiffableDataSourceItem: Hashable {}

protocol RootHelperConfiguration {
    func perform(_ operation: FSOperation) throws
}

enum FSOperation {
    case createFile(files: [URL])
    case createDirectory(directories: [URL])
    case removeItems(items: [URL])
    case rename(item: URL, newPath: URL)
    case moveItem(items: [URL], resultPath: URL)
    case copyItem(items: [URL], resultPath: URL)
    case symlink(items: [URL], resultPath: URL)
    case setPermissions(url: URL, newOctalPermissions: Int)
    case setOwnerOrGroup(url: URL, ownerName: String?, groupName: String?)
    case compress(paths: [URL], resultPath: URL, format: Compression.FormatType)
    case decompress(archive: URL, resultPath: URL)
    case extractCatalog(catalogFileURL: URL, resultPath: URL)
    case writeData(url: URL, data: Data)
    case writeString(url: URL, string: String)

    var commandLineInvokation: [String] {
        switch self {
        case .createFile(let files):
            return ["create"] + files.flatMap { ["--files", $0.path] }
        case .createDirectory(let directories):
            return ["create"] + directories.flatMap { ["--directories", $0.path] }
        case .removeItems(let items):
            return ["delete"] + items.map(\.path)
        case .rename(let item, let newPath):
            return ["rename", item.path, newPath.path]
        case .moveItem(let items, let resultPath):
            return ["move"] + items.map(\.path) + ["--destination", resultPath.path]
        case .copyItem(let items, let resultPath):
            return ["copy"] + items.map(\.path) + ["--destination", resultPath.path]
        case .symlink(let items, let resultPath):
            return ["link"] + items.map(\.path) + ["--destination", resultPath.path]
        case .setPermissions(let url, let permissions):
            return ["set-permissions", url.path, String(permissions)]
        case .setOwnerOrGroup(let url, let ownerName, let groupName):
            var arguments = ["set-owner-or-group", url.path]
            if let ownerName {
                arguments += ["--owner-name", ownerName]
            }
            if let groupName {
                arguments += ["--group-name", groupName]
            }
            return arguments
        case .compress(let paths, let resultPath, let format):
            return ["compress"] + paths.flatMap { ["--paths", $0.path] } +
                ["--destination", resultPath.path, "--format", format.fileExtension]
        case .decompress(let archive, let resultPath):
            return ["decompress", archive.path, "--destination", resultPath.path]
        case .extractCatalog(let catalogFileURL, let resultPath):
            return ["extract-catalog", catalogFileURL.path, "--destination", resultPath.path]
        case .writeData(let url, _):
            return ["write-data", url.path]
        case .writeString(let url, let string):
            return ["write-string", string, "--path", url.path]
        }
    }

    static func perform(_ operation: FSOperation, rootHelperConf: RootHelperConfiguration) throws {
        try rootHelperConf.perform(operation)
    }
}

struct RootConf: RootHelperConfiguration {
    private init() {}

    static let shared = RootConf()

    func contents(of path: URL) throws -> [URL] {
        let spawn = try spawn(command: try rootHelperURL(), args: ["get-contents", path.path])
        return spawn.standardOutput
            .split(whereSeparator: { $0.isNewline })
            .map { URL(fileURLWithPath: String($0)) }
    }

    private func rootHelperURL() throws -> URL {
        guard let rootHelperURL = Bundle.main.url(forResource: "RootHelper", withExtension: nil),
              FileManager.default.fileExists(atPath: rootHelperURL.path) else {
            throw Errors.rootHelperUnavailable
        }
        return rootHelperURL
    }

    func perform(_ operation: FSOperation) throws {
        let ret: Output
        if case let .writeData(_, data) = operation {
            ret = try spawn(command: try rootHelperURL(), args: operation.commandLineInvokation, standardInputData: data)
        } else {
            ret = try spawn(command: try rootHelperURL(), args: operation.commandLineInvokation)
        }

        guard ret.status == 0 else {
            throw Errors.otherError(description: "Root helper returned non-zero status, error: \(ret.standardError)")
        }
    }

    func runHelper(arguments: [String], standardInputData: Data? = nil) throws {
        let result = try spawn(command: try rootHelperURL(), args: arguments, standardInputData: standardInputData)
        guard result.status == 0 else {
            let message = result.standardError.trimmingCharacters(in: .whitespacesAndNewlines)
            throw Errors.otherError(description: message.isEmpty ? "Root helper failed with status \(result.status)" : message)
        }
    }

    func spawn(command: URL, args: [String], root: Bool = true, standardInputData: Data? = nil) throws -> Output {
        var stdoutPipe: [Int32] = [-1, -1]
        var stderrPipe: [Int32] = [-1, -1]
        var stdinPipe: [Int32] = [-1, -1]

        func closePipe(_ pipe: inout [Int32]) {
            if pipe.count == 2 {
                if pipe[0] >= 0 { _ = close(pipe[0]); pipe[0] = -1 }
                if pipe[1] >= 0 { _ = close(pipe[1]); pipe[1] = -1 }
            }
        }

        guard pipe(&stdoutPipe) == 0,
              pipe(&stderrPipe) == 0,
              standardInputData == nil || pipe(&stdinPipe) == 0 else {
            closePipe(&stdoutPipe); closePipe(&stderrPipe); closePipe(&stdinPipe)
            throw Errors.failedToSpawnHelper
        }

        let bufferSize = Int(BUFSIZ)
        guard fcntl(stdoutPipe[0], F_SETFL, O_NONBLOCK) != -1,
              fcntl(stderrPipe[0], F_SETFL, O_NONBLOCK) != -1 else {
            closePipe(&stdoutPipe); closePipe(&stderrPipe); closePipe(&stdinPipe)
            throw Errors.otherError(description: "Unable to configure helper pipes: \(String(cString: strerror(errno)))")
        }

        let argumentStrings = [command.lastPathComponent] + args
        let argv: [UnsafeMutablePointer<CChar>?] = argumentStrings.map { $0.withCString(strdup) }
        defer { for case let arg? in argv { free(arg) } }

        var actions: posix_spawn_file_actions_t?
        guard posix_spawn_file_actions_init(&actions) == 0 else {
            closePipe(&stdoutPipe); closePipe(&stderrPipe); closePipe(&stdinPipe)
            throw Errors.failedToSpawnHelper
        }
        defer { _ = posix_spawn_file_actions_destroy(&actions) }

        guard posix_spawn_file_actions_addclose(&actions, stdoutPipe[0]) == 0,
              posix_spawn_file_actions_addclose(&actions, stderrPipe[0]) == 0,
              posix_spawn_file_actions_adddup2(&actions, stdoutPipe[1], STDOUT_FILENO) == 0,
              posix_spawn_file_actions_adddup2(&actions, stderrPipe[1], STDERR_FILENO) == 0,
              posix_spawn_file_actions_addclose(&actions, stdoutPipe[1]) == 0,
              posix_spawn_file_actions_addclose(&actions, stderrPipe[1]) == 0 else {
            closePipe(&stdoutPipe); closePipe(&stderrPipe); closePipe(&stdinPipe)
            throw Errors.failedToSpawnHelper
        }

        if standardInputData != nil {
            guard posix_spawn_file_actions_adddup2(&actions, stdinPipe[0], STDIN_FILENO) == 0,
                  posix_spawn_file_actions_addclose(&actions, stdinPipe[0]) == 0,
                  posix_spawn_file_actions_addclose(&actions, stdinPipe[1]) == 0 else {
                closePipe(&stdoutPipe); closePipe(&stderrPipe); closePipe(&stdinPipe)
                throw Errors.failedToSpawnHelper
            }
        }

        var attr: posix_spawnattr_t?
        guard posix_spawnattr_init(&attr) == 0 else {
            closePipe(&stdoutPipe); closePipe(&stderrPipe); closePipe(&stdinPipe)
            throw Errors.failedToSpawnHelper
        }
        defer { _ = posix_spawnattr_destroy(&attr) }
        typealias SetPersona = @convention(c) (UnsafeMutablePointer<posix_spawnattr_t?>, uid_t, UInt32) -> Int32
        typealias SetPersonaID = @convention(c) (UnsafeMutablePointer<posix_spawnattr_t?>, uid_t) -> Int32
        let defaultHandle = UnsafeMutableRawPointer(bitPattern: -2)
        if let symbol = dlsym(defaultHandle, "posix_spawnattr_set_persona_np") {
            let setPersona = unsafeBitCast(symbol, to: SetPersona.self)
            _ = setPersona(&attr, 99, 1)
        }
        if let symbol = dlsym(defaultHandle, "posix_spawnattr_set_persona_uid_np") {
            let setPersonaID = unsafeBitCast(symbol, to: SetPersonaID.self)
            _ = setPersonaID(&attr, 0)
        }
        if let symbol = dlsym(defaultHandle, "posix_spawnattr_set_persona_gid_np") {
            let setPersonaID = unsafeBitCast(symbol, to: SetPersonaID.self)
            _ = setPersonaID(&attr, 0)
        }

        let env = [#"PATH=/usr/local/sbin:/var/jb/usr/local/sbin:/usr/local/bin:/var/jb/usr/local/bin:/usr/sbin:/var/jb/usr/sbin:/usr/bin:/var/jb/usr/bin:/sbin:/var/jb/sbin:/bin:/var/jb/bin:/usr/bin/X11:/var/jb/usr/bin/X11:/usr/games:/var/jb/usr/games"#]
        let proenv: [UnsafeMutablePointer<CChar>?] = env.map { $0.withCString(strdup) }
        defer { for case let e? in proenv { free(e) } }

        var pid: pid_t = 0
        let spawnStatus = argv.withUnsafeBufferPointer { argvBuffer in
            proenv.withUnsafeBufferPointer { envBuffer in
                posix_spawn(&pid, command.path, &actions, &attr, argvBuffer.baseAddress, envBuffer.baseAddress)
            }
        }
        guard spawnStatus == 0 else {
            closePipe(&stdoutPipe); closePipe(&stderrPipe); closePipe(&stdinPipe)
            throw Errors.otherError(description: "Failed to spawn root helper: \(String(cString: strerror(spawnStatus)))")
        }

        let stdoutReadFD = stdoutPipe[0]
        let stderrReadFD = stderrPipe[0]
        _ = close(stdoutPipe[1]); stdoutPipe[1] = -1
        _ = close(stderrPipe[1]); stderrPipe[1] = -1
        if standardInputData != nil { _ = close(stdinPipe[0]); stdinPipe[0] = -1 }

        let dataLock = NSLock()
        var stdoutData = Data()
        var stderrData = Data()
        let queue = DispatchQueue(label: "com.Antoine.Santander.RootHelper.read", qos: .userInitiated, attributes: .concurrent)
        let stdoutDone = DispatchSemaphore(value: 0)
        let stderrDone = DispatchSemaphore(value: 0)

        let stdoutSource = DispatchSource.makeReadSource(fileDescriptor: stdoutReadFD, queue: queue)
        let stderrSource = DispatchSource.makeReadSource(fileDescriptor: stderrReadFD, queue: queue)

        stdoutSource.setCancelHandler {
            _ = close(stdoutReadFD)
            stdoutDone.signal()
        }
        stderrSource.setCancelHandler {
            _ = close(stderrReadFD)
            stderrDone.signal()
        }

        stdoutSource.setEventHandler {
            var buffer = [UInt8](repeating: 0, count: bufferSize)
            let n = read(stdoutReadFD, &buffer, buffer.count)
            if n > 0 {
                dataLock.lock(); stdoutData.append(buffer, count: n); dataLock.unlock()
            } else if n == 0 || (n < 0 && errno != EAGAIN && errno != EINTR) {
                stdoutSource.cancel()
            }
        }
        stderrSource.setEventHandler {
            var buffer = [UInt8](repeating: 0, count: bufferSize)
            let n = read(stderrReadFD, &buffer, buffer.count)
            if n > 0 {
                dataLock.lock(); stderrData.append(buffer, count: n); dataLock.unlock()
            } else if n == 0 || (n < 0 && errno != EAGAIN && errno != EINTR) {
                stderrSource.cancel()
            }
        }

        stdoutSource.resume(); stderrSource.resume()

        if let input = standardInputData {
            let fd = stdinPipe[1]
            stdinPipe[1] = -1
            DispatchQueue.global(qos: .userInitiated).async {
                input.withUnsafeBytes { raw in
                    guard let base = raw.baseAddress else { return }
                    var offset = 0
                    while offset < raw.count {
                        let written = write(fd, base.advanced(by: offset), raw.count - offset)
                        if written > 0 { offset += written }
                        else if written < 0 && errno == EINTR { continue }
                        else { break }
                    }
                }
                _ = close(fd)
            }
        }

        var waitStatus: Int32 = 0
        var waitedPID: pid_t
        repeat {
            waitedPID = waitpid(pid, &waitStatus, 0)
        } while waitedPID == -1 && errno == EINTR
        stdoutDone.wait(); stderrDone.wait()

        dataLock.lock()
        let out = stdoutData; let err = stderrData
        dataLock.unlock()
        guard waitedPID == pid else {
            return Output(status: -1,
                          standardOutput: String(decoding: out, as: UTF8.self),
                          standardError: String(decoding: err, as: UTF8.self))
        }
        let normalExit = (waitStatus & 0x7f) == 0
        return Output(status: normalExit ? Int32((waitStatus >> 8) & 0xff) : -1,
                      standardOutput: String(decoding: out, as: UTF8.self),
                      standardError: String(decoding: err, as: UTF8.self))
    }

    struct Output {
        let status: CInt
        let standardOutput: String
        let standardError: String
    }

    var useRootHelper: Bool {
        return UserPreferences.rootHelperIsEnabled
    }

    private enum Errors: Error, LocalizedError, CustomStringConvertible {
        case rootHelperUnavailable
        case unableToReadHelperOutput
        case failedToSpawnHelper
        case otherError(description: String)

        var description: String {
            switch self {
            case .rootHelperUnavailable:
                return "Root Helper unavailable? is your install messed up?"
            case .unableToReadHelperOutput:
                return "Unable to read root helper output"
            case .failedToSpawnHelper:
                return "Failed to spawn root helper"
            case .otherError(let description):
                return description
            }
        }

        var errorDescription: String? {
            description
        }
    }
}

protocol DirectoryMonitorDelegate: AnyObject {
    func directoryMonitorDidObserveChange(directoryMonitor: DirectoryMonitor)
}

class DirectoryMonitor {
    weak var delegate: DirectoryMonitorDelegate?

    var monitoredDirectoryFileDescriptor: CInt = -1

    let directoryMonitorQueue = DispatchQueue(label: "directorymonitor", attributes: .concurrent)

    var directoryMonitorSource: DispatchSource?

    var path: Path

    init(path: Path) {
        self.path = path
    }

    func startMonitoring() {
        if directoryMonitorSource == nil && monitoredDirectoryFileDescriptor == -1 {
            monitoredDirectoryFileDescriptor = open((path.url as NSURL).fileSystemRepresentation, O_EVTONLY)

            if path.isReadable {
                directoryMonitorSource = DispatchSource.makeFileSystemObjectSource(fileDescriptor: monitoredDirectoryFileDescriptor, eventMask: .all, queue: directoryMonitorQueue) as? DispatchSource
            }

            directoryMonitorSource?.setEventHandler {
                self.delegate?.directoryMonitorDidObserveChange(directoryMonitor: self)
            }

            directoryMonitorSource?.setCancelHandler {
                close(self.monitoredDirectoryFileDescriptor)
                self.monitoredDirectoryFileDescriptor = -1
                self.directoryMonitorSource = nil
            }

            directoryMonitorSource?.resume()
        }
    }

    func stopMonitoring() {
        if directoryMonitorSource != nil {
            directoryMonitorSource?.cancel()
        }
    }
}

struct GoToItem: Hashable {

    private typealias MayExistDictionary = [String: (URL?, UIImage?)]

    let displayName: String
    let url: URL
    let image: UIImage?

    init(displayName: String, url: URL, image: UIImage?) {
        self.displayName = displayName
        self.url = url
        self.image = image
    }

    private static func _searchPathDirURL(_ searchPath: FileManager.SearchPathDirectory) -> URL? {
        return FileManager.default.urls(for: searchPath, in: .userDomainMask).first
    }

    private static func _generateAll() -> [GoToItem] {
        let coreItems: [GoToItem] = [
            GoToItem(displayName: "Root", url: URL(fileURLWithPath: "/var/root"), image: nil),
            GoToItem(displayName: "Home", url: .home, image: UIImage(systemName: "house"))
        ]

        let mayExistDict: MayExistDictionary = [
            "Applications": (_searchPathDirURL(.applicationDirectory), .appsDirectory),
            "Library":      (_searchPathDirURL(.libraryDirectory),     .libraryDirectory),
            "Documents":    (_searchPathDirURL(.documentDirectory),    .documentDirectory),
            "Downloads":    (_searchPathDirURL(.downloadsDirectory),   .downloadsDirectory)
        ]

        let mayExistItems: [GoToItem] = mayExistDict.compactMap { (key, value) in
            let (url, image) = value
            guard let url = url, FileManager.default.fileExists(atPath: url.path) else {
                return nil
            }
            return GoToItem(displayName: key, url: url, image: image)
        }

        return coreItems + mayExistItems
    }

    static let all = _generateAll()
}

fileprivate extension UIImage {
    static let appsDirectory =      UIImage(systemName: "app.dashed")
    static let libraryDirectory =   UIImage(systemName: "books.vertical")
    static let documentDirectory =  UIImage(systemName: "doc")
    static let downloadsDirectory = UIImage(systemName: "arrow.down.circle")
}

enum LoadingValueState<Value> {
    case loading
    case unavailable
    case value(Value)
}

struct PathMetadata {

    static let resourceValueKeys: Set<URLResourceKey> = [
        .creationDateKey, .contentAccessDateKey, .addedToDirectoryDateKey, .contentModificationDateKey,
        .contentTypeKey
    ]

    let creationDate: Date?
    let addedToDirectoryDate: Date?
    let lastModifiedDate: Date?
    let lastAccessedDate: Date?
    let contentType: UTType?
    var permissions: PathPermissions?

    init(filePath path: Path, resourceValues: Set<URLResourceKey> = resourceValueKeys) {
        let resourceValues = try? path.url.resourceValues(forKeys: resourceValues)
        self.creationDate = resourceValues?.creationDate
        self.addedToDirectoryDate = resourceValues?.addedToDirectoryDate
        self.lastModifiedDate = resourceValues?.contentModificationDate
        self.lastAccessedDate = resourceValues?.contentAccessDate
        self.contentType = resourceValues?.contentType
        self.permissions = PathPermissions(fileURL: path.url)
    }
}

protocol PathTransitioning {
    func goToPath(path: Path)
}

struct Permission: OptionSet, CustomStringConvertible, Equatable {
    public var rawValue: Int

    static let execute = Permission(rawValue: 1)
    static let write = Permission(rawValue: 2)
    static let read = Permission(rawValue: 4)

    init(rawValue: Int) {
        self.rawValue = rawValue
    }

    init(buffer: stat, constants: [UInt16: Permission]) {
        self = constants.filter { (constant, _) in
            return (buffer.st_mode & constant) != 0
        }
        .map(\.value)
        .reducingToSingleOptionSet()
    }

    var binaryRepresentation: String {
        var b = String(rawValue, radix: 2)
        while b.count < 3 { b = "0" + b }
        return b
    }

    var description: String {
        return "Readable: \(contains(.read)), Writable: \(contains(.write)), Executable: \(contains(.execute))"
    }

    static func binaryRepresentation(of permissions: [Permission]) -> String {
        return permissions.map { $0.binaryRepresentation }.joined()
    }

    static func octalRepresentation(of permissions: [Permission]) -> Int {
        let binary = binaryRepresentation(of: permissions)
        return Int(binary, radix: 2)!
    }

    static let ownerPermsConstants: [UInt16: Permission] = [
        S_IRUSR: .read,
        S_IWUSR: .write,
        S_IXUSR: .execute
    ]

    static let groupPermsConstants: [UInt16: Permission] = [
        S_IRGRP: .read,
        S_IWGRP: .write,
        S_IXGRP: .execute
    ]

    static let otherUsersPermsConstants: [UInt16: Permission] = [
        S_IROTH: .read,
        S_IWOTH: .write,
        S_IXOTH: .execute
    ]
}

struct PathPermissions: Equatable {
    let fileURL: URL
    var ownerPermissions: Permission
    var groupPermissions: Permission
    var otherUsersPermissions: Permission
    var ownerName: String?
    var groupOwnerName: String?
    var ownerID: Int32
    var groupID: Int32

    init?(fileURL: URL) {
        var buffer = stat()
        guard lstat(fileURL.path, &buffer) == 0 else {
            return nil
        }

        ownerPermissions = Permission(buffer: buffer, constants: Permission.ownerPermsConstants)
        groupPermissions = Permission(buffer: buffer, constants: Permission.groupPermsConstants)
        otherUsersPermissions = Permission(buffer: buffer, constants: Permission.otherUsersPermsConstants)
        ownerID = Int32(buffer.st_uid)
        groupID = Int32(buffer.st_gid)

        let attrs = try? FileManager.default.attributesOfItem(atPath: fileURL.path)
        ownerName = attrs?[.ownerAccountName] as? String
        groupOwnerName = attrs?[.groupOwnerAccountName] as? String
        self.fileURL = fileURL
    }

    init(
        fileURL: URL,
        ownerPermissions: Permission,
        groupPermissions: Permission,
        otherUsersPermissions: Permission,
        ownerName: String? = nil,
        groupOwnerName: String? = nil,
        ownerID: Int32 = 0,
        groupID: Int32 = 0
    ) {
        self.fileURL = fileURL
        self.ownerPermissions = ownerPermissions
        self.groupPermissions = groupPermissions
        self.otherUsersPermissions = otherUsersPermissions
        self.ownerName = ownerName
        self.groupOwnerName = groupOwnerName
        self.ownerID = ownerID
        self.groupID = groupID
    }

    func apply() throws {
        try fileURL.setPermissions(forOwner: ownerPermissions, group: groupPermissions, others: otherUsersPermissions)
    }
}

struct StringError: LocalizedError, CustomStringConvertible {
    let description: String

    init(_ description: String) {
        self.description = description
    }

    var errorDescription: String? {
        description
    }
}

// MARK: - Self-contained root-helper command parser
//
// The original file used Swift ArgumentParser only for the small root-helper
// command surface below. Santander is also built in environments where the
// ArgumentParser module is intentionally unavailable, so keep the command
// interface but make it dependency-free.
private enum SantanderCommandParser {
    static func arguments(_ args: [String], after flag: String) throws -> [String] {
        var values: [String] = []
        var index = 0
        while index < args.count {
            if args[index] == flag {
                guard index + 1 < args.count else {
                    throw StringError("Missing value for \(flag)")
                }
                values.append(args[index + 1])
                index += 2
            } else {
                index += 1
            }
        }
        return values
    }

    static func single(_ args: [String], flag: String, required: Bool = false) throws -> String? {
        let values = try arguments(args, after: flag)
        guard values.count <= 1 else {
            throw StringError("Option \(flag) may only be provided once")
        }
        if required && values.isEmpty {
            throw StringError("Missing required option \(flag)")
        }
        return values.first
    }

    static func positional(_ args: [String], excluding flags: Set<String>) -> [String] {
        var result: [String] = []
        var index = 0
        while index < args.count {
            let item = args[index]
            if flags.contains(item) {
                index += min(2, args.count - index)
            } else if item.hasPrefix("--") {
                index += 1
            } else {
                result.append(item)
                index += 1
            }
        }
        return result
    }

    static func url(_ value: String, label: String) throws -> URL {
        guard !value.isEmpty else {
            throw StringError("Invalid empty \(label)")
        }
        return URL(fileURLWithPath: value)
    }

    static func urls(_ values: [String], label: String) throws -> [URL] {
        try values.map { try url($0, label: label) }
    }

    static func requiredURL(_ args: [String], flag: String) throws -> URL {
        guard let value = try single(args, flag: flag, required: true) else {
            throw StringError("Missing required option \(flag)")
        }
        return try url(value, label: flag)
    }

    static func printUsage() {
        let usage = """
        Usage: RootHelperProgram <command> [options]

        Commands:
          create --directories <path>... --files <path>...
          delete <path>...
          move <path>... --destination <directory>
          copy <path>... --destination <directory>
          link <path>... --destination <directory>
          rename <path> <destination>
          set-owner-or-group <path> [--group-name <name>] [--owner-name <name>]
          set-permissions <path> <permissions>
          compress --paths <path>... --destination <path> [--format zip|tar]
          decompress <path> --destination <path>
          write-data <path>
          write-string <string> --path <path>
          get-contents <path>
        """
        FileHandle.standardError.write(Data(usage.utf8))
    }
}

struct Delete {
    let paths: [URL]

    init(arguments: [String]) throws {
        let positionals = arguments
            .filter { !$0.hasPrefix("-") }
            .map { URL(fileURLWithPath: $0) }
        guard !positionals.isEmpty else {
            throw StringError("delete requires at least one path")
        }
        self.paths = positionals
    }

    func run() throws {
        for path in paths {
            try FileManager.default.removeItem(at: path)
        }
    }
}

struct SetOwnerOrGroup {
    let path: URL
    let groupName: String?
    let ownerName: String?

    init(arguments: [String]) throws {
        let positionals = SantanderCommandParser.positional(
            arguments,
            excluding: ["--group-name", "--owner-name"]
        )
        guard let first = positionals.first, positionals.count == 1 else {
            throw StringError("set-owner-or-group requires exactly one path")
        }
        self.path = URL(fileURLWithPath: first)
        self.groupName = try SantanderCommandParser.single(arguments, flag: "--group-name")
        self.ownerName = try SantanderCommandParser.single(arguments, flag: "--owner-name")

        guard groupName != nil || ownerName != nil else {
            throw StringError("Specify --group-name and/or --owner-name")
        }
    }

    func run() throws {
        if let groupName {
            try FileManager.default.setAttributes([.groupOwnerAccountName: groupName], ofItemAtPath: path.path)
        }
        if let ownerName {
            try FileManager.default.setAttributes([.ownerAccountName: ownerName], ofItemAtPath: path.path)
        }
    }
}

struct Create {
    let directories: [URL]
    let files: [URL]

    init(arguments: [String]) throws {
        directories = try SantanderCommandParser.urls(
            SantanderCommandParser.arguments(arguments, after: "--directories"),
            label: "directory"
        )
        files = try SantanderCommandParser.urls(
            SantanderCommandParser.arguments(arguments, after: "--files"),
            label: "file"
        )

        guard !directories.isEmpty || !files.isEmpty else {
            throw StringError("create requires --directories and/or --files")
        }
    }

    func run() throws {
        for dir in directories {
            try FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
        }

        for file in files {
            let fPtr = try file.withUnsafeFileSystemRepresentation { cPathPointer in
                guard let cPathPointer, let fPtr = fopen(cPathPointer, "a") else {
                    throw StringError("Failed to create file \(file): \(String(cString: strerror(errno)))")
                }
                return fPtr
            }
            fclose(fPtr)
        }
    }
}

struct Move {
    let paths: [URL]
    let destination: URL

    init(arguments: [String]) throws {
        let positionals = SantanderCommandParser.positional(arguments, excluding: ["--destination"])
        guard !positionals.isEmpty else { throw StringError("move requires at least one source path") }
        paths = positionals.map { URL(fileURLWithPath: $0) }
        destination = try SantanderCommandParser.requiredURL(arguments, flag: "--destination")
    }

    func run() throws {
        for path in paths {
            try FileManager.default.moveItem(at: path, to: destination.appendingPathComponent(path.lastPathComponent))
        }
    }
}

struct Copy {
    let paths: [URL]
    let destination: URL

    init(arguments: [String]) throws {
        let positionals = SantanderCommandParser.positional(arguments, excluding: ["--destination"])
        guard !positionals.isEmpty else { throw StringError("copy requires at least one source path") }
        paths = positionals.map { URL(fileURLWithPath: $0) }
        destination = try SantanderCommandParser.requiredURL(arguments, flag: "--destination")
    }

    func run() throws {
        for path in paths {
            try FileManager.default.copyItem(at: path, to: destination.appendingPathComponent(path.lastPathComponent))
        }
    }
}

struct Rename {
    let path: URL
    let destination: URL

    init(arguments: [String]) throws {
        let positionals = arguments.filter { !$0.hasPrefix("-") }
        guard positionals.count == 2 else {
            throw StringError("rename requires <path> <destination>")
        }
        path = URL(fileURLWithPath: positionals[0])
        destination = URL(fileURLWithPath: positionals[1])
    }

    func run() throws {
        try FileManager.default.moveItem(at: path, to: destination)
    }
}

struct Link {
    let paths: [URL]
    let destination: URL

    init(arguments: [String]) throws {
        let positionals = SantanderCommandParser.positional(arguments, excluding: ["--destination"])
        guard !positionals.isEmpty else { throw StringError("link requires at least one source path") }
        paths = positionals.map { URL(fileURLWithPath: $0) }
        destination = try SantanderCommandParser.requiredURL(arguments, flag: "--destination")
    }

    func run() throws {
        for path in paths {
            try FileManager.default.createSymbolicLink(
                at: destination.appendingPathComponent(path.lastPathComponent),
                withDestinationURL: path
            )
        }
    }
}

struct SetPermissions {
    let path: URL
    let permissions: Int

    init(arguments: [String]) throws {
        let positionals = arguments.filter { !$0.hasPrefix("-") }
        guard positionals.count == 2, let parsed = Int(positionals[1]) else {
            throw StringError("set-permissions requires <path> <permissions>")
        }
        path = URL(fileURLWithPath: positionals[0])
        permissions = parsed
    }

    func run() throws {
        guard permissions >= 0 && permissions <= 0o7777 else {
            throw StringError("Permissions must be between 0000 and 7777")
        }
        try FileManager.default.setAttributes([.posixPermissions: permissions], ofItemAtPath: path.path)
    }
}

struct WriteData {
    let path: URL

    init(arguments: [String]) throws {
        let positionals = arguments.filter { !$0.hasPrefix("-") }
        guard positionals.count == 1 else {
            throw StringError("write-data requires <path>")
        }
        path = URL(fileURLWithPath: positionals[0])
    }

    func run() throws {
        let data = FileHandle.standardInput.readDataToEndOfFile()
        try data.write(to: path, options: .atomic)
    }
}

struct WriteString {
    let string: String
    let path: URL

    init(arguments: [String]) throws {
        let positionals = SantanderCommandParser.positional(arguments, excluding: ["--path"])
        guard positionals.count == 1 else {
            throw StringError("write-string requires exactly one string argument")
        }
        string = positionals[0]
        path = try SantanderCommandParser.requiredURL(arguments, flag: "--path")
    }

    func run() throws {
        try string.write(to: path, atomically: true, encoding: .utf8)
    }
}

struct Compress {
    let paths: [URL]
    let destination: URL
    let format: Compression.FormatType

    init(arguments: [String]) throws {
        let pathValues = try SantanderCommandParser.arguments(arguments, after: "--paths")
        guard !pathValues.isEmpty else {
            throw StringError("compress requires at least one --paths value")
        }
        paths = try SantanderCommandParser.urls(pathValues, label: "path")
        destination = try SantanderCommandParser.requiredURL(arguments, flag: "--destination")

        switch try SantanderCommandParser.single(arguments, flag: "--format") ?? "zip" {
        case "zip":
            format = .zip
        case "tar":
            format = .tar
        default:
            throw StringError("Compression format must be zip or tar")
        }
    }

    func run() throws {
        try Compression.shared.compress(paths: paths, outputPath: destination, format: format)
    }
}

struct Decompress {
    let path: URL
    let destination: URL

    init(arguments: [String]) throws {
        let positionals = SantanderCommandParser.positional(arguments, excluding: ["--destination"])
        guard positionals.count == 1 else {
            throw StringError("decompress requires <path>")
        }
        path = URL(fileURLWithPath: positionals[0])
        destination = try SantanderCommandParser.requiredURL(arguments, flag: "--destination")
    }

    func run() throws {
        try Compression.shared.extract(path: path, to: destination)
    }
}

struct ExtractCatalog {
    let path: URL
    let destination: URL

    init(arguments: [String]) throws {
        let positionals = SantanderCommandParser.positional(arguments, excluding: ["--destination"])
        guard positionals.count == 1 else {
            throw StringError("extract-catalog requires <path>")
        }
        path = URL(fileURLWithPath: positionals[0])
        destination = try SantanderCommandParser.requiredURL(arguments, flag: "--destination")
    }

    func run() throws {
        let (_, renditions) = try AssetCatalogWrapper.shared.renditions(forCarArchive: path)
        let codable = renditions.flatMap(\.renditions).toCodable()

        try FileManager.default.createDirectory(at: destination, withIntermediateDirectories: true)
        var failedItems: [String: String] = [:]
        for rend in codable {
            let newURL = destination.appendingPathComponent(rend.renditionName)
            if let data = rend.itemData {
                do {
                    try data.write(to: newURL)
                } catch {
                    failedItems[rend.renditionName] = "Unable to write item data to file: \(error.localizedDescription)"
                }
            }
        }

        if !failedItems.isEmpty {
            let message = failedItems.map { "\($0.key): \($0.value)" }.joined(separator: "\n")
            throw StringError(message.trimmingCharacters(in: .whitespacesAndNewlines))
        }
    }
}

struct GetContents {
    let path: URL

    init(arguments: [String]) throws {
        let positionals = arguments.filter { !$0.hasPrefix("-") }
        guard positionals.count == 1 else {
            throw StringError("get-contents requires <path>")
        }
        path = URL(fileURLWithPath: positionals[0])
    }

    func run() throws {
        let contents = try FileManager.default.contentsOfDirectory(at: path, includingPropertiesForKeys: nil)
        let output = contents.map(\.path).joined(separator: "\n")
        FileHandle.standardOutput.write(Data(output.utf8))
        if !output.isEmpty {
            FileHandle.standardOutput.write(Data("\n".utf8))
        }
    }
}

struct RootHelperProgram {
    static func main() throws {
        try main(ProcessInfo.processInfo.arguments.dropFirst().map { String($0) })
    }

    static func main(_ arguments: [String]) throws {
        guard let command = arguments.first?.lowercased() else {
            SantanderCommandParser.printUsage()
            return
        }

        let commandArguments = Array(arguments.dropFirst())

        switch command {
        case "create":
            try Create(arguments: commandArguments).run()
        case "delete":
            try Delete(arguments: commandArguments).run()
        case "move":
            try Move(arguments: commandArguments).run()
        case "copy":
            try Copy(arguments: commandArguments).run()
        case "link":
            try Link(arguments: commandArguments).run()
        case "rename":
            try Rename(arguments: commandArguments).run()
        case "set-owner-or-group":
            try SetOwnerOrGroup(arguments: commandArguments).run()
        case "set-permissions":
            try SetPermissions(arguments: commandArguments).run()
        case "compress":
            try Compress(arguments: commandArguments).run()
        case "decompress":
            try Decompress(arguments: commandArguments).run()
        case "extract-catalog":
            try ExtractCatalog(arguments: commandArguments).run()
        case "write-data":
            try WriteData(arguments: commandArguments).run()
        case "write-string":
            try WriteString(arguments: commandArguments).run()
        case "get-contents":
            try GetContents(arguments: commandArguments).run()
        case "help", "--help", "-h":
            SantanderCommandParser.printUsage()
        default:
            throw StringError("Unknown root-helper command: \(command)")
        }
    }
}

extension URL {

    func regularFileAllocatedSize() throws -> UInt64 {
        let resourceValues = try self.resourceValues(forKeys: allocatedSizeResourceKeys)
        guard resourceValues.isRegularFile ?? false else {
            return 0
        }
        return UInt64(resourceValues.totalFileAllocatedSize ?? resourceValues.fileAllocatedSize ?? 0)
    }

    var contents: [URL] {
        if !isReadable {
            return (try? RootConf.shared.contents(of: resolvedURL)) ?? []
        }
        let _contents = try? FileManager.default.contentsOfDirectory(at: self.resolvedURL, includingPropertiesForKeys: [])
        return _contents ?? []
    }

    var isDirectory: Bool {
        return (try? resolvedURL.resourceValues(forKeys: [.isDirectoryKey]).isDirectory) ?? false
    }

    var creationDate: Date? {
        try? resourceValues(forKeys: [.creationDateKey]).creationDate
    }

    var lastModifiedDate: Date? {
        try? resourceValues(forKeys: [.contentModificationDateKey]).contentModificationDate
    }

    var lastAccessedDate: Date? {
        try? resourceValues(forKeys: [.contentAccessDateKey]).contentAccessDate
    }

    var addedToDirectoryDate: Date? {
        try? resourceValues(forKeys: [.addedToDirectoryDateKey]).addedToDirectoryDate
    }

    var size: Int? {
        if isDirectory {
            var _size: Int = 0
            for content in contents {
                _size += content.size ?? 0
            }
            return _size
        }
        return try? resourceValues(forKeys: [.fileSizeKey]).fileSize
    }

    var contentType: UTType? {
        return try? resourceValues(forKeys: [.contentTypeKey]).contentType
    }

    var displayName: String {
        return FileManager.default.displayName(atPath: self.path)
    }

    var resolvedURL: URL {
        return (try? URL(resolvingAliasFileAt: self)) ?? self
    }

    static let root: URL = URL(fileURLWithPath: "/")
    static let home: URL = URL(fileURLWithPath: NSHomeDirectory())

    var isSymlink: Bool {
        return (try? FileManager.default.destinationOfSymbolicLink(atPath: self.path)) != nil
    }

    var isReadable: Bool {
        return FileManager.default.isReadableFile(atPath: self.path)
    }

    func setPermissions(forOwner owner: Permission, group: Permission = [], others: Permission = []) throws {
        let octal = Permission.octalRepresentation(of: [owner, group, others])
        try FSOperation.perform(.setPermissions(url: self, newOctalPermissions: octal), rootHelperConf: RootConf.shared)
    }

    func fullPathComponents() -> [URL] {
        var arr: [URL] = []
        let components = self.pathComponents
        for indx in components.indices {
            let item = components[components.startIndex...indx]
                .joined(separator: "/")
                .replacingOccurrences(of: "//", with: "/")
            if item.isEmpty {
                continue
            }
            arr.append(URL(fileURLWithPath: item))
        }
        return arr
    }

    var containsAppUUIDSubpaths: Bool {
        return pathComponents.contains("Containers") || pathComponents.contains("containers")
    }

    var applicationItem: SantanderApplication? {
        if self.pathExtension == "app" {
            return ApplicationsManager.shared.application(forBundleURL: self)
        }
        return ApplicationsManager.shared.application(forContainerURL: self) ?? ApplicationsManager.shared.application(forDataContainerURL: self)
    }
}

#if targetEnvironment(simulator)
fileprivate let applicationPaths: [String] = [URL.home.deletingLastPathComponent().path]
#else
fileprivate let applicationPaths: [String] = [
    "/private/var/containers/Bundle/Application",
    "/private/var/mobile/Containers/Data",
    "/private/var/mobile/Containers/Data/Application"
]
#endif

extension UIViewController {
    func errorAlert(
        _ errorDescription: String?,
        title: String,
        presentingFromIfAvailable presentingVC: UIViewController? = nil,
        cancelAction: UIAlertAction = .cancel(title: "OK")
    ) {
        var message: String? = nil
        if let errorDescription = errorDescription {
            message = "Error occurred: \(errorDescription)"
        }

        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        alert.addAction(cancelAction)
        let vcToPresentFrom = presentingVC ?? self
        vcToPresentFrom.present(alert, animated: true)
    }

    func errorAlert(
        _ error: Error,
        title: String,
        presentingFromIfAvailable presentingVC: UIViewController? = nil,
        cancelAction: UIAlertAction = .cancel(title: "OK")
    ) {
        self.errorAlert(error.localizedDescription, title: title, presentingFromIfAvailable: presentingVC, cancelAction: cancelAction)
    }

    func configureNavigationBarToNormal() {
        let navigationBarAppearance = UINavigationBarAppearance()
        navigationBarAppearance.configureWithDefaultBackground()
        navigationController?.navigationBar.compactAppearance = navigationBarAppearance
        navigationController?.navigationBar.scrollEdgeAppearance = navigationBarAppearance
    }

    func presentActivityVC(forItems items: [Any]) {
        let vc = UIActivityViewController(activityItems: items, applicationActivities: nil)
        vc.popoverPresentationController?.sourceView = view
        let bounds = view.bounds

        vc.popoverPresentationController?.sourceRect = CGRect(x: bounds.midX, y: bounds.midY, width: 0, height: 0)
        self.present(vc, animated: true)
    }

    func createAlertWithSpinner(title: String, message: String? = nil, heightAnchorConstant: CGFloat = 95) -> UIAlertController {
        let alertController = UIAlertController(title: title, message: message, preferredStyle: .alert)
        let spinner = UIActivityIndicatorView()
        spinner.translatesAutoresizingMaskIntoConstraints = false
        spinner.startAnimating()
        alertController.view.addSubview(spinner)

        NSLayoutConstraint.activate([
            alertController.view.heightAnchor.constraint(equalToConstant: heightAnchorConstant),
            spinner.centerXAnchor.constraint(equalTo: alertController.view.centerXAnchor),
            spinner.bottomAnchor.constraint(equalTo: alertController.view.bottomAnchor, constant: -20),
        ])

        return alertController
    }

    func saveImage(_ image: UIImage) {
        UIImageWriteToSavedPhotosAlbum(image, self, #selector(didSaveImage(_:error:context:)), nil)
    }

    @objc
    func didSaveImage(_ im: UIImage, error: Error?, context: UnsafeMutableRawPointer?) {
        if let error = error {
            errorAlert(error, title: "Unable to save image")
        }
    }
}

extension UIMenu {
    func appending(_ element: UIMenuElement) -> UIMenu {
        var children = self.children
        children.append(element)
        return self.replacingChildren(children)
    }
}

extension UIAlertAction {
    static func cancel(title: String = "Cancel", handler: (() -> Void)? = nil) -> UIAlertAction {
        UIAlertAction(title: title, style: .cancel) { _ in
            handler?()
        }
    }
}

extension FileManager {

    func allocatedSizeOfDirectory(at directoryURL: URL) throws -> UInt64 {

        var enumeratorError: Error? = nil
        func errorHandler(_: URL, error: Error) -> Bool {
            enumeratorError = error
            return false
        }

        let enumerator = self.enumerator(at: directoryURL,
                                         includingPropertiesForKeys: Array(allocatedSizeResourceKeys),
                                         options: [],
                                         errorHandler: errorHandler)!

        var accumulatedSize: UInt64 = 0

        for item in enumerator {
            if enumeratorError != nil { break }

            let contentItemURL = item as! URL
            accumulatedSize += try contentItemURL.regularFileAllocatedSize()
        }

        if let error = enumeratorError { throw error }

        return accumulatedSize
    }
}

fileprivate let allocatedSizeResourceKeys: Set<URLResourceKey> = [
    .isRegularFileKey,
    .fileAllocatedSizeKey,
    .totalFileAllocatedSizeKey,
]

extension NSNotification.Name {
    static var pathGroupsDidChange: NSNotification.Name {
        return NSNotification.Name("pathGroupsDidChange")
    }
}

extension Date {
    func listFormatted() -> String {
        if #available(iOS 15.0, *) {
            return self.formatted(date: .long, time: .shortened)
        } else {
            let dateFormatter = DateFormatter()
            dateFormatter.dateStyle = .long
            dateFormatter.timeStyle = .short
            return dateFormatter.string(from: self)
        }
    }
}

extension Collection {
    subscript(safe safeIndex: Index) -> Element? {
        return self.indices.contains(safeIndex) ? self[safeIndex] : nil
    }
}

extension UTType {

    public static func generictypes() -> [UTType] {
        return [
            .content,
            .image,
            .video,
            .text,
            .audio,
            .movie,
            .sourceCode,
            .executable
        ]
    }

    public static func audioTypes() -> [UTType] {
        return [
            .mp3,
            .aiff,
            .wav,
            .midi
        ]
    }

    public static func programmingTypes() -> [UTType] {
        var arr: [UTType] = [
            .swiftSource,
            .assemblyLanguageSource,

            .cSource,
            .objectiveCSource,
            .objectiveCPlusPlusSource,
            .cPlusPlusSource,

            .cHeader,
            .cPlusPlusHeader,

            .script,
            .shellScript,
            .javaScript,
            .pythonScript,
            .rubyScript,
            .perlScript,
            .phpScript
        ]

        if #available(iOS 15.0, *) {
            arr.append(.makefile)
        }

        return arr
    }

    public static func compressedFormatTypes() -> [UTType] {
        return [
            .zip,
            .gzip,
            .bz2
        ]
    }

    public static func imageTypes() -> [UTType] {
        return [
            .png,
            .gif,
            .jpeg,
            .webP,
            .tiff,
            .bmp,
            .svg,
            .heif
        ]
    }

    public static func documentTypes() -> [UTType] {
        return [
            .json,
            .yaml,
            .rtf,
            .xml,
            .propertyList,
            .pdf
        ]
    }

    public static func systemTypes() -> [UTType] {
        return [
            .bundle,
            .application,
            .framework,
            .log,
            .database,
            .diskImage,
            .package
        ]
    }

    public static func executableTypes() -> [UTType] {
        return [
            .executable,
            UTType(filenameExtension: "dylib")
        ]
        .compactMap { $0 }
    }

    func isOfType(_ type: UTType) -> Bool {
        return type == self || self.isSubtype(of: type)
    }
}

extension UITableViewController {
    func indexPaths(forSection section: Int) -> [IndexPath] {
        let allRows = self.tableView(tableView, numberOfRowsInSection: section)
        return (0..<allRows).map { row in
            return IndexPath(row: row, section: section)
        }
    }

    func cellWithView(_ view: UIView, text: String, rightAnchorConstant: CGFloat = -20) -> UITableViewCell {
        let cell = UITableViewCell()
        var conf = cell.defaultContentConfiguration()
        conf.text = text
        cell.contentConfiguration = conf
        view.translatesAutoresizingMaskIntoConstraints = false
        cell.contentView.addSubview(view)

        NSLayoutConstraint.activate([
            view.rightAnchor.constraint(equalTo: cell.contentView.rightAnchor, constant: rightAnchorConstant),
            view.centerYAnchor.constraint(equalTo: cell.contentView.centerYAnchor)
        ])

        return cell
    }

    func sectionHeaderWithButton(
        sectionTag: Int,
        titleText: String?,
        buttonCustomization: (UIButton) -> Void
    ) -> UIView {
        let view = UIView()
        let label = UILabel()
        let button = UIButton()
        buttonCustomization(button)

        button.tag = sectionTag

        label.text = titleText
        label.font = .systemFont(ofSize: 18, weight: .bold)

        label.translatesAutoresizingMaskIntoConstraints = false
        button.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(label)
        view.addSubview(button)

        NSLayoutConstraint.activate([
            label.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 10),
            label.topAnchor.constraint(equalTo: view.topAnchor, constant: 10),

            button.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -5),
            button.topAnchor.constraint(equalTo: view.topAnchor, constant: 5),
        ])

        return view
    }

    func seperatorFooterView() -> UIView {
        let result = UIView()
        let insets = tableView.separatorInset
        let width = tableView.bounds.width - insets.left - insets.right
        let sepFrame = CGRect(x: insets.left, y: -0.5, width: width, height: 0.5)

        let sep = CALayer()
        sep.frame = sepFrame
        sep.backgroundColor = tableView.separatorColor?.cgColor
        result.layer.addSublayer(sep)

        return result
    }

    func deleteURL(_ path: Path, completionHandler: @escaping (Bool) -> Void) {
        let confirmationController = UIAlertController(title: "Are you sure you want to delete \"\(path.lastPathComponent)\"?", message: nil, preferredStyle: .alert)
        let deleteAction = UIAlertAction(title: SantanderL10n.t("Delete"), style: .destructive) { _ in
            do {
                try FSOperation.perform(.removeItems(items: [path.url]), rootHelperConf: RootConf.shared)
                completionHandler(true)
            } catch {
                self.errorAlert(error, title: "Failed to delete \"\(path.lastPathComponent)\"")
                completionHandler(false)
            }
        }

        let cancelAction: UIAlertAction = .cancel {
            completionHandler(false)
        }

        confirmationController.addAction(deleteAction)
        confirmationController.addAction(cancelAction)
        self.present(confirmationController, animated: true)
    }
}

extension UIImage {
    func imageWith(newSize: CGSize) -> UIImage {
        let image = UIGraphicsImageRenderer(size: newSize).image { _ in
            draw(in: CGRect(origin: .zero, size: newSize))
        }
        return image.withRenderingMode(renderingMode)
    }
}

extension UIAction {
    convenience init(withClosure closure: @escaping () -> Void) {
        self.init { _ in
            closure()
        }
    }
}

extension Optional: Comparable where Wrapped: Comparable {
    public static func < (lhs: Optional, rhs: Optional) -> Bool {
        guard let lhs = lhs, let rhs = rhs else {
            return false
        }
        return lhs < rhs
    }
}

extension UITableView.Style: CaseIterable, CustomStringConvertible {
    static var userPreferred: UITableView.Style {
        return UITableView.Style(rawValue: UserPreferences.preferredTableViewStyle) ?? .insetGrouped
    }

    public static var allCases: [UITableView.Style] = [.insetGrouped, .grouped, .plain]

    public var description: String {
        switch self {
        case .plain:
            return "Plain"
        case .grouped:
            return "Grouped"
        case .insetGrouped:
            return "Inset Grouped"
        @unknown default:
            return "Unknown Mode"
        }
    }
}

extension Array where Element: OptionSet {
    func reducingToSingleOptionSet() -> Element {
        return self.reduce(Element()) { return $0.union($1) }
    }
}

extension passwd {
    init?(fileURLOwner fileURL: URL) {
        var buffer = stat()
        guard lstat(fileURL.path, &buffer) == 0, let pwd = getpwuid(buffer.st_uid)?.pointee else {
            return nil
        }
        self = pwd
    }
}

extension UIUserInterfaceStyle: CaseIterable {
    public static var allCases: [UIUserInterfaceStyle] = [.unspecified, .dark, .light]
    var description: String {
        switch self {
        case .unspecified:
            return "System"
        case .light:
            return "Light"
        case .dark:
            return "Dark"
        @unknown default:
            return "Unknown Mode"
        }
    }
}

extension UITableViewCell {
    func colorCircleAccessoryView(color: UIColor) -> UIView {
        let colorPreview = UIView(frame: CGRect(x: 0, y: 0, width: 29, height: 29))
        colorPreview.backgroundColor = color
        colorPreview.layer.cornerRadius = colorPreview.frame.size.width / 2
        colorPreview.layer.borderWidth = 1.5
        colorPreview.layer.borderColor = UIColor.systemGray.cgColor

        return colorPreview
    }
}

extension Dictionary where Key == String, Value == SerializedItemType {
    func asAnyDictionary() -> [String: Any] {
        var dict: [String: Any] = [:]
        for (key, value) in self {
            dict[key] = value.representedObject
        }
        return dict
    }
}

extension Dictionary where Key == String, Value == Any {
    func asSerializedDictionary() -> SerializedDictionaryType {
        var dict: SerializedDictionaryType = [:]
        for (key, value) in self {
            dict[key] = SerializedItemType(item: value)
        }
        return dict
    }
}

extension UIDevice {
    static let isiPad = current.userInterfaceIdiom == .pad
}

extension DateFormatter {
    static let EXIFDateFormatter = DateFormatter(withFormat: "yyyy:MM:dd HH:mm:ss")
    static let IPTCDateFormatter = DateFormatter(withFormat: "yyyyMMdd")

    convenience init(withFormat dateFormat: String) {
        self.init()
        self.dateFormat = dateFormat
    }
}

extension UIApplication {
    var sceneKeyWindow: UIWindow? {
        return UIApplication.shared
        .connectedScenes
        .flatMap { ($0 as? UIWindowScene)?.windows ?? [] }
        .first { $0.isKeyWindow }
    }
}

extension CTFontDescriptor {
    var uiFont: UIFont {
        return CTFontCreateWithFontDescriptor(self, UserPreferences.fontViewerFontSize, nil) as UIFont
    }
}

extension UIPasteboard {
    var probableURL: URL? {
        if let url = url { return url }
        if let string = string, string.hasPrefix("/") { return URL(fileURLWithPath: string) }
        return nil
    }
}

extension UIApplication {
    func setShortcutItems<URLCollection: Collection<Path>>(intoURLs urls: URLCollection) {
        shortcutItems = urls.map { bookmark in
            return UIApplicationShortcutItem(type: bookmark.url.absoluteString,
                                             localizedTitle: bookmark.lastPathComponent,
                                             localizedSubtitle: bookmark.path,
                                             icon: nil,
                                             userInfo: ["ShortcutURLToOpenTo": bookmark.path] as [String: NSSecureCoding])
        }
    }
}

extension Array<Path> {
    func toURL() -> [URL] {
        map(\.url)
    }
}


@main
class AppDelegate: UIResponder, UIApplicationDelegate {

    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        var glassConfiguration = LegacyLiquidGlass.configuration
        glassConfiguration.backend = .legacy
        glassConfiguration.adaptiveQuality = true
        glassConfiguration.sharedSurface = true
        LegacyLiquidGlass.configuration = glassConfiguration
        LLGlassBootstrap.start()

        if UserPreferences.displayRecentlyBookmarked {
            application.setShortcutItems(intoURLs: UserPreferences.bookmarks)
        } else {
            application.shortcutItems = []
        }
        
        return true
    }


    func application(_ application: UIApplication, configurationForConnecting connectingSceneSession: UISceneSession, options: UIScene.ConnectionOptions) -> UISceneConfiguration {
        return UISceneConfiguration(name: "Default Configuration", sessionRole: connectingSceneSession.role)
    }

    func application(_ application: UIApplication, didDiscardSceneSessions sceneSessions: Set<UISceneSession>) {
    }


}


class SceneDelegate: UIResponder, UIWindowSceneDelegate {
    
    var window: UIWindow?
    var visibleSubPathsVc: PathListViewController? {
        (window?.rootViewController as? UINavigationController)?.visibleViewController as? PathListViewController
    }
    
    func performShortcut(_ shortcut: UIApplicationShortcutItem) {
        switch shortcut.type {
        case "com.Antoine.santander.bookmarks":
            let vc = UINavigationController(rootViewController: PathListViewController.bookmarks())
            window?.rootViewController?.present(vc, animated: true)
        default:
            if let pathToTopenTo = shortcut.userInfo?["ShortcutURLToOpenTo"] as? String {
                visibleSubPathsVc?.goToPath(path: Path(stringLiteral: pathToTopenTo))
            }
        }
    }
    
    func windowScene(_ windowScene: UIWindowScene,performActionFor shortcutItem: UIApplicationShortcutItem, completionHandler: @escaping (Bool) -> Void) {
        self.performShortcut(shortcutItem)
        completionHandler(true)
    }
    
    func scene(_ scene: UIScene, willConnectTo session: UISceneSession, options connectionOptions: UIScene.ConnectionOptions) {
        guard let windowScene = (scene as? UIWindowScene) else { return }
        
        let subPathsVC: PathTransitioning
        let window = UIWindow(windowScene: windowScene)
        if UIDevice.isiPad {
            let splitVC = UISplitViewController(style: .doubleColumn)
            let vc = PathSidebarListViewController()
            subPathsVC = vc
            splitVC.setViewController(vc, for: .primary)
            window.rootViewController = splitVC
        } else {
            let vc = PathListViewController(style: .userPreferred, path: .root)
            subPathsVC = vc
            window.rootViewController = UINavigationController(rootViewController: vc)
        }
        
        DispatchQueue.main.async {
            window.tintColor = UserPreferences.appTintColor.uiColor
            window.overrideUserInterfaceStyle = UIUserInterfaceStyle(rawValue: UserPreferences.preferredInterfaceStyle) ?? .unspecified
        }
        
        self.window = window
        
        (window.rootViewController as? UISplitViewController)?.show(.primary)
        if let launchPath = UserPreferences.launchPath,
            FileManager.default.fileExists(atPath: launchPath) {
            subPathsVC.goToPath(path: Path(stringLiteral: launchPath))
        }
        
        window.makeKeyAndVisible()
        self.scene(scene, openURLContexts: connectionOptions.urlContexts)
        if let shortcut = connectionOptions.shortcutItem {
            self.performShortcut(shortcut)
        }
    }
    
    func sceneDidDisconnect(_ scene: UIScene) {
    }
    
    func sceneDidBecomeActive(_ scene: UIScene) {
        if let window { LegacyLiquidGlass.sceneDidChange(in: window) }
    }
    
    func sceneWillResignActive(_ scene: UIScene) {
    }
    
    func sceneWillEnterForeground(_ scene: UIScene) {
        if let window { LegacyLiquidGlass.sceneDidChange(in: window) }
    }
    
    func sceneDidEnterBackground(_ scene: UIScene) {
    }
    
    
    func scene(_ scene: UIScene, openURLContexts URLContexts: Set<UIOpenURLContext>) {
        let urls = URLContexts.map { ctx in
            URL(fileURLWithPath: ctx.url.path)
        }
        guard !urls.isEmpty else {
            return
        }
  
        let alertController = UIAlertController(title: "URL(s) being imported to app, would you like to copy it to another path?", message: nil, preferredStyle: .alert)
        let copyAction = UIAlertAction(title: SantanderL10n.t("Copy Path"), style: .default) { _ in
            self.window?.rootViewController?.present(UINavigationController(rootViewController: PathOperationViewController(paths: urls, operationType: .import)), animated: true)
        }
        
        alertController.addAction(copyAction)
        if urls.count == 1 {
            let viewItemAction = UIAlertAction(title: SantanderL10n.t("View item"), style: .default) { _ in
                let item = urls[0]
                let itemParentPath = item.deletingLastPathComponent()
                let rootVC = self.window?.rootViewController as? UINavigationController
                let vcToPush = PathListViewController(path: Path(url: itemParentPath))
                rootVC?.pushViewController(vcToPush, animated: true) {
                    if let indx = vcToPush.contents.firstIndex(of: Path(url: item)) {
                        let indexPath = IndexPath(row: indx, section: 0)
                        vcToPush.tableView.scrollToRow(at: indexPath, at: .middle, animated: true)
                        vcToPush.tableView.selectRow(at: indexPath, animated: true, scrollPosition: .middle)
                    }
                }
            }
            
            alertController.addAction(viewItemAction)
        }
        
        alertController.addAction(.cancel())
        window?.rootViewController?.present(alertController, animated: true)
        
    }
}

fileprivate extension UINavigationController {
    func pushViewController(_ viewController: UIViewController, animated: Bool, completion: @escaping (() -> Void)) {
        pushViewController(viewController, animated: animated)
        
        guard animated, let coordinator = transitionCoordinator else {
            completion()
            return
        }
        
        coordinator.animate(alongsideTransition: nil) { _ in completion() }
    }
}


class AppInfoViewController: UITableViewController {
    let app: SantanderApplication
    let subPathsSender: PathListViewController

    init(style: UITableView.Style, app: SantanderApplication, subPathsSender: PathListViewController) {
        self.app = app
        self.subPathsSender = subPathsSender
        super.init(style: style)
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        applySantanderGlass()
        navigationItem.titleView = UIImageView(image: ApplicationsManager.shared.icon(forApplication: app))
    }

    override func numberOfSections(in tableView: UITableView) -> Int {
        return 5
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        switch section {
        case 0:
            return app.claimedURLSchemes.isEmpty ? 4 : 5
        case 1:
            return 2
        case 2:
            return 4
        case 3:
            return 2
        case 4:
            return 2
        default:
            fatalError("Unknown section! \(section)")
        }
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = UITableViewCell(style: .value1, reuseIdentifier: nil)
        var conf = cell.defaultContentConfiguration()

        defer {
            cell.contentConfiguration = conf
        }

        switch (indexPath.section, indexPath.row) {
        case (0, 0):
            conf.text = "Name"
            conf.secondaryText = app.localizedName
        case (0, 1):
            conf.text = "Bundle ID"
            conf.secondaryText = app.applicationIdentifier
        case (0, 2):
            conf.text = "SDK Version"
            conf.secondaryText = app.sdkVersion
        case (0, 3):
            conf.text = "Type"
            conf.secondaryText = app.applicationType
        case (0, 4):
            conf.text = "URL schemes"
            conf.secondaryText = app.claimedURLSchemes.joined(separator: ", ")
        case (1, 0):
            conf.text = "Team ID"
            conf.secondaryText = app.teamID
        case (1, 1):
            conf.text = "Entitlements"
            cell.accessoryType = .disclosureIndicator
        case (2, 0):
            conf.text = "Deletable"
            conf.secondaryText = app.isDeletable ? "Yes" : "No"
        case (2, 1):
            conf.text = "Beta app"
            conf.secondaryText = app.isBetaApp ? "Yes" : "No"
        case (2, 2):
            conf.text = "Restricted"
            conf.secondaryText = app.isRestricted ? "Yes" : "No"
        case (2, 3):
            conf.text = "Containerized"
            conf.secondaryText = app.isContainerized ? "Yes" : "No"
        case (3, 0):
            conf.text = "Container URL"
            conf.secondaryText = app.containerURL().path
        case (3, 1):
            conf.text = "Bundle URL"
            conf.secondaryText = app.bundleURL().path
        case (4, 0):
            conf.text = "Open"
            conf.textProperties.color = .systemBlue
        case (4, 1):
            conf.text = "Delete"
            conf.textProperties.color = .systemRed
        default:
            fatalError("Unknown indexPath: \(indexPath)")
        }

        return cell
    }

    override func tableView(_ tableView: UITableView, shouldHighlightRowAt indexPath: IndexPath) -> Bool {
        switch indexPath.section {
        case 3, 4:
            return true
        default:
            return (indexPath.section, indexPath.row) == (1, 1)
        }
    }

    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        switch (indexPath.section, indexPath.row) {
        case (1, 1):
            let dict = app.entitlements.asSerializedDictionary()
            let vc = SerializedDocumentViewController(dictionary: dict, type: .plist(format: nil), title: "Entitlements", parentController: nil, canEdit: false)
            self.navigationController?.pushViewController(vc, animated: true)
        case (3, 0):
            dismissAndGoToURL(app.containerURL())
        case (3, 1):
            dismissAndGoToURL(app.bundleURL())
        case (4, 0):
            do {
                try ApplicationsManager.shared.openApp(app)
            } catch {
                self.errorAlert(error, title: "Unable to open \(app.localizedName)")
            }
        case (4, 1):
            do {
                try ApplicationsManager.shared.deleteApp(app)
                self.dismiss(animated: true)
                subPathsSender.tableView.reloadData()
            } catch {
                self.errorAlert(error, title: "Unable to delete app")
            }
        default:
            break
        }
    }

    func dismissAndGoToURL(_ url: URL) {
        self.dismiss(animated: true)
        subPathsSender.goToPath(path: Path(url: url))
    }
}

class FilePreviewDataSource: QLPreviewControllerDataSource {
    func numberOfPreviewItems(in controller: QLPreviewController) -> Int {
        return 1
    }

    func previewController(_ controller: QLPreviewController, previewItemAt index: Int) -> QLPreviewItem {
        return fileURL as QLPreviewItem
    }

    let fileURL: URL

    init(fileURL: URL) {
        self.fileURL = fileURL
    }
}

class SettingsTableViewController: UITableViewController {

    lazy var colorPickerVC: UIColorPickerViewController = {
        let vc = UIColorPickerViewController()
        vc.selectedColor = UserPreferences.appTintColor.uiColor
        vc.delegate = self
        return vc
    }()

    override func viewDidLoad() {
        super.viewDidLoad()
        applySantanderGlass()

        self.title = SantanderL10n.t("Settings")
        self.navigationController?.navigationBar.prefersLargeTitles = false
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    override init(style: UITableView.Style) {
        super.init(style: style)
    }

    override func numberOfSections(in tableView: UITableView) -> Int {
        return 4
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        switch section {
        case 0: return 1
        case 1: return 4
        case 2: return 3
        case 3: return UserPreferences.useLastOpenedPathWhenLaunching ? 1 : 2
        default: fatalError("How'd we get here?")
        }
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        switch (indexPath.section, indexPath.row) {
        case (0, 0):
            return cellWithView(settingsSwitch(forIndexPath: indexPath), text: "Root Helper")
        case (1, 0):
            return cellWithView(settingsSwitch(forIndexPath: indexPath), text: "Large navigation titles")
        case (1, 1):
            return cellWithView(settingsSwitch(forIndexPath: indexPath), text: "Always show search bar")
        case (1, 2):
            return cellWithView(settingsSwitch(forIndexPath: indexPath), text: "Show information button")
        case (1, 3):
            return cellWithView(settingsSwitch(forIndexPath: indexPath), text: "List recently used items in application shortcuts")
        case (2, 0):
            let cell = UITableViewCell()
            var conf = cell.defaultContentConfiguration()
            conf.text = "Tint Color"
            cell.contentConfiguration = conf

            cell.accessoryView = cell.colorCircleAccessoryView(color: UserPreferences.appTintColor.uiColor)
            return cell
        case (2, 1):
            return cellWithView(setupStyleButton(), text: "Table View Style")
        case (2, 2):
            return cellWithView(setupAppearanceButton(), text: "Appearance")
        case (3, 0):
            return cellWithView(setupLaunchPathButton(), text: "Launch Path")
        case (3, 1):
            let cell = UITableViewCell(style: .value1, reuseIdentifier: nil)
            var conf = cell.defaultContentConfiguration()
            conf.text = "Custom Launch Path"
            conf.secondaryText = UserPreferences.userPreferredLaunchPath ?? "N/A"
            cell.contentConfiguration = conf
            return cell
        default: fatalError()
        }
    }

    fileprivate func setupAppearanceButton() -> UIButton {
        let button = UIButton()
        let currentStyle = UIUserInterfaceStyle(rawValue: UserPreferences.preferredInterfaceStyle) ?? .unspecified
        button.setTitle(currentStyle.description, for: .normal)
        button.setTitleColor(.systemGray, for: .normal)

        let chosenStyle = UserPreferences.preferredInterfaceStyle
        let actions = UIUserInterfaceStyle.allCases.map { style in
            return UIAction(title: style.description, state: chosenStyle == style.rawValue ? .on : .off) { _ in
                self.view.window?.overrideUserInterfaceStyle = style
                UserPreferences.preferredInterfaceStyle = style.rawValue
                self.tableView.reloadRows(at: [IndexPath(row: 2, section: 2)], with: .fade)
            }
        }

        button.menu = UIMenu(children: actions)
        button.showsMenuAsPrimaryAction = true
        return button
    }

    fileprivate func setupStyleButton() -> UIButton {
        let button = UIButton()
        let selectedStyle = UITableView.Style.userPreferred

        button.setTitle(selectedStyle.description, for: .normal)
        button.setTitleColor(.systemGray, for: .normal)
        let actions = UITableView.Style.allCases.map { style in
            return UIAction(title: style.description, state: selectedStyle == style ? .on : .off) { _ in
                UserPreferences.preferredTableViewStyle = style.rawValue
                self.tableView.reloadRows(at: [IndexPath(row: 1, section: 2)], with: .none)
            }
        }

        button.menu = UIMenu(children: actions)
        button.showsMenuAsPrimaryAction = true
        return button
    }

    fileprivate func setupLaunchPathButton() -> UIButton {
        let button = UIButton()

        let customPathChosen = !UserPreferences.useLastOpenedPathWhenLaunching
        button.setTitle(customPathChosen ? "Custom Path" : "Last Opened Path", for: .normal)
        button.setTitleColor(.systemGray, for: .normal)

        let lastOpenedPathAction = UIAction(title: "Last Opened Path", state: UserPreferences.useLastOpenedPathWhenLaunching ? .on : .off) { _ in
            UserPreferences.useLastOpenedPathWhenLaunching = true
            self.tableView.reloadData()
        }

        let otherPathAction = UIAction(title: "Custom Path", state: customPathChosen ? .on : .off) { _ in
            UserPreferences.useLastOpenedPathWhenLaunching = false
            if UserPreferences.userPreferredLaunchPath == nil {
                self.changeCustomLaunchPathAlert()
            } else {
                self.tableView.reloadData()
            }
        }

        button.menu = UIMenu(children: [lastOpenedPathAction, otherPathAction])
        button.showsMenuAsPrimaryAction = true
        return button
    }

    override func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        switch section {
        case 0: return "Root"
        case 1: return "Views"
        case 2: return "Theming"
        case 3: return "Other"
        default: return nil
        }
    }

    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        switch (indexPath.section, indexPath.row) {
        case (2, 0):
            self.present(colorPickerVC, animated: true)
        case (3, 1):
            self.changeCustomLaunchPathAlert()
        default:
            break
        }
    }

    override func tableView(_ tableView: UITableView, shouldHighlightRowAt indexPath: IndexPath) -> Bool {
        return (indexPath.section, indexPath.row) == (2, 0) || (indexPath.section, indexPath.row) == (3, 1)
    }

    func defaultsKey(forIndexPath indexPath: IndexPath) -> String {
        switch (indexPath.section, indexPath.row) {
        case (0, 0):
            return "RootHelperEnabled"
        case (1, 0):
            return "UseLargeNavTitles"
        case (1, 1):
            return "AlwaysShowSearchBar"
        case (1, 2):
            return "ShowInfoButton"
        case (1, 3):
            return "DisplayRecentlyUsedPathsInAppShortcuts"
        default:
            fatalError()
        }
    }

    fileprivate func changeCustomLaunchPathAlert() {
        let alert = UIAlertController(title: "Path", message: "Enter the other path you want to be opened at launch", preferredStyle: .alert)
        alert.addTextField()
        alert.addAction(.cancel())

        let applyAction = UIAlertAction(title: SantanderL10n.t("Add"), style: .default) { _ in
            guard let text = alert.textFields?.first?.text, !text.isEmpty else {
                self.errorAlert("Input text is invalid or empty", title: "Unable to set path as Launch Path")
                return
            }

            let url = URL(fileURLWithPath: text)
            guard url.isDirectory else {
                self.errorAlert("Path must be a directory", title: "Unable to set path as Launch Path")
                return
            }

            UserPreferences.useLastOpenedPathWhenLaunching = false
            UserPreferences.userPreferredLaunchPath = url.path
        }
        alert.addAction(applyAction)
        self.present(alert, animated: true)
    }

    func switchOptionIsEnabled(forIndexPath indexPath: IndexPath) -> Bool {
        switch (indexPath.section, indexPath.row) {
        case (0, 0):
            return UserPreferences.rootHelperIsEnabled
        case (1, 0):
            return UserPreferences.useLargeNavigationTitles
        case (1, 1):
            return UserPreferences.alwaysShowSearchBar
        case (1, 2):
            return UserPreferences.showInfoButton
        case (1, 3):
            return UserPreferences.displayRecentlyBookmarked
        default:
            fatalError("Got unknown index path in \(#function)! IndexPath: \(indexPath)")
        }
    }

    func settingsSwitch(forIndexPath indexPath: IndexPath) -> UISwitch {
        let s = UISwitch()
        s.isOn = switchOptionIsEnabled(forIndexPath: indexPath)
        let action = UIAction { [self] _ in
            if (indexPath.section, indexPath.row) == (0, 0) {
                rootHelperDidClickEnable()
            } else {
                UserDefaults.standard.set(s.isOn, forKey: defaultsKey(forIndexPath: indexPath))
            }
        }

        s.addAction(action, for: .valueChanged)
        return s
    }

    fileprivate func rootHelperDidClickEnable() {
        let context = LAContext()
        if UserPreferences.rootHelperIsEnabled || !context.canEvaluatePolicy(.deviceOwnerAuthentication, error: nil) {
            UserPreferences.rootHelperIsEnabled.toggle()
            return
        }

        context.evaluatePolicy(.deviceOwnerAuthentication, localizedReason: "To enable the Root Helper.") { didSucceed, error in
            guard didSucceed else {
                DispatchQueue.main.async {
                    self.errorAlert(error?.localizedDescription ?? "Unknown Error", title: "Unable to authenticate")
                    self.tableView.reloadRows(at: [IndexPath(row: 0, section: 0)], with: .automatic)
                }
                return
            }

            UserPreferences.rootHelperIsEnabled = true
            DispatchQueue.main.async {
                self.tableView.reloadRows(at: [IndexPath(row: 0, section: 0)], with: .automatic)
            }
        }
    }
}

extension SettingsTableViewController: UIColorPickerViewControllerDelegate {
    func colorPickerViewControllerDidFinish(_ viewController: UIColorPickerViewController) {
        let color = viewController.selectedColor

        DispatchQueue.main.async {
            UserPreferences.appTintColor = CodableColor(color)
            self.view.window?.tintColor = color
            self.tableView.reloadRows(at: [IndexPath(row: 0, section: 2)], with: .fade)
        }
    }
}

class TypesSelectionCollectionViewController: UICollectionViewController {
    typealias DismissHandler = (([UTType]) -> Void)

    typealias Item = DiffableDataSourceItem<Section, UTType>
    typealias DataSource = UICollectionViewDiffableDataSource<Section, Item>
    typealias CellRegistration = UICollectionView.CellRegistration<UICollectionViewListCell, Item>

    var dismissHandler: DismissHandler
    var dataSource: DataSource!
    var selectedTypes: Set<UTType> = [] {
        didSet {
            navigationItem.rightBarButtonItem?.isEnabled = !selectedTypes.isEmpty
        }
    }

    let allItems = TypesCollection.all()

    init(dismissHandler: @escaping DismissHandler) {
        self.dismissHandler = dismissHandler

        let layout = UICollectionViewCompositionalLayout { _, env in
            var layoutConf = UICollectionLayoutListConfiguration(appearance: .insetGrouped)
            layoutConf.headerMode = .firstItemInSection
            return NSCollectionLayoutSection.list(using: layoutConf, layoutEnvironment: env)
        }

        super.init(collectionViewLayout: layout)
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    override func viewDidLoad() {
        title = SantanderL10n.t("Types")

        let cancelAction = UIAction {
            self.selectedTypes = []
            self.dismiss(animated: true)
        }

        let doneAction = UIAction {
            self.dismiss(animated: true)
        }

        let searchController = UISearchController()
        searchController.searchBar.delegate = self
        navigationItem.searchController = searchController
        navigationItem.hidesSearchBarWhenScrolling = false

        navigationItem.leftBarButtonItem = UIBarButtonItem(systemItem: .cancel, primaryAction: cancelAction)
        let rightBarButton = UIBarButtonItem(systemItem: .done, primaryAction: doneAction)
        rightBarButton.isEnabled = false
        navigationItem.rightBarButtonItem = rightBarButton
        makeDataSource()
    }

    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
        dismissHandler(Array(selectedTypes))
    }

    func makeDataSource() {
        let cellRegistration = CellRegistration { [self] cell, indexPath, itemIdentifier in
            var conf: UIListContentConfiguration
            switch itemIdentifier {
            case .section(let section):
                conf = .sidebarHeader()
                conf.text = section.description
                cell.accessories = [.outlineDisclosure()]
            case .item(let type):
                conf = cell.defaultContentConfiguration()
                conf.text = type.localizedDescription
                cell.accessories = selectedTypes.contains(type) ? [.checkmark()] : []
            }

            cell.contentConfiguration = conf
        }

        self.dataSource = DataSource(collectionView: collectionView) { collectionView, indexPath, itemIdentifier in
            return collectionView.dequeueConfiguredReusableCell(using: cellRegistration, for: indexPath, item: itemIdentifier)
        }

        showItems(fromCollections: allItems)
    }

    func showItems(fromCollections coll: [TypesCollection], animatingDifferences: Bool = false) {
        var snapshot = NSDiffableDataSourceSnapshot<Section, Item>()
        let justSections = coll.map(\.section)
        snapshot.appendSections(justSections)
        dataSource.apply(snapshot, animatingDifferences: false)

        for collection in coll {
            let collectionSection = Item.section(collection.section)
            var section = NSDiffableDataSourceSectionSnapshot<Item>()
            section.append([collectionSection])

            let types = Item.fromItems(collection.types)
            section.append(types, to: collectionSection)
            section.expand([collectionSection])
            dataSource.apply(section, to: collection.section, animatingDifferences: animatingDifferences)
        }
    }

    override func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        collectionView.deselectItem(at: indexPath, animated: false)
        let item = dataSource.itemIdentifier(for: indexPath)!
        switch item {
        case .section(_): break
        case .item(let type):
            if selectedTypes.contains(type) {
                selectedTypes.remove(type)
            } else {
                selectedTypes.insert(type)
            }

            var snapshot = dataSource.snapshot()
            snapshot.reloadItems([.item(type)])
            dataSource.apply(snapshot, animatingDifferences: true)
        }
    }

    enum Section: CustomStringConvertible {
        case generic
        case audio
        case programming
        case archive
        case image
        case document
        case executable
        case systemTypes

        var description: String {
            switch self {
            case .generic:
                return "Generic"
            case .audio:
                return "Audio"
            case .programming:
                return "Programming"
            case .archive:
                return "Archive"
            case .image:
                return "Image"
            case .document:
                return "Document"
            case .executable:
                return "Executable"
            case .systemTypes:
                return "System"
            }
        }
    }

    struct TypesCollection {
        let section: Section
        let types: [UTType]

        static func all() -> [TypesCollection] {
            return [
                TypesCollection(section: .generic, types: UTType.generictypes()),
                TypesCollection(section: .audio, types: UTType.audioTypes()),
                TypesCollection(section: .programming, types: UTType.programmingTypes()),
                TypesCollection(section: .archive, types: UTType.compressedFormatTypes()),
                TypesCollection(section: .image, types: UTType.imageTypes()),
                TypesCollection(section: .document, types: UTType.documentTypes()),
                TypesCollection(section: .systemTypes, types: UTType.systemTypes())
            ]
        }
    }
}

extension TypesSelectionCollectionViewController: UISearchBarDelegate {
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        guard !searchText.isEmpty else {
            showItems(fromCollections: allItems)
            return
        }

        var newCollection: [TypesCollection] = []
        for collection in allItems {
            let filtered = collection.types.filter { type in
                type.localizedDescription?.localizedCaseInsensitiveContains(searchText) ?? false ||
                type.preferredFilenameExtension?.localizedCaseInsensitiveContains(searchText) ?? false
            }

            if !filtered.isEmpty {
                newCollection.append(TypesCollection(section: collection.section, types: filtered))
            }
        }

        showItems(fromCollections: newCollection, animatingDifferences: false)
    }

    func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
        showItems(fromCollections: allItems)
    }
}

class PathPermissionsViewController: UITableViewController {
    var permissions: PathPermissions

    let _permissionsClone: PathPermissions

    lazy var editAction = UIAction {
        self.setEditing(!self.isEditing, animated: true)
    }

    init(style: UITableView.Style = .insetGrouped, permissions: PathPermissions) {
        self.permissions = permissions
        self._permissionsClone = permissions

        super.init(style: style)
        self.title = SantanderL10n.t("Permissions")
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        applySantanderGlass()

        navigationItem.rightBarButtonItem = UIBarButtonItem(systemItem: .edit, primaryAction: editAction)
        tableView.allowsSelectionDuringEditing = true
    }

    override func numberOfSections(in tableView: UITableView) -> Int {
        return 3
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        switch section {
        case 0, 1: return 4
        case 2: return 3
        default: fatalError("How did we get here?!")
        }
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        return cell(atIndexPath: indexPath)
    }

    override func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        switch section {
        case 0: return "Owner"
        case 1: return "Group"
        case 2: return "Other users"
        default: return nil
        }
    }

    override func tableView(_ tableView: UITableView, titleForFooterInSection section: Int) -> String? {
        section == 2 ? permissionSummary : nil
    }

    func cell(
        atIndexPath indexPath: IndexPath
    ) -> UITableViewCell {
        let cell = UITableViewCell(style: .value1, reuseIdentifier: nil)
        let permSet: Permission
        var firstRowText: String? = nil
        var firstRowSecondaryText: String? = nil

        switch indexPath.section {
        case 0:
            permSet = self.permissions.ownerPermissions
            firstRowText = "Owner"
            firstRowSecondaryText = "\(self.permissions.ownerName ?? "Unknown") (\(self.permissions.ownerID))"
        case 1:
            permSet = self.permissions.groupPermissions
            firstRowText = "Group"
            firstRowSecondaryText = "\(self.permissions.groupOwnerName ?? "Unknown") (\(self.permissions.groupID))"
        case 2:
            permSet = self.permissions.otherUsersPermissions
        default:
            fatalError()
        }

        var conf = cell.defaultContentConfiguration()
        defer {
            cell.contentConfiguration = conf
        }

        if indexPath.row == correctRow(0, indexPath: indexPath) {
            conf.text = firstRowText
            conf.secondaryText = firstRowSecondaryText ?? "N/A"
            cell.accessoryType = .disclosureIndicator
            cell.editingAccessoryType = .disclosureIndicator
            cell.isUserInteractionEnabled = tableView(self.tableView, shouldHighlightRowAt: indexPath)
            return cell
        }

        let toCheck = permissionAtRow(atIndexPath: indexPath)
        switch indexPath.row {
        case correctRow(1, indexPath: indexPath):
            conf.text = "Read"
            conf.secondaryText = permSet.contains(toCheck) ? "Yes" : "No"
        case correctRow(2, indexPath: indexPath):
            conf.text = "Write"
            conf.secondaryText = permSet.contains(toCheck) ? "Yes" : "No"
        case correctRow(3, indexPath: indexPath):
            conf.text = "Execute"
            conf.secondaryText = permSet.contains(toCheck) ? "Yes" : "No"
        default:
            fatalError("Shouldn't have gotten here! row received: \(indexPath.row)")
        }

        if self.isEditing {
            conf.secondaryText = nil
            if permSet.contains(toCheck) {
                cell.editingAccessoryType = .checkmark
            }
        }

        return cell
    }

    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if indexPath.row == correctRow(0, indexPath: indexPath) {
            let type: PathGroupOwnerViewController.ItemType
            switch indexPath.section {
            case 0:
                type = .owner(id: permissions.ownerID, name: permissions.ownerName)
            case 1:
                type = .group(id: permissions.groupID, name: permissions.groupOwnerName)
            default:
                fatalError()
            }
            self.navigationController?.pushViewController(
                PathGroupOwnerViewController(
                    style: .insetGrouped,
                    type: type,
                    sourceVC: self,
                    fileURL: permissions.fileURL
                ),
                animated: true
            )
            return
        }

        guard self.isEditing else {
            return
        }

        let perm = permissionAtRow(atIndexPath: indexPath)
        switch indexPath.section {
        case 0:
            removeOrAddPermission(fromOptionSet: &permissions.ownerPermissions, forPermission: perm)
        case 1:
            removeOrAddPermission(fromOptionSet: &permissions.groupPermissions, forPermission: perm)
        case 2:
            removeOrAddPermission(fromOptionSet: &permissions.otherUsersPermissions, forPermission: perm)
        default:
            break
        }
        tableView.reloadRows(at: [indexPath], with: .fade)
    }

    override func tableView(_ tableView: UITableView, shouldHighlightRowAt indexPath: IndexPath) -> Bool {
        if indexPath.row == correctRow(0, indexPath: indexPath) {
            return indexPath.section == 0 || indexPath.section == 1
        }

        return self.isEditing
    }

    var permissionSummary: String {
        let values = [permissions.ownerPermissions, permissions.groupPermissions, permissions.otherUsersPermissions]
        let bits = values.map { set -> String in
            let read = set.contains(.read) ? "r" : "-"
            let write = set.contains(.write) ? "w" : "-"
            let execute = set.contains(.execute) ? "x" : "-"
            return read + write + execute
        }.joined()
        let octal = Permission.octalRepresentation(of: values)
        return String(format: "%04o  %@", octal, bits)
    }

    func permissionAtRow(atIndexPath indexPath: IndexPath) -> Permission {
        switch indexPath.row {
        case correctRow(1, indexPath: indexPath):
            return .read
        case correctRow(2, indexPath: indexPath):
            return .write
        case correctRow(3, indexPath: indexPath):
            return .execute
        default:
            fatalError()
        }
    }

    func correctRow(_ num: Int, indexPath: IndexPath) -> Int {
        return indexPath.section == 2 ? num - 1 : num
    }

    override func setEditing(_ editing: Bool, animated: Bool) {
        super.setEditing(editing, animated: animated)

        navigationItem.rightBarButtonItem = UIBarButtonItem(
            systemItem: editing ? .done : .edit,
            primaryAction: editAction
        )

        if !editing, permissions != _permissionsClone {
            do {
                try permissions.apply()
            } catch {
                self.errorAlert(error, title: "Unable to change permissions of \"\(permissions.fileURL.lastPathComponent)\"")
                self.permissions = _permissionsClone
            }
        }

        self.tableView.reloadData()
    }

    override func tableView(_ tableView: UITableView, shouldIndentWhileEditingRowAt indexPath: IndexPath) -> Bool {
        return false
    }

    override func tableView(_ tableView: UITableView, editingStyleForRowAt indexPath: IndexPath) -> UITableViewCell.EditingStyle {
        return .none
    }

    func removeOrAddPermission(fromOptionSet set: inout Permission, forPermission perm: Permission) {
        if set.contains(perm) {
            set.remove(perm)
        } else {
            set.insert(perm)
        }
    }
}

class GoToView: UIView {
    let xButton = UIButton()
    let searchField = UITextField()

    override init(frame: CGRect) {
        super.init(frame: frame)
        setup()
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    func setup() {
        layer.cornerRadius = 10
        layer.masksToBounds = true

        let glassView = LLGlassView(configuration: SantanderGlass.search)
        glassView.translatesAutoresizingMaskIntoConstraints = false
        insertSubview(glassView, at: 0)
        glassView.constraintCompletely(to: self)

        let glassImage = UIImageView(image: UIImage(systemName: "magnifyingglass")?.applyingSymbolConfiguration(UIImage.SymbolConfiguration(pointSize: 30))?.withTintColor(.systemGray, renderingMode: .alwaysOriginal))
        glassImage.translatesAutoresizingMaskIntoConstraints = false
        glassImage.contentScaleFactor = 1.0
        glassView.glassContentView.addSubview(glassImage)

        searchField.tintColor = .label
        searchField.font = .systemFont(ofSize: 30)
        searchField.translatesAutoresizingMaskIntoConstraints = false
        searchField.placeholder = "Search"
        glassView.glassContentView.addSubview(searchField)

        xButton.translatesAutoresizingMaskIntoConstraints = false
        xButton.setImage(UIImage(systemName: "xmark.circle.fill")?.applyingSymbolConfiguration(UIImage.SymbolConfiguration(pointSize: 30))?.withTintColor(.systemGray, renderingMode: .alwaysOriginal), for: .normal)
        glassView.glassContentView.addSubview(xButton)

        let stackView = UIStackView(arrangedSubviews: [glassImage, searchField, xButton])
        stackView.translatesAutoresizingMaskIntoConstraints = false
        stackView.spacing = 5
        stackView.distribution = .fillProportionally
        glassView.glassContentView.addSubview(stackView)
        NSLayoutConstraint.activate([
            stackView.leadingAnchor.constraint(equalTo: glassView.glassContentView.layoutMarginsGuide.leadingAnchor),
            stackView.trailingAnchor.constraint(equalTo: glassView.glassContentView.layoutMarginsGuide.trailingAnchor),
            stackView.topAnchor.constraint(equalTo: glassView.glassContentView.layoutMarginsGuide.topAnchor, constant: 10)
        ])
        searchField.becomeFirstResponder()
    }
}

extension PathListViewController: UISearchResultsUpdating, UISearchControllerDelegate, UISearchBarDelegate {

    func updateSearchResults(for searchController: UISearchController) {
        updateResults(searchBar: searchController.searchBar)
    }

    func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
        DispatchQueue.main.async { [self] in
            searchItem?.cancel()
            isSearching = false
            displayingSearchSuggestions = false
            reloadTableData()

            setupPermissionDeniedLabelIfNeeded()
        }
    }

    func searchBar(_ searchBar: UISearchBar, selectedScopeButtonIndexDidChange selectedScope: Int) {
        updateResults(searchBar: searchBar)
    }

    @objc
    func updateResults(searchBar: UISearchBar) {
        let selectedScope = searchBar.selectedScopeButtonIndex
        let query = SearchQuery(searchBar: searchBar)

        self.searchItem?.cancel()
        isSearching = true
        guard !query.isEmpty else { return }
        displayingSearchSuggestions = false

        let newWorkItem = DispatchWorkItem(qos: .userInteractive) { [self] in

            switch selectedScope {
            case 0:
                let filtered = unfilteredContents.filter { url in
                    return query.matches(url: url)
                }

                DispatchQueue.main.async {
                    self.setFilteredContents(filtered)
                }

            case 1:
                var snapshot = SnapshotType()
                snapshot.appendSections([0])
                __enumeratePaths(unfilteredContents, withQuery: query, doBreak: { !isSearching }) { [self] path in
                    DispatchQueue.main.async {
                        let row: SubPathsRowItem = .path(path)
                        if !snapshot.itemIdentifiers.contains(row) {
                            snapshot.appendItems([row])
                            self.dataSource.apply(snapshot, animatingDifferences: false)
                        }
                    }
                }
            default:
                break
            }
        }

        self.searchItem = newWorkItem
        DispatchQueue.global(qos: .userInteractive).asyncAfter(
            deadline: .now().advanced(by: .milliseconds(2)),
            execute: newWorkItem
        )
    }

    func presentSearchController(_ searchController: UISearchController) {
        if isEditing {
            setEditing(false, animated: true)
        }

        switchToSearchSuggestions()
        permissionDeniedLabel?.removeFromSuperview()
    }

    private func __enumeratePaths(_ paths: [Path], withQuery query: SearchQuery, doBreak: () -> Bool, handler: (Path) -> ()) {
        for path in paths {
            if doBreak() { break }

            if query.matches(url: path) {
                handler(path)
            }

            if path.isDirectory {
                __enumeratePaths(path.contents, withQuery: query, doBreak: doBreak, handler: handler)
            }
        }
    }

    fileprivate struct SearchQuery {
        let searchText: String
        let conditions: [SearchSuggestion.Condition]
        let isSearchTextEmpty: Bool

        func matches(url: Path) -> Bool {
            let allConditionsSatisfied = conditions.allSatisfy { handler in
                handler(url)
            }

            if isSearchTextEmpty {
                return allConditionsSatisfied
            }

            return url.lastPathComponent.localizedCaseInsensitiveContains(searchText) && allConditionsSatisfied
        }

        var isEmpty: Bool {
            return isSearchTextEmpty && conditions.isEmpty
        }

        init(searchText: String, conditions: [SearchSuggestion.Condition]) {
            self.searchText = searchText
            self.conditions = conditions

            self.isSearchTextEmpty = searchText.isEmpty
        }

        init(searchBar: UISearchBar) {
            self.searchText = searchBar.text ?? ""
            self.conditions = searchBar.searchTextField.tokens.compactMap { $0.representedObject as? SearchSuggestion.Condition }

            self.isSearchTextEmpty = searchText.isEmpty
        }
    }
}

@available(iOS 14.0, *)
struct SearchSuggestion: Hashable {

    typealias Condition = (Path) -> Bool

    var name: String

    let image: UIImage?

    var condition: Condition

    var searchToken: UISearchToken {
        let token = UISearchToken(icon: image, text: name)
        token.representedObject = condition
        return token
    }

    static func displaySearchSuggestions(for indexPath: IndexPath, typesToCheck: [UTType]? = nil) -> SearchSuggestion {
        switch (indexPath.section, indexPath.row) {
        case (0, 0):
            return SearchSuggestion(name: "Type", image: UIImage(systemName: "menucard")) { url in
                guard let typesToCheck = typesToCheck, let urlType = url.contentType else {
                    return false
                }

                let isSubtype = typesToCheck.contains { type in
                    urlType.isSubtype(of: type)
                }

                return typesToCheck.contains(urlType) || isSubtype
            }

        case (1, 0):
            return SearchSuggestion(name: "File", image: UIImage(systemName: "doc")) { url in
                return !url.isDirectory
            }
        case (1, 1):
            return SearchSuggestion(name: "Directory", image: UIImage(systemName: "folder")) { url in
                return url.isDirectory
            }
        case (1, 2):
            return SearchSuggestion(name: "Symbolic Link", image: UIImage(systemName: "link")) { url in
                return url.url.isSymlink
            }
        case (2, 0):
            return SearchSuggestion(name: "Executable", image: UIImage(systemName: "terminal")) { url in
                return !url.isDirectory && FileManager.default.isExecutableFile(atPath: url.path)
            }
        case (2, 1):
            return SearchSuggestion(name: "Readable", image: UIImage(systemName: "book")) { url in
                return url.isReadable
            }
        case (2, 2):
            return SearchSuggestion(name: "Writable", image: UIImage(systemName: "pencil")) { url in
                return FileManager.default.isWritableFile(atPath: url.path)
            }
        default: fatalError()
        }
    }

    static let searchSuggestionSectionAndRows = [
        IndexPath(row: 0, section: 0),
        IndexPath(row: 0, section: 1), IndexPath(row: 1, section: 1), IndexPath(row: 2, section: 1),
        IndexPath(row: 0, section: 2), IndexPath(row: 1, section: 2), IndexPath(row: 2, section: 2)
    ]

    static func == (lhs: SearchSuggestion, rhs: SearchSuggestion) -> Bool {
        return lhs.name == rhs.name && lhs.image == rhs.image
    }

    func hash(into hasher: inout Hasher) {
        hasher.combine(self.name)
        hasher.combine(self.image)
    }
}

class PathListViewController: UITableViewController, PathTransitioning {

    var unfilteredContents: [Path]

    var filteredSearchContents: [Path] = []

    var selectedItems: [Path] = []

    var isSearching: Bool = false

    var contents: [Path] {
        get {
            return filteredSearchContents.isEmpty && !self.isSearching ? unfilteredContents : filteredSearchContents
        }
    }

    var sortMethod: PathsSortMethods = .userPrefered ?? .alphabetically {
        willSet {
            UserDefaults.standard.set(newValue.rawValue, forKey: "SubPathsSortMode")
            sortContents()
        }
    }

    let isBookmarksSheet: Bool

    var currentPath: Path? = nil

    let showInfoButton: Bool = UserPreferences.showInfoButton

    var displayingSearchSuggestions: Bool = false

    var directoryMonitor: DirectoryMonitor?

    var audioPlayerController: AudioPlayerViewController?

    var permissionDeniedLabel: UILabel!

    var displayHiddenFiles: Bool = UserPreferences.displayHiddenFiles {
        didSet {
            reloadTableData()

            UserPreferences.displayHiddenFiles = self.displayHiddenFiles
        }
    }

    var containsAppUUIDs: Bool?

    var searchItem: DispatchWorkItem?

    typealias SnapshotType = NSDiffableDataSourceSnapshot<Int, SubPathsRowItem>
    typealias DataSourceType = UITableViewDiffableDataSource<Int, SubPathsRowItem>
    lazy var dataSource = DataSourceType(tableView: self.tableView) { tableView, indexPath, itemIdentifier in
        switch itemIdentifier {
        case .path(let url):
            return self.pathCellRow(forURL: url, displayFullPathAsSubtitle: self.isSearching || self.isBookmarksSheet)
        case .searchSuggestion(let suggestion):
            return self.searchSuggestionCellRow(suggestion: suggestion)
        }
    }

    class func bookmarks() -> PathListViewController {
        return PathListViewController(
            contents: Array(UserPreferences.bookmarks),
            title: "Bookmarks",
            isBookmarksSheet: true)
    }

    init(style: UITableView.Style = .userPreferred, path: Path, isBookmarksSheet: Bool = false) {
        self.unfilteredContents = self.sortMethod.sorting(URLs: path.contents, sortOrder: .userPreferred)
        self.currentPath = path
        self.isBookmarksSheet = isBookmarksSheet

        super.init(style: style)
        self.title = path.lastPathComponent
    }

    init(style: UITableView.Style = .userPreferred, contents: [Path], title: String, isBookmarksSheet: Bool = false) {
        self.unfilteredContents = self.sortMethod.sorting(URLs: contents, sortOrder: .userPreferred)
        self.isBookmarksSheet = isBookmarksSheet

        super.init(style: style)
        self.title = title
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        applySantanderGlass()

        setRightBarButton()
        if !self.displayHiddenFiles {
            reloadTableData()
        }

        self.navigationController?.navigationBar.prefersLargeTitles = UserPreferences.useLargeNavigationTitles
        let searchController = UISearchController(searchResultsController: nil)
        searchController.searchBar.delegate = self
        searchController.obscuresBackgroundDuringPresentation = false
        searchController.searchResultsUpdater = self
        searchController.delegate = self
        self.tableView.keyboardDismissMode = .onDrag
        self.navigationItem.hidesSearchBarWhenScrolling = !UserPreferences.alwaysShowSearchBar
        if let currentPath = currentPath {
            searchController.searchBar.scopeButtonTitles = [currentPath.lastPathComponent, "Subdirectories"]
            self.containsAppUUIDs = currentPath.containsAppUUIDSubpaths
            setupRefreshControl(forPath: currentPath)
        }
        self.navigationItem.searchController = searchController
#if compiler(>=5.7)
        if #available(iOS 16.0, *), UIDevice.isiPad {
            self.navigationItem.style = .browser
            self.navigationItem.renameDelegate = self
        }
#endif

        tableView.dragInteractionEnabled = true
        tableView.dropDelegate = self
        tableView.dragDelegate = self
        tableView.dataSource = self.dataSource
        showPaths()

        setupPermissionDeniedLabelIfNeeded()
    }

    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)

        if let currentPath = self.currentPath {
            if directoryMonitor == nil {
                directoryMonitor = DirectoryMonitor(path: currentPath)
                directoryMonitor?.delegate = self
            }

            directoryMonitor?.startMonitoring()
            UserPreferences.lastOpenedPath = currentPath.path
        }
    }

    override var keyCommands: [UIKeyCommand]? {
        return [
            UIKeyCommand(title: "Scroll Up", action: #selector(scrollUpOrDown(sender:)), input: UIKeyCommand.inputUpArrow, modifierFlags: .command),
            UIKeyCommand(title: "Scroll Down", action: #selector(scrollUpOrDown(sender:)), input: UIKeyCommand.inputDownArrow, modifierFlags: .command)
        ]
    }

    @objc
    func scrollUpOrDown(sender: UIKeyCommand) {
        switch sender.input {
        case UIKeyCommand.inputDownArrow:
            let snapshot = dataSource.snapshot()
            let indexPathToSrcollTo = IndexPath(row: snapshot.numberOfItems - 1, section: snapshot.numberOfSections - 1)
            tableView.scrollToRow(at: indexPathToSrcollTo, at: .bottom, animated: true)
        case UIKeyCommand.inputUpArrow:
            tableView.scrollToRow(at: IndexPath(row: 0, section: 0), at: .top, animated: true)
        default: break
        }
    }

    func setupRefreshControl(forPath path: Path) {
        let refreshControl = UIRefreshControl()
        let refreshAction = UIAction { [self] in
            unfilteredContents = sortMethod.sorting(URLs: path.contents, sortOrder: .userPreferred)
            reloadTableData()
            refreshControl.endRefreshing()
        }

        refreshControl.addAction(refreshAction, for: .primaryActionTriggered)

        tableView.refreshControl = refreshControl
    }

    func showPaths(animatingDifferences: Bool = false) {
        self.displayingSearchSuggestions = false
        var snapshot = SnapshotType()

        snapshot.appendSections([0])
        snapshot.appendItems(SubPathsRowItem.fromPaths(contents))
        dataSource.apply(snapshot, animatingDifferences: animatingDifferences)
    }

    func switchToSearchSuggestions() {
        displayingSearchSuggestions = true
        var snapshot = SnapshotType()

        snapshot.appendSections([0, 1, 2])

        for indexPath in SearchSuggestion.searchSuggestionSectionAndRows {
            let item = SubPathsRowItem.searchSuggestion(.displaySearchSuggestions(for: indexPath))
            snapshot.appendItems([item], toSection: indexPath.section)
        }

        dataSource.apply(snapshot, animatingDifferences: false)
    }

    func path(forIndexPath indexPath: IndexPath) -> Path {
        switch dataSource.itemIdentifier(for: indexPath) {
        case .path(let path):
            return path
        default:
            fatalError("NEVER SUPPOSED TO BE HERE!")
        }
    }

    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)

        self.directoryMonitor?.stopMonitoring()
    }

    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if self.isEditing {
            selectedItems.append(path(forIndexPath: indexPath))
            setupOrUpdateToolbar()
            setLeftBarSelectionButtonItem()
            return
        }

        if displayingSearchSuggestions {
            let searchTextField = self.navigationItem.searchController?.searchBar.searchTextField
            let tokensCount = searchTextField?.tokens.count

            if (indexPath.section, indexPath.row) == (0, 0) {
                let vc = TypesSelectionCollectionViewController { types in
                    if !types.isEmpty {
                        var searchSuggestion = SearchSuggestion.displaySearchSuggestions(for: indexPath, typesToCheck: types)
                        searchSuggestion.name = types.compactMap(\.localizedDescription).joined(separator: ", ")
                        searchTextField?.insertToken(searchSuggestion.searchToken, at: tokensCount ?? 0)
                    }
                }

                let navVC = UINavigationController(rootViewController: vc)

                self.present(navVC, animated: true)

            } else {
                searchTextField?.insertToken(SearchSuggestion.displaySearchSuggestions(for: indexPath).searchToken, at: tokensCount ?? 0)
            }

        } else {
            let selectedItem = path(forIndexPath: indexPath)
            goToPath(path: selectedItem)
            tableView.deselectRow(at: indexPath, animated: true)
        }
    }

    override func tableView(_ tableView: UITableView, didDeselectRowAt indexPath: IndexPath) {
        guard self.isEditing else {
            return
        }

        let selected = path(forIndexPath: indexPath)
        selectedItems.removeAll { path in
            path == selected
        }

        setupOrUpdateToolbar()
        setLeftBarSelectionButtonItem()
    }

    override func tableView(_ tableView: UITableView, trailingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration? {

        guard !displayingSearchSuggestions else {
            return nil
        }

        let selectedItem = self.path(forIndexPath: indexPath)
        let itemAlreadyBookmarked = UserPreferences.bookmarks.contains(selectedItem)
        let favouriteAction = UIContextualAction(style: .normal, title: nil) { _, _, handler in
            self.removeOrAddItemToBookmarks(selectedItem, alreadyBookmarked: itemAlreadyBookmarked)
            handler(true)
        }

        favouriteAction.backgroundColor = .systemBlue
        favouriteAction.image = itemAlreadyBookmarked ? UIImage(systemName: "star.fill") : UIImage(systemName: "star")

        let deleteAction = UIContextualAction(style: .destructive, title: nil) { _, _, completion in
            self.deleteURL(selectedItem) { didSucceed in
                completion(didSucceed)
            }
        }

        deleteAction.image = UIImage(systemName: "trash")

        let config = UISwipeActionsConfiguration(actions: [deleteAction, favouriteAction])
        return config
    }

    func removeOrAddItemToBookmarks(_ item: Path, alreadyBookmarked: Bool) {
        if alreadyBookmarked {
            UserPreferences.bookmarks.remove(item)

            if self.isBookmarksSheet {
                self.unfilteredContents = Array(UserPreferences.bookmarks)

                var snapshot = self.dataSource.snapshot()
                snapshot.deleteItems([.path(item)])
                self.dataSource.apply(snapshot)
            }
        } else {
            UserPreferences.bookmarks.insert(item)
        }
    }

    func makeSortMenu() -> UIMenu {
        let actions: [UIMenuElement] = PathsSortMethods.allCases.map { type in
            let typeIsSelected = self.sortMethod == type
            return UIAction(
                title: type.description,
                image: typeIsSelected ? UIImage(systemName: SortOrder.userPreferred.imageSymbolName) : nil,
                state: typeIsSelected ? .on : .off) { _ in
                    if typeIsSelected {
                        UserDefaults.standard.set(SortOrder.userPreferred.toggling().rawValue, forKey: "SortOrder")
                        self.sortContents()
                    } else {
                        self.sortMethod = type
                    }

                    self.setRightBarButton()
                }
        }

        let menu = UIMenu(title: "Sort by..", image: UIImage(systemName: "arrow.up.arrow.down"), children: actions)
        if #available(iOS 15.0, *) {
            menu.subtitle = self.sortMethod.description
        }

        return menu
    }

    func makeNewItemMenu(forURL url: URL) -> UIMenu {
        let newFile = UIAction(title: "File", image: UIImage(systemName: "doc")) { _ in
            self.presentAlertAndCreate(type: .file, forURL: url)
        }

        let newFolder = UIAction(title: "Folder", image: UIImage(systemName: "folder")) { _ in
            self.presentAlertAndCreate(type: .directory, forURL: url)
        }

        return UIMenu(title: "New..", image: UIImage(systemName: "plus"), children: [newFile, newFolder])
    }

    func makeGoToMenu() -> UIMenu {
        var items: [UIMenuElement] = GoToItem.all.map { item in
            return UIAction(title: item.displayName, image: item.image) { _ in
                self.goToPath(path: Path(url: item.url))
            }
        }

        let otherLocationAction = UIAction(title: "Other..") { _ in
            let goToView = GoToView()
            goToView.translatesAutoresizingMaskIntoConstraints = false
            self.view.addSubview(goToView)

            NSLayoutConstraint.activate([
                goToView.centerXAnchor.constraint(equalTo: self.view.layoutMarginsGuide.centerXAnchor),
                goToView.centerYAnchor.constraint(equalTo: self.view.layoutMarginsGuide.centerYAnchor),
                goToView.heightAnchor.constraint(equalToConstant: 150),
                goToView.widthAnchor.constraint(equalToConstant: 600),
            ])
        }

        items.append(otherLocationAction)

        return UIMenu(title: "Go to..", image: UIImage(systemName: "arrow.right"), children: items)
    }

    func decompressPath(path: Path) {
        let alertController = createAlertWithSpinner(title: "Decompressing..")
        present(alertController, animated: true)
        DispatchQueue.global(qos: .userInitiated).async {
            var caughtError: Error? = nil
            do {
                let destination = path.deletingLastPathComponent()
                try Compression.shared.extract(path: path.url, to: destination.url)
            } catch {
                caughtError = error
            }

            DispatchQueue.main.async {
                alertController.dismiss(animated: true)
                if let caughtError = caughtError {
                    self.errorAlert(caughtError, title: "Unable to decompress file \(path.lastPathComponent)")
                }
            }
        }
    }

    func compressPaths(paths: [Path], destination: URL, format: Compression.FormatType) {
        let alertController = createAlertWithSpinner(title: "Compressing..", heightAnchorConstant: 120)
        present(alertController, animated: true)

        DispatchQueue.global(qos: .userInitiated).async {
            var caughtError: Error? = nil
            do {
                try Compression.shared.compress(paths: paths.map(\.url), outputPath: destination, format: format) { pathBeingProcessed in
                    DispatchQueue.main.async { alertController.message = "Compressing \(pathBeingProcessed.lastPathComponent)" }
                }
            } catch {
                caughtError = error
            }

            DispatchQueue.main.async {
                alertController.dismiss(animated: true)
                if let caughtError = caughtError {
                    self.errorAlert(caughtError, title: "Unable to compress file(s).")
                }
            }
        }
    }

    func makeCompressionMenu(paths: [Path], destination: @escaping (Compression.FormatType) -> Path) -> UIMenu {
        let actions = Compression.FormatType.allCases.map { format in
            UIAction(title: format.description) { _ in
                self.compressPaths(paths: paths, destination: destination(format).url, format: format)
            }
        }

        return UIMenu(title: "Compress", image: UIImage(systemName: "archivebox"), children: actions)
    }

    func goToFile(path: Path) {
        if path.contentType?.isOfType(.archive) ?? false {
            decompressPath(path: path)
        } else if let preferred = FileEditor.preferred(forURL: path) {
            preferred.display(senderVC: self)

            if let audioVC = preferred.viewController as? AudioPlayerViewController {
                self.audioPlayerController?.player.stop()
                self.audioPlayerController = audioVC
                self.setupAudioToolbarIfPossible()
            }

        } else {
            openQuickLookPreview(forPath: path)
        }
    }

    func openQuickLookPreview(forPath path: Path) {
        let controller = QLPreviewController()
        let shared = FilePreviewDataSource(fileURL: path.url)
        controller.dataSource = shared
        self.present(controller, animated: true)
    }

    func goToPath(path: Path) {
        if path.isDirectory {
            let parentDirectory = path.deletingLastPathComponent()

            if isBookmarksSheet || parentDirectory == self.currentPath {
                let vc = PathListViewController(path: path, isBookmarksSheet: self.isBookmarksSheet)
                self.navigationController?.pushViewController(vc, animated: true)
            } else {
                traverseThroughPath(path)
            }
        } else {
            self.goToFile(path: path)
        }
    }

    func traverseThroughPath(_ path: Path) {
        let vcs = path.url.fullPathComponents().map {
            PathListViewController(path: Path(url: $0), isBookmarksSheet: self.isBookmarksSheet)
        }

        self.navigationController?.setViewControllers(vcs, animated: true)
    }

    func sortContents() {
        self.unfilteredContents = sortMethod.sorting(URLs: unfilteredContents, sortOrder: .userPreferred)
        reloadTableData(animatingDifferences: true)
    }

    func openInfoBottomSheet(path: Path) {
        if let app = path.applicationItem {
            let actionSheet = UIAlertController(title: nil, message: nil, preferredStyle: .actionSheet)
            let pathInfoAction = UIAlertAction(title: SantanderL10n.t("Path Info"), style: .default) { _ in
                let navController = UINavigationController(
                    rootViewController: PathInformationTableViewController(style: .insetGrouped, path: path)
                )

                if #available(iOS 15.0, *) {
                    navController.sheetPresentationController?.detents = [.medium(), .large()]
                }

                self.present(navController, animated: true)
            }

            let appInfoAction = UIAlertAction(title: SantanderL10n.t("App Info"), style: .default) { _ in
                let navController = UINavigationController(
                    rootViewController: AppInfoViewController(style: .insetGrouped, app: app, subPathsSender: self)
                )

                self.present(navController, animated: true)
            }

            actionSheet.addAction(appInfoAction)
            actionSheet.addAction(pathInfoAction)
            actionSheet.addAction(.init(title: "Cancel", style: .cancel))

            actionSheet.popoverPresentationController?.sourceView = view
            let bounds = view.bounds
            actionSheet.popoverPresentationController?.sourceRect = CGRect(x: bounds.midX, y: bounds.midY, width: 0, height: 0)
            self.present(actionSheet, animated: true)
        } else {
            let navController = UINavigationController(
                rootViewController: PathInformationTableViewController(style: .insetGrouped, path: path)
            )

            if #available(iOS 15.0, *) {
                navController.sheetPresentationController?.detents = [.medium(), .large()]
            }

            self.present(navController, animated: true)
        }
    }

    override func tableView(_ tableView: UITableView, accessoryButtonTappedForRowWith indexPath: IndexPath) {
        self.openInfoBottomSheet(path: path(forIndexPath: indexPath))
    }

    func searchSuggestionCellRow(suggestion: SearchSuggestion) -> UITableViewCell {
        let cell = UITableViewCell()
        var conf = cell.defaultContentConfiguration()
        conf.text = suggestion.name
        conf.image = suggestion.image
        cell.contentConfiguration = conf
        return cell
    }

    func pathCellRow(
        forURL fsItem: Path,
        displayFullPathAsSubtitle useSubtitle: Bool = false
    ) -> UITableViewCell {
        var fsItem = fsItem
        let pathName = fsItem.lastPathComponent

        let cell = UITableViewCell(style: useSubtitle ? .subtitle : .default, reuseIdentifier: nil)
        var cellConf = cell.defaultContentConfiguration()
        defer {
            cell.contentConfiguration = cellConf
        }

        if (fsItem.pathExtension == "app" || (containsAppUUIDs ?? fsItem.deletingLastPathComponent().containsAppUUIDSubpaths)),
           let app = fsItem.applicationItem {
            cellConf.text = app.localizedName
            cellConf.image = ApplicationsManager.shared.icon(forApplication: app)
            cellConf.secondaryText = fsItem.lastPathComponent
            cell.accessoryType = .disclosureIndicator
            cellConf.textProperties.color = tableView.tintColor ?? .systemBlue
            return cell
        }

        cellConf.text = pathName

        if pathName.first == "." {
            cellConf.textProperties.color = .gray
            cellConf.secondaryTextProperties.color = .gray
        }

        if useSubtitle {
            cellConf.secondaryText = fsItem.path
        }

        cellConf.image = fsItem.displayImage

        if showInfoButton {
            cell.accessoryType = .detailDisclosureButton
        } else if fsItem.isDirectory {
            cell.accessoryType = .disclosureIndicator
        }

        return cell
    }

    override func tableView(_ tableView: UITableView, contextMenuConfigurationForRowAt indexPath: IndexPath, point: CGPoint) -> UIContextMenuConfiguration? {

        if displayingSearchSuggestions {
            return nil
        }

        let item = path(forIndexPath: indexPath)
        return UIContextMenuConfiguration(identifier: nil) {
            let vc = UIViewController()
            vc.view = self.pathCellRow(forURL: item, displayFullPathAsSubtitle: true)
            vc.view.backgroundColor = .systemBackground
            let sizeFrame = vc.view.frame
            vc.preferredContentSize = CGSize(width: sizeFrame.width, height: sizeFrame.height)
            return vc
        } actionProvider: { _ in

            let movePath = UIAction(title: "Move to..", image: UIImage(systemName: "arrow.right")) { _ in
                self.presentOperationVC(forItems: [item.url], type: .move)
            }

            let copyPath = UIAction(title: "Copy to..", image: UIImage(systemName: "doc.on.doc")) { _ in
                self.presentOperationVC(forItems: [item.url], type: .copy)
            }

            let createSymlink = UIAction(title: "Create symbolic link to..", image: UIImage(systemName: "link")) { _ in
                self.presentOperationVC(forItems: [item.url], type: .symlink)
            }

            let pasteboardOptions = UIMenu(options: .displayInline, children: self.makePasteboardMenuElements(for: item))
            let operationItemsMenu = UIMenu(options: .displayInline, children: [movePath, copyPath, createSymlink])
            let informationAction = UIAction(title: "Info", image: UIImage(systemName: "info.circle")) { _ in
                self.openInfoBottomSheet(path: item)
            }

            let shareAction = UIAction(title: "Share", image: UIImage(systemName: "square.and.arrow.up")) { _ in
                self.presentActivityVC(forItems: [item.url])
            }

            let linkAction = UIAction(title: "Create Symbolic Link", image: UIImage(systemName: "link")) { _ in
                self.presentRootLinkPrompt(for: item)
            }

            let mountAction = UIAction(title: "Mount", image: UIImage(systemName: "externaldrive.badge.plus")) { _ in
                self.presentMountPrompt(for: item)
            }

            let unmountAction = UIAction(title: "Unmount", image: UIImage(systemName: "externaldrive.badge.minus"), attributes: .destructive) { _ in
                do {
                    try RootConf.shared.runHelper(arguments: ["unmount", item.path])
                    self.reloadCurrentDirectory()
                } catch {
                    self.errorAlert(error, title: "Unable to unmount \(item.lastPathComponent)")
                }
            }

            let renameAction = UIAction(title: "Rename", image: UIImage(systemName: "rectangle.and.pencil.and.ellipsis")) { _ in
                let alert = UIAlertController(title: "Rename", message: nil, preferredStyle: .alert)
                if let cell = tableView.cellForRow(at: indexPath), var conf = cell.contentConfiguration as? UIListContentConfiguration,
                   let imageGuide = (cell.contentView as? UIListContentView)?.imageLayoutGuide {
                    let textField = RenamerTextField(path: item)
                    textField.returnKeyType = .done
                    textField.translatesAutoresizingMaskIntoConstraints = false
                    textField.delegate = self

                    textField.text = conf.text

                    conf.text = nil
                    cell.contentConfiguration = conf
                    cell.contentView.addSubview(textField)
                    NSLayoutConstraint.activate([
                        textField.leadingAnchor.constraint(equalTo: imageGuide.trailingAnchor, constant: conf.imageToTextPadding),
                        textField.centerYAnchor.constraint(equalTo: imageGuide.centerYAnchor)
                    ])
                    tableView.scrollToRow(at: indexPath, at: .top, animated: true)
                    textField.becomeFirstResponder()
                    return
                }

                let renameAction = UIAlertAction(title: SantanderL10n.t("Rename"), style: .default) { _ in

                    guard let name = alert.textFields?.first?.text else {
                        return
                    }

                    do {
                        let newPath: URL = item.deletingLastPathComponent().appendingPathComponent(name)
                        try FSOperation.perform(.rename(item: item.url, newPath: newPath), rootHelperConf: RootConf.shared)
                    } catch {
                        self.errorAlert(error, title: "Unable to rename \(item.lastPathComponent)")
                    }
                }

                alert.addTextField { textField in
                    textField.text = item.lastPathComponent
                }

                alert.addAction(.cancel())
                alert.addAction(renameAction)
                self.present(alert, animated: true)
            }

            var children: [UIMenuElement] = [informationAction, renameAction, shareAction, linkAction, mountAction]

            let compressOrDecompressAction: UIMenuElement
            if !(item.contentType?.isOfType(.archive) ?? false) {
                compressOrDecompressAction = self.makeCompressionMenu(paths: [item]) { format in
                    return item.deletingPathExtension().appendingPathExtension(format.fileExtension)
                }
            } else {
                compressOrDecompressAction = UIAction(title: "Decompress", image: UIImage(systemName: "archivebox")) { _ in
                    self.decompressPath(path: item)
                }
            }

            children.append(compressOrDecompressAction)

            if self.isMountPoint(item.url) {
                children.append(unmountAction)
            }

            if let app = item.applicationItem {
                let openAction = UIAction(title: "Open App") { _ in
                    do {
                        try ApplicationsManager.shared.openApp(app)
                    } catch {
                        self.errorAlert(error, title: "Unable to open app")
                    }
                }
                children.append(openAction)
            }

            if !item.isDirectory {
                let allEditors = FileEditor.allEditors(forPath: item)
                var actions = allEditors.map { editor in
                    UIAction(title: editor.type.description) { _ in
                        editor.display(senderVC: self)
                    }
                }

                let qlAction = UIAction(title: "QuickLook") { _ in
                    self.openQuickLookPreview(forPath: item)
                }

                actions.append(qlAction)

                children.append(UIMenu(title: "Open in..", children: actions))
            }

            if UIDevice.isiPad {
                let addActions = UserPreferences.pathGroups.enumerated().map { (index, group) in
                    return UIAction(title: group.name) { _ in
                        UserPreferences.pathGroups[index].paths.append(item.url)
                    }
                }

                let addToPathGroupsMenu = UIMenu(title: "Add to group..", image: UIImage(systemName: "sidebar.leading"), children: addActions)
                children.append(addToPathGroupsMenu)
            }

            let deleteAction = UIAction(title: "Delete", image: UIImage(systemName: "trash"), attributes: .destructive) { _ in
                self.deleteURL(item) { _ in }
            }

            let isItemBookmarked = UserPreferences.bookmarks.contains(item)
            let bookmarkAction = UIAction(
                title: isItemBookmarked ? "Remove bookmark" : "Bookmark",
                image: UIImage(systemName: isItemBookmarked ? "bookmark.slash" : "bookmark")
            ) { _ in
                self.removeOrAddItemToBookmarks(item, alreadyBookmarked: isItemBookmarked)
            }

            children.append(contentsOf: [operationItemsMenu, pasteboardOptions])
            children.append(UIMenu(options: .displayInline, children: [bookmarkAction, deleteAction]))
            return UIMenu(children: children)
        }
    }

    func presentRootLinkPrompt(for item: Path) {
        let alert = UIAlertController(title: "Create Symbolic Link", message: "Enter the destination directory.", preferredStyle: .alert)
        alert.addTextField { field in
            field.text = item.deletingLastPathComponent().path
            field.autocapitalizationType = .none
        }
        alert.addAction(.cancel())
        alert.addAction(UIAlertAction(title: SantanderL10n.t("Create"), style: .default) { [weak self, weak alert] _ in
            guard let self, let destination = alert?.textFields?.first?.text, !destination.isEmpty else { return }
            do {
                try RootConf.shared.runHelper(arguments: ["link", item.path, "--destination", destination])
                self.reloadCurrentDirectory()
            } catch {
                self.errorAlert(error, title: "Unable to create symbolic link")
            }
        })
        present(alert, animated: true)
    }

    func presentMountPrompt(for item: Path) {
        let alert = UIAlertController(title: "Mount", message: "Enter an empty or existing mount point.", preferredStyle: .alert)
        alert.addTextField { field in
            field.text = "/mnt/\(item.deletingPathExtension().lastPathComponent)"
            field.autocapitalizationType = .none
        }
        alert.addAction(.cancel())
        alert.addAction(UIAlertAction(title: SantanderL10n.t("Mount"), style: .default) { [weak self, weak alert] _ in
            guard let self, let target = alert?.textFields?.first?.text, !target.isEmpty else { return }
            do {
                try RootConf.shared.runHelper(arguments: ["mount", item.path, target])
                self.reloadCurrentDirectory()
            } catch {
                self.errorAlert(error, title: "Unable to mount \(item.lastPathComponent)")
            }
        })
        present(alert, animated: true)
    }

    func isMountPoint(_ url: URL) -> Bool {
        var current = statfs()
        guard statfs(url.path, &current) == 0 else {
            return false
        }

        var parent = statfs()
        let parentURL = url.deletingLastPathComponent()
        guard statfs(parentURL.path, &parent) == 0 else {
            return false
        }

        return current.f_fsid.val.0 != parent.f_fsid.val.0 || current.f_fsid.val.1 != parent.f_fsid.val.1
    }

    func reloadCurrentDirectory() {
        guard let currentPath else { return }
        unfilteredContents = sortMethod.sorting(URLs: currentPath.contents, sortOrder: .userPreferred)
        reloadTableData(animatingDifferences: true)
    }

    func makePasteboardMenuElements(for path: Path) -> [UIMenuElement] {
        let copyName = UIAction(title: "Copy name") { _ in
            UIPasteboard.general.string = path.lastPathComponent
        }

        let copyPath = UIAction(title: "Copy path") { _ in
            UIPasteboard.general.url = path.url
            UIPasteboard.general.string = path.path
        }

        return [copyName, copyPath]
    }

    func presentOperationVC(forItems items: [URL], type: PathSelectionOperation) {
        let vc = PathOperationViewController(paths: items, operationType: type)
        present(UINavigationController(rootViewController: vc), animated: true) { [self] in
            if let currentPath = currentPath, currentPath != .root {
                vc.goToPath(path: currentPath)
            }
        }
    }

    func makeRightBarButton() -> UIMenu {
        let selectAction = UIAction(title: "Select", image: UIImage(systemName: "checkmark.circle")) { _ in
            self.tableView.allowsMultipleSelectionDuringEditing = true
            self.setEditing(true, animated: true)
        }

        let selectionMenu = UIMenu(options: .displayInline, children: [selectAction])
        var firstMenuItems = [selectionMenu, makeSortMenu(), makeGoToMenu()]

        if let currentPath = currentPath {
            firstMenuItems.append(makeNewItemMenu(forURL: currentPath.url))
        }

        let firstMenu = UIMenu(options: .displayInline, children: firstMenuItems)
        var menuActions: [UIMenuElement] = [firstMenu]

        if !isBookmarksSheet {
            let presentBookmarks = UIAction(title: "Bookmarks", image: UIImage(systemName: "bookmark")) { _ in
                let newVC = UINavigationController(rootViewController: PathListViewController.bookmarks())
                self.present(newVC, animated: true)
            }

            menuActions.append(presentBookmarks)
        }

        if let currentPath = currentPath {
            let showInfoAction = UIAction(title: "Info", image: .init(systemName: "info.circle")) { _ in
                self.openInfoBottomSheet(path: currentPath)
            }

            menuActions.append(showInfoAction)
            let pasteAction = UIAction(title: "Paste") { _ in
                guard let probableURL = UIPasteboard.general.probableURL else {
                    self.errorAlert(nil, title: "No path to paste.")
                    return
                }

                do {
                    try FSOperation.perform(.copyItem(items: [probableURL], resultPath: currentPath.url), rootHelperConf: RootConf.shared)
                } catch {
                    self.errorAlert(error, title: "Failed to copy item to current directory.")
                }
            }

            menuActions.insert(UIMenu(options: .displayInline, children: [pasteAction]), at: 1)
        }

        let settingsAction = UIAction(title: "Settings", image: UIImage(systemName: "gear")) { _ in
            self.present(UINavigationController(rootViewController: SettingsTableViewController(style: .insetGrouped)), animated: true)
        }
        menuActions.append(settingsAction)

        let showOrHideHiddenFilesAction = UIAction(
            title: "Display hidden files",
            state: displayHiddenFiles ? .on : .off
        ) { _ in
            self.displayHiddenFiles.toggle()
            self.setRightBarButton()
        }

        menuActions.append(showOrHideHiddenFilesAction)
        return UIMenu(children: menuActions)
    }

    func setRightBarButton() {
        if self.isEditing {
            let editAction = UIAction {
                self.setEditing(false, animated: true)
            }

            self.navigationItem.rightBarButtonItem = UIBarButtonItem(
                systemItem: .done,
                primaryAction: editAction
            )

        } else {
            self.navigationItem.rightBarButtonItem = UIBarButtonItem(
                image: .init(systemName: "ellipsis.circle"),
                menu: makeRightBarButton()
            )
        }
    }

    override func setEditing(_ editing: Bool, animated: Bool) {
        super.setEditing(editing, animated: animated)

        setRightBarButton()
        setLeftBarSelectionButtonItem()
        if editing {
            setupOrUpdateToolbar()
        } else {
            hideToolbarItems()
            selectedItems = []
        }
    }

    func reloadTableData(animatingDifferences: Bool = false) {
        if !displayHiddenFiles {
            let filtered = unfilteredContents.filter { !$0.lastPathComponent.starts(with: ".") }
            setFilteredContents(filtered, animatingDifferences: animatingDifferences)
        } else {
            setFilteredContents([], animatingDifferences: animatingDifferences)
        }
    }

    func setFilteredContents(_ newContents: [Path], animatingDifferences: Bool = false) {
        self.filteredSearchContents = newContents
        if !displayingSearchSuggestions {
            self.showPaths(animatingDifferences: animatingDifferences)
        }
    }

    func setupPermissionDeniedLabelIfNeeded() {
        guard let currentPath = currentPath, contents.isEmpty, !currentPath.isReadable else {
            return
        }

        permissionDeniedLabel = UILabel()
        permissionDeniedLabel.text = "Permission Denied."

        permissionDeniedLabel.font = .systemFont(ofSize: 20, weight: .medium)
        permissionDeniedLabel.textColor = .systemGray
        permissionDeniedLabel.textAlignment = .center

        view.addSubview(permissionDeniedLabel)
        permissionDeniedLabel.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            permissionDeniedLabel.centerXAnchor.constraint(equalTo: view.layoutMarginsGuide.centerXAnchor),
            permissionDeniedLabel.centerYAnchor.constraint(equalTo: view.layoutMarginsGuide.centerYAnchor)
        ])
    }
}

extension PathListViewController: DirectoryMonitorDelegate {
    func directoryMonitorDidObserveChange(directoryMonitor: DirectoryMonitor) {
        DispatchQueue.main.async {
            let items = self.sortMethod.sorting(URLs: directoryMonitor.path.contents, sortOrder: .userPreferred)
            self.unfilteredContents = items
            self.reloadTableData(animatingDifferences: true)

            if self.isSearching, let searchBar = self.navigationItem.searchController?.searchBar {
                self.updateResults(searchBar: searchBar)
            }
        }
    }
}
#if compiler(>=5.7)
@available(iOS 16.0, *)
extension PathListViewController: UINavigationItemRenameDelegate {
    func navigationItem(_: UINavigationItem, didEndRenamingWith title: String) {
        guard let currentPath = currentPath else {
            return
        }

        let newURL: Path = currentPath.deletingLastPathComponent().appendingPathComponent(title)

        guard currentPath != newURL else {
            return
        }

        do {
            try FSOperation.perform(.moveItem(items: [currentPath.url], resultPath: newURL.url), rootHelperConf: RootConf.shared)
            self.currentPath = newURL
        } catch {
            self.errorAlert(error, title: "Unable to rename \(newURL.lastPathComponent)")
            self.title = currentPath.lastPathComponent
        }
    }

    func navigationItemShouldBeginRenaming(_: UINavigationItem) -> Bool {
        return currentPath != nil
    }
}
#endif

extension PathListViewController: UITextFieldDelegate {
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        guard let textField = textField as? RenamerTextField else {
            fatalError("How What When Where Why")
        }

        textField.notifyShouldReturnUponResigning = false
        defer {
            textField.resignFirstResponder()
            textField.removeFromSuperview()
        }

        guard let name = textField.text else { return false }
        let item = textField.path
        let newPath: URL = item.deletingLastPathComponent().appendingPathComponent(name)
        if newPath == item.url {
            return true
        }

        do {
            try FSOperation.perform(.rename(item: item.url, newPath: newPath), rootHelperConf: RootConf.shared)
        } catch {
            self.errorAlert(error, title: "Unable to rename \(item.lastPathComponent)")
        }

        print(textField.path)
        return true
    }
}

enum SubPathsRowItem: Hashable {
    static func == (lhs: SubPathsRowItem, rhs: SubPathsRowItem) -> Bool {
        switch (lhs, rhs) {
        case (.path(let firstURL), .path(let secondURL)):
            return firstURL == secondURL
        case (.searchSuggestion(let firstSuggestion), .searchSuggestion(let secondSuggestion)):
            return firstSuggestion == secondSuggestion
        default:
            return false
        }
    }

    func hash(into hasher: inout Hasher) {
        switch self {
        case .searchSuggestion(let searchSuggestion):
            hasher.combine(searchSuggestion)
        case .path(let url):
            hasher.combine(url)
        }
    }

    case searchSuggestion(SearchSuggestion)
    case path(Path)

    static func fromPaths(_ paths: [Path]) -> [SubPathsRowItem] {
        return paths.map { url in
            return .path(url)
        }
    }
}

class PathSidebarListViewController: UIViewController, PathTransitioning, UICollectionViewDelegate {

    typealias Item = DiffableDataSourceItem<String, Path>
    typealias DataSource = UICollectionViewDiffableDataSource<String, Item>
    typealias CellRegistration = UICollectionView.CellRegistration<UICollectionViewListCell, Item>

    var dataSource: DataSource!
    var pathGroups = UserPreferences.pathGroups
    var collectionView: UICollectionView!

    var subPathsSecondary: PathListViewController? {
        splitViewController?.viewController(for: .secondary) as? PathListViewController
    }

    init() {
        super.init(nibName: nil, bundle: nil)
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    override func viewDidLoad() {
        title = SantanderL10n.t("Santander")
        setupCollectionView()
        setupDataSource()

        let newGroupAction = UIAction {
            self.presentNewGroupAlert()
        }

        navigationController?.navigationBar.prefersLargeTitles = true
        let newGroupsButton = UIBarButtonItem(systemItem: .add, primaryAction: newGroupAction)
        setToolbarItems([newGroupsButton], animated: true)
        navigationController?.setToolbarHidden(false, animated: false)

        NotificationCenter.default.addObserver(forName: .pathGroupsDidChange, object: nil, queue: nil) { [self] notif in
            if let newGroups = notif.object as? [PathGroup] {
                self.pathGroups = newGroups
                addItems()
            }
        }
    }

    func setupCollectionView() {
        let layout = UICollectionViewCompositionalLayout { _, env in
            var layoutConf = UICollectionLayoutListConfiguration(appearance: .insetGrouped)
            layoutConf.headerMode = .firstItemInSection
            layoutConf.trailingSwipeActionsConfigurationProvider = { (indexPath: IndexPath) -> UISwipeActionsConfiguration? in
                let sectionAndRow = (indexPath.section, indexPath.row)

                guard sectionAndRow != (0, 0) && sectionAndRow != (0, 1) else {
                    return nil
                }

                let removeAction = UIContextualAction(style: .destructive, title: nil) { [self] _, _, completion in
                    switch dataSource.itemIdentifier(for: indexPath) {
                    case .section(let name):
                        UserPreferences.pathGroups.remove(at: indexPath.section)
                        removeSection(name)
                    case .item(_):
                        UserPreferences.pathGroups[indexPath.section].paths.remove(at: indexPath.row - 1)
                    default:
                        return completion(false)
                    }

                    return completion(true)
                }

                removeAction.image = .remove
                return UISwipeActionsConfiguration(actions: [removeAction])
            }

            return .list(using: layoutConf, layoutEnvironment: env)
        }

        self.collectionView = UICollectionView(frame: .zero, collectionViewLayout: layout)
        collectionView.translatesAutoresizingMaskIntoConstraints = false
        collectionView.delegate = self

        view.addSubview(collectionView)
        collectionView.constraintCompletely(to: view)
    }

    func setupDataSource() {
        let cellRegistration = CellRegistration { cell, indexPath, itemIdentifier in
            var conf: UIListContentConfiguration
            switch itemIdentifier {
            case .section(let headerTitle):
                conf = .sidebarHeader()
                conf.text = headerTitle
                cell.accessories = [.outlineDisclosure()]
            case .item(var path):
                conf = cell.defaultContentConfiguration()
                conf.text = path.lastPathComponent
                conf.image = path.displayImage
            }

            cell.contentConfiguration = conf
        }

        dataSource = DataSource(collectionView: collectionView) { collectionView, indexPath, item in
            return collectionView.dequeueConfiguredReusableCell(using: cellRegistration, for: indexPath, item: item)
        }

        addItems()
    }

    func addItems() {
        var snapshot = dataSource.snapshot()
        if snapshot.sectionIdentifiers.isEmpty {
            snapshot.appendSections(pathGroups.map(\.name))
            dataSource.apply(snapshot)
        }

        for group in pathGroups {
            var sectionSnapshot = NSDiffableDataSourceSectionSnapshot<Item>()
            let section: Item = .section(group.name)
            sectionSnapshot.append([section])
            sectionSnapshot.expand([section])

            let items = Item.fromItems(group.paths.map(Path.init(url:)))
            sectionSnapshot.append(items, to: section)
            dataSource.apply(sectionSnapshot, to: group.name)
        }
    }

    func removeSection(_ name: String) {
        var snapshot = dataSource.snapshot()
        snapshot.deleteSections([name])
        dataSource.apply(snapshot)
    }

    func goToPath(path: Path) {
        let secondary = subPathsSecondary
        if !path.isDirectory {
            secondary?.goToFile(path: path)
            return
        }

        if let currentSubpathsPath = secondary?.currentPath {
            guard currentSubpathsPath != path else { return }

            if currentSubpathsPath.path.hasPrefix(path.path) {
                if let vcs = secondary?.navigationController?.viewControllers as? [PathListViewController],
                   let first = vcs.first(where: { $0.currentPath == path }) {
                       secondary?.navigationController?.popToViewController(first, animated: true)
                }
            } else if path.deletingLastPathComponent() != currentSubpathsPath {
                secondary?.traverseThroughPath(path)
            } else {
                splitViewController?.setViewController(PathListViewController(path: path), for: .secondary)
            }

        } else {
            let vc = PathListViewController(path: .root)
            splitViewController?.setViewController(vc, for: .secondary)
            if path != .root { subPathsSecondary?.traverseThroughPath(path) }
        }
    }

    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        guard let item = dataSource.itemIdentifier(for: indexPath) else { return }
        switch item {
        case .section(_): break
        case .item(let path):
            goToPath(path: path)
        }
    }

    func presentNewGroupAlert() {
        let alert = UIAlertController(title: "New Group", message: nil, preferredStyle: .alert)
        alert.addTextField { textField in
            textField.placeholder = "Group name.."
        }

        let addAction = UIAlertAction(title: SantanderL10n.t("Add"), style: .default) { [self] _ in
            guard let name = alert.textFields?.first?.text else { return }
            if pathGroups.map(\.name).contains(name) {
                errorAlert("Group with same name already exists", title: "Unable to create Group with name \(name)")
            }

            let newGroup = PathGroup(name: name, paths: [])
            UserPreferences.pathGroups.append(newGroup)
        }

        alert.addAction(addAction)
        alert.addAction(.cancel())
        present(alert, animated: true)
    }
}

class PathGroupOwnerViewController: UITableViewController {
    var type: ItemType
    weak var sourceVC: PathPermissionsViewController?
    let fileURL: URL
    var allData: [ItemType] = []

    enum Section {
        case main
    }

    typealias DataSource = UITableViewDiffableDataSource<Section, ItemType>
    lazy var dataSource = DataSource(tableView: tableView) { [self] tableView, indexPath, itemIdentifier in
        let cell = UITableViewCell()
        var conf = cell.defaultContentConfiguration()
        conf.text = itemIdentifier.name
        conf.secondaryText = itemIdentifier.subtitle
        if type == itemIdentifier {
            cell.accessoryType = .checkmark
        }
        cell.contentConfiguration = conf
        return cell
    }

    init(style: UITableView.Style, type: ItemType, sourceVC: PathPermissionsViewController, fileURL: URL) {
        self.type = type
        self.sourceVC = sourceVC
        self.fileURL = fileURL
        super.init(style: style)
    }

    required init?(coder: NSCoder) {
        fatalError()
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        title = type.title
        let searchController = UISearchController(searchResultsController: nil)
        searchController.searchBar.delegate = self
        navigationItem.searchController = searchController
        navigationItem.hidesSearchBarWhenScrolling = false

        navigationItem.rightBarButtonItem = UIBarButtonItem(
            systemItem: .add,
            primaryAction: UIAction { [weak self] _ in
                self?.presentNumericIdentityEntry()
            }
        )

        allData = ItemType.candidates(forURL: fileURL, type: type)
        applyItems(allData, animatingDifference: false)
    }

    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        guard let item = dataSource.itemIdentifier(for: indexPath) else {
            return
        }

        do {
            try item.set(forURL: fileURL)
            type = item
            switch item {
            case .owner(let id, let name):
                sourceVC?.permissions.ownerID = id
                sourceVC?.permissions.ownerName = name
            case .group(let id, let name):
                sourceVC?.permissions.groupID = id
                sourceVC?.permissions.groupOwnerName = name
            }
            sourceVC?.tableView.reloadData()
            tableView.reloadData()
        } catch {
            errorAlert(error, title: "Unable to change \(type.title.lowercased())")
        }
        tableView.deselectRow(at: indexPath, animated: true)
    }

    func presentNumericIdentityEntry() {
        let alert = UIAlertController(title: "Set \(type.title)", message: "UID/GID range: -2…501", preferredStyle: .alert)
        alert.addTextField { field in
            field.keyboardType = .numbersAndPunctuation
            field.placeholder = "ID"
        }
        alert.addAction(.cancel())
        alert.addAction(UIAlertAction(title: SantanderL10n.t("Set"), style: .default) { [weak self, weak alert] _ in
            guard let self, let text = alert?.textFields?.first?.text, let id = Int32(text), (-2...501).contains(id) else {
                self?.errorAlert("The ID must be between -2 and 501.", title: "Invalid ID")
                return
            }
            do {
                try self.type.set(id: id, forURL: self.fileURL)
                switch self.type {
                case .owner:
                    self.sourceVC?.permissions.ownerID = id
                    self.sourceVC?.permissions.ownerName = PathGroupOwnerViewController.nameForUID(id)
                case .group:
                    self.sourceVC?.permissions.groupID = id
                    self.sourceVC?.permissions.groupOwnerName = PathGroupOwnerViewController.nameForGID(id)
                }
                self.sourceVC?.tableView.reloadData()
            } catch {
                self.errorAlert(error, title: "Unable to change \(self.type.title.lowercased())")
            }
        })
        present(alert, animated: true)
    }

    static func nameForUID(_ id: Int32) -> String? {
        guard let entry = getpwuid(uid_t(id))?.pointee.pw_name else {
            return nil
        }
        return String(cString: entry)
    }

    static func nameForGID(_ id: Int32) -> String? {
        guard let entry = getgrgid(gid_t(id))?.pointee.gr_name else {
            return nil
        }
        return String(cString: entry)
    }

    enum ItemType: Hashable, CustomStringConvertible {
        case owner(id: Int32, name: String?)
        case group(id: Int32, name: String?)

        var id: Int32 {
            switch self {
            case .owner(let id, _), .group(let id, _):
                return id
            }
        }

        var name: String {
            switch self {
            case .owner(let id, let name), .group(let id, let name):
                return name ?? "ID \(id)"
            }
        }

        var subtitle: String {
            "\(id)"
        }

        var title: String {
            switch self {
            case .owner:
                return "Owner"
            case .group:
                return "Group"
            }
        }

        var description: String {
            "\(name) (\(id))"
        }

        static func candidates(forURL url: URL, type: ItemType) -> [ItemType] {
            var result: [ItemType] = []
            for rawID in -2...501 {
                let id = Int32(rawID)
                switch type {
                case .owner:
                    result.append(.owner(id: id, name: PathGroupOwnerViewController.nameForUID(id)))
                case .group:
                    result.append(.group(id: id, name: PathGroupOwnerViewController.nameForGID(id)))
                }
            }

            let current: ItemType
            switch type {
            case .owner:
                var buffer = stat()
                lstat(url.path, &buffer)
                current = .owner(id: Int32(buffer.st_uid), name: PathGroupOwnerViewController.nameForUID(Int32(buffer.st_uid)))
            case .group:
                var buffer = stat()
                lstat(url.path, &buffer)
                current = .group(id: Int32(buffer.st_gid), name: PathGroupOwnerViewController.nameForGID(Int32(buffer.st_gid)))
            }

            if !result.contains(current) {
                result.insert(current, at: 0)
            }
            return result
        }

        func set(forURL url: URL) throws {
            try RootConf.shared.runHelper(arguments: arguments(for: url))
        }

        func set(id: Int32, forURL url: URL) throws {
            try RootConf.shared.runHelper(arguments: arguments(for: url, id: id))
        }

        func arguments(for url: URL, id: Int32? = nil) -> [String] {
            switch self {
            case .owner(_, let name):
                if let id {
                    return ["set-owner-or-group", url.path, "--owner-id", String(id)]
                }
                return ["set-owner-or-group", url.path, "--owner-name", name ?? ""]
            case .group(_, let name):
                if let id {
                    return ["set-owner-or-group", url.path, "--group-id", String(id)]
                }
                return ["set-owner-or-group", url.path, "--group-name", name ?? ""]
            }
        }
    }

    func applyItems(_ items: [ItemType], animatingDifference: Bool = false) {
        var snapshot = NSDiffableDataSourceSnapshot<Section, ItemType>()
        snapshot.appendSections([.main])
        snapshot.appendItems(items, toSection: .main)
        dataSource.apply(snapshot, animatingDifferences: animatingDifference)
    }
}

extension PathGroupOwnerViewController: UISearchBarDelegate {
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        if searchText.isEmpty {
            applyItems(allData, animatingDifference: true)
            return
        }

        let filtered = allData.filter { item in
            item.name.localizedCaseInsensitiveContains(searchText)
        }

        applyItems(filtered, animatingDifference: true)
    }

    func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
        applyItems(allData, animatingDifference: true)
    }
}

extension PathListViewController: AudioPlayerToolbarDelegate {

    @objc
    func setupOrUpdateToolbar() {

        let trashAction = UIAction {
            let confirmationController = UIAlertController(title: "Are you sure you want to delete \(self.selectedItems.count) item(s)?", message: nil, preferredStyle: .alert)

            let deleteAction = UIAlertAction(title: SantanderL10n.t("Delete"), style: .destructive) { _ in

                do {
                    try FSOperation.perform(.removeItems(items: self.selectedItems.map(\.url)), rootHelperConf: RootConf.shared)
                } catch {
                    self.errorAlert(error, title: "Unable to remove items")
                }

            }

            confirmationController.addAction(.cancel())
            confirmationController.addAction(deleteAction)
            self.present(confirmationController, animated: true)
        }

        let trash = UIBarButtonItem(systemItem: .trash, primaryAction: trashAction)
        trash.tintColor = UIColor.systemRed

        let shareAction = UIAction {
            self.presentActivityVC(forItems: self.selectedItems)
        }

        let share = UIBarButtonItem(image: UIImage(systemName: "square.and.arrow.up"), primaryAction: shareAction)
        let moreItems = UIBarButtonItem(image: UIImage(systemName: "ellipsis.circle"), menu: makeToolbarMoreItemsMenu())
        let items = [trash, .flexibleSpace(), share, .flexibleSpace(), moreItems].map { item in
            item.isEnabled = !selectedItems.isEmpty
            return item
        }

        self.toolbarItems = items
        self.navigationController?.setToolbarHidden(false, animated: true)
        self.navigationController?.toolbar.viewWithTag(100)?.removeFromSuperview()
    }

    @objc
    func hideToolbarItems() {
        self.toolbarItems = []
        self.navigationController?.setToolbarHidden(true, animated: true)

        setupAudioToolbarIfPossible()
    }

    fileprivate func makeToolbarMoreItemsMenu() -> UIMenu {
        let moveAction = UIAction(title: "Move", image: UIImage(systemName: "arrow.right")) { _ in
            let vc = PathOperationViewController(paths: self.selectedItems.toURL(), operationType: .move)
            self.present(UINavigationController(rootViewController: vc), animated: true)
        }

        let copyAction = UIAction(title: "Copy", image: UIImage(systemName: "doc.on.doc")) { _ in
            let vc = PathOperationViewController(paths: self.selectedItems.toURL(), operationType: .copy)
            self.present(UINavigationController(rootViewController: vc), animated: true)
        }

        let symlinkAction = UIAction(title: "Alias", image: UIImage(systemName: "link")) { _ in
            let vc = PathOperationViewController(paths: self.selectedItems.toURL(), operationType: .symlink)
            self.present(UINavigationController(rootViewController: vc), animated: true)
        }

        var children: [UIMenuElement] = [symlinkAction, moveAction, copyAction]
        if let currentPath = currentPath {
            let compresMenu = makeCompressionMenu(paths: self.selectedItems) { format in
                return currentPath.appendingPathComponent("Archive").appendingPathExtension(format.fileExtension)
            }

            children.append(compresMenu)
        }

        return UIMenu(children: children)
    }

    @objc
    func setLeftBarSelectionButtonItem() {
        if !isEditing {
            navigationItem.leftBarButtonItem = nil
            return
        }

        let contents = self.contents
        let allItemsSelected = selectedItems.count == contents.count
        let action = UIAction {
            for index in contents.indices {
                if !allItemsSelected {
                    self.tableView.selectRow(at: IndexPath(row: index, section: 0), animated: true, scrollPosition: .none)
                } else {
                    self.tableView.deselectRow(at: IndexPath(row: index, section: 0), animated: true)
                }
            }

            self.selectedItems = allItemsSelected ? [] : contents
            self.setLeftBarSelectionButtonItem()
        }

        self.navigationItem.leftBarButtonItem = UIBarButtonItem(title: allItemsSelected ? "Deselect All" : "Select All", primaryAction: action)
        setupOrUpdateToolbar()
    }

    func setupAudioToolbarIfPossible() {
        guard let audioPlayerController = audioPlayerController, let toolbar = navigationController?.toolbar else {
            return
        }

        navigationController?.setToolbarHidden(false, animated: true)

        let glassView = LLGlassView(configuration: SantanderGlass.toolbar)
        glassView.frame = toolbar.bounds
        glassView.autoresizingMask = [.flexibleWidth, .flexibleHeight]

        let audioToolbarView = AudioPlayerToolbarView(audioPlayerController, frame: glassView.bounds)
        audioToolbarView.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        audioToolbarView.delegate = self
        glassView.glassContentView.addSubview(audioToolbarView)
        glassView.tag = 100
        glassView.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(toolbarAudioPreviewWasTapped)))
        toolbar.addSubview(glassView)
    }

    @objc
    func toolbarAudioPreviewWasTapped() {
        guard let vc = audioPlayerController else {
            return
        }

        UIApplication.shared.sceneKeyWindow?.rootViewController?.present(UINavigationController(rootViewController: vc), animated: true)
    }

    func audioToolbarDidClickCancelButton(_ toolbar: AudioPlayerToolbarView) {
        let rootNav = UIApplication.shared.sceneKeyWindow?.rootViewController as? UINavigationController
        rootNav?.toolbar?.viewWithTag(100)?.removeFromSuperview()
        rootNav?.setToolbarHidden(true, animated: true)

        toolbar.audioPlayerController.player.stop()
        toolbar.audioPlayerController.removeFromSystemMediaPlayer()
        self.audioPlayerController = nil
    }
}

class PathOperationViewController: PathListViewController {

    let paths: [URL]

    let operationType: PathSelectionOperation

    let dismissWhenDone: Bool

    init(paths: [URL], operationType: PathSelectionOperation, startingPath: Path = .root, dismissWhenDone: Bool = true) {
        self.paths = paths
        self.operationType = operationType
        self.dismissWhenDone = dismissWhenDone

        super.init(path: startingPath)
    }

    required init?(coder: NSCoder) {
        fatalError("Not implemented")
    }

    override func viewDidLoad() {
        super.viewDidLoad()

        self.navigationController?.navigationBar.prefersLargeTitles = false
        self.title = self.operationType.verbDescription
        if let currentPath = self.currentPath {
            self.navigationItem.backBarButtonItem = UIBarButtonItem(title: currentPath.lastPathComponent, style: .plain, target: nil, action: nil)
        }

        for path in paths {
            _ = path.startAccessingSecurityScopedResource()
        }
    }

    @objc func done() {
        guard let currentPath = self.currentPath else {
            self.errorAlert("Unable to get current path to \(operationType.description) to, out!", title: "Can't \(operationType.description) path")
            return
        }

        do {
            switch operationType {
            case .move:
                try FSOperation.perform(.moveItem(items: paths, resultPath: currentPath.url), rootHelperConf: RootConf.shared)
            case .copy, .import:
                try FSOperation.perform(.copyItem(items: paths, resultPath: currentPath.url), rootHelperConf: RootConf.shared)
            case .symlink:
                try FSOperation.perform(.symlink(items: paths, resultPath: currentPath.url), rootHelperConf: RootConf.shared)
            case .custom(_, _, let action):
                try action(self, currentPath.url)
            }

            if dismissWhenDone {
                self.dismiss(animated: true)
            }
        } catch {
            self.errorAlert(error, title: "Unable to \(operationType.description) items")
        }

    }

    override func goToPath(path: Path) {
        let parentDirectory = path.deletingLastPathComponent()

        if parentDirectory != currentPath {
            traverseThroughPath(path)
            return
        }

        if path.isDirectory {
            self.navigationController?.pushViewController(PathOperationViewController(paths: paths, operationType: operationType, startingPath: path, dismissWhenDone: dismissWhenDone), animated: true)
        } else {
            self.goToFile(path: path)
        }
    }

    override func traverseThroughPath(_ path: Path) {
        let vcs = path.url.fullPathComponents().map { [self] newPath in
            PathOperationViewController(paths: paths, operationType: operationType, startingPath: Path(url: newPath), dismissWhenDone: dismissWhenDone)
        }

        self.navigationController?.setViewControllers(vcs, animated: true)
    }

    @objc
    func cancel() {
        self.dismiss(animated: true)
    }

    override func setRightBarButton() {
        let doneButton = UIBarButtonItem(barButtonSystemItem: .done, target: self, action: #selector(done))
        let options = UIBarButtonItem(image: .init(systemName: "ellipsis.circle"), menu: makeRightBarButton())
        self.navigationItem.rightBarButtonItems = [doneButton, options]
    }

    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)

        for path in paths {
            path.stopAccessingSecurityScopedResource()
        }
    }
}

enum PathSelectionOperation: CustomStringConvertible {
    case move
    case copy
    case `import`
    case symlink
    case custom(description: String, verbDescription: String, action: (PathOperationViewController, URL) throws -> Void)

    var description: String {
        switch self {
        case .move:
            return "move"
        case .copy:
            return "copy"
        case .import:
            return "import"
        case .symlink:
            return "symlink"
        case .custom(description: let description, _, _):
            return description
        }
    }

    var verbDescription: String {
        switch self {
        case .move:
            return "Moving to.."
        case .copy:
            return "Copying to.."
        case .import:
            return "Importing to.."
        case .symlink:
            return "Aliasing to.."
        case .custom(_, verbDescription: let verbDescription, _):
            return verbDescription
        }
    }
}

extension PathListViewController: UITableViewDropDelegate, UITableViewDragDelegate {

    func tableView(_ tableView: UITableView, performDropWith coordinator: UITableViewDropCoordinator) {
        for item in coordinator.items {
            item.dragItem.itemProvider.loadFileRepresentation(forTypeIdentifier: "public.item") { url, err in
                guard let url = url, err == nil else {
                    DispatchQueue.main.async {
                        self.errorAlert("Error: \(err?.localizedDescription ?? "Unknown")", title: "Failed to import file")
                    }
                    return
                }

                guard let currentPath = self.currentPath else {
                    return
                }

                do {
                    try FSOperation.perform(.moveItem(items: [url], resultPath: currentPath.url), rootHelperConf: RootConf.shared)
                } catch {
                    DispatchQueue.main.async {
                        self.errorAlert("Error: \(error.localizedDescription)", title: "Failed to copy item")
                    }
                }
            }
        }
    }

    func tableView(_ tableView: UITableView, canHandle session: UIDropSession) -> Bool {
        return currentPath != nil
    }

    func tableView(_ tableView: UITableView, itemsForBeginning session: UIDragSession, at indexPath: IndexPath) -> [UIDragItem] {
        guard !displayingSearchSuggestions else {
            return []
        }

        let selectedItem = path(forIndexPath: indexPath)
        let itemProvider = NSItemProvider()

        let typeID = selectedItem.contentType?.identifier ?? UTType.content.identifier

        itemProvider.registerFileRepresentation(
            forTypeIdentifier: typeID,
            visibility: .all) { completion in
                completion(selectedItem.url, true, nil)
                return nil
            }

        return [
            UIDragItem(itemProvider: itemProvider)
        ]
    }
}

class RenamerTextField: UITextField {
    override var canBecomeFirstResponder: Bool {
        true
    }

    let path: Path
    var notifyShouldReturnUponResigning: Bool = true

    init(path: Path) {
        self.path = path
        super.init(frame: .zero)
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    @discardableResult
    override func resignFirstResponder() -> Bool {
        if notifyShouldReturnUponResigning {
            return delegate?.textFieldShouldReturn?(self) ?? true
        }

        return super.resignFirstResponder()
    }
}

class PathInformationTableViewController: UITableViewController {
    let path: Path
    let metadata: PathMetadata

    var showByteCount: Bool = false
    var showDisplayName: Bool = false
    var showRealPath: Bool = false
    var showAppName: Bool
    var appName: String?

    var sizeState: LoadingValueState<Int> = .loading

    init(style: UITableView.Style, path: Path) {
        self.path = path
        self.metadata = PathMetadata(filePath: path)
        appName = path.applicationItem?.localizedName

        showAppName = (appName != nil)
        super.init(style: style)
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        applySantanderGlass()

        self.title = self.path.lastPathComponent
        DispatchQueue.global(qos: .userInteractive).async { [self] in
            var path = path
            if let size = path.size {
                sizeState = .value(size)
            } else {
                sizeState = .unavailable
            }

            DispatchQueue.main.async {
                self.tableView.reloadRows(at: [IndexPath(row: 2, section: 0)], with: .fade)
            }
        }
    }

    override func numberOfSections(in tableView: UITableView) -> Int {
        return 4
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        switch section {
        case 0:
            return self.path.isDirectory ? 4 : 3
        case 1:
            return metadata.contentType?.preferredMIMEType != nil ? 2 : 1
        case 2:
            return 4
        case 3:
            return 1
        default:
            fatalError("Impossible to be here")
        }
    }

    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        switch (indexPath.section, indexPath.row) {
        case (0, 0):
            if appName != nil {
                showAppName.toggle()
            } else if path.displayName != path.lastPathComponent {
                showDisplayName.toggle()
            }

        case (0, 1):
            showRealPath.toggle()
        case (0, 2):
            showByteCount.toggle()
        case (3, 0):
            guard let permissions = metadata.permissions else {
                return
            }

            self.navigationController?.pushViewController(PathPermissionsViewController(permissions: permissions), animated: true)
        default:
            return
        }

        tableView.reloadRows(at: [indexPath], with: .automatic)
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = UITableViewCell(style: .value1, reuseIdentifier: nil)
        var conf = cell.defaultContentConfiguration()
        switch (indexPath.section, indexPath.row) {
        case (0, 0):
            if showDisplayName {
                conf.text = "Display name"
                conf.secondaryText = self.path.displayName
            } else if showAppName {
                conf.text = "App name"
                conf.secondaryText = appName
            } else {
                conf.text = "Name"
                conf.secondaryText = path.lastPathComponent
            }

        case (0, 1):
            conf.text = showRealPath ? "Real Path" : "Path"
            if showRealPath {
                conf.secondaryText = path.resolvedURL.path
            } else {
                conf.secondaryText = self.path.path
            }

        case (0, 2):
            conf.text = "Size"
            switch sizeState {
            case .loading:
                let spinner = UIActivityIndicatorView()
                spinner.startAnimating()
                spinner.translatesAutoresizingMaskIntoConstraints = false
                cell.addSubview(spinner)

                NSLayoutConstraint.activate([
                    spinner.trailingAnchor.constraint(equalTo: cell.layoutMarginsGuide.trailingAnchor),
                    spinner.centerYAnchor.constraint(equalTo: cell.centerYAnchor)
                ])

            case .unavailable:
                conf.secondaryText = "N/A"
            case .value(let size):
                let formatter = ByteCountFormatter()
                formatter.countStyle = .file
                formatter.allowedUnits = .useAll
                formatter.includesActualByteCount = showByteCount
                conf.secondaryText = formatter.string(fromByteCount: Int64(size))
            }
        case (0, 3):
            conf.text = "Items"
            conf.secondaryText = self.path.contents.count.description
        case (1, 0):
            conf.text = "Type"
            conf.secondaryText = metadata.contentType?.localizedDescription?.localizedCapitalized ?? "N/A"
        case (1, 1):
            conf.text = "MIME Type"
            conf.secondaryText = metadata.contentType?.preferredMIMEType ?? "N/A"
        case (2, 0):
            conf.text = "Created"
            conf.secondaryText = metadata.creationDate?.listFormatted() ?? "N/A"
        case (2, 1):
            conf.text = "Added"
            conf.secondaryText = metadata.addedToDirectoryDate?.listFormatted() ?? "N/A"
        case (2, 2):
            conf.text = "Modified"
            conf.secondaryText = metadata.lastModifiedDate?.listFormatted() ?? "N/A"
        case (2, 3):
            conf.text = "Accessed"
            conf.secondaryText = metadata.lastAccessedDate?.listFormatted() ?? "N/A"
        case (3, 0):
            conf.text = "Permissions"
            cell.accessoryType = .disclosureIndicator
            cell.isUserInteractionEnabled = metadata.permissions != nil
        default: break
        }

        cell.contentConfiguration = conf
        return cell
    }

    override func tableView(_ tableView: UITableView, shouldHighlightRowAt indexPath: IndexPath) -> Bool {
        switch (indexPath.section, indexPath.row) {
        case (0, 0):
            return path.displayName != path.lastPathComponent || appName != nil
        case (0, 1):
            return (try? FileManager.default.destinationOfSymbolicLink(atPath: self.path.path)) != nil
        case (0, 2):
            return true
        case (3, 0):
            return metadata.permissions != nil
        default:
            return false
        }
    }

    override func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        return headerTitle(forSection: section)
    }

    override func tableView(_ tableView: UITableView, contextMenuConfigurationForRowAt indexPath: IndexPath, point: CGPoint) -> UIContextMenuConfiguration? {
        let cell = self.tableView(tableView, cellForRowAt: indexPath)
        guard let conf = cell.contentConfiguration as? UIListContentConfiguration, let secondaryText = conf.secondaryText else { return nil }

        return UIContextMenuConfiguration(identifier: nil, previewProvider: nil) { _ in
            let copyAction = UIAction(title: "Copy", image: UIImage(systemName: "doc.on.doc")) { _ in
                UIPasteboard.general.string = secondaryText
            }

            return UIMenu(children: [copyAction])
        }
    }

    func headerTitle(forSection section: Int) -> String {
        switch section {
        case 0: return "General"
        case 1: return "Type"
        case 2: return "Date Metadata"
        case 3: return "Permissions"
        default: fatalError("\(#function): Unknown Section num \(section)")
        }
    }
}


class AssetCatalogViewController: UIViewController {
    typealias DataSource = UICollectionViewDiffableDataSource<RenditionType, Rendition>
    typealias SupplementaryRegistration = UICollectionView.SupplementaryRegistration<AssetCatalogSectionHeader>
    typealias CellRegistration = UICollectionView.CellRegistration<AssetCatalogCell, Rendition>

    static let titleElementKind = "RenditionTypeTitle"

    let fileURL: URL
    var renditionCollection: RenditionCollection
    var catalog: CUICatalog
    fileprivate var editorDelegate: ItemEditorDelegate?

    var collectionView: UICollectionView!
    var dataSource: DataSource!
    var noResultsLabel: UILabel = UILabel()
    var layoutMode: LayoutMode = LayoutMode(UserPreferences.assetCatalogControllerLayoutMode) {
        didSet {
            collectionView.setCollectionViewLayout(createLayout(), animated: true)
            UserPreferences.assetCatalogControllerLayoutMode = layoutMode.rawValue
        }
    }

    init(renditions: RenditionCollection, fileURL: URL, catalog: CUICatalog) {
        self.renditionCollection = renditions
        self.fileURL = fileURL
        self.catalog = catalog
        super.init(nibName: nil, bundle: nil)
    }

    convenience init(catalogFileURL fileURL: URL) throws {
        let (catalog, renditions) = try AssetCatalogWrapper.shared.renditions(forCarArchive: fileURL)
        self.init(renditions: renditions, fileURL: fileURL, catalog: catalog)
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    override func viewDidLoad() {
        super.viewDidLoad()

        if !UIDevice.isiPad {
            let filename = fileURL.deletingPathExtension()
            title = filename.lastPathComponent
            navigationController?.navigationBar.prefersLargeTitles = true
        }

        navigationItem.hidesSearchBarWhenScrolling = false

        let searchController = UISearchController()
        searchController.searchBar.delegate = self
        navigationItem.searchController = searchController

        configureCollectionView()
        configureDataSource()

        setupBarItems()
    }

    override var keyCommands: [UIKeyCommand]? {
        return [
            UIKeyCommand(title: "Scroll Up", action: #selector(goUpOrDown(sender:)), input: UIKeyCommand.inputUpArrow, modifierFlags: .command),
            UIKeyCommand(title: "Scroll Down", action: #selector(goUpOrDown(sender:)), input: UIKeyCommand.inputDownArrow, modifierFlags: .command)
        ]
    }

    @objc
    func goUpOrDown(sender: UIKeyCommand) {
        switch sender.input {
        case UIKeyCommand.inputDownArrow:
            let snapshot = dataSource.snapshot()
            if let last = snapshot.sectionIdentifiers.last {
                let section = snapshot.sectionIdentifiers.count
                let row = snapshot.itemIdentifiers(inSection: last).count
                collectionView.scrollToItem(at: IndexPath(row: row - 1, section: section - 1), at: .bottom, animated: true)
            }
        case UIKeyCommand.inputUpArrow:
            collectionView.scrollToItem(at: IndexPath(row: 0, section: 0), at: .top, animated: true)
        default:
            break
        }
    }

    func configureCollectionView() {
        self.collectionView = UICollectionView(frame: .zero, collectionViewLayout: createLayout())
        collectionView.translatesAutoresizingMaskIntoConstraints = false
        collectionView.backgroundColor = .systemBackground
        collectionView.dragDelegate = self
        collectionView.delegate = self
        view.addSubview(collectionView)
        collectionView.constraintCompletely(to: view)
    }

    func makeMenuForBarButton() -> UIMenu {
        let extractAction = UIAction(title: "Extract to..") { _ in
            self.extractAction()
        }

        let changeLayoutActions = LayoutMode.allCases.map { [self] mode in
            return UIAction(title: mode.description, state: layoutMode == mode ? .on : .off) { [self] _ in
                layoutMode = mode
                setupBarItems()
            }
        }

        let changeLayoutMenu = UIMenu(title: "Layout", children: changeLayoutActions)
        return UIMenu(children: [extractAction, changeLayoutMenu])
    }

    func setupBarItems() {
        let dismissAction = UIAction { _ in
            self.dismiss(animated: true)
        }

        navigationItem.rightBarButtonItem = UIBarButtonItem(systemItem: .close, primaryAction: dismissAction)
        let barButtonWithMenu = UIBarButtonItem(image: UIImage(systemName: "ellipsis.circle"), menu: makeMenuForBarButton())

        if UIDevice.isiPad {
            splitViewController?.viewController(for: .primary)?.navigationItem.rightBarButtonItem = barButtonWithMenu
        } else {
            navigationItem.leftBarButtonItem = barButtonWithMenu
        }
    }

    func extractAction() {
        let action: PathSelectionOperation = .custom(description: "extract", verbDescription: "Extracting to..") { [self] operationVC, selectedPath in
            let extractionPath = selectedPath
                .appendingPathComponent("\(fileURL.lastPathComponent)-Extracted")

            extractItems(extractionPath: extractionPath, sourceVC: operationVC) { error in
                if let error = error {
                    operationVC.errorAlert(error, title: "Unable to extract items")
                } else {
                    operationVC.dismiss(animated: true) {
                        self.dismiss(animated: true) {
                            let rootVC = UIApplication.shared.sceneKeyWindow?.rootViewController
                            let vcToPushFrom: PathTransitioning?

                            if UIDevice.isiPad {
                                vcToPushFrom = (rootVC as? UISplitViewController)?.viewController(for: .primary) as? PathTransitioning
                            } else {
                                vcToPushFrom = (rootVC as? UINavigationController)?.visibleViewController as? PathTransitioning
                            }

                            vcToPushFrom?.goToPath(path: Path(url: extractionPath))
                        }
                    }
                }
            }
        }

        let vc = PathOperationViewController(paths: [fileURL], operationType: action, dismissWhenDone: false)
        present(UINavigationController(rootViewController: vc), animated: true) {
            vc.goToPath(path: Path(url: self.fileURL.deletingLastPathComponent()))
        }
    }

    func extractItems(
        extractionPath savePath: URL,
        sourceVC: UIViewController,
        completionHandler: @escaping (Error?) -> Void
    ) {
        let alertController = createAlertWithSpinner(title: "Extracting..")
        sourceVC.present(alertController, animated: true)

        DispatchQueue.global(qos: .userInitiated).async {
            var caughtError: Error?

            do {
                try FSOperation.perform(.extractCatalog(catalogFileURL: self.fileURL, resultPath: savePath), rootHelperConf: RootConf.shared)
            } catch {
                caughtError = error
            }

            DispatchQueue.main.async {
                alertController.dismiss(animated: true) {
                    completionHandler(caughtError)
                }
            }
        }
    }

    enum LayoutMode: Int, CustomStringConvertible, CaseIterable {
        case horizantal
        case verical

        init(_ rawValue: Int) {
            switch rawValue {
            case LayoutMode.horizantal.rawValue: self = .horizantal
            default: self = .verical
            }
        }

        var description: String {
            switch self {
            case .horizantal:
                return "Horizontal"
            case .verical:
                return "Vertical"
            }
        }
    }
}

extension AssetCatalogViewController: UICollectionViewDelegate {
    func createLayout() -> UICollectionViewLayout {
        let section: NSCollectionLayoutSection

        switch layoutMode {
        case .verical:
            let itemSize = NSCollectionLayoutSize(widthDimension: .fractionalWidth(1.0),
                                                  heightDimension: .fractionalHeight(1.0))
            let item = NSCollectionLayoutItem(layoutSize: itemSize)
            let groupSize = NSCollectionLayoutSize(widthDimension: .fractionalWidth(1.0),
                                                   heightDimension: .absolute(60))

            let group = NSCollectionLayoutGroup.horizontal(layoutSize: groupSize, subitem: item, count: 1)
            let spacing = CGFloat(10)
            group.interItemSpacing = .fixed(spacing)

            section = NSCollectionLayoutSection(group: group)
            section.interGroupSpacing = spacing
            section.contentInsets = NSDirectionalEdgeInsets(top: 0, leading: spacing, bottom: 0, trailing: spacing)
        case .horizantal:
            let itemSize = NSCollectionLayoutSize(
                widthDimension: .fractionalWidth(1),
                heightDimension: .fractionalHeight(0.40)
            )

            let layoutItem = NSCollectionLayoutItem(layoutSize: itemSize)
            layoutItem.contentInsets = NSDirectionalEdgeInsets(top: 0, leading: 5, bottom: 3, trailing: 5)

            let layoutGroupSize = NSCollectionLayoutSize(
                widthDimension: .fractionalWidth(0.93),
                heightDimension: .fractionalWidth(0.55)
            )

            let layoutGroup: NSCollectionLayoutGroup = .vertical(
                layoutSize: layoutGroupSize,
                subitem: layoutItem,
                count: 3
            )

            layoutGroup.interItemSpacing = .fixed(15)

            section = NSCollectionLayoutSection(group: layoutGroup)
            section.orthogonalScrollingBehavior = .groupPagingCentered
        }

        let titleHeaderSize = NSCollectionLayoutSize(
            widthDimension: .fractionalWidth(0.93),
            heightDimension: .absolute(50)
        )

        let titleSupplementary = NSCollectionLayoutBoundarySupplementaryItem(
            layoutSize: titleHeaderSize,
            elementKind: AssetCatalogViewController.titleElementKind,
            alignment: layoutMode == .horizantal ? .top : .topLeading
        )

        section.boundarySupplementaryItems = [titleSupplementary]
        let layout = UICollectionViewCompositionalLayout(section: section)
        let conf = UICollectionViewCompositionalLayoutConfiguration()
        conf.interSectionSpacing = 20

        layout.configuration = conf
        return layout
    }

    func configureDataSource() {
        let cellRegistration = CellRegistration { cell, indexPath, itemIdentifier in
            cell.rendition = itemIdentifier
            cell.configure()
        }

        dataSource = DataSource(collectionView: collectionView) { collectionView, indexPath, itemIdentifier in
            return collectionView.dequeueConfiguredReusableCell(using: cellRegistration, for: indexPath, item: itemIdentifier)
        }

        updateDataSourceItems(collection: renditionCollection)

        let supplementaryRegistration = SupplementaryRegistration(elementKind: AssetCatalogViewController.titleElementKind) { supplementaryView, elementKind, indexPath in
            let snapshot = self.dataSource.snapshot()
            let section = snapshot.sectionIdentifiers[indexPath.section]
            supplementaryView.configure(withSection: section, snapshot: snapshot, sender: self)
        }

        dataSource.supplementaryViewProvider = { (collectionView, string, indexPath) in
            return collectionView.dequeueConfiguredReusableSupplementary(using: supplementaryRegistration, for: indexPath)
        }
    }

    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        guard let item = dataSource.itemIdentifier(for: indexPath) else { return }
        let vc = AssetCatalogRenditionViewController(rendition: item, sender: self)
        present(UINavigationController(rootViewController: vc), animated: true)
    }

    func collectionView(_ collectionView: UICollectionView, contextMenuConfigurationForItemAt indexPath: IndexPath, point: CGPoint) -> UIContextMenuConfiguration? {
        guard let item = dataSource.itemIdentifier(for: indexPath) else { return nil }
        return UIContextMenuConfiguration(identifier: nil, previewProvider: nil) { _ in
            let copyNameAction = UIAction(title: "Copy name", image: UIImage(systemName: "doc.on.doc")) { _ in
                UIPasteboard.general.string = item.name
            }
            var children = [copyNameAction]

            if let image = item.image {
                let uiImage = UIImage(cgImage: image)
                let copyImageAction = UIAction(title: "Copy Image") { _ in
                    UIPasteboard.general.image = uiImage
                }

                children.append(copyImageAction)

                let saveImageAction = UIAction(title: "Save Image", image: UIImage(systemName: "square.and.arrow.down")) { _ in
                    self.saveImage(uiImage)
                }

                children.append(saveImageAction)
            }

            var attributes: UIMenuElement.Attributes = []

            if !item.type.isEditable {
                attributes = .disabled
            }

            let editAction = UIAction(title: "Edit", attributes: attributes) { _ in
                self.editItem(item)
            }

            children.append(editAction)

            let deleteItemAction = UIAction(title: "Delete", image: UIImage(systemName: "trash"), attributes: .destructive) { [self] _ in
                deleteItem(item, completion: nil)
            }

            children.append(deleteItemAction)

            return UIMenu(children: children)
        }
    }

    func deleteItem(_ item: Rendition, completion: ((Error?) -> Void)?) {
        do {
            try catalog.removeItem(item, fileURL: fileURL)

            let (newCatalog, newRenditions) = try AssetCatalogWrapper.shared.renditions(forCarArchive: fileURL)
            self.catalog = newCatalog
            self.renditionCollection = newRenditions
            updateDataSourceItems(collection: renditionCollection)
            completion?(nil)
        } catch {
            let completion = completion ?? { error in
                self.errorAlert(error, title: "Failed to delete item and update contents of file")
            }

            completion(error)
        }
    }

    func updateDataSourceItems(collection: RenditionCollection) {
        var snapshot = NSDiffableDataSourceSnapshot<RenditionType, Rendition>()
        for (section, items) in collection {
            snapshot.appendSections([section])
            snapshot.appendItems(items, toSection: section)
        }

        dataSource.apply(snapshot, animatingDifferences: true)

        if UIDevice.isiPad, let sidebar = splitViewController?.viewController(for: .primary) as? AssetCatalogSidebarListView {
            let sections = dataSource.snapshot().sectionIdentifiers
            var sidebarSnapshot = AssetCatalogSidebarListView.Snapshot()
            sidebarSnapshot.appendSections([.main])
            sidebarSnapshot.appendItems(sections, toSection: .main)
            sidebar.dataSource.apply(sidebarSnapshot)
        }
    }

    func editItem(_ item: Rendition, presentingFrom optionalVcToPresentFrom: UIViewController? = nil, callback: ((Error?) -> Void)? = nil) {
        guard let preview = item.representation else { return }

        let vcToPresentFrom = optionalVcToPresentFrom ?? self

        let errorCallback: ItemEditorDelegate.ErrorCallback = callback ?? { error in
            if let error = error {
                vcToPresentFrom.errorAlert(error, title: "Failed to edit item")
            }
        }

        editorDelegate = ItemEditorDelegate(sender: self, selectedRendition: item, finishedEditingCallback: errorCallback)
        let vc: UIViewController
        switch preview {
        case .image(_):
            var conf = PHPickerConfiguration()
            conf.filter = .images
            conf.selectionLimit = 1
            let photoVC = PHPickerViewController(configuration: conf)
            photoVC.delegate = editorDelegate
            vc = photoVC
        case .color(let currentCgColor):
            let colorVC = UIColorPickerViewController()
            colorVC.delegate = editorDelegate
            colorVC.selectedColor = UIColor(cgColor: currentCgColor)
            vc = colorVC
        case .rawData:
            let documentPicker = UIDocumentPickerViewController(forOpeningContentTypes: [.data], asCopy: true)
            documentPicker.delegate = editorDelegate
            vc = documentPicker
        }

        vcToPresentFrom.present(vc, animated: true)
    }
}

extension AssetCatalogViewController: UICollectionViewDragDelegate {
    func collectionView(_ collectionView: UICollectionView, itemsForBeginning session: UIDragSession, at indexPath: IndexPath) -> [UIDragItem] {
        guard let dragItem = dataSource.itemIdentifier(for: indexPath)?.makeDragItem() else { return [] }

        return [
            dragItem
        ]
    }
}

extension AssetCatalogViewController: UISearchBarDelegate {
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        noResultsLabel.removeFromSuperview()
        guard !searchText.isEmpty else {
            updateDataSourceItems(collection: renditionCollection)
            return
        }

        let newCollection = renditionCollection.map { (type, renditions) in
            let newRenditions = renditions.filter { rend in
                return rend.name.localizedCaseInsensitiveContains(searchText)
            }

            return (type, newRenditions)
        }.filter { (_, rends) in
            !rends.isEmpty
        }

        updateDataSourceItems(collection: newCollection)

        if newCollection.isEmpty, noResultsLabel.superview == nil {
            noResultsLabel.text = "No Results"
            noResultsLabel.font = .systemFont(ofSize: 20, weight: .bold)
            noResultsLabel.translatesAutoresizingMaskIntoConstraints = false
            view.addSubview(noResultsLabel)

            let guide = view.layoutMarginsGuide
            NSLayoutConstraint.activate([
                noResultsLabel.centerXAnchor.constraint(equalTo: guide.centerXAnchor),
                noResultsLabel.centerYAnchor.constraint(equalTo: guide.centerYAnchor)
            ])
        }
    }

    func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
        noResultsLabel.removeFromSuperview()
        updateDataSourceItems(collection: renditionCollection)
    }

    func fetchItemsFromFile() {
        do {
            let (newCatalog, newCollection) = try AssetCatalogWrapper.shared.renditions(forCarArchive: fileURL)
            self.catalog = newCatalog
            self.renditionCollection = newCollection
            updateDataSourceItems(collection: renditionCollection)
        } catch {
            let cancelAction = UIAlertAction(title: SantanderL10n.t("Dismiss"), style: .cancel) { _ in
                self.dismiss(animated: true)
            }

            errorAlert(error, title: "Unable to update items", presentingFromIfAvailable: nil, cancelAction: cancelAction)
        }
    }
}

extension AssetCatalogViewController {
    func scrollViewDidEndDragging(_ scrollView: UIScrollView, willDecelerate decelerate: Bool) {
        guard UIDevice.isiPad, !decelerate else { return }

        let visibleRect = CGRect(origin: collectionView.contentOffset, size: collectionView.bounds.size)
        let visiblePoint = CGPoint(x: visibleRect.midX, y: visibleRect.midY)

        guard let visibleIndexPath = collectionView.indexPathForItem(at: visiblePoint),
              let sidebar = splitViewController?.viewController(for: .primary) as? AssetCatalogSidebarListView else {
            return
        }

        sidebar.collectionView.selectItem(at: IndexPath(row: visibleIndexPath.section, section: 0), animated: true, scrollPosition: .top)
    }
}

extension AssetCatalogViewController {
    class ItemEditorDelegate: NSObject, PHPickerViewControllerDelegate, UIColorPickerViewControllerDelegate, UIDocumentPickerDelegate {
        let sender: AssetCatalogViewController
        let selectedRendition: Rendition

        typealias ErrorCallback = ((Error?) -> Void)
        var finishedEditingCallback: ErrorCallback?

        init(sender: AssetCatalogViewController, selectedRendition: Rendition, finishedEditingCallback: ErrorCallback?) {
            self.sender = sender
            self.selectedRendition = selectedRendition
            self.finishedEditingCallback = finishedEditingCallback
            super.init()
        }

        func picker(_ picker: PHPickerViewController, didFinishPicking results: [PHPickerResult]) {
            picker.dismiss(animated: true)
            guard let first = results.first else { return }
            first.itemProvider.loadObject(ofClass: UIImage.self) { [self] image, error in
                guard let image = image as? UIImage, let cgImage = image.cgImage else {
                    sender.errorAlert("Unable to acquire image selected", title: "Unable to edit item")
                    return
                }

                edit(to: .image(cgImage))
            }
        }

        func colorPickerViewControllerDidFinish(_ viewController: UIColorPickerViewController) {
            edit(to: .color(viewController.selectedColor.cgColor))
        }

        func documentPicker(_ controller: UIDocumentPickerViewController, didPickDocumentsAt urls: [URL]) {
            guard let url = urls.first else { return }
            let didAccess = url.startAccessingSecurityScopedResource()
            defer {
                if didAccess {
                    url.stopAccessingSecurityScopedResource()
                }
            }

            do {
                edit(to: .rawData(try Data(contentsOf: url)))
            } catch {
                finishedEditingCallback?(error)
            }
        }

        func edit(to newItem: Rendition.Representation) {
            DispatchQueue.main.async { [self] in
                let tmpFilename = "\(sender.fileURL.lastPathComponent)-TMP-EDIT-\(UUID().uuidString.prefix(5))"
                let temporaryFileURL = URL(fileURLWithPath: NSTemporaryDirectory()).appendingPathComponent(tmpFilename)
                do {
                    try FileManager.default.copyItem(at: sender.fileURL, to: temporaryFileURL)
                    try sender.catalog.editItem(selectedRendition, fileURL: temporaryFileURL, to: newItem)
                    try FSOperation.perform(.removeItems(items: [sender.fileURL]), rootHelperConf: RootConf.shared)
                    try FSOperation.perform(.rename(item: temporaryFileURL, newPath: sender.fileURL), rootHelperConf: RootConf.shared)

                    finishedEditingCallback?(nil)
                    sender.fetchItemsFromFile()
                } catch {
                    finishedEditingCallback?(error)
                }
            }
        }
    }
}

class AssetCatalogCell: UICollectionViewCell {
    let nameLabel: UILabel = UILabel()
    let subtitleLabel: UILabel = UILabel()
    lazy var circleView: UIView? = rendition?.representation?.uiView
    var rendition: Rendition?
}

extension AssetCatalogCell {
    static let cellBackgroundColor: UIColor = .quaternarySystemFill

    func configure() {
        setupShape()

        guard let rendition = rendition else { return }
        nameLabel.text = rendition.name
        subtitleLabel.text = makeSubtitleText(forRendition: rendition)
        subtitleLabel.font = .preferredFont(forTextStyle: .caption1)
        subtitleLabel.textColor = .secondaryLabel

        let labelsStackView = UIStackView(arrangedSubviews: [nameLabel, subtitleLabel])
        labelsStackView.translatesAutoresizingMaskIntoConstraints = false
        labelsStackView.axis = .vertical

        let stackView = UIStackView(arrangedSubviews: [labelsStackView])
        stackView.translatesAutoresizingMaskIntoConstraints = false
        stackView.spacing = 10

        contentView.addSubview(stackView)
        let guide = contentView.layoutMarginsGuide
        if let circleView = circleView {
            circleView.layer.cornerRadius = 20
            circleView.layer.cornerCurve = .circular
            circleView.translatesAutoresizingMaskIntoConstraints = false
            stackView.insertArrangedSubview(circleView, at: 0)

            NSLayoutConstraint.activate([
                circleView.heightAnchor.constraint(equalTo: guide.heightAnchor),
                circleView.widthAnchor.constraint(equalTo: guide.heightAnchor),
            ])
        }

        stackView.constraintCompletely(to: guide)
    }

    func makeSubtitleText(forRendition rend: Rendition) -> String {
        return "Scale: \(rend.cuiRend.scale())"
    }

    override var reuseIdentifier: String? {
        return rendition?.name
    }

    func setupShape() {
        var bgConf = UIBackgroundConfiguration.clear()
        bgConf.backgroundColor = AssetCatalogCell.cellBackgroundColor
        bgConf.cornerRadius = 14
        backgroundConfiguration = bgConf
    }
}

class AssetCatalogDetailsView: UIView {
    var catalog: CUICatalog

    init(catalog: CUICatalog) {
        self.catalog = catalog
        super.init(frame: .zero)

        let testLabel = UILabel()
        testLabel.text = "Hello"
        testLabel.translatesAutoresizingMaskIntoConstraints = false
        addSubview(testLabel)

        NSLayoutConstraint.activate([
            testLabel.centerXAnchor.constraint(equalTo: centerXAnchor),
            testLabel.leadingAnchor.constraint(equalTo: leadingAnchor)
        ])
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}

fileprivate extension CACornerMask {
    static func alongEdge(_ edge: CGRectEdge) -> CACornerMask {
        switch edge {
        case .maxXEdge: return [.layerMaxXMinYCorner, .layerMaxXMaxYCorner]
        case .maxYEdge: return [.layerMinXMaxYCorner, .layerMaxXMaxYCorner]
        case .minXEdge: return [.layerMinXMinYCorner, .layerMinXMaxYCorner]
        case .minYEdge: return [.layerMinXMinYCorner, .layerMaxXMinYCorner]
        }
    }
}

class AssetCatalogGridPreviewCell: UICollectionViewCell {
    var rendition: Rendition!
    var previewView: UIView!

    func configure() {
        var constraintCompletely: Bool = true
        if let preview = rendition.representation {
            previewView = preview.uiView
        } else {
            let noPreviewLabel = UILabel()
            noPreviewLabel.text = "No Preview."
            noPreviewLabel.textColor = .secondaryLabel
            previewView = noPreviewLabel
            constraintCompletely = false
        }

        previewView.clipsToBounds = true
        previewView.contentMode = .scaleAspectFit
        previewView.translatesAutoresizingMaskIntoConstraints = false

        contentView.addSubview(previewView)
        contentView.layer.cornerCurve = .continuous
        contentView.layer.cornerRadius = 12.0

        layer.shadowOpacity = 0.2
        layer.shadowRadius = 6.0

        pushCornerPropertiesToChildren()

        if constraintCompletely {
            previewView.constraintCompletely(to: contentView.layoutMarginsGuide)
        } else {
            NSLayoutConstraint.activate([
                previewView.centerXAnchor.constraint(equalTo: contentView.centerXAnchor),
                previewView.centerYAnchor.constraint(equalTo: contentView.centerYAnchor)
            ])
        }
    }

    override var reuseIdentifier: String? {
        rendition?.name
    }

    func pushCornerPropertiesToChildren() {
        previewView.layer.maskedCorners = contentView.layer.maskedCorners.union(.alongEdge(.maxYEdge))
        previewView.layer.cornerRadius = contentView.layer.cornerRadius
        previewView.layer.cornerCurve = contentView.layer.cornerCurve
    }
}

class AssetCatalogRenditionViewController: UIViewController {
    typealias DataSource = UICollectionViewDiffableDataSource<Section, ItemType>

    typealias DetailCellRegistration = UICollectionView.CellRegistration<UICollectionViewListCell, DetailItem>
    typealias ActionCellRegistration = UICollectionView.CellRegistration<UICollectionViewListCell, ItemAction>
    typealias GridPreviewCellRegistration = UICollectionView.CellRegistration<AssetCatalogGridPreviewCell, Rendition>

    var rendition: Rendition
    var collectionView: UICollectionView!
    var dataSource: DataSource!
    var sender: AssetCatalogViewController?

    init(rendition: Rendition, sender: AssetCatalogViewController?) {
        self.rendition = rendition
        self.sender = sender
        super.init(nibName: nil, bundle: nil)
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) hasn't been implemented")
    }

    override func viewDidLoad() {
        super.viewDidLoad()

        title = SantanderL10n.t("Info")
        configureCollectionView()
        configureDataSource()
        addItems()
    }

    func configureCollectionView() {
        self.collectionView = UICollectionView(frame: .zero, collectionViewLayout: makeLayout())
        collectionView.translatesAutoresizingMaskIntoConstraints = false
        collectionView.delegate = self
        collectionView.dragDelegate = self
        collectionView.backgroundColor = .secondarySystemBackground
        view.addSubview(collectionView)

        collectionView.constraintCompletely(to: view)
    }

    func editItem(sender: AssetCatalogViewController) {
        guard let saveIndx = sender.dataSource.indexPath(for: rendition) else { return }
        sender.editItem(rendition, presentingFrom: self) { [self] error in
            if let error = error {
                errorAlert(error, title: "Failed to edit item")
                return
            }

            dismiss(animated: true) {
                guard let newRend = sender.dataSource.itemIdentifier(for: saveIndx) else { return }
                let newVC = UINavigationController(rootViewController: AssetCatalogRenditionViewController(rendition: newRend, sender: sender))
                sender.present(newVC, animated: true)
            }
        }
    }

    func makeDetailCellBackgroundConfiguration() -> UIBackgroundConfiguration {
        var background = UIBackgroundConfiguration.listAccompaniedSidebarCell()
        background.cornerRadius = 8
        background.backgroundColor = .tertiarySystemBackground
        return background
    }

    func configureDataSource() {
        let listCellSecondaryTextFont: UIFont = .preferredFont(forTextStyle: .footnote)
        let detailCellBackgroundConf = makeDetailCellBackgroundConfiguration()

        let detailCellRegistration = DetailCellRegistration { cell, indexPath, details in
            var content = UIListContentConfiguration.cell()
            content.prefersSideBySideTextAndSecondaryText = true
            content.text = details.primaryText
            content.secondaryText = details.secondaryText
            content.secondaryTextProperties.font = listCellSecondaryTextFont
            cell.contentConfiguration = content
            cell.backgroundConfiguration = detailCellBackgroundConf
        }

        let previewCellRegistration = GridPreviewCellRegistration { cell, indexPath, itemIdentifier in
            cell.rendition = self.rendition
            cell.configure()
        }

        let actionCellRegistration = ActionCellRegistration { cell, indexPath, itemIdentifier in
            var conf = cell.defaultContentConfiguration()
            conf.text = itemIdentifier.displayText
            conf.image = itemIdentifier.displayImage

            if let color = itemIdentifier.textColor {
                conf.textProperties.color = color
            }

            conf.imageToTextPadding = 10
            cell.contentConfiguration = conf
            cell.backgroundConfiguration = detailCellBackgroundConf
        }

        self.dataSource = DataSource(collectionView: collectionView) { collectionView, indexPath, itemIdentifier in
            switch itemIdentifier {
            case .preview:
                return collectionView.dequeueConfiguredReusableCell(using: previewCellRegistration, for: indexPath, item: self.rendition)
            case .action(let action):
                return collectionView.dequeueConfiguredReusableCell(using: actionCellRegistration, for: indexPath, item: action)
            case .details(let detailItem):
                return collectionView.dequeueConfiguredReusableCell(using: detailCellRegistration, for: indexPath, item: detailItem)
            }
        }
    }

    func addItems() {
        var snapshot = NSDiffableDataSourceSnapshot<Section, ItemType>()
        snapshot.appendSections([.itemPreview])

        var actions: [ItemAction] = []
        if let image = rendition.image {
            let uiImage = UIImage(cgImage: image)

            let saveImageAction = ItemAction(displayText: "Save", displayImage: UIImage(systemName: "square.and.arrow.down")) {
                self.saveImage(uiImage)
            }

            let viewImageAction = ItemAction(displayText: "View", displayImage: UIImage(systemName: "magnifyingglass")) {
                let viewer = ImageViewerController(fileURL: nil, image: uiImage, title: self.rendition.name)
                self.present(UINavigationController(rootViewController: viewer), animated: true)
            }

            actions += [saveImageAction, viewImageAction]
        }

        if rendition.type.isEditable, let sender = sender {
            let editAction = ItemAction(displayText: "Edit", displayImage: UIImage(systemName: "gear")) {
                self.editItem(sender: sender)
            }

            actions.append(editAction)
        }

        if !actions.isEmpty {
            snapshot.appendSections([.itemActions])
            snapshot.appendItems(actions.map { return ItemType.action($0) }, toSection: .itemActions)
        }

        let size = rendition.cuiRend.unslicedSize()

        var itemDetails: [DetailItem] = []

        if rendition.namedLookup.name == rendition.namedLookup.renditionName {
            itemDetails.insert(DetailItem(primaryText: "Name", secondaryText: rendition.namedLookup.name), at: 0)
        } else {
            let bothNames = [
                DetailItem(primaryText: "Lookup Name", secondaryText: rendition.namedLookup.name),
                DetailItem(primaryText: "Rendition Name", secondaryText: rendition.namedLookup.renditionName)
            ]

            itemDetails.insert(contentsOf: bothNames, at: 0)
        }

        if !size.height.isZero {
            itemDetails.append(DetailItem(primaryText: "Height", secondaryText: size.height.description))
        }

        if !size.width.isZero {
            itemDetails.append(DetailItem(primaryText: "Width", secondaryText: size.width.description))
        }

        itemDetails.append(DetailItem(primaryText: "Scale", secondaryText: rendition.cuiRend.scale().description))

        let key = rendition.namedLookup.key
        let rendInfo: [DetailItem] = [
            DetailItem(primaryText: "Idiom", secondaryText: Rendition.Idiom(key)),
            DetailItem(primaryText: "Appearance", secondaryText: Rendition.Appearance(key)),
            DetailItem(primaryText: "Display Gamut", secondaryText: Rendition.DisplayGamut(key)),
            DetailItem(primaryText: "Type", secondaryText: rendition.type),
        ]

        snapshot.appendItems([.preview], toSection: .itemPreview)
        snapshot.appendSections([.itemInfo])
        snapshot.appendItems(ItemType.fromDetails(itemDetails), toSection: .itemInfo)

        if rendition.type == .multiSizeImageSet,
           let nsObjectSizes = rendition.cuiRend.value(forKey: "sizeIndexes") as? [NSObject] {
            let sizes = nsObjectSizes.compactMap { $0.value(forKey: "size") as? CGSize }
            let items = sizes.enumerated().map { (indx, size) in
                DetailItem(primaryText: "Size \(indx)", secondaryText: "Width: \(size.width), Height: \(size.height)")
            }

            snapshot.appendSections([.specificTypeInfo])
            snapshot.appendItems(ItemType.fromDetails(items), toSection: .specificTypeInfo)
        }

        switch rendition.representation {
        case .color(let cgColor):
            let uiColor = UIColor(cgColor: cgColor)
            let codableColor = CodableColor(uiColor)

            let colorSpaceName = (cgColor.colorSpace?.name as? String ?? "N/A")
                .replacingOccurrences(of: "kCGColorSpace", with: "")
            let colorDetails = [
                DetailItem(primaryText: "ColorSpace", secondaryText: colorSpaceName),
                DetailItem(primaryText: "Red", secondaryText: String(format: "%.3f", codableColor.red)),
                DetailItem(primaryText: "Blue", secondaryText: String(format: "%.3f", codableColor.blue)),
                DetailItem(primaryText: "Green", secondaryText: String(format: "%.3f", codableColor.green)),
            ]

            snapshot.insertSections([.specificTypeInfo], afterSection: .itemInfo)
            snapshot.appendItems(ItemType.fromDetails(colorDetails), toSection: .specificTypeInfo)
        default:
            break
        }

        snapshot.appendSections([.renditionKeyInfo])
        snapshot.appendItems(ItemType.fromDetails(rendInfo), toSection: .renditionKeyInfo)

        if let sender = sender {
            let deleteImage = UIImage(systemName: "trash")?.withTintColor(.systemRed, renderingMode: .alwaysOriginal)
            let deleteAction = ItemAction(displayText: "Delete", displayImage: deleteImage, textColor: .systemRed) {
                let confirmationAlert = UIAlertController(title: "Are you sure you want to delete this item?", message: nil, preferredStyle: .actionSheet)
                let deleteAction = UIAlertAction(title: SantanderL10n.t("Delete"), style: .destructive) { [self] _ in
                    sender.deleteItem(rendition) { [self] error in
                        if let error = error {
                            errorAlert(error, title: "Failed to delete item")
                        } else {
                            dismiss(animated: true)
                        }
                    }
                }

                confirmationAlert.addAction(deleteAction)
                confirmationAlert.addAction(.cancel())

                self.present(confirmationAlert, animated: true)
            }

            snapshot.appendSections([.deleteItem])
            snapshot.appendItems([.action(deleteAction)], toSection: .deleteItem)
        }

        dataSource.apply(snapshot)
    }

    func makeLayout() -> UICollectionViewLayout {
        lazy var snapshot = dataSource.snapshot()
        let layout = UICollectionViewCompositionalLayout { sectionIndex, enviroment in
            let section = snapshot.sectionIdentifiers[sectionIndex]
            switch section {
            case .itemPreview:
                let itemSize = NSCollectionLayoutSize(widthDimension: .fractionalWidth(1.0),
                                                     heightDimension: .estimated(180))
                let item = NSCollectionLayoutItem(layoutSize: itemSize)
                let groupSize = NSCollectionLayoutSize(widthDimension: .fractionalWidth(1.0),
                                                       heightDimension: .estimated(180))
                let group = NSCollectionLayoutGroup.horizontal(layoutSize: groupSize, subitem: item, count: 1)
                group.interItemSpacing = .fixed(20)

                return NSCollectionLayoutSection(group: group)
            case .itemActions:
                let itemSize = NSCollectionLayoutSize(widthDimension: .fractionalWidth(1.0),
                                                     heightDimension: .fractionalHeight(1.0))
                let item = NSCollectionLayoutItem(layoutSize: itemSize)

                let groupSize = NSCollectionLayoutSize(widthDimension: .fractionalWidth(1.0),
                                                      heightDimension: .absolute(44))
                let group = NSCollectionLayoutGroup.horizontal(layoutSize: groupSize, subitem: item, count: snapshot.numberOfItems(inSection: section))

                let spacing = CGFloat(10)
                group.interItemSpacing = .fixed(spacing)

                let section = NSCollectionLayoutSection(group: group)
                section.interGroupSpacing = spacing
                section.contentInsets = NSDirectionalEdgeInsets(top: 0, leading: 16, bottom: 0, trailing: 16)
                return section
            default:
                let list = NSCollectionLayoutSection.list(
                    using: .init(appearance: .sidebar),
                    layoutEnvironment: enviroment
                )
                list.interGroupSpacing = 5

                return list
            }
        }
        let config = UICollectionViewCompositionalLayoutConfiguration()
        config.interSectionSpacing = 10
        layout.configuration = config

        return layout
    }

    enum Section: Hashable {
        case itemPreview
        case itemActions
        case itemInfo
        case specificTypeInfo
        case renditionKeyInfo
        case deleteItem
    }

    enum ItemType: Hashable {
        case preview
        case action(ItemAction)
        case details(DetailItem)

        static func fromDetails(_ details: [DetailItem]) -> [ItemType] {
            return details.map { details in
                ItemType.details(details)
            }
        }
    }

    struct DetailItem: Hashable {
        let primaryText: String
        let secondaryText: String

        init(primaryText: String, secondaryText: String?) {
            self.primaryText = primaryText
            self.secondaryText = secondaryText ?? "N/A"
        }

        init<DetailTextType: CustomStringConvertible>(primaryText: String, secondaryText: DetailTextType?) {
            self.primaryText = primaryText
            self.secondaryText = secondaryText?.description ?? "N/A"
        }
    }

    struct ItemAction: Hashable {
        static func == (lhs: ItemAction, rhs: ItemAction) -> Bool {
            return lhs.displayText == rhs.displayText
        }

        let displayText: String
        let displayImage: UIImage?
        let textColor: UIColor?
        let action: (() -> Void)

        init(displayText: String, displayImage: UIImage?, textColor: UIColor? = nil, action: @escaping () -> Void) {
            self.displayText = displayText
            self.displayImage = displayImage
            self.textColor = textColor
            self.action = action
        }

        func hash(into hasher: inout Hasher) {
            hasher.combine(displayText)
            hasher.combine(displayImage)
            hasher.combine(textColor)
        }
    }
}

extension AssetCatalogRenditionViewController: UICollectionViewDelegate, UICollectionViewDragDelegate {
    func collectionView(_ collectionView: UICollectionView, contextMenuConfigurationForItemAt indexPath: IndexPath, point: CGPoint) -> UIContextMenuConfiguration? {
        UIContextMenuConfiguration(identifier: nil, previewProvider: nil) { [self] _ in
            let item = dataSource.itemIdentifier(for: indexPath)
            switch item {
            case .action(let itemAction):
                let menuAction = UIAction(title: itemAction.displayText, image: itemAction.displayImage) { _ in
                    itemAction.action()
                }

                return UIMenu(children: [menuAction])
            case .details(let detail):
                let menuAction = UIAction(title: "Copy", image: UIImage(systemName: "doc.on.doc")) { _ in
                    UIPasteboard.general.string = detail.secondaryText
                }

                return UIMenu(children: [menuAction])
            default:
                return nil
            }
        }
    }

    func collectionView(_ collectionView: UICollectionView, shouldHighlightItemAt indexPath: IndexPath) -> Bool {
        switch dataSource.itemIdentifier(for: indexPath) {
        case .action(_): return true
        default: return false
        }
    }

    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        switch dataSource.itemIdentifier(for: indexPath) {
        case .action(let action): action.action()
        default: break
        }
    }

    func collectionView(_ collectionView: UICollectionView, itemsForBeginning session: UIDragSession, at indexPath: IndexPath) -> [UIDragItem] {
        guard indexPath.section == 0, let dragItem = rendition.makeDragItem() else { return [] }

        if let cell = collectionView.cellForItem(at: indexPath) as? AssetCatalogGridPreviewCell {
            dragItem.previewProvider = {
                let params = UIDragPreviewParameters()
                params.backgroundColor = .clear
                return UIDragPreview(view: cell.previewView, parameters: params)
            }
        }

        return [
            dragItem
        ]
    }
}

class AssetCatalogSectionHeader: UICollectionReusableView {
    let stackView = UIStackView()

    let titleLabel = UILabel()
    let subtitleLabel = UILabel()

    func configure(withSection section: RenditionType, snapshot: NSDiffableDataSourceSnapshot<RenditionType, Rendition>, sender: AssetCatalogViewController) {
        titleLabel.text = section.description
        titleLabel.font = .preferredFont(forTextStyle: .title3)

        subtitleLabel.text = "\(snapshot.itemIdentifiers(inSection: section).count) Items"
        subtitleLabel.textColor = .secondaryLabel
        subtitleLabel.font = .preferredFont(forTextStyle: .caption1)

        stackView.addArrangedSubview(titleLabel)
        stackView.addArrangedSubview(subtitleLabel)

        stackView.axis = .vertical
        stackView.translatesAutoresizingMaskIntoConstraints = false
        addSubview(stackView)

        let guide = layoutMarginsGuide
        NSLayoutConstraint.activate([
            stackView.centerYAnchor.constraint(equalTo: guide.centerYAnchor),
            stackView.leadingAnchor.constraint(equalTo: guide.leadingAnchor)
        ])
    }
}

class AssetCatalogSidebarListView: UIViewController {

    enum Section: Hashable {
        case main
    }

    typealias DataSource = UICollectionViewDiffableDataSource<Section, RenditionType>
    typealias Snapshot = NSDiffableDataSourceSnapshot<Section, RenditionType>
    typealias CellRegistration = UICollectionView.CellRegistration<UICollectionViewListCell, RenditionType>

    let catalogController: AssetCatalogViewController

    var collectionView: UICollectionView!
    var dataSource: DataSource!

    lazy var sections: [RenditionType] = []

    init(catalogController: AssetCatalogViewController) {
        self.catalogController = catalogController

        super.init(nibName: nil, bundle: nil)
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    override func viewDidLoad() {
        super.viewDidLoad()

        makeCollectionView()
        makeDataSource()
        addItems()

        splitViewController?.setViewController(catalogController, for: .secondary)

        title = catalogController.fileURL.deletingPathExtension().lastPathComponent
        navigationController?.navigationBar.prefersLargeTitles = true
    }

    func makeCollectionView() {
        let layout = UICollectionViewCompositionalLayout { _, env in
            return .list(using: UICollectionLayoutListConfiguration(appearance: .sidebar), layoutEnvironment: env)
        }

        collectionView = UICollectionView(frame: .zero, collectionViewLayout: layout)
        collectionView.translatesAutoresizingMaskIntoConstraints = false
        collectionView.delegate = self
        view.addSubview(collectionView)

        collectionView.constraintCompletely(to: view)
    }

    func makeDataSource() {

        let cellRegistration = CellRegistration { cell, indexPath, itemIdentifier in
            var conf = cell.defaultContentConfiguration()
            conf.text = itemIdentifier.description
            conf.image = itemIdentifier.displayImage
            cell.contentConfiguration = conf
        }

        self.dataSource = DataSource(collectionView: collectionView) { collectionView, indexPath, itemIdentifier in
            return collectionView.dequeueConfiguredReusableCell(using: cellRegistration, for: indexPath, item: itemIdentifier)
        }
    }

    func addItems() {
        var snapshot = Snapshot()
        snapshot.appendSections([.main])
        snapshot.appendItems(sections, toSection: .main)
        dataSource.apply(snapshot)
    }
}

extension AssetCatalogSidebarListView: UICollectionViewDelegate {
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        catalogController.collectionView.scrollToItem(at: IndexPath(row: 0, section: indexPath.row), at: .top, animated: true)
    }
}

fileprivate extension RenditionType {
    var displayImage: UIImage? {
        switch self {
        case .image, .svg:
            return UIImage(systemName: "photo")
        case .icon:
            return UIImage(systemName: "app")
        case .imageSet:
            return UIImage(systemName: "photo.stack")
        case .multiSizeImageSet:
            return UIImage(systemName: "cube.box")
        case .pdf:
            return UIImage(systemName: "doc.richtext")
        case .color:
            return UIImage(systemName: "paintbrush")
        case .rawData:
            return UIImage(systemName: "text.quote")
        case .unknown:
            return UIImage(systemName: "questionmark.app")
        }
    }
}

class AudioPlayerViewController: UIViewController {
    let fileURL: URL
    var playButton: UIButton!
    var loopButton: UIButton!
    var playbackSlider: UISlider!
    var durationLabel: UILabel!
    var currentProgressLabel: UILabel!
    var forwardButton: UIButton!
    var backwardButton: UIButton!

    var player: AVAudioPlayer
    var asset: AVAsset
    lazy var displayLink: CADisplayLink = CADisplayLink(target: self, selector: #selector(sychronizeSliderProgress))

    var doLoop: Bool = false

    var playbackCallback: (() -> Void)? = nil

    var playbackSpeedRate: Float = UserPreferences.audioVCSpeed {
        didSet {
            UserPreferences.audioVCSpeed = playbackSpeedRate
            player.rate = playbackSpeedRate
        }
    }

    var itemName: String {
        let nameFromMetadata = asset.metadata.first { $0.commonKey?.rawValue == "title" }?.stringValue
        return nameFromMetadata ?? fileURL.lastPathComponent
    }

    var artistName: String? {
        return asset.metadata.first { $0.commonKey?.rawValue == "artist" }?.stringValue
    }

    var skipDuration: Int = UserPreferences.skipDuration {
        didSet {
            UserPreferences.skipDuration = skipDuration
        }
    }

    let availableSkipDurations: [Int] = [5, 10, 15, 30, 45, 60, 90]
    let availableSpeedRates: [Float] = [0.5, 1.0, 1.5, 2.0]

    lazy var artworkImage: UIImage? = _getArtworkImage()

    func _getArtworkImage() -> UIImage? {
        guard let data = asset.metadata.first(where: { $0.commonKey?.rawValue == "artwork" })?.dataValue, let image = UIImage(data: data) else {
            return nil
        }

        return image
    }

    func playButtonSymbolName() -> String {
        player.isPlaying ? "pause.fill" : "play.fill"
    }

    func playButtonImage(withSize pointSize: CGFloat = 45, imageTintColor: UIColor? = .systemGray) -> UIImage? {
        let conf = UIImage.SymbolConfiguration(pointSize: pointSize, weight: .medium, scale: .medium)

        let imageSymbolName = playButtonSymbolName()
        let image = UIImage(systemName: imageSymbolName, withConfiguration: conf)
        if let imageTintColor = imageTintColor {
            return image?.withTintColor(imageTintColor, renderingMode: .alwaysOriginal)
        }

        return image
    }

    init(fileURL: URL, player: AVAudioPlayer) {
        self.fileURL = fileURL
        self.asset = AVAsset(url: fileURL)
        self.player = player

        self.player.enableRate = true
        self.player.rate = playbackSpeedRate

        super.init(nibName: nil, bundle: nil)
    }

    convenience init(fileURL: URL) throws {
        self.init(fileURL: fileURL, player: try AVAudioPlayer(contentsOf: fileURL))
    }

    convenience init(fileURL: URL, data: Data) throws {
        self.init(fileURL: fileURL, player: try AVAudioPlayer(data: data))
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    override func viewDidLoad() {
        super.viewDidLoad()

        self.view.backgroundColor = .secondarySystemBackground
        setupBarButtons()

        displayLink.add(to: .main, forMode: .default)

        addItemToSystemMediaPlayer()

        player.delegate = self
        let playAction = UIAction(image: playButtonImage()) { _ in
            self.play()
        }

        self.playButton = UIButton(primaryAction: playAction)

        self.playbackSlider = UISlider()

        playbackSlider.minimumValue = 0
        playbackSlider.maximumValue = Float(player.duration)
        playbackSlider.isContinuous = false

        playbackSlider.setThumbImage(UIImage(systemName: "circle.fill"), for: .normal)
        playbackSlider.tintColor = .lightGray
        playbackSlider.addTarget(self, action: #selector(sliderDidChange(_:)), for: .valueChanged)
        playbackSlider.addTarget(self, action: #selector(didBeginDraggingSlider), for: .touchDown)

        let titleLabel = UILabel()
        titleLabel.text = itemName
        titleLabel.font = .preferredFont(forTextStyle: .title2)
        titleLabel.textAlignment = .left

        let artistLabel = UILabel()
        artistLabel.text = artistName ?? "Unknown Artist"
        artistLabel.textAlignment = .left
        artistLabel.textColor = .systemGray

        self.durationLabel = UILabel()
        durationLabel.text = format(timeInterval: player.duration)
        durationLabel.textColor = .systemGray

        self.currentProgressLabel = UILabel()
        currentProgressLabel.text = format(timeInterval: player.duration)
        currentProgressLabel.textColor = .systemGray

        let loopAction = UIAction(image: loopButtonImage()) { action in
            self.doLoop.toggle()
            self.loopButton.setImage(self.loopButtonImage(), for: .normal)
        }
        self.loopButton = UIButton(primaryAction: loopAction)

        self.forwardButton = UIButton(
            primaryAction: UIAction(
                image: UIImage(systemName: "goforward")?.withTintColor(.systemGray, renderingMode: .alwaysOriginal)
            ) { _ in
                self.player.currentTime += Double(self.skipDuration)
            }
        )

        self.backwardButton = UIButton(
            primaryAction: UIAction(
                image: UIImage(systemName: "gobackward")?.withTintColor(.systemGray, renderingMode: .alwaysOriginal)
            ) { _ in
                self.player.currentTime -= Double(self.skipDuration)
            }
        )

        let buttonsStackView = UIStackView(arrangedSubviews: [backwardButton, playButton, forwardButton])
        buttonsStackView.spacing = 40

        let labelsStackView = UIStackView(arrangedSubviews: [titleLabel, artistLabel])
        labelsStackView.axis = .vertical

        durationLabel.translatesAutoresizingMaskIntoConstraints = false
        playbackSlider.translatesAutoresizingMaskIntoConstraints = false
        buttonsStackView.translatesAutoresizingMaskIntoConstraints = false
        labelsStackView.translatesAutoresizingMaskIntoConstraints = false
        loopButton.translatesAutoresizingMaskIntoConstraints = false
        currentProgressLabel.translatesAutoresizingMaskIntoConstraints = false

        view.addSubview(buttonsStackView)
        view.addSubview(labelsStackView)
        view.addSubview(durationLabel)
        view.addSubview(playbackSlider)
        view.addSubview(currentProgressLabel)
        view.addSubview(loopButton)

        NSLayoutConstraint.activate([
            playbackSlider.centerYAnchor.constraint(equalTo: view.centerYAnchor, constant: 120),
            playbackSlider.trailingAnchor.constraint(equalTo: view.layoutMarginsGuide.trailingAnchor),
            playbackSlider.leadingAnchor.constraint(equalTo: view.layoutMarginsGuide.leadingAnchor),

            buttonsStackView.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            buttonsStackView.centerYAnchor.constraint(equalTo: playbackSlider.centerYAnchor, constant: 80),

            labelsStackView.trailingAnchor.constraint(equalTo: playbackSlider.trailingAnchor),
            labelsStackView.leadingAnchor.constraint(equalTo: playbackSlider.leadingAnchor),
            labelsStackView.bottomAnchor.constraint(equalTo: playbackSlider.topAnchor, constant: -10),

            durationLabel.trailingAnchor.constraint(equalTo: titleLabel.trailingAnchor),
            durationLabel.topAnchor.constraint(equalTo: playbackSlider.bottomAnchor),

            currentProgressLabel.leadingAnchor.constraint(equalTo: titleLabel.leadingAnchor),
            currentProgressLabel.topAnchor.constraint(equalTo: playbackSlider.bottomAnchor),

            loopButton.trailingAnchor.constraint(equalTo: artistLabel.trailingAnchor),
            loopButton.topAnchor.constraint(equalTo: artistLabel.topAnchor)
        ])

    }

    func play() {
        if player.isPlaying {
            player.pause()
        } else {
            try? AVAudioSession.sharedInstance().setCategory(.playback)
            try? AVAudioSession.sharedInstance().setActive(true, options: .notifyOthersOnDeactivation)

            player.play()
        }

        setPlayButtonImage()
        playbackCallback?()
    }

    func setPlayButtonImage() {
        playButton.setImage(playButtonImage(), for: .normal)
    }

    @objc
    func sliderDidChange(_ sender: UISlider) {
        player.currentTime = Double(sender.value)
        displayLink.isPaused = false
    }

    @objc
    func sychronizeSliderProgress() {
        if !playbackSlider.isTracking {
            MPNowPlayingInfoCenter.default().nowPlayingInfo?[MPMediaItemPropertyPlaybackDuration] = player.duration
            MPNowPlayingInfoCenter.default().nowPlayingInfo?[MPNowPlayingInfoPropertyElapsedPlaybackTime] = player.currentTime
        }

        let synchronized = player.currentTime
        playbackSlider.setValue(Float(synchronized), animated: true)
        currentProgressLabel.text = format(timeInterval: synchronized)
        if let currentTimeLeft = format(timeInterval: player.duration - player.currentTime) {
            self.durationLabel.text = "-\(currentTimeLeft)"
        }

        displayLink.isPaused = false
    }

    @objc func didBeginDraggingSlider() {
        displayLink.isPaused = true
    }

    func format(timeInterval: TimeInterval) -> String? {
        let formatter = DateComponentsFormatter()

        formatter.zeroFormattingBehavior = []

        formatter.allowedUnits = [.second, .minute]
        if timeInterval >= 3600 {
            formatter.allowedUnits.insert(.hour)
        }

        return formatter.string(from: timeInterval)
    }

    func loopButtonImage() -> UIImage? {
        let image = UIImage(systemName: "repeat")
        if !self.doLoop {
            return image?.withTintColor(.systemGray, renderingMode: .alwaysOriginal)
        }

        return image
    }

    func setupBarButtons() {
        let durationActions = availableSkipDurations.map { duration in
            UIAction(title: duration.description, state: self.skipDuration == duration ? .on : .off) { _ in
                self.skipDuration = duration
                self.setupBarButtons()
            }
        }

        let skipDurationSubMenu = UIMenu(title: "Backward / Forward duration", children: durationActions)

        let adjustSpeedActions = availableSpeedRates.map { rate in
            UIAction(title: rate.description, state: self.playbackSpeedRate == rate ? .on : .off) { _ in
                self.playbackSpeedRate = rate
                self.setupBarButtons()
            }
        }

        let adjustSpeedMenu = UIMenu(title: "Speed", image: UIImage(systemName: "speedometer"), children: adjustSpeedActions)
        let menu = UIMenu(children: [adjustSpeedMenu, skipDurationSubMenu])
        self.navigationItem.rightBarButtonItem = UIBarButtonItem(image: UIImage(systemName: "ellipsis.circle"), menu: menu)
        self.navigationItem.leftBarButtonItem = UIBarButtonItem(title: SantanderL10n.t("Dismiss"), primaryAction: UIAction { _ in
            self.dismiss(animated: true)
        })
    }

    func addItemToSystemMediaPlayer() {
        let center = MPNowPlayingInfoCenter.default()

        UIApplication.shared.beginReceivingRemoteControlEvents()
        MPRemoteCommandCenter.shared().playCommand.addTarget { event in
            self.player.play()
            self.setPlayButtonImage()
            self.playbackCallback?()
            return .success
        }

        MPRemoteCommandCenter.shared().pauseCommand.addTarget { event in
            self.player.pause()
            self.setPlayButtonImage()
            self.playbackCallback?()
            return .success
        }

        MPRemoteCommandCenter.shared().nextTrackCommand.addTarget {event in
            self.player.currentTime += Double(self.skipDuration)
            return .success
        }

        MPRemoteCommandCenter.shared().previousTrackCommand.addTarget {event in
            self.player.currentTime -= Double(self.skipDuration)
            return .success
        }

        var info: [String: Any] = [
            MPMediaItemPropertyTitle: self.itemName,
            MPNowPlayingInfoPropertyMediaType: MPNowPlayingInfoMediaType.audio.rawValue,
            MPNowPlayingInfoPropertyAssetURL: self.fileURL,
            MPNowPlayingInfoPropertyIsLiveStream: false
        ]

        if let album = asset.metadata.first(where: { $0.commonKey?.rawValue == "album" })?.stringValue {
            info[MPMediaItemPropertyAlbumTitle] = album
        }

        if let artist = self.artistName {
            info[MPMediaItemPropertyArtist] = artist
        }

        if let artworkImage = artworkImage {
            let mpArtwork = MPMediaItemArtwork(boundsSize: artworkImage.size) { _ in
                return artworkImage
            }

            info[MPMediaItemPropertyArtwork] = mpArtwork
        }

        center.nowPlayingInfo = info
    }

    override func dismiss(animated flag: Bool, completion: (() -> Void)? = nil) {
        player.stop()
        super.dismiss(animated: flag, completion: completion)
    }

    func removeFromSystemMediaPlayer() {
        MPNowPlayingInfoCenter.default().nowPlayingInfo = nil
    }
}

extension AudioPlayerViewController: AVAudioPlayerDelegate {
    func audioPlayerDidFinishPlaying(_ player: AVAudioPlayer, successfully flag: Bool) {
        if self.doLoop {
            player.play()
        }

        setPlayButtonImage()
        playbackCallback?()
    }
}

class AudioPlayerToolbarView: UIView {
    let audioPlayerController: AudioPlayerViewController
    weak var delegate: AudioPlayerToolbarDelegate?
    var playButton: UIButton!

    init(_ audioPlayerController: AudioPlayerViewController, frame: CGRect) {
        self.audioPlayerController = audioPlayerController

        super.init(frame: frame)

        let titleLabel = UILabel()
        titleLabel.text = audioPlayerController.itemName
        titleLabel.translatesAutoresizingMaskIntoConstraints = false
        addSubview(titleLabel)

        let cancelAction = UIAction(image: UIImage(systemName: "xmark.circle")) { _ in
            self.delegate?.audioToolbarDidClickCancelButton(self)
        }

        self.playButton = UIButton()
        setPlayButtonImage()
        let playOrStopAction = UIAction { _ in
            self.playOrStop()
        }

        playButton.addAction(playOrStopAction, for: .touchUpInside)

        audioPlayerController.playbackCallback = {
            self.setPlayButtonImage()
        }

        let cancelButton = UIButton(primaryAction: cancelAction)
        let buttonsStackView = UIStackView(arrangedSubviews: [playButton, cancelButton])
        buttonsStackView.spacing = 10
        buttonsStackView.translatesAutoresizingMaskIntoConstraints = false

        addSubview(buttonsStackView)

        NSLayoutConstraint.activate([
            titleLabel.leadingAnchor.constraint(equalTo: layoutMarginsGuide.leadingAnchor),
            titleLabel.centerYAnchor.constraint(equalTo: centerYAnchor),

            buttonsStackView.centerYAnchor.constraint(equalTo: centerYAnchor),
            buttonsStackView.trailingAnchor.constraint(equalTo: layoutMarginsGuide.trailingAnchor)
        ])
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    func playOrStop() {
        audioPlayerController.play()
        setPlayButtonImage()
    }

    func setPlayButtonImage() {
        playButton.setImage(audioPlayerController.playButtonImage(withSize: 20, imageTintColor: nil), for: .normal)
    }
}

protocol AudioPlayerToolbarDelegate: AnyObject {
    func audioToolbarDidClickCancelButton(_ toolbar: AudioPlayerToolbarView)
}

struct FileEditor {
    let type: FileEditorType
    let viewController: UIViewController

    static func preferred(forURL _url: Path) -> FileEditor? {
        let url = _url.url
        if url.pathExtension == "car", let carVC = FileEditorType.assetCatalog.viewController(forPath: url, data: nil) {
            return FileEditor(type: .assetCatalog, viewController: carVC)
        }

        guard let data = try? Data(contentsOf: url) else {
            return nil
        }

        let type = url.contentType
        if type == .unixExecutable {
            return FileEditor(type: .executable, viewController: BinaryExecutionViewController(executableURL: url))
        }

        if type?.isOfType(.audio) ?? false, let audio = FileEditorType.audio.viewController(forPath: url, data: data) {
            return FileEditor(type: .audio, viewController: audio)
        }

        if type?.isOfType(.font) ?? false, let fontVC = FileEditorType.font.viewController(forPath: url, data: data) {
            return FileEditor(type: .font, viewController: fontVC)
        }

        if let imageVC = FileEditorType.image.viewController(forPath: url, data: data) {
            return FileEditor(type: .image, viewController: imageVC)
        }

        if (type?.isOfType(.video) ?? false || type?.isOfType(.movie) ?? false),
            let videoPlayer = FileEditorType.video.viewController(forPath: url, data: data) {
            return FileEditor(type: .video, viewController: videoPlayer)
        }

        if let plistVc = FileEditorType.propertyList.viewController(forPath: url, data: data) {
            return FileEditor(type: .propertyList, viewController: plistVc)
        }

        if url.pathExtension == "json", let jsonVC = FileEditorType.json.viewController(forPath: url, data: data) {
            return FileEditor(type: .json, viewController: jsonVC)
        }

        if let textEditorVc = FileEditorType.text.viewController(forPath: url, data: data) {
            return FileEditor(type: .text, viewController: textEditorVc)
        }

        return nil
    }

    static func allEditors(forPath path: Path) -> [FileEditor] {
        let url = path.url
        let data = try? Data(contentsOf: url)

        return FileEditorType.allCases.compactMap { type in
            guard let vc = type.viewController(forPath: url, data: data) else {
                return nil
            }
            return FileEditor(type: type, viewController: vc)
        }
    }

    func display(senderVC: UIViewController) {
        let vcToPresent: UIViewController
        if type.useNavigationController {
            vcToPresent = UINavigationController(rootViewController: viewController)
        } else {
            vcToPresent = viewController
        }

        if type.presentAsFullScreen {
            vcToPresent.modalPresentationStyle = .fullScreen
        }

        senderVC.present(vcToPresent, animated: true)
    }
}

enum FileEditorType: CustomStringConvertible, CaseIterable {
    case audio, image, video
    case propertyList, json, text, font
    case assetCatalog
    case executable

    func viewController(forPath path: URL, data: Data?) -> UIViewController? {
        if self == .assetCatalog {
            guard path.pathExtension == "car",
                  let vc = try? AssetCatalogViewController(catalogFileURL: path) else {
                return nil
            }

            if UIDevice.isiPad {
                return __makeSplitViewController(with: AssetCatalogSidebarListView(catalogController: vc), for: .primary)
            }

            return vc
        }

        guard let data = data else { return nil }

        switch self {
        case .audio:
            return try? AudioPlayerViewController(fileURL: path, data: data)
        case .propertyList:
            let fmt: UnsafeMutablePointer<PropertyListSerialization.PropertyListFormat> = .allocate(capacity: 4)
            let plist = try? PropertyListSerialization.propertyList(from: data, format: fmt)

            if let dict = plist as? [String: Any] {
                return SerializedDocumentViewController(dictionary: dict.asSerializedDictionary(), type: .plist(format: fmt.pointee), title: path.lastPathComponent, fileURL: path, parentController: nil, canEdit: true)
            } else if let arr = plist as? Array<Any> {
                return SerializedArrayViewController(array: arr, type: .plist(format: fmt.pointee), parentController: nil, title: path.lastPathComponent, fileURL: path, canEdit: true)
            }

            return nil
        case .json:

            let json = try? JSONSerialization.jsonObject(with: data)

            if let dict = json as? [String: Any] {
                return SerializedDocumentViewController(dictionary: dict.asSerializedDictionary(), type: .json, title: path.lastPathComponent, fileURL: path, parentController: nil, canEdit: true)
            } else if let arr = json as? Array<Any> {
                return SerializedArrayViewController(array: arr, type: .json, parentController: nil, title: path.lastPathComponent, fileURL: path, canEdit: true)
            }

            return nil
        case .text:
            guard let stringContents = String(data: data, encoding: .utf8) else {
                return nil
            }

            let textVC = TextFileEditorViewController(fileURL: path, contents: stringContents)
            if UIDevice.isiPad {
                return __makeSplitViewController(with: textVC, for: .secondary)
            }

            return textVC
        case .image:
            guard let image = UIImage(data: data) else {
                return nil
            }

            return ImageViewerController(fileURL: path, image: image)
        case .video:
            let type = path.contentType
            guard (type?.isOfType(.movie) ?? false || type?.isOfType(.video) ?? false) else {
                return nil
            }

            let controller = AVPlayerViewController()
            controller.player = AVPlayer(url: path)
            return controller
        case .font:
            guard let descriptors = CTFontManagerCreateFontDescriptorsFromURL(path as CFURL) as? [CTFontDescriptor], !descriptors.isEmpty else {
                return nil
            }

            return FontViewerController(selectedFont: descriptors.first!.uiFont, descriptors: descriptors)
        case .executable:
            return BinaryExecutionViewController(executableURL: path)
        case .assetCatalog: return nil
        }
    }

    private func __makeSplitViewController(with vc: UIViewController, for column: UISplitViewController.Column) -> UISplitViewController {
        let splitVC = UISplitViewController(style: .doubleColumn)
        splitVC.setViewController(vc, for: column)
        return splitVC
    }

    var description: String {
        switch self {
        case .audio:
            return "Audio Player"
        case .video:
            return "Video Player"
        case .image:
            return "Image Viewer"
        case .propertyList:
            return "Property List Viewer"
        case .json:
            return "JSON Viewer"
        case .font:
            return "Font Viewer"
        case .text:
            return "Text Editor"
        case .assetCatalog:
            return "Asset Catalog Viewer"
        case .executable:
            return "Executable Runner"
        }
    }

    var presentAsFullScreen: Bool {
        switch self {
        case .text, .image, .video, .executable:
            return true
        case .audio, .font:
            return false
        case .propertyList, .json, .assetCatalog:
            return UIDevice.isiPad
        }
    }

    var useNavigationController: Bool {
        switch self {
        case .video:
            return false
        case .text, .assetCatalog:
            return !UIDevice.isiPad
        default:
            return true
        }
    }
}

class BinaryExecutionViewController: UIViewController {
    let executableURL: URL
    var task: NSTask = NSTask()
    var textView: UITextView!

    init(executableURL: URL) {
        self.executableURL = executableURL

        super.init(nibName: nil, bundle: nil)
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    override func viewDidLoad() {
        super.viewDidLoad()

        view.backgroundColor = .secondarySystemBackground

        title = SantanderL10n.t("Execution")
        let doneAction = UIAction {
            if self.task.isRunning {
                self.task.interrupt()
            }
            self.dismiss(animated: true)
        }

        navigationItem.rightBarButtonItem = UIBarButtonItem(systemItem: .done, primaryAction: doneAction)
        configureNavigationBarToNormal()

        let executableTextField = UITextField()

        let action = UIAction {
            if self.task.isRunning {
                self.task.interrupt()
            }
            self.spawnExecutable(pathAndArgs: executableTextField.text!)
        }

        executableTextField.autocorrectionType = .no
        executableTextField.returnKeyType = .go
        executableTextField.addAction(action, for: .primaryActionTriggered)
        executableTextField.text = executableURL.path
        executableTextField.font = UIFont(name: "Menlo", size: UIFont.systemFontSize)
        executableTextField.translatesAutoresizingMaskIntoConstraints = false
        executableTextField.backgroundColor = .systemBackground
        executableTextField.inputAccessoryView = makeKeyboardToolbar(forTextField: executableTextField)
        view.addSubview(executableTextField)

        let guide = view.safeAreaLayoutGuide
        NSLayoutConstraint.activate([
            executableTextField.trailingAnchor.constraint(equalTo: guide.trailingAnchor),
            executableTextField.leadingAnchor.constraint(equalTo: guide.leadingAnchor),
            executableTextField.topAnchor.constraint(equalTo: guide.topAnchor),
            executableTextField.heightAnchor.constraint(equalToConstant: 50),
        ])

        self.textView = UITextView()
        textView.text = ""
        textView.font = .systemFont(ofSize: 20)
        textView.isEditable = false
        textView.translatesAutoresizingMaskIntoConstraints = false
        textView.backgroundColor = view.backgroundColor
        view.addSubview(textView)

        NSLayoutConstraint.activate([
            textView.leadingAnchor.constraint(equalTo: guide.leadingAnchor),
            textView.trailingAnchor.constraint(equalTo: guide.trailingAnchor),
            textView.topAnchor.constraint(equalTo: executableTextField.bottomAnchor),
            textView.heightAnchor.constraint(equalTo: view.heightAnchor)
        ])
    }

    func makeKeyboardToolbar(forTextField textField: UITextField) -> UIToolbar {
        let toolbar = UIToolbar()

        let dismissKeyboardAction = UIAction {
            textField.resignFirstResponder()
        }

        let dismissButton = UIBarButtonItem(title: SantanderL10n.t("Dismiss"), primaryAction: dismissKeyboardAction)
        toolbar.setItems([.flexibleSpace(), dismissButton], animated: true)
        toolbar.sizeToFit()
        return toolbar
    }

    func spawnExecutable(pathAndArgs: String) {
        var components = pathAndArgs.components(separatedBy: " ")
        guard let executable = components.first, !executable.isEmpty else {
            self.errorAlert("Enter a valid executable and arguments.", title: "Input is empty")
            return
        }

        components.removeFirst()
        self.task = NSTask()
        task.executableURL = URL(fileURLWithPath: executable)
        task.arguments = components

        let pipe = Pipe()
        pipe.fileHandleForReading.readabilityHandler = { outPipe in
            guard let output = String(data: outPipe.availableData, encoding: .utf8),
            !output.isEmpty else {
                return
            }

            DispatchQueue.main.async {
                self.textView.text.append(output)
            }
        }

        task.standardError = pipe
        task.standardOutput = pipe
        do {
            textView.text = ""
            try task.launchAndReturnError()
            task.waitUntilExit()
        } catch {
            self.errorAlert(error, title: "Unable to launch process")
        }
    }
}

class FontViewerController: UIViewController {
    var selectedFont: UIFont
    var descriptors: [CTFontDescriptor]

    var textView: UITextView!
    var amountLabel: UILabel!

    init(selectedFont: UIFont, descriptors: [CTFontDescriptor]) {
        self.selectedFont = selectedFont
        self.descriptors = descriptors
        super.init(nibName: nil, bundle: nil)

        self.title = selectedFont.familyName
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        navigationController?.navigationBar.prefersLargeTitles = false

        view.backgroundColor = .systemBackground

        setupRightBarButton()

        self.textView = UITextView()
        textView.text = "The quick brown fox jumps over the lazy dog and runs away."
        textView.font = self.selectedFont
        textView.inputAccessoryView = makeKeyboardToolbar(textView: textView)
        textView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(textView)

        textView.constraintCompletely(to: view)

        configureNavigationBarToNormal()
        setupBottomView()
    }

    func setupRightBarButton() {
        let presentInfoAction = UIAction {
            if self.descriptors.count > 1 {
                let alert = UIAlertController(title: nil, message: nil, preferredStyle: .actionSheet)
                let actions = self.descriptors.map { descriptor in
                    let uiFont = descriptor.uiFont
                    return UIAlertAction(title: uiFont.fontName, style: .default) { _ in
                        let vc = FontInformationViewController(font: uiFont)
                        self.present(UINavigationController(rootViewController: vc), animated: true)
                    }
                }

                for action in actions {
                    alert.addAction(action)
                }

                alert.addAction(.cancel())
                self.present(alert, animated: true)
            } else {
                let vc = FontInformationViewController(font: self.selectedFont)
                self.present(UINavigationController(rootViewController: vc), animated: true)
            }
        }

        let infoButton = UIBarButtonItem(image: UIImage(systemName: "info.circle"), primaryAction: presentInfoAction)

        if descriptors.count > 1 {
            let selectFontActions = descriptors.map { descr in
                let uiFont = descr.uiFont
                return UIAction(title: uiFont.fontName, state: uiFont == self.selectedFont ? .on : .off) { _ in
                    self.selectedFont = uiFont.withSize(self.selectedFont.pointSize)
                    self.updateFontSize(newSize: self.selectedFont.pointSize)
                    self.setupRightBarButton()
                }
            }

            let selectFontMenu = UIMenu(children: selectFontActions)
            navigationItem.rightBarButtonItems = [
                UIBarButtonItem(title: SantanderL10n.t("Select font.."), menu: selectFontMenu),
                infoButton
            ]
        } else {
            navigationItem.rightBarButtonItem = infoButton
        }
    }

    func updateFontSize(newSize: CGFloat) {
        UserPreferences.fontViewerFontSize = newSize
        self.selectedFont = selectedFont.withSize(newSize)
        self.textView.font = selectedFont
        amountLabel.text = Int(newSize).description
    }

    func setupBottomView() {
        let newView = UIView()
        newView.backgroundColor = .secondarySystemBackground

        self.amountLabel = UILabel()
        amountLabel.text = Int(selectedFont.pointSize).description

        let slider = UISlider()
        slider.maximumValue = 90
        slider.value = Float(selectedFont.pointSize)

        let sliderChangedAction = UIAction {
            self.updateFontSize(newSize: CGFloat(slider.value))
        }

        slider.addAction(sliderChangedAction, for: .valueChanged)

        let stackView = UIStackView(arrangedSubviews: [slider, amountLabel])
        stackView.translatesAutoresizingMaskIntoConstraints = false
        stackView.spacing = 10

        newView.addSubview(stackView)
        newView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(newView)
        NSLayoutConstraint.activate([
            newView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            newView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            newView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -50),
            newView.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor),

            stackView.centerYAnchor.constraint(equalTo: newView.centerYAnchor),
            stackView.leadingAnchor.constraint(equalTo: newView.layoutMarginsGuide.leadingAnchor),
            stackView.trailingAnchor.constraint(equalTo: newView.layoutMarginsGuide.trailingAnchor),
        ])

    }

    func makeKeyboardToolbar(textView: UITextView) -> UIToolbar {
        let toolbar = UIToolbar()
        let action = UIAction {
            textView.resignFirstResponder()
        }

        let doneButton = UIBarButtonItem(systemItem: .done, primaryAction: action)

        toolbar.setItems([.flexibleSpace(), doneButton], animated: true)
        toolbar.sizeToFit()
        return toolbar
    }
}

class FontInformationViewController: UITableViewController {
    let font: UIFont
    let ctFont: CTFont
    let fontName: String

    init(font: UIFont) {
        self.font = font
        self.ctFont = font as CTFont
        self.fontName = CTFontCopyAttribute(ctFont, kCTFontDisplayNameAttribute) as? String ?? font.fontName

        super.init(style: .userPreferred)
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    override func viewDidLoad() {
        super.viewDidLoad()

        let fontLabel = UILabel()
        fontLabel.text = fontName
        fontLabel.font = font.withSize(30)

        navigationItem.titleView = fontLabel
    }

    override func numberOfSections(in tableView: UITableView) -> Int {
        return 2
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        switch section {
        case 0:
            return 6
        case 1:
            return 3
        default:
            fatalError()
        }
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = UITableViewCell(style: .value1, reuseIdentifier: nil)
        var conf = cell.defaultContentConfiguration()
        defer {
            cell.contentConfiguration = conf
        }

        switch (indexPath.section, indexPath.row) {
        case (0, 0):
            conf.text = "Full name"
            conf.secondaryText = fontName
        case (0, 1):
            conf.text = "Family name"
            conf.secondaryText = font.familyName
        case (0, 2):
            conf.text = "PostScript name"
            conf.secondaryText = font.fontDescriptor.postscriptName
        case (0, 3):
            conf.text = "Style"
            conf.secondaryText = CTFontCopyAttribute(ctFont, kCTFontStyleNameAttribute) as? String ?? "N/A"
        case (0, 4):
            conf.text = "Enabled"
            if let isEnabled = CTFontCopyAttribute(ctFont, kCTFontEnabledAttribute) as? Bool {
                conf.secondaryText = isEnabled ? "Yes" : "No"
            } else {
                conf.secondaryText = "N/A"
            }
        case (0, 5):
            conf.text = "URL"
            let url = CTFontCopyAttribute(ctFont, kCTFontURLAttribute) as? URL
            conf.secondaryText = url?.path ?? "N/A"
        case (1, 0):
            conf.text = "Designer"
            conf.secondaryText = CTFontCopyName(ctFont, kCTFontDesignerNameKey) as? String ?? "N/A"
        case (1, 1):
            conf.text = "Manufacturer"
            conf.secondaryText = CTFontCopyName(ctFont, kCTFontManufacturerNameKey) as? String ?? "N/A"
        case (1, 2):
            conf.text = "Version"
            conf.secondaryText = CTFontCopyName(ctFont, kCTFontVersionNameKey) as? String ?? "N/A"
        default:
            fatalError("Unhandled indexPath: \(indexPath)")
        }

        return cell
    }

    override func tableView(_ tableView: UITableView, shouldHighlightRowAt indexPath: IndexPath) -> Bool {
        return false
    }
}

class ImageMetadataViewController: UITableViewController {
    var metadata: ImageMetadata
    let fileURL: URL

    init(metadata: ImageMetadata, fileURL: URL) {
        self.metadata = metadata
        self.fileURL = fileURL

        super.init(style: .userPreferred)
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    override func numberOfSections(in tableView: UITableView) -> Int {
        return 4
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        switch section {
        case 0, 1: return 3
        case 2, 3: return 2
        default: fatalError()
        }
    }

    override func viewDidLoad() {
        super.viewDidLoad()

        self.title = SantanderL10n.t("Metadata")
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = UITableViewCell(style: .value1, reuseIdentifier: nil)
        var conf = cell.defaultContentConfiguration()

        defer {
            cell.contentConfiguration = conf
        }

        switch (indexPath.section, indexPath.row) {
        case (0, 0):
            conf.text = "Pixel Height"
            conf.secondaryText = metadata.pixelHeight?.description ?? "N/A"
        case (0, 1):
            conf.text = "Pixel Width"
            conf.secondaryText = metadata.pixelWidth?.description ?? "N/A"
        case (0, 2):
            let datePicker = UIDatePicker()
            if let dateTaken = metadata.dateTimeTaken {
                datePicker.setDate(dateTaken, animated: true)
            }

            let action = UIAction {
                self.setNewDate(withDatePicker: datePicker)
            }

            datePicker.addAction(action, for: .editingDidEnd)
            return cellWithView(datePicker, text: "Date", rightAnchorConstant: -5)
        case (1, 0):
            conf.text = "Camera Model"
            conf.secondaryText = metadata.cameraInfo?.model ?? "N/A"
        case (1, 1):
            conf.text = "Camera Manufacturer"
            conf.secondaryText = metadata.cameraInfo?.manufacturer ?? "N/A"
        case (1, 2):
            conf.text = "Camera Software"
            conf.secondaryText = metadata.cameraInfo?.softwareVersion ?? "N/A"
        case (2, 0):
            conf.text = "Lens Model"
            conf.secondaryText = metadata.exifInfo?.lensModel ?? "N/A"
        case (2, 1):
            conf.text = "Lens Manufacturer"
            conf.secondaryText = metadata.exifInfo?.lensManufacturer ?? "N/A"
        case (3, 0):
            conf.text = "Latitude"
            conf.secondaryText = metadata.location.lat?.description ?? "N/A"
        case (3, 1):
            conf.text = "Longitude"
            conf.secondaryText = metadata.location.long?.description ?? "N/A"
        default:
            break
        }

        return cell
    }

    override func tableView(_ tableView: UITableView, shouldHighlightRowAt indexPath: IndexPath) -> Bool {
        return false
    }

    func headerTitle(forSection section: Int) -> String {
        switch section {
        case 0:
            return "General"
        case 1:
            return "Camera"
        case 2:
            return "Lens"
        case 3:
            return "Location"
        default:
            fatalError()
        }
    }

    func setNewDate(withDatePicker datePicker: UIDatePicker) {
        let exifFormattedDate = DateFormatter.EXIFDateFormatter.string(from: datePicker.date)
        let iptcFormattedDate = DateFormatter.IPTCDateFormatter.string(from: datePicker.date)
        var copy = metadata.dictionary

        var tiffDictionary = (copy[kCGImagePropertyTIFFDictionary as String] as? [String: Any]) ?? [:]
        tiffDictionary[kCGImagePropertyTIFFDateTime as String] = exifFormattedDate

        var exifDictionary = (copy[kCGImagePropertyExifDictionary as String] as? [String: Any]) ?? [:]
        exifDictionary[kCGImagePropertyExifDateTimeOriginal as String] = exifFormattedDate
        exifDictionary[kCGImagePropertyExifDateTimeDigitized as String] = exifFormattedDate

        var iptcDictionary = (copy[kCGImagePropertyIPTCDictionary as String] as? [String: Any]) ?? [:]
        iptcDictionary[kCGImagePropertyIPTCDateCreated as String] = iptcFormattedDate

        copy[kCGImagePropertyTIFFDictionary as String] = tiffDictionary
        copy[kCGImagePropertyExifDictionary as String] = exifDictionary
        copy[kCGImagePropertyIPTCDictionary as String] = iptcDictionary

        if !metadata.setProperties(toDictionary: copy, forFileURL: fileURL) {
            errorAlert("", title: "Unable to set date of image")
        }
    }

    override func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        return sectionHeaderWithButton(sectionTag: section, titleText: headerTitle(forSection: section)) { button in
            guard section == 3 else {
                button.isHidden = true
                return
            }

            let action = UIAction { _ in
                self.presentMapEditor()
            }

            button.setTitle("View", for: .normal)
            button.setTitleColor(.systemBlue, for: .normal)
            button.addAction(action, for: .touchUpInside)
        }
    }

    override func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 40
    }

    func presentMapEditor() {
        let vc = ImageLocationEditorViewController(metadata: metadata, metadataSenderVC: self, fileURL: fileURL)
        let navVC = UINavigationController(rootViewController: vc)
        navVC.modalPresentationStyle = .fullScreen
        self.present(navVC, animated: true)
    }
}

class ImageLocationEditorViewController: UIViewController, MKMapViewDelegate {
    let fileURL: URL
    let metadata: ImageMetadata
    let metadataSenderVC: ImageMetadataViewController

    var mapView: MKMapView!
    var annotation: MKPointAnnotation!

    init(metadata: ImageMetadata, metadataSenderVC: ImageMetadataViewController, fileURL: URL) {
        self.metadata = metadata
        self.fileURL = fileURL
        self.metadataSenderVC = metadataSenderVC

        super.init(nibName: nil, bundle: nil)
    }

    required init?(coder: NSCoder) {
        fatalError()
    }

    override func viewDidLoad() {
        super.viewDidLoad()

        title = SantanderL10n.t("Location")

        let dismissAction = UIAction {
            self.dismiss(animated: true)
        }

        navigationItem.leftBarButtonItem = UIBarButtonItem(title: SantanderL10n.t("Dismiss"), primaryAction: dismissAction)

        mapView = MKMapView()
        mapView.translatesAutoresizingMaskIntoConstraints = false
        mapView.delegate = self

        annotation = MKPointAnnotation()

        mapView.addAnnotation(annotation)

        view.addSubview(mapView)

        mapView.constraintCompletely(to: view)

        if let center = metadata.location.coordinate {
            annotation.coordinate = center
            mapView.setRegion(MKCoordinateRegion(center: center, span: .init()), animated: true)
        }

        configureNavigationBarToNormal()
        setRightBarButton()
        setupToolbar()
    }

    func setRightBarButton() {
        let action = UIAction {
            self.setEditing(!self.isEditing, animated: true)
        }

        navigationItem.rightBarButtonItem = UIBarButtonItem(
            systemItem: isEditing ? .done : .edit,
            primaryAction: action
        )
    }

    override func setEditing(_ editing: Bool, animated: Bool) {
        super.setEditing(editing, animated: animated)

        setRightBarButton()

        if !editing {
            setImageLocation(nullify: false)
        } else {
            mapView.addAnnotation(annotation)
        }
    }

    func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
        guard let anno = self.annotation else {
            return nil
        }

        let view = MKPinAnnotationView(annotation: anno, reuseIdentifier: "DraggablePin")
        view.isDraggable = true
        return view
    }

    func moveAnnotation(_ mapView: MKMapView) {
        if isEditing {
            annotation.coordinate = mapView.centerCoordinate
        }
    }

    func setImageLocation(nullify: Bool) {
        let coordinate = annotation.coordinate
        var newGPSDict = (metadata.dictionary[kCGImagePropertyGPSDictionary as String] as? [String: Any?]) ?? [:]
        if nullify {
            newGPSDict[kCGImagePropertyGPSLatitude as String] = nil
            newGPSDict[kCGImagePropertyGPSLongitude as String] = nil
            metadata.location = ImageLocation(lat: nil, long: nil)
        } else {
            newGPSDict[kCGImagePropertyGPSLatitude as String] = coordinate.latitude
            newGPSDict[kCGImagePropertyGPSLongitude as String] = coordinate.longitude
            metadata.location = ImageLocation(lat: coordinate.latitude, long: coordinate.longitude)
        }

        var copy = metadata.dictionary
        copy[kCGImagePropertyGPSDictionary as String] = newGPSDict

        let didSucceed = metadata.setProperties(toDictionary: copy, forFileURL: fileURL)
        if !didSucceed {
            errorAlert("", title: "Unable to set location of image")
        } else {
            metadataSenderVC.metadata = .init(dictionary: copy)
            metadataSenderVC.tableView.reloadData()
            if nullify {
                mapView.removeAnnotation(annotation)
            }
        }
        self.setupToolbar()
    }

    func mapView(_ mapView: MKMapView, regionDidChangeAnimated animated: Bool) {
        moveAnnotation(mapView)
    }

    func setupToolbar() {
        let action = UIAction {
            let alert = UIAlertController(title: "Remove image location?", message: nil, preferredStyle: .actionSheet)
            let removeAction = UIAlertAction(title: SantanderL10n.t("Remove"), style: .destructive) { _ in
                self.setImageLocation(nullify: true)
            }

            alert.addAction(removeAction)
            alert.addAction(.cancel())
            self.present(alert, animated: true)
        }

        let trashButton = UIBarButtonItem(image: UIImage(systemName: "trash"), primaryAction: action)
        trashButton.isEnabled = metadata.location.coordinate != nil
        trashButton.tintColor = .systemRed

        navigationController?.setToolbarHidden(false, animated: true)
        self.toolbarItems = [trashButton]
    }
}

class ImageViewerController: UIViewController {
    let fileURL: URL?
    let image: UIImage
    var metadata: ImageMetadata?

    typealias SetWallpaperFunction = @convention(c) (_: NSDictionary, _: NSDictionary, _: Int, _: Int) -> Int

    init(fileURL: URL?, image: UIImage, title: String? = nil) {
        self.fileURL = fileURL
        self.image = image

        super.init(nibName: nil, bundle: nil)
        self.title = fileURL?.lastPathComponent ?? title
    }

    convenience init?(fileURL: URL) {
        guard let image = UIImage(contentsOfFile: fileURL.path) else {
            return nil
        }

        self.init(fileURL: fileURL, image: image)
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        if let fileURL = fileURL {
            self.metadata = ImageMetadata(fileURL: fileURL)
        }

        view.backgroundColor = .systemBackground

        let doneAction = UIAction { _ in
            self.dismiss(animated: true)
        }

        let doneButton = UIBarButtonItem(systemItem: .done, primaryAction: doneAction)
        let infoButton = UIBarButtonItem()

        if let metadata = self.metadata, let fileURL = fileURL {
            let infoAction = UIAction { _ in
                let vc = ImageMetadataViewController(metadata: metadata, fileURL: fileURL)
                self.present(UINavigationController(rootViewController: vc), animated: true)
            }

            infoButton.primaryAction = infoAction
        } else {
            infoButton.isEnabled = false
        }

        infoButton.image = UIImage(systemName: "info.circle")

        navigationItem.rightBarButtonItem = doneButton
        navigationItem.leftBarButtonItem = infoButton

        if let pdfPage = PDFPage(image: image) {
            let pdfView = PDFView(frame: self.view.bounds)
            pdfView.displayDirection = .vertical
            pdfView.displayMode = .singlePage
            pdfView.backgroundColor = .systemBackground

            let pdfDoc = PDFDocument()
            pdfDoc.insert(pdfPage, at: 0)

            pdfView.document = pdfDoc
            pdfView.autoScales = true
            pdfView.minScaleFactor = pdfView.scaleFactorForSizeToFit

            self.view = pdfView
        } else {
            setupFailedLabel()
        }

        configureNavigationBarToNormal()
        setupToolbar()
    }

    func setupFailedLabel() {
        let failedLabel = UILabel()
        failedLabel.text = "Failed to display image."
        failedLabel.textColor = .systemGray
        failedLabel.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(failedLabel)

        NSLayoutConstraint.activate([
            failedLabel.centerXAnchor.constraint(equalTo: self.view.centerXAnchor),
            failedLabel.centerYAnchor.constraint(equalTo: self.view.centerYAnchor)
        ])
    }

    func setupToolbar() {
        let shareMenuAction = UIAction {
            if let fileURL = self.fileURL {
                self.presentActivityVC(forItems: [fileURL])
            } else {
                self.presentActivityVC(forItems: [self.image])
            }
        }

        let shareMenuButton = UIBarButtonItem(image: UIImage(systemName: "square.and.arrow.up"), primaryAction: shareMenuAction)
        let saveImageAction = UIAction(title: "Save Image") { _ in
            self.saveImage(self.image)
        }

        let setWallpaperActions = WallpaperDestination.allCases.map { location in
            return UIAction(title: location.description) { _ in
                self.setImageAsWallpaper(to: location)
            }
        }

        let setAsWallpaperMenu = UIMenu(title: "Set as wallpaper for..", children: setWallpaperActions)

        let actionsMenu = UIMenu(children: [saveImageAction, setAsWallpaperMenu])
        self.toolbarItems = [shareMenuButton, .flexibleSpace(), UIBarButtonItem(image: UIImage(systemName: "ellipsis.circle"), menu: actionsMenu)]
        self.navigationController?.setToolbarHidden(false, animated: true)
    }

    func setImageAsWallpaper(to location: WallpaperDestination) {
        let sbF = dlopen("/System/Library/PrivateFrameworks/SpringBoardFoundation.framework/SpringBoardFoundation", RTLD_LAZY)
        let sbServer = dlopen("/System/Library/PrivateFrameworks/SpringBoardUIServices.framework/SpringBoardUIServices", RTLD_LAZY)

        defer {
            dlclose(sbF)
            dlclose(sbServer)
        }

        guard let options = NSClassFromString("SBFWallpaperOptions")?.alloc(),
              let pointer = dlsym(sbServer, "SBSUIWallpaperSetImages"),
              let setWallpaper = unsafeBitCast(pointer, to: (SetWallpaperFunction)?.self)
        else {
            errorAlert(nil, title: "Unable to set image as wallpaper")
            return
        }

        let imagesDict = [
            "light": image,
            "dark": image
        ]

        let optionsDict = [
            "light" : options,
            "dark": options
        ]

        let result = setWallpaper(NSDictionary(dictionary: imagesDict), NSDictionary(dictionary: optionsDict), location.rawValue, traitCollection.userInterfaceStyle.rawValue)
        if result != 1 {
            errorAlert("SBSUIWallpaperSetImages returned status code \(result) (should be 1)", title: "Unable to set image as wallpaper")
        }
    }

    enum WallpaperDestination: Int, CustomStringConvertible, CaseIterable {
        static let allCases: [WallpaperDestination] = [.homeScreen, .lockScreen, .both]

        case lockScreen = 1
        case homeScreen = 2
        case both = 3

        var description: String {
            switch self {
            case .lockScreen:
                return "Lock Screen"
            case .homeScreen:
                return "Home Screen"
            case .both:
                return "Home Screen & Lock Screen"
            }
        }
    }
}

private final class SerializedArrayItemDelegate: NSObject, SerializedItemViewControllerDelegate {
    weak var controller: SerializedArrayViewController?
    let index: Int

    init(controller: SerializedArrayViewController, index: Int) {
        self.controller = controller
        self.index = index
    }

    func didChangeName(ofItem item: String, to newName: String) -> Bool {
        false
    }

    func didChangeValue(ofItem item: String, to newValue: SerializedItemType) -> Bool {
        guard let controller else { return false }
        var values = controller.array
        values[index] = newValue.representedObject
        return controller.writeToFile(newArray: values)
    }
}

class SerializedArrayViewController: UITableViewController {
    var array: Array<Any>
    let type: SerializedDocumentViewerType
    let fileURL: URL?
    let canEdit: Bool
    var parentController: SerializedControllerParent?

    init(
        array: Array<Any>,
        type: SerializedDocumentViewerType,
        parentController: SerializedControllerParent?,
        title: String?,
        fileURL: URL?,
        canEdit: Bool
    ) {
        self.array = array
        self.type = type
        self.fileURL = fileURL
        self.canEdit = canEdit
        self.parentController = parentController

        super.init(style: .userPreferred)
        self.title = title
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        applySantanderGlass()
        guard canEdit else { return }
        navigationItem.rightBarButtonItem = UIBarButtonItem(
            systemItem: .add,
            primaryAction: UIAction { [weak self] _ in
                self?.presentAddArrayItem()
            }
        )
    }

    func presentAddArrayItem() {
        let alert = UIAlertController(title: "Add Value", message: nil, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: SantanderL10n.t("String"), style: .default) { [weak self] _ in self?.appendValue("") })
        alert.addAction(UIAlertAction(title: SantanderL10n.t("Boolean"), style: .default) { [weak self] _ in self?.appendValue(false) })
        alert.addAction(UIAlertAction(title: SantanderL10n.t("Integer"), style: .default) { [weak self] _ in self?.appendValue(0) })
        alert.addAction(UIAlertAction(title: SantanderL10n.t("Real"), style: .default) { [weak self] _ in self?.appendValue(0.0) })
        alert.addAction(UIAlertAction(title: SantanderL10n.t("Date"), style: .default) { [weak self] _ in self?.appendValue(Date()) })
        alert.addAction(UIAlertAction(title: SantanderL10n.t("Array"), style: .default) { [weak self] _ in self?.appendValue([Any]()) })
        alert.addAction(UIAlertAction(title: SantanderL10n.t("Dictionary"), style: .default) { [weak self] _ in self?.appendValue([String: Any]()) })
        alert.addAction(.cancel())
        present(alert, animated: true)
    }

    func appendValue(_ value: Any) {
        var newArray = array
        newArray.append(value)
        let index = newArray.count - 1
        guard writeToFile(newArray: newArray) else { return }
        tableView.insertRows(at: [IndexPath(row: index, section: 0)], with: .automatic)
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return array.count
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = UITableViewCell()
        var conf = cell.defaultContentConfiguration()
        let item = array[indexPath.row]

        if item as? Array<Any> != nil {
            conf.text = "Array (Index \(indexPath.row))"
            cell.accessoryType = .disclosureIndicator
        } else if item as? [String: Any] != nil {
            conf.text = "Dictionary (Index \(indexPath.row))"
            cell.accessoryType = .disclosureIndicator
        } else {
            let serialized = SerializedItemType(item: item)
            conf.text = serialized.description
            conf.secondaryText = serialized.typeDescription
        }

        cell.contentConfiguration = conf
        return cell
    }

    override func tableView(_ tableView: UITableView, shouldHighlightRowAt indexPath: IndexPath) -> Bool {
        return true
    }

    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if let arr = array[indexPath.row] as? Array<Any> {
            let title = "Array (Index \(indexPath.row))"
            let vc = SerializedArrayViewController(
                array: arr,
                type: type,
                parentController: .array(self, index: indexPath.row),
                title: title,
                fileURL: fileURL,
                canEdit: canEdit
            )

            navigationController?.pushViewController(vc, animated: true)
        } else if let dict = array[indexPath.row] as? [String: Any] {
            let serializedDict = dict.asSerializedDictionary()

            let title = "Dictionary (Index \(indexPath.row))"
            let vc = SerializedDocumentViewController(dictionary: serializedDict, type: type, title: title, fileURL: fileURL, parentController: .array(self, index: indexPath.row), canEdit: true)
            navigationController?.pushViewController(vc, animated: true)
        } else {
            let item = SerializedItemType(item: array[indexPath.row])
            let vc = SerializedItemViewController(item: item, itemKey: "Index \(indexPath.row)")
            let delegate = SerializedArrayItemDelegate(controller: self, index: indexPath.row)
            vc.delegate = delegate
            vc.retainedDelegate = delegate
            navigationController?.pushViewController(vc, animated: true)
        }
    }

    override func tableView(_ tableView: UITableView, trailingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration? {
        guard canEdit else {
            return nil
        }

        let removeAction = UIContextualAction(style: .destructive, title: nil) { _, _, completion in
            var newArr = self.array
            newArr.remove(at: indexPath.row)

            if self.writeToFile(newArray: newArr) {
                tableView.deleteRows(at: [indexPath], with: .fade)
                completion(true)
            } else {
                completion(false)
            }
        }

        removeAction.image = .remove
        return UISwipeActionsConfiguration(actions: [removeAction])
    }

    func writeToFile(newArray: Array<Any>) -> Bool {

        if let parentController = parentController {
            let didSucceed: Bool

            switch parentController {
            case .dictionary(let parent, let key):
                var parentDict = parent.serializedDict
                parentDict[key] = .array(newArray)
                didSucceed = parent.writeToFile(newDict: parentDict)
            case .array(let parent, let index):
                guard parent.array.indices.contains(index) else {
                    return false
                }
                var parentArr = parent.array
                parentArr[index] = newArray
                didSucceed = parent.writeToFile(newArray: parentArr)
            }

            if didSucceed {
                self.array = newArray
            }

            return didSucceed
        }

        guard let fileURL = fileURL else {
            return false
        }

        do {
            let newSerializedData: Data
            switch type {
            case .json:
                newSerializedData = try JSONSerialization.data(withJSONObject: newArray)
            case .plist(let format):
                guard let format = format else {
                    return false
                }

                newSerializedData = try PropertyListSerialization.data(fromPropertyList: newArray, format: format, options: 0)
            }

            try FSOperation.perform(.writeData(url: fileURL, data: newSerializedData), rootHelperConf: RootConf.shared)
            self.array = newArray
            return true
        } catch {
            self.errorAlert(error, title: "Unable to write to file")
            return false
        }
    }
}

typealias SerializedDictionaryType = [String: SerializedItemType]

class SerializedDocumentViewController: UITableViewController, SerializedItemViewControllerDelegate {

    var serializedDict: SerializedDictionaryType

    var filteredDict: SerializedDictionaryType = [:]

    var keys: [String] {
        let keysArr = Array(isSearching ? filteredDict.keys : serializedDict.keys)
        return keysArr.sorted { $0.localizedStandardCompare($1) == .orderedAscending }
    }

    var fileURL: URL?
    var canEdit: Bool
    var isSearching: Bool = false
    let type: SerializedDocumentViewerType
    let parentController: SerializedControllerParent?

    init(
        dictionary: SerializedDictionaryType,
        type: SerializedDocumentViewerType,
        title: String,
        fileURL: URL? = nil,
        parentController: SerializedControllerParent?,
        canEdit: Bool
    ) {
        self.serializedDict = dictionary
        self.type = type
        self.fileURL = fileURL
        self.canEdit = canEdit
        self.parentController = parentController

        super.init(style: .userPreferred)
        self.title = title
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        applySantanderGlass()

        let closeButton = UIBarButtonItem(systemItem: .done, primaryAction: UIAction(withClosure: dismissVC))
        let addButton = UIBarButtonItem(
            systemItem: .add,
            primaryAction: UIAction { [weak self] _ in
                self?.presentAddValue()
            }
        )
        navigationItem.rightBarButtonItems = canEdit ? [closeButton, addButton] : [closeButton]
        let searchController = UISearchController()
        searchController.searchBar.delegate = self
        navigationItem.searchController = searchController
        navigationItem.hidesSearchBarWhenScrolling = !UserPreferences.alwaysShowSearchBar
    }

    convenience init?(
        type: SerializedDocumentViewerType,
        fileURL: URL,
        data: Data,
        canEdit: Bool
    ) {

        switch type {
        case .json:
            guard let json = try? JSONSerialization.jsonObject(with: data) as? [String: Any] else {
                return nil
            }

            let newDict = json.asSerializedDictionary()
            self.init(dictionary: newDict, type: .json, title: fileURL.lastPathComponent, fileURL: fileURL, parentController: nil, canEdit: canEdit)
        case .plist(_):
            let fmt: UnsafeMutablePointer<PropertyListSerialization.PropertyListFormat>? = .allocate(capacity: 4)
            defer {
                fmt?.deallocate()
            }

            guard let plist = try? PropertyListSerialization.propertyList(from: data, format: fmt) as? [String: Any] else {
                return nil
            }

            let newDict = plist.asSerializedDictionary()

            self.init(dictionary: newDict, type: .plist(format: fmt?.pointee), title: fileURL.lastPathComponent, fileURL: fileURL, parentController: nil, canEdit: canEdit)
        }
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return keys.count
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = UITableViewCell(style: .value2, reuseIdentifier: nil)
        var conf = cell.defaultContentConfiguration()
        let text = keys[indexPath.row]

        conf.text = text
        let elem = dictElement(forKey: text)

        switch elem {
        case .dictionary(_), .array(_):
            cell.accessoryType = .disclosureIndicator
        default:
            cell.accessoryType = .detailButton
        }

        conf.secondaryText = valueDescription(forElement: elem)
        cell.contentConfiguration = conf
        return cell
    }

    func dismissVC() {
        self.dismiss(animated: true)
    }

    func presentViewController(forIndexPath indexPath: IndexPath) {
        let text = keys[indexPath.row]
        let elem = dictElement(forKey: text)!

        if case .array(let arr) = elem {
            let vc = SerializedArrayViewController(array: arr, type: type, parentController: .dictionary(self, key: text), title: text, fileURL: fileURL, canEdit: canEdit)
            self.navigationController?.pushViewController(vc, animated: true)
        } else if case .dictionary(let dict) = elem {
            let newDict = dict.asSerializedDictionary()

            let vc = SerializedDocumentViewController(dictionary: newDict, type: type, title: text, fileURL: fileURL, parentController: .dictionary(self, key: text), canEdit: true)
            self.navigationController?.pushViewController(vc, animated: true)
        } else {
            let vc = SerializedItemViewController(item: elem, itemKey: text)
            vc.delegate = self
            navigationController?.pushViewController(vc, animated: true)
        }
    }

    override func tableView(_ tableView: UITableView, accessoryButtonTappedForRowWith indexPath: IndexPath) {
        presentViewController(forIndexPath: indexPath)
    }

    func didChangeName(ofItem item: String, to newName: String) -> Bool {
        guard let value = serializedDict[item] else {
            return false
        }

        var newDict: SerializedDictionaryType = serializedDict
        newDict[item] = nil
        newDict[newName] = value

        let didSucceed = writeToFile(newDict: newDict)
        tableView.reloadData()
        return didSucceed
    }

    func didChangeValue(ofItem item: String, to newValue: SerializedItemType) -> Bool {
        var newDict: SerializedDictionaryType = serializedDict
        newDict[item] = newValue

        let didSucceed = writeToFile(newDict: newDict)
        if isSearching {
            tableView.reloadData()
        } else {
            updateFilteredDict(reloadData: true, searchText: nil)
        }
        return didSucceed
    }

    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        presentViewController(forIndexPath: indexPath)
    }

    @discardableResult
    func writeToFile(newDict: SerializedDictionaryType) -> Bool {
        guard let fileURL = fileURL, canEdit else {
            return false
        }

        if let parentController = parentController {
            let didSucced: Bool
            switch parentController {
            case .dictionary(let parent, let key):
                var parentDict = parent.serializedDict
                parentDict[key] = .dictionary(newDict.asAnyDictionary())
                didSucced = parent.writeToFile(newDict: parentDict)
            case .array(let parent, let index):
                guard parent.array.indices.contains(index) else {
                    return false
                }
                var parentArr = parent.array
                parentArr[index] = newDict.asAnyDictionary()
                didSucced = parent.writeToFile(newArray: parentArr)
            }

            if didSucced {
                self.serializedDict = newDict
                return true
            }

            return false
        }

        switch type {
        case .json:
            do {
                let newData = try JSONSerialization.data(withJSONObject: newDict.asAnyDictionary(), options: .prettyPrinted)
                try FSOperation.perform(.writeData(url: fileURL, data: newData), rootHelperConf: RootConf.shared)
                self.serializedDict = newDict
                return true
            } catch {
                self.errorAlert(error, title: "Unable to write to file \(fileURL.lastPathComponent)", presentingFromIfAvailable: presentedViewController)
                return false
            }
        case .plist(let format):
            guard let format = format else {
                self.errorAlert("Unable to get plist format", title: "Can't write to Property List file", presentingFromIfAvailable: presentedViewController)
                return false
            }

            do {
                let newData = try PropertyListSerialization.data(fromPropertyList: newDict.asAnyDictionary(), format: format, options: 0)
                try FSOperation.perform(.writeData(url: fileURL, data: newData), rootHelperConf: RootConf.shared)
                self.serializedDict = newDict
                return true
            } catch {
                self.errorAlert(error, title: "Unable to write to file \(fileURL.lastPathComponent)", presentingFromIfAvailable: presentedViewController)
                return false
            }
        }
    }

    func presentAddValue() {
        guard canEdit else {
            return
        }

        let alert = UIAlertController(title: "Add Key", message: nil, preferredStyle: .alert)
        alert.addTextField { field in
            field.placeholder = "Key"
            field.autocapitalizationType = .none
        }

        let types = [
            ("String", SerializedItemType.string("")),
            ("Boolean", SerializedItemType.bool(false)),
            ("Integer", SerializedItemType.int(0)),
            ("Real", SerializedItemType.float(0)),
            ("Date", SerializedItemType.date(Date())),
            ("Array", SerializedItemType.array([])),
            ("Dictionary", SerializedItemType.dictionary([:]))
        ]

        for (name, value) in types {
            alert.addAction(UIAlertAction(title: name, style: .default) { [weak self, weak alert] _ in
                guard let self, let key = alert?.textFields?.first?.text?.trimmingCharacters(in: .whitespacesAndNewlines), !key.isEmpty else {
                    return
                }
                guard self.serializedDict[key] == nil else {
                    self.errorAlert("The key already exists.", title: "Duplicate Key")
                    return
                }
                var newDict = self.serializedDict
                newDict[key] = value
                guard self.writeToFile(newDict: newDict) else {
                    return
                }
                self.updateFilteredDict(reloadData: true, searchText: nil)
            })
        }

        alert.addAction(.cancel())
        present(alert, animated: true)
    }

    func dictElement(forKey key: String) -> SerializedItemType? {
        return isSearching ? filteredDict[key] : serializedDict[key]
    }

    override func tableView(_ tableView: UITableView, trailingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration? {
        guard canEdit else {
            return nil
        }

        let deleteAction = UIContextualAction(style: .destructive, title: nil) { _, _, completion in
            var newDict = self.serializedDict
            newDict[self.keys[indexPath.row]] = nil
            if self.writeToFile(newDict: newDict) {
                self.updateFilteredDict(reloadData: false, searchText: nil)
                self.tableView.deleteRows(at: [indexPath], with: .fade)
                completion(true)
            } else {
                completion(false)
            }
        }
        deleteAction.image = .remove

        return UISwipeActionsConfiguration(actions: [deleteAction])
    }
}

enum SerializedDocumentViewerType {
    case json
    case plist(format: PropertyListSerialization.PropertyListFormat?)
}

extension SerializedDocumentViewController: UISearchBarDelegate {
    func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
        isSearching = false
        tableView.reloadData()
    }

    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        isSearching = !searchText.isEmpty

        updateFilteredDict(reloadData: true, searchText: searchText)
    }

    func valueDescription(forElement element: SerializedItemType?) -> String? {
        switch element {
        case .array(_), .dictionary(_):
            return element?.typeDescription
        default:
            return element?.description
        }
    }

    func updateFilteredDict(reloadData: Bool, searchText text: String?) {
        if isSearching {
            let searchText = text ?? navigationItem.searchController?.searchBar.text ?? ""
            filteredDict = serializedDict.filter { (key, value) in
                return key.localizedCaseInsensitiveContains(searchText) ||
                valueDescription(forElement: value)?.localizedCaseInsensitiveContains(searchText) ?? false
            }
        }

        if reloadData {
            tableView.reloadData()
        }
    }
}

enum SerializedItemType: Equatable, CustomStringConvertible {
    static func == (lhs: SerializedItemType, rhs: SerializedItemType) -> Bool {
        switch (lhs, rhs) {
        case (.string(let first), .string(let second)):         return first == second
        case (.bool(let first), .bool(let second)):             return first == second
        case (.int(let first), .int(let second)):               return first == second
        case (.float(let first), .float(let second)):           return first == second
        case (.data(let first), .data(let second)):             return first == second
        case (.date(let first), .date(let second)):             return first == second
        case (.array(let first), .array(let second)):
            return NSArray(array: first) == NSArray(array: second)
        case (.dictionary(let first), .dictionary(let second)):
            return NSDictionary(dictionary: first) == NSDictionary(dictionary: second)
        default:
            return false
        }
    }

    case string(String)
    case bool(Bool)
    case int(Int)
    case float(Float)
    case array(Array<Any>)
    case dictionary([String: Any])
    case data(Data)
    case date(Date)
    case other(Any)

    init(item: Any) {
        switch item {
        case let string as String:
            self = .string(string)
        case let nsNumber as NSNumber:
            if CFGetTypeID(nsNumber) == CFBooleanGetTypeID() {
                self = .bool(nsNumber.boolValue)
            } else {
                switch CFNumberGetType(nsNumber as CFNumber) {
                case .floatType, .float32Type, .float64Type, .cgFloatType, .doubleType:
                    self = .float(nsNumber.floatValue)
                default:
                    self = .int(nsNumber.intValue)
                }
            }
        case let arr as Array<Any>:
            self = .array(arr)
        case let dictionary as Dictionary<String, Any>:
            self = .dictionary(dictionary)
        case let data as NSData:
            self = .data(data as Data)
        case let date as NSDate:
            self = .date(date as Date)
        default:
            self = .other(item)
        }

    }

    var description: String {
        switch self {
        case .string(let string):
            return string
        case .bool(let bool):
            return bool.description
        case .int(let int):
            return int.description
        case .float(let float):
            return float.description
        case .array(let array):
            return array.description
        case .dictionary(let nsDictionary):
            return nsDictionary.description
        case .date(let date):
            return date.listFormatted()
        case .data(let data):
            return "Data (Size: \(data.count))"
        case .other(let any):
            return String(describing: any)
        }
    }

    var typeDescription: String {
        switch self {
        case .string(_):
            return "String"
        case .bool(_):
            return "Boolean"
        case .int(_):
            return "Integer"
        case .float(_):
            return "Float"
        case .data(_):
            return "Data"
        case .array(_):
            return "Array"
        case .dictionary(_):
            return "Dictionary"
        case .date(_):
            return "Date"
        case .other(_):
            return "Unknown Type"
        }
    }

    var representedObject: Any {
        switch self {
        case .string(let string):
            return string
        case .bool(let bool):
            return bool
        case .int(let int):
            return int
        case .float(let float):
            return float
        case .array(let nsArray):
            return nsArray
        case .dictionary(let nsDictionary):
            return nsDictionary
        case .data(let data):
            return data
        case .date(let date):
            return date
        case .other(let any):
            return any
        }
    }

}

enum SerializedControllerParent {
    case dictionary(SerializedDocumentViewController, key: String)
    case array(SerializedArrayViewController, index: Int)
}

class SerializedItemViewController: UITableViewController {
    var item: SerializedItemType
    var itemKey: String

    weak var delegate: SerializedItemViewControllerDelegate?
    var retainedDelegate: SerializedItemViewControllerDelegate?

    init(item: SerializedItemType, itemKey: String) {
        self.item = item
        self.itemKey = itemKey

        super.init(style: .grouped)
    }

    required init?(coder: NSCoder) {
        fatalError()
    }

    func setItem(to newValue: SerializedItemType) {
        if self.delegate?.didChangeValue(ofItem: itemKey, to: newValue) ?? false {
            item = newValue
            tableView.reloadRows(at: [IndexPath(row: 0, section: 1)], with: .fade)
        }
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        applySantanderGlass()
        title = itemKey
    }

    override func numberOfSections(in tableView: UITableView) -> Int {
        return 3
    }

    override func tableView(_ tableView: UITableView, shouldHighlightRowAt indexPath: IndexPath) -> Bool {
        return false
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }

    func makeBoolChangeButton(currentItemBoolValue: Bool) -> UIButton {
        let button = UIButton()
        let actions = [true, false].map { bool in
            UIAction(title: bool.description, state: currentItemBoolValue == bool ? .on : .off) { _ in
                self.setItem(to: .bool(bool))
            }
        }

        button.menu = UIMenu(children: actions)
        button.showsMenuAsPrimaryAction = true

        button.setTitle(currentItemBoolValue.description, for: .normal)
        button.setTitleColor(.systemGray, for: .normal)
        return button
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = UITableViewCell(style: .value1, reuseIdentifier: nil)
        var conf = cell.defaultContentConfiguration()

        switch indexPath.section {
        case 0:
            let textField = UITextField(frame: cell.frame)
            textField.text = itemKey
            textField.returnKeyType = .done

            let action = UIAction {
                self.itemKeyTextFieldDone(textField, indexPath: indexPath)
            }
            textField.addAction(action, for: .editingDidEndOnExit)
            cell.contentView.addSubview(textField)

            textField.translatesAutoresizingMaskIntoConstraints = false
            NSLayoutConstraint.activate([
                textField.leadingAnchor.constraint(equalTo: cell.contentView.layoutMarginsGuide.leadingAnchor),
                textField.centerYAnchor.constraint(equalTo: cell.contentView.centerYAnchor)
            ])

            return cell
        case 1:
            switch item {
            case .bool(let bool):
                return cellWithView(makeBoolChangeButton(currentItemBoolValue: bool), text: "Value")
            case .string(let string):
                let textView = UITextView(frame: cell.frame)
                textView.text = string
                textView.font = .systemFont(ofSize: UIFont.systemFontSize)
                textView.backgroundColor = cell.backgroundColor
                textView.autoresizingMask = [.flexibleHeight, .flexibleWidth]
                textView.isScrollEnabled = true

                let editTextAction = UIAction {
                    guard let text = textView.text else {
                        return
                    }

                    self.setItem(to: .string(text))
                    textView.resignFirstResponder()
                }

                textView.inputAccessoryView = toolbarDoneView(doneAction: editTextAction, textFieldOrView: textView)
                cell.contentView.addSubview(textView)
                return cell
            case .int(_), .float(_):
                return cellWithView(valueTextField(atIndexPath: indexPath), text: "Value")
            case .date(let date):
                let datePicker = UIDatePicker()
                datePicker.date = date

                let action = UIAction {
                    self.setItem(to: .date(datePicker.date))
                }

                datePicker.addAction(action, for: .editingDidEnd)
                return cellWithView(datePicker, text: "Value")
            case .data(let data):
                let textView = UITextView(frame: cell.frame)
                textView.text = data.map { String(format: "%02x", $0) }.joined()
                textView.font = .monospacedSystemFont(ofSize: 15, weight: .regular)
                textView.autoresizingMask = [.flexibleWidth, .flexibleHeight]
                let editAction = UIAction {
                    guard let value = textView.text else { return }
                    let compact = value.replacingOccurrences(of: " ", with: "")
                        .replacingOccurrences(of: "\n", with: "")
                    guard compact.count % 2 == 0 else {
                        self.errorAlert("Hex data must contain an even number of characters.", title: "Invalid Data")
                        return
                    }
                    var bytes: [UInt8] = []
                    var index = compact.startIndex
                    while index < compact.endIndex {
                        let next = compact.index(index, offsetBy: 2)
                        guard let byte = UInt8(compact[index..<next], radix: 16) else {
                            self.errorAlert("The data contains an invalid hexadecimal byte.", title: "Invalid Data")
                            return
                        }
                        bytes.append(byte)
                        index = next
                    }
                    self.setItem(to: .data(Data(bytes)))
                    textView.resignFirstResponder()
                }
                textView.inputAccessoryView = toolbarDoneView(doneAction: editAction, textFieldOrView: textView)
                cell.contentView.addSubview(textView)
                textView.translatesAutoresizingMaskIntoConstraints = false
                NSLayoutConstraint.activate([
                    textView.leadingAnchor.constraint(equalTo: cell.contentView.layoutMarginsGuide.leadingAnchor),
                    textView.trailingAnchor.constraint(equalTo: cell.contentView.layoutMarginsGuide.trailingAnchor),
                    textView.topAnchor.constraint(equalTo: cell.contentView.topAnchor, constant: 8),
                    textView.bottomAnchor.constraint(equalTo: cell.contentView.bottomAnchor, constant: -8),
                    textView.heightAnchor.constraint(greaterThanOrEqualToConstant: 100)
                ])
                return cell
            default:
                conf.text = "Value"
                conf.secondaryText = item.description
            }
        case 2:
            conf.text = "Type"
            conf.secondaryText = item.typeDescription
        default:
            fatalError()
        }

        cell.contentConfiguration = conf
        return cell
    }

    override func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        switch section {
        case 0:
            return "Key"
        case 1:
            return "Value"
        case 2:
            return "Type"
        default:
            return nil
        }
    }

    func valueTextField(atIndexPath indexPath: IndexPath) -> UITextField {
        let textField = UITextField()

        let action = UIAction {
            self.valueTextFieldDone(textField, atIndexPath: indexPath)
        }

        switch item {
        case .string(let string):
            textField.text = string
            textField.returnKeyType = .done
            textField.addAction(action, for: .editingDidEndOnExit)
        case .int(let int):
            textField.keyboardType = .numberPad
            textField.text = int.description
            textField.inputAccessoryView = toolbarDoneView(doneAction: action, textFieldOrView: textField)
        case .float(let float):
            textField.text = float.description
            textField.keyboardType = .decimalPad
            textField.inputAccessoryView = toolbarDoneView(doneAction: action, textFieldOrView: textField)
        default:
            fatalError()
        }

        return textField
    }

    func toolbarDoneView(doneAction: UIAction, textFieldOrView: UIResponder) -> UIToolbar {
        let toolbar = UIToolbar()

        let cancelAction = UIAction {
            textFieldOrView.resignFirstResponder()
        }

        let doneButton = UIBarButtonItem(systemItem: .done, primaryAction: doneAction)
        let cancelButton = UIBarButtonItem(systemItem: .cancel, primaryAction: cancelAction)

        toolbar.setItems([cancelButton, .flexibleSpace(), doneButton], animated: true)
        toolbar.sizeToFit()
        return toolbar
    }

    func valueTextFieldDone(_ textField: UITextField, atIndexPath indexPath: IndexPath) {
        guard let text = textField.text, !text.isEmpty else {
            return
        }

        switch item {
        case .string(_):
            setItem(to: .string(text))
        case .int(_):
            guard let num = Int(text) else { return }
            setItem(to: .int(num))
        case .float(_):
            guard let num = Float(text) else { return }
            setItem(to: .float(num))
        default:
            break
        }

        textField.resignFirstResponder()
    }

    func itemKeyTextFieldDone(_ textField: UITextField, indexPath: IndexPath) {
        guard let text = textField.text, !text.isEmpty else {
            return
        }

        if self.delegate?.didChangeName(ofItem: itemKey, to: text) ?? false {
            self.itemKey = text
            self.title = self.itemKey
            self.tableView.reloadRows(at: [indexPath], with: .fade)
        }

        textField.resignFirstResponder()
    }

}

protocol SerializedItemViewControllerDelegate: AnyObject {
    func didChangeName(ofItem item: String, to newName: String) -> Bool
    func didChangeValue(ofItem item: String, to newValue: SerializedItemType) -> Bool
}

fileprivate func makeGenericButton(image: UIImage?) -> UIButton {
    let button = UIButton(type: .system)
    button.translatesAutoresizingMaskIntoConstraints = false
    button.setImage(image, for: .normal)
    button.tintColor = .label
    return button
}


extension PathListViewController {
    override func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        SantanderGlass.styleCell(cell)
    }
}

extension PathPermissionsViewController {
    override func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        SantanderGlass.styleCell(cell)
    }
}

extension SerializedDocumentViewController {
    override func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        SantanderGlass.styleCell(cell)
    }
}

extension SerializedArrayViewController {
    override func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        SantanderGlass.styleCell(cell)
    }
}

extension SerializedItemViewController {
    override func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        SantanderGlass.styleCell(cell)
    }
}

extension PathInformationTableViewController {
    override func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        SantanderGlass.styleCell(cell)
    }
}

class KeyboardSearchView: UIInputView {
    weak var textView: TextView?

    let searchQueue = DispatchQueue(label: "com.Antoine.Santander.KeyboardSearchView.search", qos: .background)
    var searchWorkItem: DispatchWorkItem?

    var searchMethod: SearchQuery.MatchMethod = .contains
    var isCaseSensitive: Bool = false

    var searchTextField: UISearchTextField!

    var currentIndex: Int = 0
    var chevronUpButton: UIButton!
    var chevronDownButton: UIButton!
    var currentResults: [SearchResult] = []

    init(
        frame: CGRect = CGRect(origin: .zero, size: CGSize(width: UIScreen.main.bounds.width, height: 44)),
        textView: TextView
    ) {
        super.init(frame: frame, inputViewStyle: .default)
        self.textView = textView
        commonInit()
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    func commonInit() {
        let doneButton = UIButton(type: .system)
        doneButton.translatesAutoresizingMaskIntoConstraints = false
        doneButton.setTitle("Done", for: .normal)
        doneButton.titleLabel?.font = .preferredFont(forTextStyle: .body)
        doneButton.setTitleColor(.white, for: .normal)
        doneButton.addTarget(self, action: #selector(doneDismiss), for: .allEvents)

        self.chevronUpButton = makeGenericButton(image: UIImage(systemName: "chevron.up"))
        self.chevronDownButton = makeGenericButton(image: UIImage(systemName: "chevron.down"))

        chevronUpButton.tag = 0
        chevronDownButton.tag = 1

        chevronUpButton.addTarget(self, action: #selector(chevronButtonClicked(sender:)), for: .touchUpInside)
        chevronDownButton.addTarget(self, action: #selector(chevronButtonClicked(sender:)), for: .touchUpInside)

        chevronUpButton.isEnabled = false
        chevronDownButton.isEnabled = false

        let filterButton = makeGenericButton(image: UIImage(systemName: "line.horizontal.3.decrease.circle")?.withTintColor(.systemBlue, renderingMode: .alwaysOriginal))

        filterButton.menu = makeSearchMethodMenu(button: filterButton)
        filterButton.showsMenuAsPrimaryAction = true

        let chevronButtonsStackView = UIStackView(arrangedSubviews: [filterButton, chevronUpButton, chevronDownButton])
        chevronButtonsStackView.setCustomSpacing(10, after: filterButton)
        chevronButtonsStackView.translatesAutoresizingMaskIntoConstraints = false

        self.searchTextField = UISearchTextField()
        searchTextField.addTarget(self, action: #selector(searchDidChange(searchTextField:)), for: .editingChanged)
        searchTextField.inputAccessoryView = self
        searchTextField.translatesAutoresizingMaskIntoConstraints = false

        addSubview(doneButton)
        addSubview(searchTextField)
        addSubview(chevronButtonsStackView)

        NSLayoutConstraint.activate([
            doneButton.leadingAnchor.constraint(equalTo: leadingAnchor, constant: 10),
            doneButton.centerYAnchor.constraint(equalTo: layoutMarginsGuide.centerYAnchor),

            chevronButtonsStackView.centerYAnchor.constraint(equalTo: layoutMarginsGuide.centerYAnchor),
            chevronButtonsStackView.trailingAnchor.constraint(equalTo: layoutMarginsGuide.trailingAnchor),

            searchTextField.leadingAnchor.constraint(equalTo: doneButton.leadingAnchor, constant: 50),
            searchTextField.trailingAnchor.constraint(equalTo: chevronButtonsStackView.leadingAnchor, constant: -10),
            searchTextField.centerYAnchor.constraint(equalTo: layoutMarginsGuide.centerYAnchor),
        ])
    }

    func makeSearchMethodMenu(button: UIButton) -> UIMenu {
        let filterButtonItems = SearchQuery.MatchMethod.allCases.reversed().map { meth in
            return UIAction(title: meth.description, state: searchMethod == meth ? .on : .off) { [unowned self] _ in
                searchMethod = meth
                button.menu = makeSearchMethodMenu(button: button)
            }
        }

        let caseSensitiveAction = UIAction(title: "Case Sensitive", state: isCaseSensitive ? .on : .off) { [unowned self] action in
            isCaseSensitive.toggle()
            button.menu = makeSearchMethodMenu(button: button)
        }

        let items: [UIMenuElement] = [UIMenu(options: .displayInline, children: [caseSensitiveAction])]
        + filterButtonItems
        return UIMenu(title: "Search Method", children: items)
    }

    @objc
    func doneDismiss() {
        guard let textView else { return }
        textView.highlightedRanges = []
        textView.inputAccessoryView = KeyboardToolsView(textView: textView)
        textView.resignFirstResponder()
    }

    @objc
    func searchDidChange(searchTextField: UISearchTextField) {
        searchWorkItem?.cancel()

        guard let textView else {
            return
        }

        guard let text = searchTextField.text, !text.isEmpty else {
            textView.highlightedRanges = []
            chevronUpButton.isEnabled = false
            chevronDownButton.isEnabled = false
            return
        }

        let newItem = DispatchWorkItem(flags: .assignCurrentContext) { [unowned self] in
            update(withResults: textView.search(for: makeSearchQuery(text: text)))
        }

        searchWorkItem = newItem
        searchQueue.asyncAfter(deadline: .now().advanced(by: .milliseconds(3)), execute: newItem)
    }

    func update(withResults results: [SearchResult]) {
        currentResults = results

        let areResultsNotEmpty = !results.isEmpty
        DispatchQueue.main.async { [unowned self] in
            if areResultsNotEmpty {
                textView?.scrollRangeToVisible(results[0].range)
            }

            chevronUpButton.isEnabled = areResultsNotEmpty
            chevronDownButton.isEnabled = areResultsNotEmpty
        }

        let highlightedRanges = results.map { result in
            HighlightedRange(range: result.range, color: .systemOrange)
        }

        textView?.highlightedRanges = highlightedRanges
    }

    func makeSearchQuery(text: String) -> SearchQuery {
        return SearchQuery(text: text, matchMethod: searchMethod, isCaseSensitive: isCaseSensitive)
    }

    @objc
    func chevronButtonClicked(sender: UIButton) {
        switch sender.tag {
        case 0:
            currentIndex -= 1
        case 1:
            currentIndex += 1
        default:
            break
        }

        chevronUpButton.isEnabled = currentIndex != 0
        chevronDownButton.isEnabled = currentIndex != (currentResults.count - 1)
        print(currentIndex, currentResults.count)

        textView?.scrollRangeToVisible(currentResults[currentIndex].range)
    }
}

extension SearchQuery.MatchMethod: CaseIterable, CustomStringConvertible {
    public static var allCases: [SearchQuery.MatchMethod] = [.startsWith, .endsWith, .contains, .fullWord, .regularExpression]

    public var description: String {
        switch self {
        case .contains:
            return "Contains"
        case .fullWord:
            return "Full Word"
        case .startsWith:
            return "Starts With"
        case .endsWith:
            return "Ends With"
        case .regularExpression:
            return "Regex"
        }
    }
}

fileprivate func _makeGenericButton(image: UIImage?) -> UIButton {
    let button = UIButton(type: .system)
    button.translatesAutoresizingMaskIntoConstraints = false
    button.setImage(image, for: .normal)
    button.tintColor = .label
    return button
}

final class KeyboardToolsView: UIInputView {
    private let shiftLeftButton = _makeGenericButton(image: UIImage(systemName: "arrow.left.to.line"))
    private let shiftRightButton = _makeGenericButton(image: UIImage(systemName: "arrow.right.to.line"))

    private let undoButton = _makeGenericButton(image: UIImage(systemName: "arrow.uturn.backward"))
    private let redoButton = _makeGenericButton(image: UIImage(systemName: "arrow.uturn.forward"))

    private let dismissButton = _makeGenericButton(image: UIImage(systemName: "keyboard.chevron.compact.down"))
    private let searchButton = _makeGenericButton(image: UIImage(systemName: "magnifyingglass"))

    private weak var textView: TextView?

    init(textView: TextView) {
        self.textView = textView
        let frame = CGRect(x: 0, y: 0, width: UIScreen.main.bounds.width, height: 44)
        super.init(frame: frame, inputViewStyle: .keyboard)
        setupView()
        setupLayout()
        NotificationCenter.default.addObserver(self, selector: #selector(updateUndoRedoButtonStates), name: .NSUndoManagerCheckpoint, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(updateUndoRedoButtonStates), name: .NSUndoManagerDidUndoChange, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(updateUndoRedoButtonStates), name: .NSUndoManagerDidRedoChange, object: nil)
    }

    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    deinit {
        NotificationCenter.default.removeObserver(self)
    }

    private func setupView() {
        addSubview(shiftLeftButton)
        addSubview(shiftRightButton)
        addSubview(undoButton)
        addSubview(redoButton)
        addSubview(dismissButton)
        addSubview(searchButton)

        shiftLeftButton.addTarget(self, action: #selector(shiftLeft), for: .touchUpInside)
        shiftRightButton.addTarget(self, action: #selector(shiftRight), for: .touchUpInside)
        undoButton.addTarget(self, action: #selector(undo), for: .touchUpInside)
        redoButton.addTarget(self, action: #selector(redo), for: .touchUpInside)
        dismissButton.addTarget(self, action: #selector(dismissKeyboard), for: .touchUpInside)
        searchButton.addTarget(self, action: #selector(switchToSearch), for: .touchUpInside)
        updateUndoRedoButtonStates()
    }

    private func setupLayout() {
        NSLayoutConstraint.activate([
            shiftLeftButton.leadingAnchor.constraint(equalTo: layoutMarginsGuide.leadingAnchor),
            shiftLeftButton.topAnchor.constraint(equalTo: topAnchor),
            shiftLeftButton.bottomAnchor.constraint(equalTo: bottomAnchor),

            shiftRightButton.leadingAnchor.constraint(equalTo: shiftLeftButton.trailingAnchor, constant: 6),
            shiftRightButton.topAnchor.constraint(equalTo: topAnchor),
            shiftRightButton.bottomAnchor.constraint(equalTo: bottomAnchor),

            undoButton.trailingAnchor.constraint(equalTo: redoButton.leadingAnchor, constant: -10),
            undoButton.topAnchor.constraint(equalTo: topAnchor),
            undoButton.bottomAnchor.constraint(equalTo: bottomAnchor),

            redoButton.trailingAnchor.constraint(equalTo: dismissButton.leadingAnchor, constant: -46),
            redoButton.topAnchor.constraint(equalTo: topAnchor),
            redoButton.bottomAnchor.constraint(equalTo: bottomAnchor),

            dismissButton.trailingAnchor.constraint(equalTo: layoutMarginsGuide.trailingAnchor),
            dismissButton.topAnchor.constraint(equalTo: topAnchor),
            dismissButton.bottomAnchor.constraint(equalTo: bottomAnchor),

            searchButton.trailingAnchor.constraint(equalTo: dismissButton.trailingAnchor, constant: -35),
            searchButton.topAnchor.constraint(equalTo: topAnchor),
            searchButton.bottomAnchor.constraint(equalTo: bottomAnchor)
        ])
    }
}

private extension KeyboardToolsView {
    @objc private func shiftLeft() {
        textView?.shiftLeft()
    }

    @objc private func shiftRight() {
        textView?.shiftRight()
    }

    @objc private func undo() {
        textView?.undoManager?.undo()
    }

    @objc private func redo() {
        textView?.undoManager?.redo()
    }

    @objc private func dismissKeyboard() {
        textView?.resignFirstResponder()
    }

    @objc private func switchToSearch() {
        guard let textView else { return }
        textView.inputAccessoryView = KeyboardSearchView(textView: textView)
        textView.resignFirstResponder()
        textView.becomeFirstResponder()
    }

    @objc private func updateUndoRedoButtonStates() {
        let undoManager = textView?.undoManager
        undoButton.isEnabled = undoManager?.canUndo ?? false
        redoButton.isEnabled = undoManager?.canRedo ?? false
    }
}

class TextEditorThemeSettingsViewController: SettingsTableViewController {

    weak var delegate: EditorThemeSettingsDelegate?
    var selectedIndexPath: IndexPath? = nil
    var theme: CodableTextEditorTheme

    var editorBackgroundColor: UIColor {
        theme.textEditorBackgroundColor?.uiColor ?? .tertiarySystemBackground
    }

    init(style: UITableView.Style, theme: CodableTextEditorTheme) {
        self.theme = theme
        super.init(style: style)
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) hasn't been implemented.")
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        applySantanderGlass()
        self.title = SantanderL10n.t("Text Editor Settings")
    }

    override func numberOfSections(in tableView: UITableView) -> Int {
        return 3
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        switch section {
        case 1: return 3
        case 0, 2: return 2
        default: fatalError("How the hell did you get here?! Unhandled section: \(section)")
        }
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = UITableViewCell(style: .value1, reuseIdentifier: nil)
        var conf = cell.defaultContentConfiguration()
        switch (indexPath.section, indexPath.row) {
        case (0, 0):
            conf.text = "Font"
            conf.secondaryText = theme.font.uiFont.fontName
        case (0, 1):
            conf.text = "Font size"
            let stepper = UIStepper()
            stepper.value = theme.font.uiFont.pointSize
            stepper.addTarget(self, action: #selector(fontStepperValueChanged(sender:)), for: .valueChanged)
            cell.accessoryView = stepper
            conf.secondaryText = theme.font.uiFont.pointSize.description
        case (1, 0):
            return cellWithView(settingsSwitch(forIndexPath: indexPath), text: "Show Line Count")
        case (1, 1):
            return cellWithView(settingsSwitch(forIndexPath: indexPath), text: "Wrap Lines")
        case (1, 2):
            return cellWithView(settingsSwitch(forIndexPath: indexPath), text: "Use Character Pairs")
        case (2, 0):
            conf.text = "Text Color"
            cell.accessoryView = cell.colorCircleAccessoryView(color: theme.textColor?.uiColor ?? .label)
        case (2, 1):
            conf.text = "Editor Background Color"
            cell.accessoryView = cell.colorCircleAccessoryView(color: editorBackgroundColor)
        default: break
        }

        cell.contentConfiguration = conf
        return cell
    }

    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        self.selectedIndexPath = indexPath
        if indexPath.section == 2 {
            let vc = UIColorPickerViewController()
            switch indexPath.row {
            case 0:
                vc.selectedColor = theme.textColor?.uiColor ?? .label
            case 1:
                vc.selectedColor = editorBackgroundColor
            default:
                break
            }

            vc.delegate = self
            self.present(vc, animated: true)
            return
        }

        switch (indexPath.section, indexPath.row) {
        case (0, 0):
            let vc = UIFontPickerViewController()
            vc.delegate = self
            self.present(vc, animated: true)
        default: break
        }
    }

    override func switchOptionIsEnabled(forIndexPath indexPath: IndexPath) -> Bool {
        switch (indexPath.section, indexPath.row) {
        case (1, 0):
            return UserPreferences.showLineCount
        case (1, 1):
            return UserPreferences.wrapLines
        case (1, 2):
            return UserPreferences.useCharacterPairs
        default:
            fatalError()
        }
    }

    override func settingsSwitch(forIndexPath indexPath: IndexPath) -> UISwitch {
        let s = super.settingsSwitch(forIndexPath: indexPath)

        let action = UIAction {
            UserDefaults.standard.set(s.isOn, forKey: self.defaultsKey(forIndexPath: indexPath))
            switch indexPath.row {
            case 0:
                self.delegate?.showLineCountConfigurationDidChange(showLineCount: s.isOn)
            case 1:
                self.delegate?.wrapLinesConfigurationDidChange(wrapLines: s.isOn)
            case 2:
                self.delegate?.characterPairConfigurationDidChange(useCharacterPairs: s.isOn)
            default:
                break
            }
        }

        s.addAction(action, for: .valueChanged)
        return s
    }

    override func defaultsKey(forIndexPath indexPath: IndexPath) -> String {
        switch (indexPath.section, indexPath.row) {
        case (1, 0):
            return "TextEditorShowLineCount"
        case (1, 1):
            return "TextEditorWrapLines"
        case (1, 2):
            return "TextEditorUseCharacterPairs"
        default:
            fatalError()
        }
    }

    @objc
    func fontStepperValueChanged(sender: UIStepper) {
        let val = sender.value
        self.theme.font = CodableFont(self.theme.font.uiFont.withSize(val))

        let stepperCellIndexPath = IndexPath(row: 1, section: 0)
        self.tableView.reloadRows(at: [stepperCellIndexPath], with: .none)
        delegate?.themeDidChange(to: self.theme)
    }

    override func tableView(_ tableView: UITableView, shouldHighlightRowAt indexPath: IndexPath) -> Bool {
        return indexPath.section == 2 || (indexPath.section, indexPath.row) == (0, 0)
    }

    func setColor(_ color: UIColor, forIndexPath indexPath: IndexPath) {
        switch (indexPath.section, indexPath.row) {
        case (2, 0):
            theme.textColor = CodableColor(color)
            self.delegate?.themeDidChange(to: theme)
        case (2, 1):
            let codableColor = CodableColor(color)
            theme.textEditorBackgroundColor = codableColor
            self.delegate?.didChangeEditorBackground(to: codableColor)
        default:
            break
        }

        tableView.reloadRows(at: [indexPath], with: .none)
    }

    override func colorPickerViewControllerDidFinish(_ viewController: UIColorPickerViewController) {
        guard let selectedIndexPath = selectedIndexPath else {
            return
        }
        setColor(viewController.selectedColor, forIndexPath: selectedIndexPath)
    }

    override func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        switch section {
        case 0:
            return "Fonts"
        case 1:
            return "Lines"
        case 2:
            return "Colors"
        default:
            return nil
        }
    }
}

extension TextEditorThemeSettingsViewController {
    override func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        SantanderGlass.styleCell(cell)
    }
}

extension TextEditorThemeSettingsViewController: UIFontPickerViewControllerDelegate {
    func fontPickerViewControllerDidPickFont(_ viewController: UIFontPickerViewController) {
        viewController.dismiss(animated: true)
        guard let descriptor = viewController.selectedFontDescriptor else { return }
        let existingFontSize = self.theme.font.uiFont.pointSize
        self.theme.font = CodableFont(UIFont(descriptor: descriptor, size: existingFontSize))

        let fontNameIndexPath = IndexPath(row: 0, section: 0)
        self.tableView.reloadRows(at: [fontNameIndexPath], with: .none)
        delegate?.themeDidChange(to: self.theme)
    }
}

protocol EditorThemeSettingsDelegate: AnyObject {
    func themeDidChange(to newTheme: CodableTextEditorTheme)
    func wrapLinesConfigurationDidChange(wrapLines: Bool)
    func showLineCountConfigurationDidChange(showLineCount: Bool)
    func characterPairConfigurationDidChange(useCharacterPairs: Bool)
    func didChangeEditorBackground(to color: CodableColor)
}

class TextFileEditorViewController: UIViewController, TextViewDelegate, EditorThemeSettingsDelegate {
    var fileURL: URL
    var originalContents: String

    var textView: TextView = TextView()
    var keyboardToolsView: KeyboardToolsView!
    var theme: CodableTextEditorTheme = UserPreferences.textEditorTheme {
        didSet {
            UserPreferences.textEditorTheme = theme
            let state = TextViewState(text: textView.text, theme: theme.theme)
            if Thread.isMainThread {
                textView.setState(state)
            } else {
                DispatchQueue.main.async {
                    self.textView.setState(state)
                }
            }
        }
    }

    init(fileURL: URL, contents: String) {
        self.fileURL = fileURL
        self.originalContents = contents

        super.init(nibName: nil, bundle: nil)
    }

    convenience init(fileURL: URL) throws {
        self.init(fileURL: fileURL, contents: try String(contentsOf: fileURL))
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    lazy var themeController: TextEditorThemeSettingsViewController = {
        let controller = TextEditorThemeSettingsViewController(style: .insetGrouped, theme: self.theme)
        controller.delegate = self
        return controller
    }()

    override func viewDidLoad() {
        super.viewDidLoad()

        self.title = fileURL.lastPathComponent
        textView.showLineNumbers = UserPreferences.showLineCount
        textView.isLineWrappingEnabled = UserPreferences.wrapLines
        textView.setState(TextViewState(text: originalContents, theme: theme.theme))

        textView.autocorrectionType = .no
        textView.autocapitalizationType = .none
        if UserPreferences.useCharacterPairs {
            textView.characterPairs = AnyCharacterPair.all()
        }

        textView.isEditable = true
        textView.editorDelegate = self
        textView.backgroundColor = theme.textEditorBackgroundColor?.uiColor ?? .tertiarySystemBackground
        self.keyboardToolsView = KeyboardToolsView(textView: textView)
        textView.inputAccessoryView = keyboardToolsView

        let saveBarButton = UIBarButtonItem(barButtonSystemItem: .save, target: self, action: #selector(saveToFile))
        saveBarButton.isEnabled = !textIsSameAsOriginal
        navigationItem.rightBarButtonItems = [saveBarButton, UIBarButtonItem(image: UIImage(systemName: "ellipsis.circle"), menu: makeRightBarMenuItemsMenu())]

        navigationItem.leftBarButtonItem = UIBarButtonItem(barButtonSystemItem: .cancel, target: self, action: #selector(cancel))

#if compiler(>=5.7)
        if #available(iOS 16.0, *) {
            navigationItem.style = .editor
            self.navigationItem.renameDelegate = self
            self.navigationItem.documentProperties = UIDocumentProperties(url: fileURL)
        }
#endif

        textView.keyboardDismissMode = .onDrag
        textView.translatesAutoresizingMaskIntoConstraints = false

        view.addSubview(textView)

        configureNavigationBarToNormal()

        textView.constraintCompletely(to: view)

        if UIDevice.isiPad {
            let navVC = UINavigationController(rootViewController: themeController)
            splitViewController?.setViewController(navVC, for: .primary)
            splitViewController?.preferredDisplayMode = .oneBesideSecondary
        }

        let notificationCenter = NotificationCenter.default
        notificationCenter.addObserver(self, selector: #selector(adjustForKeyboard), name: UIResponder.keyboardWillHideNotification, object: nil)
        notificationCenter.addObserver(self, selector: #selector(adjustForKeyboard), name: UIResponder.keyboardWillChangeFrameNotification, object: nil)
    }

    @objc func adjustForKeyboard(notification: Notification) {
        guard let keyboardValue = notification.userInfo?[UIResponder.keyboardFrameEndUserInfoKey] as? NSValue else {
            return
        }

        let keyboardScreenEndFrame = keyboardValue.cgRectValue
        let keyboardViewEndFrame = view.convert(keyboardScreenEndFrame, from: view.window)

        if notification.name == UIResponder.keyboardWillHideNotification {
            textView.contentInset = .zero
        } else {
            textView.contentInset = UIEdgeInsets(top: 0, left: 0,
                                                 bottom: keyboardViewEndFrame.height - view.safeAreaInsets.bottom,
                                                 right: 0)
        }

        textView.scrollIndicatorInsets = textView.contentInset
        let selectedRange = textView.selectedRange
        textView.scrollRangeToVisible(selectedRange)
    }

    override var keyCommands: [UIKeyCommand]? {
        return [
            UIKeyCommand(title: "Zoom in", action: #selector(zoomInOrOut(sender:)), input: "+", modifierFlags: .command),
            UIKeyCommand(title: "Zoom out", action: #selector(zoomInOrOut(sender:)), input: "-", modifierFlags: .command)
        ]
    }

    @objc func zoomInOrOut(sender: UIKeyCommand) {
        let existingFont = theme.font.uiFont
        self.theme.font = CodableFont(existingFont.withSize(existingFont.pointSize))

        switch sender.title {
        case "Zoom in":
            self.theme.font = CodableFont(existingFont.withSize(existingFont.pointSize + 1))
        case "Zoom out":
            self.theme.font = CodableFont(existingFont.withSize(existingFont.pointSize - 1))
        default:
            break
        }

        themeController.theme = self.theme
        themeController.tableView.reloadRows(at: [IndexPath(row: 1, section: 0)], with: .none)
    }

    func makeRightBarMenuItemsMenu() -> UIMenu {
        let settingsAction = UIAction(title: "Settings", image: UIImage(systemName: "gear")) { _ in
            self.presentTextEditorSettings()
        }

        let goToLineAction = UIAction(title: "Go to line") { _ in
            self.showGoToLine()
        }

        return UIMenu(image: UIImage(systemName: "ellipsis.circle"), children: [settingsAction, goToLineAction])
    }

    func showGoToLine() {
        let alert = UIAlertController(title: "Go to line", message: nil, preferredStyle: .alert)
        alert.addTextField { textField in
            textField.keyboardType = .numberPad
        }

        let goToLineAction = UIAlertAction(title: SantanderL10n.t("Go to line"), style: .default) { _ in
            guard let text = alert.textFields?.first?.text, let line = Int(text) else {
                print("\(#function) should not have reached here!")
                return
            }

            self.textView.goToLine(line - 1)
        }

        alert.addAction(.cancel())
        alert.addAction(goToLineAction)
        self.present(alert, animated: true)
    }

    func textViewDidChange(_ textView: TextView) {
        self.navigationItem.rightBarButtonItem?.isEnabled = !textIsSameAsOriginal
    }

    @objc
    func saveToFile() {
        let newContentsToSave = textView.text ?? ""

        do {
            try FSOperation.perform(.writeString(url: fileURL, string: newContentsToSave), rootHelperConf: RootConf.shared)
            self.dismiss(animated: true)
        } catch {
            self.errorAlert(error, title: "Unable to save to file")
        }
    }

    @objc
    func cancel() {
        if !textIsSameAsOriginal {
            let alert = UIAlertController(title: "Unsaved changes", message: "the file \"\(fileURL.lastPathComponent)\" has some unsaved changes, are you sure you want to close the file?", preferredStyle: .alert)
            let saveAction = UIAlertAction(title: SantanderL10n.t("Save"), style: .default) { _ in
                self.saveToFile()
            }
            let dontSaveAction = UIAlertAction(title: SantanderL10n.t("Don't save"), style: .destructive) { _ in
                self.dismiss(animated: true)
            }
            alert.addAction(dontSaveAction)
            alert.addAction(saveAction)
            self.present(alert, animated: true)
        } else {
            self.dismiss(animated: true)
        }
    }

    var textIsSameAsOriginal: Bool {
        textView.text == originalContents
    }

    @objc func presentTextEditorSettings() {
        if UIDevice.isiPad {
            splitViewController?.show(.primary)
        } else {
            let navVC = UINavigationController(rootViewController: themeController)

            if #available(iOS 15.0, *) {
                navVC.sheetPresentationController?.detents = [.medium(), .large()]
            }
            self.present(navVC, animated: true)
        }
    }

    func themeDidChange(to newTheme: CodableTextEditorTheme) {
        self.theme = newTheme
    }

    func wrapLinesConfigurationDidChange(wrapLines: Bool) {
        self.textView.isLineWrappingEnabled = wrapLines
    }

    func showLineCountConfigurationDidChange(showLineCount: Bool) {
        self.textView.showLineNumbers = showLineCount
    }

    func didChangeEditorBackground(to color: CodableColor) {
        self.textView.backgroundColor = color.uiColor
        self.theme.textEditorBackgroundColor = color
    }

    func characterPairConfigurationDidChange(useCharacterPairs: Bool) {
        textView.characterPairs = useCharacterPairs ? AnyCharacterPair.all() : []
    }
}

#if compiler(>=5.7)
@available(iOS 16.0, *)
extension TextFileEditorViewController: UINavigationItemRenameDelegate {
    func navigationItem(_: UINavigationItem, didEndRenamingWith title: String) {
        let newURL = self.fileURL.deletingLastPathComponent().appendingPathComponent(title)

        guard newURL != self.fileURL else {
            return
        }

        do {
            try FSOperation.perform(.moveItem(items: [fileURL], resultPath: newURL), rootHelperConf: RootConf.shared)
            self.fileURL = newURL
        } catch {
            self.errorAlert(error, title: "Unable to rename \(fileURL.lastPathComponent)")
            self.title = fileURL.lastPathComponent
        }
    }
}
#endif

class AnyTheme: Theme {
    public init(
        textColor: UIColor,
        font: UIFont,
        gutterBackgroundColor: UIColor,
        gutterHairlineColor: UIColor,
        lineNumberColor: UIColor,
        lineNumberFont: UIFont,
        selectedLineBackgroundColor: UIColor,
        selectedLinesLineNumberColor: UIColor,
        selectedLinesGutterBackgroundColor: UIColor,
        invisibleCharactersColor: UIColor,
        pageGuideBackgroundColor: UIColor,
        pageGuideHairlineColor: UIColor,
        markedTextBackgroundColor: UIColor,
        markedTextBackgroundBorderColor: UIColor
    ) {
        self._textColor = textColor
        self._font = font
        self._gutterBackgroundColor = gutterBackgroundColor
        self._gutterHairlineColor = gutterHairlineColor
        self._lineNumberColor = lineNumberColor
        self._lineNumberFont = lineNumberFont
        self._selectedLineBackgroundColor = selectedLineBackgroundColor
        self._selectedLinesLineNumberColor = selectedLinesLineNumberColor
        self._selectedLinesGutterBackgroundColor = selectedLinesGutterBackgroundColor
        self._invisibleCharactersColor = invisibleCharactersColor
        self._pageGuideBackgroundColor = pageGuideBackgroundColor
        self._pageGuideHairlineColor = pageGuideHairlineColor
        self._markedTextBackgroundColor = markedTextBackgroundColor
        self._markedTextBackgroundBorderColor = markedTextBackgroundBorderColor
    }

    private let _textColor: UIColor
    private let _font: UIFont
    private let _gutterBackgroundColor: UIColor
    private let _gutterHairlineColor: UIColor
    private let _lineNumberColor: UIColor
    private let _lineNumberFont: UIFont
    private let _selectedLineBackgroundColor: UIColor
    private let _selectedLinesLineNumberColor: UIColor
    private let _selectedLinesGutterBackgroundColor: UIColor
    private let _invisibleCharactersColor: UIColor
    private let _pageGuideBackgroundColor: UIColor
    private let _pageGuideHairlineColor: UIColor
    private let _markedTextBackgroundColor: UIColor
    private let _markedTextBackgroundBorderColor: UIColor

    var textColor: UIColor { _textColor }
    var font: UIFont { _font }
    var gutterBackgroundColor: UIColor { _gutterBackgroundColor }
    var gutterHairlineColor: UIColor { _gutterHairlineColor }
    var lineNumberColor: UIColor { _lineNumberColor }
    var lineNumberFont: UIFont { _lineNumberFont }
    var selectedLineBackgroundColor: UIColor { _selectedLineBackgroundColor }
    var selectedLinesLineNumberColor: UIColor { _selectedLinesLineNumberColor }
    var selectedLinesGutterBackgroundColor: UIColor { _selectedLinesGutterBackgroundColor }
    var invisibleCharactersColor: UIColor { _invisibleCharactersColor }
    var pageGuideBackgroundColor: UIColor { _pageGuideBackgroundColor }
    var pageGuideHairlineColor: UIColor { _pageGuideHairlineColor }
    var markedTextBackgroundColor: UIColor { _markedTextBackgroundColor }
    var markedTextBackgroundBorderColor: UIColor { _markedTextBackgroundBorderColor }

    func textColor(for rawHighlightName: String) -> UIColor? {
        _ = rawHighlightName
        return nil
    }

    func font(for rawHighlightName: String) -> UIFont? {
        _ = rawHighlightName
        return nil
    }
}

struct CodableColor: Codable {
    let red: CGFloat
    let green: CGFloat
    let blue: CGFloat
    let alpha: CGFloat

    var uiColor: UIColor {
        return UIColor(red: self.red, green: self.green, blue: self.blue, alpha: self.alpha)
    }

    init(_ color: UIColor) {
        var _red: CGFloat = 0, _green: CGFloat = 0, _blue: CGFloat = 0, _alpha: CGFloat = 0

        color.getRed(&_red, green: &_green, blue: &_blue, alpha: &_alpha)

        self.red = _red
        self.blue = _blue
        self.green = _green
        self.alpha = _alpha
    }
}

struct CodableFont: Codable {
    var name: String
    var size: CGFloat

    var uiFont: UIFont {
        UIFont(name: name, size: size) ?? UIFont.monospacedSystemFont(ofSize: size, weight: .regular)
    }

    init(_ font: UIFont) {
        self.name = font.fontName
        self.size = font.pointSize
    }
}

struct CodableTextEditorTheme: Codable {
    var textColor: CodableColor? = nil
    var font = CodableFont(UIFont(name: "Menlo-Regular", size: 16)!)

    var gutterBackgroundColor: CodableColor = CodableColor(.secondarySystemBackground)
    var gutterHairlineColor: CodableColor = CodableColor(.opaqueSeparator)

    var lineNumberColor: CodableColor = CodableColor(.secondaryLabel)
    var lineNumberFont = CodableFont(UIFont(name: "Menlo-Regular", size: 14)!)

    var selectedLineBackgroundColor: CodableColor = CodableColor(.secondarySystemBackground)
    var selectedLinesLineNumberColor: CodableColor = CodableColor(.label)
    var selectedLinesGutterBackgroundColor: CodableColor = CodableColor(UIColor.opaqueSeparator.withAlphaComponent(0.4))

    var invisibleCharactersColor: CodableColor = CodableColor(.tertiaryLabel)

    var pageGuideBackgroundColor: CodableColor = CodableColor(.secondarySystemBackground)
    var pageGuideHairlineColor: CodableColor = CodableColor(.opaqueSeparator)

    var markedTextBackgroundColor: CodableColor = CodableColor(.systemFill)
    var markedTextBackgroundBorderColor: CodableColor = CodableColor(.clear)

    var textEditorBackgroundColor: CodableColor? = nil
    var theme: AnyTheme {
        AnyTheme(
            textColor: textColor?.uiColor ?? .label,
            font: font.uiFont,
            gutterBackgroundColor: gutterBackgroundColor.uiColor,
            gutterHairlineColor: gutterHairlineColor.uiColor,
            lineNumberColor: lineNumberColor.uiColor,
            lineNumberFont: lineNumberFont.uiFont,
            selectedLineBackgroundColor: selectedLineBackgroundColor.uiColor,
            selectedLinesLineNumberColor: selectedLinesLineNumberColor.uiColor,
            selectedLinesGutterBackgroundColor: selectedLinesGutterBackgroundColor.uiColor,
            invisibleCharactersColor: invisibleCharactersColor.uiColor,
            pageGuideBackgroundColor: pageGuideBackgroundColor.uiColor,
            pageGuideHairlineColor: pageGuideHairlineColor.uiColor,
            markedTextBackgroundColor: markedTextBackgroundColor.uiColor,
            markedTextBackgroundBorderColor: markedTextBackgroundBorderColor.uiColor
        )
    }
}

struct AnyCharacterPair: CharacterPair {
    var leading: String
    var trailing: String

    static func all() -> [AnyCharacterPair] {
        return [
            AnyCharacterPair(leading: "{", trailing: "}"),
            AnyCharacterPair(leading: "(", trailing: ")"),
            AnyCharacterPair(leading: "[", trailing: "]"),
            AnyCharacterPair(leading: "<", trailing: ">")
        ]
    }
}
