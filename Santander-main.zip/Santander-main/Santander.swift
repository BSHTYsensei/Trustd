import AVFoundation
import AVKit
import CoreLocation
import CoreMedia
import Darwin
import Foundation
import ImageIO
import LocalAuthentication
import MapKit
import MediaPlayer
import ObjectiveC
import os
import PDFKit
import PhotosUI
import QuickLook
import UIKit
import UniformTypeIdentifiers


private enum SantanderRuntimeKit {
    static let coreUIHandle: UnsafeMutableRawPointer? = {
        let candidates = [
            "/System/Library/PrivateFrameworks/CoreUI.framework/CoreUI"
        ]
        for path in candidates where FileManager.default.fileExists(atPath: path) {
            if let handle = dlopen(path, RTLD_LAZY | RTLD_LOCAL) {
                return handle
            }
        }
        return nil
    }()

    static func method(_ receiver: AnyObject, _ selector: Selector) -> Method? {
        guard let cls = object_getClass(receiver) else { return nil }
        return class_getInstanceMethod(cls, selector)
    }

    static func object(_ receiver: AnyObject, _ selector: Selector) -> AnyObject? {
        guard let method = method(receiver, selector) else { return nil }
        typealias Fn = @convention(c) (AnyObject, Selector) -> Unmanaged<AnyObject>?
        let fn = unsafeBitCast(method_getImplementation(method), to: Fn.self)
        return fn(receiver, selector)?.takeUnretainedValue()
    }

    static func object(_ receiver: AnyObject, _ selector: Selector, _ arg: AnyObject?) -> AnyObject? {
        guard let method = method(receiver, selector) else { return nil }
        typealias Fn = @convention(c) (AnyObject, Selector, AnyObject?) -> Unmanaged<AnyObject>?
        let fn = unsafeBitCast(method_getImplementation(method), to: Fn.self)
        return fn(receiver, selector, arg)?.takeUnretainedValue()
    }

    static func object(_ receiver: AnyObject, _ selector: Selector, _ arg: AnyObject?, _ boolArg: Bool) -> AnyObject? {
        guard let method = method(receiver, selector) else { return nil }
        typealias Fn = @convention(c) (AnyObject, Selector, AnyObject?, Bool) -> Unmanaged<AnyObject>?
        let fn = unsafeBitCast(method_getImplementation(method), to: Fn.self)
        return fn(receiver, selector, arg, boolArg)?.takeUnretainedValue()
    }

    static func bool(_ receiver: AnyObject, _ selector: Selector, _ arg: AnyObject? = nil) -> Bool? {
        guard let method = method(receiver, selector) else { return nil }
        if arg == nil {
            typealias Fn = @convention(c) (AnyObject, Selector) -> Bool
            let fn = unsafeBitCast(method_getImplementation(method), to: Fn.self)
            return fn(receiver, selector)
        }
        typealias Fn = @convention(c) (AnyObject, Selector, AnyObject?) -> Bool
        let fn = unsafeBitCast(method_getImplementation(method), to: Fn.self)
        return fn(receiver, selector, arg)
    }

    static func int64(_ receiver: AnyObject, _ selector: Selector) -> Int64? {
        guard let method = method(receiver, selector) else { return nil }
        typealias Fn = @convention(c) (AnyObject, Selector) -> Int64
        let fn = unsafeBitCast(method_getImplementation(method), to: Fn.self)
        return fn(receiver, selector)
    }

    static func cgFloat(_ receiver: AnyObject, _ selector: Selector) -> CGFloat? {
        guard let method = method(receiver, selector) else { return nil }
        typealias Fn = @convention(c) (AnyObject, Selector) -> CGFloat
        let fn = unsafeBitCast(method_getImplementation(method), to: Fn.self)
        return fn(receiver, selector)
    }

    static func size(_ receiver: AnyObject, _ selector: Selector) -> CGSize? {
        guard let method = method(receiver, selector) else { return nil }
        typealias Fn = @convention(c) (AnyObject, Selector) -> CGSize
        let fn = unsafeBitCast(method_getImplementation(method), to: Fn.self)
        return fn(receiver, selector)
    }

    static func color(_ receiver: AnyObject, _ selector: Selector) -> CGColor? {
        guard let method = method(receiver, selector) else { return nil }
        typealias Fn = @convention(c) (AnyObject, Selector) -> Unmanaged<CGColor>?
        let fn = unsafeBitCast(method_getImplementation(method), to: Fn.self)
        return fn(receiver, selector)?.takeUnretainedValue()
    }

    static func image(_ receiver: AnyObject, _ selector: Selector) -> CGImage? {
        guard let method = method(receiver, selector) else { return nil }
        typealias Fn = @convention(c) (AnyObject, Selector) -> Unmanaged<CGImage>?
        let fn = unsafeBitCast(method_getImplementation(method), to: Fn.self)
        return fn(receiver, selector)?.takeUnretainedValue()
    }

    static func data(_ receiver: AnyObject, _ selector: Selector) -> Data? {
        guard let object = object(receiver, selector) else { return nil }
        if let data = object as? Data { return data }
        if let data = object as? NSData { return data as Data }
        return nil
    }

    static func block(_ receiver: AnyObject, _ selector: Selector, _ callback: @escaping (AnyObject) -> Void) {
        guard let method = method(receiver, selector) else { return }
        typealias Block = @convention(block) (AnyObject) -> Void
        let block: Block = { object in callback(object) }
        let blockObject = unsafeBitCast(block, to: AnyObject.self)
        typealias Fn = @convention(c) (AnyObject, Selector, AnyObject) -> Void
        let fn = unsafeBitCast(method_getImplementation(method), to: Fn.self)
        fn(receiver, selector, blockObject)
    }

    static func allocateAndInitialize(className: String, initializer: Selector, argument: AnyObject) -> AnyObject? {
        _ = coreUIHandle
        guard let cls = NSClassFromString(className),
              let allocated = object(cls as AnyObject, NSSelectorFromString("alloc")) else {
            return nil
        }
        return object(allocated, initializer, argument)
    }
}

final class CUIRenditionKey: Hashable, CustomStringConvertible {
    private let raw: AnyObject?
    let themeElement: Int64
    let themePart: Int64
    let themeIdiom: Int64
    let themeSubtype: Int64
    let themeDisplayGamut: Int64
    let themeAppearance: Int64

    init(raw: AnyObject?) {
        self.raw = raw

        func read(_ names: [String]) -> Int64 {
            guard let raw else { return 0 }
            for name in names {
                let selector = Selector((name))
                if let value = SantanderRuntimeKit.int64(raw, selector) {
                    return value
                }
                if let value = (raw as? NSObject)?.value(forKey: name) as? NSNumber {
                    return value.int64Value
                }
            }
            return 0
        }

        themeElement = read(["themeElement"])
        themePart = read(["themePart"])
        themeIdiom = read(["themeIdiom"])
        themeSubtype = read(["themeSubtype"])
        themeDisplayGamut = read(["themeDisplayGamut"])
        themeAppearance = read(["themeAppearance"])
    }

    func keyList() -> AnyObject? {
        guard let raw else { return nil }
        return SantanderRuntimeKit.object(raw, Selector(("keyList")))
            ?? raw
    }

    func hash(into hasher: inout Hasher) {
        hasher.combine(themeElement)
        hasher.combine(themePart)
        hasher.combine(themeIdiom)
        hasher.combine(themeSubtype)
        hasher.combine(themeDisplayGamut)
        hasher.combine(themeAppearance)
    }

    static func == (lhs: CUIRenditionKey, rhs: CUIRenditionKey) -> Bool {
        lhs.themeElement == rhs.themeElement &&
        lhs.themePart == rhs.themePart &&
        lhs.themeIdiom == rhs.themeIdiom &&
        lhs.themeSubtype == rhs.themeSubtype &&
        lhs.themeDisplayGamut == rhs.themeDisplayGamut &&
        lhs.themeAppearance == rhs.themeAppearance
    }

    var description: String {
        if let raw,
           let value = SantanderRuntimeKit.object(raw, NSSelectorFromString("description")) as? String {
            return value
        }
        return [
            themeElement, themePart, themeIdiom, themeSubtype,
            themeDisplayGamut, themeAppearance
        ].map(String.init).joined(separator: "/")
    }
}

final class CUIThemeRendition: Hashable {
    fileprivate let raw: AnyObject

    init(raw: AnyObject) {
        self.raw = raw
    }

    var classForCoder: AnyClass { type(of: raw) }

    func scale() -> CGFloat {
        SantanderRuntimeKit.cgFloat(raw, NSSelectorFromString("scale")) ?? 1.0
    }

    func unslicedSize() -> CGSize {
        SantanderRuntimeKit.size(raw, Selector(("unslicedSize"))) ?? .zero
    }

    func value(forKey key: String) -> Any? {
        let selector = Selector((key))
        if SantanderRuntimeKit.method(raw, selector) != nil {
            return SantanderRuntimeKit.object(raw, selector)
        }
        return (raw as? NSObject)?.value(forKey: key)
    }

    func data() -> Data? {
        SantanderRuntimeKit.data(raw, NSSelectorFromString("data"))
    }

    func srcData() -> Data? {
        SantanderRuntimeKit.data(raw, Selector(("srcData")))
    }

    func cgColor() -> Unmanaged<CGColor>? {
        guard let color = SantanderRuntimeKit.color(raw, Selector(("cgColor"))) else { return nil }
        return Unmanaged.passUnretained(color)
    }

    func uncroppedImage() -> Unmanaged<CGImage>? {
        guard let image = SantanderRuntimeKit.image(raw, Selector(("uncroppedImage"))) else { return nil }
        return Unmanaged.passUnretained(image)
    }

    func createImageFromPDFRendition(withScale scale: CGFloat) -> Unmanaged<CGImage>? {
        guard let data = data(),
              let provider = CGDataProvider(data: data as CFData),
              let document = CGPDFDocument(provider),
              let page = document.page(at: 1) else {
            return nil
        }

        let rect = page.getBoxRect(.mediaBox)
        let width = max(1.0, rect.width * scale)
        let height = max(1.0, rect.height * scale)
        guard let colorSpace = CGColorSpace(name: CGColorSpace.sRGB),
              let context = CGContext(
                data: nil,
                width: Int(width),
                height: Int(height),
                bitsPerComponent: 8,
                bytesPerRow: 0,
                space: colorSpace,
                bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue
              ) else {
            return nil
        }

        context.interpolationQuality = .high
        context.drawPDFPage(page)
        guard let image = context.makeImage() else { return nil }
        return Unmanaged.passRetained(image)
    }

    func name() -> String {
        SantanderRuntimeKit.object(raw, Selector(("name"))) as? String ?? ""
    }

    func key() -> CUIRenditionKey {
        CUIRenditionKey(raw: SantanderRuntimeKit.object(raw, Selector(("key"))))
    }

    static func == (lhs: CUIThemeRendition, rhs: CUIThemeRendition) -> Bool {
        lhs.raw === rhs.raw
    }

    func hash(into hasher: inout Hasher) {
        hasher.combine(ObjectIdentifier(raw))
    }
}

final class CUINamedLookup: Hashable {
    fileprivate let raw: AnyObject
    let name: String
    let renditionName: String
    let key: CUIRenditionKey
    let rendition: CUIThemeRendition

    init(raw: AnyObject) {
        self.raw = raw
        self.name = SantanderRuntimeKit.object(raw, Selector(("name"))) as? String
            ?? "Unnamed Asset"
        self.renditionName = SantanderRuntimeKit.object(raw, Selector(("renditionName"))) as? String
            ?? self.name
        self.key = CUIRenditionKey(raw: SantanderRuntimeKit.object(raw, Selector(("key"))))

        if let rendition = SantanderRuntimeKit.object(raw, Selector(("rendition"))) {
            self.rendition = CUIThemeRendition(raw: rendition)
        } else {
            self.rendition = CUIThemeRendition(raw: raw)
        }
    }

    static func == (lhs: CUINamedLookup, rhs: CUINamedLookup) -> Bool {
        lhs.name == rhs.name &&
        lhs.renditionName == rhs.renditionName &&
        lhs.key == rhs.key
    }

    func hash(into hasher: inout Hasher) {
        hasher.combine(name)
        hasher.combine(renditionName)
        hasher.combine(key)
    }
}

final class CUICatalog: NSObject {
    private let raw: AnyObject

    init(url: URL) throws {
        guard FileManager.default.fileExists(atPath: url.path) else {
            throw StringError("Asset catalog does not exist: \(url.path)")
        }

        guard let object =
                SantanderRuntimeKit.allocateAndInitialize(
                    className: "CUICatalog",
                    initializer: NSSelectorFromString("initWithURL:"),
                    argument: url as NSURL
                )
                ?? SantanderRuntimeKit.allocateAndInitialize(
                    className: "CUICatalog",
                    initializer: NSSelectorFromString("initWithContentsOfURL:"),
                    argument: url as NSURL
                ) else {
            throw StringError("CoreUI CUICatalog is unavailable on this OS.")
        }

        raw = object
        super.init()
    }

    func enumerateNamedLookups(_ block: @escaping (CUINamedLookup) -> Void) {
        SantanderRuntimeKit.block(raw, Selector(("enumerateNamedLookupsUsingBlock:"))) { object in
            block(CUINamedLookup(raw: object))
        }
    }

    func __getRenditionCollection() -> RenditionCollection {
        var grouped: [RenditionType: [Rendition]] = [:]
        enumerateNamedLookups { lookup in
            let rendition = Rendition(lookup)
            grouped[rendition.type, default: []].append(rendition)
        }

        return grouped.map { type, items in
            (
                type,
                items.sorted {
                    $0.name.localizedCaseInsensitiveCompare($1.name) == .orderedAscending
                }
            )
        }.sorted {
            $0.0.description.localizedCaseInsensitiveCompare($1.0.description) == .orderedAscending
        }
    }

    func removeItem(_ rendition: Rendition, fileURL: URL) throws {
        try SantanderAssetCatalogEditing.remove(rendition, fileURL: fileURL)
    }

    func editItem(
        _ item: Rendition,
        fileURL: URL,
        to newValue: Rendition.Representation,
        isAlphaAllowed: Bool = true
    ) throws {
        try SantanderAssetCatalogEditing.edit(
            item,
            fileURL: fileURL,
            to: newValue,
            isAlphaAllowed: isAlphaAllowed
        )
    }
}

typealias RenditionCollection = [(type: RenditionType, renditions: [Rendition])]

final class Rendition: Hashable {
    static let macCatalystSubtype: Int64 = 32401

    let cuiRend: CUIThemeRendition
    let namedLookup: CUINamedLookup
    let type: RenditionType
    let name: String

    lazy var representation: Representation? = Representation(self)
    lazy var image: CGImage? = getImage()

    init(_ namedLookup: CUINamedLookup) {
        self.cuiRend = namedLookup.rendition
        self.namedLookup = namedLookup
        self.type = RenditionType(namedLookup: namedLookup)
        self.name = type == .icon ? cuiRend.name() : namedLookup.name
    }

    private func getImage() -> CGImage? {
        if let image = cuiRend.uncroppedImage()?.takeUnretainedValue() {
            return image
        }

        if type == .pdf {
            return cuiRend.createImageFromPDFRendition(withScale: UIScreen.main.scale)?.takeUnretainedValue()
        }

        if let data = cuiRend.data(),
           let source = CGImageSourceCreateWithData(data as CFData, nil),
           let image = CGImageSourceCreateImageAtIndex(source, 0, nil) {
            return image
        }

        return nil
    }

    func makeDragItem() -> UIDragItem? {
        guard let image else { return nil }
        let uiImage = UIImage(cgImage: image)
        let provider = NSItemProvider(object: uiImage)
        let item = UIDragItem(itemProvider: provider)
        item.localObject = uiImage
        return item
    }

    static func == (lhs: Rendition, rhs: Rendition) -> Bool {
        lhs.name == rhs.name && lhs.type == rhs.type && lhs.namedLookup == rhs.namedLookup && lhs.cuiRend == rhs.cuiRend
    }

    func hash(into hasher: inout Hasher) {
        hasher.combine(name)
        hasher.combine(type)
        hasher.combine(namedLookup)
        hasher.combine(cuiRend)
    }

    enum Idiom: CustomStringConvertible {
        case universal, iphone, ipad, tv, watch, carPlay, macCatalyst, marketing

        init?(_ key: CUIRenditionKey) {
            if key.themeSubtype == Rendition.macCatalystSubtype {
                self = .macCatalyst
                return
            }
            switch key.themeIdiom {
            case 0: self = .universal
            case 1: self = .iphone
            case 2: self = .ipad
            case 3: self = .tv
            case 4: self = .carPlay
            case 5: self = .watch
            case 6: self = .marketing
            default: return nil
            }
        }

        var description: String {
            switch self {
            case .universal: return SantanderL10n.t("Universal")
            case .iphone: return SantanderL10n.t("iPhone")
            case .ipad: return SantanderL10n.t("iPad")
            case .tv: return SantanderL10n.t("TV")
            case .watch: return SantanderL10n.t("Watch")
            case .carPlay: return SantanderL10n.t("CarPlay")
            case .macCatalyst: return SantanderL10n.t("Mac Catalyst")
            case .marketing: return SantanderL10n.t("Marketing")
            }
        }
    }

    enum DisplayGamut: Int64, Hashable, CustomStringConvertible {
        case sRGB = 0
        case p3 = 1
        init?(_ key: CUIRenditionKey) { self.init(rawValue: key.themeDisplayGamut) }
        var description: String {
            switch self {
            case .sRGB: return SantanderL10n.t("SRGB")
            case .p3: return SantanderL10n.t("Display P3")
            }
        }
    }

    enum Appearance: Int64, CustomStringConvertible {
        case any = 0
        case dark = 1
        case highContrast = 2
        case highConstrastDark = 3
        case light = 4
        case highConstrastLight = 5

        init?(_ key: CUIRenditionKey) { self.init(rawValue: key.themeAppearance) }

        var description: String {
            switch self {
            case .any: return SantanderL10n.t("Any")
            case .dark: return SantanderL10n.t("Dark")
            case .highContrast: return SantanderL10n.t("High Contrast")
            case .highConstrastDark: return SantanderL10n.t("High Contrast Dark")
            case .light: return SantanderL10n.t("Light")
            case .highConstrastLight: return SantanderL10n.t("High Contrast Light")
            }
        }
    }

    enum Representation: Hashable {
        case color(CGColor)
        case image(CGImage)
        case rawData(Data)

        var uiView: UIView {
            switch self {
            case .color(let color):
                let view = UIView()
                view.backgroundColor = UIColor(cgColor: color)
                return view
            case .image(let image):
                let view = UIImageView(image: UIImage(cgImage: image))
                view.clipsToBounds = true
                view.contentMode = .scaleAspectFit
                return view
        case .rawData:
                return UIView()
            }
        }

        init?(_ rendition: Rendition) {
            if let color = rendition.cuiRend.cgColor()?.takeUnretainedValue() {
                self = .color(color)
            } else if let image = rendition.image {
                self = .image(image)
            } else if let data = rendition.cuiRend.data() {
                self = .rawData(data)
            } else {
                return nil
            }
        }
    }
}

enum RenditionType: Int, Codable, Hashable, CustomStringConvertible, CaseIterable {
    case image, icon, imageSet, multiSizeImageSet, pdf, color, svg, rawData, unknown

    init(namedLookup: CUINamedLookup) {
        let className = NSStringFromClass(namedLookup.rendition.classForCoder)
        switch className {
        case "_CUIRawPixelRendition":
            self = .image
        case "_CUIThemePixelRendition", "_CUIInternalLinkRendition":
            let key = namedLookup.key
            if key.themeElement == 85 && key.themePart == 220 {
                self = .icon
            } else if key.themeElement == 9 {
                self = .imageSet
            } else {
                self = .image
            }
        case "_CUIThemePDFRendition":
            self = .pdf
        case "_CUIThemeColorRendition":
            self = .color
        case "_CUIThemeSVGRendition":
            self = .svg
        case "_CUIThemeMultisizeImageSetRendition":
            self = .multiSizeImageSet
        case "_CUIRawDataRendition":
            self = .rawData
        default:
            self = .unknown
        }
    }

    var description: String {
        switch self {
        case .image: return SantanderL10n.t("Image")
        case .icon: return SantanderL10n.t("Icon")
        case .imageSet: return SantanderL10n.t("Image Set")
        case .multiSizeImageSet: return SantanderL10n.t("Multisize Image Set")
        case .pdf: return SantanderL10n.t("PDF")
        case .color: return SantanderL10n.t("Color")
        case .svg: return SantanderL10n.t("SVG (Vector)")
        case .rawData: return SantanderL10n.t("Raw Data")
        case .unknown: return SantanderL10n.t("Unknown")
        }
    }

    var isEditable: Bool {
        switch self {
        case .image, .icon, .color: return true
        default: return false
        }
    }
}

final class AssetCatalogWrapper {
    static let shared = AssetCatalogWrapper()

    func renditions(forCarArchive url: URL) throws -> (CUICatalog, RenditionCollection) {
        let catalog = try CUICatalog(url: url)
        return (catalog, catalog.__getRenditionCollection())
    }
}

struct CodableRendition {
    let renditionName: String
    let itemData: Data?
}

extension Array where Element == Rendition {
    func toCodable() -> [CodableRendition] {
        map { rendition in
            let data = rendition.cuiRend.srcData()
                ?? rendition.cuiRend.data()
                ?? rendition.image.flatMap { UIImage(cgImage: $0).pngData() }
            return CodableRendition(renditionName: rendition.name, itemData: data)
        }
    }
}

private enum SantanderAssetCatalogEditing {
    private static func storage(for fileURL: URL) -> AnyObject? {
        _ = SantanderRuntimeKit.coreUIHandle
        guard let cls = NSClassFromString("CUIMutableCommonAssetStorage"),
              let allocated = SantanderRuntimeKit.object(cls as AnyObject, NSSelectorFromString("alloc")) else {
            return nil
        }

        return SantanderRuntimeKit.object(
            allocated,
            Selector(("initWithPath:forWriting:")),
            fileURL.path as NSString,
            true
        )
    }

    static func remove(_ rendition: Rendition, fileURL: URL) throws {
        guard let storage = storage(for: fileURL) else {
            throw StringError("CoreUI asset writing is unavailable on this iOS version.")
        }
        let key = rendition.cuiRend.key().keyList() as AnyObject
        let selector = Selector(("removeAssetForKey:"))
        guard let method = SantanderRuntimeKit.method(storage, selector) else {
            throw StringError("CoreUI removeAssetForKey: is unavailable.")
        }

        typealias Fn = @convention(c) (AnyObject, Selector, AnyObject) -> Bool
        let fn = unsafeBitCast(method_getImplementation(method), to: Fn.self)
        guard fn(storage, selector, key) else {
            throw StringError("CoreUI failed to remove \(rendition.name).")
        }

        try flush(storage, fileURL: fileURL)
    }

    static func edit(
        _ item: Rendition,
        fileURL: URL,
        to newValue: Rendition.Representation,
        isAlphaAllowed: Bool
    ) throws {
        guard let storage = storage(for: fileURL) else {
            throw StringError("CoreUI asset writing is unavailable on this iOS version.")
        }
        let key = item.cuiRend.key().keyList() as AnyObject
        let selector = Selector(("setAsset:forKey:"))
        guard let method = SantanderRuntimeKit.method(storage, selector) else {
            throw StringError("CoreUI setAsset:forKey: is unavailable.")
        }

        switch newValue {
        case .color(let color):
            let asset = isAlphaAllowed ? color : UIColor(cgColor: color).withAlphaComponent(1).cgColor
            typealias Fn = @convention(c) (AnyObject, Selector, AnyObject, AnyObject) -> Bool
            let fn = unsafeBitCast(method_getImplementation(method), to: Fn.self)
            guard fn(storage, selector, asset, key) else {
                throw StringError("CoreUI failed to write \(item.name).")
            }
            try flush(storage, fileURL: fileURL)
        case .image(let image):
            let asset = image as AnyObject
            typealias Fn = @convention(c) (AnyObject, Selector, AnyObject, AnyObject) -> Bool
            let fn = unsafeBitCast(method_getImplementation(method), to: Fn.self)
            guard fn(storage, selector, asset, key) else {
                throw StringError("CoreUI failed to write \(item.name).")
            }
            try flush(storage, fileURL: fileURL)
        case .rawData(let data):
            let asset = data as NSData
            typealias Fn = @convention(c) (AnyObject, Selector, AnyObject, AnyObject) -> Bool
            let fn = unsafeBitCast(method_getImplementation(method), to: Fn.self)
            guard fn(storage, selector, asset, key) else {
                throw StringError("CoreUI failed to write raw data for \(item.name).")
            }
            try flush(storage, fileURL: fileURL)
        }
    }

    private static func flush(_ storage: AnyObject, fileURL: URL) throws {
        if SantanderRuntimeKit.method(storage, NSSelectorFromString("writeToPath:")) != nil {
            guard SantanderRuntimeKit.bool(storage, NSSelectorFromString("writeToPath:"), fileURL.path as NSString) == true else {
                throw StringError("CoreUI failed to save the asset catalog.")
            }
            return
        }
        if SantanderRuntimeKit.method(storage, NSSelectorFromString("writeToURL:")) != nil {
            guard SantanderRuntimeKit.bool(storage, NSSelectorFromString("writeToURL:"), fileURL as NSURL) == true else {
                throw StringError("CoreUI failed to save the asset catalog.")
            }
            return
        }
        if SantanderRuntimeKit.method(storage, Selector(("write"))) != nil {
            _ = SantanderRuntimeKit.object(storage, Selector(("write")))
            return
        }
        throw StringError("CoreUI storage does not expose a writable catalog method.")
    }
}

struct ArchiveOptions: OptionSet {
    var rawValue: Int32
    init(rawValue: Int32) { self.rawValue = rawValue }

    static let restoreOwner = ArchiveOptions(rawValue: 1 << 0)
    static let restorePermissions = ArchiveOptions(rawValue: 1 << 1)
    static let restoreTime = ArchiveOptions(rawValue: 1 << 2)
    static let dontOverwite = ArchiveOptions(rawValue: 1 << 3)
    static let unlink = ArchiveOptions(rawValue: 1 << 4)
    static let restoreACLs = ArchiveOptions(rawValue: 1 << 5)
    static let restoreFFLags = ArchiveOptions(rawValue: 1 << 6)
    static let restoreXattrs = ArchiveOptions(rawValue: 1 << 7)
    static let secureSymlinks = ArchiveOptions(rawValue: 1 << 8)
    static let secureNoDotDot = ArchiveOptions(rawValue: 1 << 9)
    static let dontCreateParentDirs = ArchiveOptions(rawValue: 1 << 10)
    static let sparse = ArchiveOptions(rawValue: 1 << 11)
    static let includeMacOSMetadata = ArchiveOptions(rawValue: 1 << 12)
    static let dontUseHFSCompression = ArchiveOptions(rawValue: 1 << 13)
    static let forceUseHFSCompression = ArchiveOptions(rawValue: 1 << 14)
    static let rejectAbsolutePaths = ArchiveOptions(rawValue: 1 << 15)
}

final class Compression {
    enum FormatType: CaseIterable, CustomStringConvertible {
        case zip
        case tar

        var fileExtension: String {
            switch self {
            case .zip: return "zip"
            case .tar: return "tar"
            }
        }

        var description: String {
            switch self {
            case .zip: return SantanderL10n.t("Zip")
            case .tar: return SantanderL10n.t("Tar")
            }
        }
    }

    static let shared = Compression()
    private init() {}

    func compress(
        paths: [URL],
        outputPath: URL,
        format: FormatType,
        progress: ((URL) -> Void)? = nil
    ) throws {
        guard !paths.isEmpty else {
            throw StringError("No input paths were supplied.")
        }

        try FileManager.default.createDirectory(
            at: outputPath.deletingLastPathComponent(),
            withIntermediateDirectories: true
        )

        switch format {
        case .zip:
            let result = try SantanderProcessRunner.run(
                "/usr/bin/zip",
                ["-qry", outputPath.path] + paths.map(\.path)
            )
            guard result.status == 0 else {
                throw StringError("zip failed: \(result.stderr)")
            }
        case .tar:
            let result = try SantanderProcessRunner.run(
                "/usr/bin/tar",
                ["-cf", outputPath.path] + paths.map(\.path)
            )
            guard result.status == 0 else {
                throw StringError("tar failed: \(result.stderr)")
            }
        }

        for path in paths {
            progress?(path)
        }
    }

    func extract(
        path compressedFile: URL,
        to destination: URL,
        options: ArchiveOptions = [.restoreTime, .restorePermissions, .restoreACLs, .restoreFFLags]
    ) throws {
        try FileManager.default.createDirectory(at: destination, withIntermediateDirectories: true)

        let lower = compressedFile.path.lowercased()
        if lower.hasSuffix(".zip") {
            let result = try SantanderProcessRunner.run(
                "/usr/bin/unzip",
                ["-o", compressedFile.path, "-d", destination.path]
            )
            guard result.status == 0 else {
                throw StringError("unzip failed: \(result.stderr)")
            }
            return
        }

        let result = try SantanderProcessRunner.run(
            "/usr/bin/tar",
            ["-xf", compressedFile.path, "-C", destination.path]
        )
        guard result.status == 0 else {
            throw StringError("tar failed: \(result.stderr)")
        }

        _ = options
    }
}

final class NSTask: NSObject {
    var executableURL: URL?
    var arguments: [String] = []
    var standardOutput: Any?
    var standardError: Any?
    private(set) var processIdentifier: pid_t = 0
    private(set) var terminationStatus: Int32 = 0
    private(set) var isRunning = false

    func launchAndReturnError() throws {
        guard let executableURL else {
            throw StringError("Executable URL is missing.")
        }

        var actions: posix_spawn_file_actions_t?
        guard posix_spawn_file_actions_init(&actions) == 0 else {
            throw StringError("Unable to initialize process actions.")
        }
        defer { _ = posix_spawn_file_actions_destroy(&actions) }

        var stdoutPipe: Pipe?
        var stderrPipe: Pipe?

        func addStream(_ stream: Any?, fd: Int32, pipeStore: inout Pipe?) throws {
            guard let pipe = stream as? Pipe else { return }
            pipeStore = pipe
            let childFD = pipe.fileHandleForWriting.fileDescriptor
            guard posix_spawn_file_actions_adddup2(&actions, childFD, fd) == 0 else {
                throw StringError("Unable to attach process output pipe.")
            }
        }

        try addStream(standardOutput, fd: STDOUT_FILENO, pipeStore: &stdoutPipe)
        try addStream(standardError, fd: STDERR_FILENO, pipeStore: &stderrPipe)

        var argv = [strdup(executableURL.path)]
        argv.append(contentsOf: arguments.map { strdup($0) })
        argv.append(nil)
        defer { for pointer in argv.compactMap({ $0 }) { free(pointer) } }

        var pid: pid_t = 0
        let result = argv.withUnsafeMutableBufferPointer { buffer in
            posix_spawn(&pid, executableURL.path, &actions, nil, buffer.baseAddress, environ)
        }
        guard result == 0 else {
            throw NSError(
                domain: NSPOSIXErrorDomain,
                code: Int(result),
                userInfo: [NSLocalizedDescriptionKey: String(cString: strerror(result))]
            )
        }

        processIdentifier = pid
        isRunning = true

        stdoutPipe?.fileHandleForWriting.closeFile()
        stderrPipe?.fileHandleForWriting.closeFile()

        _ = stdoutPipe
        _ = stderrPipe
    }

    func waitUntilExit() {
        guard processIdentifier > 0 else { return }
        var status: Int32 = 0
        _ = waitpid(processIdentifier, &status, 0)
        terminationStatus = status
        isRunning = false
    }

    func interrupt() {
        guard processIdentifier > 0, isRunning else { return }
        _ = kill(processIdentifier, SIGINT)
    }
}

private struct SantanderProcessResult {
    let status: Int32
    let stdout: String
    let stderr: String
}

private enum SantanderProcessRunner {
    static func run(_ executable: String, _ arguments: [String]) throws -> SantanderProcessResult {
        var stdoutPipe = [Int32](repeating: 0, count: 2)
        var stderrPipe = [Int32](repeating: 0, count: 2)
        guard pipe(&stdoutPipe) == 0 else {
            throw StringError("Unable to create stdout pipe.")
        }
        guard pipe(&stderrPipe) == 0 else {
            _ = close(stdoutPipe[0]); _ = close(stdoutPipe[1])
            throw StringError("Unable to create stderr pipe.")
        }

        var actions: posix_spawn_file_actions_t?
        guard posix_spawn_file_actions_init(&actions) == 0 else {
            _ = close(stdoutPipe[0]); _ = close(stdoutPipe[1])
            _ = close(stderrPipe[0]); _ = close(stderrPipe[1])
            throw StringError("Unable to initialize process actions.")
        }
        defer { _ = posix_spawn_file_actions_destroy(&actions) }

        _ = posix_spawn_file_actions_adddup2(&actions, stdoutPipe[1], STDOUT_FILENO)
        _ = posix_spawn_file_actions_adddup2(&actions, stderrPipe[1], STDERR_FILENO)
        _ = posix_spawn_file_actions_addclose(&actions, stdoutPipe[0])
        _ = posix_spawn_file_actions_addclose(&actions, stderrPipe[0])

        var argv = [strdup(executable)]
        argv.append(contentsOf: arguments.map { strdup($0) })
        argv.append(nil)
        defer { for pointer in argv.compactMap({ $0 }) { free(pointer) } }

        var pid: pid_t = 0
        let result = argv.withUnsafeMutableBufferPointer { buffer in
            posix_spawn(&pid, executable, &actions, nil, buffer.baseAddress, environ)
        }

        _ = close(stdoutPipe[1])
        _ = close(stderrPipe[1])

        guard result == 0 else {
            _ = close(stdoutPipe[0]); _ = close(stderrPipe[0])
            throw NSError(
                domain: NSPOSIXErrorDomain,
                code: Int(result),
                userInfo: [NSLocalizedDescriptionKey: String(cString: strerror(result))]
            )
        }

        let group = DispatchGroup()
        var stdoutData = Data()
        var stderrData = Data()

        func readAll(_ fd: Int32) -> Data {
            var data = Data()
            var buffer = [UInt8](repeating: 0, count: 16 * 1024)
            while true {
                let count = buffer.withUnsafeMutableBytes { rawBuffer -> Int in
                    guard let baseAddress = rawBuffer.baseAddress else { return 0 }
                    return read(fd, baseAddress, rawBuffer.count)
                }
                if count <= 0 { break }
                data.append(buffer, count: count)
            }
            return data
        }

        group.enter()
        DispatchQueue.global(qos: .utility).async {
            stdoutData = readAll(stdoutPipe[0])
            _ = close(stdoutPipe[0])
            group.leave()
        }

        group.enter()
        DispatchQueue.global(qos: .utility).async {
            stderrData = readAll(stderrPipe[0])
            _ = close(stderrPipe[0])
            group.leave()
        }

        var status: Int32 = 0
        _ = waitpid(pid, &status, 0)
        group.wait()

        return SantanderProcessResult(
            status: status,
            stdout: String(data: stdoutData, encoding: .utf8) ?? "",
            stderr: String(data: stderrData, encoding: .utf8) ?? ""
        )
    }
}

protocol CharacterPair {
    var leading: String { get }
    var trailing: String { get }
}

class Theme {}

struct TextViewState {
    let text: String
    let theme: AnyTheme
}

struct HighlightedRange {
    let range: NSRange
    let color: UIColor
}

struct SearchResult {
    let range: NSRange
}

struct SearchQuery {
    enum MatchMethod {
        case startsWith, endsWith, contains, fullWord, regularExpression
    }

    let text: String
    let matchMethod: MatchMethod
    let isCaseSensitive: Bool

    init(text: String, matchMethod: MatchMethod, isCaseSensitive: Bool) {
        self.text = text
        self.matchMethod = matchMethod
        self.isCaseSensitive = isCaseSensitive
    }

    func ranges(in source: String) -> [NSRange] {
        guard !text.isEmpty else { return [] }

        let nsSource = source as NSString
        let range = NSRange(location: 0, length: nsSource.length)
        let options: NSRegularExpression.Options = isCaseSensitive ? [] : [.caseInsensitive]

        if matchMethod == .regularExpression,
           let regex = try? NSRegularExpression(pattern: text, options: options) {
            return regex.matches(in: source, range: range).map(\.range)
        }

        let comparisonOptions: NSString.CompareOptions = isCaseSensitive ? [] : [.caseInsensitive]
        var result: [NSRange] = []
        var cursor = 0

        while cursor < nsSource.length {
            let found = nsSource.range(
                of: text,
                options: comparisonOptions,
                range: NSRange(location: cursor, length: nsSource.length - cursor)
            )
            guard found.location != NSNotFound else { break }

            func isBoundary(_ index: Int) -> Bool {
                if index <= 0 || index >= nsSource.length { return true }
                let left = nsSource.substring(with: NSRange(location: index - 1, length: 1))
                let right = nsSource.substring(with: NSRange(location: index, length: 1))
                let wordSet = CharacterSet.alphanumerics.union(.letters).union(.decimalDigits)
                let leftIsWord = left.rangeOfCharacter(from: wordSet) != nil
                let rightIsWord = right.rangeOfCharacter(from: wordSet) != nil
                return !(leftIsWord && rightIsWord)
            }

            let accepted: Bool
            switch matchMethod {
            case .contains:
                accepted = true
            case .startsWith:
                accepted = found.location == 0 || isBoundary(found.location)
            case .endsWith:
                accepted = NSMaxRange(found) == nsSource.length || isBoundary(NSMaxRange(found))
            case .fullWord:
                accepted = isBoundary(found.location) && isBoundary(NSMaxRange(found))
            case .regularExpression:
                accepted = true
            }

            if accepted {
                result.append(found)
            }

            cursor = max(NSMaxRange(found), cursor + 1)
        }

        return result
    }
}

final class TextView: UITextView, UITextViewDelegate {
    weak var editorDelegate: TextViewDelegate?
    var characterPairs: [CharacterPair] = []
    var showLineNumbers: Bool = false
    var isLineWrappingEnabled: Bool = true {
        didSet {
            textContainer.lineBreakMode = isLineWrappingEnabled ? .byWordWrapping : .byClipping
            textContainer.widthTracksTextView = isLineWrappingEnabled
        }
    }

    var highlightedRanges: [HighlightedRange] = [] {
        didSet { updateHighlightedRanges() }
    }

    override init(frame: CGRect, textContainer: NSTextContainer? = nil) {
        super.init(frame: frame, textContainer: textContainer)
        commonInit()
    }

    convenience init() {
        self.init(frame: .zero, textContainer: nil)
    }

    required init?(coder: NSCoder) {
        super.init(coder: coder)
        commonInit()
    }

    private func commonInit() {
        delegate = self
        font = .monospacedSystemFont(ofSize: 16, weight: .regular)
        autocorrectionType = .no
        autocapitalizationType = .none
        smartQuotesType = .no
        smartDashesType = .no
        backgroundColor = .clear
    }

    func setState(_ state: TextViewState) {
        let editable = isEditable
        isEditable = false
        text = state.text
        font = state.theme.font
        textColor = state.theme.textColor
        isEditable = editable
        textContainer.lineBreakMode = isLineWrappingEnabled ? .byWordWrapping : .byClipping
        textContainer.widthTracksTextView = isLineWrappingEnabled
        updateHighlightedRanges()
    }

    func goToLine(_ zeroBasedLine: Int) {
        let target = max(0, zeroBasedLine)
        let textString = text as NSString
        var line = 0
        var location = 0

        while line < target, location < textString.length {
            let newline = textString.range(
                of: "\n",
                options: [],
                range: NSRange(location: location, length: textString.length - location)
            )
            guard newline.location != NSNotFound else { break }
            location = NSMaxRange(newline)
            line += 1
        }

        selectedRange = NSRange(location: min(location, textString.length), length: 0)
        scrollRangeToVisible(selectedRange)
    }

    func search(for query: SearchQuery) -> [SearchResult] {
        query.ranges(in: text).map(SearchResult.init(range:))
    }

    func shiftLeft() {
        guard selectedRange.length > 0 else { return }
        let range = selectedRange
        let mutable = NSMutableString(string: text)
        mutable.replaceCharacters(in: range, with: "")
        text = mutable as String
        selectedRange = NSRange(location: range.location, length: 0)
    }

    func shiftRight() {
        guard selectedRange.length > 0 else { return }
        let range = selectedRange
        let mutable = NSMutableString(string: text)
        let selected = (text as NSString).substring(with: range)
        mutable.replaceCharacters(in: range, with: "    " + selected)
        text = mutable as String
        selectedRange = NSRange(location: range.location + 4, length: range.length)
    }

    private func updateHighlightedRanges() {
        guard !highlightedRanges.isEmpty else { return }
        let mutable = NSMutableAttributedString(string: text)
        mutable.addAttribute(.font, value: font ?? UIFont.monospacedSystemFont(ofSize: 16, weight: .regular),
                              range: NSRange(location: 0, length: mutable.length))
        for item in highlightedRanges where NSMaxRange(item.range) <= mutable.length {
            mutable.addAttribute(.backgroundColor, value: item.color, range: item.range)
        }
        let currentSelection = selectedRange
        attributedText = mutable
        selectedRange = NSRange(location: min(currentSelection.location, mutable.length), length: 0)
    }

    func textViewShouldBeginEditing(_ textView: UITextView) -> Bool {
        editorDelegate?.textViewShouldBeginEditing?(self) ?? true
    }

    func textViewShouldEndEditing(_ textView: UITextView) -> Bool {
        editorDelegate?.textViewShouldEndEditing?(self) ?? true
    }

    func textView(
        _ textView: UITextView,
        shouldChangeTextIn range: NSRange,
        replacementText text: String
    ) -> Bool {
        guard range.length == 0, text.count == 1, !characterPairs.isEmpty else {
            return true
        }

        guard let pair = characterPairs.first(where: { $0.leading == text }) else {
            return true
        }

        let insertionLocation = range.location
        let mutable = NSMutableString(string: self.text)
        mutable.insert(text + pair.trailing, at: insertionLocation)
        self.text = mutable as String
        selectedRange = NSRange(location: insertionLocation + text.utf16.count, length: 0)
        editorDelegate?.textViewDidChange(self)
        return false
    }

    func textViewDidChange(_ textView: UITextView) {
        editorDelegate?.textViewDidChange(self)
    }
}

@objc protocol TextViewDelegate: AnyObject {
    @objc optional func textViewShouldBeginEditing(_ textView: TextView) -> Bool
    @objc optional func textViewShouldEndEditing(_ textView: TextView) -> Bool
    func textViewDidChange(_ textView: TextView)
}

private enum SantanderObjCRuntime {
    static let launchServicesHandle: UnsafeMutableRawPointer? = {
        let candidates = [
            "/System/Library/PrivateFrameworks/LaunchServices.framework/LaunchServices",
            "/System/Library/PrivateFrameworks/MobileCoreServices.framework/MobileCoreServices",
            "/System/Library/Frameworks/MobileCoreServices.framework/MobileCoreServices",
            "/System/Library/Frameworks/CoreServices.framework/CoreServices"
        ]

        for path in candidates where FileManager.default.fileExists(atPath: path) {
            if let handle = dlopen(path, RTLD_LAZY) {
                return handle
            }
        }
        return nil
    }()

    static func sendObject(
        to receiver: AnyObject,
        selector: Selector,
        argument: AnyObject? = nil
    ) -> AnyObject? {
        _ = launchServicesHandle
        guard let method = object_getClass(receiver).flatMap({ class_getInstanceMethod($0, selector) }) else {
            return nil
        }

        typealias Message = @convention(c) (AnyObject, Selector, AnyObject?) -> Unmanaged<AnyObject>?
        let function = unsafeBitCast(method_getImplementation(method), to: Message.self)
        return function(receiver, selector, argument)?.takeUnretainedValue()
    }

    static func sendObject(
        to receiver: AnyObject,
        selector: Selector
    ) -> AnyObject? {
        _ = launchServicesHandle
        guard let method = object_getClass(receiver).flatMap({ class_getInstanceMethod($0, selector) }) else {
            return nil
        }

        typealias Message = @convention(c) (AnyObject, Selector) -> Unmanaged<AnyObject>?
        let function = unsafeBitCast(method_getImplementation(method), to: Message.self)
        return function(receiver, selector)?.takeUnretainedValue()
    }

    static func sendObject(
        to receiver: AnyObject,
        selector: Selector,
        intArgument: Int32
    ) -> AnyObject? {
        _ = launchServicesHandle
        guard let method = object_getClass(receiver).flatMap({ class_getInstanceMethod($0, selector) }) else {
            return nil
        }

        typealias Message = @convention(c) (AnyObject, Selector, Int32) -> Unmanaged<AnyObject>?
        let function = unsafeBitCast(method_getImplementation(method), to: Message.self)
        return function(receiver, selector, intArgument)?.takeUnretainedValue()
    }

    static func sendBool(
        to receiver: AnyObject,
        selector: Selector,
        argument: AnyObject?
    ) -> Bool? {
        _ = launchServicesHandle
        guard let method = object_getClass(receiver).flatMap({ class_getInstanceMethod($0, selector) }) else {
            return nil
        }

        typealias Message = @convention(c) (AnyObject, Selector, AnyObject?) -> Bool
        let function = unsafeBitCast(method_getImplementation(method), to: Message.self)
        return function(receiver, selector, argument)
    }

    static func sendBool(
        to receiver: AnyObject,
        selector: Selector,
        firstArgument: AnyObject?,
        secondArgument: AnyObject?
    ) -> Bool? {
        _ = launchServicesHandle
        guard let method = object_getClass(receiver).flatMap({ class_getInstanceMethod($0, selector) }) else {
            return nil
        }

        typealias Message = @convention(c) (AnyObject, Selector, AnyObject?, AnyObject?) -> Bool
        let function = unsafeBitCast(method_getImplementation(method), to: Message.self)
        return function(receiver, selector, firstArgument, secondArgument)
    }
}

final class SantanderApplication {
    fileprivate let object: AnyObject

    init?(object: AnyObject) {
        guard object_isClass(object) == false else { return nil }
        self.object = object
    }

    var applicationIdentifier: String {
        stringValue(for: "applicationIdentifier") ?? stringValue(for: "bundleIdentifier") ?? ""
    }

    var localizedName: String {
        stringValue(for: "localizedName")
            ?? (SantanderObjCRuntime.sendObject(
                to: object,
                selector: Selector(("localizedNameForContext:")),
                argument: nil
            ) as? String)
            ?? applicationIdentifier
    }

    var applicationType: String? { stringValue(for: "applicationType") }
    var sdkVersion: String? { stringValue(for: "sdkVersion") }
    var teamID: String? { stringValue(for: "teamID") }

    var claimedURLSchemes: [String] {
        let selector = Selector(("claimedURLSchemes"))
        guard let value = SantanderObjCRuntime.sendObject(to: object, selector: selector) else {
            return []
        }

        if let array = value as? [String] { return array }
        if let set = value as? Set<String> { return Array(set) }
        if let nsArray = value as? NSArray { return nsArray.compactMap { $0 as? String } }
        if let nsSet = value as? NSSet { return nsSet.allObjects.compactMap { $0 as? String } }
        return []
    }

    var isDeletable: Bool { boolValue(for: "isDeletable") }
    var isBetaApp: Bool { boolValue(for: "isBetaApp") }
    var isRestricted: Bool { boolValue(for: "isRestricted") }
    var isContainerized: Bool { boolValue(for: "isContainerized") }

    func bundleURL() -> URL {
        urlValue(for: "bundleURL") ?? URL(fileURLWithPath: "")
    }

    func containerURL() -> URL {
        urlValue(for: "containerURL") ?? URL(fileURLWithPath: "")
    }

    func dataContainerURL() -> URL {
        urlValue(for: "dataContainerURL") ?? URL(fileURLWithPath: "")
    }

    var entitlements: [String: Any] {
        let selectorNames = ["entitlements", "_entitlements"]
        for name in selectorNames {
            guard let value = SantanderObjCRuntime.sendObject(to: object, selector: Selector((name))) else {
                continue
            }
            if let dictionary = value as? [String: Any] { return dictionary }
            if let dictionary = value as? NSDictionary {
                return dictionary.reduce(into: [String: Any]()) { partialResult, element in
                    if let key = element.key as? String { partialResult[key] = element.value }
                }
            }
        }
        return [:]
    }

    private func stringValue(for selectorName: String) -> String? {
        SantanderObjCRuntime.sendObject(to: object, selector: Selector((selectorName))) as? String
    }

    private func urlValue(for selectorName: String) -> URL? {
        guard let value = SantanderObjCRuntime.sendObject(to: object, selector: Selector((selectorName))) else {
            return nil
        }
        if let url = value as? URL { return url }
        if let url = value as? NSURL { return url as URL }
        return nil
    }

    private func boolValue(for selectorName: String) -> Bool {
        guard let method = object_getClass(object).flatMap({ class_getInstanceMethod($0, Selector((selectorName))) }) else {
            return false
        }
        typealias Message = @convention(c) (AnyObject, Selector) -> Bool
        let function = unsafeBitCast(method_getImplementation(method), to: Message.self)
        return function(object, Selector((selectorName)))
    }
}

private final class ApplicationsManager {
    static let shared = ApplicationsManager()

    private let cacheLock = NSLock()
    private var applicationsCache: [SantanderApplication] = []
    private var applicationsCacheDate = Date.distantPast
    private let cacheLifetime: TimeInterval = 2.0

    private init() {}

    func application(forBundleURL url: URL) -> SantanderApplication? {
        let proxyClass = NSClassFromString("LSApplicationProxy") as AnyObject?
        if let proxyClass,
           let object = SantanderObjCRuntime.sendObject(
                to: proxyClass,
                selector: Selector(("applicationProxyForBundleURL:")),
                argument: url as NSURL
           ),
           let app = SantanderApplication(object: object) {
            return app
        }

        return findApplication { Self.normalizedPath($0.bundleURL()) == Self.normalizedPath(url) }
    }

    func application(forContainerURL url: URL) -> SantanderApplication? {
        findApplication { Self.normalizedPath($0.containerURL()) == Self.normalizedPath(url) }
    }

    func application(forDataContainerURL url: URL) -> SantanderApplication? {
        findApplication { Self.normalizedPath($0.dataContainerURL()) == Self.normalizedPath(url) }
    }

    func icon(forApplication app: SantanderApplication) -> UIImage? {
        let selector = Selector(("iconDataForVariant:"))
        for variant in [2, 1, 0] {
            guard let dataObject = SantanderObjCRuntime.sendObject(
                to: app.object,
                selector: selector,
                intArgument: Int32(variant)
            ),
            let data = dataObject as? NSData,
            let image = UIImage(data: data as Data) else {
                continue
            }
            return image
        }
        return nil
    }

    func openApp(_ app: SantanderApplication) throws {
        guard let workspace = defaultWorkspace() else {
            throw Self.error("LSApplicationWorkspace is unavailable")
        }

        let selector = Selector(("openApplicationWithBundleID:"))
        guard let result = SantanderObjCRuntime.sendBool(
            to: workspace,
            selector: selector,
            argument: app.applicationIdentifier as NSString
        ) else {
            throw Self.error("LaunchServices does not expose openApplicationWithBundleID:")
        }
        guard result else {
            throw Self.error("LaunchServices failed to open \(app.applicationIdentifier)")
        }
    }

    func deleteApp(_ app: SantanderApplication) throws {
        guard let workspace = defaultWorkspace() else {
            throw Self.error("LSApplicationWorkspace is unavailable")
        }

        let selector = Selector(("uninstallApplication:withOptions:"))
        guard let result = SantanderObjCRuntime.sendBool(
            to: workspace,
            selector: selector,
            firstArgument: app.applicationIdentifier as NSString,
            secondArgument: nil
        ) else {
            throw Self.error("LaunchServices does not expose uninstallApplication:withOptions:")
        }
        guard result else {
            throw Self.error("LaunchServices failed to delete \(app.applicationIdentifier)")
        }
        invalidateCache()
    }

    func reload() {
        invalidateCache()
    }

    private func defaultWorkspace() -> AnyObject? {
        guard let workspaceClass = NSClassFromString("LSApplicationWorkspace") as AnyObject? else {
            return nil
        }
        return SantanderObjCRuntime.sendObject(to: workspaceClass, selector: Selector(("defaultWorkspace")))
    }

    private func allInstalledApplications() -> [SantanderApplication] {
        cacheLock.lock()
        let cached = applicationsCache
        let age = Date().timeIntervalSince(applicationsCacheDate)
        cacheLock.unlock()

        if !cached.isEmpty, age < cacheLifetime {
            return cached
        }

        guard let workspace = defaultWorkspace() else {
            return cached
        }

        let raw = SantanderObjCRuntime.sendObject(to: workspace, selector: Selector(("allInstalledApplications")))
            ?? SantanderObjCRuntime.sendObject(to: workspace, selector: Selector(("allApplications")))
        let rawObjects = (raw as? NSArray)?.compactMap { $0 as AnyObject } ?? []
        let applications = rawObjects.compactMap(SantanderApplication.init(object:))

        cacheLock.lock()
        applicationsCache = applications
        applicationsCacheDate = Date()
        cacheLock.unlock()
        return applications
    }

    private func findApplication(where predicate: (SantanderApplication) -> Bool) -> SantanderApplication? {
        allInstalledApplications().first(where: predicate)
    }

    private func invalidateCache() {
        cacheLock.lock()
        applicationsCache.removeAll(keepingCapacity: true)
        applicationsCacheDate = .distantPast
        cacheLock.unlock()
    }

    private static func normalizedPath(_ url: URL) -> String {
        url.standardizedFileURL.resolvingSymlinksInPath().path
    }

    private static func error(_ message: String) -> NSError {
        NSError(
            domain: "Santander.Applications",
            code: -1,
            userInfo: [NSLocalizedDescriptionKey: message]
        )
    }
}

private enum SantanderL10n {
    /// Santander's UI is intentionally presented in Simplified Chinese.
    /// A persisted value is still honored so a future language selector can reuse this layer.
    static var language: String {
        if let value = UserDefaults.standard.string(forKey: "SantanderLanguage") {
            return value
        }
        return "zh-Hans"
    }

    static func setLanguage(_ value: String) {
        UserDefaults.standard.set(value, forKey: "SantanderLanguage")
    }

    static func t(_ value: String) -> String {
        guard language.hasPrefix("zh") else { return value }
        if let exact = table[value] {
            return exact
        }

        // Dynamic messages used throughout the app.
        let dynamicPrefixes: [(String, String)] = [
        "Subdirectories": "子目录",
        "New": "新建",
        "Enter a valid executable and arguments.": "请输入有效的可执行文件和参数。",
        "Failed to open item": "打开项目失败",
        "Select font..": "选择字体…",
        "Save Image": "保存图片",
        "No Preview.": "无预览。",
        "No Results": "无结果",
        "Input is empty": "输入为空",
        "Scale": "缩放",
        "Lookup Name": "查找名称",
        "Rendition Name": "资源名称",
        "Height": "高度",
        "Width": "宽度",
        "Idiom": "设备类型",
        "Display Gamut": "显示色域",
        "ColorSpace": "色彩空间",
        "Red": "红",
        "Blue": "蓝",
        "Green": "绿",
        "Unknown Artist": "未知艺术家",
        "Default Configuration": "默认配置",
        "Moving to..": "移动到…",
        "Copying to..": "复制到…",
        "Importing to..": "导入到…",
        "Aliasing to..": "创建别名到…",
        "Add": "添加",
        "Add Key": "添加键",
        "Add Value": "添加值",
        "Cancel": "取消",
        "Close": "关闭",
        "Save": "保存",
        "Done": "完成",
        "Edit": "编辑",
        "Delete": "删除",
        "Remove": "移除",
        "Rename": "重命名",
        "Copy": "复制",
        "Move": "移动",
        "Duplicate": "复制副本",
        "Paste": "粘贴",
        "Select": "选择",
        "Select All": "全选",
        "Deselect All": "取消全选",
        "Open": "打开",
        "Share": "分享",
        "Search": "搜索",
        "Info": "信息",
        "Path Info": "路径信息",
        "Permissions": "权限",
        "Owner": "所有者",
        "Group": "群组",
        "Other": "其他",
        "Other users": "其他用户",
        "Read": "读取",
        "Write": "写入",
        "Execute": "执行",
        "Root": "根目录",
        "Mount": "挂载",
        "Unmount": "卸载",
        "Symbolic Link": "符号链接",
        "Create Symbolic Link": "创建符号链接",
        "Compress": "压缩",
        "Decompress": "解压",
        "Archive": "归档",
        "File": "文件",
        "Folder": "文件夹",
        "Directory": "文件夹",
        "String": "String",
        "Integer": "Integer",
        "Real": "Real",
        "Boolean": "Boolean",
        "Float": "Float",
        "Date": "Date",
        "Data": "Data",
        "Array": "Array",
        "Dictionary": "Dictionary",
        "Key": "Key",
        "Value": "Value",
        "Property List Viewer": "属性列表查看器",
        "Property List Editor": "属性列表编辑器",
        "Text Editor": "文本编辑器",
        "Text Editor Settings": "文本编辑器设置",
        "Image Viewer": "图片查看器",
        "Audio Player": "音频播放器",
        "Video Player": "视频播放器",
        "Font Viewer": "字体查看器",
        "QuickLook": "快速查看",
        "Settings": "设置",
        "General": "通用",
        "Appearance": "外观",
        "Light": "浅色",
        "Dark": "深色",
        "Default": "默认",
        "Applications": "应用程序",
        "Documents": "文稿",
        "Downloads": "下载",
        "Library": "资源库",
        "Home": "主目录",
        "System": "系统",
        "Contents": "内容",
        "Items": "项目",
        "Name": "名称",
        "Size": "大小",
        "Modified": "修改时间",
        "Created": "创建时间",
        "Added": "添加时间",
        "Accessed": "访问时间",
        "Date modified": "修改日期",
        "Date created": "创建日期",
        "Executable": "可执行文件",
        "Entitlements": "权限声明",
        "Bundle ID": "Bundle ID",
        "App Info": "应用信息",
        "App name": "应用名称",
        "Invalid Data": "数据无效",
        "Not implemented": "尚未实现",
        "Root Helper": "Root 助手",
        "Enabled": "已启用",
        "Disabled": "已停用",
        "Ascending": "升序",
        "Descending": "降序",
        "Alphabetical order": "按名称排序",
        "Grouped": "分组",
        "Plain": "普通",
        "Programming": "编程",
        "Font size": "字体大小",
        "Go to line": "跳转到行",
        "Search Method": "搜索方式",
        "Case Sensitive": "区分大小写",
        "Full Word": "完整单词",
        "Regex": "正则表达式",
        "Starts With": "开头匹配",
        "Ends With": "结尾匹配",
        "Contains": "包含",
        "Display hidden files": "显示隐藏文件",
        "Always show search bar": "始终显示搜索栏",
        "Show information button": "显示信息按钮",
        "Large navigation titles": "使用大号导航标题",
        "Create": "创建",
        "New Group": "新建群组",
        "Duplicate Key": "键重复",
        "Remove bookmark": "移除书签",
        "Bookmarks": "书签",
        "Scroll Up": "向上滚动",
        "Scroll Down": "向下滚动",
        "Copy Path": "复制路径",
        "View item": "查看项目",
        "Copy name": "复制名称",
        "Copy path": "复制路径",
        "Sort by..": "排序方式",
        "New..": "新建",
        "Other..": "其他…",
        "Go to..": "前往…",
        "Move to..": "移动到…",
        "Copy to..": "复制到…",
        "Create symbolic link to..": "创建符号链接到…",
        "Open App": "打开应用",
        "Open in..": "打开方式…",
        "Add to group..": "添加到群组…",
        "Decompressing..": "正在解压…",
        "Compressing..": "正在压缩…",
        "Extract to..": "提取到…",
        "Extracting..": "正在提取…",
        "Layout": "布局",
        "Horizontal": "横向",
        "Vertical": "纵向",
        "Copy Image": "复制图片",
        "Set as wallpaper for..": "设置为墙纸…",
        "Lock Screen": "锁定屏幕",
        "Home Screen": "主屏幕",
        "Home Screen & Lock Screen": "主屏幕与锁定屏幕",
        "Backward / Forward duration": "后退/前进时长",
        "Speed": "播放速度",
        "Zoom in": "放大",
        "Zoom out": "缩小",
        "Dismiss": "关闭",
        "View": "查看",
        "Path": "路径",
        "Launch Path": "启动路径",
        "Custom Launch Path": "自定义启动路径",
        "Last Opened Path": "上次打开的路径",
        "Table View Style": "列表样式",
        "Tint Color": "强调色",
        "Views": "界面",
        "Theming": "主题",
        "Types": "类型",
        "Generic": "通用",
        "Audio": "音频",
        "Document": "文稿",
        "Date Metadata": "日期元数据",
        "Full name": "全名",
        "Family name": "系列名称",
        "PostScript name": "PostScript 名称",
        "Style": "样式",
        "URL": "URL",
        "Designer": "设计者",
        "Manufacturer": "制造商",
        "Version": "版本",
        "Pixel Height": "像素高度",
        "Pixel Width": "像素宽度",
        "Camera Model": "相机型号",
        "Camera Manufacturer": "相机制造商",
        "Camera Software": "相机软件",
        "Lens Model": "镜头型号",
        "Lens Manufacturer": "镜头制造商",
        "Latitude": "纬度",
        "Longitude": "经度",
        "Font": "字体",
        "Text Color": "文本颜色",
        "Editor Background Color": "编辑器背景色",
        "Fonts": "字体",
        "Lines": "行",
        "Colors": "颜色",
        "Show Line Count": "显示行数",
        "Wrap Lines": "自动换行",
        "Use Character Pairs": "使用字符配对",
        "SDK Version": "SDK 版本",
        "URL schemes": "URL 方案",
        "Team ID": "团队 ID",
        "Deletable": "可删除",
        "Beta app": "测试版应用",
        "Restricted": "受限",
        "Containerized": "已容器化",
        "Container URL": "容器路径",
        "Bundle URL": "Bundle 路径",
        "Display name": "显示名称",
        "MIME Type": "MIME 类型",
        "Alias": "别名",
        "ID": "ID",
        "Set": "设置",
        "Invalid ID": "ID 无效",
        "ID range": "UID/GID 范围：-2…501",
        "Unknown Type": "未知类型",
        "Removed": "已移除",
        "Unknown Mode": "未知模式",
        "SRGB": "sRGB",
        "Display P3": "Display P3",
        "Universal": "通用",
        "CarPlay": "CarPlay",
        "Marketing": "营销",
        "Mac Catalyst": "Mac Catalyst",
        "Any": "任意",
        "High Contrast": "高对比度",
        "High Contrast Dark": "高对比度深色",
        "High Contrast Light": "高对比度浅色",
        "Image": "图像",
        "Icon": "图标",
        "Image Set": "图像集",
        "Multisize Image Set": "多尺寸图像集",
        "PDF": "PDF",
        "Color": "颜色",
        "SVG (Vector)": "SVG（矢量）",
        "Raw Data": "原始数据",
        "Unknown": "未知",
        "Zip": "ZIP",
        "Tar": "TAR",
        "Are you sure you want to delete this item?": "确定要删除此项目吗？",
        "Unable to delete app": "无法删除应用",
        "Unable to open app": "无法打开应用",
        "Unable to save image": "无法保存图片",
        "无法设置壁纸": "无法将图片设置为墙纸",
        "Failed to edit item": "编辑项目失败",
        "Unable to update items": "无法更新项目",
        "Unable to edit item": "无法编辑项目",
        "Failed to delete item": "删除项目失败",
        "Unable to write to file": "无法写入文件",
        "Unable to save to file": "无法保存文件",
        "Unsaved changes": "未保存的更改",
        "Can't write to Property List file": "无法写入属性列表文件",
        "Unable to launch process": "无法启动进程",
        "Remove image location?": "移除图片位置？",
        "Failed to display image.": "无法显示图片。",
        "The key already exists.": "键已存在。",
        "Hex data must contain an even number of characters.": "十六进制数据必须包含偶数个字符。",
        "The data contains an invalid hexadecimal byte.": "数据包含无效的十六进制字节。",
        "Unable to set date of image": "无法设置图片日期",
        "Unable to set location of image": "无法设置图片位置",
        "无法删除项目": "无法移除项目",
        "Failed to import file": "导入文件失败",
        "Failed to copy item": "复制项目失败",
        "Failed to delete item and update contents of file": "删除项目并更新文件内容失败",
        "Unable to extract items": "无法提取项目",
        "无法读取属性列表格式。": "无法获取属性列表格式",
        "Unknown Error": "未知错误",
        "Unable to authenticate": "无法进行身份验证",
        "Unable to set path as Launch Path": "无法将路径设置为启动路径",
        "Path must be a directory": "路径必须是目录",
        "Input text is invalid or empty": "输入文本无效或为空",
        "Enter the other path you want to be opened at launch": "请输入启动时要打开的其他路径",
        "URL(s) being imported to app, would you like to copy it to another path?": "正在向应用导入 URL，是否要将其复制到其他路径？",
        "Enter the destination directory.": "请输入目标目录。",
        "Enter an empty or existing mount point.": "请输入空的或现有的挂载点。",
        "No path to paste.": "没有可粘贴的路径。",
        "Failed to copy item to current directory.": "复制项目到当前目录失败。",
        "Group with same name already exists": "同名群组已存在",
        "The ID must be between -2 and 501.": "ID 必须介于 -2 和 501 之间。",
        "Root helper returned non-zero status, error: \\(ret.standardError)": "Root 助手返回错误：\\(ret.standardError)",
        "Root helper failed with status \\(result.status)": "Root 助手失败，状态码：\\(result.status)",
        "Unable to configure helper pipes: \\(String(cString: strerror(errno)))": "无法配置 Root 助手管道：\\(String(cString: strerror(errno)))",
        "Unable to attach process output pipe.": "无法连接进程输出管道。",
        "Unable to create stdout pipe.": "无法创建标准输出管道。",
        "Unable to create stderr pipe.": "无法创建标准错误管道。",
        "Unable to initialize process actions.": "无法初始化进程操作。",
        "Executable URL is missing.": "缺少可执行文件路径。",
        "Asset catalog does not exist: \\(url.path)": "资源目录不存在：\\(url.path)",
        "CoreUI CUICatalog is unavailable on this OS.": "当前系统无法使用 CoreUI 资源目录。",
        "CoreUI asset writing is unavailable on this iOS version.": "此 iOS 版本不支持 CoreUI 资源写入。",
        "CoreUI failed to save the asset catalog.": "CoreUI 保存资源目录失败。",
        "CoreUI storage does not expose a writable catalog method.": "CoreUI 存储未提供可写入资源目录的方法。",
        "No input paths were supplied.": "未提供输入路径。",
        "Compression format must be zip or tar": "压缩格式必须是 zip 或 tar",
        "Unable to write item data to file: \\(error.localizedDescription)": "无法将项目数据写入文件：\\(error.localizedDescription)",
        "Permission Denied.": "没有权限。",
        "Please enter a name.": "请输入名称。",
        "file": "文件",
        "directory": "文件夹",
        "name": "名称",
        "Group name..": "群组名称…",
        "Custom Path": "自定义路径",
        "List recently used items in application shortcuts": "在应用快捷方式中列出最近使用项目",
        "Hello": "你好",
        "The quick brown fox jumps over the lazy dog and runs away.": "敏捷的棕色狐狸跳过懒狗，然后跑开了。",
        "OK": "好",
        "Error occurred: ": "发生错误：",
        "Inset Grouped": "内嵌分组",
        "N/A": "不可用",
        "Camera": "相机",
        "Lens": "镜头",
        "Location": "位置",
        "TextEditorShowLineCount": "显示行数",
        "TextEditorWrapLines": "自动换行",
        "TextEditorUseCharacterPairs": "使用字符配对",
        "Type": "类型",
        "Locked": "锁定文件",
        "Date Label": "日期",
        "Position in array": "数组中的位置",
        "Value (in base64)": "值（base64）",
        "Change type": "更改类型",
        "JSON Viewer": "JSON 查看器",
        "Asset Catalog Viewer": "资源目录查看器",
        "Executable Runner": "可执行文件运行器",
        "iPhone": "iPhone",
        "iPad": "iPad",
        "TV": "电视",
        "Watch": "Apple Watch",
        "无法创建符号链接": "无法创建符号链接",
        "move": "移动",
        "copy": "复制",
        "import": "导入",
        "symlink": "符号链接",
        "Root Helper unavailable? is your install messed up?": "Root 助手不可用，请检查安装是否完整。",
        "Unable to read root helper output": "无法读取 Root 助手输出",
        "Failed to spawn root helper": "无法启动 Root 助手",
        "Bookmark": "添加书签",
        "点击选择类型": "点击选择类型",
        "Unnamed Asset": "未命名资源",
        "Readable": "可读",
        "Writable": "可写",
        ]
        for (prefix, translatedPrefix) in dynamicPrefixes where value.hasPrefix(prefix) {
            return translatedPrefix + String(value.dropFirst(prefix.count)).trimmingCharacters(in: .whitespaces)
        }

        if value.hasPrefix("Can't ") {
            var suffix = String(value.dropFirst("Can't ".count))
            suffix = suffix.replacingOccurrences(of: " path", with: "路径")
            return "无法" + suffix
        }

        if value.hasPrefix("Unable to ") {
            var suffix = String(value.dropFirst("Unable to ".count))
            suffix = suffix.replacingOccurrences(of: " items", with: "项目")
            suffix = suffix.replacingOccurrences(of: " file(s)", with: "文件")
            return "无法" + suffix
        }
        return value
    }

    private static let table: [String: String] = [
        "Subdirectories": "子目录",
        "New": "新建",
        "Enter a valid executable and arguments.": "请输入有效的可执行文件和参数。",
        "Failed to open item": "打开项目失败",
        "Scale": "缩放",
        "Height": "高度",
        "Width": "宽度",
        "Idiom": "设备类型",
        "ColorSpace": "色彩空间",
        "Red": "红",
        "Blue": "蓝",
        "Green": "绿",
        "Default Configuration": "默认配置",
        "Moving to..": "移动到…",
        "Copying to..": "复制到…",
        "Importing to..": "导入到…",
        "Aliasing to..": "创建别名到…",

        "Add": "添加",
        "Add Key": "添加键",
        "Add Value": "添加值",
        "Close": "关闭",
        "Save": "保存",
        "Done": "完成",
        "Edit": "编辑",
        "Delete": "删除",
        "Remove": "移除",
        "Rename": "重命名",
        "Copy": "复制",
        "Move": "移动",
        "Duplicate": "复制副本",
        "Paste": "粘贴",
        "Select": "选择",
        "Open": "打开",
        "Share": "分享",
        "Search": "搜索",
        "Info": "信息",
        "Path Info": "路径信息",
        "Permissions": "权限",
        "Owner": "所有者",
        "Group": "群组",
        "Other": "其他",
        "Other users": "其他用户",
        "Read": "读取",
        "Write": "写入",
        "Execute": "执行",
        "Root": "根目录",
        "Mount": "挂载",
        "Unmount": "卸载",
        "Create Symbolic Link": "创建符号链接",
        "Compress": "压缩",
        "Decompress": "解压",
        "Archive": "归档",
        "Folder": "文件夹",
        "String": "String",
        "Integer": "Integer",
        "Real": "Real",
        "Boolean": "Boolean",
        "Float": "Float",
        "Date": "Date",
        "Data": "Data",
        "Array": "Array",
        "Dictionary": "Dictionary",
        "Key": "Key",
        "Value": "Value",
        "Property List Viewer": "属性列表查看器",
        "Property List Editor": "属性列表编辑器",
        "Text Editor": "文本编辑器",
        "Text Editor Settings": "文本编辑器设置",
        "Image Viewer": "图片查看器",
        "Audio Player": "音频播放器",
        "Video Player": "视频播放器",
        "Font Viewer": "字体查看器",
        "QuickLook": "快速查看",
        "Settings": "设置",
        "General": "通用",
        "Appearance": "外观",
        "Light": "浅色",
        "Dark": "深色",
        "Default": "默认",
        "Applications": "应用程序",
        "Documents": "文稿",
        "Downloads": "下载",
        "Library": "资源库",
        "Home": "主目录",
        "System": "系统",
        "Contents": "内容",
        "Items": "项目",
        "Name": "名称",
        "Size": "大小",
        "Modified": "修改时间",
        "Created": "创建时间",
        "Added": "添加时间",
        "Accessed": "访问时间",
        "Date modified": "修改日期",
        "Date created": "创建日期",
        "Entitlements": "权限声明",
        "Bundle ID": "Bundle ID",
        "App Info": "应用信息",
        "App name": "应用名称",
        "Input is empty": "输入为空",
        "Invalid Data": "数据无效",
        "Not implemented": "尚未实现",
        "Root Helper": "Root 助手",
        "Enabled": "已启用",
        "Disabled": "已停用",
        "Ascending": "升序",
        "Descending": "降序",
        "Alphabetical order": "按名称排序",
        "Grouped": "分组",
        "Plain": "普通",
        "Programming": "编程",
        "Font size": "字体大小",
        "Go to line": "跳转到行",
        "Search Method": "搜索方式",
        "Case Sensitive": "区分大小写",
        "Full Word": "完整单词",
        "Regex": "正则表达式",
        "Starts With": "开头匹配",
        "Ends With": "结尾匹配",
        "Contains": "包含",
        "Display hidden files": "显示隐藏文件",
        "Always show search bar": "始终显示搜索栏",
        "Show information button": "显示信息按钮",
        "Large navigation titles": "使用大号导航标题",
        "Create": "创建",
        "New Group": "新建群组",
        "Bookmarks": "书签",
        "Scroll Up": "向上滚动",
        "Scroll Down": "向下滚动",
        "Copy Path": "复制路径",
        "View item": "查看项目",
        "Copy name": "复制名称",
        "Copy path": "复制路径",
        "Sort by..": "排序方式",
        "New..": "新建",
        "Other..": "其他…",
        "Go to..": "前往…",
        "Move to..": "移动到…",
        "Copy to..": "复制到…",
        "Create symbolic link to..": "创建符号链接到…",
        "Open App": "打开应用",
        "Open in..": "打开方式…",
        "Add to group..": "添加到群组…",
        "Decompressing..": "正在解压…",
        "Compressing..": "正在压缩…",
        "Extract to..": "提取到…",
        "Extracting..": "正在提取…",
        "Layout": "布局",
        "Horizontal": "横向",
        "Vertical": "纵向",
        "Copy Image": "复制图片",
        "Save Image": "保存图片",
        "Set as wallpaper for..": "设置为墙纸…",
        "Lock Screen": "锁定屏幕",
        "Home Screen": "主屏幕",
        "Home Screen & Lock Screen": "主屏幕与锁定屏幕",
        "Backward / Forward duration": "后退/前进时长",
        "Speed": "播放速度",
        "Zoom in": "放大",
        "Zoom out": "缩小",
        "Dismiss": "关闭",
        "View": "查看",
        "Path": "路径",
        "Launch Path": "启动路径",
        "Custom Launch Path": "自定义启动路径",
        "Last Opened Path": "上次打开的路径",
        "Table View Style": "列表样式",
        "Tint Color": "强调色",
        "Views": "界面",
        "Theming": "主题",
        "Types": "类型",
        "Generic": "通用",
        "Audio": "音频",
        "Document": "文稿",
        "Date Metadata": "日期元数据",
        "Style": "样式",
        "URL": "URL",
        "Designer": "设计者",
        "Manufacturer": "制造商",
        "Version": "版本",
        "Latitude": "纬度",
        "Longitude": "经度",
        "Font": "字体",
        "Text Color": "文本颜色",
        "Editor Background Color": "编辑器背景色",
        "Fonts": "字体",
        "Lines": "行",
        "Colors": "颜色",
        "Show Line Count": "显示行数",
        "Wrap Lines": "自动换行",
        "Use Character Pairs": "使用字符配对",
        "SDK Version": "SDK 版本",
        "URL schemes": "URL 方案",
        "Team ID": "团队 ID",
        "Deletable": "可删除",
        "Beta app": "测试版应用",
        "Restricted": "受限",
        "Containerized": "已容器化",
        "Container URL": "容器路径",
        "Bundle URL": "Bundle 路径",
        "Display name": "显示名称",
        "MIME Type": "MIME 类型",
        "Alias": "别名",
        "ID": "ID",
        "Set": "设置",
        "Invalid ID": "ID 无效",
        "ID range": "UID/GID 范围：-2…501",
        "Unknown Type": "未知类型",
        "Removed": "已移除",
        "Unknown Mode": "未知模式",
        "SRGB": "sRGB",
        "Display P3": "Display P3",
        "Universal": "通用",
        "CarPlay": "CarPlay",
        "Marketing": "营销",
        "Mac Catalyst": "Mac Catalyst",
        "Any": "任意",
        "High Contrast": "高对比度",
        "High Contrast Dark": "高对比度深色",
        "High Contrast Light": "高对比度浅色",
        "Image": "图像",
        "Icon": "图标",
        "Image Set": "图像集",
        "Multisize Image Set": "多尺寸图像集",
        "PDF": "PDF",
        "Color": "颜色",
        "SVG (Vector)": "SVG（矢量）",
        "Raw Data": "原始数据",
        "Unknown": "未知",
        "Zip": "ZIP",
        "Tar": "TAR",
        "Are you sure you want to delete this item?": "确定要删除此项目吗？",
        "Unable to delete app": "无法删除应用",
        "Unable to open app": "无法打开应用",
        "Unable to save image": "无法保存图片",
        "无法设置壁纸": "无法将图片设置为墙纸",
        "Failed to edit item": "编辑项目失败",
        "Unable to update items": "无法更新项目",
        "Unable to edit item": "无法编辑项目",
        "Failed to delete item": "删除项目失败",
        "Unable to write to file": "无法写入文件",
        "Unable to save to file": "无法保存文件",
        "Unsaved changes": "未保存的更改",
        "Can't write to Property List file": "无法写入属性列表文件",
        "Unable to launch process": "无法启动进程",
        "Remove image location?": "移除图片位置？",
        "Failed to display image.": "无法显示图片。",
        "The key already exists.": "键已存在。",
        "Hex data must contain an even number of characters.": "十六进制数据必须包含偶数个字符。",
        "The data contains an invalid hexadecimal byte.": "数据包含无效的十六进制字节。",
        "Unable to set date of image": "无法设置图片日期",
        "Unable to set location of image": "无法设置图片位置",
        "无法删除项目": "无法移除项目",
        "Failed to import file": "导入文件失败",
        "Failed to copy item": "复制项目失败",
        "Failed to delete item and update contents of file": "删除项目并更新文件内容失败",
        "Unable to extract items": "无法提取项目",
        "无法读取属性列表格式。": "无法获取属性列表格式",
        "Unable to authenticate": "无法进行身份验证",
        "Unable to set path as Launch Path": "无法将路径设置为启动路径",
        "Enter the other path you want to be opened at launch": "请输入启动时要打开的其他路径",
        "URL(s) being imported to app, would you like to copy it to another path?": "正在向应用导入 URL，是否要将其复制到其他路径？",
        "Enter the destination directory.": "请输入目标目录。",
        "Enter an empty or existing mount point.": "请输入空的或现有的挂载点。",
        "No path to paste.": "没有可粘贴的路径。",
        "Failed to copy item to current directory.": "复制项目到当前目录失败。",
        "Group with same name already exists": "同名群组已存在",
        "The ID must be between -2 and 501.": "ID 必须介于 -2 和 501 之间。",
        "Root helper returned non-zero status, error: \\(ret.standardError)": "Root 助手返回错误：\\(ret.standardError)",
        "Root helper failed with status \\(result.status)": "Root 助手失败，状态码：\\(result.status)",
        "Unable to configure helper pipes: \\(String(cString: strerror(errno)))": "无法配置 Root 助手管道：\\(String(cString: strerror(errno)))",
        "Unable to attach process output pipe.": "无法连接进程输出管道。",
        "Unable to create stdout pipe.": "无法创建标准输出管道。",
        "Unable to create stderr pipe.": "无法创建标准错误管道。",
        "Unable to initialize process actions.": "无法初始化进程操作。",
        "Executable URL is missing.": "缺少可执行文件路径。",
        "Asset catalog does not exist: \\(url.path)": "资源目录不存在：\\(url.path)",
        "CoreUI CUICatalog is unavailable on this OS.": "当前系统无法使用 CoreUI 资源目录。",
        "CoreUI asset writing is unavailable on this iOS version.": "此 iOS 版本不支持 CoreUI 资源写入。",
        "CoreUI failed to save the asset catalog.": "CoreUI 保存资源目录失败。",
        "CoreUI storage does not expose a writable catalog method.": "CoreUI 存储未提供可写入资源目录的方法。",
        "No input paths were supplied.": "未提供输入路径。",
        "Compression format must be zip or tar": "压缩格式必须是 zip 或 tar",
        "Unable to write item data to file: \\(error.localizedDescription)": "无法将项目数据写入文件：\\(error.localizedDescription)",
        "Permission Denied.": "没有权限。",
        "Please enter a name.": "请输入名称。",
        "file": "文件",
        "directory": "文件夹",
        "name": "名称",
        "Group name..": "群组名称…",
        "Custom Path": "自定义路径",
        "List recently used items in application shortcuts": "在应用快捷方式中列出最近使用项目",
        "No Preview.": "无预览。",
        "Hello": "你好",
        "The quick brown fox jumps over the lazy dog and runs away.": "敏捷的棕色狐狸跳过懒狗，然后跑开了。",
        "OK": "好",
        "Error occurred: ": "发生错误：",
        "Inset Grouped": "内嵌分组",
        "N/A": "不可用",
        "Camera": "相机",
        "Lens": "镜头",
        "Location": "位置",
        "TextEditorShowLineCount": "显示行数",
        "TextEditorWrapLines": "自动换行",
        "TextEditorUseCharacterPairs": "使用字符配对",
        "Type": "类型",
        "Locked": "锁定文件",
        "Position in array": "数组中的位置",
        "Value (in base64)": "值（base64）",
        "Change type": "更改类型",
        "Duplicate Key": "键重复",
        "JSON Viewer": "JSON 查看器",
        "Asset Catalog Viewer": "资源目录查看器",
        "Executable Runner": "可执行文件运行器",
        "iPhone": "iPhone",
        "iPad": "iPad",
        "TV": "电视",
        "Watch": "Apple Watch",
        "无法创建符号链接": "无法创建符号链接",
        "move": "移动",
        "copy": "复制",
        "import": "导入",
        "symlink": "符号链接",
        "Root Helper unavailable? is your install messed up?": "Root 助手不可用，请检查安装是否完整。",
        "Unable to read root helper output": "无法读取 Root 助手输出",
        "Failed to spawn root helper": "无法启动 Root 助手",
        "Input text is invalid or empty": "输入文本无效或为空",
        "Path must be a directory": "路径必须是目录",
        "Cancel": "取消",
        "Deselect All": "取消全选",
        "Select All": "全选",
        "Remove bookmark": "移除书签",
        "Bookmark": "添加书签",
        "点击选择类型": "点击选择类型",
        "Unknown Error": "未知错误",
        "Unnamed Asset": "未命名资源",
        "Lookup Name": "查找名称",
        "Rendition Name": "资源名称",
        "Display Gamut": "显示色域",
        "Unknown Artist": "未知艺术家",
        "Select font..": "选择字体…",
        "Full name": "全名",
        "Family name": "系列名称",
        "PostScript name": "PostScript 名称",
        "Pixel Height": "像素高度",
        "Pixel Width": "像素宽度",
        "Camera Model": "相机型号",
        "Camera Manufacturer": "相机制造商",
        "Camera Software": "相机软件",
        "Lens Model": "镜头型号",
        "Lens Manufacturer": "镜头制造商",
        "No Results": "无结果",
        "Expand": "展开",
        "Collapse": "收起",
        "File": "文件",
        "Directory": "文件夹",
        "Symbolic Link": "符号链接",
        "Executable": "可执行文件",
        "Readable": "可读",
        "Writable": "可写",
        "No": "否",
        "Yes": "是",
        "How What When Where Why": "如何、什么、何时、哪里、为什么",
        "Information": "信息"
    ]
}

private enum SantanderGlass {
    static let backgroundTag = 0x53474C42

    static var background: LegacyLiquidGlass.Configuration {
        var c = LLGlassPresets.clear
        c.backend = .automatic; c.quality = .medium; c.adaptiveQuality = true
        c.cornerRadius = 0; c.liveCapture = false; c.sharedSurface = false
        c.maxCapturePixels = 360_000; c.maxRenderScale = 1.15; c.captureScale = 0.58
        c.refractionScale = 0.35; c.tintStrength = 0.045; c.specularStrength = 0.18
        c.morphing = false; c.animated = false; c.interactive = false; c.pointerInteraction = false
        c.preferredFrameRate = 30; c.idleFrameRate = 12; c.liveCaptureDuringScroll = false
        c.cacheStaticBackdrops = true
        return c
    }

    static var selectedCell: LegacyLiquidGlass.Configuration {
        var c = cell
        c.style = .prominent; c.tintStrength = 0.18; c.specularStrength = 0.40
        return c
    }

    static var search: LegacyLiquidGlass.Configuration {
        var c = LLGlassPresets.clear
        c.backend = .automatic; c.quality = .medium; c.adaptiveQuality = true
        c.cornerRadius = 12; c.maxCapturePixels = 360_000; c.maxRenderScale = 1.25
        c.liveCapture = false; c.animated = false; c.interactive = false; c.pointerInteraction = false
        return c
    }

    static var toolbar: LegacyLiquidGlass.Configuration {
        var c = LLGlassPresets.regular
        c.backend = .automatic; c.quality = .medium; c.adaptiveQuality = true
        c.cornerRadius = 0; c.shadowOpacity = 0; c.morphing = false
        c.maxCapturePixels = 500_000; c.maxRenderScale = 1.5
        c.liveCapture = false; c.animated = false; c.interactive = false; c.pointerInteraction = false
        return c
    }

    static func installBackground(in window: UIWindow) {
        guard window.viewWithTag(backgroundTag) == nil else { return }
        // Keep a solid system backdrop underneath the single full-window glass.
        // A fully transparent UIWindow can otherwise expose the same composited
        // material twice during UIKit layout/transition passes.
        window.backgroundColor = .systemBackground
        let glass = LLGlassView(configuration: background)
        glass.tag = backgroundTag
        glass.translatesAutoresizingMaskIntoConstraints = false
        glass.isUserInteractionEnabled = false
        window.insertSubview(glass, at: 0)
        NSLayoutConstraint.activate([
            glass.leadingAnchor.constraint(equalTo: window.leadingAnchor),
            glass.trailingAnchor.constraint(equalTo: window.trailingAnchor),
            glass.topAnchor.constraint(equalTo: window.topAnchor),
            glass.bottomAnchor.constraint(equalTo: window.bottomAnchor)
        ])
    }

    static func installBackgroundIfNeeded(in window: UIWindow) {
        installBackground(in: window)
    }

    static func style(_ controller: UIViewController) {
        controller.view.backgroundColor = .clear
        controller.view.isOpaque = false

        // IMPORTANT: exactly one liquid-glass backdrop belongs to one UIWindow.
        // Installing another glass into every pushed UINavigationController (or
        // modal navigation stack) makes the same backdrop get sampled more than
        // once, producing stacked/overlapping glass, especially at /.
        if let window = controller.viewIfLoaded?.window ?? controller.navigationController?.viewIfLoaded?.window ?? UIApplication.shared.sceneKeyWindow {
            installBackground(in: window)
        }

        if let table = controller as? UITableViewController { styleTable(table.tableView) }
        if let bar = controller.navigationController?.navigationBar { configureNavigationBar(bar) }
    }

    static func prepareForContentTransition(in controller: UIViewController) {
        guard let window = controller.viewIfLoaded?.window ?? controller.navigationController?.viewIfLoaded?.window ?? UIApplication.shared.sceneKeyWindow else { return }
        let glass = window.viewWithTag(backgroundTag) as? LLGlassView
        glass?.prepareForContentTransition()
        LLGlassBackdropCoordinatorRegistry.shared.coordinatorIfPresent(for: window)?.purge()
    }

    static func refreshBackdrop(for controller: UIViewController) {
        guard let window = controller.viewIfLoaded?.window ?? controller.navigationController?.viewIfLoaded?.window ?? UIApplication.shared.sceneKeyWindow else { return }
        let coordinator = LLGlassBackdropCoordinatorRegistry.shared.coordinator(for: window)
        coordinator.markDirty()
        DispatchQueue.main.async {
            coordinator.requestCapture(force: true)
        }
    }

    static func finishContentTransition(in controller: UIViewController) {
        guard let window = controller.viewIfLoaded?.window ?? controller.navigationController?.viewIfLoaded?.window ?? UIApplication.shared.sceneKeyWindow else { return }
        let glass = window.viewWithTag(backgroundTag) as? LLGlassView
        let coordinator = LLGlassBackdropCoordinatorRegistry.shared.coordinatorIfPresent(for: window)
        glass?.finishContentTransition()
        DispatchQueue.main.async {
            coordinator?.requestCapture(force: true)
        }
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.08) {
            coordinator?.requestCapture(force: true)
        }
    }

    static func styleTable(_ table: UITableView) {
        table.backgroundColor = .clear
        table.backgroundView = nil
        table.isOpaque = false
        table.separatorColor = UIColor.separator.withAlphaComponent(0.16)
        if #available(iOS 15.0, *) {
            table.sectionHeaderTopPadding = 0
        }
    }

    static func styleCell(_ cell: UITableViewCell) {
        // The screen-level glass is the only live backdrop. Cells remain
        // transparent so adjacent rows never create stacked/overlapping glass.
        cell.backgroundColor = .clear
        cell.contentView.backgroundColor = .clear
        cell.backgroundConfiguration = .clear()
        cell.selectedBackgroundView = nil
        cell.selectionStyle = .default
    }

    static func configureNavigationBar(_ navigationBar: UINavigationBar) {
        let appearance = UINavigationBarAppearance()
        appearance.configureWithTransparentBackground()
        appearance.backgroundEffect = nil
        appearance.backgroundColor = .clear
        appearance.shadowColor = .clear
        navigationBar.standardAppearance = appearance
        navigationBar.scrollEdgeAppearance = appearance
        navigationBar.compactAppearance = appearance
        navigationBar.tintColor = .label
        navigationBar.isTranslucent = true
    }
}

extension UIViewController {
    func applySantanderGlass() { SantanderGlass.style(self) }
}

private enum SantanderLocalization {
    static func install() {
        UILabel.appearance().textColor = .label
        UIButton.appearance().tintColor = .label
    }
}

@propertyWrapper
struct Storage<T> {
    let key: String
    let defaultValue: T

    init(key: String, defaultValue: T) {
        self.key = key
        self.defaultValue = defaultValue
    }

    var wrappedValue: T {
        get {
            return UserDefaults.standard.object(forKey: key) as? T ?? defaultValue
        }
        set {
            UserDefaults.standard.set(newValue, forKey: key)
        }
    }
}

@propertyWrapper
struct CodableStorage<T: Codable> {
    typealias ChangeHandler = ((T) -> ())

    let key: String
    let defaultValue: T
    var didChange: ChangeHandler?

    init(key: String, defaultValue: T, didChange: ChangeHandler?) {
        self.key = key
        self.defaultValue = defaultValue
        self.didChange = didChange
    }

    var wrappedValue: T {
        get {
            guard let data = UserDefaults.standard.data(forKey: key),
                  let decoded = try? JSONDecoder().decode(T.self, from: data) else {
                return defaultValue
            }
            return decoded
        }
        set {
            guard let encoded = try? JSONEncoder().encode(newValue) else {
                return
            }
            UserDefaults.standard.set(encoded, forKey: key)
            didChange?(newValue)
        }
    }
}

enum UserPreferences {
    @Storage(key: "UseLargeNavTitles", defaultValue: true)
    static var useLargeNavigationTitles: Bool

    @Storage(key: "BookmarksData", defaultValue: [])
    static private var _bookmarksData: [Data]

    static var bookmarks: Set<Path> {
        get {
            var dataArr = self._bookmarksData
            let arr: [Path] = dataArr.compactMap { data in
                var isStale: Bool = false
                guard let url = try? URL(resolvingBookmarkData: data, bookmarkDataIsStale: &isStale) else { return nil }
                if isStale, let indx = dataArr.firstIndex(of: data), let urlData = try? url.bookmarkData() {
                    dataArr[indx] = urlData
                    self._bookmarksData = dataArr
                }
                return Path(url: url)
            }
            return Set(arr)
        }
        set {
            _bookmarksData = newValue.compactMap { url in
                try? url.url.bookmarkData()
            }
            if displayRecentlyBookmarked {
                let bookmarks: [Path] = newValue.suffix(5)
                UIApplication.shared.setShortcutItems(intoURLs: bookmarks)
            }
        }
    }

    @Storage(key: "AlwaysShowSearchBar", defaultValue: true)
    static var alwaysShowSearchBar: Bool

    @Storage(key: "ShowInfoButton", defaultValue: false)
    static var showInfoButton: Bool

    @Storage(key: "LastOpenedPath", defaultValue: nil)
    static var lastOpenedPath: String?

    @Storage(key: "UseLastOpenedPathWhenLaunching", defaultValue: true)
    static var useLastOpenedPathWhenLaunching: Bool

    @Storage(key: "UserPreferredLaunchPath", defaultValue: nil)
    static var userPreferredLaunchPath: String?

    @Storage(key: "TextEditorWrapLines", defaultValue: true)
    static var wrapLines: Bool

    @Storage(key: "TextEditorShowLineCount", defaultValue: true)
    static var showLineCount: Bool

    @Storage(key: "TextEditorUseCharacterPairs", defaultValue: true)
    static var useCharacterPairs: Bool

    @Storage(key: "AudioVCSkipDuration", defaultValue: 15)
    static var skipDuration: Int

    @Storage(key: "AudioVCSpeed", defaultValue: 1)
    static var audioVCSpeed: Float

    @Storage(key: "displayHiddenFiles", defaultValue: true)
    static var displayHiddenFiles: Bool

    @Storage(key: "userIntefaceStyle", defaultValue: UIUserInterfaceStyle.unspecified.rawValue)
    static var preferredInterfaceStyle: Int

    @Storage(key: "userPreferredTableViewStyle", defaultValue: UITableView.Style.insetGrouped.rawValue)
    static var preferredTableViewStyle: Int

    @Storage(key: "FontViewerFontSize", defaultValue: 30)
    static var fontViewerFontSize: CGFloat

    @Storage(key: "AssetCatalogControllerLayoutMode", defaultValue: AssetCatalogViewController.LayoutMode.verical.rawValue)
    static var assetCatalogControllerLayoutMode: Int

    @Storage(key: "RootHelperEnabled", defaultValue: false)
    static var rootHelperIsEnabled: Bool

    @Storage(key: "DisplayRecentlyUsedPathsInAppShortcuts", defaultValue: true)
    static var displayRecentlyBookmarked: Bool

    @CodableStorage(key: "PathGroups", defaultValue: [.default], didChange: { groups in
        NotificationCenter.default.post(name: .pathGroupsDidChange, object: groups)
    })
    static var pathGroups: [PathGroup]

    static var launchPath: String? {
        useLastOpenedPathWhenLaunching ? lastOpenedPath : userPreferredLaunchPath
    }

    @CodableStorage(key: "TextEditorTheme", defaultValue: CodableTextEditorTheme(), didChange: nil)
    static var textEditorTheme: CodableTextEditorTheme

    @CodableStorage(key: "AppTintColor", defaultValue: CodableColor(.systemBlue), didChange: nil)
    static var appTintColor: CodableColor
}

struct PathGroup: Codable, Hashable {
    let name: String
    var paths: [URL]

    static let `default` = PathGroup(name: "Default", paths: [.root])

    func hash(into hasher: inout Hasher) {
        hasher.combine(name)
        hasher.combine(paths)
    }
}

protocol BaseLayoutAnchorSupporting {
    var leadingAnchor: NSLayoutXAxisAnchor { get }
    var trailingAnchor: NSLayoutXAxisAnchor { get }
    var topAnchor: NSLayoutYAxisAnchor { get }
    var bottomAnchor: NSLayoutYAxisAnchor { get }
}

extension UILayoutGuide: BaseLayoutAnchorSupporting {}
extension UIView: BaseLayoutAnchorSupporting {
    func constraintCompletely(to otherView: BaseLayoutAnchorSupporting) {
        NSLayoutConstraint.activate([
            self.leadingAnchor.constraint(equalTo: otherView.leadingAnchor),
            self.trailingAnchor.constraint(equalTo: otherView.trailingAnchor),
            self.topAnchor.constraint(equalTo: otherView.topAnchor),
            self.bottomAnchor.constraint(equalTo: otherView.bottomAnchor)
        ])
    }
}

enum PathType: CustomStringConvertible {
    case file, directory

    var description: String {
        switch self {
        case .file:
            return SantanderL10n.t("file")
        case .directory:
            return SantanderL10n.t("directory")
        }
    }
}

extension UIViewController {
    func presentAlertAndCreate(type: PathType, forURL url: URL) {
        let alert = UIAlertController(title: "\(SantanderL10n.t("New")) \(SantanderL10n.t(type.description))", message: nil, preferredStyle: .alert)
        alert.addTextField { textField in
            textField.placeholder = SantanderL10n.t("name")
        }

        let createAction = UIAlertAction(title: SantanderL10n.t("Create"), style: .default) { _ in
            guard let name = alert.textFields?.first?.text, !name.isEmpty else {
                return
            }

            let urlToCreate = url.appendingPathComponent(name)
            do {
                switch type {
                case .file:
                    try FSOperation.perform(.createFile(files: [urlToCreate]), rootHelperConf: RootConf.shared)
                case .directory:
                    try FSOperation.perform(.createDirectory(directories: [urlToCreate]), rootHelperConf: RootConf.shared)
                }
            } catch {
                self.errorAlert(error, title: "无法创建 \(name)")
            }
        }

        alert.addAction(.cancel())
        alert.addAction(createAction)
        self.present(alert, animated: true)
    }
}

enum PathsSortMethods: String, CaseIterable, CustomStringConvertible {
    case alphabetically
    case size
    case type
    case dateCreated
    case dateModified
    case dateAccessed
    case dateAdded

    static var userPrefered: PathsSortMethods? {
        if let string = UserDefaults.standard.string(forKey: "SubPathsSortMode"), let sortMode = PathsSortMethods(rawValue: string) {
            return sortMode
        }
        return nil
    }

    var description: String {
        switch self {
        case .alphabetically:
            return SantanderL10n.t("Alphabetical order")
        case .size:
            return SantanderL10n.t("Size")
        case .type:
            return SantanderL10n.t("Type")
        case .dateCreated:
            return SantanderL10n.t("Date created")
        case .dateModified:
            return SantanderL10n.t("Date modified")
        case .dateAccessed:
            return SantanderL10n.t("Date accessed")
        case .dateAdded:
            return SantanderL10n.t("Date Added")
        }
    }

    func sorting(URLs urls: [Path], sortOrder: SortOrder) -> [Path] {
        return urls.sorted { (first: Path, second: Path) in
            let ascending: Bool
            let firstURL = first.url
            let secondURL = second.url
            switch self {
            case .alphabetically:
                ascending = firstURL.lastPathComponent < secondURL.lastPathComponent
            case .size:
                ascending = firstURL.size > secondURL.size
            case .type:
                let firstType = firstURL.contentType?.identifier ?? ""
                let secondType = secondURL.contentType?.identifier ?? ""
                let typeComparison = firstType.localizedStandardCompare(secondType)
                if typeComparison != .orderedSame {
                    return sortOrder == .descending
                        ? typeComparison == .orderedDescending
                        : typeComparison == .orderedAscending
                }
                let firstName = firstURL.lastPathComponent
                let secondName = secondURL.lastPathComponent
                let nameComparison = firstName.localizedStandardCompare(secondName)
                return sortOrder == .descending
                    ? nameComparison == .orderedDescending
                    : nameComparison == .orderedAscending
            case .dateCreated:
                ascending = firstURL.creationDate > secondURL.creationDate
            case .dateModified:
                ascending =  firstURL.lastModifiedDate > secondURL.lastModifiedDate
            case .dateAccessed:
                ascending = firstURL.lastAccessedDate > secondURL.lastAccessedDate
            case .dateAdded:
                ascending = firstURL.addedToDirectoryDate > secondURL.addedToDirectoryDate
            }

            if sortOrder == .descending {
                return !ascending
            }

            return ascending
        }
    }
}

enum SortOrder: String, CaseIterable, CustomStringConvertible {
    case ascending, descending

    init(rawValue: String) {
        switch rawValue.lowercased() {
        case "ascending":
            self = .ascending
        case "descending":
            self = .descending
        default:
            self = .ascending
        }
    }

    static var userPreferred: SortOrder {
        guard let rawValue = UserDefaults.standard.string(forKey: "SortOrder") else {
            return .ascending
        }
        return self.init(rawValue: rawValue)
    }

    var description: String {
        switch self {
        case .ascending:
            return SantanderL10n.t("Ascending")
        case .descending:
            return SantanderL10n.t("Descending")
        }
    }

    var imageSymbolName: String {
        switch self {
        case .ascending:
            return "chevron.up"
        case .descending:
            return "chevron.down"
        }
    }

    func toggling() -> SortOrder {
        switch self {
        case .ascending:
            return .descending
        case .descending:
            return .ascending
        }
    }
}

struct Path: Hashable, ExpressibleByStringLiteral {
    static let resourceKeys: Set<URLResourceKey> = [.isDirectoryKey, .contentTypeKey]

    static let root: Path = "/"
    static let home: Path = Path(url: URL(fileURLWithPath: NSHomeDirectory()))

    var url: URL
    var lastPathComponent: String
    var isDirectory: Bool
    var contentType: UTType?

    lazy var size = _getSize()
    lazy var displayImage: UIImage? = _displayImage()

    static let iconsDictionary: [UTType: String] = [
        .text: "doc.text",
        .image: "photo",
        .audio: "waveform",
        .video: "play",
        .movie: "play",
        .executable: "terminal"
    ]

    static func isUType(_ type: UTType, ofAnotherType another: UTType) -> Bool {
        return type == another || type.isSubtype(of: another)
    }

    var path: String {
        url.path
    }

    var displayName: String {
        FileManager.default.displayName(atPath: url.path)
    }

    var pathExtension: String {
        return url.pathExtension
    }

    var containsAppUUIDSubpaths: Bool {
        return url.pathComponents.contains("Containers") || url.pathComponents.contains("containers")
    }

    func deletingLastPathComponent() -> Path {
        return Path(url: url.deletingLastPathComponent())
    }

    func deletingPathExtension() -> Path {
        return Path(url: url.deletingPathExtension())
    }

    func appendingPathExtension(_ ext: String) -> Path {
        return Path(url: url.appendingPathExtension(ext))
    }

    func appendingPathComponent(_ component: String) -> Path {
        return Path(url: url.appendingPathComponent(component))
    }

    func appendingPathComponent(_ component: String) -> URL {
        return url.appendingPathComponent(component)
    }

    var resolvedURL: URL {
        return (try? URL(resolvingAliasFileAt: url)) ?? url
    }

    var contents: [Path] {
        let urls = (try? FileManager.default.contentsOfDirectory(at: url, includingPropertiesForKeys: nil)) ?? []
        return urls.map { url in
            Path(url:url)
        }
    }

    var applicationItem: SantanderApplication? {
        if pathExtension == "app" {
            return ApplicationsManager.shared.application(forBundleURL: self.url)
        }
        return ApplicationsManager.shared.application(forContainerURL: self.url) ?? ApplicationsManager.shared.application(forDataContainerURL: self.url)
    }

    private func _getSize() -> Int? {
        if isDirectory {
            var _size: Int = 0
            for var content in contents {
                _size += content.size ?? 0
            }
            return _size
        }
        return try? url.resourceValues(forKeys: [.fileSizeKey]).fileSize
    }

    var isReadable: Bool {
        return FileManager.default.isReadableFile(atPath: url.path)
    }

    private func _displayImage() -> UIImage? {
        if isDirectory {
            return UIImage(systemName: "folder.fill")
        } else {
            guard let type = self.contentType, type != .data else {
                return UIImage(systemName: "doc")
            }
            let imageName = Self.iconsDictionary.first { (key, _) in
                Self.isUType(type, ofAnotherType: key)
            }
            return UIImage(systemName: imageName?.value ?? "doc")
        }
    }

    init(url: URL) {
        self.url = url
        self.lastPathComponent = url.lastPathComponent

        let resourceValues = try? url.resourceValues(forKeys: Self.resourceKeys)
        self.isDirectory = resourceValues?.isDirectory ?? false
        self.contentType = resourceValues?.contentType
    }

    init(stringLiteral value: StringLiteralType) {
        self.init(url: URL(fileURLWithPath: value))
    }
}

class ImageMetadata {
    let pixelWidth: Int?
    let pixelHeight: Int?

    var location: ImageLocation
    let exifInfo: ImageExifInfo?
    let cameraInfo: ImageCameraInfo?
    let dateTimeTaken: Date?

    var dictionary: [String: Any]

    func setProperties(toDictionary newDict: [String: Any], forFileURL fileURL: URL) -> Bool {
        guard let imageSource = CGImageSourceCreateWithURL(fileURL as CFURL, nil),
              let type = CGImageSourceGetType(imageSource),
              let dest = CGImageDestinationCreateWithURL(fileURL as CFURL, type, 1, nil)
        else {
            return false
        }

        CGImageDestinationAddImageFromSource(dest, imageSource, 0, newDict as CFDictionary)

        if CGImageDestinationFinalize(dest) {
            self.dictionary = newDict
            return true
        } else {
            return false
        }
    }

    convenience init?(fileURL: URL) {
        guard let imageSource = CGImageSourceCreateWithURL(fileURL as CFURL, nil),
              let dict = CGImageSourceCopyPropertiesAtIndex(imageSource, 0, nil) as? [String: Any] else {
            return nil
        }
        self.init(dictionary: dict)
    }

    init(dictionary dict: [String: Any]) {
        self.pixelWidth = dict[kCGImagePropertyPixelWidth as String] as? Int
        self.pixelHeight = dict[kCGImagePropertyPixelHeight as String] as? Int

        if let exifDict = dict[kCGImagePropertyExifDictionary as String] as? [String: Any] {
            self.exifInfo = ImageExifInfo(exifDict: exifDict)
        } else {
            self.exifInfo = nil
        }

        if let gpsDict = dict[kCGImagePropertyGPSDictionary as String] as? [String: Any] {
            let lat = gpsDict[kCGImagePropertyGPSLatitude as String] as? CLLocationDegrees
            let long = gpsDict[kCGImagePropertyGPSLongitude as String] as? CLLocationDegrees
            self.location = ImageLocation(lat: lat, long: long)
        } else {
            self.location = ImageLocation(lat: nil, long: nil)
        }

        if let tiffDict = dict[kCGImagePropertyTIFFDictionary as String] as? [String: Any] {
            self.cameraInfo = ImageCameraInfo(tiffDictionary: tiffDict)
            if let dateTime = tiffDict[kCGImagePropertyTIFFDateTime as String] as? String {
                self.dateTimeTaken = DateFormatter.EXIFDateFormatter.date(from: dateTime)
            } else {
                self.dateTimeTaken = nil
            }
        } else {
            self.cameraInfo = nil
            self.dateTimeTaken = nil
        }

        self.dictionary = dict
    }
}

struct ImageLocation {
    var lat: CLLocationDegrees?
    var long: CLLocationDegrees?

    var coordinate: CLLocationCoordinate2D? {
        guard let lat = lat, let long = long else {
            return nil
        }
        return CLLocationCoordinate2D(latitude: lat, longitude: long)
    }
}

struct ImageCameraInfo {
    let manufacturer: String?
    let model: String?
    let softwareVersion: String?

    init(tiffDictionary: [String: Any]) {
        self.manufacturer = tiffDictionary[kCGImagePropertyTIFFMake as String] as? String
        self.model = tiffDictionary[kCGImagePropertyTIFFModel as String] as? String
        self.softwareVersion = tiffDictionary[kCGImagePropertyTIFFSoftware as String] as? String
    }
}

struct ImageExifInfo {
    let apertureValue: Double?
    let brightnessValue: Double?
    let lensModel: String?
    let lensManufacturer: String?

    init(exifDict: [String: Any]) {
        self.apertureValue = exifDict[kCGImagePropertyExifApertureValue as String] as? Double
        self.brightnessValue = exifDict[kCGImagePropertyExifBrightnessValue as String] as? Double
        self.lensModel = exifDict[kCGImagePropertyExifLensModel as String] as? String
        self.lensManufacturer = exifDict[kCGImagePropertyExifLensMake as String] as? String
    }
}

enum DiffableDataSourceItem<Section: Hashable, Item: Hashable> {
    case section(Section)
    case item(Item)

    static func fromItems(_ items: [Item]) -> [DiffableDataSourceItem] {
        return items.map { item in
            return .item(item)
        }
    }
}

extension DiffableDataSourceItem: Hashable {}

protocol RootHelperConfiguration {
    func perform(_ operation: FSOperation) throws
}

enum FSOperation {
    case createFile(files: [URL])
    case createDirectory(directories: [URL])
    case removeItems(items: [URL])
    case rename(item: URL, newPath: URL)
    case moveItem(items: [URL], resultPath: URL)
    case copyItem(items: [URL], resultPath: URL)
    case symlink(items: [URL], resultPath: URL)
    case setPermissions(url: URL, newOctalPermissions: Int)
    case setOwnerOrGroup(url: URL, ownerName: String?, groupName: String?)
    case setLocked(url: URL, locked: Bool)
    case compress(paths: [URL], resultPath: URL, format: Compression.FormatType)
    case decompress(archive: URL, resultPath: URL)
    case extractCatalog(catalogFileURL: URL, resultPath: URL)
    case writeData(url: URL, data: Data)
    case writeString(url: URL, string: String)

    var commandLineInvokation: [String] {
        switch self {
        case .createFile(let files):
            return ["create"] + files.flatMap { ["--files", $0.path] }
        case .createDirectory(let directories):
            return ["create"] + directories.flatMap { ["--directories", $0.path] }
        case .removeItems(let items):
            return ["delete"] + items.map(\.path)
        case .rename(let item, let newPath):
            return ["rename", item.path, newPath.path]
        case .moveItem(let items, let resultPath):
            return ["move"] + items.map(\.path) + ["--destination", resultPath.path]
        case .copyItem(let items, let resultPath):
            return ["copy"] + items.map(\.path) + ["--destination", resultPath.path]
        case .symlink(let items, let resultPath):
            return ["link"] + items.map(\.path) + ["--destination", resultPath.path]
        case .setPermissions(let url, let permissions):
            return ["set-permissions", url.path, String(permissions)]
        case .setOwnerOrGroup(let url, let ownerName, let groupName):
            var arguments = ["set-owner-or-group", url.path]
            if let ownerName {
                arguments += ["--owner-name", ownerName]
            }
            if let groupName {
                arguments += ["--group-name", groupName]
            }
            return arguments
        case .setLocked(let url, let locked):
            return ["set-locked", url.path, locked ? "1" : "0"]
        case .compress(let paths, let resultPath, let format):
            return ["compress"] + paths.flatMap { ["--paths", $0.path] } +
                ["--destination", resultPath.path, "--format", format.fileExtension]
        case .decompress(let archive, let resultPath):
            return ["decompress", archive.path, "--destination", resultPath.path]
        case .extractCatalog(let catalogFileURL, let resultPath):
            return ["extract-catalog", catalogFileURL.path, "--destination", resultPath.path]
        case .writeData(let url, _):
            return ["write-data", url.path]
        case .writeString(let url, let string):
            return ["write-string", string, "--path", url.path]
        }
    }

    static func perform(_ operation: FSOperation, rootHelperConf: RootHelperConfiguration) throws {
        try rootHelperConf.perform(operation)
    }
}

struct RootConf: RootHelperConfiguration {
    private init() {}

    static let shared = RootConf()

    func contents(of path: URL) throws -> [URL] {
        let spawn = try spawn(command: try rootHelperURL(), args: ["get-contents", path.path])
        return spawn.standardOutput
            .split(whereSeparator: { $0.isNewline })
            .map { URL(fileURLWithPath: String($0)) }
    }

    private func rootHelperURL() throws -> URL {
        guard let rootHelperURL = Bundle.main.url(forResource: "RootHelper", withExtension: nil),
              FileManager.default.fileExists(atPath: rootHelperURL.path) else {
            throw Errors.rootHelperUnavailable
        }
        return rootHelperURL
    }

    func perform(_ operation: FSOperation) throws {
        let ret: Output
        if case let .writeData(_, data) = operation {
            ret = try spawn(command: try rootHelperURL(), args: operation.commandLineInvokation, standardInputData: data)
        } else {
            ret = try spawn(command: try rootHelperURL(), args: operation.commandLineInvokation)
        }

        guard ret.status == 0 else {
            throw Errors.otherError(description: "Root helper returned non-zero status, error: \(ret.standardError)")
        }
    }

    func runHelper(arguments: [String], standardInputData: Data? = nil) throws {
        let result = try spawn(command: try rootHelperURL(), args: arguments, standardInputData: standardInputData)
        guard result.status == 0 else {
            let message = result.standardError.trimmingCharacters(in: .whitespacesAndNewlines)
            throw Errors.otherError(description: message.isEmpty ? "Root helper failed with status \(result.status)" : message)
        }
    }

    func spawn(command: URL, args: [String], root: Bool = true, standardInputData: Data? = nil) throws -> Output {
        var stdoutPipe: [Int32] = [-1, -1]
        var stderrPipe: [Int32] = [-1, -1]
        var stdinPipe: [Int32] = [-1, -1]

        func closePipe(_ pipe: inout [Int32]) {
            if pipe.count == 2 {
                if pipe[0] >= 0 { _ = close(pipe[0]); pipe[0] = -1 }
                if pipe[1] >= 0 { _ = close(pipe[1]); pipe[1] = -1 }
            }
        }

        guard pipe(&stdoutPipe) == 0,
              pipe(&stderrPipe) == 0,
              standardInputData == nil || pipe(&stdinPipe) == 0 else {
            closePipe(&stdoutPipe); closePipe(&stderrPipe); closePipe(&stdinPipe)
            throw Errors.failedToSpawnHelper
        }

        let bufferSize = Int(BUFSIZ)
        guard fcntl(stdoutPipe[0], F_SETFL, O_NONBLOCK) != -1,
              fcntl(stderrPipe[0], F_SETFL, O_NONBLOCK) != -1 else {
            closePipe(&stdoutPipe); closePipe(&stderrPipe); closePipe(&stdinPipe)
            throw Errors.otherError(description: "Unable to configure helper pipes: \(String(cString: strerror(errno)))")
        }

        let argumentStrings = [command.lastPathComponent] + args
        let argv: [UnsafeMutablePointer<CChar>?] = argumentStrings.map { $0.withCString(strdup) }
        defer { for case let arg? in argv { free(arg) } }

        var actions: posix_spawn_file_actions_t?
        guard posix_spawn_file_actions_init(&actions) == 0 else {
            closePipe(&stdoutPipe); closePipe(&stderrPipe); closePipe(&stdinPipe)
            throw Errors.failedToSpawnHelper
        }
        defer { _ = posix_spawn_file_actions_destroy(&actions) }

        guard posix_spawn_file_actions_addclose(&actions, stdoutPipe[0]) == 0,
              posix_spawn_file_actions_addclose(&actions, stderrPipe[0]) == 0,
              posix_spawn_file_actions_adddup2(&actions, stdoutPipe[1], STDOUT_FILENO) == 0,
              posix_spawn_file_actions_adddup2(&actions, stderrPipe[1], STDERR_FILENO) == 0,
              posix_spawn_file_actions_addclose(&actions, stdoutPipe[1]) == 0,
              posix_spawn_file_actions_addclose(&actions, stderrPipe[1]) == 0 else {
            closePipe(&stdoutPipe); closePipe(&stderrPipe); closePipe(&stdinPipe)
            throw Errors.failedToSpawnHelper
        }

        if standardInputData != nil {
            guard posix_spawn_file_actions_adddup2(&actions, stdinPipe[0], STDIN_FILENO) == 0,
                  posix_spawn_file_actions_addclose(&actions, stdinPipe[0]) == 0,
                  posix_spawn_file_actions_addclose(&actions, stdinPipe[1]) == 0 else {
                closePipe(&stdoutPipe); closePipe(&stderrPipe); closePipe(&stdinPipe)
                throw Errors.failedToSpawnHelper
            }
        }

        var attr: posix_spawnattr_t?
        guard posix_spawnattr_init(&attr) == 0 else {
            closePipe(&stdoutPipe); closePipe(&stderrPipe); closePipe(&stdinPipe)
            throw Errors.failedToSpawnHelper
        }
        defer { _ = posix_spawnattr_destroy(&attr) }
        typealias SetPersona = @convention(c) (UnsafeMutablePointer<posix_spawnattr_t?>, uid_t, UInt32) -> Int32
        typealias SetPersonaID = @convention(c) (UnsafeMutablePointer<posix_spawnattr_t?>, uid_t) -> Int32
        let defaultHandle = UnsafeMutableRawPointer(bitPattern: -2)
        if let symbol = dlsym(defaultHandle, "posix_spawnattr_set_persona_np") {
            let setPersona = unsafeBitCast(symbol, to: SetPersona.self)
            _ = setPersona(&attr, 99, 1)
        }
        if let symbol = dlsym(defaultHandle, "posix_spawnattr_set_persona_uid_np") {
            let setPersonaID = unsafeBitCast(symbol, to: SetPersonaID.self)
            _ = setPersonaID(&attr, 0)
        }
        if let symbol = dlsym(defaultHandle, "posix_spawnattr_set_persona_gid_np") {
            let setPersonaID = unsafeBitCast(symbol, to: SetPersonaID.self)
            _ = setPersonaID(&attr, 0)
        }

        let env = [#"PATH=/usr/local/sbin:/var/jb/usr/local/sbin:/usr/local/bin:/var/jb/usr/local/bin:/usr/sbin:/var/jb/usr/sbin:/usr/bin:/var/jb/usr/bin:/sbin:/var/jb/sbin:/bin:/var/jb/bin:/usr/bin/X11:/var/jb/usr/bin/X11:/usr/games:/var/jb/usr/games"#]
        let proenv: [UnsafeMutablePointer<CChar>?] = env.map { $0.withCString(strdup) }
        defer { for case let e? in proenv { free(e) } }

        var pid: pid_t = 0
        let spawnStatus = argv.withUnsafeBufferPointer { argvBuffer in
            proenv.withUnsafeBufferPointer { envBuffer in
                posix_spawn(&pid, command.path, &actions, &attr, argvBuffer.baseAddress, envBuffer.baseAddress)
            }
        }
        guard spawnStatus == 0 else {
            closePipe(&stdoutPipe); closePipe(&stderrPipe); closePipe(&stdinPipe)
            throw Errors.otherError(description: "Failed to spawn root helper: \(String(cString: strerror(spawnStatus)))")
        }

        let stdoutReadFD = stdoutPipe[0]
        let stderrReadFD = stderrPipe[0]
        _ = close(stdoutPipe[1]); stdoutPipe[1] = -1
        _ = close(stderrPipe[1]); stderrPipe[1] = -1
        if standardInputData != nil { _ = close(stdinPipe[0]); stdinPipe[0] = -1 }

        let dataLock = NSLock()
        var stdoutData = Data()
        var stderrData = Data()
        let queue = DispatchQueue(label: "com.Antoine.Santander.RootHelper.read", qos: .userInitiated, attributes: .concurrent)
        let stdoutDone = DispatchSemaphore(value: 0)
        let stderrDone = DispatchSemaphore(value: 0)

        let stdoutSource = DispatchSource.makeReadSource(fileDescriptor: stdoutReadFD, queue: queue)
        let stderrSource = DispatchSource.makeReadSource(fileDescriptor: stderrReadFD, queue: queue)

        stdoutSource.setCancelHandler {
            _ = close(stdoutReadFD)
            stdoutDone.signal()
        }
        stderrSource.setCancelHandler {
            _ = close(stderrReadFD)
            stderrDone.signal()
        }

        stdoutSource.setEventHandler {
            var buffer = [UInt8](repeating: 0, count: bufferSize)
            let n = read(stdoutReadFD, &buffer, buffer.count)
            if n > 0 {
                dataLock.lock(); stdoutData.append(buffer, count: n); dataLock.unlock()
            } else if n == 0 || (n < 0 && errno != EAGAIN && errno != EINTR) {
                stdoutSource.cancel()
            }
        }
        stderrSource.setEventHandler {
            var buffer = [UInt8](repeating: 0, count: bufferSize)
            let n = read(stderrReadFD, &buffer, buffer.count)
            if n > 0 {
                dataLock.lock(); stderrData.append(buffer, count: n); dataLock.unlock()
            } else if n == 0 || (n < 0 && errno != EAGAIN && errno != EINTR) {
                stderrSource.cancel()
            }
        }

        stdoutSource.resume(); stderrSource.resume()

        if let input = standardInputData {
            let fd = stdinPipe[1]
            stdinPipe[1] = -1
            DispatchQueue.global(qos: .userInitiated).async {
                input.withUnsafeBytes { raw in
                    guard let base = raw.baseAddress else { return }
                    var offset = 0
                    while offset < raw.count {
                        let written = write(fd, base.advanced(by: offset), raw.count - offset)
                        if written > 0 { offset += written }
                        else if written < 0 && errno == EINTR { continue }
                        else { break }
                    }
                }
                _ = close(fd)
            }
        }

        var waitStatus: Int32 = 0
        var waitedPID: pid_t
        repeat {
            waitedPID = waitpid(pid, &waitStatus, 0)
        } while waitedPID == -1 && errno == EINTR
        stdoutDone.wait(); stderrDone.wait()

        dataLock.lock()
        let out = stdoutData; let err = stderrData
        dataLock.unlock()
        guard waitedPID == pid else {
            return Output(status: -1,
                          standardOutput: String(decoding: out, as: UTF8.self),
                          standardError: String(decoding: err, as: UTF8.self))
        }
        let normalExit = (waitStatus & 0x7f) == 0
        return Output(status: normalExit ? Int32((waitStatus >> 8) & 0xff) : -1,
                      standardOutput: String(decoding: out, as: UTF8.self),
                      standardError: String(decoding: err, as: UTF8.self))
    }

    struct Output {
        let status: CInt
        let standardOutput: String
        let standardError: String
    }

    var useRootHelper: Bool {
        return UserPreferences.rootHelperIsEnabled
    }

    private enum Errors: Error, LocalizedError, CustomStringConvertible {
        case rootHelperUnavailable
        case unableToReadHelperOutput
        case failedToSpawnHelper
        case otherError(description: String)

        var description: String {
            switch self {
            case .rootHelperUnavailable:
                return "Root Helper unavailable? is your install messed up?"
            case .unableToReadHelperOutput:
                return "Unable to read root helper output"
            case .failedToSpawnHelper:
                return "Failed to spawn root helper"
            case .otherError(let description):
                return description
            }
        }

        var errorDescription: String? {
            SantanderL10n.t(description)
        }
    }
}

protocol DirectoryMonitorDelegate: AnyObject {
    func directoryMonitorDidObserveChange(directoryMonitor: DirectoryMonitor)
}

class DirectoryMonitor {
    weak var delegate: DirectoryMonitorDelegate?

    var monitoredDirectoryFileDescriptor: CInt = -1

    let directoryMonitorQueue = DispatchQueue(label: "directorymonitor", attributes: .concurrent)

    var directoryMonitorSource: DispatchSource?

    var path: Path

    init(path: Path) {
        self.path = path
    }

    func startMonitoring() {
        if directoryMonitorSource == nil && monitoredDirectoryFileDescriptor == -1 {
            monitoredDirectoryFileDescriptor = open((path.url as NSURL).fileSystemRepresentation, O_EVTONLY)

            if path.isReadable {
                directoryMonitorSource = DispatchSource.makeFileSystemObjectSource(fileDescriptor: monitoredDirectoryFileDescriptor, eventMask: .all, queue: directoryMonitorQueue) as? DispatchSource
            }

            directoryMonitorSource?.setEventHandler {
                self.delegate?.directoryMonitorDidObserveChange(directoryMonitor: self)
            }

            directoryMonitorSource?.setCancelHandler {
                close(self.monitoredDirectoryFileDescriptor)
                self.monitoredDirectoryFileDescriptor = -1
                self.directoryMonitorSource = nil
            }

            directoryMonitorSource?.resume()
        }
    }

    func stopMonitoring() {
        if directoryMonitorSource != nil {
            directoryMonitorSource?.cancel()
        }
    }
}

struct GoToItem: Hashable {

    private typealias MayExistDictionary = [String: (URL?, UIImage?)]

    let displayName: String
    let url: URL
    let image: UIImage?

    init(displayName: String, url: URL, image: UIImage?) {
        self.displayName = displayName
        self.url = url
        self.image = image
    }

    private static func _searchPathDirURL(_ searchPath: FileManager.SearchPathDirectory) -> URL? {
        return FileManager.default.urls(for: searchPath, in: .userDomainMask).first
    }

    private static func _generateAll() -> [GoToItem] {
        let coreItems: [GoToItem] = [
            GoToItem(displayName: SantanderL10n.t("Root"), url: URL(fileURLWithPath: "/var/root"), image: nil),
            GoToItem(displayName: SantanderL10n.t("Home"), url: .home, image: UIImage(systemName: "house"))
        ]

        let mayExistDict: MayExistDictionary = [
            "Applications": (_searchPathDirURL(.applicationDirectory), .appsDirectory),
            "Library":      (_searchPathDirURL(.libraryDirectory),     .libraryDirectory),
            "Documents":    (_searchPathDirURL(.documentDirectory),    .documentDirectory),
            "Downloads":    (_searchPathDirURL(.downloadsDirectory),   .downloadsDirectory)
        ]

        let mayExistItems: [GoToItem] = mayExistDict.compactMap { (key, value) in
            let (url, image) = value
            guard let url = url, FileManager.default.fileExists(atPath: url.path) else {
                return nil
            }
            return GoToItem(displayName: SantanderL10n.t(key), url: url, image: image)
        }

        return coreItems + mayExistItems
    }

    static let all = _generateAll()
}

fileprivate extension UIImage {
    static let appsDirectory =      UIImage(systemName: "app.dashed")
    static let libraryDirectory =   UIImage(systemName: "books.vertical")
    static let documentDirectory =  UIImage(systemName: "doc")
    static let downloadsDirectory = UIImage(systemName: "arrow.down.circle")
}

enum LoadingValueState<Value> {
    case loading
    case unavailable
    case value(Value)
}

struct PathMetadata {

    static let resourceValueKeys: Set<URLResourceKey> = [
        .creationDateKey, .contentAccessDateKey, .addedToDirectoryDateKey, .contentModificationDateKey,
        .contentTypeKey
    ]

    let creationDate: Date?
    let addedToDirectoryDate: Date?
    let lastModifiedDate: Date?
    let lastAccessedDate: Date?
    let contentType: UTType?
    var permissions: PathPermissions?

    init(filePath path: Path, resourceValues: Set<URLResourceKey> = resourceValueKeys) {
        let resourceValues = try? path.url.resourceValues(forKeys: resourceValues)
        self.creationDate = resourceValues?.creationDate
        self.addedToDirectoryDate = resourceValues?.addedToDirectoryDate
        self.lastModifiedDate = resourceValues?.contentModificationDate
        self.lastAccessedDate = resourceValues?.contentAccessDate
        self.contentType = resourceValues?.contentType
        self.permissions = PathPermissions(fileURL: path.url)
    }
}

protocol PathTransitioning {
    func goToPath(path: Path)
}

struct Permission: OptionSet, CustomStringConvertible, Equatable {
    public var rawValue: Int

    static let execute = Permission(rawValue: 1)
    static let write = Permission(rawValue: 2)
    static let read = Permission(rawValue: 4)

    init(rawValue: Int) {
        self.rawValue = rawValue
    }

    init(buffer: stat, constants: [UInt16: Permission]) {
        self = constants.filter { (constant, _) in
            return (buffer.st_mode & constant) != 0
        }
        .map(\.value)
        .reducingToSingleOptionSet()
    }

    var binaryRepresentation: String {
        var b = String(rawValue, radix: 2)
        while b.count < 3 { b = "0" + b }
        return b
    }

    var description: String {
        let labels = [(Permission.read, SantanderL10n.t("Read")), (Permission.write, SantanderL10n.t("Write")), (Permission.execute, SantanderL10n.t("Execute"))]
        return labels.compactMap { contains($0.0) ? "\($0.1) ✓" : nil }.joined(separator: "  ")
    }

    static func binaryRepresentation(of permissions: [Permission]) -> String {
        return permissions.map { $0.binaryRepresentation }.joined()
    }

    static func octalRepresentation(of permissions: [Permission]) -> Int {
        let binary = binaryRepresentation(of: permissions)
        return Int(binary, radix: 2)!
    }

    static let ownerPermsConstants: [UInt16: Permission] = [
        S_IRUSR: .read,
        S_IWUSR: .write,
        S_IXUSR: .execute
    ]

    static let groupPermsConstants: [UInt16: Permission] = [
        S_IRGRP: .read,
        S_IWGRP: .write,
        S_IXGRP: .execute
    ]

    static let otherUsersPermsConstants: [UInt16: Permission] = [
        S_IROTH: .read,
        S_IWOTH: .write,
        S_IXOTH: .execute
    ]
}

struct PathPermissions: Equatable {
    let fileURL: URL
    var ownerPermissions: Permission
    var groupPermissions: Permission
    var otherUsersPermissions: Permission
    var ownerName: String?
    var groupOwnerName: String?
    var ownerID: Int32
    var groupID: Int32
    var isLocked: Bool

    static func isLocked(at fileURL: URL) -> Bool {
        var buffer = stat()
        guard lstat(fileURL.path, &buffer) == 0 else { return false }
        return (buffer.st_flags & UInt32(UF_IMMUTABLE)) != 0
    }

    init?(fileURL: URL) {
        var buffer = stat()
        guard lstat(fileURL.path, &buffer) == 0 else {
            return nil
        }

        ownerPermissions = Permission(buffer: buffer, constants: Permission.ownerPermsConstants)
        groupPermissions = Permission(buffer: buffer, constants: Permission.groupPermsConstants)
        otherUsersPermissions = Permission(buffer: buffer, constants: Permission.otherUsersPermsConstants)
        ownerID = Int32(bitPattern: UInt32(buffer.st_uid))
        groupID = Int32(bitPattern: UInt32(buffer.st_gid))
        isLocked = (buffer.st_flags & UInt32(UF_IMMUTABLE)) != 0

        let attrs = try? FileManager.default.attributesOfItem(atPath: fileURL.path)
        ownerName = attrs?[.ownerAccountName] as? String
        groupOwnerName = attrs?[.groupOwnerAccountName] as? String
        self.fileURL = fileURL
    }

    init(
        fileURL: URL,
        ownerPermissions: Permission,
        groupPermissions: Permission,
        otherUsersPermissions: Permission,
        ownerName: String? = nil,
        groupOwnerName: String? = nil,
        ownerID: Int32 = 0,
        groupID: Int32 = 0,
        isLocked: Bool = false
    ) {
        self.fileURL = fileURL
        self.ownerPermissions = ownerPermissions
        self.groupPermissions = groupPermissions
        self.otherUsersPermissions = otherUsersPermissions
        self.ownerName = ownerName
        self.groupOwnerName = groupOwnerName
        self.ownerID = ownerID
        self.groupID = groupID
        self.isLocked = isLocked
    }

    func apply() throws {
        try fileURL.setPermissions(forOwner: ownerPermissions, group: groupPermissions, others: otherUsersPermissions)
    }

    func applyLocked(_ locked: Bool) throws {
        try FSOperation.perform(.setLocked(url: fileURL, locked: locked), rootHelperConf: RootConf.shared)
        isLocked = locked
    }
}

struct StringError: LocalizedError, CustomStringConvertible {
    let description: String

    init(_ description: String) {
        self.description = description
    }

    var errorDescription: String? {
        SantanderL10n.t(description)
    }
}

private enum SantanderCommandParser {
    static func arguments(_ args: [String], after flag: String) throws -> [String] {
        var values: [String] = []
        var index = 0
        while index < args.count {
            if args[index] == flag {
                guard index + 1 < args.count else {
                    throw StringError("Missing value for \(flag)")
                }
                values.append(args[index + 1])
                index += 2
            } else {
                index += 1
            }
        }
        return values
    }

    static func single(_ args: [String], flag: String, required: Bool = false) throws -> String? {
        let values = try arguments(args, after: flag)
        guard values.count <= 1 else {
            throw StringError("Option \(flag) may only be provided once")
        }
        if required && values.isEmpty {
            throw StringError("Missing required option \(flag)")
        }
        return values.first
    }

    static func positional(_ args: [String], excluding flags: Set<String>) -> [String] {
        var result: [String] = []
        var index = 0
        while index < args.count {
            let item = args[index]
            if flags.contains(item) {
                index += min(2, args.count - index)
            } else if item.hasPrefix("--") {
                index += 1
            } else {
                result.append(item)
                index += 1
            }
        }
        return result
    }

    static func url(_ value: String, label: String) throws -> URL {
        guard !value.isEmpty else {
            throw StringError("Invalid empty \(label)")
        }
        return URL(fileURLWithPath: value)
    }

    static func urls(_ values: [String], label: String) throws -> [URL] {
        try values.map { try url($0, label: label) }
    }

    static func requiredURL(_ args: [String], flag: String) throws -> URL {
        guard let value = try single(args, flag: flag, required: true) else {
            throw StringError("Missing required option \(flag)")
        }
        return try url(value, label: flag)
    }

    static func printUsage() {
        let usage = """
        Usage: RootHelperProgram <command> [options]

        Commands:
          create --directories <path>... --files <path>...
          delete <path>...
          move <path>... --destination <directory>
          copy <path>... --destination <directory>
          link <path>... --destination <directory>
          rename <path> <destination>
          set-owner-or-group <path> [--group-name <name>] [--owner-name <name>] [--group-id <id>] [--owner-id <id>]
          set-locked <path> <0|1>
          set-permissions <path> <permissions>
          compress --paths <path>... --destination <path> [--format zip|tar]
          decompress <path> --destination <path>
          write-data <path>
          write-string <string> --path <path>
          get-contents <path>
        """
        FileHandle.standardError.write(Data(usage.utf8))
    }
}

struct Delete {
    let paths: [URL]

    init(arguments: [String]) throws {
        let positionals = arguments
            .filter { !$0.hasPrefix("-") }
            .map { URL(fileURLWithPath: $0) }
        guard !positionals.isEmpty else {
            throw StringError("delete requires at least one path")
        }
        self.paths = positionals
    }

    func run() throws {
        for path in paths {
            try FileManager.default.removeItem(at: path)
        }
    }
}

struct SetOwnerOrGroup {
    let path: URL
    let groupName: String?
    let ownerName: String?
    let groupID: Int32?
    let ownerID: Int32?

    init(arguments: [String]) throws {
        let positionals = SantanderCommandParser.positional(
            arguments,
            excluding: ["--group-name", "--owner-name", "--group-id", "--owner-id"]
        )
        guard let first = positionals.first, positionals.count == 1 else {
            throw StringError("set-owner-or-group requires exactly one path")
        }
        self.path = URL(fileURLWithPath: first)
        self.groupName = try SantanderCommandParser.single(arguments, flag: "--group-name")
        self.ownerName = try SantanderCommandParser.single(arguments, flag: "--owner-name")
        if let value = try SantanderCommandParser.single(arguments, flag: "--group-id") {
            self.groupID = Int32(value)
        } else {
            self.groupID = nil
        }
        if let value = try SantanderCommandParser.single(arguments, flag: "--owner-id") {
            self.ownerID = Int32(value)
        } else {
            self.ownerID = nil
        }

        guard groupName != nil || ownerName != nil || groupID != nil || ownerID != nil else {
            throw StringError("Specify an owner/group name or ID")
        }
        guard !(groupName != nil && groupID != nil), !(ownerName != nil && ownerID != nil) else {
            throw StringError("Do not specify both a name and an ID for the same field")
        }
    }

    func run() throws {
        var uid = uid_t.max
        var gid = gid_t.max
        if let ownerID {
            uid = UInt32(bitPattern: ownerID)
        }
        if let groupID {
            gid = UInt32(bitPattern: groupID)
        }

        if ownerID != nil || groupID != nil {
            guard lchown(path.path, uid, gid) == 0 else {
                throw StringError(String(cString: strerror(errno)))
            }
        }

        if let groupName {
            try FileManager.default.setAttributes([.groupOwnerAccountName: groupName], ofItemAtPath: path.path)
        }
        if let ownerName {
            try FileManager.default.setAttributes([.ownerAccountName: ownerName], ofItemAtPath: path.path)
        }
    }
}

struct SetLocked {
    let path: URL
    let locked: Bool

    init(arguments: [String]) throws {
        let positionals = arguments.filter { !$0.hasPrefix("-") }
        guard positionals.count == 2 else {
            throw StringError("set-locked requires <path> <0|1>")
        }
        self.path = URL(fileURLWithPath: positionals[0])
        guard positionals[1] == "0" || positionals[1] == "1" else {
            throw StringError("set-locked requires 0 or 1")
        }
        self.locked = positionals[1] == "1"
    }

    func run() throws {
        var buffer = stat()
        guard lstat(path.path, &buffer) == 0 else {
            throw StringError(String(cString: strerror(errno)))
        }
        let current = UInt32(buffer.st_flags)
        let next = locked ? (current | UInt32(UF_IMMUTABLE)) : (current & ~UInt32(UF_IMMUTABLE))
        guard chflags(path.path, next) == 0 else {
            throw StringError(String(cString: strerror(errno)))
        }
    }
}

struct Create {
    let directories: [URL]
    let files: [URL]

    init(arguments: [String]) throws {
        directories = try SantanderCommandParser.urls(
            SantanderCommandParser.arguments(arguments, after: "--directories"),
            label: "directory"
        )
        files = try SantanderCommandParser.urls(
            SantanderCommandParser.arguments(arguments, after: "--files"),
            label: "file"
        )

        guard !directories.isEmpty || !files.isEmpty else {
            throw StringError("create requires --directories and/or --files")
        }
    }

    func run() throws {
        for dir in directories {
            try FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
        }

        for file in files {
            let fPtr = try file.withUnsafeFileSystemRepresentation { cPathPointer in
                guard let cPathPointer, let fPtr = fopen(cPathPointer, "a") else {
                    throw StringError("Failed to create file \(file): \(String(cString: strerror(errno)))")
                }
                return fPtr
            }
            fclose(fPtr)
        }
    }
}

struct Move {
    let paths: [URL]
    let destination: URL

    init(arguments: [String]) throws {
        let positionals = SantanderCommandParser.positional(arguments, excluding: ["--destination"])
        guard !positionals.isEmpty else { throw StringError("move requires at least one source path") }
        paths = positionals.map { URL(fileURLWithPath: $0) }
        destination = try SantanderCommandParser.requiredURL(arguments, flag: "--destination")
    }

    func run() throws {
        for path in paths {
            try FileManager.default.moveItem(at: path, to: destination.appendingPathComponent(path.lastPathComponent))
        }
    }
}

struct Copy {
    let paths: [URL]
    let destination: URL

    init(arguments: [String]) throws {
        let positionals = SantanderCommandParser.positional(arguments, excluding: ["--destination"])
        guard !positionals.isEmpty else { throw StringError("copy requires at least one source path") }
        paths = positionals.map { URL(fileURLWithPath: $0) }
        destination = try SantanderCommandParser.requiredURL(arguments, flag: "--destination")
    }

    func run() throws {
        for path in paths {
            try FileManager.default.copyItem(at: path, to: destination.appendingPathComponent(path.lastPathComponent))
        }
    }
}

struct Rename {
    let path: URL
    let destination: URL

    init(arguments: [String]) throws {
        let positionals = arguments.filter { !$0.hasPrefix("-") }
        guard positionals.count == 2 else {
            throw StringError("rename requires <path> <destination>")
        }
        path = URL(fileURLWithPath: positionals[0])
        destination = URL(fileURLWithPath: positionals[1])
    }

    func run() throws {
        try FileManager.default.moveItem(at: path, to: destination)
    }
}

struct Link {
    let paths: [URL]
    let destination: URL

    init(arguments: [String]) throws {
        let positionals = SantanderCommandParser.positional(arguments, excluding: ["--destination"])
        guard !positionals.isEmpty else { throw StringError("link requires at least one source path") }
        paths = positionals.map { URL(fileURLWithPath: $0) }
        destination = try SantanderCommandParser.requiredURL(arguments, flag: "--destination")
    }

    func run() throws {
        for path in paths {
            try FileManager.default.createSymbolicLink(
                at: destination.appendingPathComponent(path.lastPathComponent),
                withDestinationURL: path
            )
        }
    }
}

struct SetPermissions {
    let path: URL
    let permissions: Int

    init(arguments: [String]) throws {
        let positionals = arguments.filter { !$0.hasPrefix("-") }
        guard positionals.count == 2, let parsed = Int(positionals[1]) else {
            throw StringError("set-permissions requires <path> <permissions>")
        }
        path = URL(fileURLWithPath: positionals[0])
        permissions = parsed
    }

    func run() throws {
        guard permissions >= 0 && permissions <= 0o7777 else {
            throw StringError("Permissions must be between 0000 and 7777")
        }
        try FileManager.default.setAttributes([.posixPermissions: permissions], ofItemAtPath: path.path)
    }
}

private func ensureFileContentIsUnlocked(_ path: URL) throws {
    var buffer = stat()
    guard lstat(path.path, &buffer) == 0 else {
        throw StringError(String(cString: strerror(errno)))
    }
    if (buffer.st_flags & UInt32(UF_IMMUTABLE)) != 0 {
        throw StringError("文件已锁定，系统禁止修改其内容。")
    }
}

struct WriteData {
    let path: URL

    init(arguments: [String]) throws {
        let positionals = arguments.filter { !$0.hasPrefix("-") }
        guard positionals.count == 1 else {
            throw StringError("write-data requires <path>")
        }
        path = URL(fileURLWithPath: positionals[0])
    }

    func run() throws {
        try ensureFileContentIsUnlocked(path)
        let data = FileHandle.standardInput.readDataToEndOfFile()
        try data.write(to: path, options: .atomic)
    }
}

struct WriteString {
    let string: String
    let path: URL

    init(arguments: [String]) throws {
        let positionals = SantanderCommandParser.positional(arguments, excluding: ["--path"])
        guard positionals.count == 1 else {
            throw StringError("write-string requires exactly one string argument")
        }
        string = positionals[0]
        path = try SantanderCommandParser.requiredURL(arguments, flag: "--path")
    }

    func run() throws {
        try ensureFileContentIsUnlocked(path)
        try string.write(to: path, atomically: true, encoding: .utf8)
    }
}

struct Compress {
    let paths: [URL]
    let destination: URL
    let format: Compression.FormatType

    init(arguments: [String]) throws {
        let pathValues = try SantanderCommandParser.arguments(arguments, after: "--paths")
        guard !pathValues.isEmpty else {
            throw StringError("compress requires at least one --paths value")
        }
        paths = try SantanderCommandParser.urls(pathValues, label: "path")
        destination = try SantanderCommandParser.requiredURL(arguments, flag: "--destination")

        switch try SantanderCommandParser.single(arguments, flag: "--format") ?? "zip" {
        case "zip":
            format = .zip
        case "tar":
            format = .tar
        default:
            throw StringError("Compression format must be zip or tar")
        }
    }

    func run() throws {
        try Compression.shared.compress(paths: paths, outputPath: destination, format: format)
    }
}

struct Decompress {
    let path: URL
    let destination: URL

    init(arguments: [String]) throws {
        let positionals = SantanderCommandParser.positional(arguments, excluding: ["--destination"])
        guard positionals.count == 1 else {
            throw StringError("decompress requires <path>")
        }
        path = URL(fileURLWithPath: positionals[0])
        destination = try SantanderCommandParser.requiredURL(arguments, flag: "--destination")
    }

    func run() throws {
        try Compression.shared.extract(path: path, to: destination)
    }
}

struct ExtractCatalog {
    let path: URL
    let destination: URL

    init(arguments: [String]) throws {
        let positionals = SantanderCommandParser.positional(arguments, excluding: ["--destination"])
        guard positionals.count == 1 else {
            throw StringError("extract-catalog requires <path>")
        }
        path = URL(fileURLWithPath: positionals[0])
        destination = try SantanderCommandParser.requiredURL(arguments, flag: "--destination")
    }

    func run() throws {
        let (_, renditions) = try AssetCatalogWrapper.shared.renditions(forCarArchive: path)
        let codable = renditions.flatMap(\.renditions).toCodable()

        try FileManager.default.createDirectory(at: destination, withIntermediateDirectories: true)
        var failedItems: [String: String] = [:]
        for rend in codable {
            let newURL = destination.appendingPathComponent(rend.renditionName)
            if let data = rend.itemData {
                do {
                    try data.write(to: newURL)
                } catch {
                    failedItems[rend.renditionName] = "Unable to write item data to file: \(error.localizedDescription)"
                }
            }
        }

        if !failedItems.isEmpty {
            let message = failedItems.map { "\($0.key): \($0.value)" }.joined(separator: "\n")
            throw StringError(message.trimmingCharacters(in: .whitespacesAndNewlines))
        }
    }
}

struct GetContents {
    let path: URL

    init(arguments: [String]) throws {
        let positionals = arguments.filter { !$0.hasPrefix("-") }
        guard positionals.count == 1 else {
            throw StringError("get-contents requires <path>")
        }
        path = URL(fileURLWithPath: positionals[0])
    }

    func run() throws {
        let contents = try FileManager.default.contentsOfDirectory(at: path, includingPropertiesForKeys: nil)
        let output = contents.map(\.path).joined(separator: "\n")
        FileHandle.standardOutput.write(Data(output.utf8))
        if !output.isEmpty {
            FileHandle.standardOutput.write(Data("\n".utf8))
        }
    }
}

struct RootHelperProgram {
    static func main() throws {
        try main(ProcessInfo.processInfo.arguments.dropFirst().map { String($0) })
    }

    static func main(_ arguments: [String]) throws {
        guard let command = arguments.first?.lowercased() else {
            SantanderCommandParser.printUsage()
            return
        }

        let commandArguments = Array(arguments.dropFirst())

        switch command {
        case "create":
            try Create(arguments: commandArguments).run()
        case "delete":
            try Delete(arguments: commandArguments).run()
        case "move":
            try Move(arguments: commandArguments).run()
        case "copy":
            try Copy(arguments: commandArguments).run()
        case "link":
            try Link(arguments: commandArguments).run()
        case "rename":
            try Rename(arguments: commandArguments).run()
        case "set-owner-or-group":
            try SetOwnerOrGroup(arguments: commandArguments).run()
        case "set-locked":
            try SetLocked(arguments: commandArguments).run()
        case "set-permissions":
            try SetPermissions(arguments: commandArguments).run()
        case "compress":
            try Compress(arguments: commandArguments).run()
        case "decompress":
            try Decompress(arguments: commandArguments).run()
        case "extract-catalog":
            try ExtractCatalog(arguments: commandArguments).run()
        case "write-data":
            try WriteData(arguments: commandArguments).run()
        case "write-string":
            try WriteString(arguments: commandArguments).run()
        case "get-contents":
            try GetContents(arguments: commandArguments).run()
        case "help", "--help", "-h":
            SantanderCommandParser.printUsage()
        default:
            throw StringError("Unknown root-helper command: \(command)")
        }
    }
}

extension URL {

    func regularFileAllocatedSize() throws -> UInt64 {
        let resourceValues = try self.resourceValues(forKeys: allocatedSizeResourceKeys)
        guard resourceValues.isRegularFile ?? false else {
            return 0
        }
        return UInt64(resourceValues.totalFileAllocatedSize ?? resourceValues.fileAllocatedSize ?? 0)
    }

    var contents: [URL] {
        if !isReadable {
            return (try? RootConf.shared.contents(of: resolvedURL)) ?? []
        }
        let _contents = try? FileManager.default.contentsOfDirectory(at: self.resolvedURL, includingPropertiesForKeys: [])
        return _contents ?? []
    }

    var isDirectory: Bool {
        return (try? resolvedURL.resourceValues(forKeys: [.isDirectoryKey]).isDirectory) ?? false
    }

    var creationDate: Date? {
        try? resourceValues(forKeys: [.creationDateKey]).creationDate
    }

    var lastModifiedDate: Date? {
        try? resourceValues(forKeys: [.contentModificationDateKey]).contentModificationDate
    }

    var lastAccessedDate: Date? {
        try? resourceValues(forKeys: [.contentAccessDateKey]).contentAccessDate
    }

    var addedToDirectoryDate: Date? {
        try? resourceValues(forKeys: [.addedToDirectoryDateKey]).addedToDirectoryDate
    }

    var size: Int? {
        if isDirectory {
            var _size: Int = 0
            for content in contents {
                _size += content.size ?? 0
            }
            return _size
        }
        return try? resourceValues(forKeys: [.fileSizeKey]).fileSize
    }

    var contentType: UTType? {
        return try? resourceValues(forKeys: [.contentTypeKey]).contentType
    }

    var displayName: String {
        return FileManager.default.displayName(atPath: self.path)
    }

    var resolvedURL: URL {
        return (try? URL(resolvingAliasFileAt: self)) ?? self
    }

    static let root: URL = URL(fileURLWithPath: "/")
    static let home: URL = URL(fileURLWithPath: NSHomeDirectory())

    var isSymlink: Bool {
        return (try? FileManager.default.destinationOfSymbolicLink(atPath: self.path)) != nil
    }

    var isReadable: Bool {
        return FileManager.default.isReadableFile(atPath: self.path)
    }

    func setPermissions(forOwner owner: Permission, group: Permission = [], others: Permission = []) throws {
        let octal = Permission.octalRepresentation(of: [owner, group, others])
        try FSOperation.perform(.setPermissions(url: self, newOctalPermissions: octal), rootHelperConf: RootConf.shared)
    }

    func fullPathComponents() -> [URL] {
        var arr: [URL] = []
        let components = self.pathComponents
        for indx in components.indices {
            let item = components[components.startIndex...indx]
                .joined(separator: "/")
                .replacingOccurrences(of: "//", with: "/")
            if item.isEmpty {
                continue
            }
            arr.append(URL(fileURLWithPath: item))
        }
        return arr
    }

    var containsAppUUIDSubpaths: Bool {
        return pathComponents.contains("Containers") || pathComponents.contains("containers")
    }

    var applicationItem: SantanderApplication? {
        if self.pathExtension == "app" {
            return ApplicationsManager.shared.application(forBundleURL: self)
        }
        return ApplicationsManager.shared.application(forContainerURL: self) ?? ApplicationsManager.shared.application(forDataContainerURL: self)
    }
}

#if targetEnvironment(simulator)
fileprivate let applicationPaths: [String] = [URL.home.deletingLastPathComponent().path]
#else
fileprivate let applicationPaths: [String] = [
    "/private/var/containers/Bundle/Application",
    "/private/var/mobile/Containers/Data",
    "/private/var/mobile/Containers/Data/Application"
]
#endif

extension UIViewController {
    func errorAlert(
        _ errorDescription: String?,
        title: String,
        presentingFromIfAvailable presentingVC: UIViewController? = nil,
        cancelAction: UIAlertAction = .cancel(title: SantanderL10n.t("OK"))
    ) {
        var message: String? = nil
        if let errorDescription = errorDescription {
            message = SantanderL10n.t("Error occurred: \(errorDescription)")
        }

        let alert = UIAlertController(title: SantanderL10n.t(title), message: message, preferredStyle: .alert)
        alert.addAction(cancelAction)
        let vcToPresentFrom = presentingVC ?? self
        vcToPresentFrom.present(alert, animated: true)
    }

    func errorAlert(
        _ error: Error,
        title: String,
        presentingFromIfAvailable presentingVC: UIViewController? = nil,
        cancelAction: UIAlertAction = .cancel(title: SantanderL10n.t("OK"))
    ) {
        self.errorAlert(error.localizedDescription, title: title, presentingFromIfAvailable: presentingVC, cancelAction: cancelAction)
    }

    func configureNavigationBarToNormal() {
        let navigationBarAppearance = UINavigationBarAppearance()
        navigationBarAppearance.configureWithDefaultBackground()
        navigationController?.navigationBar.compactAppearance = navigationBarAppearance
        navigationController?.navigationBar.scrollEdgeAppearance = navigationBarAppearance
    }

    func presentActivityVC(forItems items: [Any]) {
        let vc = UIActivityViewController(activityItems: items, applicationActivities: nil)
        vc.popoverPresentationController?.sourceView = view
        let bounds = view.bounds

        vc.popoverPresentationController?.sourceRect = CGRect(x: bounds.midX, y: bounds.midY, width: 0, height: 0)
        self.present(vc, animated: true)
    }

    func createAlertWithSpinner(title: String, message: String? = nil, heightAnchorConstant: CGFloat = 95) -> UIAlertController {
        let alertController = UIAlertController(title: title, message: message, preferredStyle: .alert)
        let spinner = UIActivityIndicatorView()
        spinner.translatesAutoresizingMaskIntoConstraints = false
        spinner.startAnimating()
        alertController.view.addSubview(spinner)

        NSLayoutConstraint.activate([
            alertController.view.heightAnchor.constraint(equalToConstant: heightAnchorConstant),
            spinner.centerXAnchor.constraint(equalTo: alertController.view.centerXAnchor),
            spinner.bottomAnchor.constraint(equalTo: alertController.view.bottomAnchor, constant: -20),
        ])

        return alertController
    }

    func saveImage(_ image: UIImage) {
        UIImageWriteToSavedPhotosAlbum(image, self, #selector(didSaveImage(_:error:context:)), nil)
    }

    @objc
    func didSaveImage(_ im: UIImage, error: Error?, context: UnsafeMutableRawPointer?) {
        if let error = error {
            errorAlert(error, title: SantanderL10n.t("Unable to save image"))
        }
    }
}

extension UIMenu {
    func appending(_ element: UIMenuElement) -> UIMenu {
        var children = self.children
        children.append(element)
        return self.replacingChildren(children)
    }
}

extension UIAlertAction {
    static func cancel(title: String = "Cancel", handler: (() -> Void)? = nil) -> UIAlertAction {
        UIAlertAction(title: SantanderL10n.t(title), style: .cancel) { _ in
            handler?()
        }
    }
}

extension FileManager {

    func allocatedSizeOfDirectory(at directoryURL: URL) throws -> UInt64 {

        var enumeratorError: Error? = nil
        func errorHandler(_: URL, error: Error) -> Bool {
            enumeratorError = error
            return false
        }

        let enumerator = self.enumerator(at: directoryURL,
                                         includingPropertiesForKeys: Array(allocatedSizeResourceKeys),
                                         options: [],
                                         errorHandler: errorHandler)!

        var accumulatedSize: UInt64 = 0

        for item in enumerator {
            if enumeratorError != nil { break }

            let contentItemURL = item as! URL
            accumulatedSize += try contentItemURL.regularFileAllocatedSize()
        }

        if let error = enumeratorError { throw error }

        return accumulatedSize
    }
}

fileprivate let allocatedSizeResourceKeys: Set<URLResourceKey> = [
    .isRegularFileKey,
    .fileAllocatedSizeKey,
    .totalFileAllocatedSizeKey,
]

extension NSNotification.Name {
    static var pathGroupsDidChange: NSNotification.Name {
        return NSNotification.Name("pathGroupsDidChange")
    }
}

extension Date {
    func listFormatted() -> String {
        if #available(iOS 15.0, *) {
            return self.formatted(date: .long, time: .shortened)
        } else {
            let dateFormatter = DateFormatter()
            dateFormatter.dateStyle = .long
            dateFormatter.timeStyle = .short
            return dateFormatter.string(from: self)
        }
    }
}

extension Collection {
    subscript(safe safeIndex: Index) -> Element? {
        return self.indices.contains(safeIndex) ? self[safeIndex] : nil
    }
}

extension UTType {

    public static func generictypes() -> [UTType] {
        return [
            .content,
            .image,
            .video,
            .text,
            .audio,
            .movie,
            .sourceCode,
            .executable
        ]
    }

    public static func audioTypes() -> [UTType] {
        return [
            .mp3,
            .aiff,
            .wav,
            .midi
        ]
    }

    public static func programmingTypes() -> [UTType] {
        var arr: [UTType] = [
            .swiftSource,
            .assemblyLanguageSource,

            .cSource,
            .objectiveCSource,
            .objectiveCPlusPlusSource,
            .cPlusPlusSource,

            .cHeader,
            .cPlusPlusHeader,

            .script,
            .shellScript,
            .javaScript,
            .pythonScript,
            .rubyScript,
            .perlScript,
            .phpScript
        ]

        if #available(iOS 15.0, *) {
            arr.append(.makefile)
        }

        return arr
    }

    public static func compressedFormatTypes() -> [UTType] {
        return [
            .zip,
            .gzip,
            .bz2
        ]
    }

    public static func imageTypes() -> [UTType] {
        return [
            .png,
            .gif,
            .jpeg,
            .webP,
            .tiff,
            .bmp,
            .svg,
            .heif
        ]
    }

    public static func documentTypes() -> [UTType] {
        return [
            .json,
            .yaml,
            .rtf,
            .xml,
            .propertyList,
            .pdf
        ]
    }

    public static func systemTypes() -> [UTType] {
        return [
            .bundle,
            .application,
            .framework,
            .log,
            .database,
            .diskImage,
            .package
        ]
    }

    public static func executableTypes() -> [UTType] {
        return [
            .executable,
            UTType(filenameExtension: "dylib")
        ]
        .compactMap { $0 }
    }

    func isOfType(_ type: UTType) -> Bool {
        return type == self || self.isSubtype(of: type)
    }
}

extension UITableViewController {
    func indexPaths(forSection section: Int) -> [IndexPath] {
        let allRows = self.tableView(tableView, numberOfRowsInSection: section)
        return (0..<allRows).map { row in
            return IndexPath(row: row, section: section)
        }
    }

    func cellWithView(_ view: UIView, text: String, rightAnchorConstant: CGFloat = -20) -> UITableViewCell {
        let cell = UITableViewCell()
        var conf = cell.defaultContentConfiguration()
        conf.text = text
        cell.contentConfiguration = conf
        view.translatesAutoresizingMaskIntoConstraints = false
        cell.contentView.addSubview(view)

        NSLayoutConstraint.activate([
            view.rightAnchor.constraint(equalTo: cell.contentView.rightAnchor, constant: rightAnchorConstant),
            view.centerYAnchor.constraint(equalTo: cell.contentView.centerYAnchor)
        ])

        return cell
    }

    func sectionHeaderWithButton(
        sectionTag: Int,
        titleText: String?,
        buttonCustomization: (UIButton) -> Void
    ) -> UIView {
        let view = UIView()
        let label = UILabel()
        let button = UIButton()
        buttonCustomization(button)

        button.tag = sectionTag

        label.text = titleText
        label.font = .systemFont(ofSize: 18, weight: .bold)

        label.translatesAutoresizingMaskIntoConstraints = false
        button.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(label)
        view.addSubview(button)

        NSLayoutConstraint.activate([
            label.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 10),
            label.topAnchor.constraint(equalTo: view.topAnchor, constant: 10),

            button.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -5),
            button.topAnchor.constraint(equalTo: view.topAnchor, constant: 5),
        ])

        return view
    }

    func seperatorFooterView() -> UIView {
        let result = UIView()
        let insets = tableView.separatorInset
        let width = tableView.bounds.width - insets.left - insets.right
        let sepFrame = CGRect(x: insets.left, y: -0.5, width: width, height: 0.5)

        let sep = CALayer()
        sep.frame = sepFrame
        sep.backgroundColor = tableView.separatorColor?.cgColor
        result.layer.addSublayer(sep)

        return result
    }

    func deleteURL(_ path: Path, completionHandler: @escaping (Bool) -> Void) {
        let confirmationController = UIAlertController(title: "确定要删除「\(path.lastPathComponent)」吗？", message: nil, preferredStyle: .alert)
        let deleteAction = UIAlertAction(title: SantanderL10n.t("Delete"), style: .destructive) { _ in
            do {
                try FSOperation.perform(.removeItems(items: [path.url]), rootHelperConf: RootConf.shared)
                completionHandler(true)
            } catch {
                self.errorAlert(error, title: "删除「\(path.lastPathComponent)」失败")
                completionHandler(false)
            }
        }

        let cancelAction: UIAlertAction = .cancel {
            completionHandler(false)
        }

        confirmationController.addAction(deleteAction)
        confirmationController.addAction(cancelAction)
        self.present(confirmationController, animated: true)
    }
}

extension UIImage {
    func imageWith(newSize: CGSize) -> UIImage {
        let image = UIGraphicsImageRenderer(size: newSize).image { _ in
            draw(in: CGRect(origin: .zero, size: newSize))
        }
        return image.withRenderingMode(renderingMode)
    }
}

extension UIAction {
    convenience init(withClosure closure: @escaping () -> Void) {
        self.init { _ in
            closure()
        }
    }
}

extension Optional: Comparable where Wrapped: Comparable {
    public static func < (lhs: Optional, rhs: Optional) -> Bool {
        guard let lhs = lhs, let rhs = rhs else {
            return false
        }
        return lhs < rhs
    }
}

extension UITableView.Style: CaseIterable, CustomStringConvertible {
    static var userPreferred: UITableView.Style {
        return UITableView.Style(rawValue: UserPreferences.preferredTableViewStyle) ?? .insetGrouped
    }

    public static var allCases: [UITableView.Style] = [.insetGrouped, .grouped, .plain]

    public var description: String {
        switch self {
        case .plain:
            return SantanderL10n.t("Plain")
        case .grouped:
            return SantanderL10n.t("Grouped")
        case .insetGrouped:
            return SantanderL10n.t("Inset Grouped")
        @unknown default:
            return SantanderL10n.t("Unknown Mode")
        }
    }
}

extension Array where Element: OptionSet {
    func reducingToSingleOptionSet() -> Element {
        return self.reduce(Element()) { return $0.union($1) }
    }
}

extension passwd {
    init?(fileURLOwner fileURL: URL) {
        var buffer = stat()
        guard lstat(fileURL.path, &buffer) == 0, let pwd = getpwuid(buffer.st_uid)?.pointee else {
            return nil
        }
        self = pwd
    }
}

extension UIUserInterfaceStyle: CaseIterable {
    public static var allCases: [UIUserInterfaceStyle] = [.unspecified, .dark, .light]
    var description: String {
        switch self {
        case .unspecified:
            return SantanderL10n.t("System")
        case .light:
            return SantanderL10n.t("Light")
        case .dark:
            return SantanderL10n.t("Dark")
        @unknown default:
            return SantanderL10n.t("Unknown Mode")
        }
    }
}

extension UITableViewCell {
    func colorCircleAccessoryView(color: UIColor) -> UIView {
        let colorPreview = UIView(frame: CGRect(x: 0, y: 0, width: 29, height: 29))
        colorPreview.backgroundColor = color
        colorPreview.layer.cornerRadius = colorPreview.frame.size.width / 2
        colorPreview.layer.borderWidth = 1.5
        colorPreview.layer.borderColor = UIColor.systemGray.cgColor

        return colorPreview
    }
}

extension Dictionary where Key == String, Value == SerializedItemType {
    func asAnyDictionary() -> [String: Any] {
        var dict: [String: Any] = [:]
        for (key, value) in self {
            dict[key] = value.representedObject
        }
        return dict
    }
}

extension Dictionary where Key == String, Value == Any {
    func asSerializedDictionary() -> SerializedDictionaryType {
        var dict: SerializedDictionaryType = [:]
        for (key, value) in self {
            dict[key] = SerializedItemType(item: value)
        }
        return dict
    }
}

extension UIDevice {
    static let isiPad = current.userInterfaceIdiom == .pad
}

extension DateFormatter {
    static let EXIFDateFormatter = DateFormatter(withFormat: "yyyy:MM:dd HH:mm:ss")
    static let IPTCDateFormatter = DateFormatter(withFormat: "yyyyMMdd")

    convenience init(withFormat dateFormat: String) {
        self.init()
        self.dateFormat = dateFormat
    }
}

extension UIApplication {
    var sceneKeyWindow: UIWindow? {
        return UIApplication.shared
        .connectedScenes
        .flatMap { ($0 as? UIWindowScene)?.windows ?? [] }
        .first { $0.isKeyWindow }
    }
}

extension CTFontDescriptor {
    var uiFont: UIFont {
        return CTFontCreateWithFontDescriptor(self, UserPreferences.fontViewerFontSize, nil) as UIFont
    }
}

extension UIPasteboard {
    var probableURL: URL? {
        if let url = url { return url }
        if let string = string, string.hasPrefix("/") { return URL(fileURLWithPath: string) }
        return nil
    }
}

extension UIApplication {
    func setShortcutItems<URLCollection: Collection<Path>>(intoURLs urls: URLCollection) {
        shortcutItems = urls.map { bookmark in
            return UIApplicationShortcutItem(type: bookmark.url.absoluteString,
                                             localizedTitle: bookmark.lastPathComponent,
                                             localizedSubtitle: bookmark.path,
                                             icon: nil,
                                             userInfo: ["ShortcutURLToOpenTo": bookmark.path] as [String: NSSecureCoding])
        }
    }
}

extension Array<Path> {
    func toURL() -> [URL] {
        map(\.url)
    }
}


@main
class AppDelegate: UIResponder, UIApplicationDelegate {

    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        var glassConfiguration = LegacyLiquidGlass.configuration
        glassConfiguration.backend = .automatic
        glassConfiguration.adaptiveQuality = true
        glassConfiguration.sharedSurface = true
        LegacyLiquidGlass.configuration = glassConfiguration
        LLGlassBootstrap.start()

        if UserPreferences.displayRecentlyBookmarked {
            application.setShortcutItems(intoURLs: UserPreferences.bookmarks)
        } else {
            application.shortcutItems = []
        }
        
        return true
    }


    func application(_ application: UIApplication, configurationForConnecting connectingSceneSession: UISceneSession, options: UIScene.ConnectionOptions) -> UISceneConfiguration {
        return UISceneConfiguration(name: "Default Configuration", sessionRole: connectingSceneSession.role)
    }

    func application(_ application: UIApplication, didDiscardSceneSessions sceneSessions: Set<UISceneSession>) {
    }


}


class SceneDelegate: UIResponder, UIWindowSceneDelegate {
    
    var window: UIWindow?
    var visibleSubPathsVc: PathListViewController? {
        (window?.rootViewController as? UINavigationController)?.visibleViewController as? PathListViewController
    }
    
    func performShortcut(_ shortcut: UIApplicationShortcutItem) {
        switch shortcut.type {
        case "com.Antoine.santander.bookmarks":
            let vc = UINavigationController(rootViewController: PathListViewController.bookmarks())
            window?.rootViewController?.present(vc, animated: true)
        default:
            if let pathToTopenTo = shortcut.userInfo?["ShortcutURLToOpenTo"] as? String {
                visibleSubPathsVc?.goToPath(path: Path(stringLiteral: pathToTopenTo))
            }
        }
    }
    
    func windowScene(_ windowScene: UIWindowScene,performActionFor shortcutItem: UIApplicationShortcutItem, completionHandler: @escaping (Bool) -> Void) {
        self.performShortcut(shortcutItem)
        completionHandler(true)
    }
    
    func scene(_ scene: UIScene, willConnectTo session: UISceneSession, options connectionOptions: UIScene.ConnectionOptions) {
        guard let windowScene = (scene as? UIWindowScene) else { return }
        
        let subPathsVC: PathTransitioning
        let window = UIWindow(windowScene: windowScene)
        if UIDevice.isiPad {
            let splitVC = UISplitViewController(style: .doubleColumn)
            let vc = PathSidebarListViewController()
            subPathsVC = vc
            splitVC.setViewController(vc, for: .primary)
            window.rootViewController = splitVC
        } else {
            let vc = PathListViewController(style: .userPreferred, path: .root)
            subPathsVC = vc
            window.rootViewController = UINavigationController(rootViewController: vc)
        }
        
        DispatchQueue.main.async {
            window.tintColor = UserPreferences.appTintColor.uiColor
            window.overrideUserInterfaceStyle = UIUserInterfaceStyle(rawValue: UserPreferences.preferredInterfaceStyle) ?? .unspecified
        }
        
        self.window = window
        // Install the single screen-level glass before the first visible frame.
        SantanderGlass.installBackgroundIfNeeded(in: window)
        
        (window.rootViewController as? UISplitViewController)?.show(.primary)
        if let launchPath = UserPreferences.launchPath,
            FileManager.default.fileExists(atPath: launchPath) {
            subPathsVC.goToPath(path: Path(stringLiteral: launchPath))
        }
        
        window.makeKeyAndVisible()
        self.scene(scene, openURLContexts: connectionOptions.urlContexts)
        if let shortcut = connectionOptions.shortcutItem {
            self.performShortcut(shortcut)
        }
    }
    
    func sceneDidDisconnect(_ scene: UIScene) {
    }
    
    func sceneDidBecomeActive(_ scene: UIScene) {
        if let window { LegacyLiquidGlass.sceneDidChange(in: window) }
    }
    
    func sceneWillResignActive(_ scene: UIScene) {
    }
    
    func sceneWillEnterForeground(_ scene: UIScene) {
        if let window { LegacyLiquidGlass.sceneDidChange(in: window) }
    }
    
    func sceneDidEnterBackground(_ scene: UIScene) {
    }
    
    
    func scene(_ scene: UIScene, openURLContexts URLContexts: Set<UIOpenURLContext>) {
        let urls = URLContexts.map { ctx in
            URL(fileURLWithPath: ctx.url.path)
        }
        guard !urls.isEmpty else {
            return
        }
  
        let alertController = UIAlertController(title: SantanderL10n.t("URL(s) being imported to app, would you like to copy it to another path?"), message: nil, preferredStyle: .alert)
        let copyAction = UIAlertAction(title: SantanderL10n.t("Copy Path"), style: .default) { _ in
            self.window?.rootViewController?.present(UINavigationController(rootViewController: PathOperationViewController(paths: urls, operationType: .import)), animated: true)
        }
        
        alertController.addAction(copyAction)
        if urls.count == 1 {
            let viewItemAction = UIAlertAction(title: SantanderL10n.t("View item"), style: .default) { _ in
                let item = urls[0]
                let itemParentPath = item.deletingLastPathComponent()
                let rootVC = self.window?.rootViewController as? UINavigationController
                let vcToPush = PathListViewController(path: Path(url: itemParentPath))
                rootVC?.pushViewController(vcToPush, animated: true) {
                    vcToPush.selectPathWhenLoaded(Path(url: item))
                }
            }
            
            alertController.addAction(viewItemAction)
        }
        
        alertController.addAction(.cancel())
        window?.rootViewController?.present(alertController, animated: true)
        
    }
}

fileprivate extension UINavigationController {
    func pushViewController(_ viewController: UIViewController, animated: Bool, completion: @escaping (() -> Void)) {
        pushViewController(viewController, animated: animated)
        
        guard animated, let coordinator = transitionCoordinator else {
            completion()
            return
        }
        
        coordinator.animate(alongsideTransition: nil) { _ in completion() }
    }
}


class AppInfoViewController: UITableViewController {
    let app: SantanderApplication
    let subPathsSender: PathListViewController

    init(style: UITableView.Style, app: SantanderApplication, subPathsSender: PathListViewController) {
        self.app = app
        self.subPathsSender = subPathsSender
        super.init(style: style)
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        applySantanderGlass()
        navigationItem.titleView = UIImageView(image: ApplicationsManager.shared.icon(forApplication: app))
    }

    override func numberOfSections(in tableView: UITableView) -> Int {
        return 5
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        switch section {
        case 0:
            return app.claimedURLSchemes.isEmpty ? 4 : 5
        case 1:
            return 2
        case 2:
            return 4
        case 3:
            return 2
        case 4:
            return 2
        default:
            fatalError("Unknown section! \(section)")
        }
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = UITableViewCell(style: .value1, reuseIdentifier: nil)
        var conf = cell.defaultContentConfiguration()

        defer {
            cell.contentConfiguration = conf
        }

        switch (indexPath.section, indexPath.row) {
        case (0, 0):
            conf.text = SantanderL10n.t("Name")
            conf.secondaryText = app.localizedName
        case (0, 1):
            conf.text = SantanderL10n.t("Bundle ID")
            conf.secondaryText = app.applicationIdentifier
        case (0, 2):
            conf.text = SantanderL10n.t("SDK Version")
            conf.secondaryText = app.sdkVersion
        case (0, 3):
            conf.text = SantanderL10n.t("Type")
            conf.secondaryText = app.applicationType
        case (0, 4):
            conf.text = SantanderL10n.t("URL schemes")
            conf.secondaryText = app.claimedURLSchemes.joined(separator: ", ")
        case (1, 0):
            conf.text = SantanderL10n.t("Team ID")
            conf.secondaryText = app.teamID
        case (1, 1):
            conf.text = SantanderL10n.t("Entitlements")
            cell.accessoryType = .disclosureIndicator
        case (2, 0):
            conf.text = SantanderL10n.t("Deletable")
            cell.accessoryType = app.isDeletable ? .checkmark : .none
        case (2, 1):
            conf.text = SantanderL10n.t("Beta app")
            cell.accessoryType = app.isBetaApp ? .checkmark : .none
        case (2, 2):
            conf.text = SantanderL10n.t("Restricted")
            cell.accessoryType = app.isRestricted ? .checkmark : .none
        case (2, 3):
            conf.text = SantanderL10n.t("Containerized")
            cell.accessoryType = app.isContainerized ? .checkmark : .none
        case (3, 0):
            conf.text = SantanderL10n.t("Container URL")
            conf.secondaryText = app.containerURL().path
        case (3, 1):
            conf.text = SantanderL10n.t("Bundle URL")
            conf.secondaryText = app.bundleURL().path
        case (4, 0):
            conf.text = SantanderL10n.t("Open")
            conf.textProperties.color = .systemBlue
        case (4, 1):
            conf.text = SantanderL10n.t("Delete")
            conf.textProperties.color = .systemRed
        default:
            fatalError("Unknown indexPath: \(indexPath)")
        }

        return cell
    }

    override func tableView(_ tableView: UITableView, shouldHighlightRowAt indexPath: IndexPath) -> Bool {
        switch indexPath.section {
        case 3, 4:
            return true
        default:
            return (indexPath.section, indexPath.row) == (1, 1)
        }
    }

    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        switch (indexPath.section, indexPath.row) {
        case (1, 1):
            let dict = app.entitlements.asSerializedDictionary()
            let vc = PlistTreeEditorViewController(rootValue: dict.asAnyDictionary(), format: nil, fileURL: nil, title: SantanderL10n.t("Entitlements"), canEdit: false)
            self.navigationController?.pushViewController(vc, animated: true)
        case (3, 0):
            dismissAndGoToURL(app.containerURL())
        case (3, 1):
            dismissAndGoToURL(app.bundleURL())
        case (4, 0):
            do {
                try ApplicationsManager.shared.openApp(app)
            } catch {
                self.errorAlert(error, title: "无法打开 \(app.localizedName)")
            }
        case (4, 1):
            do {
                try ApplicationsManager.shared.deleteApp(app)
                self.dismiss(animated: true)
                subPathsSender.tableView.reloadData()
            } catch {
                self.errorAlert(error, title: SantanderL10n.t("Unable to delete app"))
            }
        default:
            break
        }
    }

    func dismissAndGoToURL(_ url: URL) {
        self.dismiss(animated: true)
        subPathsSender.goToPath(path: Path(url: url))
    }
}

class FilePreviewDataSource: QLPreviewControllerDataSource {
    func numberOfPreviewItems(in controller: QLPreviewController) -> Int {
        return 1
    }

    func previewController(_ controller: QLPreviewController, previewItemAt index: Int) -> QLPreviewItem {
        return fileURL as QLPreviewItem
    }

    let fileURL: URL

    init(fileURL: URL) {
        self.fileURL = fileURL
    }
}

class SettingsTableViewController: UITableViewController {

    lazy var colorPickerVC: UIColorPickerViewController = {
        let vc = UIColorPickerViewController()
        vc.selectedColor = UserPreferences.appTintColor.uiColor
        vc.delegate = self
        return vc
    }()

    override func viewDidLoad() {
        super.viewDidLoad()
        applySantanderGlass()

        self.title = SantanderL10n.t("Settings")
        self.navigationController?.navigationBar.prefersLargeTitles = false
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    override init(style: UITableView.Style) {
        super.init(style: style)
    }

    override func numberOfSections(in tableView: UITableView) -> Int {
        return 4
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        switch section {
        case 0: return 1
        case 1: return 4
        case 2: return 3
        case 3: return UserPreferences.useLastOpenedPathWhenLaunching ? 1 : 2
        default: fatalError("How'd we get here?")
        }
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        switch (indexPath.section, indexPath.row) {
        case (0, 0):
            return cellWithView(settingsSwitch(forIndexPath: indexPath), text: SantanderL10n.t("Root Helper"))
        case (1, 0):
            return cellWithView(settingsSwitch(forIndexPath: indexPath), text: SantanderL10n.t("Large navigation titles"))
        case (1, 1):
            return cellWithView(settingsSwitch(forIndexPath: indexPath), text: SantanderL10n.t("Always show search bar"))
        case (1, 2):
            return cellWithView(settingsSwitch(forIndexPath: indexPath), text: SantanderL10n.t("Show information button"))
        case (1, 3):
            return cellWithView(settingsSwitch(forIndexPath: indexPath), text: SantanderL10n.t("List recently used items in application shortcuts"))
        case (2, 0):
            let cell = UITableViewCell()
            var conf = cell.defaultContentConfiguration()
            conf.text = SantanderL10n.t("Tint Color")
            cell.contentConfiguration = conf

            cell.accessoryView = cell.colorCircleAccessoryView(color: UserPreferences.appTintColor.uiColor)
            return cell
        case (2, 1):
            return cellWithView(setupStyleButton(), text: SantanderL10n.t("Table View Style"))
        case (2, 2):
            return cellWithView(setupAppearanceButton(), text: SantanderL10n.t("Appearance"))
        case (3, 0):
            return cellWithView(setupLaunchPathButton(), text: SantanderL10n.t("Launch Path"))
        case (3, 1):
            let cell = UITableViewCell(style: .value1, reuseIdentifier: nil)
            var conf = cell.defaultContentConfiguration()
            conf.text = SantanderL10n.t("Custom Launch Path")
            conf.secondaryText = UserPreferences.userPreferredLaunchPath ?? SantanderL10n.t("N/A")
            cell.contentConfiguration = conf
            return cell
        default: fatalError()
        }
    }

    fileprivate func setupAppearanceButton() -> UIButton {
        let button = UIButton()
        let currentStyle = UIUserInterfaceStyle(rawValue: UserPreferences.preferredInterfaceStyle) ?? .unspecified
        button.setTitle(currentStyle.description, for: .normal)
        button.setTitleColor(.systemGray, for: .normal)

        let chosenStyle = UserPreferences.preferredInterfaceStyle
        let actions = UIUserInterfaceStyle.allCases.map { style in
            return UIAction(title: style.description, state: chosenStyle == style.rawValue ? .on : .off) { _ in
                self.view.window?.overrideUserInterfaceStyle = style
                UserPreferences.preferredInterfaceStyle = style.rawValue
                self.tableView.reloadRows(at: [IndexPath(row: 2, section: 2)], with: .fade)
            }
        }

        button.menu = UIMenu(children: actions)
        button.showsMenuAsPrimaryAction = true
        return button
    }

    fileprivate func setupStyleButton() -> UIButton {
        let button = UIButton()
        let selectedStyle = UITableView.Style.userPreferred

        button.setTitle(selectedStyle.description, for: .normal)
        button.setTitleColor(.systemGray, for: .normal)
        let actions = UITableView.Style.allCases.map { style in
            return UIAction(title: style.description, state: selectedStyle == style ? .on : .off) { _ in
                UserPreferences.preferredTableViewStyle = style.rawValue
                self.tableView.reloadRows(at: [IndexPath(row: 1, section: 2)], with: .none)
            }
        }

        button.menu = UIMenu(children: actions)
        button.showsMenuAsPrimaryAction = true
        return button
    }

    fileprivate func setupLaunchPathButton() -> UIButton {
        let button = UIButton()

        let customPathChosen = !UserPreferences.useLastOpenedPathWhenLaunching
        button.setTitle(customPathChosen ? SantanderL10n.t("Custom Path") : SantanderL10n.t("Last Opened Path"), for: .normal)
        button.setTitleColor(.systemGray, for: .normal)

        let lastOpenedPathAction = UIAction(title: SantanderL10n.t("Last Opened Path"), state: UserPreferences.useLastOpenedPathWhenLaunching ? .on : .off) { _ in
            UserPreferences.useLastOpenedPathWhenLaunching = true
            self.tableView.reloadData()
        }

        let otherPathAction = UIAction(title: SantanderL10n.t("Custom Path"), state: customPathChosen ? .on : .off) { _ in
            UserPreferences.useLastOpenedPathWhenLaunching = false
            if UserPreferences.userPreferredLaunchPath == nil {
                self.changeCustomLaunchPathAlert()
            } else {
                self.tableView.reloadData()
            }
        }

        button.menu = UIMenu(children: [lastOpenedPathAction, otherPathAction])
        button.showsMenuAsPrimaryAction = true
        return button
    }

    override func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        switch section {
        case 0: return SantanderL10n.t("Root")
        case 1: return SantanderL10n.t("Views")
        case 2: return SantanderL10n.t("Theming")
        case 3: return SantanderL10n.t("Other")
        default: return nil
        }
    }

    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        switch (indexPath.section, indexPath.row) {
        case (2, 0):
            self.present(colorPickerVC, animated: true)
        case (3, 1):
            self.changeCustomLaunchPathAlert()
        default:
            break
        }
    }

    override func tableView(_ tableView: UITableView, shouldHighlightRowAt indexPath: IndexPath) -> Bool {
        return (indexPath.section, indexPath.row) == (2, 0) || (indexPath.section, indexPath.row) == (3, 1)
    }

    func defaultsKey(forIndexPath indexPath: IndexPath) -> String {
        switch (indexPath.section, indexPath.row) {
        case (0, 0):
            return "RootHelperEnabled"
        case (1, 0):
            return "UseLargeNavTitles"
        case (1, 1):
            return "AlwaysShowSearchBar"
        case (1, 2):
            return "ShowInfoButton"
        case (1, 3):
            return "DisplayRecentlyUsedPathsInAppShortcuts"
        default:
            fatalError()
        }
    }

    fileprivate func changeCustomLaunchPathAlert() {
        let alert = UIAlertController(title: SantanderL10n.t("Path"), message: SantanderL10n.t("Enter the other path you want to be opened at launch"), preferredStyle: .alert)
        alert.addTextField()
        alert.addAction(.cancel())

        let applyAction = UIAlertAction(title: SantanderL10n.t("Add"), style: .default) { _ in
            guard let text = alert.textFields?.first?.text, !text.isEmpty else {
                self.errorAlert(SantanderL10n.t("Input text is invalid or empty"), title: SantanderL10n.t("Unable to set path as Launch Path"))
                return
            }

            let url = URL(fileURLWithPath: text)
            guard url.isDirectory else {
                self.errorAlert(SantanderL10n.t("Path must be a directory"), title: SantanderL10n.t("Unable to set path as Launch Path"))
                return
            }

            UserPreferences.useLastOpenedPathWhenLaunching = false
            UserPreferences.userPreferredLaunchPath = url.path
        }
        alert.addAction(applyAction)
        self.present(alert, animated: true)
    }

    func switchOptionIsEnabled(forIndexPath indexPath: IndexPath) -> Bool {
        switch (indexPath.section, indexPath.row) {
        case (0, 0):
            return UserPreferences.rootHelperIsEnabled
        case (1, 0):
            return UserPreferences.useLargeNavigationTitles
        case (1, 1):
            return UserPreferences.alwaysShowSearchBar
        case (1, 2):
            return UserPreferences.showInfoButton
        case (1, 3):
            return UserPreferences.displayRecentlyBookmarked
        default:
            fatalError("Got unknown index path in \(#function)! IndexPath: \(indexPath)")
        }
    }

    func settingsSwitch(forIndexPath indexPath: IndexPath) -> UISwitch {
        let s = UISwitch()
        s.isOn = switchOptionIsEnabled(forIndexPath: indexPath)
        let action = UIAction { [self] _ in
            if (indexPath.section, indexPath.row) == (0, 0) {
                rootHelperDidClickEnable()
            } else {
                UserDefaults.standard.set(s.isOn, forKey: defaultsKey(forIndexPath: indexPath))
            }
        }

        s.addAction(action, for: .valueChanged)
        return s
    }

    fileprivate func rootHelperDidClickEnable() {
        let context = LAContext()
        if UserPreferences.rootHelperIsEnabled || !context.canEvaluatePolicy(.deviceOwnerAuthentication, error: nil) {
            UserPreferences.rootHelperIsEnabled.toggle()
            return
        }

        context.evaluatePolicy(.deviceOwnerAuthentication, localizedReason: SantanderL10n.t("To enable the Root Helper.")) { didSucceed, error in
            guard didSucceed else {
                DispatchQueue.main.async {
                    self.errorAlert(error?.localizedDescription ?? SantanderL10n.t("Unknown Error"), title: SantanderL10n.t("Unable to authenticate"))
                    self.tableView.reloadRows(at: [IndexPath(row: 0, section: 0)], with: .automatic)
                }
                return
            }

            UserPreferences.rootHelperIsEnabled = true
            DispatchQueue.main.async {
                self.tableView.reloadRows(at: [IndexPath(row: 0, section: 0)], with: .automatic)
            }
        }
    }
}

extension SettingsTableViewController: UIColorPickerViewControllerDelegate {
    func colorPickerViewControllerDidFinish(_ viewController: UIColorPickerViewController) {
        let color = viewController.selectedColor

        DispatchQueue.main.async {
            UserPreferences.appTintColor = CodableColor(color)
            self.view.window?.tintColor = color
            self.tableView.reloadRows(at: [IndexPath(row: 0, section: 2)], with: .fade)
        }
    }
}

class TypesSelectionCollectionViewController: UICollectionViewController {
    typealias DismissHandler = (([UTType]) -> Void)

    typealias Item = DiffableDataSourceItem<Section, UTType>
    typealias DataSource = UICollectionViewDiffableDataSource<Section, Item>
    typealias CellRegistration = UICollectionView.CellRegistration<UICollectionViewListCell, Item>

    var dismissHandler: DismissHandler
    var dataSource: DataSource!
    var selectedTypes: Set<UTType> = [] {
        didSet {
            navigationItem.rightBarButtonItem?.isEnabled = !selectedTypes.isEmpty
        }
    }

    let allItems = TypesCollection.all()

    init(dismissHandler: @escaping DismissHandler) {
        self.dismissHandler = dismissHandler

        let layout = UICollectionViewCompositionalLayout { _, env in
            var layoutConf = UICollectionLayoutListConfiguration(appearance: .insetGrouped)
            layoutConf.headerMode = .firstItemInSection
            return NSCollectionLayoutSection.list(using: layoutConf, layoutEnvironment: env)
        }

        super.init(collectionViewLayout: layout)
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    override func viewDidLoad() {
        title = SantanderL10n.t("Types")

        let cancelAction = UIAction {
            self.selectedTypes = []
            self.dismiss(animated: true)
        }

        let doneAction = UIAction {
            self.dismiss(animated: true)
        }

        let searchController = UISearchController()
        searchController.searchBar.delegate = self
        navigationItem.searchController = searchController
        navigationItem.hidesSearchBarWhenScrolling = false

        navigationItem.leftBarButtonItem = UIBarButtonItem(systemItem: .cancel, primaryAction: cancelAction)
        let rightBarButton = UIBarButtonItem(systemItem: .done, primaryAction: doneAction)
        rightBarButton.isEnabled = false
        navigationItem.rightBarButtonItem = rightBarButton
        makeDataSource()
    }

    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
        dismissHandler(Array(selectedTypes))
    }

    func makeDataSource() {
        let cellRegistration = CellRegistration { [self] cell, indexPath, itemIdentifier in
            var conf: UIListContentConfiguration
            switch itemIdentifier {
            case .section(let section):
                conf = .sidebarHeader()
                conf.text = section.description
                cell.accessories = [.outlineDisclosure()]
            case .item(let type):
                conf = cell.defaultContentConfiguration()
                conf.text = type.localizedDescription
                cell.accessories = selectedTypes.contains(type) ? [.checkmark()] : []
            }

            cell.contentConfiguration = conf
        }

        self.dataSource = DataSource(collectionView: collectionView) { collectionView, indexPath, itemIdentifier in
            return collectionView.dequeueConfiguredReusableCell(using: cellRegistration, for: indexPath, item: itemIdentifier)
        }

        showItems(fromCollections: allItems)
    }

    func showItems(fromCollections coll: [TypesCollection], animatingDifferences: Bool = false) {
        var snapshot = NSDiffableDataSourceSnapshot<Section, Item>()
        let justSections = coll.map(\.section)
        snapshot.appendSections(justSections)
        dataSource.apply(snapshot, animatingDifferences: false)

        for collection in coll {
            let collectionSection = Item.section(collection.section)
            var section = NSDiffableDataSourceSectionSnapshot<Item>()
            section.append([collectionSection])

            let types = Item.fromItems(collection.types)
            section.append(types, to: collectionSection)
            section.expand([collectionSection])
            dataSource.apply(section, to: collection.section, animatingDifferences: animatingDifferences)
        }
    }

    override func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        collectionView.deselectItem(at: indexPath, animated: false)
        let item = dataSource.itemIdentifier(for: indexPath)!
        switch item {
        case .section(_): break
        case .item(let type):
            if selectedTypes.contains(type) {
                selectedTypes.remove(type)
            } else {
                selectedTypes.insert(type)
            }

            var snapshot = dataSource.snapshot()
            snapshot.reloadItems([.item(type)])
            dataSource.apply(snapshot, animatingDifferences: true)
        }
    }

    enum Section: CustomStringConvertible {
        case generic
        case audio
        case programming
        case archive
        case image
        case document
        case executable
        case systemTypes

        var description: String {
            switch self {
            case .generic:
                return SantanderL10n.t("Generic")
            case .audio:
                return SantanderL10n.t("Audio")
            case .programming:
                return SantanderL10n.t("Programming")
            case .archive:
                return SantanderL10n.t("Archive")
            case .image:
                return SantanderL10n.t("Image")
            case .document:
                return SantanderL10n.t("Document")
            case .executable:
                return SantanderL10n.t("Executable")
            case .systemTypes:
                return SantanderL10n.t("System")
            }
        }
    }

    struct TypesCollection {
        let section: Section
        let types: [UTType]

        static func all() -> [TypesCollection] {
            return [
                TypesCollection(section: .generic, types: UTType.generictypes()),
                TypesCollection(section: .audio, types: UTType.audioTypes()),
                TypesCollection(section: .programming, types: UTType.programmingTypes()),
                TypesCollection(section: .archive, types: UTType.compressedFormatTypes()),
                TypesCollection(section: .image, types: UTType.imageTypes()),
                TypesCollection(section: .document, types: UTType.documentTypes()),
                TypesCollection(section: .systemTypes, types: UTType.systemTypes())
            ]
        }
    }
}

extension TypesSelectionCollectionViewController: UISearchBarDelegate {
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        guard !searchText.isEmpty else {
            showItems(fromCollections: allItems)
            return
        }

        var newCollection: [TypesCollection] = []
        for collection in allItems {
            let filtered = collection.types.filter { type in
                type.localizedDescription?.localizedCaseInsensitiveContains(searchText) ?? false ||
                type.preferredFilenameExtension?.localizedCaseInsensitiveContains(searchText) ?? false
            }

            if !filtered.isEmpty {
                newCollection.append(TypesCollection(section: collection.section, types: filtered))
            }
        }

        showItems(fromCollections: newCollection, animatingDifferences: false)
    }

    func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
        showItems(fromCollections: allItems)
    }
}

class PathPermissionsViewController: UITableViewController {
    var permissions: PathPermissions

    init(style: UITableView.Style = .insetGrouped, permissions: PathPermissions) {
        self.permissions = permissions
        super.init(style: style)
        self.title = SantanderL10n.t("Permissions")
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        applySantanderGlass()
    }

    override func numberOfSections(in tableView: UITableView) -> Int { 4 }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        section == 0 ? 1 : (section == 3 ? 3 : 4)
    }

    override func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        switch section {
        case 0: return SantanderL10n.t("File Attributes")
        case 1: return SantanderL10n.t("Owner")
        case 2: return SantanderL10n.t("Group")
        case 3: return SantanderL10n.t("Other users")
        default: return nil
        }
    }

    override func tableView(_ tableView: UITableView, titleForFooterInSection section: Int) -> String? {
        section == 3 ? permissionSummary : nil
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = UITableViewCell(style: .value1, reuseIdentifier: nil)
        var conf = cell.defaultContentConfiguration()

        if indexPath.section == 0 {
            conf.text = SantanderL10n.t("Locked")
            let toggle = UISwitch()
            toggle.isOn = permissions.isLocked
            toggle.addAction(UIAction { [weak self, weak toggle] _ in
                guard let self, let toggle else { return }
                let requested = toggle.isOn
                let old = self.permissions.isLocked
                toggle.isEnabled = false
                let url = self.permissions.fileURL
                DispatchQueue.global(qos: .utility).async {
                    do {
                        try FSOperation.perform(.setLocked(url: url, locked: requested), rootHelperConf: RootConf.shared)
                        DispatchQueue.main.async {
                            guard let self, let toggle else { return }
                            self.permissions.isLocked = requested
                            toggle.isEnabled = true
                        }
                    } catch {
                        DispatchQueue.main.async {
                            guard let self, let toggle else { return }
                            toggle.setOn(old, animated: true)
                            toggle.isEnabled = true
                            self.errorAlert(error, title: SantanderL10n.t("无法修改文件锁定状态"))
                        }
                    }
                }
            }, for: .valueChanged)
            cell.accessoryView = toggle
            cell.selectionStyle = .none
            cell.contentConfiguration = conf
            return cell
        }

        let isOwner = indexPath.section == 1
        let isGroup = indexPath.section == 2
        let permSet: Permission
        let identityTitle: String
        let identitySubtitle: String
        switch indexPath.section {
        case 1:
            permSet = permissions.ownerPermissions
            identityTitle = SantanderL10n.t("Owner")
            identitySubtitle = "\(permissions.ownerName ?? SantanderL10n.t("Unknown")) · UID \(permissions.ownerID)"
        case 2:
            permSet = permissions.groupPermissions
            identityTitle = SantanderL10n.t("Group")
            identitySubtitle = "\(permissions.groupOwnerName ?? SantanderL10n.t("Unknown")) · GID \(permissions.groupID)"
        default:
            permSet = permissions.otherUsersPermissions
            identityTitle = SantanderL10n.t("Other users")
            identitySubtitle = permissionSummary
        }

        if indexPath.row == 0 && (isOwner || isGroup) {
            conf.text = identityTitle
            conf.secondaryText = identitySubtitle
            cell.accessoryType = .disclosureIndicator
            cell.contentConfiguration = conf
            return cell
        }

        let permissionRow = isOwner || isGroup ? indexPath.row - 1 : indexPath.row
        let perm: Permission = [.read, .write, .execute][permissionRow]
        switch permissionRow {
        case 0: conf.text = SantanderL10n.t("Read")
        case 1: conf.text = SantanderL10n.t("Write")
        default: conf.text = SantanderL10n.t("Execute")
        }
        // Per request: all yes/no states use a checkmark, not text and not Edit mode.
        cell.accessoryType = permSet.contains(perm) ? .checkmark : .none
        cell.selectionStyle = .default
        cell.contentConfiguration = conf
        return cell
    }

    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        defer { tableView.deselectRow(at: indexPath, animated: true) }
        if indexPath.section == 0 { return }

        if (indexPath.section == 1 || indexPath.section == 2) && indexPath.row == 0 {
            let type: PathGroupOwnerViewController.ItemType
            if indexPath.section == 1 {
                type = .owner(id: permissions.ownerID, name: permissions.ownerName)
            } else {
                type = .group(id: permissions.groupID, name: permissions.groupOwnerName)
            }
            let destination = PathGroupOwnerViewController(style: .insetGrouped, type: type, sourceVC: self, fileURL: permissions.fileURL)
            SantanderGlass.prepareForContentTransition(in: self)
            UIView.performWithoutAnimation {
                navigationController?.pushViewController(destination, animated: false)
                navigationController?.view.layoutIfNeeded()
                destination.view.layoutIfNeeded()
            }
            SantanderGlass.finishContentTransition(in: destination)
            return
        }

        let permissionRow = (indexPath.section == 1 || indexPath.section == 2) ? indexPath.row - 1 : indexPath.row
        guard [0, 1, 2].contains(permissionRow) else { return }
        let perm: Permission = [.read, .write, .execute][permissionRow]
        var requestedPermissions = permissions
        switch indexPath.section {
        case 1:
            if requestedPermissions.ownerPermissions.contains(perm) { requestedPermissions.ownerPermissions.remove(perm) }
            else { requestedPermissions.ownerPermissions.insert(perm) }
        case 2:
            if requestedPermissions.groupPermissions.contains(perm) { requestedPermissions.groupPermissions.remove(perm) }
            else { requestedPermissions.groupPermissions.insert(perm) }
        case 3:
            if requestedPermissions.otherUsersPermissions.contains(perm) { requestedPermissions.otherUsersPermissions.remove(perm) }
            else { requestedPermissions.otherUsersPermissions.insert(perm) }
        default: return
        }

        permissions = requestedPermissions
        tableView.reloadRows(at: [indexPath], with: .none)
        let url = requestedPermissions.fileURL
        DispatchQueue.global(qos: .utility).async {
            do {
                try requestedPermissions.apply()
            } catch {
                DispatchQueue.main.async { [weak self] in
                    guard let self else { return }
                    if let fresh = PathPermissions(fileURL: url) { self.permissions = fresh }
                    self.tableView.reloadData()
                    self.errorAlert(error, title: "无法修改「\(url.lastPathComponent)」的权限")
                }
            }
        }
    }

    var permissionSummary: String {
        let values = [permissions.ownerPermissions, permissions.groupPermissions, permissions.otherUsersPermissions]
        let bits = values.map { set -> String in
            let read = set.contains(.read) ? "r" : "-"
            let write = set.contains(.write) ? "w" : "-"
            let execute = set.contains(.execute) ? "x" : "-"
            return read + write + execute
        }.joined()
        let octal = Permission.octalRepresentation(of: values)
        return String(format: "%04o  %@", octal, bits)
    }
}

class GoToView: UIView {
    let xButton = UIButton()
    let searchField = UITextField()

    override init(frame: CGRect) {
        super.init(frame: frame)
        setup()
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    func setup() {
        layer.cornerRadius = 10
        layer.masksToBounds = true

        let glassView = LLGlassView(configuration: SantanderGlass.search)
        glassView.translatesAutoresizingMaskIntoConstraints = false
        insertSubview(glassView, at: 0)
        glassView.constraintCompletely(to: self)

        let glassImage = UIImageView(image: UIImage(systemName: "magnifyingglass")?.applyingSymbolConfiguration(UIImage.SymbolConfiguration(pointSize: 30))?.withTintColor(.systemGray, renderingMode: .alwaysOriginal))
        glassImage.translatesAutoresizingMaskIntoConstraints = false
        glassImage.contentScaleFactor = 1.0
        glassView.glassContentView.addSubview(glassImage)

        searchField.tintColor = .label
        searchField.font = .systemFont(ofSize: 30)
        searchField.translatesAutoresizingMaskIntoConstraints = false
        searchField.placeholder = SantanderL10n.t("Search")
        glassView.glassContentView.addSubview(searchField)

        xButton.translatesAutoresizingMaskIntoConstraints = false
        xButton.setImage(UIImage(systemName: "xmark.circle.fill")?.applyingSymbolConfiguration(UIImage.SymbolConfiguration(pointSize: 30))?.withTintColor(.systemGray, renderingMode: .alwaysOriginal), for: .normal)
        glassView.glassContentView.addSubview(xButton)

        let stackView = UIStackView(arrangedSubviews: [glassImage, searchField, xButton])
        stackView.translatesAutoresizingMaskIntoConstraints = false
        stackView.spacing = 5
        stackView.distribution = .fillProportionally
        glassView.glassContentView.addSubview(stackView)
        NSLayoutConstraint.activate([
            stackView.leadingAnchor.constraint(equalTo: glassView.glassContentView.layoutMarginsGuide.leadingAnchor),
            stackView.trailingAnchor.constraint(equalTo: glassView.glassContentView.layoutMarginsGuide.trailingAnchor),
            stackView.topAnchor.constraint(equalTo: glassView.glassContentView.layoutMarginsGuide.topAnchor, constant: 10)
        ])
        searchField.becomeFirstResponder()
    }
}

extension PathListViewController: UISearchResultsUpdating, UISearchControllerDelegate, UISearchBarDelegate {

    func updateSearchResults(for searchController: UISearchController) {
        updateResults(searchBar: searchController.searchBar)
    }

    func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
        DispatchQueue.main.async { [self] in
            searchItem?.cancel()
            isSearching = false
            displayingSearchSuggestions = false
            reloadTableData()

            setupPermissionDeniedLabelIfNeeded()
        }
    }

    func searchBar(_ searchBar: UISearchBar, selectedScopeButtonIndexDidChange selectedScope: Int) {
        updateResults(searchBar: searchBar)
    }

    @objc
    func updateResults(searchBar: UISearchBar) {
        let selectedScope = searchBar.selectedScopeButtonIndex
        let query = SearchQuery(searchBar: searchBar)

        self.searchItem?.cancel()
        isSearching = true
        guard !query.isEmpty else { return }
        displayingSearchSuggestions = false

        let newWorkItem = DispatchWorkItem(qos: .userInteractive) { [self] in

            switch selectedScope {
            case 0:
                let filtered = unfilteredContents.filter { url in
                    return query.matches(url: url)
                }

                DispatchQueue.main.async {
                    self.setFilteredContents(filtered)
                }

            case 1:
                var snapshot = SnapshotType()
                snapshot.appendSections([0])
                __enumeratePaths(unfilteredContents, withQuery: query, doBreak: { !isSearching }) { [self] path in
                    DispatchQueue.main.async {
                        let row: SubPathsRowItem = .path(path)
                        if !snapshot.itemIdentifiers.contains(row) {
                            snapshot.appendItems([row])
                            self.dataSource.apply(snapshot, animatingDifferences: false)
                        }
                    }
                }
            default:
                break
            }
        }

        self.searchItem = newWorkItem
        DispatchQueue.global(qos: .userInteractive).asyncAfter(
            deadline: .now().advanced(by: .milliseconds(2)),
            execute: newWorkItem
        )
    }

    func presentSearchController(_ searchController: UISearchController) {
        if isEditing {
            setEditing(false, animated: true)
        }

        switchToSearchSuggestions()
        permissionDeniedLabel?.removeFromSuperview()
    }

    private func __enumeratePaths(_ paths: [Path], withQuery query: SearchQuery, doBreak: () -> Bool, handler: (Path) -> ()) {
        for path in paths {
            if doBreak() { break }

            if query.matches(url: path) {
                handler(path)
            }

            if path.isDirectory {
                __enumeratePaths(path.contents, withQuery: query, doBreak: doBreak, handler: handler)
            }
        }
    }

    fileprivate struct SearchQuery {
        let searchText: String
        let conditions: [SearchSuggestion.Condition]
        let isSearchTextEmpty: Bool

        func matches(url: Path) -> Bool {
            let allConditionsSatisfied = conditions.allSatisfy { handler in
                handler(url)
            }

            if isSearchTextEmpty {
                return allConditionsSatisfied
            }

            return url.lastPathComponent.localizedCaseInsensitiveContains(searchText) && allConditionsSatisfied
        }

        var isEmpty: Bool {
            return isSearchTextEmpty && conditions.isEmpty
        }

        init(searchText: String, conditions: [SearchSuggestion.Condition]) {
            self.searchText = searchText
            self.conditions = conditions

            self.isSearchTextEmpty = searchText.isEmpty
        }

        init(searchBar: UISearchBar) {
            self.searchText = searchBar.text ?? ""
            self.conditions = searchBar.searchTextField.tokens.compactMap { $0.representedObject as? SearchSuggestion.Condition }

            self.isSearchTextEmpty = searchText.isEmpty
        }
    }
}

@available(iOS 14.0, *)
struct SearchSuggestion: Hashable {

    typealias Condition = (Path) -> Bool

    var name: String

    let image: UIImage?

    var condition: Condition

    var searchToken: UISearchToken {
        let token = UISearchToken(icon: image, text: name)
        token.representedObject = condition
        return token
    }

    static func displaySearchSuggestions(for indexPath: IndexPath, typesToCheck: [UTType]? = nil) -> SearchSuggestion {
        switch (indexPath.section, indexPath.row) {
        case (0, 0):
            return SearchSuggestion(name: SantanderL10n.t("Type"), image: UIImage(systemName: "menucard")) { url in
                guard let typesToCheck = typesToCheck, let urlType = url.contentType else {
                    return false
                }

                let isSubtype = typesToCheck.contains { type in
                    urlType.isSubtype(of: type)
                }

                return typesToCheck.contains(urlType) || isSubtype
            }

        case (1, 0):
            return SearchSuggestion(name: SantanderL10n.t("File"), image: UIImage(systemName: "doc")) { url in
                return !url.isDirectory
            }
        case (1, 1):
            return SearchSuggestion(name: SantanderL10n.t("Directory"), image: UIImage(systemName: "folder")) { url in
                return url.isDirectory
            }
        case (1, 2):
            return SearchSuggestion(name: SantanderL10n.t("Symbolic Link"), image: UIImage(systemName: "link")) { url in
                return url.url.isSymlink
            }
        case (2, 0):
            return SearchSuggestion(name: SantanderL10n.t("Executable"), image: UIImage(systemName: "terminal")) { url in
                return !url.isDirectory && FileManager.default.isExecutableFile(atPath: url.path)
            }
        case (2, 1):
            return SearchSuggestion(name: SantanderL10n.t("Readable"), image: UIImage(systemName: "book")) { url in
                return url.isReadable
            }
        case (2, 2):
            return SearchSuggestion(name: SantanderL10n.t("Writable"), image: UIImage(systemName: "pencil")) { url in
                return FileManager.default.isWritableFile(atPath: url.path)
            }
        default: fatalError()
        }
    }

    static let searchSuggestionSectionAndRows = [
        IndexPath(row: 0, section: 0),
        IndexPath(row: 0, section: 1), IndexPath(row: 1, section: 1), IndexPath(row: 2, section: 1),
        IndexPath(row: 0, section: 2), IndexPath(row: 1, section: 2), IndexPath(row: 2, section: 2)
    ]

    static func == (lhs: SearchSuggestion, rhs: SearchSuggestion) -> Bool {
        return lhs.name == rhs.name && lhs.image == rhs.image
    }

    func hash(into hasher: inout Hasher) {
        hasher.combine(self.name)
        hasher.combine(self.image)
    }
}

class PathListViewController: UITableViewController, PathTransitioning {

    // Directory enumeration can hit the filesystem (and Root Helper) and must never
    // block the navigation transition on the main thread.
    var unfilteredContents: [Path]

    var filteredSearchContents: [Path] = []

    private var directoryLoadGeneration = UUID()
    private var didStartInitialDirectoryLoad = false
    private var isDirectoryContentsReady = false

    var selectedItems: [Path] = []

    var isSearching: Bool = false

    var contents: [Path] {
        get {
            return filteredSearchContents.isEmpty && !self.isSearching ? unfilteredContents : filteredSearchContents
        }
    }

    var sortMethod: PathsSortMethods = .userPrefered ?? .alphabetically {
        willSet {
            UserDefaults.standard.set(newValue.rawValue, forKey: "SubPathsSortMode")
            sortContents()
        }
    }

    let isBookmarksSheet: Bool

    var currentPath: Path? = nil

    let showInfoButton: Bool = UserPreferences.showInfoButton

    var displayingSearchSuggestions: Bool = false

    var directoryMonitor: DirectoryMonitor?

    var audioPlayerController: AudioPlayerViewController?

    var permissionDeniedLabel: UILabel!

    var displayHiddenFiles: Bool = UserPreferences.displayHiddenFiles {
        didSet {
            reloadTableData()

            UserPreferences.displayHiddenFiles = self.displayHiddenFiles
        }
    }

    var containsAppUUIDs: Bool?

    var searchItem: DispatchWorkItem?

    typealias SnapshotType = NSDiffableDataSourceSnapshot<Int, SubPathsRowItem>
    typealias DataSourceType = UITableViewDiffableDataSource<Int, SubPathsRowItem>
    lazy var dataSource = DataSourceType(tableView: self.tableView) { tableView, indexPath, itemIdentifier in
        switch itemIdentifier {
        case .path(let url):
            return self.pathCellRow(forURL: url, displayFullPathAsSubtitle: self.isSearching || self.isBookmarksSheet)
        case .searchSuggestion(let suggestion):
            return self.searchSuggestionCellRow(suggestion: suggestion)
        }
    }

    class func bookmarks() -> PathListViewController {
        return PathListViewController(
            contents: Array(UserPreferences.bookmarks),
            title: SantanderL10n.t("Bookmarks"),
            isBookmarksSheet: true)
    }

    init(style: UITableView.Style = .userPreferred, path: Path, isBookmarksSheet: Bool = false) {
        // IMPORTANT: do not enumerate the directory here. This initializer is executed
        // on the navigation call stack, so a large directory used to leave the previous
        // folder's UI visible until path.contents finished.
        self.unfilteredContents = []
        self.currentPath = path
        self.isBookmarksSheet = isBookmarksSheet

        super.init(style: style)
        self.title = path.lastPathComponent
    }

    init(style: UITableView.Style = .userPreferred, contents: [Path], title: String, isBookmarksSheet: Bool = false) {
        self.unfilteredContents = self.sortMethod.sorting(URLs: contents, sortOrder: .userPreferred)
        self.isBookmarksSheet = isBookmarksSheet

        super.init(style: style)
        self.title = title
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        applySantanderGlass()

        setRightBarButton()

        // Show the destination controller immediately. The filesystem work happens
        // off the main thread so the old folder's UI is not held on screen.
        showPaths(animatingDifferences: false)
        if let currentPath = self.currentPath {
            loadDirectoryContentsInBackground(for: currentPath)
        }

        self.navigationController?.navigationBar.prefersLargeTitles = UserPreferences.useLargeNavigationTitles
        let searchController = UISearchController(searchResultsController: nil)
        searchController.searchBar.delegate = self
        searchController.obscuresBackgroundDuringPresentation = false
        searchController.searchResultsUpdater = self
        searchController.delegate = self
        self.tableView.keyboardDismissMode = .onDrag
        self.navigationItem.hidesSearchBarWhenScrolling = !UserPreferences.alwaysShowSearchBar
        if let currentPath = currentPath {
            searchController.searchBar.scopeButtonTitles = [currentPath.lastPathComponent, SantanderL10n.t("Subdirectories")]
            setupRefreshControl(forPath: currentPath)

            let pathForFlags = currentPath
            DispatchQueue.global(qos: .utility).async { [weak self] in
                let contains = pathForFlags.containsAppUUIDSubpaths
                DispatchQueue.main.async { [weak self] in
                    guard let self, self.currentPath == pathForFlags else { return }
                    self.containsAppUUIDs = contains
                }
            }
        }
        self.navigationItem.searchController = searchController
#if compiler(>=5.7)
        if #available(iOS 16.0, *), UIDevice.isiPad {
            self.navigationItem.style = .browser
            self.navigationItem.renameDelegate = self
        }
#endif

        tableView.dragInteractionEnabled = true
        tableView.dropDelegate = self
        tableView.dragDelegate = self
        tableView.dataSource = self.dataSource

        setupPermissionDeniedLabelIfNeeded()
    }

    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)

        if let currentPath = self.currentPath {
            if directoryMonitor == nil {
                directoryMonitor = DirectoryMonitor(path: currentPath)
                directoryMonitor?.delegate = self
            }

            directoryMonitor?.startMonitoring()
            UserPreferences.lastOpenedPath = currentPath.path
            SantanderGlass.refreshBackdrop(for: self)
        }
    }

    override var keyCommands: [UIKeyCommand]? {
        return [
            UIKeyCommand(title: SantanderL10n.t("Scroll Up"), action: #selector(scrollUpOrDown(sender:)), input: UIKeyCommand.inputUpArrow, modifierFlags: .command),
            UIKeyCommand(title: SantanderL10n.t("Scroll Down"), action: #selector(scrollUpOrDown(sender:)), input: UIKeyCommand.inputDownArrow, modifierFlags: .command)
        ]
    }

    @objc
    func scrollUpOrDown(sender: UIKeyCommand) {
        switch sender.input {
        case UIKeyCommand.inputDownArrow:
            let snapshot = dataSource.snapshot()
            let indexPathToSrcollTo = IndexPath(row: snapshot.numberOfItems - 1, section: snapshot.numberOfSections - 1)
            tableView.scrollToRow(at: indexPathToSrcollTo, at: .bottom, animated: true)
        case UIKeyCommand.inputUpArrow:
            tableView.scrollToRow(at: IndexPath(row: 0, section: 0), at: .top, animated: true)
        default: break
        }
    }

    private func loadDirectoryContentsInBackground(for path: Path, forceReload: Bool = false) {
        guard path.isDirectory || forceReload else { return }

        if didStartInitialDirectoryLoad && !forceReload && isDirectoryContentsReady {
            return
        }

        didStartInitialDirectoryLoad = true
        isDirectoryContentsReady = false
        directoryLoadGeneration = UUID()
        let generation = directoryLoadGeneration
        let sortMethod = self.sortMethod
        let sortOrder = SortOrder.userPreferred
        let currentControllerPath = path

        DispatchQueue.global(qos: .userInitiated).async { [weak self] in
            guard let self else { return }

            let loadedContents = sortMethod.sorting(
                URLs: path.contents,
                sortOrder: sortOrder
            )

            DispatchQueue.main.async {
                guard self.currentPath == currentControllerPath,
                      self.directoryLoadGeneration == generation else {
                    return
                }

                self.unfilteredContents = loadedContents
                self.isDirectoryContentsReady = true
                self.reloadTableData(animatingDifferences: false)
                SantanderGlass.refreshBackdrop(for: self)
                self.setupPermissionDeniedLabelIfNeeded()

                if let pendingPath = self.pendingSelectionPath {
                    self.pendingSelectionPath = nil
                    self.selectLoadedPath(pendingPath)
                }

                // Rebuild the refresh control's closure around the current Path.
                if let currentPath = self.currentPath, currentPath == currentControllerPath {
                    self.setupRefreshControl(forPath: currentPath)
                }

            }
        }
    }

    func setupRefreshControl(forPath path: Path) {
        let refreshControl = UIRefreshControl()
        let refreshAction = UIAction { [weak self, weak refreshControl] _ in
            guard let self else { return }

            let requestedPath = path
            let sortMethod = self.sortMethod
            DispatchQueue.global(qos: .userInitiated).async {
                let refreshedContents = sortMethod.sorting(
                    URLs: requestedPath.contents,
                    sortOrder: SortOrder.userPreferred
                )

                DispatchQueue.main.async {
                    guard self.currentPath == requestedPath else {
                        refreshControl?.endRefreshing()
                        return
                    }

                    self.unfilteredContents = refreshedContents
                    self.isDirectoryContentsReady = true
                    self.reloadTableData(animatingDifferences: false)
                    self.setupPermissionDeniedLabelIfNeeded()
                    if let pendingPath = self.pendingSelectionPath {
                        self.pendingSelectionPath = nil
                        self.selectLoadedPath(pendingPath)
                    }
                    refreshControl?.endRefreshing()
                }
            }
        }

        refreshControl.addAction(refreshAction, for: .primaryActionTriggered)

        tableView.refreshControl = refreshControl
    }

    func showPaths(animatingDifferences: Bool = false) {
        self.displayingSearchSuggestions = false
        var snapshot = SnapshotType()

        snapshot.appendSections([0])
        snapshot.appendItems(SubPathsRowItem.fromPaths(contents))
        dataSource.apply(snapshot, animatingDifferences: animatingDifferences)
    }

    func switchToSearchSuggestions() {
        displayingSearchSuggestions = true
        var snapshot = SnapshotType()

        snapshot.appendSections([0, 1, 2])

        for indexPath in SearchSuggestion.searchSuggestionSectionAndRows {
            let item = SubPathsRowItem.searchSuggestion(.displaySearchSuggestions(for: indexPath))
            snapshot.appendItems([item], toSection: indexPath.section)
        }

        dataSource.apply(snapshot, animatingDifferences: false)
    }

    func path(forIndexPath indexPath: IndexPath) -> Path {
        switch dataSource.itemIdentifier(for: indexPath) {
        case .path(let path):
            return path
        default:
            fatalError("NEVER SUPPOSED TO BE HERE!")
        }
    }

    private var pendingSelectionPath: Path?

    func selectPathWhenLoaded(_ path: Path) {
        guard let currentPath = self.currentPath, currentPath.isDirectory else { return }

        if isDirectoryContentsReady {
            selectLoadedPath(path)
        } else {
            pendingSelectionPath = path
        }
    }

    private func selectLoadedPath(_ path: Path) {
        guard let index = contents.firstIndex(of: path) else { return }

        let indexPath = IndexPath(row: index, section: 0)
        tableView.scrollToRow(at: indexPath, at: .middle, animated: true)
        tableView.selectRow(at: indexPath, animated: true, scrollPosition: .middle)
    }


    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)

        self.directoryMonitor?.stopMonitoring()
    }

    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if self.isEditing {
            selectedItems.append(path(forIndexPath: indexPath))
            setupOrUpdateToolbar()
            setLeftBarSelectionButtonItem()
            return
        }

        if displayingSearchSuggestions {
            let searchTextField = self.navigationItem.searchController?.searchBar.searchTextField
            let tokensCount = searchTextField?.tokens.count

            if (indexPath.section, indexPath.row) == (0, 0) {
                let vc = TypesSelectionCollectionViewController { types in
                    if !types.isEmpty {
                        var searchSuggestion = SearchSuggestion.displaySearchSuggestions(for: indexPath, typesToCheck: types)
                        searchSuggestion.name = types.compactMap(\.localizedDescription).joined(separator: ", ")
                        searchTextField?.insertToken(searchSuggestion.searchToken, at: tokensCount ?? 0)
                    }
                }

                let navVC = UINavigationController(rootViewController: vc)

                self.present(navVC, animated: true)

            } else {
                searchTextField?.insertToken(SearchSuggestion.displaySearchSuggestions(for: indexPath).searchToken, at: tokensCount ?? 0)
            }

        } else {
            let selectedItem = path(forIndexPath: indexPath)
            goToPath(path: selectedItem)
            tableView.deselectRow(at: indexPath, animated: true)
        }
    }

    override func tableView(_ tableView: UITableView, didDeselectRowAt indexPath: IndexPath) {
        guard self.isEditing else {
            return
        }

        let selected = path(forIndexPath: indexPath)
        selectedItems.removeAll { path in
            path == selected
        }

        setupOrUpdateToolbar()
        setLeftBarSelectionButtonItem()
    }

    override func tableView(_ tableView: UITableView, trailingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration? {

        guard !displayingSearchSuggestions else {
            return nil
        }

        let selectedItem = self.path(forIndexPath: indexPath)
        let itemAlreadyBookmarked = UserPreferences.bookmarks.contains(selectedItem)
        let favouriteAction = UIContextualAction(style: .normal, title: nil) { _, _, handler in
            self.removeOrAddItemToBookmarks(selectedItem, alreadyBookmarked: itemAlreadyBookmarked)
            handler(true)
        }

        favouriteAction.backgroundColor = .systemBlue
        favouriteAction.image = itemAlreadyBookmarked ? UIImage(systemName: "star.fill") : UIImage(systemName: "star")

        let deleteAction = UIContextualAction(style: .destructive, title: nil) { _, _, completion in
            self.deleteURL(selectedItem) { didSucceed in
                completion(didSucceed)
            }
        }

        deleteAction.image = UIImage(systemName: "trash")

        let config = UISwipeActionsConfiguration(actions: [deleteAction, favouriteAction])
        return config
    }

    func removeOrAddItemToBookmarks(_ item: Path, alreadyBookmarked: Bool) {
        if alreadyBookmarked {
            UserPreferences.bookmarks.remove(item)

            if self.isBookmarksSheet {
                self.unfilteredContents = Array(UserPreferences.bookmarks)

                var snapshot = self.dataSource.snapshot()
                snapshot.deleteItems([.path(item)])
                self.dataSource.apply(snapshot)
            }
        } else {
            UserPreferences.bookmarks.insert(item)
        }
    }

    func makeSortMenu() -> UIMenu {
        let actions: [UIMenuElement] = PathsSortMethods.allCases.map { type in
            let typeIsSelected = self.sortMethod == type
            return UIAction(
                title: type.description,
                image: typeIsSelected ? UIImage(systemName: SortOrder.userPreferred.imageSymbolName) : nil,
                state: typeIsSelected ? .on : .off) { _ in
                    if typeIsSelected {
                        UserDefaults.standard.set(SortOrder.userPreferred.toggling().rawValue, forKey: "SortOrder")
                        self.sortContents()
                    } else {
                        self.sortMethod = type
                    }

                    self.setRightBarButton()
                }
        }

        let menu = UIMenu(title: SantanderL10n.t("Sort by.."), image: UIImage(systemName: "arrow.up.arrow.down"), children: actions)
        if #available(iOS 15.0, *) {
            menu.subtitle = self.sortMethod.description
        }

        return menu
    }

    func makeNewItemMenu(forURL url: URL) -> UIMenu {
        let newFile = UIAction(title: SantanderL10n.t("File"), image: UIImage(systemName: "doc")) { _ in
            self.presentAlertAndCreate(type: .file, forURL: url)
        }

        let newFolder = UIAction(title: SantanderL10n.t("Folder"), image: UIImage(systemName: "folder")) { _ in
            self.presentAlertAndCreate(type: .directory, forURL: url)
        }

        return UIMenu(title: SantanderL10n.t("New.."), image: UIImage(systemName: "plus"), children: [newFile, newFolder])
    }

    func makeGoToMenu() -> UIMenu {
        var items: [UIMenuElement] = GoToItem.all.map { item in
            return UIAction(title: item.displayName, image: item.image) { _ in
                self.goToPath(path: Path(url: item.url))
            }
        }

        let otherLocationAction = UIAction(title: SantanderL10n.t("Other..")) { _ in
            let goToView = GoToView()
            goToView.translatesAutoresizingMaskIntoConstraints = false
            self.view.addSubview(goToView)

            NSLayoutConstraint.activate([
                goToView.centerXAnchor.constraint(equalTo: self.view.layoutMarginsGuide.centerXAnchor),
                goToView.centerYAnchor.constraint(equalTo: self.view.layoutMarginsGuide.centerYAnchor),
                goToView.heightAnchor.constraint(equalToConstant: 150),
                goToView.widthAnchor.constraint(equalToConstant: 600),
            ])
        }

        items.append(otherLocationAction)

        return UIMenu(title: SantanderL10n.t("Go to.."), image: UIImage(systemName: "arrow.right"), children: items)
    }

    func decompressPath(path: Path) {
        let alertController = createAlertWithSpinner(title: SantanderL10n.t("Decompressing.."))
        present(alertController, animated: true)
        DispatchQueue.global(qos: .userInitiated).async {
            var caughtError: Error? = nil
            do {
                let destination = path.deletingLastPathComponent()
                try Compression.shared.extract(path: path.url, to: destination.url)
            } catch {
                caughtError = error
            }

            DispatchQueue.main.async {
                alertController.dismiss(animated: true)
                if let caughtError = caughtError {
                    self.errorAlert(caughtError, title: "无法解压文件 \(path.lastPathComponent)")
                }
            }
        }
    }

    func compressPaths(paths: [Path], destination: URL, format: Compression.FormatType) {
        let alertController = createAlertWithSpinner(title: SantanderL10n.t("Compressing.."), heightAnchorConstant: 120)
        present(alertController, animated: true)

        DispatchQueue.global(qos: .userInitiated).async {
            var caughtError: Error? = nil
            do {
                try Compression.shared.compress(paths: paths.map(\.url), outputPath: destination, format: format) { pathBeingProcessed in
                    DispatchQueue.main.async { alertController.message = "正在压缩：\(pathBeingProcessed.lastPathComponent)" }
                }
            } catch {
                caughtError = error
            }

            DispatchQueue.main.async {
                alertController.dismiss(animated: true)
                if let caughtError = caughtError {
                    self.errorAlert(caughtError, title: "无法压缩文件。")
                }
            }
        }
    }

    func makeCompressionMenu(paths: [Path], destination: @escaping (Compression.FormatType) -> Path) -> UIMenu {
        let actions = Compression.FormatType.allCases.map { format in
            UIAction(title: format.description) { _ in
                self.compressPaths(paths: paths, destination: destination(format).url, format: format)
            }
        }

        return UIMenu(title: SantanderL10n.t("Compress"), image: UIImage(systemName: "archivebox"), children: actions)
    }

    func goToFile(path: Path) {
        if path.contentType?.isOfType(.archive) ?? false {
            decompressPath(path: path)
        } else if let preferred = FileEditor.preferred(forURL: path) {
            preferred.display(senderVC: self)

            if let audioVC = preferred.viewController as? AudioPlayerViewController {
                self.audioPlayerController?.player.stop()
                self.audioPlayerController = audioVC
                self.setupAudioToolbarIfPossible()
            }

        } else {
            openQuickLookPreview(forPath: path)
        }
    }

    func openQuickLookPreview(forPath path: Path) {
        let controller = QLPreviewController()
        let shared = FilePreviewDataSource(fileURL: path.url)
        controller.dataSource = shared
        self.present(controller, animated: true)
    }

    func goToPath(path: Path) {
        if path.isDirectory {
            let parentDirectory = path.deletingLastPathComponent()

            if isBookmarksSheet || parentDirectory == self.currentPath {
                guard let navigationController = self.navigationController else { return }
                let vc = PathListViewController(path: path, isBookmarksSheet: self.isBookmarksSheet)
                vc.loadViewIfNeeded()
                // Clear the old snapshot before constructing/pushing the destination.
                // Even if iOS spends a frame laying out the new controller, the user
                // never sees the previous directory's rows through a transparent glass layer.
                var emptySnapshot = SnapshotType()
                emptySnapshot.appendSections([0])
                SantanderGlass.prepareForContentTransition(in: self)
                dataSource.apply(emptySnapshot, animatingDifferences: false)
                UIView.performWithoutAnimation {
                    navigationController.pushViewController(vc, animated: false)
                    navigationController.view.layoutIfNeeded()
                    vc.view.layoutIfNeeded()
                }
                SantanderGlass.finishContentTransition(in: vc)
            } else {
                traverseThroughPath(path)
            }
        } else {
            self.goToFile(path: path)
        }
    }

    func traverseThroughPath(_ path: Path) {
        let vcs = path.url.fullPathComponents().map {
            PathListViewController(path: Path(url: $0), isBookmarksSheet: self.isBookmarksSheet)
        }

        guard let navigationController = self.navigationController, let destination = vcs.last else { return }
        SantanderGlass.prepareForContentTransition(in: self)
        UIView.performWithoutAnimation {
            navigationController.setViewControllers(vcs, animated: false)
            navigationController.view.layoutIfNeeded()
            destination.view.layoutIfNeeded()
        }
        SantanderGlass.finishContentTransition(in: destination)
    }

    func sortContents() {
        self.unfilteredContents = sortMethod.sorting(URLs: unfilteredContents, sortOrder: .userPreferred)
        reloadTableData(animatingDifferences: true)
    }

    func openInfoBottomSheet(path: Path) {
        if let app = path.applicationItem {
            let actionSheet = UIAlertController(title: nil, message: nil, preferredStyle: .actionSheet)
            let pathInfoAction = UIAlertAction(title: SantanderL10n.t("Path Info"), style: .default) { _ in
                let navController = UINavigationController(
                    rootViewController: PathInformationTableViewController(style: .insetGrouped, path: path)
                )

                if #available(iOS 15.0, *) {
                    navController.sheetPresentationController?.detents = [.medium(), .large()]
                }

                self.present(navController, animated: true)
            }

            let appInfoAction = UIAlertAction(title: SantanderL10n.t("App Info"), style: .default) { _ in
                let navController = UINavigationController(
                    rootViewController: AppInfoViewController(style: .insetGrouped, app: app, subPathsSender: self)
                )

                self.present(navController, animated: true)
            }

            actionSheet.addAction(appInfoAction)
            actionSheet.addAction(pathInfoAction)
            actionSheet.addAction(.init(title: SantanderL10n.t("Cancel"), style: .cancel))

            actionSheet.popoverPresentationController?.sourceView = view
            let bounds = view.bounds
            actionSheet.popoverPresentationController?.sourceRect = CGRect(x: bounds.midX, y: bounds.midY, width: 0, height: 0)
            self.present(actionSheet, animated: true)
        } else {
            let navController = UINavigationController(
                rootViewController: PathInformationTableViewController(style: .insetGrouped, path: path)
            )

            if #available(iOS 15.0, *) {
                navController.sheetPresentationController?.detents = [.medium(), .large()]
            }

            self.present(navController, animated: true)
        }
    }

    override func tableView(_ tableView: UITableView, accessoryButtonTappedForRowWith indexPath: IndexPath) {
        self.openInfoBottomSheet(path: path(forIndexPath: indexPath))
    }

    func searchSuggestionCellRow(suggestion: SearchSuggestion) -> UITableViewCell {
        let cell = UITableViewCell()
        SantanderGlass.styleCell(cell)
        var conf = cell.defaultContentConfiguration()
        conf.text = suggestion.name
        conf.image = suggestion.image
        cell.contentConfiguration = conf
        return cell
    }

    func pathCellRow(
        forURL fsItem: Path,
        displayFullPathAsSubtitle useSubtitle: Bool = false
    ) -> UITableViewCell {
        var fsItem = fsItem
        let pathName = fsItem.lastPathComponent

        let cell = UITableViewCell(style: useSubtitle ? .subtitle : .default, reuseIdentifier: nil)
        SantanderGlass.styleCell(cell)
        var cellConf = cell.defaultContentConfiguration()
        defer {
            cell.contentConfiguration = cellConf
        }

        if (fsItem.pathExtension == "app" || (containsAppUUIDs ?? fsItem.deletingLastPathComponent().containsAppUUIDSubpaths)),
           let app = fsItem.applicationItem {
            cellConf.text = app.localizedName
            cellConf.image = ApplicationsManager.shared.icon(forApplication: app)
            cellConf.secondaryText = fsItem.lastPathComponent
            cell.accessoryType = .disclosureIndicator
            cellConf.textProperties.color = tableView.tintColor ?? .systemBlue
            return cell
        }

        cellConf.text = pathName

        if pathName.first == "." {
            cellConf.textProperties.color = .gray
            cellConf.secondaryTextProperties.color = .gray
        }

        if useSubtitle {
            cellConf.secondaryText = fsItem.path
        }

        cellConf.image = fsItem.displayImage

        if showInfoButton {
            cell.accessoryType = .detailDisclosureButton
        } else if fsItem.isDirectory {
            cell.accessoryType = .disclosureIndicator
        }

        return cell
    }

    override func tableView(_ tableView: UITableView, contextMenuConfigurationForRowAt indexPath: IndexPath, point: CGPoint) -> UIContextMenuConfiguration? {

        if displayingSearchSuggestions {
            return nil
        }

        let item = path(forIndexPath: indexPath)
        return UIContextMenuConfiguration(identifier: nil) {
            let vc = UIViewController()
            vc.view = self.pathCellRow(forURL: item, displayFullPathAsSubtitle: true)
            vc.view.backgroundColor = .systemBackground
            let sizeFrame = vc.view.frame
            vc.preferredContentSize = CGSize(width: sizeFrame.width, height: sizeFrame.height)
            return vc
        } actionProvider: { _ in

            let movePath = UIAction(title: SantanderL10n.t("Move to.."), image: UIImage(systemName: "arrow.right")) { _ in
                self.presentOperationVC(forItems: [item.url], type: .move)
            }

            let copyPath = UIAction(title: SantanderL10n.t("Copy to.."), image: UIImage(systemName: "doc.on.doc")) { _ in
                self.presentOperationVC(forItems: [item.url], type: .copy)
            }

            let createSymlink = UIAction(title: SantanderL10n.t("Create symbolic link to.."), image: UIImage(systemName: "link")) { _ in
                self.presentOperationVC(forItems: [item.url], type: .symlink)
            }

            let pasteboardOptions = UIMenu(options: .displayInline, children: self.makePasteboardMenuElements(for: item))
            let operationItemsMenu = UIMenu(options: .displayInline, children: [movePath, copyPath, createSymlink])
            let informationAction = UIAction(title: SantanderL10n.t("Info"), image: UIImage(systemName: "info.circle")) { _ in
                self.openInfoBottomSheet(path: item)
            }

            let shareAction = UIAction(title: SantanderL10n.t("Share"), image: UIImage(systemName: "square.and.arrow.up")) { _ in
                self.presentActivityVC(forItems: [item.url])
            }

            let linkAction = UIAction(title: SantanderL10n.t("Create Symbolic Link"), image: UIImage(systemName: "link")) { _ in
                self.presentRootLinkPrompt(for: item)
            }

            let mountAction = UIAction(title: SantanderL10n.t("Mount"), image: UIImage(systemName: "externaldrive.badge.plus")) { _ in
                self.presentMountPrompt(for: item)
            }

            let unmountAction = UIAction(title: SantanderL10n.t("Unmount"), image: UIImage(systemName: "externaldrive.badge.minus"), attributes: .destructive) { _ in
                do {
                    try RootConf.shared.runHelper(arguments: ["unmount", item.path])
                    self.reloadCurrentDirectory()
                } catch {
                    self.errorAlert(error, title: "无法卸载 \(item.lastPathComponent)")
                }
            }

            let renameAction = UIAction(title: SantanderL10n.t("Rename"), image: UIImage(systemName: "rectangle.and.pencil.and.ellipsis")) { _ in
                let alert = UIAlertController(title: SantanderL10n.t("Rename"), message: nil, preferredStyle: .alert)
                if let cell = tableView.cellForRow(at: indexPath), var conf = cell.contentConfiguration as? UIListContentConfiguration,
                   let imageGuide = (cell.contentView as? UIListContentView)?.imageLayoutGuide {
                    let textField = RenamerTextField(path: item)
                    textField.returnKeyType = .done
                    textField.translatesAutoresizingMaskIntoConstraints = false
                    textField.delegate = self

                    textField.text = conf.text

                    conf.text = nil
                    cell.contentConfiguration = conf
                    cell.contentView.addSubview(textField)
                    NSLayoutConstraint.activate([
                        textField.leadingAnchor.constraint(equalTo: imageGuide.trailingAnchor, constant: conf.imageToTextPadding),
                        textField.centerYAnchor.constraint(equalTo: imageGuide.centerYAnchor)
                    ])
                    tableView.scrollToRow(at: indexPath, at: .top, animated: true)
                    textField.becomeFirstResponder()
                    return
                }

                let renameAction = UIAlertAction(title: SantanderL10n.t("Rename"), style: .default) { _ in

                    guard let name = alert.textFields?.first?.text else {
                        return
                    }

                    do {
                        let newPath: URL = item.deletingLastPathComponent().appendingPathComponent(name)
                        try FSOperation.perform(.rename(item: item.url, newPath: newPath), rootHelperConf: RootConf.shared)
                    } catch {
                        self.errorAlert(error, title: "无法重命名 \(item.lastPathComponent)")
                    }
                }

                alert.addTextField { textField in
                    textField.text = item.lastPathComponent
                }

                alert.addAction(.cancel())
                alert.addAction(renameAction)
                self.present(alert, animated: true)
            }

            var children: [UIMenuElement] = [informationAction, renameAction, shareAction, linkAction, mountAction]

            let compressOrDecompressAction: UIMenuElement
            if !(item.contentType?.isOfType(.archive) ?? false) {
                compressOrDecompressAction = self.makeCompressionMenu(paths: [item]) { format in
                    return item.deletingPathExtension().appendingPathExtension(format.fileExtension)
                }
            } else {
                compressOrDecompressAction = UIAction(title: SantanderL10n.t("Decompress"), image: UIImage(systemName: "archivebox")) { _ in
                    self.decompressPath(path: item)
                }
            }

            children.append(compressOrDecompressAction)

            if self.isMountPoint(item.url) {
                children.append(unmountAction)
            }

            if let app = item.applicationItem {
                let openAction = UIAction(title: SantanderL10n.t("Open App")) { _ in
                    do {
                        try ApplicationsManager.shared.openApp(app)
                    } catch {
                        self.errorAlert(error, title: SantanderL10n.t("Unable to open app"))
                    }
                }
                children.append(openAction)
            }

            if !item.isDirectory {
                let allEditors = FileEditor.allEditors(forPath: item)
                var actions = allEditors.map { editor in
                    UIAction(title: editor.type.description) { _ in
                        editor.display(senderVC: self)
                    }
                }

                let qlAction = UIAction(title: SantanderL10n.t("QuickLook")) { _ in
                    self.openQuickLookPreview(forPath: item)
                }

                actions.append(qlAction)

                children.append(UIMenu(title: SantanderL10n.t("Open in.."), children: actions))
            }

            if UIDevice.isiPad {
                let addActions = UserPreferences.pathGroups.enumerated().map { (index, group) in
                    return UIAction(title: group.name) { _ in
                        UserPreferences.pathGroups[index].paths.append(item.url)
                    }
                }

                let addToPathGroupsMenu = UIMenu(title: SantanderL10n.t("Add to group.."), image: UIImage(systemName: "sidebar.leading"), children: addActions)
                children.append(addToPathGroupsMenu)
            }

            let deleteAction = UIAction(title: SantanderL10n.t("Delete"), image: UIImage(systemName: "trash"), attributes: .destructive) { _ in
                self.deleteURL(item) { _ in }
            }

            let isItemBookmarked = UserPreferences.bookmarks.contains(item)
            let bookmarkAction = UIAction(
                title: isItemBookmarked ? SantanderL10n.t("Remove bookmark") : SantanderL10n.t("Bookmark"),
                image: UIImage(systemName: isItemBookmarked ? "bookmark.slash" : "bookmark")
            ) { _ in
                self.removeOrAddItemToBookmarks(item, alreadyBookmarked: isItemBookmarked)
            }

            children.append(contentsOf: [operationItemsMenu, pasteboardOptions])
            children.append(UIMenu(options: .displayInline, children: [bookmarkAction, deleteAction]))
            return UIMenu(children: children)
        }
    }

    func presentRootLinkPrompt(for item: Path) {
        let alert = UIAlertController(title: SantanderL10n.t("Create Symbolic Link"), message: SantanderL10n.t("Enter the destination directory."), preferredStyle: .alert)
        alert.addTextField { field in
            field.text = item.deletingLastPathComponent().path
            field.autocapitalizationType = .none
        }
        alert.addAction(.cancel())
        alert.addAction(UIAlertAction(title: SantanderL10n.t("Create"), style: .default) { [weak self, weak alert] _ in
            guard let self, let destination = alert?.textFields?.first?.text, !destination.isEmpty else { return }
            do {
                try RootConf.shared.runHelper(arguments: ["link", item.path, "--destination", destination])
                self.reloadCurrentDirectory()
            } catch {
                self.errorAlert(error, title: SantanderL10n.t("无法创建符号链接"))
            }
        })
        present(alert, animated: true)
    }

    func presentMountPrompt(for item: Path) {
        let alert = UIAlertController(title: SantanderL10n.t("Mount"), message: SantanderL10n.t("Enter an empty or existing mount point."), preferredStyle: .alert)
        alert.addTextField { field in
            field.text = "/mnt/\(item.deletingPathExtension().lastPathComponent)"
            field.autocapitalizationType = .none
        }
        alert.addAction(.cancel())
        alert.addAction(UIAlertAction(title: SantanderL10n.t("Mount"), style: .default) { [weak self, weak alert] _ in
            guard let self, let target = alert?.textFields?.first?.text, !target.isEmpty else { return }
            do {
                try RootConf.shared.runHelper(arguments: ["mount", item.path, target])
                self.reloadCurrentDirectory()
            } catch {
                self.errorAlert(error, title: "无法挂载 \(item.lastPathComponent)")
            }
        })
        present(alert, animated: true)
    }

    func isMountPoint(_ url: URL) -> Bool {
        var current = statfs()
        guard statfs(url.path, &current) == 0 else {
            return false
        }

        var parent = statfs()
        let parentURL = url.deletingLastPathComponent()
        guard statfs(parentURL.path, &parent) == 0 else {
            return false
        }

        return current.f_fsid.val.0 != parent.f_fsid.val.0 || current.f_fsid.val.1 != parent.f_fsid.val.1
    }

    func reloadCurrentDirectory() {
        guard let currentPath else { return }
        let path = currentPath
        let generation = UUID()
        directoryLoadGeneration = generation
        let sortMethod = self.sortMethod

        DispatchQueue.global(qos: .userInitiated).async { [weak self] in
            let contents = sortMethod.sorting(URLs: path.contents, sortOrder: .userPreferred)
            DispatchQueue.main.async { [weak self] in
                guard let self,
                      self.currentPath == path,
                      self.directoryLoadGeneration == generation else { return }
                self.unfilteredContents = contents
                self.reloadTableData(animatingDifferences: false)
            }
        }
    }

    func makePasteboardMenuElements(for path: Path) -> [UIMenuElement] {
        let copyName = UIAction(title: SantanderL10n.t("Copy name")) { _ in
            UIPasteboard.general.string = path.lastPathComponent
        }

        let copyPath = UIAction(title: SantanderL10n.t("Copy path")) { _ in
            UIPasteboard.general.url = path.url
            UIPasteboard.general.string = path.path
        }

        return [copyName, copyPath]
    }

    func presentOperationVC(forItems items: [URL], type: PathSelectionOperation) {
        let vc = PathOperationViewController(paths: items, operationType: type)
        present(UINavigationController(rootViewController: vc), animated: true) { [self] in
            if let currentPath = currentPath, currentPath != .root {
                vc.goToPath(path: currentPath)
            }
        }
    }

    func makeRightBarButton() -> UIMenu {
        let selectAction = UIAction(title: SantanderL10n.t("Select"), image: UIImage(systemName: "checkmark.circle")) { _ in
            self.tableView.allowsMultipleSelectionDuringEditing = true
            self.setEditing(true, animated: true)
        }

        let selectionMenu = UIMenu(options: .displayInline, children: [selectAction])
        var firstMenuItems = [selectionMenu, makeSortMenu(), makeGoToMenu()]

        if let currentPath = currentPath {
            firstMenuItems.append(makeNewItemMenu(forURL: currentPath.url))
        }

        let firstMenu = UIMenu(options: .displayInline, children: firstMenuItems)
        var menuActions: [UIMenuElement] = [firstMenu]

        if !isBookmarksSheet {
            let presentBookmarks = UIAction(title: SantanderL10n.t("Bookmarks"), image: UIImage(systemName: "bookmark")) { _ in
                let newVC = UINavigationController(rootViewController: PathListViewController.bookmarks())
                self.present(newVC, animated: true)
            }

            menuActions.append(presentBookmarks)
        }

        if let currentPath = currentPath {
            let showInfoAction = UIAction(title: SantanderL10n.t("Info"), image: .init(systemName: "info.circle")) { _ in
                self.openInfoBottomSheet(path: currentPath)
            }

            menuActions.append(showInfoAction)
            let pasteAction = UIAction(title: SantanderL10n.t("Paste")) { _ in
                guard let probableURL = UIPasteboard.general.probableURL else {
                    self.errorAlert(nil, title: SantanderL10n.t("No path to paste."))
                    return
                }

                do {
                    try FSOperation.perform(.copyItem(items: [probableURL], resultPath: currentPath.url), rootHelperConf: RootConf.shared)
                } catch {
                    self.errorAlert(error, title: SantanderL10n.t("Failed to copy item to current directory."))
                }
            }

            menuActions.insert(UIMenu(options: .displayInline, children: [pasteAction]), at: 1)
        }

        let settingsAction = UIAction(title: SantanderL10n.t("Settings"), image: UIImage(systemName: "gear")) { _ in
            self.present(UINavigationController(rootViewController: SettingsTableViewController(style: .insetGrouped)), animated: true)
        }
        menuActions.append(settingsAction)

        let showOrHideHiddenFilesAction = UIAction(
            title: SantanderL10n.t("Display hidden files"),
            state: displayHiddenFiles ? .on : .off
        ) { _ in
            self.displayHiddenFiles.toggle()
            self.setRightBarButton()
        }

        menuActions.append(showOrHideHiddenFilesAction)
        return UIMenu(children: menuActions)
    }

    func setRightBarButton() {
        if self.isEditing {
            let editAction = UIAction {
                self.setEditing(false, animated: true)
            }

            self.navigationItem.rightBarButtonItem = UIBarButtonItem(
                systemItem: .done,
                primaryAction: editAction
            )

        } else {
            self.navigationItem.rightBarButtonItem = UIBarButtonItem(
                image: .init(systemName: "ellipsis.circle"),
                menu: makeRightBarButton()
            )
        }
    }

    override func setEditing(_ editing: Bool, animated: Bool) {
        super.setEditing(editing, animated: animated)

        setRightBarButton()
        setLeftBarSelectionButtonItem()
        if editing {
            setupOrUpdateToolbar()
        } else {
            hideToolbarItems()
            selectedItems = []
        }
    }

    func reloadTableData(animatingDifferences: Bool = false) {
        if !displayHiddenFiles {
            let filtered = unfilteredContents.filter { !$0.lastPathComponent.starts(with: ".") }
            setFilteredContents(filtered, animatingDifferences: animatingDifferences)
        } else {
            setFilteredContents([], animatingDifferences: animatingDifferences)
        }
    }

    func setFilteredContents(_ newContents: [Path], animatingDifferences: Bool = false) {
        self.filteredSearchContents = newContents
        if !displayingSearchSuggestions {
            self.showPaths(animatingDifferences: animatingDifferences)
            SantanderGlass.refreshBackdrop(for: self)
        }
    }

    func setupPermissionDeniedLabelIfNeeded() {
        guard let currentPath = currentPath, contents.isEmpty, !currentPath.isReadable else {
            return
        }

        permissionDeniedLabel = UILabel()
        permissionDeniedLabel.text = SantanderL10n.t("Permission Denied.")

        permissionDeniedLabel.font = .systemFont(ofSize: 20, weight: .medium)
        permissionDeniedLabel.textColor = .systemGray
        permissionDeniedLabel.textAlignment = .center

        view.addSubview(permissionDeniedLabel)
        permissionDeniedLabel.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            permissionDeniedLabel.centerXAnchor.constraint(equalTo: view.layoutMarginsGuide.centerXAnchor),
            permissionDeniedLabel.centerYAnchor.constraint(equalTo: view.layoutMarginsGuide.centerYAnchor)
        ])
    }
}

extension PathListViewController: DirectoryMonitorDelegate {
    func directoryMonitorDidObserveChange(directoryMonitor: DirectoryMonitor) {
        let observedPath = directoryMonitor.path
        let sortMethod = self.sortMethod

        DispatchQueue.global(qos: .userInitiated).async { [weak self] in
            let items = sortMethod.sorting(
                URLs: observedPath.contents,
                sortOrder: SortOrder.userPreferred
            )

            DispatchQueue.main.async {
                guard let self, self.currentPath == observedPath else { return }

                self.unfilteredContents = items
                self.isDirectoryContentsReady = true
                self.reloadTableData(animatingDifferences: true)

                if self.isSearching, let searchBar = self.navigationItem.searchController?.searchBar {
                    self.updateResults(searchBar: searchBar)
                }
            }
        }
    }
}
#if compiler(>=5.7)
@available(iOS 16.0, *)
extension PathListViewController: UINavigationItemRenameDelegate {
    func navigationItem(_: UINavigationItem, didEndRenamingWith title: String) {
        guard let currentPath = currentPath else {
            return
        }

        let newURL: Path = currentPath.deletingLastPathComponent().appendingPathComponent(title)

        guard currentPath != newURL else {
            return
        }

        do {
            try FSOperation.perform(.moveItem(items: [currentPath.url], resultPath: newURL.url), rootHelperConf: RootConf.shared)
            self.currentPath = newURL
        } catch {
            self.errorAlert(error, title: "无法重命名 \(newURL.lastPathComponent)")
            self.title = currentPath.lastPathComponent
        }
    }

    func navigationItemShouldBeginRenaming(_: UINavigationItem) -> Bool {
        return currentPath != nil
    }
}
#endif

extension PathListViewController: UITextFieldDelegate {
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        guard let textField = textField as? RenamerTextField else {
            fatalError("How What When Where Why")
        }

        textField.notifyShouldReturnUponResigning = false
        defer {
            textField.resignFirstResponder()
            textField.removeFromSuperview()
        }

        guard let name = textField.text else { return false }
        let item = textField.path
        let newPath: URL = item.deletingLastPathComponent().appendingPathComponent(name)
        if newPath == item.url {
            return true
        }

        do {
            try FSOperation.perform(.rename(item: item.url, newPath: newPath), rootHelperConf: RootConf.shared)
        } catch {
            self.errorAlert(error, title: "无法重命名 \(item.lastPathComponent)")
        }

        print(textField.path)
        return true
    }
}

enum SubPathsRowItem: Hashable {
    static func == (lhs: SubPathsRowItem, rhs: SubPathsRowItem) -> Bool {
        switch (lhs, rhs) {
        case (.path(let firstURL), .path(let secondURL)):
            return firstURL == secondURL
        case (.searchSuggestion(let firstSuggestion), .searchSuggestion(let secondSuggestion)):
            return firstSuggestion == secondSuggestion
        default:
            return false
        }
    }

    func hash(into hasher: inout Hasher) {
        switch self {
        case .searchSuggestion(let searchSuggestion):
            hasher.combine(searchSuggestion)
        case .path(let url):
            hasher.combine(url)
        }
    }

    case searchSuggestion(SearchSuggestion)
    case path(Path)

    static func fromPaths(_ paths: [Path]) -> [SubPathsRowItem] {
        return paths.map { url in
            return .path(url)
        }
    }
}

class PathSidebarListViewController: UIViewController, PathTransitioning, UICollectionViewDelegate {

    typealias Item = DiffableDataSourceItem<String, Path>
    typealias DataSource = UICollectionViewDiffableDataSource<String, Item>
    typealias CellRegistration = UICollectionView.CellRegistration<UICollectionViewListCell, Item>

    var dataSource: DataSource!
    var pathGroups = UserPreferences.pathGroups
    var collectionView: UICollectionView!

    var subPathsSecondary: PathListViewController? {
        splitViewController?.viewController(for: .secondary) as? PathListViewController
    }

    init() {
        super.init(nibName: nil, bundle: nil)
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    override func viewDidLoad() {
        title = SantanderL10n.t("Santander")
        setupCollectionView()
        setupDataSource()

        let newGroupAction = UIAction {
            self.presentNewGroupAlert()
        }

        navigationController?.navigationBar.prefersLargeTitles = true
        let newGroupsButton = UIBarButtonItem(systemItem: .add, primaryAction: newGroupAction)
        setToolbarItems([newGroupsButton], animated: true)
        navigationController?.setToolbarHidden(false, animated: false)

        NotificationCenter.default.addObserver(forName: .pathGroupsDidChange, object: nil, queue: nil) { [self] notif in
            if let newGroups = notif.object as? [PathGroup] {
                self.pathGroups = newGroups
                addItems()
            }
        }
    }

    func setupCollectionView() {
        let layout = UICollectionViewCompositionalLayout { _, env in
            var layoutConf = UICollectionLayoutListConfiguration(appearance: .insetGrouped)
            layoutConf.headerMode = .firstItemInSection
            layoutConf.trailingSwipeActionsConfigurationProvider = { (indexPath: IndexPath) -> UISwipeActionsConfiguration? in
                let sectionAndRow = (indexPath.section, indexPath.row)

                guard sectionAndRow != (0, 0) && sectionAndRow != (0, 1) else {
                    return nil
                }

                let removeAction = UIContextualAction(style: .destructive, title: nil) { [self] _, _, completion in
                    switch dataSource.itemIdentifier(for: indexPath) {
                    case .section(let name):
                        UserPreferences.pathGroups.remove(at: indexPath.section)
                        removeSection(name)
                    case .item(_):
                        UserPreferences.pathGroups[indexPath.section].paths.remove(at: indexPath.row - 1)
                    default:
                        return completion(false)
                    }

                    return completion(true)
                }

                removeAction.image = .remove
                return UISwipeActionsConfiguration(actions: [removeAction])
            }

            return .list(using: layoutConf, layoutEnvironment: env)
        }

        self.collectionView = UICollectionView(frame: .zero, collectionViewLayout: layout)
        collectionView.translatesAutoresizingMaskIntoConstraints = false
        collectionView.delegate = self

        view.addSubview(collectionView)
        collectionView.constraintCompletely(to: view)
    }

    func setupDataSource() {
        let cellRegistration = CellRegistration { cell, indexPath, itemIdentifier in
            var conf: UIListContentConfiguration
            switch itemIdentifier {
            case .section(let headerTitle):
                conf = .sidebarHeader()
                conf.text = headerTitle
                cell.accessories = [.outlineDisclosure()]
            case .item(var path):
                conf = cell.defaultContentConfiguration()
                conf.text = path.lastPathComponent
                conf.image = path.displayImage
            }

            cell.contentConfiguration = conf
        }

        dataSource = DataSource(collectionView: collectionView) { collectionView, indexPath, item in
            return collectionView.dequeueConfiguredReusableCell(using: cellRegistration, for: indexPath, item: item)
        }

        addItems()
    }

    func addItems() {
        var snapshot = dataSource.snapshot()
        if snapshot.sectionIdentifiers.isEmpty {
            snapshot.appendSections(pathGroups.map(\.name))
            dataSource.apply(snapshot)
        }

        for group in pathGroups {
            var sectionSnapshot = NSDiffableDataSourceSectionSnapshot<Item>()
            let section: Item = .section(group.name)
            sectionSnapshot.append([section])
            sectionSnapshot.expand([section])

            let items = Item.fromItems(group.paths.map(Path.init(url:)))
            sectionSnapshot.append(items, to: section)
            dataSource.apply(sectionSnapshot, to: group.name)
        }
    }

    func removeSection(_ name: String) {
        var snapshot = dataSource.snapshot()
        snapshot.deleteSections([name])
        dataSource.apply(snapshot)
    }

    func goToPath(path: Path) {
        let secondary = subPathsSecondary
        if !path.isDirectory {
            secondary?.goToFile(path: path)
            return
        }

        if let currentSubpathsPath = secondary?.currentPath {
            guard currentSubpathsPath != path else { return }

            if currentSubpathsPath.path.hasPrefix(path.path) {
                if let vcs = secondary?.navigationController?.viewControllers as? [PathListViewController],
                   let first = vcs.first(where: { $0.currentPath == path }) {
                       secondary?.navigationController?.popToViewController(first, animated: false)
                }
            } else if path.deletingLastPathComponent() != currentSubpathsPath {
                secondary?.traverseThroughPath(path)
            } else {
                splitViewController?.setViewController(PathListViewController(path: path), for: .secondary)
            }

        } else {
            let vc = PathListViewController(path: .root)
            splitViewController?.setViewController(vc, for: .secondary)
            if path != .root { subPathsSecondary?.traverseThroughPath(path) }
        }
    }

    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        guard let item = dataSource.itemIdentifier(for: indexPath) else { return }
        switch item {
        case .section(_): break
        case .item(let path):
            goToPath(path: path)
        }
    }

    func presentNewGroupAlert() {
        let alert = UIAlertController(title: SantanderL10n.t("New Group"), message: nil, preferredStyle: .alert)
        alert.addTextField { textField in
            textField.placeholder = SantanderL10n.t("Group name..")
        }

        let addAction = UIAlertAction(title: SantanderL10n.t("Add"), style: .default) { [self] _ in
            guard let name = alert.textFields?.first?.text else { return }
            if pathGroups.map(\.name).contains(name) {
                errorAlert("同名的组已经存在。", title: "无法创建名为「\(name)」的组")
            }

            let newGroup = PathGroup(name: name, paths: [])
            UserPreferences.pathGroups.append(newGroup)
        }

        alert.addAction(addAction)
        alert.addAction(.cancel())
        present(alert, animated: true)
    }
}

class PathGroupOwnerViewController: UITableViewController {
    var type: ItemType
    weak var sourceVC: PathPermissionsViewController?
    let fileURL: URL
    var allData: [ItemType] = []
    private var isApplyingIdentity = false

    enum Section { case main }
    typealias DataSource = UITableViewDiffableDataSource<Section, ItemType>

    lazy var dataSource = DataSource(tableView: tableView) { [weak self] tableView, indexPath, itemIdentifier in
        let cell = UITableViewCell()
        SantanderGlass.styleCell(cell)
        var conf = cell.defaultContentConfiguration()
        conf.text = itemIdentifier.name
        cell.selectionStyle = itemIdentifier.id == -1 ? .none : .default
        conf.secondaryText = itemIdentifier.subtitle
        cell.accessoryType = self?.type == itemIdentifier ? .checkmark : .none
        cell.contentConfiguration = conf
        return cell
    }

    init(style: UITableView.Style, type: ItemType, sourceVC: PathPermissionsViewController, fileURL: URL) {
        self.type = type
        self.sourceVC = sourceVC
        self.fileURL = fileURL
        super.init(style: style)
    }

    required init?(coder: NSCoder) { fatalError() }

    override func viewDidLoad() {
        super.viewDidLoad()
        applySantanderGlass()
        title = type.title
        tableView.indentationWidth = 18
        let searchController = UISearchController(searchResultsController: nil)
        searchController.searchBar.delegate = self
        searchController.searchBar.placeholder = SantanderL10n.t("Search")
        navigationItem.searchController = searchController
        navigationItem.hidesSearchBarWhenScrolling = false
        navigationItem.rightBarButtonItem = nil

        // Render the complete UID/GID range. Every entry is selectable directly
        // and the current identity is represented by a checkmark.

        // -2…501 set atomically once the background lookup has completed.
        applyItems([type], animatingDifference: false)
        let url = fileURL
        let selectedType = type
        DispatchQueue.global(qos: .utility).async { [weak self] in
            let candidates = ItemType.candidates(forURL: url, type: selectedType)
            DispatchQueue.main.async {
                guard let self, self.type == selectedType else { return }
                self.allData = candidates
                self.applyItems(candidates, animatingDifference: false)
            }
        }
    }

    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        guard !isApplyingIdentity, let item = dataSource.itemIdentifier(for: indexPath) else { return }
        guard item.id != -1 else {
            tableView.deselectRow(at: indexPath, animated: true)
            return
        }

        let oldType = type
        isApplyingIdentity = true
        type = item
        switch item {
        case .owner(let id, let name):
            sourceVC?.permissions.ownerID = id
            sourceVC?.permissions.ownerName = name
        case .group(let id, let name):
            sourceVC?.permissions.groupID = id
            sourceVC?.permissions.groupOwnerName = name
        }
        sourceVC?.tableView.reloadData()
        tableView.reloadData()
        tableView.deselectRow(at: indexPath, animated: true)

        let url = fileURL
        DispatchQueue.global(qos: .utility).async { [weak self] in
            do {
                try item.set(id: item.id, forURL: url)
                DispatchQueue.main.async {
                    self?.isApplyingIdentity = false
                }
            } catch {
                DispatchQueue.main.async { [weak self] in
                    guard let self else { return }
                    self.type = oldType
                    switch oldType {
                    case .owner(let id, let name):
                        self.sourceVC?.permissions.ownerID = id
                        self.sourceVC?.permissions.ownerName = name
                    case .group(let id, let name):
                        self.sourceVC?.permissions.groupID = id
                        self.sourceVC?.permissions.groupOwnerName = name
                    }
                    self.sourceVC?.tableView.reloadData()
                    self.tableView.reloadData()
                    self.isApplyingIdentity = false
                    self.errorAlert(error, title: "无法修改\(self.type.title)")
                }
            }
        }
    }


    private static func readIdentityMap(at path: String) -> [Int32: String] {
        guard let data = FileManager.default.contents(atPath: path), let text = String(data: data, encoding: .utf8) else { return [:] }
        var result: [Int32: String] = [:]
        for line in text.split(whereSeparator: \.isNewline) {
            let fields = line.split(separator: ":", omittingEmptySubsequences: false)
            guard fields.count >= 3, let id = Int32(fields[2]) else { continue }
            let name = String(fields[0])
            if !name.isEmpty { result[id] = name }
        }
        return result
    }

    static func nameForUID(_ id: Int32) -> String? {
        if let name = readIdentityMap(at: "/etc/passwd")[id] { return name }
        if id >= 0 {
            let raw = UInt32(id)
            if let entry = getpwuid(uid_t(raw)), let pointer = entry.pointee.pw_name {
                return String(cString: pointer)
            }
        }
        if id == -2 { return "nobody" }
        return nil
    }

    static func nameForGID(_ id: Int32) -> String? {
        if let name = readIdentityMap(at: "/etc/group")[id] { return name }
        if id >= 0 {
            let raw = UInt32(id)
            if let entry = getgrgid(gid_t(raw)), let pointer = entry.pointee.gr_name {
                return String(cString: pointer)
            }
        }
        if id == -2 { return "nogroup" }
        return nil
    }

    enum ItemType: Hashable, CustomStringConvertible {
        case owner(id: Int32, name: String?)
        case group(id: Int32, name: String?)

        var id: Int32 {
            switch self { case .owner(let id, _), .group(let id, _): return id }
        }

        var name: String {
            switch self {
            case .owner(let id, let name): return name ?? "UID \(id)"
            case .group(let id, let name): return name ?? "GID \(id)"
            }
        }

        var subtitle: String {
            switch self {
            case .owner: return "UID \(id)"
            case .group: return "GID \(id)"
            }
        }

        var title: String {
            switch self { case .owner: return SantanderL10n.t("Owner"); case .group: return SantanderL10n.t("Group") }
        }

        var description: String { "\(name) (\(id))" }

        static func candidates(forURL url: URL, type: ItemType) -> [ItemType] {
            // Filza-style selector: keep every numeric identity in the requested
            // range visible, even when the system has no textual account name.
            // Resolve the passwd/group files once instead of reading them 504 times.
            let names: [Int32: String]
            switch type {
            case .owner:
                names = readIdentityMap(at: "/etc/passwd")
            case .group:
                names = readIdentityMap(at: "/etc/group")
            }

            var result: [ItemType] = []
            result.reserveCapacity(504)
            for rawID in -2...501 {
                let id = Int32(rawID)
                // Never reinterpret negative POSIX IDs as huge uid_t/gid_t values.
                // iOS uses IDs such as -2 for system/nobody-style accounts.
                // Resolve libc names only for non-negative IDs; every numeric ID
                // remains visible with a deterministic fallback label.
                let name: String?
                if let mapped = names[id] {
                    name = mapped
                } else if id >= 0 {
                    let raw = UInt32(id)
                    switch type {
                    case .owner:
                        name = getpwuid(uid_t(raw)).flatMap { pointer in
                            guard let value = pointer.pointee.pw_name else { return nil }
                            return String(cString: value)
                        }
                    case .group:
                        name = getgrgid(gid_t(raw)).flatMap { pointer in
                            guard let value = pointer.pointee.gr_name else { return nil }
                            return String(cString: value)
                        }
                    }
                } else {
                    name = Self.fallbackName(id: id, group: {
                        if case .group = type { return true }; return false
                    }())
                }

                switch type {
                case .owner: result.append(.owner(id: id, name: name))
                case .group: result.append(.group(id: id, name: name))
                }
            }
            return result
        }

        private static func fallbackName(id: Int32, group: Bool) -> String? {
            if id == -2 { return group ? "nogroup" : "nobody" }
            if id == -1 { return group ? "GID -1 · POSIX 保留" : "UID -1 · POSIX 保留" }
            return nil
        }

        func set(forURL url: URL) throws { try set(id: id, forURL: url) }

        func set(id: Int32, forURL url: URL) throws {
            // POSIX reserves -1 (all-bits-one) as the "do not change" sentinel
            // for chown(2). It can remain visible in the requested range, but
            // must never be sent as a real UID/GID.
            guard id != -1 else {
                throw StringError("UID/GID -1 是 POSIX 保留值，不能作为实际所有者或群组 ID。")
            }
            try RootConf.shared.runHelper(arguments: arguments(for: url, id: id))
        }

        func arguments(for url: URL, id: Int32? = nil) -> [String] {
            switch self {
            case .owner:
                return ["set-owner-or-group", url.path, "--owner-id", String(id ?? self.id)]
            case .group:
                return ["set-owner-or-group", url.path, "--group-id", String(id ?? self.id)]
            }
        }
    }

    func applyItems(_ items: [ItemType], animatingDifference: Bool = false) {
        var snapshot = NSDiffableDataSourceSnapshot<Section, ItemType>()
        snapshot.appendSections([.main])
        snapshot.appendItems(items, toSection: .main)
        dataSource.apply(snapshot, animatingDifferences: animatingDifference)
    }
}

extension PathGroupOwnerViewController: UISearchBarDelegate {
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        if searchText.isEmpty {
            applyItems(allData, animatingDifference: true)
            return
        }

        let filtered = allData.filter { item in
            item.name.localizedCaseInsensitiveContains(searchText) ||
            item.subtitle.localizedCaseInsensitiveContains(searchText) ||
            item.description.localizedCaseInsensitiveContains(searchText)
        }

        applyItems(filtered, animatingDifference: true)
    }

    func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
        applyItems(allData, animatingDifference: true)
    }
}

extension PathListViewController: AudioPlayerToolbarDelegate {

    @objc
    func setupOrUpdateToolbar() {

        let trashAction = UIAction {
            let confirmationController = UIAlertController(title: "确定要删除已选的 \(self.selectedItems.count) 个项目吗？", message: nil, preferredStyle: .alert)

            let deleteAction = UIAlertAction(title: SantanderL10n.t("Delete"), style: .destructive) { _ in

                do {
                    try FSOperation.perform(.removeItems(items: self.selectedItems.map(\.url)), rootHelperConf: RootConf.shared)
                } catch {
                    self.errorAlert(error, title: SantanderL10n.t("无法删除项目"))
                }

            }

            confirmationController.addAction(.cancel())
            confirmationController.addAction(deleteAction)
            self.present(confirmationController, animated: true)
        }

        let trash = UIBarButtonItem(systemItem: .trash, primaryAction: trashAction)
        trash.tintColor = UIColor.systemRed

        let shareAction = UIAction {
            self.presentActivityVC(forItems: self.selectedItems)
        }

        let share = UIBarButtonItem(image: UIImage(systemName: "square.and.arrow.up"), primaryAction: shareAction)
        let moreItems = UIBarButtonItem(image: UIImage(systemName: "ellipsis.circle"), menu: makeToolbarMoreItemsMenu())
        let items = [trash, .flexibleSpace(), share, .flexibleSpace(), moreItems].map { item in
            item.isEnabled = !selectedItems.isEmpty
            return item
        }

        self.toolbarItems = items
        self.navigationController?.setToolbarHidden(false, animated: true)
        self.navigationController?.toolbar.viewWithTag(100)?.removeFromSuperview()
    }

    @objc
    func hideToolbarItems() {
        self.toolbarItems = []
        self.navigationController?.setToolbarHidden(true, animated: true)

        setupAudioToolbarIfPossible()
    }

    fileprivate func makeToolbarMoreItemsMenu() -> UIMenu {
        let moveAction = UIAction(title: SantanderL10n.t("Move"), image: UIImage(systemName: "arrow.right")) { _ in
            let vc = PathOperationViewController(paths: self.selectedItems.toURL(), operationType: .move)
            self.present(UINavigationController(rootViewController: vc), animated: true)
        }

        let copyAction = UIAction(title: SantanderL10n.t("Copy"), image: UIImage(systemName: "doc.on.doc")) { _ in
            let vc = PathOperationViewController(paths: self.selectedItems.toURL(), operationType: .copy)
            self.present(UINavigationController(rootViewController: vc), animated: true)
        }

        let symlinkAction = UIAction(title: SantanderL10n.t("Alias"), image: UIImage(systemName: "link")) { _ in
            let vc = PathOperationViewController(paths: self.selectedItems.toURL(), operationType: .symlink)
            self.present(UINavigationController(rootViewController: vc), animated: true)
        }

        var children: [UIMenuElement] = [symlinkAction, moveAction, copyAction]
        if let currentPath = currentPath {
            let compresMenu = makeCompressionMenu(paths: self.selectedItems) { format in
                return currentPath.appendingPathComponent("Archive").appendingPathExtension(format.fileExtension)
            }

            children.append(compresMenu)
        }

        return UIMenu(children: children)
    }

    @objc
    func setLeftBarSelectionButtonItem() {
        if !isEditing {
            navigationItem.leftBarButtonItem = nil
            return
        }

        let contents = self.contents
        let allItemsSelected = selectedItems.count == contents.count
        let action = UIAction {
            for index in contents.indices {
                if !allItemsSelected {
                    self.tableView.selectRow(at: IndexPath(row: index, section: 0), animated: true, scrollPosition: .none)
                } else {
                    self.tableView.deselectRow(at: IndexPath(row: index, section: 0), animated: true)
                }
            }

            self.selectedItems = allItemsSelected ? [] : contents
            self.setLeftBarSelectionButtonItem()
        }

        self.navigationItem.leftBarButtonItem = UIBarButtonItem(title: allItemsSelected ? SantanderL10n.t("Deselect All") : SantanderL10n.t("Select All"), primaryAction: action)
        setupOrUpdateToolbar()
    }

    func setupAudioToolbarIfPossible() {
        guard let audioPlayerController = audioPlayerController, let toolbar = navigationController?.toolbar else {
            return
        }

        navigationController?.setToolbarHidden(false, animated: true)

        // The window already owns the only custom liquid-glass backdrop. Keep the
        // audio bar on a native material instead of creating another sampled glass
        // surface over the same window. This removes the stacked-glass artefact.
        let materialView = UIVisualEffectView(effect: UIBlurEffect(style: .systemMaterial))
        materialView.frame = toolbar.bounds
        materialView.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        materialView.tag = 100

        let audioToolbarView = AudioPlayerToolbarView(audioPlayerController, frame: materialView.bounds)
        audioToolbarView.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        audioToolbarView.delegate = self
        materialView.contentView.addSubview(audioToolbarView)
        materialView.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(toolbarAudioPreviewWasTapped)))
        toolbar.addSubview(materialView)
    }

    @objc
    func toolbarAudioPreviewWasTapped() {
        guard let vc = audioPlayerController else {
            return
        }

        UIApplication.shared.sceneKeyWindow?.rootViewController?.present(UINavigationController(rootViewController: vc), animated: true)
    }

    func audioToolbarDidClickCancelButton(_ toolbar: AudioPlayerToolbarView) {
        let rootNav = UIApplication.shared.sceneKeyWindow?.rootViewController as? UINavigationController
        rootNav?.toolbar?.viewWithTag(100)?.removeFromSuperview()
        rootNav?.setToolbarHidden(true, animated: true)

        toolbar.audioPlayerController.player.stop()
        toolbar.audioPlayerController.removeFromSystemMediaPlayer()
        self.audioPlayerController = nil
    }
}

class PathOperationViewController: PathListViewController {

    let paths: [URL]

    let operationType: PathSelectionOperation

    let dismissWhenDone: Bool

    init(paths: [URL], operationType: PathSelectionOperation, startingPath: Path = .root, dismissWhenDone: Bool = true) {
        self.paths = paths
        self.operationType = operationType
        self.dismissWhenDone = dismissWhenDone

        super.init(path: startingPath)
    }

    required init?(coder: NSCoder) {
        fatalError("Not implemented")
    }

    override func viewDidLoad() {
        super.viewDidLoad()

        self.navigationController?.navigationBar.prefersLargeTitles = false
        self.title = self.operationType.verbDescription
        if let currentPath = self.currentPath {
            self.navigationItem.backBarButtonItem = UIBarButtonItem(title: currentPath.lastPathComponent, style: .plain, target: nil, action: nil)
        }

        for path in paths {
            _ = path.startAccessingSecurityScopedResource()
        }
    }

    @objc func done() {
        guard let currentPath = self.currentPath else {
            self.errorAlert("无法获取用于\(operationType.description)的当前路径。", title: "无法\(operationType.description)路径")
            return
        }

        do {
            switch operationType {
            case .move:
                try FSOperation.perform(.moveItem(items: paths, resultPath: currentPath.url), rootHelperConf: RootConf.shared)
            case .copy, .import:
                try FSOperation.perform(.copyItem(items: paths, resultPath: currentPath.url), rootHelperConf: RootConf.shared)
            case .symlink:
                try FSOperation.perform(.symlink(items: paths, resultPath: currentPath.url), rootHelperConf: RootConf.shared)
            case .custom(_, _, let action):
                try action(self, currentPath.url)
            }

            if dismissWhenDone {
                self.dismiss(animated: true)
            }
        } catch {
            self.errorAlert(error, title: "无法\(operationType.description)项目")
        }

    }

    override func goToPath(path: Path) {
        let parentDirectory = path.deletingLastPathComponent()

        if parentDirectory != currentPath {
            traverseThroughPath(path)
            return
        }

        if path.isDirectory {
            self.navigationController?.pushViewController(PathOperationViewController(paths: paths, operationType: operationType, startingPath: path, dismissWhenDone: dismissWhenDone), animated: true)
        } else {
            self.goToFile(path: path)
        }
    }

    override func traverseThroughPath(_ path: Path) {
        let vcs = path.url.fullPathComponents().map { [self] newPath in
            PathOperationViewController(paths: paths, operationType: operationType, startingPath: Path(url: newPath), dismissWhenDone: dismissWhenDone)
        }

        self.navigationController?.setViewControllers(vcs, animated: vcs.count > 1)
    }

    @objc
    func cancel() {
        self.dismiss(animated: true)
    }

    override func setRightBarButton() {
        let doneButton = UIBarButtonItem(barButtonSystemItem: .done, target: self, action: #selector(done))
        let options = UIBarButtonItem(image: .init(systemName: "ellipsis.circle"), menu: makeRightBarButton())
        self.navigationItem.rightBarButtonItems = [doneButton, options]
    }

    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)

        for path in paths {
            path.stopAccessingSecurityScopedResource()
        }
    }
}

enum PathSelectionOperation: CustomStringConvertible {
    case move
    case copy
    case `import`
    case symlink
    case custom(description: String, verbDescription: String, action: (PathOperationViewController, URL) throws -> Void)

    var description: String {
        switch self {
        case .move:
            return SantanderL10n.t("move")
        case .copy:
            return SantanderL10n.t("copy")
        case .import:
            return SantanderL10n.t("import")
        case .symlink:
            return SantanderL10n.t("symlink")
        case .custom(description: let description, _, _):
            return description
        }
    }

    var verbDescription: String {
        switch self {
        case .move:
            return SantanderL10n.t("Moving to..")
        case .copy:
            return SantanderL10n.t("Copying to..")
        case .import:
            return SantanderL10n.t("Importing to..")
        case .symlink:
            return SantanderL10n.t("Aliasing to..")
        case .custom(_, verbDescription: let verbDescription, _):
            return verbDescription
        }
    }
}

extension PathListViewController: UITableViewDropDelegate, UITableViewDragDelegate {

    func tableView(_ tableView: UITableView, performDropWith coordinator: UITableViewDropCoordinator) {
        for item in coordinator.items {
            item.dragItem.itemProvider.loadFileRepresentation(forTypeIdentifier: "public.item") { url, err in
                guard let url = url, err == nil else {
                    DispatchQueue.main.async {
                        self.errorAlert("Error: \(err?.localizedDescription ?? SantanderL10n.t("Unknown"))", title: SantanderL10n.t("Failed to import file"))
                    }
                    return
                }

                guard let currentPath = self.currentPath else {
                    return
                }

                do {
                    try FSOperation.perform(.moveItem(items: [url], resultPath: currentPath.url), rootHelperConf: RootConf.shared)
                } catch {
                    DispatchQueue.main.async {
                        self.errorAlert("Error: \(error.localizedDescription)", title: SantanderL10n.t("Failed to copy item"))
                    }
                }
            }
        }
    }

    func tableView(_ tableView: UITableView, canHandle session: UIDropSession) -> Bool {
        return currentPath != nil
    }

    func tableView(_ tableView: UITableView, itemsForBeginning session: UIDragSession, at indexPath: IndexPath) -> [UIDragItem] {
        guard !displayingSearchSuggestions else {
            return []
        }

        let selectedItem = path(forIndexPath: indexPath)
        let itemProvider = NSItemProvider()

        let typeID = selectedItem.contentType?.identifier ?? UTType.content.identifier

        itemProvider.registerFileRepresentation(
            forTypeIdentifier: typeID,
            visibility: .all) { completion in
                completion(selectedItem.url, true, nil)
                return nil
            }

        return [
            UIDragItem(itemProvider: itemProvider)
        ]
    }
}

class RenamerTextField: UITextField {
    override var canBecomeFirstResponder: Bool {
        true
    }

    let path: Path
    var notifyShouldReturnUponResigning: Bool = true

    init(path: Path) {
        self.path = path
        super.init(frame: .zero)
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    @discardableResult
    override func resignFirstResponder() -> Bool {
        if notifyShouldReturnUponResigning {
            return delegate?.textFieldShouldReturn?(self) ?? true
        }

        return super.resignFirstResponder()
    }
}

class PathInformationTableViewController: UITableViewController {
    let path: Path
    let metadata: PathMetadata

    var showByteCount: Bool = false
    var showDisplayName: Bool = false
    var showRealPath: Bool = false
    var showAppName: Bool
    var appName: String?

    var sizeState: LoadingValueState<Int> = .loading

    init(style: UITableView.Style, path: Path) {
        self.path = path
        self.metadata = PathMetadata(filePath: path)
        appName = path.applicationItem?.localizedName

        showAppName = (appName != nil)
        super.init(style: style)
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        applySantanderGlass()

        self.title = self.path.lastPathComponent
        DispatchQueue.global(qos: .userInteractive).async { [self] in
            var path = path
            if let size = path.size {
                sizeState = .value(size)
            } else {
                sizeState = .unavailable
            }

            DispatchQueue.main.async {
                self.tableView.reloadRows(at: [IndexPath(row: 2, section: 0)], with: .fade)
            }
        }
    }

    override func numberOfSections(in tableView: UITableView) -> Int {
        return 4
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        switch section {
        case 0:
            return self.path.isDirectory ? 4 : 3
        case 1:
            return metadata.contentType?.preferredMIMEType != nil ? 2 : 1
        case 2:
            return 4
        case 3:
            return 1
        default:
            fatalError("Impossible to be here")
        }
    }

    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        switch (indexPath.section, indexPath.row) {
        case (0, 0):
            if appName != nil {
                showAppName.toggle()
            } else if path.displayName != path.lastPathComponent {
                showDisplayName.toggle()
            }

        case (0, 1):
            showRealPath.toggle()
        case (0, 2):
            showByteCount.toggle()
        case (3, 0):
            guard let permissions = metadata.permissions else {
                return
            }

            self.navigationController?.pushViewController(PathPermissionsViewController(permissions: permissions), animated: true)
        default:
            return
        }

        tableView.reloadRows(at: [indexPath], with: .automatic)
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = UITableViewCell(style: .value1, reuseIdentifier: nil)
        var conf = cell.defaultContentConfiguration()
        switch (indexPath.section, indexPath.row) {
        case (0, 0):
            if showDisplayName {
                conf.text = SantanderL10n.t("Display name")
                conf.secondaryText = self.path.displayName
            } else if showAppName {
                conf.text = SantanderL10n.t("App name")
                conf.secondaryText = appName
            } else {
                conf.text = SantanderL10n.t("Name")
                conf.secondaryText = path.lastPathComponent
            }

        case (0, 1):
            conf.text = showRealPath ? SantanderL10n.t("Real Path") : SantanderL10n.t("Path")
            if showRealPath {
                conf.secondaryText = path.resolvedURL.path
            } else {
                conf.secondaryText = self.path.path
            }

        case (0, 2):
            conf.text = SantanderL10n.t("Size")
            switch sizeState {
            case .loading:
                let spinner = UIActivityIndicatorView()
                spinner.startAnimating()
                spinner.translatesAutoresizingMaskIntoConstraints = false
                cell.addSubview(spinner)

                NSLayoutConstraint.activate([
                    spinner.trailingAnchor.constraint(equalTo: cell.layoutMarginsGuide.trailingAnchor),
                    spinner.centerYAnchor.constraint(equalTo: cell.centerYAnchor)
                ])

            case .unavailable:
                conf.secondaryText = "不适用"
            case .value(let size):
                let formatter = ByteCountFormatter()
                formatter.countStyle = .file
                formatter.allowedUnits = .useAll
                formatter.includesActualByteCount = showByteCount
                conf.secondaryText = formatter.string(fromByteCount: Int64(size))
            }
        case (0, 3):
            conf.text = SantanderL10n.t("Items")
            conf.secondaryText = self.path.contents.count.description
        case (1, 0):
            conf.text = SantanderL10n.t("Type")
            conf.secondaryText = metadata.contentType?.localizedDescription?.localizedCapitalized ?? SantanderL10n.t("N/A")
        case (1, 1):
            conf.text = SantanderL10n.t("MIME Type")
            conf.secondaryText = metadata.contentType?.preferredMIMEType ?? SantanderL10n.t("N/A")
        case (2, 0):
            conf.text = SantanderL10n.t("Created")
            conf.secondaryText = metadata.creationDate?.listFormatted() ?? SantanderL10n.t("N/A")
        case (2, 1):
            conf.text = SantanderL10n.t("Added")
            conf.secondaryText = metadata.addedToDirectoryDate?.listFormatted() ?? SantanderL10n.t("N/A")
        case (2, 2):
            conf.text = SantanderL10n.t("Modified")
            conf.secondaryText = metadata.lastModifiedDate?.listFormatted() ?? SantanderL10n.t("N/A")
        case (2, 3):
            conf.text = SantanderL10n.t("Accessed")
            conf.secondaryText = metadata.lastAccessedDate?.listFormatted() ?? SantanderL10n.t("N/A")
        case (3, 0):
            conf.text = SantanderL10n.t("Permissions")
            cell.accessoryType = .disclosureIndicator
            cell.isUserInteractionEnabled = metadata.permissions != nil
        default: break
        }

        cell.contentConfiguration = conf
        return cell
    }

    override func tableView(_ tableView: UITableView, shouldHighlightRowAt indexPath: IndexPath) -> Bool {
        switch (indexPath.section, indexPath.row) {
        case (0, 0):
            return path.displayName != path.lastPathComponent || appName != nil
        case (0, 1):
            return (try? FileManager.default.destinationOfSymbolicLink(atPath: self.path.path)) != nil
        case (0, 2):
            return true
        case (3, 0):
            return metadata.permissions != nil
        default:
            return false
        }
    }

    override func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        return headerTitle(forSection: section)
    }

    override func tableView(_ tableView: UITableView, contextMenuConfigurationForRowAt indexPath: IndexPath, point: CGPoint) -> UIContextMenuConfiguration? {
        let cell = self.tableView(tableView, cellForRowAt: indexPath)
        guard let conf = cell.contentConfiguration as? UIListContentConfiguration, let secondaryText = conf.secondaryText else { return nil }

        return UIContextMenuConfiguration(identifier: nil, previewProvider: nil) { _ in
            let copyAction = UIAction(title: SantanderL10n.t("Copy"), image: UIImage(systemName: "doc.on.doc")) { _ in
                UIPasteboard.general.string = secondaryText
            }

            return UIMenu(children: [copyAction])
        }
    }

    func headerTitle(forSection section: Int) -> String {
        switch section {
        case 0: return SantanderL10n.t("General")
        case 1: return SantanderL10n.t("Type")
        case 2: return SantanderL10n.t("Date Metadata")
        case 3: return SantanderL10n.t("Permissions")
        default: fatalError("\(#function): Unknown Section num \(section)")
        }
    }
}


class AssetCatalogViewController: UIViewController {
    typealias DataSource = UICollectionViewDiffableDataSource<RenditionType, Rendition>
    typealias SupplementaryRegistration = UICollectionView.SupplementaryRegistration<AssetCatalogSectionHeader>
    typealias CellRegistration = UICollectionView.CellRegistration<AssetCatalogCell, Rendition>

    static let titleElementKind = "RenditionTypeTitle"

    let fileURL: URL
    var renditionCollection: RenditionCollection
    var catalog: CUICatalog
    fileprivate var editorDelegate: ItemEditorDelegate?

    var collectionView: UICollectionView!
    var dataSource: DataSource!
    var noResultsLabel: UILabel = UILabel()
    var layoutMode: LayoutMode = LayoutMode(UserPreferences.assetCatalogControllerLayoutMode) {
        didSet {
            collectionView.setCollectionViewLayout(createLayout(), animated: true)
            UserPreferences.assetCatalogControllerLayoutMode = layoutMode.rawValue
        }
    }

    init(renditions: RenditionCollection, fileURL: URL, catalog: CUICatalog) {
        self.renditionCollection = renditions
        self.fileURL = fileURL
        self.catalog = catalog
        super.init(nibName: nil, bundle: nil)
    }

    convenience init(catalogFileURL fileURL: URL) throws {
        let (catalog, renditions) = try AssetCatalogWrapper.shared.renditions(forCarArchive: fileURL)
        self.init(renditions: renditions, fileURL: fileURL, catalog: catalog)
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    override func viewDidLoad() {
        super.viewDidLoad()

        if !UIDevice.isiPad {
            let filename = fileURL.deletingPathExtension()
            title = filename.lastPathComponent
            navigationController?.navigationBar.prefersLargeTitles = true
        }

        navigationItem.hidesSearchBarWhenScrolling = false

        let searchController = UISearchController()
        searchController.searchBar.delegate = self
        navigationItem.searchController = searchController

        configureCollectionView()
        configureDataSource()

        setupBarItems()
    }

    override var keyCommands: [UIKeyCommand]? {
        return [
            UIKeyCommand(title: SantanderL10n.t("Scroll Up"), action: #selector(goUpOrDown(sender:)), input: UIKeyCommand.inputUpArrow, modifierFlags: .command),
            UIKeyCommand(title: SantanderL10n.t("Scroll Down"), action: #selector(goUpOrDown(sender:)), input: UIKeyCommand.inputDownArrow, modifierFlags: .command)
        ]
    }

    @objc
    func goUpOrDown(sender: UIKeyCommand) {
        switch sender.input {
        case UIKeyCommand.inputDownArrow:
            let snapshot = dataSource.snapshot()
            if let last = snapshot.sectionIdentifiers.last {
                let section = snapshot.sectionIdentifiers.count
                let row = snapshot.itemIdentifiers(inSection: last).count
                collectionView.scrollToItem(at: IndexPath(row: row - 1, section: section - 1), at: .bottom, animated: true)
            }
        case UIKeyCommand.inputUpArrow:
            collectionView.scrollToItem(at: IndexPath(row: 0, section: 0), at: .top, animated: true)
        default:
            break
        }
    }

    func configureCollectionView() {
        self.collectionView = UICollectionView(frame: .zero, collectionViewLayout: createLayout())
        collectionView.translatesAutoresizingMaskIntoConstraints = false
        collectionView.backgroundColor = .systemBackground
        collectionView.dragDelegate = self
        collectionView.delegate = self
        view.addSubview(collectionView)
        collectionView.constraintCompletely(to: view)
    }

    func makeMenuForBarButton() -> UIMenu {
        let extractAction = UIAction(title: SantanderL10n.t("Extract to..")) { _ in
            self.extractAction()
        }

        let changeLayoutActions = LayoutMode.allCases.map { [self] mode in
            return UIAction(title: mode.description, state: layoutMode == mode ? .on : .off) { [self] _ in
                layoutMode = mode
                setupBarItems()
            }
        }

        let changeLayoutMenu = UIMenu(title: SantanderL10n.t("Layout"), children: changeLayoutActions)
        return UIMenu(children: [extractAction, changeLayoutMenu])
    }

    func setupBarItems() {
        let dismissAction = UIAction { _ in
            self.dismiss(animated: true)
        }

        navigationItem.rightBarButtonItem = UIBarButtonItem(systemItem: .close, primaryAction: dismissAction)
        let barButtonWithMenu = UIBarButtonItem(image: UIImage(systemName: "ellipsis.circle"), menu: makeMenuForBarButton())

        if UIDevice.isiPad {
            splitViewController?.viewController(for: .primary)?.navigationItem.rightBarButtonItem = barButtonWithMenu
        } else {
            navigationItem.leftBarButtonItem = barButtonWithMenu
        }
    }

    func extractAction() {
        let action: PathSelectionOperation = .custom(description: "extract", verbDescription: SantanderL10n.t("Extracting to..")) { [self] operationVC, selectedPath in
            let extractionPath = selectedPath
                .appendingPathComponent("\(fileURL.lastPathComponent)-Extracted")

            extractItems(extractionPath: extractionPath, sourceVC: operationVC) { error in
                if let error = error {
                    operationVC.errorAlert(error, title: SantanderL10n.t("Unable to extract items"))
                } else {
                    operationVC.dismiss(animated: true) {
                        self.dismiss(animated: true) {
                            let rootVC = UIApplication.shared.sceneKeyWindow?.rootViewController
                            let vcToPushFrom: PathTransitioning?

                            if UIDevice.isiPad {
                                vcToPushFrom = (rootVC as? UISplitViewController)?.viewController(for: .primary) as? PathTransitioning
                            } else {
                                vcToPushFrom = (rootVC as? UINavigationController)?.visibleViewController as? PathTransitioning
                            }

                            vcToPushFrom?.goToPath(path: Path(url: extractionPath))
                        }
                    }
                }
            }
        }

        let vc = PathOperationViewController(paths: [fileURL], operationType: action, dismissWhenDone: false)
        present(UINavigationController(rootViewController: vc), animated: true) {
            vc.goToPath(path: Path(url: self.fileURL.deletingLastPathComponent()))
        }
    }

    func extractItems(
        extractionPath savePath: URL,
        sourceVC: UIViewController,
        completionHandler: @escaping (Error?) -> Void
    ) {
        let alertController = createAlertWithSpinner(title: SantanderL10n.t("Extracting.."))
        sourceVC.present(alertController, animated: true)

        DispatchQueue.global(qos: .userInitiated).async {
            var caughtError: Error?

            do {
                try FSOperation.perform(.extractCatalog(catalogFileURL: self.fileURL, resultPath: savePath), rootHelperConf: RootConf.shared)
            } catch {
                caughtError = error
            }

            DispatchQueue.main.async {
                alertController.dismiss(animated: true) {
                    completionHandler(caughtError)
                }
            }
        }
    }

    enum LayoutMode: Int, CustomStringConvertible, CaseIterable {
        case horizantal
        case verical

        init(_ rawValue: Int) {
            switch rawValue {
            case LayoutMode.horizantal.rawValue: self = .horizantal
            default: self = .verical
            }
        }

        var description: String {
            switch self {
            case .horizantal:
                return SantanderL10n.t("Horizontal")
            case .verical:
                return SantanderL10n.t("Vertical")
            }
        }
    }
}

extension AssetCatalogViewController: UICollectionViewDelegate {
    func createLayout() -> UICollectionViewLayout {
        let section: NSCollectionLayoutSection

        switch layoutMode {
        case .verical:
            let itemSize = NSCollectionLayoutSize(widthDimension: .fractionalWidth(1.0),
                                                  heightDimension: .fractionalHeight(1.0))
            let item = NSCollectionLayoutItem(layoutSize: itemSize)
            let groupSize = NSCollectionLayoutSize(widthDimension: .fractionalWidth(1.0),
                                                   heightDimension: .absolute(60))

            let group = NSCollectionLayoutGroup.horizontal(layoutSize: groupSize, subitem: item, count: 1)
            let spacing = CGFloat(10)
            group.interItemSpacing = .fixed(spacing)

            section = NSCollectionLayoutSection(group: group)
            section.interGroupSpacing = spacing
            section.contentInsets = NSDirectionalEdgeInsets(top: 0, leading: spacing, bottom: 0, trailing: spacing)
        case .horizantal:
            let itemSize = NSCollectionLayoutSize(
                widthDimension: .fractionalWidth(1),
                heightDimension: .fractionalHeight(0.40)
            )

            let layoutItem = NSCollectionLayoutItem(layoutSize: itemSize)
            layoutItem.contentInsets = NSDirectionalEdgeInsets(top: 0, leading: 5, bottom: 3, trailing: 5)

            let layoutGroupSize = NSCollectionLayoutSize(
                widthDimension: .fractionalWidth(0.93),
                heightDimension: .fractionalWidth(0.55)
            )

            let layoutGroup: NSCollectionLayoutGroup = .vertical(
                layoutSize: layoutGroupSize,
                subitem: layoutItem,
                count: 3
            )

            layoutGroup.interItemSpacing = .fixed(15)

            section = NSCollectionLayoutSection(group: layoutGroup)
            section.orthogonalScrollingBehavior = .groupPagingCentered
        }

        let titleHeaderSize = NSCollectionLayoutSize(
            widthDimension: .fractionalWidth(0.93),
            heightDimension: .absolute(50)
        )

        let titleSupplementary = NSCollectionLayoutBoundarySupplementaryItem(
            layoutSize: titleHeaderSize,
            elementKind: AssetCatalogViewController.titleElementKind,
            alignment: layoutMode == .horizantal ? .top : .topLeading
        )

        section.boundarySupplementaryItems = [titleSupplementary]
        let layout = UICollectionViewCompositionalLayout(section: section)
        let conf = UICollectionViewCompositionalLayoutConfiguration()
        conf.interSectionSpacing = 20

        layout.configuration = conf
        return layout
    }

    func configureDataSource() {
        let cellRegistration = CellRegistration { cell, indexPath, itemIdentifier in
            cell.rendition = itemIdentifier
            cell.configure()
        }

        dataSource = DataSource(collectionView: collectionView) { collectionView, indexPath, itemIdentifier in
            return collectionView.dequeueConfiguredReusableCell(using: cellRegistration, for: indexPath, item: itemIdentifier)
        }

        updateDataSourceItems(collection: renditionCollection)

        let supplementaryRegistration = SupplementaryRegistration(elementKind: AssetCatalogViewController.titleElementKind) { supplementaryView, elementKind, indexPath in
            let snapshot = self.dataSource.snapshot()
            let section = snapshot.sectionIdentifiers[indexPath.section]
            supplementaryView.configure(withSection: section, snapshot: snapshot, sender: self)
        }

        dataSource.supplementaryViewProvider = { (collectionView, string, indexPath) in
            return collectionView.dequeueConfiguredReusableSupplementary(using: supplementaryRegistration, for: indexPath)
        }
    }

    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        guard let item = dataSource.itemIdentifier(for: indexPath) else { return }
        let vc = AssetCatalogRenditionViewController(rendition: item, sender: self)
        present(UINavigationController(rootViewController: vc), animated: true)
    }

    func collectionView(_ collectionView: UICollectionView, contextMenuConfigurationForItemAt indexPath: IndexPath, point: CGPoint) -> UIContextMenuConfiguration? {
        guard let item = dataSource.itemIdentifier(for: indexPath) else { return nil }
        return UIContextMenuConfiguration(identifier: nil, previewProvider: nil) { _ in
            let copyNameAction = UIAction(title: SantanderL10n.t("Copy name"), image: UIImage(systemName: "doc.on.doc")) { _ in
                UIPasteboard.general.string = item.name
            }
            var children = [copyNameAction]

            if let image = item.image {
                let uiImage = UIImage(cgImage: image)
                let copyImageAction = UIAction(title: SantanderL10n.t("Copy Image")) { _ in
                    UIPasteboard.general.image = uiImage
                }

                children.append(copyImageAction)

                let saveImageAction = UIAction(title: SantanderL10n.t("Save Image"), image: UIImage(systemName: "square.and.arrow.down")) { _ in
                    self.saveImage(uiImage)
                }

                children.append(saveImageAction)
            }

            var attributes: UIMenuElement.Attributes = []

            if !item.type.isEditable {
                attributes = .disabled
            }

            let editAction = UIAction(title: SantanderL10n.t("Edit"), attributes: attributes) { _ in
                self.editItem(item)
            }

            children.append(editAction)

            let deleteItemAction = UIAction(title: SantanderL10n.t("Delete"), image: UIImage(systemName: "trash"), attributes: .destructive) { [self] _ in
                deleteItem(item, completion: nil)
            }

            children.append(deleteItemAction)

            return UIMenu(children: children)
        }
    }

    func deleteItem(_ item: Rendition, completion: ((Error?) -> Void)?) {
        do {
            try catalog.removeItem(item, fileURL: fileURL)

            let (newCatalog, newRenditions) = try AssetCatalogWrapper.shared.renditions(forCarArchive: fileURL)
            self.catalog = newCatalog
            self.renditionCollection = newRenditions
            updateDataSourceItems(collection: renditionCollection)
            completion?(nil)
        } catch {
            let completion = completion ?? { error in
                self.errorAlert(error, title: SantanderL10n.t("Failed to delete item and update contents of file"))
            }

            completion(error)
        }
    }

    func updateDataSourceItems(collection: RenditionCollection) {
        var snapshot = NSDiffableDataSourceSnapshot<RenditionType, Rendition>()
        for (section, items) in collection {
            snapshot.appendSections([section])
            snapshot.appendItems(items, toSection: section)
        }

        dataSource.apply(snapshot, animatingDifferences: true)

        if UIDevice.isiPad, let sidebar = splitViewController?.viewController(for: .primary) as? AssetCatalogSidebarListView {
            let sections = dataSource.snapshot().sectionIdentifiers
            var sidebarSnapshot = AssetCatalogSidebarListView.Snapshot()
            sidebarSnapshot.appendSections([.main])
            sidebarSnapshot.appendItems(sections, toSection: .main)
            sidebar.dataSource.apply(sidebarSnapshot)
        }
    }

    func editItem(_ item: Rendition, presentingFrom optionalVcToPresentFrom: UIViewController? = nil, callback: ((Error?) -> Void)? = nil) {
        guard let preview = item.representation else { return }

        let vcToPresentFrom = optionalVcToPresentFrom ?? self

        let errorCallback: ItemEditorDelegate.ErrorCallback = callback ?? { error in
            if let error = error {
                vcToPresentFrom.errorAlert(error, title: SantanderL10n.t("Failed to edit item"))
            }
        }

        editorDelegate = ItemEditorDelegate(sender: self, selectedRendition: item, finishedEditingCallback: errorCallback)
        let vc: UIViewController
        switch preview {
        case .image(_):
            var conf = PHPickerConfiguration()
            conf.filter = .images
            conf.selectionLimit = 1
            let photoVC = PHPickerViewController(configuration: conf)
            photoVC.delegate = editorDelegate
            vc = photoVC
        case .color(let currentCgColor):
            let colorVC = UIColorPickerViewController()
            colorVC.delegate = editorDelegate
            colorVC.selectedColor = UIColor(cgColor: currentCgColor)
            vc = colorVC
        case .rawData:
            let documentPicker = UIDocumentPickerViewController(forOpeningContentTypes: [.data], asCopy: true)
            documentPicker.delegate = editorDelegate
            vc = documentPicker
        }

        vcToPresentFrom.present(vc, animated: true)
    }
}

extension AssetCatalogViewController: UICollectionViewDragDelegate {
    func collectionView(_ collectionView: UICollectionView, itemsForBeginning session: UIDragSession, at indexPath: IndexPath) -> [UIDragItem] {
        guard let dragItem = dataSource.itemIdentifier(for: indexPath)?.makeDragItem() else { return [] }

        return [
            dragItem
        ]
    }
}

extension AssetCatalogViewController: UISearchBarDelegate {
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        noResultsLabel.removeFromSuperview()
        guard !searchText.isEmpty else {
            updateDataSourceItems(collection: renditionCollection)
            return
        }

        let newCollection = renditionCollection.map { (type, renditions) in
            let newRenditions = renditions.filter { rend in
                return rend.name.localizedCaseInsensitiveContains(searchText)
            }

            return (type, newRenditions)
        }.filter { (_, rends) in
            !rends.isEmpty
        }

        updateDataSourceItems(collection: newCollection)

        if newCollection.isEmpty, noResultsLabel.superview == nil {
            noResultsLabel.text = SantanderL10n.t("No Results")
            noResultsLabel.font = .systemFont(ofSize: 20, weight: .bold)
            noResultsLabel.translatesAutoresizingMaskIntoConstraints = false
            view.addSubview(noResultsLabel)

            let guide = view.layoutMarginsGuide
            NSLayoutConstraint.activate([
                noResultsLabel.centerXAnchor.constraint(equalTo: guide.centerXAnchor),
                noResultsLabel.centerYAnchor.constraint(equalTo: guide.centerYAnchor)
            ])
        }
    }

    func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
        noResultsLabel.removeFromSuperview()
        updateDataSourceItems(collection: renditionCollection)
    }

    func fetchItemsFromFile() {
        do {
            let (newCatalog, newCollection) = try AssetCatalogWrapper.shared.renditions(forCarArchive: fileURL)
            self.catalog = newCatalog
            self.renditionCollection = newCollection
            updateDataSourceItems(collection: renditionCollection)
        } catch {
            let cancelAction = UIAlertAction(title: SantanderL10n.t("Dismiss"), style: .cancel) { _ in
                self.dismiss(animated: true)
            }

            errorAlert(error, title: SantanderL10n.t("Unable to update items"), presentingFromIfAvailable: nil, cancelAction: cancelAction)
        }
    }
}

extension AssetCatalogViewController {
    func scrollViewDidEndDragging(_ scrollView: UIScrollView, willDecelerate decelerate: Bool) {
        guard UIDevice.isiPad, !decelerate else { return }

        let visibleRect = CGRect(origin: collectionView.contentOffset, size: collectionView.bounds.size)
        let visiblePoint = CGPoint(x: visibleRect.midX, y: visibleRect.midY)

        guard let visibleIndexPath = collectionView.indexPathForItem(at: visiblePoint),
              let sidebar = splitViewController?.viewController(for: .primary) as? AssetCatalogSidebarListView else {
            return
        }

        sidebar.collectionView.selectItem(at: IndexPath(row: visibleIndexPath.section, section: 0), animated: true, scrollPosition: .top)
    }
}

extension AssetCatalogViewController {
    class ItemEditorDelegate: NSObject, PHPickerViewControllerDelegate, UIColorPickerViewControllerDelegate, UIDocumentPickerDelegate {
        let sender: AssetCatalogViewController
        let selectedRendition: Rendition

        typealias ErrorCallback = ((Error?) -> Void)
        var finishedEditingCallback: ErrorCallback?

        init(sender: AssetCatalogViewController, selectedRendition: Rendition, finishedEditingCallback: ErrorCallback?) {
            self.sender = sender
            self.selectedRendition = selectedRendition
            self.finishedEditingCallback = finishedEditingCallback
            super.init()
        }

        func picker(_ picker: PHPickerViewController, didFinishPicking results: [PHPickerResult]) {
            picker.dismiss(animated: true)
            guard let first = results.first else { return }
            first.itemProvider.loadObject(ofClass: UIImage.self) { [self] image, error in
                guard let image = image as? UIImage, let cgImage = image.cgImage else {
                    sender.errorAlert("无法获取所选图像。", title: SantanderL10n.t("Unable to edit item"))
                    return
                }

                edit(to: .image(cgImage))
            }
        }

        func colorPickerViewControllerDidFinish(_ viewController: UIColorPickerViewController) {
            edit(to: .color(viewController.selectedColor.cgColor))
        }

        func documentPicker(_ controller: UIDocumentPickerViewController, didPickDocumentsAt urls: [URL]) {
            guard let url = urls.first else { return }
            let didAccess = url.startAccessingSecurityScopedResource()
            defer {
                if didAccess {
                    url.stopAccessingSecurityScopedResource()
                }
            }

            do {
                edit(to: .rawData(try Data(contentsOf: url)))
            } catch {
                finishedEditingCallback?(error)
            }
        }

        func edit(to newItem: Rendition.Representation) {
            DispatchQueue.main.async { [self] in
                let tmpFilename = "\(sender.fileURL.lastPathComponent)-TMP-EDIT-\(UUID().uuidString.prefix(5))"
                let temporaryFileURL = URL(fileURLWithPath: NSTemporaryDirectory()).appendingPathComponent(tmpFilename)
                do {
                    try FileManager.default.copyItem(at: sender.fileURL, to: temporaryFileURL)
                    try sender.catalog.editItem(selectedRendition, fileURL: temporaryFileURL, to: newItem)
                    try FSOperation.perform(.removeItems(items: [sender.fileURL]), rootHelperConf: RootConf.shared)
                    try FSOperation.perform(.rename(item: temporaryFileURL, newPath: sender.fileURL), rootHelperConf: RootConf.shared)

                    finishedEditingCallback?(nil)
                    sender.fetchItemsFromFile()
                } catch {
                    finishedEditingCallback?(error)
                }
            }
        }
    }
}

class AssetCatalogCell: UICollectionViewCell {
    let nameLabel: UILabel = UILabel()
    let subtitleLabel: UILabel = UILabel()
    lazy var circleView: UIView? = rendition?.representation?.uiView
    var rendition: Rendition?
}

extension AssetCatalogCell {
    static let cellBackgroundColor: UIColor = .quaternarySystemFill

    func configure() {
        setupShape()

        guard let rendition = rendition else { return }
        nameLabel.text = rendition.name
        subtitleLabel.text = makeSubtitleText(forRendition: rendition)
        subtitleLabel.font = .preferredFont(forTextStyle: .caption1)
        subtitleLabel.textColor = .secondaryLabel

        let labelsStackView = UIStackView(arrangedSubviews: [nameLabel, subtitleLabel])
        labelsStackView.translatesAutoresizingMaskIntoConstraints = false
        labelsStackView.axis = .vertical

        let stackView = UIStackView(arrangedSubviews: [labelsStackView])
        stackView.translatesAutoresizingMaskIntoConstraints = false
        stackView.spacing = 10

        contentView.addSubview(stackView)
        let guide = contentView.layoutMarginsGuide
        if let circleView = circleView {
            circleView.layer.cornerRadius = 20
            circleView.layer.cornerCurve = .circular
            circleView.translatesAutoresizingMaskIntoConstraints = false
            stackView.insertArrangedSubview(circleView, at: 0)

            NSLayoutConstraint.activate([
                circleView.heightAnchor.constraint(equalTo: guide.heightAnchor),
                circleView.widthAnchor.constraint(equalTo: guide.heightAnchor),
            ])
        }

        stackView.constraintCompletely(to: guide)
    }

    func makeSubtitleText(forRendition rend: Rendition) -> String {
        return "\(SantanderL10n.t("Scale"))：\(rend.cuiRend.scale())"
    }

    override var reuseIdentifier: String? {
        return rendition?.name
    }

    func setupShape() {
        var bgConf = UIBackgroundConfiguration.clear()
        bgConf.backgroundColor = AssetCatalogCell.cellBackgroundColor
        bgConf.cornerRadius = 14
        backgroundConfiguration = bgConf
    }
}

class AssetCatalogDetailsView: UIView {
    var catalog: CUICatalog

    init(catalog: CUICatalog) {
        self.catalog = catalog
        super.init(frame: .zero)

        let testLabel = UILabel()
        testLabel.text = SantanderL10n.t("Hello")
        testLabel.translatesAutoresizingMaskIntoConstraints = false
        addSubview(testLabel)

        NSLayoutConstraint.activate([
            testLabel.centerXAnchor.constraint(equalTo: centerXAnchor),
            testLabel.leadingAnchor.constraint(equalTo: leadingAnchor)
        ])
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}

fileprivate extension CACornerMask {
    static func alongEdge(_ edge: CGRectEdge) -> CACornerMask {
        switch edge {
        case .maxXEdge: return [.layerMaxXMinYCorner, .layerMaxXMaxYCorner]
        case .maxYEdge: return [.layerMinXMaxYCorner, .layerMaxXMaxYCorner]
        case .minXEdge: return [.layerMinXMinYCorner, .layerMinXMaxYCorner]
        case .minYEdge: return [.layerMinXMinYCorner, .layerMaxXMinYCorner]
        }
    }
}

class AssetCatalogGridPreviewCell: UICollectionViewCell {
    var rendition: Rendition!
    var previewView: UIView!

    func configure() {
        var constraintCompletely: Bool = true
        if let preview = rendition.representation {
            previewView = preview.uiView
        } else {
            let noPreviewLabel = UILabel()
            noPreviewLabel.text = SantanderL10n.t("No Preview.")
            noPreviewLabel.textColor = .secondaryLabel
            previewView = noPreviewLabel
            constraintCompletely = false
        }

        previewView.clipsToBounds = true
        previewView.contentMode = .scaleAspectFit
        previewView.translatesAutoresizingMaskIntoConstraints = false

        contentView.addSubview(previewView)
        contentView.layer.cornerCurve = .continuous
        contentView.layer.cornerRadius = 12.0

        layer.shadowOpacity = 0.2
        layer.shadowRadius = 6.0

        pushCornerPropertiesToChildren()

        if constraintCompletely {
            previewView.constraintCompletely(to: contentView.layoutMarginsGuide)
        } else {
            NSLayoutConstraint.activate([
                previewView.centerXAnchor.constraint(equalTo: contentView.centerXAnchor),
                previewView.centerYAnchor.constraint(equalTo: contentView.centerYAnchor)
            ])
        }
    }

    override var reuseIdentifier: String? {
        rendition?.name
    }

    func pushCornerPropertiesToChildren() {
        previewView.layer.maskedCorners = contentView.layer.maskedCorners.union(.alongEdge(.maxYEdge))
        previewView.layer.cornerRadius = contentView.layer.cornerRadius
        previewView.layer.cornerCurve = contentView.layer.cornerCurve
    }
}

class AssetCatalogRenditionViewController: UIViewController {
    typealias DataSource = UICollectionViewDiffableDataSource<Section, ItemType>

    typealias DetailCellRegistration = UICollectionView.CellRegistration<UICollectionViewListCell, DetailItem>
    typealias ActionCellRegistration = UICollectionView.CellRegistration<UICollectionViewListCell, ItemAction>
    typealias GridPreviewCellRegistration = UICollectionView.CellRegistration<AssetCatalogGridPreviewCell, Rendition>

    var rendition: Rendition
    var collectionView: UICollectionView!
    var dataSource: DataSource!
    var sender: AssetCatalogViewController?

    init(rendition: Rendition, sender: AssetCatalogViewController?) {
        self.rendition = rendition
        self.sender = sender
        super.init(nibName: nil, bundle: nil)
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) hasn't been implemented")
    }

    override func viewDidLoad() {
        super.viewDidLoad()

        title = SantanderL10n.t("Info")
        configureCollectionView()
        configureDataSource()
        addItems()
    }

    func configureCollectionView() {
        self.collectionView = UICollectionView(frame: .zero, collectionViewLayout: makeLayout())
        collectionView.translatesAutoresizingMaskIntoConstraints = false
        collectionView.delegate = self
        collectionView.dragDelegate = self
        collectionView.backgroundColor = .secondarySystemBackground
        view.addSubview(collectionView)

        collectionView.constraintCompletely(to: view)
    }

    func editItem(sender: AssetCatalogViewController) {
        guard let saveIndx = sender.dataSource.indexPath(for: rendition) else { return }
        sender.editItem(rendition, presentingFrom: self) { [self] error in
            if let error = error {
                errorAlert(error, title: SantanderL10n.t("Failed to edit item"))
                return
            }

            dismiss(animated: true) {
                guard let newRend = sender.dataSource.itemIdentifier(for: saveIndx) else { return }
                let newVC = UINavigationController(rootViewController: AssetCatalogRenditionViewController(rendition: newRend, sender: sender))
                sender.present(newVC, animated: true)
            }
        }
    }

    func makeDetailCellBackgroundConfiguration() -> UIBackgroundConfiguration {
        var background = UIBackgroundConfiguration.listAccompaniedSidebarCell()
        background.cornerRadius = 8
        background.backgroundColor = .tertiarySystemBackground
        return background
    }

    func configureDataSource() {
        let listCellSecondaryTextFont: UIFont = .preferredFont(forTextStyle: .footnote)
        let detailCellBackgroundConf = makeDetailCellBackgroundConfiguration()

        let detailCellRegistration = DetailCellRegistration { cell, indexPath, details in
            var content = UIListContentConfiguration.cell()
            content.prefersSideBySideTextAndSecondaryText = true
            content.text = details.primaryText
            content.secondaryText = details.secondaryText
            content.secondaryTextProperties.font = listCellSecondaryTextFont
            cell.contentConfiguration = content
            cell.backgroundConfiguration = detailCellBackgroundConf
        }

        let previewCellRegistration = GridPreviewCellRegistration { cell, indexPath, itemIdentifier in
            cell.rendition = self.rendition
            cell.configure()
        }

        let actionCellRegistration = ActionCellRegistration { cell, indexPath, itemIdentifier in
            var conf = cell.defaultContentConfiguration()
            conf.text = itemIdentifier.displayText
            conf.image = itemIdentifier.displayImage

            if let color = itemIdentifier.textColor {
                conf.textProperties.color = color
            }

            conf.imageToTextPadding = 10
            cell.contentConfiguration = conf
            cell.backgroundConfiguration = detailCellBackgroundConf
        }

        self.dataSource = DataSource(collectionView: collectionView) { collectionView, indexPath, itemIdentifier in
            switch itemIdentifier {
            case .preview:
                return collectionView.dequeueConfiguredReusableCell(using: previewCellRegistration, for: indexPath, item: self.rendition)
            case .action(let action):
                return collectionView.dequeueConfiguredReusableCell(using: actionCellRegistration, for: indexPath, item: action)
            case .details(let detailItem):
                return collectionView.dequeueConfiguredReusableCell(using: detailCellRegistration, for: indexPath, item: detailItem)
            }
        }
    }

    func addItems() {
        var snapshot = NSDiffableDataSourceSnapshot<Section, ItemType>()
        snapshot.appendSections([.itemPreview])

        var actions: [ItemAction] = []
        if let image = rendition.image {
            let uiImage = UIImage(cgImage: image)

            let saveImageAction = ItemAction(displayText: SantanderL10n.t("Save"), displayImage: UIImage(systemName: "square.and.arrow.down")) {
                self.saveImage(uiImage)
            }

            let viewImageAction = ItemAction(displayText: "View", displayImage: UIImage(systemName: "magnifyingglass")) {
                let viewer = ImageViewerController(fileURL: nil, image: uiImage, title: self.rendition.name)
                self.present(UINavigationController(rootViewController: viewer), animated: true)
            }

            actions += [saveImageAction, viewImageAction]
        }

        if rendition.type.isEditable, let sender = sender {
            let editAction = ItemAction(displayText: "Edit", displayImage: UIImage(systemName: "gear")) {
                self.editItem(sender: sender)
            }

            actions.append(editAction)
        }

        if !actions.isEmpty {
            snapshot.appendSections([.itemActions])
            snapshot.appendItems(actions.map { return ItemType.action($0) }, toSection: .itemActions)
        }

        let size = rendition.cuiRend.unslicedSize()

        var itemDetails: [DetailItem] = []

        if rendition.namedLookup.name == rendition.namedLookup.renditionName {
            itemDetails.insert(DetailItem(primaryText: SantanderL10n.t("Name"), secondaryText: rendition.namedLookup.name), at: 0)
        } else {
            let bothNames = [
                DetailItem(primaryText: SantanderL10n.t("Lookup Name"), secondaryText: rendition.namedLookup.name),
                DetailItem(primaryText: SantanderL10n.t("Rendition Name"), secondaryText: rendition.namedLookup.renditionName)
            ]

            itemDetails.insert(contentsOf: bothNames, at: 0)
        }

        if !size.height.isZero {
            itemDetails.append(DetailItem(primaryText: SantanderL10n.t("Height"), secondaryText: size.height.description))
        }

        if !size.width.isZero {
            itemDetails.append(DetailItem(primaryText: SantanderL10n.t("Width"), secondaryText: size.width.description))
        }

        itemDetails.append(DetailItem(primaryText: SantanderL10n.t("Scale"), secondaryText: rendition.cuiRend.scale().description))

        let key = rendition.namedLookup.key
        let rendInfo: [DetailItem] = [
            DetailItem(primaryText: SantanderL10n.t("Idiom"), secondaryText: Rendition.Idiom(key)),
            DetailItem(primaryText: SantanderL10n.t("Appearance"), secondaryText: Rendition.Appearance(key)),
            DetailItem(primaryText: SantanderL10n.t("Display Gamut"), secondaryText: Rendition.DisplayGamut(key)),
            DetailItem(primaryText: SantanderL10n.t("Type"), secondaryText: rendition.type),
        ]

        snapshot.appendItems([.preview], toSection: .itemPreview)
        snapshot.appendSections([.itemInfo])
        snapshot.appendItems(ItemType.fromDetails(itemDetails), toSection: .itemInfo)

        if rendition.type == .multiSizeImageSet,
           let nsObjectSizes = rendition.cuiRend.value(forKey: "sizeIndexes") as? [NSObject] {
            let sizes = nsObjectSizes.compactMap { $0.value(forKey: "size") as? CGSize }
            let items = sizes.enumerated().map { (indx, size) in
                DetailItem(primaryText: "大小 \(indx)", secondaryText: "宽度：\(size.width)，高度：\(size.height)")
            }

            snapshot.appendSections([.specificTypeInfo])
            snapshot.appendItems(ItemType.fromDetails(items), toSection: .specificTypeInfo)
        }

        switch rendition.representation {
        case .color(let cgColor):
            let uiColor = UIColor(cgColor: cgColor)
            let codableColor = CodableColor(uiColor)

            let colorSpaceName = (cgColor.colorSpace?.name as? String ?? SantanderL10n.t("N/A"))
                .replacingOccurrences(of: "kCGColorSpace", with: "")
            let colorDetails = [
                DetailItem(primaryText: SantanderL10n.t("ColorSpace"), secondaryText: colorSpaceName),
                DetailItem(primaryText: SantanderL10n.t("Red"), secondaryText: String(format: "%.3f", codableColor.red)),
                DetailItem(primaryText: SantanderL10n.t("Blue"), secondaryText: String(format: "%.3f", codableColor.blue)),
                DetailItem(primaryText: SantanderL10n.t("Green"), secondaryText: String(format: "%.3f", codableColor.green)),
            ]

            snapshot.insertSections([.specificTypeInfo], afterSection: .itemInfo)
            snapshot.appendItems(ItemType.fromDetails(colorDetails), toSection: .specificTypeInfo)
        default:
            break
        }

        snapshot.appendSections([.renditionKeyInfo])
        snapshot.appendItems(ItemType.fromDetails(rendInfo), toSection: .renditionKeyInfo)

        if let sender = sender {
            let deleteImage = UIImage(systemName: "trash")?.withTintColor(.systemRed, renderingMode: .alwaysOriginal)
            let deleteAction = ItemAction(displayText: SantanderL10n.t("Delete"), displayImage: deleteImage, textColor: .systemRed) {
                let confirmationAlert = UIAlertController(title: SantanderL10n.t("Are you sure you want to delete this item?"), message: nil, preferredStyle: .actionSheet)
                let deleteAction = UIAlertAction(title: SantanderL10n.t("Delete"), style: .destructive) { [self] _ in
                    sender.deleteItem(rendition) { [self] error in
                        if let error = error {
                            errorAlert(error, title: SantanderL10n.t("Failed to delete item"))
                        } else {
                            dismiss(animated: true)
                        }
                    }
                }

                confirmationAlert.addAction(deleteAction)
                confirmationAlert.addAction(.cancel())

                self.present(confirmationAlert, animated: true)
            }

            snapshot.appendSections([.deleteItem])
            snapshot.appendItems([.action(deleteAction)], toSection: .deleteItem)
        }

        dataSource.apply(snapshot)
    }

    func makeLayout() -> UICollectionViewLayout {
        lazy var snapshot = dataSource.snapshot()
        let layout = UICollectionViewCompositionalLayout { sectionIndex, enviroment in
            let section = snapshot.sectionIdentifiers[sectionIndex]
            switch section {
            case .itemPreview:
                let itemSize = NSCollectionLayoutSize(widthDimension: .fractionalWidth(1.0),
                                                     heightDimension: .estimated(180))
                let item = NSCollectionLayoutItem(layoutSize: itemSize)
                let groupSize = NSCollectionLayoutSize(widthDimension: .fractionalWidth(1.0),
                                                       heightDimension: .estimated(180))
                let group = NSCollectionLayoutGroup.horizontal(layoutSize: groupSize, subitem: item, count: 1)
                group.interItemSpacing = .fixed(20)

                return NSCollectionLayoutSection(group: group)
            case .itemActions:
                let itemSize = NSCollectionLayoutSize(widthDimension: .fractionalWidth(1.0),
                                                     heightDimension: .fractionalHeight(1.0))
                let item = NSCollectionLayoutItem(layoutSize: itemSize)

                let groupSize = NSCollectionLayoutSize(widthDimension: .fractionalWidth(1.0),
                                                      heightDimension: .absolute(44))
                let group = NSCollectionLayoutGroup.horizontal(layoutSize: groupSize, subitem: item, count: snapshot.numberOfItems(inSection: section))

                let spacing = CGFloat(10)
                group.interItemSpacing = .fixed(spacing)

                let section = NSCollectionLayoutSection(group: group)
                section.interGroupSpacing = spacing
                section.contentInsets = NSDirectionalEdgeInsets(top: 0, leading: 16, bottom: 0, trailing: 16)
                return section
            default:
                let list = NSCollectionLayoutSection.list(
                    using: .init(appearance: .sidebar),
                    layoutEnvironment: enviroment
                )
                list.interGroupSpacing = 5

                return list
            }
        }
        let config = UICollectionViewCompositionalLayoutConfiguration()
        config.interSectionSpacing = 10
        layout.configuration = config

        return layout
    }

    enum Section: Hashable {
        case itemPreview
        case itemActions
        case itemInfo
        case specificTypeInfo
        case renditionKeyInfo
        case deleteItem
    }

    enum ItemType: Hashable {
        case preview
        case action(ItemAction)
        case details(DetailItem)

        static func fromDetails(_ details: [DetailItem]) -> [ItemType] {
            return details.map { details in
                ItemType.details(details)
            }
        }
    }

    struct DetailItem: Hashable {
        let primaryText: String
        let secondaryText: String

        init(primaryText: String, secondaryText: String?) {
            self.primaryText = primaryText
            self.secondaryText = secondaryText ?? SantanderL10n.t("N/A")
        }

        init<DetailTextType: CustomStringConvertible>(primaryText: String, secondaryText: DetailTextType?) {
            self.primaryText = primaryText
            self.secondaryText = secondaryText?.description ?? SantanderL10n.t("N/A")
        }
    }

    struct ItemAction: Hashable {
        static func == (lhs: ItemAction, rhs: ItemAction) -> Bool {
            return lhs.displayText == rhs.displayText
        }

        let displayText: String
        let displayImage: UIImage?
        let textColor: UIColor?
        let action: (() -> Void)

        init(displayText: String, displayImage: UIImage?, textColor: UIColor? = nil, action: @escaping () -> Void) {
            self.displayText = displayText
            self.displayImage = displayImage
            self.textColor = textColor
            self.action = action
        }

        func hash(into hasher: inout Hasher) {
            hasher.combine(displayText)
            hasher.combine(displayImage)
            hasher.combine(textColor)
        }
    }
}

extension AssetCatalogRenditionViewController: UICollectionViewDelegate, UICollectionViewDragDelegate {
    func collectionView(_ collectionView: UICollectionView, contextMenuConfigurationForItemAt indexPath: IndexPath, point: CGPoint) -> UIContextMenuConfiguration? {
        UIContextMenuConfiguration(identifier: nil, previewProvider: nil) { [self] _ in
            let item = dataSource.itemIdentifier(for: indexPath)
            switch item {
            case .action(let itemAction):
                let menuAction = UIAction(title: itemAction.displayText, image: itemAction.displayImage) { _ in
                    itemAction.action()
                }

                return UIMenu(children: [menuAction])
            case .details(let detail):
                let menuAction = UIAction(title: SantanderL10n.t("Copy"), image: UIImage(systemName: "doc.on.doc")) { _ in
                    UIPasteboard.general.string = detail.secondaryText
                }

                return UIMenu(children: [menuAction])
            default:
                return nil
            }
        }
    }

    func collectionView(_ collectionView: UICollectionView, shouldHighlightItemAt indexPath: IndexPath) -> Bool {
        switch dataSource.itemIdentifier(for: indexPath) {
        case .action(_): return true
        default: return false
        }
    }

    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        switch dataSource.itemIdentifier(for: indexPath) {
        case .action(let action): action.action()
        default: break
        }
    }

    func collectionView(_ collectionView: UICollectionView, itemsForBeginning session: UIDragSession, at indexPath: IndexPath) -> [UIDragItem] {
        guard indexPath.section == 0, let dragItem = rendition.makeDragItem() else { return [] }

        if let cell = collectionView.cellForItem(at: indexPath) as? AssetCatalogGridPreviewCell {
            dragItem.previewProvider = {
                let params = UIDragPreviewParameters()
                params.backgroundColor = .clear
                return UIDragPreview(view: cell.previewView, parameters: params)
            }
        }

        return [
            dragItem
        ]
    }
}

class AssetCatalogSectionHeader: UICollectionReusableView {
    let stackView = UIStackView()

    let titleLabel = UILabel()
    let subtitleLabel = UILabel()

    func configure(withSection section: RenditionType, snapshot: NSDiffableDataSourceSnapshot<RenditionType, Rendition>, sender: AssetCatalogViewController) {
        titleLabel.text = section.description
        titleLabel.font = .preferredFont(forTextStyle: .title3)

        subtitleLabel.text = "\(snapshot.itemIdentifiers(inSection: section).count) \(SantanderL10n.t("Items"))"
        subtitleLabel.textColor = .secondaryLabel
        subtitleLabel.font = .preferredFont(forTextStyle: .caption1)

        stackView.addArrangedSubview(titleLabel)
        stackView.addArrangedSubview(subtitleLabel)

        stackView.axis = .vertical
        stackView.translatesAutoresizingMaskIntoConstraints = false
        addSubview(stackView)

        let guide = layoutMarginsGuide
        NSLayoutConstraint.activate([
            stackView.centerYAnchor.constraint(equalTo: guide.centerYAnchor),
            stackView.leadingAnchor.constraint(equalTo: guide.leadingAnchor)
        ])
    }
}

class AssetCatalogSidebarListView: UIViewController {

    enum Section: Hashable {
        case main
    }

    typealias DataSource = UICollectionViewDiffableDataSource<Section, RenditionType>
    typealias Snapshot = NSDiffableDataSourceSnapshot<Section, RenditionType>
    typealias CellRegistration = UICollectionView.CellRegistration<UICollectionViewListCell, RenditionType>

    let catalogController: AssetCatalogViewController

    var collectionView: UICollectionView!
    var dataSource: DataSource!

    lazy var sections: [RenditionType] = []

    init(catalogController: AssetCatalogViewController) {
        self.catalogController = catalogController

        super.init(nibName: nil, bundle: nil)
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    override func viewDidLoad() {
        super.viewDidLoad()

        makeCollectionView()
        makeDataSource()
        addItems()

        splitViewController?.setViewController(catalogController, for: .secondary)

        title = catalogController.fileURL.deletingPathExtension().lastPathComponent
        navigationController?.navigationBar.prefersLargeTitles = true
    }

    func makeCollectionView() {
        let layout = UICollectionViewCompositionalLayout { _, env in
            return .list(using: UICollectionLayoutListConfiguration(appearance: .sidebar), layoutEnvironment: env)
        }

        collectionView = UICollectionView(frame: .zero, collectionViewLayout: layout)
        collectionView.translatesAutoresizingMaskIntoConstraints = false
        collectionView.delegate = self
        view.addSubview(collectionView)

        collectionView.constraintCompletely(to: view)
    }

    func makeDataSource() {

        let cellRegistration = CellRegistration { cell, indexPath, itemIdentifier in
            var conf = cell.defaultContentConfiguration()
            conf.text = itemIdentifier.description
            conf.image = itemIdentifier.displayImage
            cell.contentConfiguration = conf
        }

        self.dataSource = DataSource(collectionView: collectionView) { collectionView, indexPath, itemIdentifier in
            return collectionView.dequeueConfiguredReusableCell(using: cellRegistration, for: indexPath, item: itemIdentifier)
        }
    }

    func addItems() {
        var snapshot = Snapshot()
        snapshot.appendSections([.main])
        snapshot.appendItems(sections, toSection: .main)
        dataSource.apply(snapshot)
    }
}

extension AssetCatalogSidebarListView: UICollectionViewDelegate {
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        catalogController.collectionView.scrollToItem(at: IndexPath(row: 0, section: indexPath.row), at: .top, animated: true)
    }
}

fileprivate extension RenditionType {
    var displayImage: UIImage? {
        switch self {
        case .image, .svg:
            return UIImage(systemName: "photo")
        case .icon:
            return UIImage(systemName: "app")
        case .imageSet:
            return UIImage(systemName: "photo.stack")
        case .multiSizeImageSet:
            return UIImage(systemName: "cube.box")
        case .pdf:
            return UIImage(systemName: "doc.richtext")
        case .color:
            return UIImage(systemName: "paintbrush")
        case .rawData:
            return UIImage(systemName: "text.quote")
        case .unknown:
            return UIImage(systemName: "questionmark.app")
        }
    }
}

class AudioPlayerViewController: UIViewController {
    let fileURL: URL
    var playButton: UIButton!
    var loopButton: UIButton!
    var playbackSlider: UISlider!
    var durationLabel: UILabel!
    var currentProgressLabel: UILabel!
    var forwardButton: UIButton!
    var backwardButton: UIButton!

    var player: AVAudioPlayer
    var asset: AVAsset
    lazy var displayLink: CADisplayLink = CADisplayLink(target: self, selector: #selector(sychronizeSliderProgress))

    var doLoop: Bool = false

    var playbackCallback: (() -> Void)? = nil

    var playbackSpeedRate: Float = UserPreferences.audioVCSpeed {
        didSet {
            UserPreferences.audioVCSpeed = playbackSpeedRate
            player.rate = playbackSpeedRate
        }
    }

    var itemName: String {
        let nameFromMetadata = asset.metadata.first { $0.commonKey?.rawValue == "title" }?.stringValue
        return nameFromMetadata ?? fileURL.lastPathComponent
    }

    var artistName: String? {
        return asset.metadata.first { $0.commonKey?.rawValue == "artist" }?.stringValue
    }

    var skipDuration: Int = UserPreferences.skipDuration {
        didSet {
            UserPreferences.skipDuration = skipDuration
        }
    }

    let availableSkipDurations: [Int] = [5, 10, 15, 30, 45, 60, 90]
    let availableSpeedRates: [Float] = [0.5, 1.0, 1.5, 2.0]

    lazy var artworkImage: UIImage? = _getArtworkImage()

    func _getArtworkImage() -> UIImage? {
        guard let data = asset.metadata.first(where: { $0.commonKey?.rawValue == "artwork" })?.dataValue, let image = UIImage(data: data) else {
            return nil
        }

        return image
    }

    func playButtonSymbolName() -> String {
        player.isPlaying ? "pause.fill" : "play.fill"
    }

    func playButtonImage(withSize pointSize: CGFloat = 45, imageTintColor: UIColor? = .systemGray) -> UIImage? {
        let conf = UIImage.SymbolConfiguration(pointSize: pointSize, weight: .medium, scale: .medium)

        let imageSymbolName = playButtonSymbolName()
        let image = UIImage(systemName: imageSymbolName, withConfiguration: conf)
        if let imageTintColor = imageTintColor {
            return image?.withTintColor(imageTintColor, renderingMode: .alwaysOriginal)
        }

        return image
    }

    init(fileURL: URL, player: AVAudioPlayer) {
        self.fileURL = fileURL
        self.asset = AVAsset(url: fileURL)
        self.player = player

        self.player.enableRate = true
        self.player.rate = playbackSpeedRate

        super.init(nibName: nil, bundle: nil)
    }

    convenience init(fileURL: URL) throws {
        self.init(fileURL: fileURL, player: try AVAudioPlayer(contentsOf: fileURL))
    }

    convenience init(fileURL: URL, data: Data) throws {
        self.init(fileURL: fileURL, player: try AVAudioPlayer(data: data))
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    override func viewDidLoad() {
        super.viewDidLoad()

        self.view.backgroundColor = .secondarySystemBackground
        setupBarButtons()

        displayLink.add(to: .main, forMode: .default)

        addItemToSystemMediaPlayer()

        player.delegate = self
        let playAction = UIAction(image: playButtonImage()) { _ in
            self.play()
        }

        self.playButton = UIButton(primaryAction: playAction)

        self.playbackSlider = UISlider()

        playbackSlider.minimumValue = 0
        playbackSlider.maximumValue = Float(player.duration)
        playbackSlider.isContinuous = false

        playbackSlider.setThumbImage(UIImage(systemName: "circle.fill"), for: .normal)
        playbackSlider.tintColor = .lightGray
        playbackSlider.addTarget(self, action: #selector(sliderDidChange(_:)), for: .valueChanged)
        playbackSlider.addTarget(self, action: #selector(didBeginDraggingSlider), for: .touchDown)

        let titleLabel = UILabel()
        titleLabel.text = itemName
        titleLabel.font = .preferredFont(forTextStyle: .title2)
        titleLabel.textAlignment = .left

        let artistLabel = UILabel()
        artistLabel.text = artistName ?? SantanderL10n.t("Unknown Artist")
        artistLabel.textAlignment = .left
        artistLabel.textColor = .systemGray

        self.durationLabel = UILabel()
        durationLabel.text = format(timeInterval: player.duration)
        durationLabel.textColor = .systemGray

        self.currentProgressLabel = UILabel()
        currentProgressLabel.text = format(timeInterval: player.duration)
        currentProgressLabel.textColor = .systemGray

        let loopAction = UIAction(image: loopButtonImage()) { action in
            self.doLoop.toggle()
            self.loopButton.setImage(self.loopButtonImage(), for: .normal)
        }
        self.loopButton = UIButton(primaryAction: loopAction)

        self.forwardButton = UIButton(
            primaryAction: UIAction(
                image: UIImage(systemName: "goforward")?.withTintColor(.systemGray, renderingMode: .alwaysOriginal)
            ) { _ in
                self.player.currentTime += Double(self.skipDuration)
            }
        )

        self.backwardButton = UIButton(
            primaryAction: UIAction(
                image: UIImage(systemName: "gobackward")?.withTintColor(.systemGray, renderingMode: .alwaysOriginal)
            ) { _ in
                self.player.currentTime -= Double(self.skipDuration)
            }
        )

        let buttonsStackView = UIStackView(arrangedSubviews: [backwardButton, playButton, forwardButton])
        buttonsStackView.spacing = 40

        let labelsStackView = UIStackView(arrangedSubviews: [titleLabel, artistLabel])
        labelsStackView.axis = .vertical

        durationLabel.translatesAutoresizingMaskIntoConstraints = false
        playbackSlider.translatesAutoresizingMaskIntoConstraints = false
        buttonsStackView.translatesAutoresizingMaskIntoConstraints = false
        labelsStackView.translatesAutoresizingMaskIntoConstraints = false
        loopButton.translatesAutoresizingMaskIntoConstraints = false
        currentProgressLabel.translatesAutoresizingMaskIntoConstraints = false

        view.addSubview(buttonsStackView)
        view.addSubview(labelsStackView)
        view.addSubview(durationLabel)
        view.addSubview(playbackSlider)
        view.addSubview(currentProgressLabel)
        view.addSubview(loopButton)

        NSLayoutConstraint.activate([
            playbackSlider.centerYAnchor.constraint(equalTo: view.centerYAnchor, constant: 120),
            playbackSlider.trailingAnchor.constraint(equalTo: view.layoutMarginsGuide.trailingAnchor),
            playbackSlider.leadingAnchor.constraint(equalTo: view.layoutMarginsGuide.leadingAnchor),

            buttonsStackView.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            buttonsStackView.centerYAnchor.constraint(equalTo: playbackSlider.centerYAnchor, constant: 80),

            labelsStackView.trailingAnchor.constraint(equalTo: playbackSlider.trailingAnchor),
            labelsStackView.leadingAnchor.constraint(equalTo: playbackSlider.leadingAnchor),
            labelsStackView.bottomAnchor.constraint(equalTo: playbackSlider.topAnchor, constant: -10),

            durationLabel.trailingAnchor.constraint(equalTo: titleLabel.trailingAnchor),
            durationLabel.topAnchor.constraint(equalTo: playbackSlider.bottomAnchor),

            currentProgressLabel.leadingAnchor.constraint(equalTo: titleLabel.leadingAnchor),
            currentProgressLabel.topAnchor.constraint(equalTo: playbackSlider.bottomAnchor),

            loopButton.trailingAnchor.constraint(equalTo: artistLabel.trailingAnchor),
            loopButton.topAnchor.constraint(equalTo: artistLabel.topAnchor)
        ])

    }

    func play() {
        if player.isPlaying {
            player.pause()
        } else {
            try? AVAudioSession.sharedInstance().setCategory(.playback)
            try? AVAudioSession.sharedInstance().setActive(true, options: .notifyOthersOnDeactivation)

            player.play()
        }

        setPlayButtonImage()
        playbackCallback?()
    }

    func setPlayButtonImage() {
        playButton.setImage(playButtonImage(), for: .normal)
    }

    @objc
    func sliderDidChange(_ sender: UISlider) {
        player.currentTime = Double(sender.value)
        displayLink.isPaused = false
    }

    @objc
    func sychronizeSliderProgress() {
        if !playbackSlider.isTracking {
            MPNowPlayingInfoCenter.default().nowPlayingInfo?[MPMediaItemPropertyPlaybackDuration] = player.duration
            MPNowPlayingInfoCenter.default().nowPlayingInfo?[MPNowPlayingInfoPropertyElapsedPlaybackTime] = player.currentTime
        }

        let synchronized = player.currentTime
        playbackSlider.setValue(Float(synchronized), animated: true)
        currentProgressLabel.text = format(timeInterval: synchronized)
        if let currentTimeLeft = format(timeInterval: player.duration - player.currentTime) {
            self.durationLabel.text = "-\(currentTimeLeft)"
        }

        displayLink.isPaused = false
    }

    @objc func didBeginDraggingSlider() {
        displayLink.isPaused = true
    }

    func format(timeInterval: TimeInterval) -> String? {
        let formatter = DateComponentsFormatter()

        formatter.zeroFormattingBehavior = []

        formatter.allowedUnits = [.second, .minute]
        if timeInterval >= 3600 {
            formatter.allowedUnits.insert(.hour)
        }

        return formatter.string(from: timeInterval)
    }

    func loopButtonImage() -> UIImage? {
        let image = UIImage(systemName: "repeat")
        if !self.doLoop {
            return image?.withTintColor(.systemGray, renderingMode: .alwaysOriginal)
        }

        return image
    }

    func setupBarButtons() {
        let durationActions = availableSkipDurations.map { duration in
            UIAction(title: duration.description, state: self.skipDuration == duration ? .on : .off) { _ in
                self.skipDuration = duration
                self.setupBarButtons()
            }
        }

        let skipDurationSubMenu = UIMenu(title: SantanderL10n.t("Backward / Forward duration"), children: durationActions)

        let adjustSpeedActions = availableSpeedRates.map { rate in
            UIAction(title: rate.description, state: self.playbackSpeedRate == rate ? .on : .off) { _ in
                self.playbackSpeedRate = rate
                self.setupBarButtons()
            }
        }

        let adjustSpeedMenu = UIMenu(title: SantanderL10n.t("Speed"), image: UIImage(systemName: "speedometer"), children: adjustSpeedActions)
        let menu = UIMenu(children: [adjustSpeedMenu, skipDurationSubMenu])
        self.navigationItem.rightBarButtonItem = UIBarButtonItem(image: UIImage(systemName: "ellipsis.circle"), menu: menu)
        self.navigationItem.leftBarButtonItem = UIBarButtonItem(title: SantanderL10n.t("Dismiss"), primaryAction: UIAction { _ in
            self.dismiss(animated: true)
        })
    }

    func addItemToSystemMediaPlayer() {
        let center = MPNowPlayingInfoCenter.default()

        UIApplication.shared.beginReceivingRemoteControlEvents()
        MPRemoteCommandCenter.shared().playCommand.addTarget { event in
            self.player.play()
            self.setPlayButtonImage()
            self.playbackCallback?()
            return .success
        }

        MPRemoteCommandCenter.shared().pauseCommand.addTarget { event in
            self.player.pause()
            self.setPlayButtonImage()
            self.playbackCallback?()
            return .success
        }

        MPRemoteCommandCenter.shared().nextTrackCommand.addTarget {event in
            self.player.currentTime += Double(self.skipDuration)
            return .success
        }

        MPRemoteCommandCenter.shared().previousTrackCommand.addTarget {event in
            self.player.currentTime -= Double(self.skipDuration)
            return .success
        }

        var info: [String: Any] = [
            MPMediaItemPropertyTitle: self.itemName,
            MPNowPlayingInfoPropertyMediaType: MPNowPlayingInfoMediaType.audio.rawValue,
            MPNowPlayingInfoPropertyAssetURL: self.fileURL,
            MPNowPlayingInfoPropertyIsLiveStream: false
        ]

        if let album = asset.metadata.first(where: { $0.commonKey?.rawValue == "album" })?.stringValue {
            info[MPMediaItemPropertyAlbumTitle] = album
        }

        if let artist = self.artistName {
            info[MPMediaItemPropertyArtist] = artist
        }

        if let artworkImage = artworkImage {
            let mpArtwork = MPMediaItemArtwork(boundsSize: artworkImage.size) { _ in
                return artworkImage
            }

            info[MPMediaItemPropertyArtwork] = mpArtwork
        }

        center.nowPlayingInfo = info
    }

    override func dismiss(animated flag: Bool, completion: (() -> Void)? = nil) {
        player.stop()
        super.dismiss(animated: flag, completion: completion)
    }

    func removeFromSystemMediaPlayer() {
        MPNowPlayingInfoCenter.default().nowPlayingInfo = nil
    }
}

extension AudioPlayerViewController: AVAudioPlayerDelegate {
    func audioPlayerDidFinishPlaying(_ player: AVAudioPlayer, successfully flag: Bool) {
        if self.doLoop {
            player.play()
        }

        setPlayButtonImage()
        playbackCallback?()
    }
}

class AudioPlayerToolbarView: UIView {
    let audioPlayerController: AudioPlayerViewController
    weak var delegate: AudioPlayerToolbarDelegate?
    var playButton: UIButton!

    init(_ audioPlayerController: AudioPlayerViewController, frame: CGRect) {
        self.audioPlayerController = audioPlayerController

        super.init(frame: frame)

        let titleLabel = UILabel()
        titleLabel.text = audioPlayerController.itemName
        titleLabel.translatesAutoresizingMaskIntoConstraints = false
        addSubview(titleLabel)

        let cancelAction = UIAction(image: UIImage(systemName: "xmark.circle")) { _ in
            self.delegate?.audioToolbarDidClickCancelButton(self)
        }

        self.playButton = UIButton()
        setPlayButtonImage()
        let playOrStopAction = UIAction { _ in
            self.playOrStop()
        }

        playButton.addAction(playOrStopAction, for: .touchUpInside)

        audioPlayerController.playbackCallback = {
            self.setPlayButtonImage()
        }

        let cancelButton = UIButton(primaryAction: cancelAction)
        let buttonsStackView = UIStackView(arrangedSubviews: [playButton, cancelButton])
        buttonsStackView.spacing = 10
        buttonsStackView.translatesAutoresizingMaskIntoConstraints = false

        addSubview(buttonsStackView)

        NSLayoutConstraint.activate([
            titleLabel.leadingAnchor.constraint(equalTo: layoutMarginsGuide.leadingAnchor),
            titleLabel.centerYAnchor.constraint(equalTo: centerYAnchor),

            buttonsStackView.centerYAnchor.constraint(equalTo: centerYAnchor),
            buttonsStackView.trailingAnchor.constraint(equalTo: layoutMarginsGuide.trailingAnchor)
        ])
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    func playOrStop() {
        audioPlayerController.play()
        setPlayButtonImage()
    }

    func setPlayButtonImage() {
        playButton.setImage(audioPlayerController.playButtonImage(withSize: 20, imageTintColor: nil), for: .normal)
    }
}

protocol AudioPlayerToolbarDelegate: AnyObject {
    func audioToolbarDidClickCancelButton(_ toolbar: AudioPlayerToolbarView)
}

struct FileEditor {
    let type: FileEditorType
    let viewController: UIViewController

    static func preferred(forURL _url: Path) -> FileEditor? {
        let url = _url.url
        if url.pathExtension == "car", let carVC = FileEditorType.assetCatalog.viewController(forPath: url, data: nil) {
            return FileEditor(type: .assetCatalog, viewController: carVC)
        }

        guard let data = try? Data(contentsOf: url) else {
            return nil
        }

        let type = url.contentType
        if type == .unixExecutable {
            return FileEditor(type: .executable, viewController: BinaryExecutionViewController(executableURL: url))
        }

        if type?.isOfType(.audio) ?? false, let audio = FileEditorType.audio.viewController(forPath: url, data: data) {
            return FileEditor(type: .audio, viewController: audio)
        }

        if type?.isOfType(.font) ?? false, let fontVC = FileEditorType.font.viewController(forPath: url, data: data) {
            return FileEditor(type: .font, viewController: fontVC)
        }

        if let imageVC = FileEditorType.image.viewController(forPath: url, data: data) {
            return FileEditor(type: .image, viewController: imageVC)
        }

        if (type?.isOfType(.video) ?? false || type?.isOfType(.movie) ?? false),
            let videoPlayer = FileEditorType.video.viewController(forPath: url, data: data) {
            return FileEditor(type: .video, viewController: videoPlayer)
        }

        if let plistVc = FileEditorType.propertyList.viewController(forPath: url, data: data) {
            return FileEditor(type: .propertyList, viewController: plistVc)
        }

        if url.pathExtension == "json", let jsonVC = FileEditorType.json.viewController(forPath: url, data: data) {
            return FileEditor(type: .json, viewController: jsonVC)
        }

        if let textEditorVc = FileEditorType.text.viewController(forPath: url, data: data) {
            return FileEditor(type: .text, viewController: textEditorVc)
        }

        return nil
    }

    static func allEditors(forPath path: Path) -> [FileEditor] {
        let url = path.url
        let data = try? Data(contentsOf: url)

        return FileEditorType.allCases.compactMap { type in
            guard let vc = type.viewController(forPath: url, data: data) else {
                return nil
            }
            return FileEditor(type: type, viewController: vc)
        }
    }

    func display(senderVC: UIViewController) {
        let vcToPresent: UIViewController
        if type.useNavigationController {
            vcToPresent = UINavigationController(rootViewController: viewController)
        } else {
            vcToPresent = viewController
        }

        if type.presentAsFullScreen {
            vcToPresent.modalPresentationStyle = .fullScreen
        }

        senderVC.present(vcToPresent, animated: true)
    }
}

enum FileEditorType: CustomStringConvertible, CaseIterable {
    case audio, image, video
    case propertyList, json, text, font
    case assetCatalog
    case executable

    func viewController(forPath path: URL, data: Data?) -> UIViewController? {
        if self == .assetCatalog {
            guard path.pathExtension == "car",
                  let vc = try? AssetCatalogViewController(catalogFileURL: path) else {
                return nil
            }

            if UIDevice.isiPad {
                return __makeSplitViewController(with: AssetCatalogSidebarListView(catalogController: vc), for: .primary)
            }

            return vc
        }

        guard let data = data else { return nil }

        switch self {
        case .audio:
            return try? AudioPlayerViewController(fileURL: path, data: data)
        case .propertyList:
            let fmt: UnsafeMutablePointer<PropertyListSerialization.PropertyListFormat> = .allocate(capacity: 4)
            defer { fmt.deallocate() }
            let plist = try? PropertyListSerialization.propertyList(from: data, format: fmt)

            let contentCanEdit = !PathPermissions.isLocked(at: path)
            if let dict = plist as? [String: Any] {
                return PlistTreeEditorViewController(rootValue: dict, format: fmt.pointee, fileURL: path, title: path.lastPathComponent, canEdit: contentCanEdit)
            } else if let arr = plist as? Array<Any> {
                return PlistTreeEditorViewController(rootValue: arr, format: fmt.pointee, fileURL: path, title: path.lastPathComponent, canEdit: contentCanEdit)
            }

            return nil
        case .json:

            let json = try? JSONSerialization.jsonObject(with: data)
            let contentCanEdit = !PathPermissions.isLocked(at: path)

            if let dict = json as? [String: Any] {
                return SerializedDocumentViewController(dictionary: dict.asSerializedDictionary(), type: .json, title: path.lastPathComponent, fileURL: path, parentController: nil, canEdit: contentCanEdit)
            } else if let arr = json as? Array<Any> {
                return SerializedArrayViewController(array: arr, type: .json, parentController: nil, title: path.lastPathComponent, fileURL: path, canEdit: contentCanEdit)
            }

            return nil
        case .text:
            guard let stringContents = String(data: data, encoding: .utf8) else {
                return nil
            }

            let textVC = TextFileEditorViewController(fileURL: path, contents: stringContents)
            if UIDevice.isiPad {
                return __makeSplitViewController(with: textVC, for: .secondary)
            }

            return textVC
        case .image:
            guard let image = UIImage(data: data) else {
                return nil
            }

            return ImageViewerController(fileURL: path, image: image)
        case .video:
            let type = path.contentType
            guard (type?.isOfType(.movie) ?? false || type?.isOfType(.video) ?? false) else {
                return nil
            }

            let controller = AVPlayerViewController()
            controller.player = AVPlayer(url: path)
            return controller
        case .font:
            guard let descriptors = CTFontManagerCreateFontDescriptorsFromURL(path as CFURL) as? [CTFontDescriptor], !descriptors.isEmpty else {
                return nil
            }

            return FontViewerController(selectedFont: descriptors.first!.uiFont, descriptors: descriptors)
        case .executable:
            return BinaryExecutionViewController(executableURL: path)
        case .assetCatalog: return nil
        }
    }

    private func __makeSplitViewController(with vc: UIViewController, for column: UISplitViewController.Column) -> UISplitViewController {
        let splitVC = UISplitViewController(style: .doubleColumn)
        splitVC.setViewController(vc, for: column)
        return splitVC
    }

    var description: String {
        switch self {
        case .audio:
            return SantanderL10n.t("Audio Player")
        case .video:
            return SantanderL10n.t("Video Player")
        case .image:
            return SantanderL10n.t("Image Viewer")
        case .propertyList:
            return SantanderL10n.t("Property List Editor")
        case .json:
            return SantanderL10n.t("JSON Viewer")
        case .font:
            return SantanderL10n.t("Font Viewer")
        case .text:
            return SantanderL10n.t("Text Editor")
        case .assetCatalog:
            return SantanderL10n.t("Asset Catalog Viewer")
        case .executable:
            return SantanderL10n.t("Executable Runner")
        }
    }

    var presentAsFullScreen: Bool {
        switch self {
        case .text, .image, .video, .executable:
            return true
        case .audio, .font:
            return false
        case .propertyList, .json, .assetCatalog:
            return UIDevice.isiPad
        }
    }

    var useNavigationController: Bool {
        switch self {
        case .video:
            return false
        case .text, .assetCatalog:
            return !UIDevice.isiPad
        default:
            return true
        }
    }
}

class BinaryExecutionViewController: UIViewController {
    let executableURL: URL
    var task: NSTask = NSTask()
    var textView: UITextView!

    init(executableURL: URL) {
        self.executableURL = executableURL

        super.init(nibName: nil, bundle: nil)
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    override func viewDidLoad() {
        super.viewDidLoad()

        view.backgroundColor = .secondarySystemBackground

        title = SantanderL10n.t("Execution")
        let doneAction = UIAction {
            if self.task.isRunning {
                self.task.interrupt()
            }
            self.dismiss(animated: true)
        }

        navigationItem.rightBarButtonItem = UIBarButtonItem(systemItem: .done, primaryAction: doneAction)
        configureNavigationBarToNormal()

        let executableTextField = UITextField()

        let action = UIAction {
            if self.task.isRunning {
                self.task.interrupt()
            }
            self.spawnExecutable(pathAndArgs: executableTextField.text!)
        }

        executableTextField.autocorrectionType = .no
        executableTextField.returnKeyType = .go
        executableTextField.addAction(action, for: .primaryActionTriggered)
        executableTextField.text = executableURL.path
        executableTextField.font = UIFont(name: "Menlo", size: UIFont.systemFontSize)
        executableTextField.translatesAutoresizingMaskIntoConstraints = false
        executableTextField.backgroundColor = .systemBackground
        executableTextField.inputAccessoryView = makeKeyboardToolbar(forTextField: executableTextField)
        view.addSubview(executableTextField)

        let guide = view.safeAreaLayoutGuide
        NSLayoutConstraint.activate([
            executableTextField.trailingAnchor.constraint(equalTo: guide.trailingAnchor),
            executableTextField.leadingAnchor.constraint(equalTo: guide.leadingAnchor),
            executableTextField.topAnchor.constraint(equalTo: guide.topAnchor),
            executableTextField.heightAnchor.constraint(equalToConstant: 50),
        ])

        self.textView = UITextView()
        textView.text = ""
        textView.font = .systemFont(ofSize: 20)
        textView.isEditable = false
        textView.translatesAutoresizingMaskIntoConstraints = false
        textView.backgroundColor = view.backgroundColor
        view.addSubview(textView)

        NSLayoutConstraint.activate([
            textView.leadingAnchor.constraint(equalTo: guide.leadingAnchor),
            textView.trailingAnchor.constraint(equalTo: guide.trailingAnchor),
            textView.topAnchor.constraint(equalTo: executableTextField.bottomAnchor),
            textView.heightAnchor.constraint(equalTo: view.heightAnchor)
        ])
    }

    func makeKeyboardToolbar(forTextField textField: UITextField) -> UIToolbar {
        let toolbar = UIToolbar()

        let dismissKeyboardAction = UIAction {
            textField.resignFirstResponder()
        }

        let dismissButton = UIBarButtonItem(title: SantanderL10n.t("Dismiss"), primaryAction: dismissKeyboardAction)
        toolbar.setItems([.flexibleSpace(), dismissButton], animated: true)
        toolbar.sizeToFit()
        return toolbar
    }

    func spawnExecutable(pathAndArgs: String) {
        var components = pathAndArgs.components(separatedBy: " ")
        guard let executable = components.first, !executable.isEmpty else {
            self.errorAlert("Enter a valid executable and arguments.", title: SantanderL10n.t("Input is empty"))
            return
        }

        components.removeFirst()
        self.task = NSTask()
        task.executableURL = URL(fileURLWithPath: executable)
        task.arguments = components

        let pipe = Pipe()
        pipe.fileHandleForReading.readabilityHandler = { outPipe in
            guard let output = String(data: outPipe.availableData, encoding: .utf8),
            !output.isEmpty else {
                return
            }

            DispatchQueue.main.async {
                self.textView.text.append(output)
            }
        }

        task.standardError = pipe
        task.standardOutput = pipe
        do {
            textView.text = ""
            try task.launchAndReturnError()
            task.waitUntilExit()
        } catch {
            self.errorAlert(error, title: SantanderL10n.t("Unable to launch process"))
        }
    }
}

class FontViewerController: UIViewController {
    var selectedFont: UIFont
    var descriptors: [CTFontDescriptor]

    var textView: UITextView!
    var amountLabel: UILabel!

    init(selectedFont: UIFont, descriptors: [CTFontDescriptor]) {
        self.selectedFont = selectedFont
        self.descriptors = descriptors
        super.init(nibName: nil, bundle: nil)

        self.title = selectedFont.familyName
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        navigationController?.navigationBar.prefersLargeTitles = false

        view.backgroundColor = .systemBackground

        setupRightBarButton()

        self.textView = UITextView()
        textView.text = SantanderL10n.t("The quick brown fox jumps over the lazy dog and runs away.")
        textView.font = self.selectedFont
        textView.inputAccessoryView = makeKeyboardToolbar(textView: textView)
        textView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(textView)

        textView.constraintCompletely(to: view)

        configureNavigationBarToNormal()
        setupBottomView()
    }

    func setupRightBarButton() {
        let presentInfoAction = UIAction {
            if self.descriptors.count > 1 {
                let alert = UIAlertController(title: nil, message: nil, preferredStyle: .actionSheet)
                let actions = self.descriptors.map { descriptor in
                    let uiFont = descriptor.uiFont
                    return UIAlertAction(title: uiFont.fontName, style: .default) { _ in
                        let vc = FontInformationViewController(font: uiFont)
                        self.present(UINavigationController(rootViewController: vc), animated: true)
                    }
                }

                for action in actions {
                    alert.addAction(action)
                }

                alert.addAction(.cancel())
                self.present(alert, animated: true)
            } else {
                let vc = FontInformationViewController(font: self.selectedFont)
                self.present(UINavigationController(rootViewController: vc), animated: true)
            }
        }

        let infoButton = UIBarButtonItem(image: UIImage(systemName: "info.circle"), primaryAction: presentInfoAction)

        if descriptors.count > 1 {
            let selectFontActions = descriptors.map { descr in
                let uiFont = descr.uiFont
                return UIAction(title: uiFont.fontName, state: uiFont == self.selectedFont ? .on : .off) { _ in
                    self.selectedFont = uiFont.withSize(self.selectedFont.pointSize)
                    self.updateFontSize(newSize: self.selectedFont.pointSize)
                    self.setupRightBarButton()
                }
            }

            let selectFontMenu = UIMenu(children: selectFontActions)
            navigationItem.rightBarButtonItems = [
                UIBarButtonItem(title: SantanderL10n.t("Select font.."), menu: selectFontMenu),
                infoButton
            ]
        } else {
            navigationItem.rightBarButtonItem = infoButton
        }
    }

    func updateFontSize(newSize: CGFloat) {
        UserPreferences.fontViewerFontSize = newSize
        self.selectedFont = selectedFont.withSize(newSize)
        self.textView.font = selectedFont
        amountLabel.text = Int(newSize).description
    }

    func setupBottomView() {
        let newView = UIView()
        newView.backgroundColor = .secondarySystemBackground

        self.amountLabel = UILabel()
        amountLabel.text = Int(selectedFont.pointSize).description

        let slider = UISlider()
        slider.maximumValue = 90
        slider.value = Float(selectedFont.pointSize)

        let sliderChangedAction = UIAction {
            self.updateFontSize(newSize: CGFloat(slider.value))
        }

        slider.addAction(sliderChangedAction, for: .valueChanged)

        let stackView = UIStackView(arrangedSubviews: [slider, amountLabel])
        stackView.translatesAutoresizingMaskIntoConstraints = false
        stackView.spacing = 10

        newView.addSubview(stackView)
        newView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(newView)
        NSLayoutConstraint.activate([
            newView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            newView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            newView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -50),
            newView.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor),

            stackView.centerYAnchor.constraint(equalTo: newView.centerYAnchor),
            stackView.leadingAnchor.constraint(equalTo: newView.layoutMarginsGuide.leadingAnchor),
            stackView.trailingAnchor.constraint(equalTo: newView.layoutMarginsGuide.trailingAnchor),
        ])

    }

    func makeKeyboardToolbar(textView: UITextView) -> UIToolbar {
        let toolbar = UIToolbar()
        let action = UIAction {
            textView.resignFirstResponder()
        }

        let doneButton = UIBarButtonItem(systemItem: .done, primaryAction: action)

        toolbar.setItems([.flexibleSpace(), doneButton], animated: true)
        toolbar.sizeToFit()
        return toolbar
    }
}

class FontInformationViewController: UITableViewController {
    let font: UIFont
    let ctFont: CTFont
    let fontName: String

    init(font: UIFont) {
        self.font = font
        self.ctFont = font as CTFont
        self.fontName = CTFontCopyAttribute(ctFont, kCTFontDisplayNameAttribute) as? String ?? font.fontName

        super.init(style: .userPreferred)
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    override func viewDidLoad() {
        super.viewDidLoad()

        let fontLabel = UILabel()
        fontLabel.text = fontName
        fontLabel.font = font.withSize(30)

        navigationItem.titleView = fontLabel
    }

    override func numberOfSections(in tableView: UITableView) -> Int {
        return 2
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        switch section {
        case 0:
            return 6
        case 1:
            return 3
        default:
            fatalError()
        }
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = UITableViewCell(style: .value1, reuseIdentifier: nil)
        var conf = cell.defaultContentConfiguration()
        defer {
            cell.contentConfiguration = conf
        }

        switch (indexPath.section, indexPath.row) {
        case (0, 0):
            conf.text = SantanderL10n.t("Full name")
            conf.secondaryText = fontName
        case (0, 1):
            conf.text = SantanderL10n.t("Family name")
            conf.secondaryText = font.familyName
        case (0, 2):
            conf.text = SantanderL10n.t("PostScript name")
            conf.secondaryText = font.fontDescriptor.postscriptName
        case (0, 3):
            conf.text = SantanderL10n.t("Style")
            conf.secondaryText = CTFontCopyAttribute(ctFont, kCTFontStyleNameAttribute) as? String ?? SantanderL10n.t("N/A")
        case (0, 4):
            conf.text = SantanderL10n.t("Enabled")
            if let isEnabled = CTFontCopyAttribute(ctFont, kCTFontEnabledAttribute) as? Bool {
                cell.accessoryType = isEnabled ? .checkmark : .none
            } else {
                conf.secondaryText = SantanderL10n.t("N/A")
            }
        case (0, 5):
            conf.text = SantanderL10n.t("URL")
            let url = CTFontCopyAttribute(ctFont, kCTFontURLAttribute) as? URL
            conf.secondaryText = url?.path ?? SantanderL10n.t("N/A")
        case (1, 0):
            conf.text = SantanderL10n.t("Designer")
            conf.secondaryText = CTFontCopyName(ctFont, kCTFontDesignerNameKey) as? String ?? SantanderL10n.t("N/A")
        case (1, 1):
            conf.text = SantanderL10n.t("Manufacturer")
            conf.secondaryText = CTFontCopyName(ctFont, kCTFontManufacturerNameKey) as? String ?? SantanderL10n.t("N/A")
        case (1, 2):
            conf.text = SantanderL10n.t("Version")
            conf.secondaryText = CTFontCopyName(ctFont, kCTFontVersionNameKey) as? String ?? SantanderL10n.t("N/A")
        default:
            fatalError("Unhandled indexPath: \(indexPath)")
        }

        return cell
    }

    override func tableView(_ tableView: UITableView, shouldHighlightRowAt indexPath: IndexPath) -> Bool {
        return false
    }
}

class ImageMetadataViewController: UITableViewController {
    var metadata: ImageMetadata
    let fileURL: URL

    init(metadata: ImageMetadata, fileURL: URL) {
        self.metadata = metadata
        self.fileURL = fileURL

        super.init(style: .userPreferred)
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    override func numberOfSections(in tableView: UITableView) -> Int {
        return 4
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        switch section {
        case 0, 1: return 3
        case 2, 3: return 2
        default: fatalError()
        }
    }

    override func viewDidLoad() {
        super.viewDidLoad()

        self.title = SantanderL10n.t("Metadata")
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = UITableViewCell(style: .value1, reuseIdentifier: nil)
        var conf = cell.defaultContentConfiguration()

        defer {
            cell.contentConfiguration = conf
        }

        switch (indexPath.section, indexPath.row) {
        case (0, 0):
            conf.text = SantanderL10n.t("Pixel Height")
            conf.secondaryText = metadata.pixelHeight?.description ?? SantanderL10n.t("N/A")
        case (0, 1):
            conf.text = SantanderL10n.t("Pixel Width")
            conf.secondaryText = metadata.pixelWidth?.description ?? SantanderL10n.t("N/A")
        case (0, 2):
            let datePicker = UIDatePicker()
            if let dateTaken = metadata.dateTimeTaken {
                datePicker.setDate(dateTaken, animated: true)
            }

            let action = UIAction {
                self.setNewDate(withDatePicker: datePicker)
            }

            datePicker.addAction(action, for: .editingDidEnd)
            return cellWithView(datePicker, text: SantanderL10n.t("Date Label"), rightAnchorConstant: -5)
        case (1, 0):
            conf.text = SantanderL10n.t("Camera Model")
            conf.secondaryText = metadata.cameraInfo?.model ?? SantanderL10n.t("N/A")
        case (1, 1):
            conf.text = SantanderL10n.t("Camera Manufacturer")
            conf.secondaryText = metadata.cameraInfo?.manufacturer ?? SantanderL10n.t("N/A")
        case (1, 2):
            conf.text = SantanderL10n.t("Camera Software")
            conf.secondaryText = metadata.cameraInfo?.softwareVersion ?? SantanderL10n.t("N/A")
        case (2, 0):
            conf.text = SantanderL10n.t("Lens Model")
            conf.secondaryText = metadata.exifInfo?.lensModel ?? SantanderL10n.t("N/A")
        case (2, 1):
            conf.text = SantanderL10n.t("Lens Manufacturer")
            conf.secondaryText = metadata.exifInfo?.lensManufacturer ?? SantanderL10n.t("N/A")
        case (3, 0):
            conf.text = SantanderL10n.t("Latitude")
            conf.secondaryText = metadata.location.lat?.description ?? SantanderL10n.t("N/A")
        case (3, 1):
            conf.text = SantanderL10n.t("Longitude")
            conf.secondaryText = metadata.location.long?.description ?? SantanderL10n.t("N/A")
        default:
            break
        }

        return cell
    }

    override func tableView(_ tableView: UITableView, shouldHighlightRowAt indexPath: IndexPath) -> Bool {
        return false
    }

    func headerTitle(forSection section: Int) -> String {
        switch section {
        case 0:
            return SantanderL10n.t("General")
        case 1:
            return SantanderL10n.t("Camera")
        case 2:
            return SantanderL10n.t("Lens")
        case 3:
            return SantanderL10n.t("Location")
        default:
            fatalError()
        }
    }

    func setNewDate(withDatePicker datePicker: UIDatePicker) {
        let exifFormattedDate = DateFormatter.EXIFDateFormatter.string(from: datePicker.date)
        let iptcFormattedDate = DateFormatter.IPTCDateFormatter.string(from: datePicker.date)
        var copy = metadata.dictionary

        var tiffDictionary = (copy[kCGImagePropertyTIFFDictionary as String] as? [String: Any]) ?? [:]
        tiffDictionary[kCGImagePropertyTIFFDateTime as String] = exifFormattedDate

        var exifDictionary = (copy[kCGImagePropertyExifDictionary as String] as? [String: Any]) ?? [:]
        exifDictionary[kCGImagePropertyExifDateTimeOriginal as String] = exifFormattedDate
        exifDictionary[kCGImagePropertyExifDateTimeDigitized as String] = exifFormattedDate

        var iptcDictionary = (copy[kCGImagePropertyIPTCDictionary as String] as? [String: Any]) ?? [:]
        iptcDictionary[kCGImagePropertyIPTCDateCreated as String] = iptcFormattedDate

        copy[kCGImagePropertyTIFFDictionary as String] = tiffDictionary
        copy[kCGImagePropertyExifDictionary as String] = exifDictionary
        copy[kCGImagePropertyIPTCDictionary as String] = iptcDictionary

        if !metadata.setProperties(toDictionary: copy, forFileURL: fileURL) {
            errorAlert("", title: SantanderL10n.t("Unable to set date of image"))
        }
    }

    override func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        return sectionHeaderWithButton(sectionTag: section, titleText: headerTitle(forSection: section)) { button in
            guard section == 3 else {
                button.isHidden = true
                return
            }

            let action = UIAction { _ in
                self.presentMapEditor()
            }

            button.setTitle(SantanderL10n.t("View"), for: .normal)
            button.setTitleColor(.systemBlue, for: .normal)
            button.addAction(action, for: .touchUpInside)
        }
    }

    override func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 40
    }

    func presentMapEditor() {
        let vc = ImageLocationEditorViewController(metadata: metadata, metadataSenderVC: self, fileURL: fileURL)
        let navVC = UINavigationController(rootViewController: vc)
        navVC.modalPresentationStyle = .fullScreen
        self.present(navVC, animated: true)
    }
}

class ImageLocationEditorViewController: UIViewController, MKMapViewDelegate {
    let fileURL: URL
    let metadata: ImageMetadata
    let metadataSenderVC: ImageMetadataViewController

    var mapView: MKMapView!
    var annotation: MKPointAnnotation!

    init(metadata: ImageMetadata, metadataSenderVC: ImageMetadataViewController, fileURL: URL) {
        self.metadata = metadata
        self.fileURL = fileURL
        self.metadataSenderVC = metadataSenderVC

        super.init(nibName: nil, bundle: nil)
    }

    required init?(coder: NSCoder) {
        fatalError()
    }

    override func viewDidLoad() {
        super.viewDidLoad()

        title = SantanderL10n.t("Location")

        let dismissAction = UIAction {
            self.dismiss(animated: true)
        }

        navigationItem.leftBarButtonItem = UIBarButtonItem(title: SantanderL10n.t("Dismiss"), primaryAction: dismissAction)

        mapView = MKMapView()
        mapView.translatesAutoresizingMaskIntoConstraints = false
        mapView.delegate = self

        annotation = MKPointAnnotation()

        mapView.addAnnotation(annotation)

        view.addSubview(mapView)

        mapView.constraintCompletely(to: view)

        if let center = metadata.location.coordinate {
            annotation.coordinate = center
            mapView.setRegion(MKCoordinateRegion(center: center, span: .init()), animated: true)
        }

        configureNavigationBarToNormal()
        setRightBarButton()
        setupToolbar()
    }

    func setRightBarButton() {
        let action = UIAction {
            self.setEditing(!self.isEditing, animated: true)
        }

        navigationItem.rightBarButtonItem = UIBarButtonItem(
            systemItem: isEditing ? .done : .edit,
            primaryAction: action
        )
    }

    override func setEditing(_ editing: Bool, animated: Bool) {
        super.setEditing(editing, animated: animated)

        setRightBarButton()

        if !editing {
            setImageLocation(nullify: false)
        } else {
            mapView.addAnnotation(annotation)
        }
    }

    func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
        guard let anno = self.annotation else {
            return nil
        }

        let view = MKPinAnnotationView(annotation: anno, reuseIdentifier: "DraggablePin")
        view.isDraggable = true
        return view
    }

    func moveAnnotation(_ mapView: MKMapView) {
        if isEditing {
            annotation.coordinate = mapView.centerCoordinate
        }
    }

    func setImageLocation(nullify: Bool) {
        let coordinate = annotation.coordinate
        var newGPSDict = (metadata.dictionary[kCGImagePropertyGPSDictionary as String] as? [String: Any?]) ?? [:]
        if nullify {
            newGPSDict[kCGImagePropertyGPSLatitude as String] = nil
            newGPSDict[kCGImagePropertyGPSLongitude as String] = nil
            metadata.location = ImageLocation(lat: nil, long: nil)
        } else {
            newGPSDict[kCGImagePropertyGPSLatitude as String] = coordinate.latitude
            newGPSDict[kCGImagePropertyGPSLongitude as String] = coordinate.longitude
            metadata.location = ImageLocation(lat: coordinate.latitude, long: coordinate.longitude)
        }

        var copy = metadata.dictionary
        copy[kCGImagePropertyGPSDictionary as String] = newGPSDict

        let didSucceed = metadata.setProperties(toDictionary: copy, forFileURL: fileURL)
        if !didSucceed {
            errorAlert("", title: SantanderL10n.t("Unable to set location of image"))
        } else {
            metadataSenderVC.metadata = .init(dictionary: copy)
            metadataSenderVC.tableView.reloadData()
            if nullify {
                mapView.removeAnnotation(annotation)
            }
        }
        self.setupToolbar()
    }

    func mapView(_ mapView: MKMapView, regionDidChangeAnimated animated: Bool) {
        moveAnnotation(mapView)
    }

    func setupToolbar() {
        let action = UIAction {
            let alert = UIAlertController(title: SantanderL10n.t("Remove image location?"), message: nil, preferredStyle: .actionSheet)
            let removeAction = UIAlertAction(title: SantanderL10n.t("Remove"), style: .destructive) { _ in
                self.setImageLocation(nullify: true)
            }

            alert.addAction(removeAction)
            alert.addAction(.cancel())
            self.present(alert, animated: true)
        }

        let trashButton = UIBarButtonItem(image: UIImage(systemName: "trash"), primaryAction: action)
        trashButton.isEnabled = metadata.location.coordinate != nil
        trashButton.tintColor = .systemRed

        navigationController?.setToolbarHidden(false, animated: true)
        self.toolbarItems = [trashButton]
    }
}

class ImageViewerController: UIViewController {
    let fileURL: URL?
    let image: UIImage
    var metadata: ImageMetadata?

    typealias SetWallpaperFunction = @convention(c) (_: NSDictionary, _: NSDictionary, _: Int, _: Int) -> Int

    init(fileURL: URL?, image: UIImage, title: String? = nil) {
        self.fileURL = fileURL
        self.image = image

        super.init(nibName: nil, bundle: nil)
        self.title = fileURL?.lastPathComponent ?? title
    }

    convenience init?(fileURL: URL) {
        guard let image = UIImage(contentsOfFile: fileURL.path) else {
            return nil
        }

        self.init(fileURL: fileURL, image: image)
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        if let fileURL = fileURL {
            self.metadata = ImageMetadata(fileURL: fileURL)
        }

        view.backgroundColor = .systemBackground

        let doneAction = UIAction { _ in
            self.dismiss(animated: true)
        }

        let doneButton = UIBarButtonItem(systemItem: .done, primaryAction: doneAction)
        let infoButton = UIBarButtonItem()

        if let metadata = self.metadata, let fileURL = fileURL {
            let infoAction = UIAction { _ in
                let vc = ImageMetadataViewController(metadata: metadata, fileURL: fileURL)
                self.present(UINavigationController(rootViewController: vc), animated: true)
            }

            infoButton.primaryAction = infoAction
        } else {
            infoButton.isEnabled = false
        }

        infoButton.image = UIImage(systemName: "info.circle")

        navigationItem.rightBarButtonItem = doneButton
        navigationItem.leftBarButtonItem = infoButton

        if let pdfPage = PDFPage(image: image) {
            let pdfView = PDFView(frame: self.view.bounds)
            pdfView.displayDirection = .vertical
            pdfView.displayMode = .singlePage
            pdfView.backgroundColor = .systemBackground

            let pdfDoc = PDFDocument()
            pdfDoc.insert(pdfPage, at: 0)

            pdfView.document = pdfDoc
            pdfView.autoScales = true
            pdfView.minScaleFactor = pdfView.scaleFactorForSizeToFit

            self.view = pdfView
        } else {
            setupFailedLabel()
        }

        configureNavigationBarToNormal()
        setupToolbar()
    }

    func setupFailedLabel() {
        let failedLabel = UILabel()
        failedLabel.text = SantanderL10n.t("Failed to display image.")
        failedLabel.textColor = .systemGray
        failedLabel.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(failedLabel)

        NSLayoutConstraint.activate([
            failedLabel.centerXAnchor.constraint(equalTo: self.view.centerXAnchor),
            failedLabel.centerYAnchor.constraint(equalTo: self.view.centerYAnchor)
        ])
    }

    func setupToolbar() {
        let shareMenuAction = UIAction {
            if let fileURL = self.fileURL {
                self.presentActivityVC(forItems: [fileURL])
            } else {
                self.presentActivityVC(forItems: [self.image])
            }
        }

        let shareMenuButton = UIBarButtonItem(image: UIImage(systemName: "square.and.arrow.up"), primaryAction: shareMenuAction)
        let saveImageAction = UIAction(title: SantanderL10n.t("Save Image")) { _ in
            self.saveImage(self.image)
        }

        let setWallpaperActions = WallpaperDestination.allCases.map { location in
            return UIAction(title: location.description) { _ in
                self.setImageAsWallpaper(to: location)
            }
        }

        let setAsWallpaperMenu = UIMenu(title: SantanderL10n.t("Set as wallpaper for.."), children: setWallpaperActions)

        let actionsMenu = UIMenu(children: [saveImageAction, setAsWallpaperMenu])
        self.toolbarItems = [shareMenuButton, .flexibleSpace(), UIBarButtonItem(image: UIImage(systemName: "ellipsis.circle"), menu: actionsMenu)]
        self.navigationController?.setToolbarHidden(false, animated: true)
    }

    func setImageAsWallpaper(to location: WallpaperDestination) {
        let sbF = dlopen("/System/Library/PrivateFrameworks/SpringBoardFoundation.framework/SpringBoardFoundation", RTLD_LAZY)
        let sbServer = dlopen("/System/Library/PrivateFrameworks/SpringBoardUIServices.framework/SpringBoardUIServices", RTLD_LAZY)

        defer {
            dlclose(sbF)
            dlclose(sbServer)
        }

        guard let options = NSClassFromString("SBFWallpaperOptions")?.alloc(),
              let pointer = dlsym(sbServer, "SBSUIWallpaperSetImages"),
              let setWallpaper = unsafeBitCast(pointer, to: (SetWallpaperFunction)?.self)
        else {
            errorAlert(nil, title: SantanderL10n.t("无法设置壁纸"))
            return
        }

        let imagesDict = [
            "light": image,
            "dark": image
        ]

        let optionsDict = [
            "light" : options,
            "dark": options
        ]

        let result = setWallpaper(NSDictionary(dictionary: imagesDict), NSDictionary(dictionary: optionsDict), location.rawValue, traitCollection.userInterfaceStyle.rawValue)
        if result != 1 {
            errorAlert("SBSUIWallpaperSetImages returned status code \(result) (should be 1)", title: SantanderL10n.t("无法设置壁纸"))
        }
    }

    enum WallpaperDestination: Int, CustomStringConvertible, CaseIterable {
        static let allCases: [WallpaperDestination] = [.homeScreen, .lockScreen, .both]

        case lockScreen = 1
        case homeScreen = 2
        case both = 3

        var description: String {
            switch self {
            case .lockScreen:
                return SantanderL10n.t("Lock Screen")
            case .homeScreen:
                return SantanderL10n.t("Home Screen")
            case .both:
                return SantanderL10n.t("Home Screen & Lock Screen")
            }
        }
    }
}

private final class SerializedArrayItemDelegate: NSObject, SerializedItemViewControllerDelegate {
    weak var controller: SerializedArrayViewController?
    let index: Int

    init(controller: SerializedArrayViewController, index: Int) {
        self.controller = controller
        self.index = index
    }

    func didChangeName(ofItem item: String, to newName: String) -> Bool {
        false
    }

    func didChangeValue(ofItem item: String, to newValue: SerializedItemType) -> Bool {
        guard let controller else { return false }
        var values = controller.array
        values[index] = newValue.representedObject
        return controller.writeToFile(newArray: values)
    }
}


private struct PlistTreePath: Hashable {
    enum Component: Hashable {
        case key(String)
        case index(Int)
    }
    var components: [Component] = []

    func appending(_ component: Component) -> PlistTreePath {
        var result = self
        result.components.append(component)
        return result
    }

    var parent: PlistTreePath? {
        guard !components.isEmpty else { return nil }
        var result = components
        result.removeLast()
        return PlistTreePath(components: result)
    }

    var lastComponent: Component? { components.last }
}

private struct PlistTreeNode {
    let path: PlistTreePath
    let depth: Int
    let label: String
    let value: Any
    let item: SerializedItemType
    let isContainer: Bool
}

private final class PlistTreeItemDelegate: NSObject, SerializedItemViewControllerDelegate {
    weak var controller: PlistTreeEditorViewController?
    var path: PlistTreePath

    init(controller: PlistTreeEditorViewController, path: PlistTreePath) {
        self.controller = controller
        self.path = path
    }

    func didChangeName(ofItem item: String, to newName: String) -> Bool {
        guard let controller else { return false }
        guard controller.renameDictionaryKey(at: path, to: newName) else { return false }
        if case .key = path.lastComponent {
            path.components[path.components.count - 1] = .key(newName)
        }
        return true
    }

    func didChangeValue(ofItem item: String, to newValue: SerializedItemType) -> Bool {
        controller?.replaceNode(at: path, with: newValue.representedObject) ?? false
    }
}

final class PlistTreeEditorViewController: UITableViewController {
    private var rootValue: Any
    private let format: PropertyListSerialization.PropertyListFormat?
    private let fileURL: URL?
    private let canEdit: Bool
    private var expandedPaths = Set<PlistTreePath>()
    private var activeContainerPath: PlistTreePath?
    private var rows: [PlistTreeNode] = []
    private var retainedDelegates: [PlistTreeItemDelegate] = []
    private var hasUnsavedChanges = false

    init(
        rootValue: Any,
        format: PropertyListSerialization.PropertyListFormat?,
        fileURL: URL?,
        title: String,
        canEdit: Bool
    ) {
        self.rootValue = rootValue
        self.format = format
        self.fileURL = fileURL
        self.canEdit = canEdit
        super.init(style: .insetGrouped)
        self.title = title
        self.expandedPaths = allContainerPaths(in: rootValue, at: PlistTreePath())
        self.activeContainerPath = isContainerValue(rootValue) ? PlistTreePath() : nil
    }

    required init?(coder: NSCoder) { fatalError("init(coder:) has not been implemented") }

    override func viewDidLoad() {
        super.viewDidLoad()
        applySantanderGlass()
        navigationItem.largeTitleDisplayMode = .never
        if canEdit {
            let add = UIBarButtonItem(systemItem: .add, primaryAction: UIAction { [weak self] _ in self?.addNewTeamValue() })
            let save = UIBarButtonItem(title: SantanderL10n.t("Save"), style: .done, target: self, action: #selector(saveChanges))
            navigationItem.rightBarButtonItems = [save, add]
            updateSaveButton()
        } else {
            navigationItem.rightBarButtonItems = nil
        }
        tableView.rowHeight = UITableView.automaticDimension
        tableView.estimatedRowHeight = 52
        reloadTree()
    }

    override func numberOfSections(in tableView: UITableView) -> Int { 1 }
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int { rows.count }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let node = rows[indexPath.row]
        let cell = UITableViewCell(style: .default, reuseIdentifier: nil)
        cell.backgroundColor = .clear
        cell.contentView.backgroundColor = .clear
        cell.selectionStyle = canEdit || node.isContainer ? .default : .none

        let rowStack = UIStackView()
        rowStack.axis = .horizontal
        rowStack.alignment = .center
        rowStack.spacing = 8
        rowStack.translatesAutoresizingMaskIntoConstraints = false
        cell.contentView.addSubview(rowStack)

        let leadingSpacer = UIView()
        leadingSpacer.translatesAutoresizingMaskIntoConstraints = false
        leadingSpacer.widthAnchor.constraint(equalToConstant: CGFloat(node.depth) * 20).isActive = true
        rowStack.addArrangedSubview(leadingSpacer)

        if node.isContainer {
            let disclosure = UIButton(type: .system)
            disclosure.translatesAutoresizingMaskIntoConstraints = false
            disclosure.widthAnchor.constraint(equalToConstant: 24).isActive = true
            disclosure.heightAnchor.constraint(equalToConstant: 36).isActive = true
            let expanded = expandedPaths.contains(node.path)
            disclosure.setImage(UIImage(systemName: expanded ? "chevron.down" : "chevron.right"), for: .normal)
            disclosure.accessibilityLabel = expanded ? SantanderL10n.t("Collapse") : SantanderL10n.t("Expand")
            disclosure.addAction(UIAction { [weak self] _ in
                guard let self, let row = self.rows.firstIndex(where: { $0.path == node.path }) else { return }
                self.toggleExpansion(at: row)
            }, for: .touchUpInside)
            rowStack.addArrangedSubview(disclosure)
        } else {
            let spacer = UIView()
            spacer.widthAnchor.constraint(equalToConstant: 24).isActive = true
            rowStack.addArrangedSubview(spacer)
        }

        let textStack = UIStackView()
        textStack.axis = .vertical
        textStack.alignment = .fill
        textStack.spacing = 2

        let titleLabel = UILabel()
        titleLabel.text = node.label
        titleLabel.font = .preferredFont(forTextStyle: .body)
        titleLabel.numberOfLines = 1
        textStack.addArrangedSubview(titleLabel)

        let subtitleLabel = UILabel()
        subtitleLabel.font = .preferredFont(forTextStyle: .caption1)
        subtitleLabel.textColor = .secondaryLabel
        subtitleLabel.numberOfLines = 1

        switch node.item {
        case .bool:
            subtitleLabel.text = "Boolean"
        case .array(let array):
            subtitleLabel.text = "Array • \(array.count) 项"
        case .dictionary(let dictionary):
            subtitleLabel.text = "Dictionary • \(dictionary.count) 项"
        default:
            let valueDescription = node.item.description
            subtitleLabel.text = valueDescription.isEmpty ? node.item.typeDescription : "\(node.item.typeDescription) • \(valueDescription)"
        }
        textStack.addArrangedSubview(subtitleLabel)
        rowStack.addArrangedSubview(textStack)

        if case .bool(let bool) = node.item {
            let toggle = UISwitch()
            toggle.isOn = bool
            toggle.isEnabled = canEdit
            toggle.addAction(UIAction { [weak self, weak toggle] _ in
                guard let self, let toggle else { return }
                let requested = toggle.isOn
                if !self.replaceNode(at: node.path, with: requested) {
                    toggle.setOn(!requested, animated: true)
                }
            }, for: .valueChanged)
            rowStack.addArrangedSubview(toggle)
        }

        if canEdit || !node.isContainer {
            let info = UIButton(type: .system)
            info.translatesAutoresizingMaskIntoConstraints = false
            info.widthAnchor.constraint(equalToConstant: 32).isActive = true
            info.heightAnchor.constraint(equalToConstant: 36).isActive = true
            info.setImage(UIImage(systemName: "info.circle"), for: .normal)
            info.accessibilityLabel = SantanderL10n.t("详细信息")
            info.addAction(UIAction { [weak self] _ in
                guard let self, let row = self.rows.firstIndex(where: { $0.path == node.path }) else { return }
                self.openDetails(for: row)
            }, for: .touchUpInside)
            rowStack.addArrangedSubview(info)
        }

        NSLayoutConstraint.activate([
            rowStack.leadingAnchor.constraint(equalTo: cell.contentView.layoutMarginsGuide.leadingAnchor),
            rowStack.trailingAnchor.constraint(equalTo: cell.contentView.layoutMarginsGuide.trailingAnchor),
            rowStack.topAnchor.constraint(equalTo: cell.contentView.topAnchor, constant: 5),
            rowStack.bottomAnchor.constraint(equalTo: cell.contentView.bottomAnchor, constant: -5)
        ])
        return cell
    }

    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        guard rows.indices.contains(indexPath.row) else { return }
        let node = rows[indexPath.row]
        if node.isContainer {
            activeContainerPath = node.path
            toggleExpansion(at: indexPath.row)
        } else {
            openDetails(for: indexPath.row)
        }
    }

    override func tableView(_ tableView: UITableView, trailingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration? {
        guard canEdit, rows.indices.contains(indexPath.row) else { return nil }
        let node = rows[indexPath.row]
        let delete = UIContextualAction(style: .destructive, title: nil) { [weak self] _, _, completion in
            guard let self else { completion(false); return }
            if self.deleteNode(at: node.path) {
                completion(true)
            } else {
                completion(false)
            }
        }
        delete.image = UIImage(systemName: "trash")
        return UISwipeActionsConfiguration(actions: [delete])
    }

    private func toggleExpansion(at row: Int) {
        guard rows.indices.contains(row) else { return }
        let path = rows[row].path
        if expandedPaths.contains(path) {
            expandedPaths = expandedPaths.filter { existing in
                !(existing == path || existing.components.starts(with: path.components))
            }
        } else {
            expandedPaths.insert(path)
        }
        reloadTree()
    }

    private func openDetails(for row: Int) {
        guard rows.indices.contains(row) else { return }
        let node = rows[row]
        let vc = SerializedItemViewController(
            item: node.item,
            itemKey: node.label,
            allowsKeyEditing: { if case .key = node.path.lastComponent { return true }; return false }(),
            documentType: .plist(format: format),
            canEdit: canEdit
        )
        let delegate = PlistTreeItemDelegate(controller: self, path: node.path)
        vc.delegate = delegate
        vc.retainedDelegate = delegate
        retainedDelegates.append(delegate)
        navigationController?.pushViewController(vc, animated: false)
    }

    private func addNewTeamValue() {
        let targetPath = activeContainerPath
        let target = targetPath.flatMap(value(at:)) ?? rootValue
        switch target {
        case var dictionary as [String: Any]:
            var key = "NewTeam"
            var suffix = 2
            while dictionary[key] != nil {
                key = "NewTeam \(suffix)"
                suffix += 1
            }
            dictionary[key] = false
            if let targetPath {
                _ = replaceNode(at: targetPath, with: dictionary)
                expandedPaths.insert(targetPath)
                activeContainerPath = targetPath
            } else if writeAndApplyRoot(dictionary) {
                rootValue = dictionary
            }
        case var array as [Any]:
            array.append(false)
            if let targetPath {
                _ = replaceNode(at: targetPath, with: array)
            } else {
                _ = writeAndApplyRoot(array)
            }
        default:
            // Filza's new-value action is meaningful on a dictionary/array; when
            // the current selection is a scalar, fall back to the root container.
            if let rootDict = rootValue as? [String: Any] {
                var mutable = rootDict
                var key = "NewTeam"
                var suffix = 2
                while mutable[key] != nil { key = "NewTeam \(suffix)"; suffix += 1 }
                mutable[key] = false
                _ = writeAndApplyRoot(mutable)
            } else if var rootArray = rootValue as? [Any] {
                rootArray.append(false)
                _ = writeAndApplyRoot(rootArray)
            }
        }
        reloadTree()
    }

    @discardableResult
    fileprivate func replaceNode(at path: PlistTreePath, with newValue: Any) -> Bool {
        guard path.components.isEmpty || value(at: path) != nil else { return false }
        let newRoot = replacing(rootValue, at: path.components, with: newValue)
        guard writeAndApplyRoot(newRoot) else { return false }
        rootValue = newRoot
        expandedPaths = expandedPaths.filter { p in
            guard let value = self.value(at: p) else { return false }
            return isContainerValue(value)
        }
        if isContainerValue(newValue) { expandedPaths.insert(path) }
        return true
    }

    fileprivate func renameDictionaryKey(at path: PlistTreePath, to newName: String) -> Bool {
        guard !newName.isEmpty, let last = path.lastComponent else { return false }
        guard case .key(let oldName) = last, oldName != newName else { return oldName == newName }
        let parentPath = path.parent ?? PlistTreePath()
        guard var dictionary = value(at: parentPath) as? [String: Any], dictionary[oldName] != nil else { return false }
        guard dictionary[newName] == nil else {
            errorAlert(SantanderL10n.t("The key already exists."), title: SantanderL10n.t("Duplicate Key"))
            return false
        }
        let value = dictionary.removeValue(forKey: oldName)!
        dictionary[newName] = value
        let newRoot = replacing(rootValue, at: parentPath.components, with: dictionary)
        guard writeAndApplyRoot(newRoot) else { return false }
        rootValue = newRoot
        let newPath = PlistTreePath(components: parentPath.components + [.key(newName)])
        if expandedPaths.contains(path) { expandedPaths.insert(newPath); expandedPaths.remove(path) }
        if activeContainerPath == path { activeContainerPath = newPath }
        return true
    }

    @discardableResult
    private func deleteNode(at path: PlistTreePath) -> Bool {
        guard !path.components.isEmpty else { return false }
        let newRoot = removing(rootValue, at: path.components)
        guard writeAndApplyRoot(newRoot) else { return false }
        rootValue = newRoot
        expandedPaths = expandedPaths.filter { !($0 == path || $0.components.starts(with: path.components)) }
        if activeContainerPath == path { activeContainerPath = path.parent }
        reloadTree()
        return true
    }

    private func writeAndApplyRoot(_ newRoot: Any) -> Bool {
        guard canEdit else { return false }
        // Filza-style plist editing keeps changes in the editor until Save.
        // Serialize now to validate that the whole tree is still a valid plist.
        if let format {
            do { _ = try PropertyListSerialization.data(fromPropertyList: newRoot, format: format, options: 0) }
            catch {
                errorAlert(error, title: SantanderL10n.t("Unable to write to file"))
                return false
            }
        }
        hasUnsavedChanges = true
        updateSaveButton()
        return true
    }

    @objc private func saveChanges() {
        guard canEdit, hasUnsavedChanges, let fileURL, let format else { return }
        do {
            let data = try PropertyListSerialization.data(fromPropertyList: rootValue, format: format, options: 0)
            try FSOperation.perform(.writeData(url: fileURL, data: data), rootHelperConf: RootConf.shared)
            hasUnsavedChanges = false
            updateSaveButton()
        } catch {
            errorAlert(error, title: SantanderL10n.t("Unable to write to file"))
        }
    }

    private func updateSaveButton() {
        guard let buttons = navigationItem.rightBarButtonItems else { return }
        for button in buttons where button.action == #selector(saveChanges) {
            button.isEnabled = hasUnsavedChanges
        }
    }

    private func reloadTree() {
        rows.removeAll(keepingCapacity: true)
        let rootItem = SerializedItemType(item: rootValue)
        let rootContainer = isContainerValue(rootValue)
        rows.append(PlistTreeNode(
            path: PlistTreePath(),
            depth: 0,
            label: SantanderL10n.t("Root"),
            value: rootValue,
            item: rootItem,
            isContainer: rootContainer
        ))
        if rootContainer && expandedPaths.contains(PlistTreePath()) {
            buildChildRows(from: rootValue, at: PlistTreePath(), depth: 1, into: &rows)
        }
        tableView.reloadData()
        updateSaveButton()
    }

    private func buildChildRows(from value: Any, at path: PlistTreePath, depth: Int, into rows: inout [PlistTreeNode]) {
        if let dictionary = value as? [String: Any] {
            for key in dictionary.keys.sorted(by: { $0.localizedStandardCompare($1) == .orderedAscending }) {
                let childPath = path.appending(.key(key))
                let child = dictionary[key]!
                let item = SerializedItemType(item: child)
                let container = isContainerValue(child)
                rows.append(PlistTreeNode(path: childPath, depth: depth, label: key, value: child, item: item, isContainer: container))
                if container, expandedPaths.contains(childPath) {
                    buildChildRows(from: child, at: childPath, depth: depth + 1, into: &rows)
                }
            }
        } else if let array = value as? [Any] {
            for index in array.indices {
                let child = array[index]
                let childPath = path.appending(.index(index))
                let item = SerializedItemType(item: child)
                let container = isContainerValue(child)
                rows.append(PlistTreeNode(path: childPath, depth: depth, label: "Item \(index)", value: child, item: item, isContainer: container))
                if container, expandedPaths.contains(childPath) {
                    buildChildRows(from: child, at: childPath, depth: depth + 1, into: &rows)
                }
            }
        }
    }

    private func allContainerPaths(in value: Any, at path: PlistTreePath) -> Set<PlistTreePath> {
        var result = Set<PlistTreePath>()
        if let dictionary = value as? [String: Any] {
            result.insert(path)
            for (key, child) in dictionary {
                if isContainerValue(child) {
                    result.formUnion(allContainerPaths(in: child, at: path.appending(.key(key))))
                }
            }
        } else if let array = value as? [Any] {
            result.insert(path)
            for (index, child) in array.enumerated() where isContainerValue(child) {
                result.formUnion(allContainerPaths(in: child, at: path.appending(.index(index))))
            }
        }
        return result
    }

    private func value(at path: PlistTreePath?) -> Any? {
        guard let path else { return nil }
        return value(at: path.components)
    }

    private func value(at components: [PlistTreePath.Component]) -> Any? {
        var current = rootValue
        for component in components {
            switch component {
            case .key(let key):
                guard let dictionary = current as? [String: Any], let next = dictionary[key] else { return nil }
                current = next
            case .index(let index):
                guard let array = current as? [Any], array.indices.contains(index) else { return nil }
                current = array[index]
            }
        }
        return current
    }

    private func isContainerValue(_ value: Any) -> Bool {
        value is [String: Any] || value is [Any]
    }

    private func replacing(_ value: Any, at components: [PlistTreePath.Component], with newValue: Any) -> Any {
        guard let component = components.first else { return newValue }
        let rest = Array(components.dropFirst())
        switch component {
        case .key(let key):
            guard var dictionary = value as? [String: Any], let child = dictionary[key] else { return value }
            dictionary[key] = replacing(child, at: rest, with: newValue)
            return dictionary
        case .index(let index):
            guard var array = value as? [Any], array.indices.contains(index) else { return value }
            array[index] = replacing(array[index], at: rest, with: newValue)
            return array
        }
    }

    private func removing(_ value: Any, at components: [PlistTreePath.Component]) -> Any {
        guard let component = components.first else { return value }
        let rest = Array(components.dropFirst())
        switch component {
        case .key(let key):
            guard var dictionary = value as? [String: Any] else { return value }
            if rest.isEmpty {
                dictionary.removeValue(forKey: key)
            } else if let child = dictionary[key] {
                dictionary[key] = removing(child, at: rest)
            }
            return dictionary
        case .index(let index):
            guard var array = value as? [Any], array.indices.contains(index) else { return value }
            if rest.isEmpty {
                array.remove(at: index)
            } else {
                array[index] = removing(array[index], at: rest)
            }
            return array
        }
    }
}

class SerializedArrayViewController: UITableViewController {
    var array: Array<Any>
    let type: SerializedDocumentViewerType
    let fileURL: URL?
    let canEdit: Bool
    var parentController: SerializedControllerParent?

    init(
        array: Array<Any>,
        type: SerializedDocumentViewerType,
        parentController: SerializedControllerParent?,
        title: String?,
        fileURL: URL?,
        canEdit: Bool
    ) {
        self.array = array
        self.type = type
        self.fileURL = fileURL
        self.canEdit = canEdit
        self.parentController = parentController

        super.init(style: .userPreferred)
        self.title = title
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        applySantanderGlass()
        guard canEdit else { return }
        navigationItem.rightBarButtonItem = UIBarButtonItem(
            systemItem: .add,
            primaryAction: UIAction { [weak self] _ in
                self?.presentAddArrayItem()
            }
        )
    }

    func presentAddArrayItem() {
        let alert = UIAlertController(title: SantanderL10n.t("Add Value"), message: nil, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "String", style: .default) { [weak self] _ in self?.appendValue("") })
        alert.addAction(UIAlertAction(title: "Boolean", style: .default) { [weak self] _ in self?.appendValue(false) })
        alert.addAction(UIAlertAction(title: "Integer", style: .default) { [weak self] _ in self?.appendValue(0) })
        alert.addAction(UIAlertAction(title: "Real", style: .default) { [weak self] _ in self?.appendValue(0.0) })
        alert.addAction(UIAlertAction(title: "Date", style: .default) { [weak self] _ in self?.appendValue(Date()) })
        if case .plist = type {
            alert.addAction(UIAlertAction(title: "Data", style: .default) { [weak self] _ in self?.appendValue(Data()) })
        }
        alert.addAction(UIAlertAction(title: "Array", style: .default) { [weak self] _ in self?.appendValue([Any]()) })
        alert.addAction(UIAlertAction(title: "Dictionary", style: .default) { [weak self] _ in self?.appendValue([String: Any]()) })
        alert.addAction(.cancel())
        present(alert, animated: true)
    }

    func appendValue(_ value: Any) {
        var newArray = array
        newArray.append(value)
        let index = newArray.count - 1
        guard writeToFile(newArray: newArray) else { return }
        tableView.insertRows(at: [IndexPath(row: index, section: 0)], with: .automatic)
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return array.count
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = UITableViewCell()
        var conf = cell.defaultContentConfiguration()
        let item = array[indexPath.row]

        let serialized = SerializedItemType(item: item)
        conf.text = "Item \(indexPath.row)"
        if let array = item as? [Any] {
            conf.secondaryText = "Array • \(array.count) 项"
            cell.accessoryType = .disclosureIndicator
        } else if let dictionary = item as? [String: Any] {
            conf.secondaryText = "Dictionary • \(dictionary.count) 项"
            cell.accessoryType = .disclosureIndicator
        } else {
            let value = serialized.description.isEmpty ? "" : " • \(serialized.description)"
            conf.secondaryText = "\(serialized.typeDescription)\(value)"
            cell.accessoryType = .detailButton
        }

        cell.contentConfiguration = conf
        return cell
    }

    override func tableView(_ tableView: UITableView, shouldHighlightRowAt indexPath: IndexPath) -> Bool {
        return true
    }

    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if let arr = array[indexPath.row] as? Array<Any> {
            let title = "Item \(indexPath.row)"
            let vc = SerializedArrayViewController(
                array: arr,
                type: type,
                parentController: .array(self, index: indexPath.row),
                title: title,
                fileURL: fileURL,
                canEdit: canEdit
            )

            navigationController?.pushViewController(vc, animated: true)
        } else if let dict = array[indexPath.row] as? [String: Any] {
            let serializedDict = dict.asSerializedDictionary()

            let title = "Item \(indexPath.row)"
            let vc = SerializedDocumentViewController(dictionary: serializedDict, type: type, title: title, fileURL: fileURL, parentController: .array(self, index: indexPath.row), canEdit: true)
            navigationController?.pushViewController(vc, animated: true)
        } else {
            let item = SerializedItemType(item: array[indexPath.row])
            let vc = SerializedItemViewController(item: item, itemKey: "Item \(indexPath.row)", allowsKeyEditing: false, documentType: type, canEdit: canEdit)
            let delegate = SerializedArrayItemDelegate(controller: self, index: indexPath.row)
            vc.delegate = delegate
            vc.retainedDelegate = delegate
            navigationController?.pushViewController(vc, animated: true)
        }
    }

    override func tableView(_ tableView: UITableView, trailingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration? {
        guard canEdit else {
            return nil
        }

        let removeAction = UIContextualAction(style: .destructive, title: nil) { _, _, completion in
            var newArr = self.array
            newArr.remove(at: indexPath.row)

            if self.writeToFile(newArray: newArr) {
                tableView.deleteRows(at: [indexPath], with: .fade)
                completion(true)
            } else {
                completion(false)
            }
        }

        removeAction.image = .remove
        return UISwipeActionsConfiguration(actions: [removeAction])
    }

    func writeToFile(newArray: Array<Any>) -> Bool {

        if let parentController = parentController {
            let didSucceed: Bool

            switch parentController {
            case .dictionary(let parent, let key):
                var parentDict = parent.serializedDict
                parentDict[key] = .array(newArray)
                didSucceed = parent.writeToFile(newDict: parentDict)
            case .array(let parent, let index):
                guard parent.array.indices.contains(index) else {
                    return false
                }
                var parentArr = parent.array
                parentArr[index] = newArray
                didSucceed = parent.writeToFile(newArray: parentArr)
            }

            if didSucceed {
                self.array = newArray
            }

            return didSucceed
        }

        guard let fileURL = fileURL else {
            return false
        }

        do {
            let newSerializedData: Data
            switch type {
            case .json:
                newSerializedData = try JSONSerialization.data(withJSONObject: newArray)
            case .plist(let format):
                guard let format = format else {
                    return false
                }

                newSerializedData = try PropertyListSerialization.data(fromPropertyList: newArray, format: format, options: 0)
            }

            try FSOperation.perform(.writeData(url: fileURL, data: newSerializedData), rootHelperConf: RootConf.shared)
            self.array = newArray
            return true
        } catch {
            self.errorAlert(error, title: SantanderL10n.t("Unable to write to file"))
            return false
        }
    }
}

typealias SerializedDictionaryType = [String: SerializedItemType]

class SerializedDocumentViewController: UITableViewController, SerializedItemViewControllerDelegate {

    var serializedDict: SerializedDictionaryType

    var filteredDict: SerializedDictionaryType = [:]

    var keys: [String] {
        let keysArr = Array(isSearching ? filteredDict.keys : serializedDict.keys)
        return keysArr.sorted { $0.localizedStandardCompare($1) == .orderedAscending }
    }

    var fileURL: URL?
    var canEdit: Bool
    var isSearching: Bool = false
    let type: SerializedDocumentViewerType
    let parentController: SerializedControllerParent?

    init(
        dictionary: SerializedDictionaryType,
        type: SerializedDocumentViewerType,
        title: String,
        fileURL: URL? = nil,
        parentController: SerializedControllerParent?,
        canEdit: Bool
    ) {
        self.serializedDict = dictionary
        self.type = type
        self.fileURL = fileURL
        self.canEdit = canEdit
        self.parentController = parentController

        super.init(style: .userPreferred)
        self.title = title
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        applySantanderGlass()

        let closeButton = UIBarButtonItem(systemItem: .done, primaryAction: UIAction(withClosure: dismissVC))
        let addButton = UIBarButtonItem(
            systemItem: .add,
            primaryAction: UIAction { [weak self] _ in
                self?.presentAddValue()
            }
        )
        navigationItem.rightBarButtonItems = canEdit ? [closeButton, addButton] : [closeButton]
        let searchController = UISearchController()
        searchController.searchBar.delegate = self
        navigationItem.searchController = searchController
        navigationItem.hidesSearchBarWhenScrolling = !UserPreferences.alwaysShowSearchBar
    }

    convenience init?(
        type: SerializedDocumentViewerType,
        fileURL: URL,
        data: Data,
        canEdit: Bool
    ) {

        switch type {
        case .json:
            guard let json = try? JSONSerialization.jsonObject(with: data) as? [String: Any] else {
                return nil
            }

            let newDict = json.asSerializedDictionary()
            self.init(dictionary: newDict, type: .json, title: fileURL.lastPathComponent, fileURL: fileURL, parentController: nil, canEdit: canEdit)
        case .plist(_):
            let fmt: UnsafeMutablePointer<PropertyListSerialization.PropertyListFormat>? = .allocate(capacity: 4)
            defer {
                fmt?.deallocate()
            }

            guard let plist = try? PropertyListSerialization.propertyList(from: data, format: fmt) as? [String: Any] else {
                return nil
            }

            let newDict = plist.asSerializedDictionary()

            self.init(dictionary: newDict, type: .plist(format: fmt?.pointee), title: fileURL.lastPathComponent, fileURL: fileURL, parentController: nil, canEdit: canEdit)
        }
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return keys.count
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = UITableViewCell(style: .value2, reuseIdentifier: nil)
        var conf = cell.defaultContentConfiguration()
        let text = keys[indexPath.row]

        conf.text = text
        let elem = dictElement(forKey: text)

        switch elem {
        case .dictionary(_), .array(_):
            cell.accessoryType = .disclosureIndicator
        default:
            cell.accessoryType = .detailButton
        }

        conf.secondaryText = valueDescription(forElement: elem)
        cell.contentConfiguration = conf
        return cell
    }

    func dismissVC() {
        self.dismiss(animated: true)
    }

    func presentViewController(forIndexPath indexPath: IndexPath) {
        let text = keys[indexPath.row]
        let elem = dictElement(forKey: text)!

        if case .array(let arr) = elem {
            let vc = SerializedArrayViewController(array: arr, type: type, parentController: .dictionary(self, key: text), title: text, fileURL: fileURL, canEdit: canEdit)
            self.navigationController?.pushViewController(vc, animated: true)
        } else if case .dictionary(let dict) = elem {
            let newDict = dict.asSerializedDictionary()

            let vc = SerializedDocumentViewController(dictionary: newDict, type: type, title: text, fileURL: fileURL, parentController: .dictionary(self, key: text), canEdit: true)
            self.navigationController?.pushViewController(vc, animated: true)
        } else {
            let vc = SerializedItemViewController(item: elem, itemKey: text, allowsKeyEditing: true, documentType: type, canEdit: canEdit)
            vc.delegate = self
            navigationController?.pushViewController(vc, animated: true)
        }
    }

    override func tableView(_ tableView: UITableView, accessoryButtonTappedForRowWith indexPath: IndexPath) {
        presentViewController(forIndexPath: indexPath)
    }

    func didChangeName(ofItem item: String, to newName: String) -> Bool {
        guard let value = serializedDict[item] else {
            return false
        }

        var newDict: SerializedDictionaryType = serializedDict
        newDict[item] = nil
        newDict[newName] = value

        let didSucceed = writeToFile(newDict: newDict)
        tableView.reloadData()
        return didSucceed
    }

    func didChangeValue(ofItem item: String, to newValue: SerializedItemType) -> Bool {
        var newDict: SerializedDictionaryType = serializedDict
        newDict[item] = newValue

        let didSucceed = writeToFile(newDict: newDict)
        if isSearching {
            tableView.reloadData()
        } else {
            updateFilteredDict(reloadData: true, searchText: nil)
        }
        return didSucceed
    }

    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        presentViewController(forIndexPath: indexPath)
    }

    @discardableResult
    func writeToFile(newDict: SerializedDictionaryType) -> Bool {
        guard let fileURL = fileURL, canEdit else {
            return false
        }

        if let parentController = parentController {
            let didSucced: Bool
            switch parentController {
            case .dictionary(let parent, let key):
                var parentDict = parent.serializedDict
                parentDict[key] = .dictionary(newDict.asAnyDictionary())
                didSucced = parent.writeToFile(newDict: parentDict)
            case .array(let parent, let index):
                guard parent.array.indices.contains(index) else {
                    return false
                }
                var parentArr = parent.array
                parentArr[index] = newDict.asAnyDictionary()
                didSucced = parent.writeToFile(newArray: parentArr)
            }

            if didSucced {
                self.serializedDict = newDict
                return true
            }

            return false
        }

        switch type {
        case .json:
            do {
                let newData = try JSONSerialization.data(withJSONObject: newDict.asAnyDictionary(), options: .prettyPrinted)
                try FSOperation.perform(.writeData(url: fileURL, data: newData), rootHelperConf: RootConf.shared)
                self.serializedDict = newDict
                return true
            } catch {
                self.errorAlert(error, title: "无法写入文件 \(fileURL.lastPathComponent)", presentingFromIfAvailable: presentedViewController)
                return false
            }
        case .plist(let format):
            guard let format = format else {
                self.errorAlert("无法读取属性列表格式。", title: "无法写入属性列表文件", presentingFromIfAvailable: presentedViewController)
                return false
            }

            do {
                let newData = try PropertyListSerialization.data(fromPropertyList: newDict.asAnyDictionary(), format: format, options: 0)
                try FSOperation.perform(.writeData(url: fileURL, data: newData), rootHelperConf: RootConf.shared)
                self.serializedDict = newDict
                return true
            } catch {
                self.errorAlert(error, title: "无法写入文件 \(fileURL.lastPathComponent)", presentingFromIfAvailable: presentedViewController)
                return false
            }
        }
    }

    func presentAddValue() {
        guard canEdit else {
            return
        }

        let alert = UIAlertController(title: SantanderL10n.t("Add Key"), message: nil, preferredStyle: .alert)
        alert.addTextField { field in
            field.placeholder = SantanderL10n.t("Key")
            field.autocapitalizationType = .none
        }

        var types = [
            ("String", SerializedItemType.string("")),
            ("Boolean", SerializedItemType.bool(false)),
            ("Integer", SerializedItemType.int(0)),
            ("Real", SerializedItemType.float(0)),
            ("Date", SerializedItemType.date(Date()))
        ]
        if case .plist = type {
            types.append(("Data", SerializedItemType.data(Data())))
        }
        types += [
            ("Array", SerializedItemType.array([])),
            ("Dictionary", SerializedItemType.dictionary([:]))
        ]

        for (name, value) in types {
            alert.addAction(UIAlertAction(title: name, style: .default) { [weak self, weak alert] _ in
                guard let self, let key = alert?.textFields?.first?.text?.trimmingCharacters(in: .whitespacesAndNewlines), !key.isEmpty else {
                    return
                }
                guard self.serializedDict[key] == nil else {
                    self.errorAlert("The key already exists.", title: SantanderL10n.t("Duplicate Key"))
                    return
                }
                var newDict = self.serializedDict
                newDict[key] = value
                guard self.writeToFile(newDict: newDict) else {
                    return
                }
                self.updateFilteredDict(reloadData: true, searchText: nil)
            })
        }

        alert.addAction(.cancel())
        present(alert, animated: true)
    }

    func dictElement(forKey key: String) -> SerializedItemType? {
        return isSearching ? filteredDict[key] : serializedDict[key]
    }

    override func tableView(_ tableView: UITableView, trailingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration? {
        guard canEdit else {
            return nil
        }

        let deleteAction = UIContextualAction(style: .destructive, title: nil) { _, _, completion in
            var newDict = self.serializedDict
            newDict[self.keys[indexPath.row]] = nil
            if self.writeToFile(newDict: newDict) {
                self.updateFilteredDict(reloadData: false, searchText: nil)
                self.tableView.deleteRows(at: [indexPath], with: .fade)
                completion(true)
            } else {
                completion(false)
            }
        }
        deleteAction.image = .remove

        return UISwipeActionsConfiguration(actions: [deleteAction])
    }
}

enum SerializedDocumentViewerType {
    case json
    case plist(format: PropertyListSerialization.PropertyListFormat?)
}

extension SerializedDocumentViewController: UISearchBarDelegate {
    func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
        isSearching = false
        tableView.reloadData()
    }

    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        isSearching = !searchText.isEmpty

        updateFilteredDict(reloadData: true, searchText: searchText)
    }

    func valueDescription(forElement element: SerializedItemType?) -> String? {
        guard let element else { return nil }
        switch element {
        case .array(let array):
            return "Array • \(array.count) 项"
        case .dictionary(let dictionary):
            return "Dictionary • \(dictionary.count) 项"
        default:
            let value = element.description.isEmpty ? "" : " • \(element.description)"
            return "\(element.typeDescription)\(value)"
        }
    }

    func updateFilteredDict(reloadData: Bool, searchText text: String?) {
        if isSearching {
            let searchText = text ?? navigationItem.searchController?.searchBar.text ?? ""
            filteredDict = serializedDict.filter { (key, value) in
                return key.localizedCaseInsensitiveContains(searchText) ||
                valueDescription(forElement: value)?.localizedCaseInsensitiveContains(searchText) ?? false
            }
        }

        if reloadData {
            tableView.reloadData()
        }
    }
}

enum SerializedItemType: Equatable, CustomStringConvertible {
    static func == (lhs: SerializedItemType, rhs: SerializedItemType) -> Bool {
        switch (lhs, rhs) {
        case (.string(let first), .string(let second)):         return first == second
        case (.bool(let first), .bool(let second)):             return first == second
        case (.int(let first), .int(let second)):               return first == second
        case (.float(let first), .float(let second)):           return first == second
        case (.data(let first), .data(let second)):             return first == second
        case (.date(let first), .date(let second)):             return first == second
        case (.array(let first), .array(let second)):
            return NSArray(array: first) == NSArray(array: second)
        case (.dictionary(let first), .dictionary(let second)):
            return NSDictionary(dictionary: first) == NSDictionary(dictionary: second)
        default:
            return false
        }
    }

    case string(String)
    case bool(Bool)
    case int(Int)
    case float(Float)
    case array(Array<Any>)
    case dictionary([String: Any])
    case data(Data)
    case date(Date)
    case other(Any)

    init(item: Any) {
        switch item {
        case let string as String:
            self = .string(string)
        case let nsNumber as NSNumber:
            if CFGetTypeID(nsNumber) == CFBooleanGetTypeID() {
                self = .bool(nsNumber.boolValue)
            } else {
                switch CFNumberGetType(nsNumber as CFNumber) {
                case .floatType, .float32Type, .float64Type, .cgFloatType, .doubleType:
                    self = .float(nsNumber.floatValue)
                default:
                    self = .int(nsNumber.intValue)
                }
            }
        case let arr as Array<Any>:
            self = .array(arr)
        case let dictionary as Dictionary<String, Any>:
            self = .dictionary(dictionary)
        case let data as NSData:
            self = .data(data as Data)
        case let date as NSDate:
            self = .date(date as Date)
        default:
            self = .other(item)
        }

    }

    var description: String {
        switch self {
        case .string(let string):
            return string
        case .bool(let bool):
            return bool ? "✓" : ""
        case .int(let int):
            return int.description
        case .float(let float):
            return float.description
        case .array(let array):
            return array.description
        case .dictionary(let nsDictionary):
            return nsDictionary.description
        case .date(let date):
            return date.listFormatted()
        case .data(let data):
            return "Data（大小：\(data.count)）"
        case .other(let any):
            return String(describing: any)
        }
    }

    var typeDescription: String {
        switch self {
        case .string(_): return "String"
        case .bool(_): return "Boolean"
        case .int(_): return "Integer"
        case .float(_): return "Real"
        case .data(_): return "Data"
        case .array(_): return "Array"
        case .dictionary(_): return "Dictionary"
        case .date(_): return "Date"
        case .other(_): return SantanderL10n.t("Unknown")
        }
    }

    var representedObject: Any {
        switch self {
        case .string(let string):
            return string
        case .bool(let bool):
            return bool
        case .int(let int):
            return int
        case .float(let float):
            return float
        case .array(let nsArray):
            return nsArray
        case .dictionary(let nsDictionary):
            return nsDictionary
        case .data(let data):
            return data
        case .date(let date):
            return date
        case .other(let any):
            return any
        }
    }

}

enum SerializedControllerParent {
    case dictionary(SerializedDocumentViewController, key: String)
    case array(SerializedArrayViewController, index: Int)
}

class SerializedItemViewController: UITableViewController {
    var item: SerializedItemType
    var itemKey: String
    let allowsKeyEditing: Bool
    let documentType: SerializedDocumentViewerType
    let canEdit: Bool

    weak var delegate: SerializedItemViewControllerDelegate?
    var retainedDelegate: SerializedItemViewControllerDelegate?

    init(
        item: SerializedItemType,
        itemKey: String,
        allowsKeyEditing: Bool = true,
        documentType: SerializedDocumentViewerType = .plist(format: nil),
        canEdit: Bool = true
    ) {
        self.item = item
        self.itemKey = itemKey
        self.allowsKeyEditing = allowsKeyEditing
        self.documentType = documentType
        self.canEdit = canEdit
        super.init(style: .grouped)
    }

    required init?(coder: NSCoder) {
        fatalError()
    }

    @discardableResult
    func setItem(to newValue: SerializedItemType) -> Bool {
        guard canEdit else { return false }
        if self.delegate?.didChangeValue(ofItem: itemKey, to: newValue) ?? false {
            item = newValue
            tableView.reloadRows(at: [IndexPath(row: 0, section: 1)], with: .fade)
            tableView.reloadRows(at: [IndexPath(row: 0, section: 2)], with: .none)
            return true
        }
        return false
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        applySantanderGlass()
        title = itemKey
    }

    override func numberOfSections(in tableView: UITableView) -> Int {
        return 3
    }

    override func tableView(_ tableView: UITableView, shouldHighlightRowAt indexPath: IndexPath) -> Bool {
        return canEdit && indexPath.section == 2
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }

    func makeBoolChangeSwitch(currentItemBoolValue: Bool) -> UISwitch {
        let toggle = UISwitch()
        toggle.isOn = currentItemBoolValue
        toggle.isEnabled = canEdit
        toggle.addAction(UIAction { [weak self, weak toggle] _ in
            guard let self, let toggle else { return }
            let requested = toggle.isOn
            if !self.setItem(to: .bool(requested)) {
                toggle.setOn(!requested, animated: true)
            }
        }, for: .valueChanged)
        return toggle
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = UITableViewCell(style: .value1, reuseIdentifier: nil)
        var conf = cell.defaultContentConfiguration()

        switch indexPath.section {
        case 0:
            if allowsKeyEditing && canEdit {
                let textField = UITextField(frame: cell.frame)
                textField.text = itemKey
                textField.returnKeyType = .done

                let action = UIAction { [weak self] in
                    self?.itemKeyTextFieldDone(textField, indexPath: indexPath)
                }
                textField.addAction(action, for: .editingDidEndOnExit)
                cell.contentView.addSubview(textField)

                textField.translatesAutoresizingMaskIntoConstraints = false
                NSLayoutConstraint.activate([
                    textField.leadingAnchor.constraint(equalTo: cell.contentView.layoutMarginsGuide.leadingAnchor),
                    textField.trailingAnchor.constraint(equalTo: cell.contentView.layoutMarginsGuide.trailingAnchor),
                    textField.centerYAnchor.constraint(equalTo: cell.contentView.centerYAnchor)
                ])
                return cell
            }

            conf.text = itemKey
            conf.textProperties.numberOfLines = 1

        case 1:
            switch item {
            case .bool(let bool):
                return cellWithView(makeBoolChangeSwitch(currentItemBoolValue: bool), text: SantanderL10n.t("Value"))
            case .string(let string):
                let textView = UITextView(frame: cell.frame)
                textView.text = string
                textView.font = .systemFont(ofSize: UIFont.systemFontSize)
                textView.backgroundColor = cell.backgroundColor
                textView.autoresizingMask = [.flexibleHeight, .flexibleWidth]
                textView.isScrollEnabled = true
                textView.isEditable = canEdit

                let editTextAction = UIAction { [weak self] in
                    guard let self, let text = textView.text else { return }
                    self.setItem(to: .string(text))
                    textView.resignFirstResponder()
                }

                if canEdit {
                    textView.inputAccessoryView = toolbarDoneView(doneAction: editTextAction, textFieldOrView: textView)
                }
                cell.contentView.addSubview(textView)
                return cell
            case .int(_), .float(_):
                let textField = valueTextField(atIndexPath: indexPath)
                textField.isEnabled = canEdit
                return cellWithView(textField, text: SantanderL10n.t("Value"))
            case .date(let date):
                let datePicker = UIDatePicker()
                datePicker.date = date
                datePicker.isEnabled = canEdit

                let action = UIAction { [weak self] in
                    guard let self else { return }
                    self.setItem(to: .date(datePicker.date))
                }

                if canEdit {
                    datePicker.addAction(action, for: .editingDidEnd)
                }
                return cellWithView(datePicker, text: SantanderL10n.t("Value"))
            case .data(let data):
                let textView = UITextView(frame: cell.frame)
                textView.text = data.base64EncodedString()
                textView.font = .monospacedSystemFont(ofSize: 15, weight: .regular)
                textView.autoresizingMask = [.flexibleWidth, .flexibleHeight]
                textView.isEditable = canEdit
                let editAction = UIAction { [weak self] in
                    guard let self, canEdit, let value = textView.text else { return }
                    let compact = value
                        .replacingOccurrences(of: " ", with: "")
                        .replacingOccurrences(of: "\n", with: "")
                        .replacingOccurrences(of: "\r", with: "")
                        .replacingOccurrences(of: "\t", with: "")
                    guard let decoded = Data(base64Encoded: compact) else {
                        self.errorAlert("Base64 数据格式无效。", title: SantanderL10n.t("Invalid Data"))
                        return
                    }
                    self.setItem(to: .data(decoded))
                    textView.resignFirstResponder()
                }
                if canEdit {
                    textView.inputAccessoryView = toolbarDoneView(doneAction: editAction, textFieldOrView: textView)
                }
                cell.contentView.addSubview(textView)
                textView.translatesAutoresizingMaskIntoConstraints = false
                NSLayoutConstraint.activate([
                    textView.leadingAnchor.constraint(equalTo: cell.contentView.layoutMarginsGuide.leadingAnchor),
                    textView.trailingAnchor.constraint(equalTo: cell.contentView.layoutMarginsGuide.trailingAnchor),
                    textView.topAnchor.constraint(equalTo: cell.contentView.topAnchor, constant: 8),
                    textView.bottomAnchor.constraint(equalTo: cell.contentView.bottomAnchor, constant: -8),
                    textView.heightAnchor.constraint(greaterThanOrEqualToConstant: 100)
                ])
                return cellWithView(textView, text: SantanderL10n.t("Value (in base64)"))
            default:
                conf.text = SantanderL10n.t("Value")
                conf.secondaryText = item.description
            }

        case 2:
            conf.text = item.typeDescription
            conf.secondaryText = canEdit ? SantanderL10n.t("点击选择类型") : nil
            cell.accessoryType = canEdit ? .disclosureIndicator : .none

        default:
            fatalError()
        }

        cell.contentConfiguration = conf
        return cell
    }

    override func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        switch section {
        case 0:
            return allowsKeyEditing ? SantanderL10n.t("Key") : SantanderL10n.t("Position in array")
        case 1:
            return SantanderL10n.t("Value")
        case 2:
            return canEdit ? SantanderL10n.t("Change type") : SantanderL10n.t("Type")
        default:
            return nil
        }
    }

    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        guard canEdit, indexPath.section == 2 else { return }
        presentTypePicker()
    }

    private func presentTypePicker() {
        let alert = UIAlertController(title: SantanderL10n.t("Change type"), message: nil, preferredStyle: .actionSheet)
        var typeNames = ["String", "Boolean", "Integer", "Real", "Date"]
        if case .plist = documentType {
            typeNames.append("Data")
        }
        typeNames += ["Array", "Dictionary"]

        for typeName in typeNames {
            alert.addAction(UIAlertAction(title: typeName, style: .default) { [weak self] _ in
                guard let self, let newItem = self.convertedItem(for: typeName) else { return }
                self.setItem(to: newItem)
            })
        }
        alert.addAction(.cancel())

        if let popover = alert.popoverPresentationController {
            popover.sourceView = tableView
            popover.sourceRect = tableView.rectForRow(at: IndexPath(row: 0, section: 2))
        }
        present(alert, animated: true)
    }

    private func convertedItem(for typeName: String) -> SerializedItemType? {
        switch typeName {
        case "String":
            switch item { case .string(let value): return .string(value); default: return .string(item.description) }
        case "Boolean":
            if case .bool(let value) = item { return .bool(value) }
            return .bool(false)
        case "Integer":
            switch item {
            case .int(let value): return .int(value)
            case .float(let value): return .int(Int(value))
            default: return .int(0)
            }
        case "Real":
            switch item {
            case .float(let value): return .float(value)
            case .int(let value): return .float(Float(value))
            default: return .float(0)
            }
        case "Date":
            if case .date(let value) = item { return .date(value) }
            return .date(Date())
        case "Data":
            if case .data(let value) = item { return .data(value) }
            return .data(Data())
        case "Array":
            if case .array(let value) = item { return .array(value) }
            return .array([])
        case "Dictionary":
            if case .dictionary(let value) = item { return .dictionary(value) }
            return .dictionary([:])
        default:
            return nil
        }
    }

    func valueTextField(atIndexPath indexPath: IndexPath) -> UITextField {
        let textField = UITextField()
        let action = UIAction { [weak self] in
            self?.valueTextFieldDone(textField, atIndexPath: indexPath)
        }

        switch item {
        case .string(let string):
            textField.text = string
            textField.returnKeyType = .done
            textField.addAction(action, for: .editingDidEndOnExit)
        case .int(let int):
            textField.keyboardType = .numberPad
            textField.text = int.description
            textField.inputAccessoryView = toolbarDoneView(doneAction: action, textFieldOrView: textField)
        case .float(let float):
            textField.text = float.description
            textField.keyboardType = .decimalPad
            textField.inputAccessoryView = toolbarDoneView(doneAction: action, textFieldOrView: textField)
        default:
            break
        }
        return textField
    }

    func toolbarDoneView(doneAction: UIAction, textFieldOrView: UIResponder) -> UIToolbar {
        let toolbar = UIToolbar()
        let cancelAction = UIAction { textFieldOrView.resignFirstResponder() }
        let doneButton = UIBarButtonItem(systemItem: .done, primaryAction: doneAction)
        let cancelButton = UIBarButtonItem(systemItem: .cancel, primaryAction: cancelAction)
        toolbar.setItems([cancelButton, .flexibleSpace(), doneButton], animated: false)
        toolbar.sizeToFit()
        return toolbar
    }

    func valueTextFieldDone(_ textField: UITextField, atIndexPath indexPath: IndexPath) {
        guard canEdit, let text = textField.text, !text.isEmpty else {
            return
        }

        switch item {
        case .string(_):
            setItem(to: .string(text))
        case .int(_):
            guard let num = Int(text) else { return }
            setItem(to: .int(num))
        case .float(_):
            guard let num = Float(text) else { return }
            setItem(to: .float(num))
        default:
            break
        }
        textField.resignFirstResponder()
    }

    func itemKeyTextFieldDone(_ textField: UITextField, indexPath: IndexPath) {
        guard canEdit, allowsKeyEditing, let text = textField.text, !text.isEmpty else {
            return
        }

        if self.delegate?.didChangeName(ofItem: itemKey, to: text) ?? false {
            self.itemKey = text
            self.title = self.itemKey
            self.tableView.reloadRows(at: [indexPath], with: .fade)
        }
        textField.resignFirstResponder()
    }
}

protocol SerializedItemViewControllerDelegate: AnyObject {
    func didChangeName(ofItem item: String, to newName: String) -> Bool
    func didChangeValue(ofItem item: String, to newValue: SerializedItemType) -> Bool
}

fileprivate func makeGenericButton(image: UIImage?) -> UIButton {
    let button = UIButton(type: .system)
    button.translatesAutoresizingMaskIntoConstraints = false
    button.setImage(image, for: .normal)
    button.tintColor = .label
    return button
}


extension PathListViewController {
    override func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        SantanderGlass.styleCell(cell)
    }
}

extension PathPermissionsViewController {
    override func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        SantanderGlass.styleCell(cell)
    }
}

extension PathGroupOwnerViewController {
    override func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        SantanderGlass.styleCell(cell)
    }
}

extension SerializedDocumentViewController {
    override func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        SantanderGlass.styleCell(cell)
    }
}

extension SerializedArrayViewController {
    override func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        SantanderGlass.styleCell(cell)
    }
}

extension PlistTreeEditorViewController {
    override func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        SantanderGlass.styleCell(cell)
    }
}

extension SerializedItemViewController {
    override func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        SantanderGlass.styleCell(cell)
    }
}

extension PathInformationTableViewController {
    override func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        SantanderGlass.styleCell(cell)
    }
}

class KeyboardSearchView: UIInputView {
    weak var textView: TextView?

    let searchQueue = DispatchQueue(label: "com.Antoine.Santander.KeyboardSearchView.search", qos: .background)
    var searchWorkItem: DispatchWorkItem?

    var searchMethod: SearchQuery.MatchMethod = .contains
    var isCaseSensitive: Bool = false

    var searchTextField: UISearchTextField!

    var currentIndex: Int = 0
    var chevronUpButton: UIButton!
    var chevronDownButton: UIButton!
    var currentResults: [SearchResult] = []

    init(
        frame: CGRect = CGRect(origin: .zero, size: CGSize(width: UIScreen.main.bounds.width, height: 44)),
        textView: TextView
    ) {
        super.init(frame: frame, inputViewStyle: .default)
        self.textView = textView
        commonInit()
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    func commonInit() {
        let doneButton = UIButton(type: .system)
        doneButton.translatesAutoresizingMaskIntoConstraints = false
        doneButton.setTitle(SantanderL10n.t("Done"), for: .normal)
        doneButton.titleLabel?.font = .preferredFont(forTextStyle: .body)
        doneButton.setTitleColor(.white, for: .normal)
        doneButton.addTarget(self, action: #selector(doneDismiss), for: .allEvents)

        self.chevronUpButton = makeGenericButton(image: UIImage(systemName: "chevron.up"))
        self.chevronDownButton = makeGenericButton(image: UIImage(systemName: "chevron.down"))

        chevronUpButton.tag = 0
        chevronDownButton.tag = 1

        chevronUpButton.addTarget(self, action: #selector(chevronButtonClicked(sender:)), for: .touchUpInside)
        chevronDownButton.addTarget(self, action: #selector(chevronButtonClicked(sender:)), for: .touchUpInside)

        chevronUpButton.isEnabled = false
        chevronDownButton.isEnabled = false

        let filterButton = makeGenericButton(image: UIImage(systemName: "line.horizontal.3.decrease.circle")?.withTintColor(.systemBlue, renderingMode: .alwaysOriginal))

        filterButton.menu = makeSearchMethodMenu(button: filterButton)
        filterButton.showsMenuAsPrimaryAction = true

        let chevronButtonsStackView = UIStackView(arrangedSubviews: [filterButton, chevronUpButton, chevronDownButton])
        chevronButtonsStackView.setCustomSpacing(10, after: filterButton)
        chevronButtonsStackView.translatesAutoresizingMaskIntoConstraints = false

        self.searchTextField = UISearchTextField()
        searchTextField.addTarget(self, action: #selector(searchDidChange(searchTextField:)), for: .editingChanged)
        searchTextField.inputAccessoryView = self
        searchTextField.translatesAutoresizingMaskIntoConstraints = false

        addSubview(doneButton)
        addSubview(searchTextField)
        addSubview(chevronButtonsStackView)

        NSLayoutConstraint.activate([
            doneButton.leadingAnchor.constraint(equalTo: leadingAnchor, constant: 10),
            doneButton.centerYAnchor.constraint(equalTo: layoutMarginsGuide.centerYAnchor),

            chevronButtonsStackView.centerYAnchor.constraint(equalTo: layoutMarginsGuide.centerYAnchor),
            chevronButtonsStackView.trailingAnchor.constraint(equalTo: layoutMarginsGuide.trailingAnchor),

            searchTextField.leadingAnchor.constraint(equalTo: doneButton.leadingAnchor, constant: 50),
            searchTextField.trailingAnchor.constraint(equalTo: chevronButtonsStackView.leadingAnchor, constant: -10),
            searchTextField.centerYAnchor.constraint(equalTo: layoutMarginsGuide.centerYAnchor),
        ])
    }

    func makeSearchMethodMenu(button: UIButton) -> UIMenu {
        let filterButtonItems = SearchQuery.MatchMethod.allCases.reversed().map { meth in
            return UIAction(title: meth.description, state: searchMethod == meth ? .on : .off) { [unowned self] _ in
                searchMethod = meth
                button.menu = makeSearchMethodMenu(button: button)
            }
        }

        let caseSensitiveAction = UIAction(title: SantanderL10n.t("Case Sensitive"), state: isCaseSensitive ? .on : .off) { [unowned self] action in
            isCaseSensitive.toggle()
            button.menu = makeSearchMethodMenu(button: button)
        }

        let items: [UIMenuElement] = [UIMenu(options: .displayInline, children: [caseSensitiveAction])]
        + filterButtonItems
        return UIMenu(title: SantanderL10n.t("Search Method"), children: items)
    }

    @objc
    func doneDismiss() {
        guard let textView else { return }
        textView.highlightedRanges = []
        textView.inputAccessoryView = KeyboardToolsView(textView: textView)
        textView.resignFirstResponder()
    }

    @objc
    func searchDidChange(searchTextField: UISearchTextField) {
        searchWorkItem?.cancel()

        guard let textView else {
            return
        }

        guard let text = searchTextField.text, !text.isEmpty else {
            textView.highlightedRanges = []
            chevronUpButton.isEnabled = false
            chevronDownButton.isEnabled = false
            return
        }

        let newItem = DispatchWorkItem(flags: .assignCurrentContext) { [unowned self] in
            update(withResults: textView.search(for: makeSearchQuery(text: text)))
        }

        searchWorkItem = newItem
        searchQueue.asyncAfter(deadline: .now().advanced(by: .milliseconds(3)), execute: newItem)
    }

    func update(withResults results: [SearchResult]) {
        currentResults = results

        let areResultsNotEmpty = !results.isEmpty
        DispatchQueue.main.async { [unowned self] in
            if areResultsNotEmpty {
                textView?.scrollRangeToVisible(results[0].range)
            }

            chevronUpButton.isEnabled = areResultsNotEmpty
            chevronDownButton.isEnabled = areResultsNotEmpty
        }

        let highlightedRanges = results.map { result in
            HighlightedRange(range: result.range, color: .systemOrange)
        }

        textView?.highlightedRanges = highlightedRanges
    }

    func makeSearchQuery(text: String) -> SearchQuery {
        return SearchQuery(text: text, matchMethod: searchMethod, isCaseSensitive: isCaseSensitive)
    }

    @objc
    func chevronButtonClicked(sender: UIButton) {
        switch sender.tag {
        case 0:
            currentIndex -= 1
        case 1:
            currentIndex += 1
        default:
            break
        }

        chevronUpButton.isEnabled = currentIndex != 0
        chevronDownButton.isEnabled = currentIndex != (currentResults.count - 1)
        print(currentIndex, currentResults.count)

        textView?.scrollRangeToVisible(currentResults[currentIndex].range)
    }
}

extension SearchQuery.MatchMethod: CaseIterable, CustomStringConvertible {
    public static var allCases: [SearchQuery.MatchMethod] = [.startsWith, .endsWith, .contains, .fullWord, .regularExpression]

    public var description: String {
        switch self {
        case .contains:
            return SantanderL10n.t("Contains")
        case .fullWord:
            return SantanderL10n.t("Full Word")
        case .startsWith:
            return SantanderL10n.t("Starts With")
        case .endsWith:
            return SantanderL10n.t("Ends With")
        case .regularExpression:
            return SantanderL10n.t("Regex")
        }
    }
}

fileprivate func _makeGenericButton(image: UIImage?) -> UIButton {
    let button = UIButton(type: .system)
    button.translatesAutoresizingMaskIntoConstraints = false
    button.setImage(image, for: .normal)
    button.tintColor = .label
    return button
}

final class KeyboardToolsView: UIInputView {
    private let shiftLeftButton = _makeGenericButton(image: UIImage(systemName: "arrow.left.to.line"))
    private let shiftRightButton = _makeGenericButton(image: UIImage(systemName: "arrow.right.to.line"))

    private let undoButton = _makeGenericButton(image: UIImage(systemName: "arrow.uturn.backward"))
    private let redoButton = _makeGenericButton(image: UIImage(systemName: "arrow.uturn.forward"))

    private let dismissButton = _makeGenericButton(image: UIImage(systemName: "keyboard.chevron.compact.down"))
    private let searchButton = _makeGenericButton(image: UIImage(systemName: "magnifyingglass"))

    private weak var textView: TextView?

    init(textView: TextView) {
        self.textView = textView
        let frame = CGRect(x: 0, y: 0, width: UIScreen.main.bounds.width, height: 44)
        super.init(frame: frame, inputViewStyle: .keyboard)
        setupView()
        setupLayout()
        NotificationCenter.default.addObserver(self, selector: #selector(updateUndoRedoButtonStates), name: .NSUndoManagerCheckpoint, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(updateUndoRedoButtonStates), name: .NSUndoManagerDidUndoChange, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(updateUndoRedoButtonStates), name: .NSUndoManagerDidRedoChange, object: nil)
    }

    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    deinit {
        NotificationCenter.default.removeObserver(self)
    }

    private func setupView() {
        addSubview(shiftLeftButton)
        addSubview(shiftRightButton)
        addSubview(undoButton)
        addSubview(redoButton)
        addSubview(dismissButton)
        addSubview(searchButton)

        shiftLeftButton.addTarget(self, action: #selector(shiftLeft), for: .touchUpInside)
        shiftRightButton.addTarget(self, action: #selector(shiftRight), for: .touchUpInside)
        undoButton.addTarget(self, action: #selector(undo), for: .touchUpInside)
        redoButton.addTarget(self, action: #selector(redo), for: .touchUpInside)
        dismissButton.addTarget(self, action: #selector(dismissKeyboard), for: .touchUpInside)
        searchButton.addTarget(self, action: #selector(switchToSearch), for: .touchUpInside)
        updateUndoRedoButtonStates()
    }

    private func setupLayout() {
        NSLayoutConstraint.activate([
            shiftLeftButton.leadingAnchor.constraint(equalTo: layoutMarginsGuide.leadingAnchor),
            shiftLeftButton.topAnchor.constraint(equalTo: topAnchor),
            shiftLeftButton.bottomAnchor.constraint(equalTo: bottomAnchor),

            shiftRightButton.leadingAnchor.constraint(equalTo: shiftLeftButton.trailingAnchor, constant: 6),
            shiftRightButton.topAnchor.constraint(equalTo: topAnchor),
            shiftRightButton.bottomAnchor.constraint(equalTo: bottomAnchor),

            undoButton.trailingAnchor.constraint(equalTo: redoButton.leadingAnchor, constant: -10),
            undoButton.topAnchor.constraint(equalTo: topAnchor),
            undoButton.bottomAnchor.constraint(equalTo: bottomAnchor),

            redoButton.trailingAnchor.constraint(equalTo: dismissButton.leadingAnchor, constant: -46),
            redoButton.topAnchor.constraint(equalTo: topAnchor),
            redoButton.bottomAnchor.constraint(equalTo: bottomAnchor),

            dismissButton.trailingAnchor.constraint(equalTo: layoutMarginsGuide.trailingAnchor),
            dismissButton.topAnchor.constraint(equalTo: topAnchor),
            dismissButton.bottomAnchor.constraint(equalTo: bottomAnchor),

            searchButton.trailingAnchor.constraint(equalTo: dismissButton.trailingAnchor, constant: -35),
            searchButton.topAnchor.constraint(equalTo: topAnchor),
            searchButton.bottomAnchor.constraint(equalTo: bottomAnchor)
        ])
    }
}

private extension KeyboardToolsView {
    @objc private func shiftLeft() {
        textView?.shiftLeft()
    }

    @objc private func shiftRight() {
        textView?.shiftRight()
    }

    @objc private func undo() {
        textView?.undoManager?.undo()
    }

    @objc private func redo() {
        textView?.undoManager?.redo()
    }

    @objc private func dismissKeyboard() {
        textView?.resignFirstResponder()
    }

    @objc private func switchToSearch() {
        guard let textView else { return }
        textView.inputAccessoryView = KeyboardSearchView(textView: textView)
        textView.resignFirstResponder()
        textView.becomeFirstResponder()
    }

    @objc private func updateUndoRedoButtonStates() {
        let undoManager = textView?.undoManager
        undoButton.isEnabled = undoManager?.canUndo ?? false
        redoButton.isEnabled = undoManager?.canRedo ?? false
    }
}

class TextEditorThemeSettingsViewController: SettingsTableViewController {

    weak var delegate: EditorThemeSettingsDelegate?
    var selectedIndexPath: IndexPath? = nil
    var theme: CodableTextEditorTheme

    var editorBackgroundColor: UIColor {
        theme.textEditorBackgroundColor?.uiColor ?? .tertiarySystemBackground
    }

    init(style: UITableView.Style, theme: CodableTextEditorTheme) {
        self.theme = theme
        super.init(style: style)
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) hasn't been implemented.")
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        applySantanderGlass()
        self.title = SantanderL10n.t("Text Editor Settings")
    }

    override func numberOfSections(in tableView: UITableView) -> Int {
        return 3
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        switch section {
        case 1: return 3
        case 0, 2: return 2
        default: fatalError("How the hell did you get here?! Unhandled section: \(section)")
        }
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = UITableViewCell(style: .value1, reuseIdentifier: nil)
        var conf = cell.defaultContentConfiguration()
        switch (indexPath.section, indexPath.row) {
        case (0, 0):
            conf.text = SantanderL10n.t("Font")
            conf.secondaryText = theme.font.uiFont.fontName
        case (0, 1):
            conf.text = SantanderL10n.t("Font size")
            let stepper = UIStepper()
            stepper.value = theme.font.uiFont.pointSize
            stepper.addTarget(self, action: #selector(fontStepperValueChanged(sender:)), for: .valueChanged)
            cell.accessoryView = stepper
            conf.secondaryText = theme.font.uiFont.pointSize.description
        case (1, 0):
            return cellWithView(settingsSwitch(forIndexPath: indexPath), text: SantanderL10n.t("Show Line Count"))
        case (1, 1):
            return cellWithView(settingsSwitch(forIndexPath: indexPath), text: SantanderL10n.t("Wrap Lines"))
        case (1, 2):
            return cellWithView(settingsSwitch(forIndexPath: indexPath), text: SantanderL10n.t("Use Character Pairs"))
        case (2, 0):
            conf.text = SantanderL10n.t("Text Color")
            cell.accessoryView = cell.colorCircleAccessoryView(color: theme.textColor?.uiColor ?? .label)
        case (2, 1):
            conf.text = SantanderL10n.t("Editor Background Color")
            cell.accessoryView = cell.colorCircleAccessoryView(color: editorBackgroundColor)
        default: break
        }

        cell.contentConfiguration = conf
        return cell
    }

    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        self.selectedIndexPath = indexPath
        if indexPath.section == 2 {
            let vc = UIColorPickerViewController()
            switch indexPath.row {
            case 0:
                vc.selectedColor = theme.textColor?.uiColor ?? .label
            case 1:
                vc.selectedColor = editorBackgroundColor
            default:
                break
            }

            vc.delegate = self
            self.present(vc, animated: true)
            return
        }

        switch (indexPath.section, indexPath.row) {
        case (0, 0):
            let vc = UIFontPickerViewController()
            vc.delegate = self
            self.present(vc, animated: true)
        default: break
        }
    }

    override func switchOptionIsEnabled(forIndexPath indexPath: IndexPath) -> Bool {
        switch (indexPath.section, indexPath.row) {
        case (1, 0):
            return UserPreferences.showLineCount
        case (1, 1):
            return UserPreferences.wrapLines
        case (1, 2):
            return UserPreferences.useCharacterPairs
        default:
            fatalError()
        }
    }

    override func settingsSwitch(forIndexPath indexPath: IndexPath) -> UISwitch {
        let s = super.settingsSwitch(forIndexPath: indexPath)

        let action = UIAction {
            UserDefaults.standard.set(s.isOn, forKey: self.defaultsKey(forIndexPath: indexPath))
            switch indexPath.row {
            case 0:
                self.delegate?.showLineCountConfigurationDidChange(showLineCount: s.isOn)
            case 1:
                self.delegate?.wrapLinesConfigurationDidChange(wrapLines: s.isOn)
            case 2:
                self.delegate?.characterPairConfigurationDidChange(useCharacterPairs: s.isOn)
            default:
                break
            }
        }

        s.addAction(action, for: .valueChanged)
        return s
    }

    override func defaultsKey(forIndexPath indexPath: IndexPath) -> String {
        switch (indexPath.section, indexPath.row) {
        case (1, 0):
            return "TextEditorShowLineCount"
        case (1, 1):
            return "TextEditorWrapLines"
        case (1, 2):
            return "TextEditorUseCharacterPairs"
        default:
            fatalError()
        }
    }

    @objc
    func fontStepperValueChanged(sender: UIStepper) {
        let val = sender.value
        self.theme.font = CodableFont(self.theme.font.uiFont.withSize(val))

        let stepperCellIndexPath = IndexPath(row: 1, section: 0)
        self.tableView.reloadRows(at: [stepperCellIndexPath], with: .none)
        delegate?.themeDidChange(to: self.theme)
    }

    override func tableView(_ tableView: UITableView, shouldHighlightRowAt indexPath: IndexPath) -> Bool {
        return indexPath.section == 2 || (indexPath.section, indexPath.row) == (0, 0)
    }

    func setColor(_ color: UIColor, forIndexPath indexPath: IndexPath) {
        switch (indexPath.section, indexPath.row) {
        case (2, 0):
            theme.textColor = CodableColor(color)
            self.delegate?.themeDidChange(to: theme)
        case (2, 1):
            let codableColor = CodableColor(color)
            theme.textEditorBackgroundColor = codableColor
            self.delegate?.didChangeEditorBackground(to: codableColor)
        default:
            break
        }

        tableView.reloadRows(at: [indexPath], with: .none)
    }

    override func colorPickerViewControllerDidFinish(_ viewController: UIColorPickerViewController) {
        guard let selectedIndexPath = selectedIndexPath else {
            return
        }
        setColor(viewController.selectedColor, forIndexPath: selectedIndexPath)
    }

    override func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        switch section {
        case 0:
            return SantanderL10n.t("Fonts")
        case 1:
            return SantanderL10n.t("Lines")
        case 2:
            return SantanderL10n.t("Colors")
        default:
            return nil
        }
    }
}

extension TextEditorThemeSettingsViewController {
    override func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        SantanderGlass.styleCell(cell)
    }
}

extension TextEditorThemeSettingsViewController: UIFontPickerViewControllerDelegate {
    func fontPickerViewControllerDidPickFont(_ viewController: UIFontPickerViewController) {
        viewController.dismiss(animated: true)
        guard let descriptor = viewController.selectedFontDescriptor else { return }
        let existingFontSize = self.theme.font.uiFont.pointSize
        self.theme.font = CodableFont(UIFont(descriptor: descriptor, size: existingFontSize))

        let fontNameIndexPath = IndexPath(row: 0, section: 0)
        self.tableView.reloadRows(at: [fontNameIndexPath], with: .none)
        delegate?.themeDidChange(to: self.theme)
    }
}

protocol EditorThemeSettingsDelegate: AnyObject {
    func themeDidChange(to newTheme: CodableTextEditorTheme)
    func wrapLinesConfigurationDidChange(wrapLines: Bool)
    func showLineCountConfigurationDidChange(showLineCount: Bool)
    func characterPairConfigurationDidChange(useCharacterPairs: Bool)
    func didChangeEditorBackground(to color: CodableColor)
}

class TextFileEditorViewController: UIViewController, TextViewDelegate, EditorThemeSettingsDelegate {
    var fileURL: URL
    var originalContents: String

    var textView: TextView = TextView()
    var keyboardToolsView: KeyboardToolsView!
    var theme: CodableTextEditorTheme = UserPreferences.textEditorTheme {
        didSet {
            UserPreferences.textEditorTheme = theme
            let state = TextViewState(text: textView.text, theme: theme.theme)
            if Thread.isMainThread {
                textView.setState(state)
            } else {
                DispatchQueue.main.async {
                    self.textView.setState(state)
                }
            }
        }
    }

    init(fileURL: URL, contents: String) {
        self.fileURL = fileURL
        self.originalContents = contents

        super.init(nibName: nil, bundle: nil)
    }

    convenience init(fileURL: URL) throws {
        self.init(fileURL: fileURL, contents: try String(contentsOf: fileURL))
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    lazy var themeController: TextEditorThemeSettingsViewController = {
        let controller = TextEditorThemeSettingsViewController(style: .insetGrouped, theme: self.theme)
        controller.delegate = self
        return controller
    }()

    override func viewDidLoad() {
        super.viewDidLoad()

        self.title = fileURL.lastPathComponent
        textView.showLineNumbers = UserPreferences.showLineCount
        textView.isLineWrappingEnabled = UserPreferences.wrapLines
        textView.setState(TextViewState(text: originalContents, theme: theme.theme))

        textView.autocorrectionType = .no
        textView.autocapitalizationType = .none
        if UserPreferences.useCharacterPairs {
            textView.characterPairs = AnyCharacterPair.all()
        }

        let contentLocked = PathPermissions.isLocked(at: fileURL)
        textView.isEditable = !contentLocked
        textView.editorDelegate = contentLocked ? nil : self
        textView.backgroundColor = theme.textEditorBackgroundColor?.uiColor ?? .tertiarySystemBackground
        self.keyboardToolsView = KeyboardToolsView(textView: textView)
        textView.inputAccessoryView = keyboardToolsView

        let saveBarButton = UIBarButtonItem(barButtonSystemItem: .save, target: self, action: #selector(saveToFile))
        saveBarButton.isEnabled = !contentLocked && !textIsSameAsOriginal
        navigationItem.rightBarButtonItems = [saveBarButton, UIBarButtonItem(image: UIImage(systemName: "ellipsis.circle"), menu: makeRightBarMenuItemsMenu())]

        navigationItem.leftBarButtonItem = UIBarButtonItem(barButtonSystemItem: .cancel, target: self, action: #selector(cancel))

#if compiler(>=5.7)
        if #available(iOS 16.0, *) {
            navigationItem.style = .editor
            self.navigationItem.renameDelegate = self
            self.navigationItem.documentProperties = UIDocumentProperties(url: fileURL)
        }
#endif

        textView.keyboardDismissMode = .onDrag
        textView.translatesAutoresizingMaskIntoConstraints = false

        view.addSubview(textView)

        configureNavigationBarToNormal()

        textView.constraintCompletely(to: view)

        if UIDevice.isiPad {
            let navVC = UINavigationController(rootViewController: themeController)
            splitViewController?.setViewController(navVC, for: .primary)
            splitViewController?.preferredDisplayMode = .oneBesideSecondary
        }

        let notificationCenter = NotificationCenter.default
        notificationCenter.addObserver(self, selector: #selector(adjustForKeyboard), name: UIResponder.keyboardWillHideNotification, object: nil)
        notificationCenter.addObserver(self, selector: #selector(adjustForKeyboard), name: UIResponder.keyboardWillChangeFrameNotification, object: nil)
    }

    @objc func adjustForKeyboard(notification: Notification) {
        guard let keyboardValue = notification.userInfo?[UIResponder.keyboardFrameEndUserInfoKey] as? NSValue else {
            return
        }

        let keyboardScreenEndFrame = keyboardValue.cgRectValue
        let keyboardViewEndFrame = view.convert(keyboardScreenEndFrame, from: view.window)

        if notification.name == UIResponder.keyboardWillHideNotification {
            textView.contentInset = .zero
        } else {
            textView.contentInset = UIEdgeInsets(top: 0, left: 0,
                                                 bottom: keyboardViewEndFrame.height - view.safeAreaInsets.bottom,
                                                 right: 0)
        }

        textView.scrollIndicatorInsets = textView.contentInset
        let selectedRange = textView.selectedRange
        textView.scrollRangeToVisible(selectedRange)
    }

    override var keyCommands: [UIKeyCommand]? {
        return [
            UIKeyCommand(title: SantanderL10n.t("Zoom in"), action: #selector(zoomInOrOut(sender:)), input: "+", modifierFlags: .command),
            UIKeyCommand(title: SantanderL10n.t("Zoom out"), action: #selector(zoomInOrOut(sender:)), input: "-", modifierFlags: .command)
        ]
    }

    @objc func zoomInOrOut(sender: UIKeyCommand) {
        let existingFont = theme.font.uiFont
        self.theme.font = CodableFont(existingFont.withSize(existingFont.pointSize))

        switch sender.title {
        case SantanderL10n.t("Zoom in"):
            self.theme.font = CodableFont(existingFont.withSize(existingFont.pointSize + 1))
        case SantanderL10n.t("Zoom out"):
            self.theme.font = CodableFont(existingFont.withSize(existingFont.pointSize - 1))
        default:
            break
        }

        themeController.theme = self.theme
        themeController.tableView.reloadRows(at: [IndexPath(row: 1, section: 0)], with: .none)
    }

    func makeRightBarMenuItemsMenu() -> UIMenu {
        let settingsAction = UIAction(title: SantanderL10n.t("Settings"), image: UIImage(systemName: "gear")) { _ in
            self.presentTextEditorSettings()
        }

        let goToLineAction = UIAction(title: SantanderL10n.t("Go to line")) { _ in
            self.showGoToLine()
        }

        return UIMenu(image: UIImage(systemName: "ellipsis.circle"), children: [settingsAction, goToLineAction])
    }

    func showGoToLine() {
        let alert = UIAlertController(title: SantanderL10n.t("Go to line"), message: nil, preferredStyle: .alert)
        alert.addTextField { textField in
            textField.keyboardType = .numberPad
        }

        let goToLineAction = UIAlertAction(title: SantanderL10n.t("Go to line"), style: .default) { _ in
            guard let text = alert.textFields?.first?.text, let line = Int(text) else {
                print("\(#function) should not have reached here!")
                return
            }

            self.textView.goToLine(line - 1)
        }

        alert.addAction(.cancel())
        alert.addAction(goToLineAction)
        self.present(alert, animated: true)
    }

    func textViewDidChange(_ textView: TextView) {
        self.navigationItem.rightBarButtonItem?.isEnabled = !textIsSameAsOriginal
    }

    @objc
    func saveToFile() {
        let newContentsToSave = textView.text ?? ""

        do {
            try FSOperation.perform(.writeString(url: fileURL, string: newContentsToSave), rootHelperConf: RootConf.shared)
            self.dismiss(animated: true)
        } catch {
            self.errorAlert(error, title: SantanderL10n.t("Unable to save to file"))
        }
    }

    @objc
    func cancel() {
        if !textIsSameAsOriginal {
            let alert = UIAlertController(title: SantanderL10n.t("Unsaved changes"), message: "文件「\(fileURL.lastPathComponent)」有未保存的更改，确定要关闭吗？", preferredStyle: .alert)
            let saveAction = UIAlertAction(title: SantanderL10n.t("Save"), style: .default) { _ in
                self.saveToFile()
            }
            let dontSaveAction = UIAlertAction(title: SantanderL10n.t("Don't save"), style: .destructive) { _ in
                self.dismiss(animated: true)
            }
            alert.addAction(dontSaveAction)
            alert.addAction(saveAction)
            self.present(alert, animated: true)
        } else {
            self.dismiss(animated: true)
        }
    }

    var textIsSameAsOriginal: Bool {
        textView.text == originalContents
    }

    @objc func presentTextEditorSettings() {
        if UIDevice.isiPad {
            splitViewController?.show(.primary)
        } else {
            let navVC = UINavigationController(rootViewController: themeController)

            if #available(iOS 15.0, *) {
                navVC.sheetPresentationController?.detents = [.medium(), .large()]
            }
            self.present(navVC, animated: true)
        }
    }

    func themeDidChange(to newTheme: CodableTextEditorTheme) {
        self.theme = newTheme
    }

    func wrapLinesConfigurationDidChange(wrapLines: Bool) {
        self.textView.isLineWrappingEnabled = wrapLines
    }

    func showLineCountConfigurationDidChange(showLineCount: Bool) {
        self.textView.showLineNumbers = showLineCount
    }

    func didChangeEditorBackground(to color: CodableColor) {
        self.textView.backgroundColor = color.uiColor
        self.theme.textEditorBackgroundColor = color
    }

    func characterPairConfigurationDidChange(useCharacterPairs: Bool) {
        textView.characterPairs = useCharacterPairs ? AnyCharacterPair.all() : []
    }
}

#if compiler(>=5.7)
@available(iOS 16.0, *)
extension TextFileEditorViewController: UINavigationItemRenameDelegate {
    func navigationItem(_: UINavigationItem, didEndRenamingWith title: String) {
        let newURL = self.fileURL.deletingLastPathComponent().appendingPathComponent(title)

        guard newURL != self.fileURL else {
            return
        }

        do {
            try FSOperation.perform(.moveItem(items: [fileURL], resultPath: newURL), rootHelperConf: RootConf.shared)
            self.fileURL = newURL
        } catch {
            self.errorAlert(error, title: "无法重命名 \(fileURL.lastPathComponent)")
            self.title = fileURL.lastPathComponent
        }
    }
}
#endif

class AnyTheme: Theme {
    public init(
        textColor: UIColor,
        font: UIFont,
        gutterBackgroundColor: UIColor,
        gutterHairlineColor: UIColor,
        lineNumberColor: UIColor,
        lineNumberFont: UIFont,
        selectedLineBackgroundColor: UIColor,
        selectedLinesLineNumberColor: UIColor,
        selectedLinesGutterBackgroundColor: UIColor,
        invisibleCharactersColor: UIColor,
        pageGuideBackgroundColor: UIColor,
        pageGuideHairlineColor: UIColor,
        markedTextBackgroundColor: UIColor,
        markedTextBackgroundBorderColor: UIColor
    ) {
        self._textColor = textColor
        self._font = font
        self._gutterBackgroundColor = gutterBackgroundColor
        self._gutterHairlineColor = gutterHairlineColor
        self._lineNumberColor = lineNumberColor
        self._lineNumberFont = lineNumberFont
        self._selectedLineBackgroundColor = selectedLineBackgroundColor
        self._selectedLinesLineNumberColor = selectedLinesLineNumberColor
        self._selectedLinesGutterBackgroundColor = selectedLinesGutterBackgroundColor
        self._invisibleCharactersColor = invisibleCharactersColor
        self._pageGuideBackgroundColor = pageGuideBackgroundColor
        self._pageGuideHairlineColor = pageGuideHairlineColor
        self._markedTextBackgroundColor = markedTextBackgroundColor
        self._markedTextBackgroundBorderColor = markedTextBackgroundBorderColor
    }

    private let _textColor: UIColor
    private let _font: UIFont
    private let _gutterBackgroundColor: UIColor
    private let _gutterHairlineColor: UIColor
    private let _lineNumberColor: UIColor
    private let _lineNumberFont: UIFont
    private let _selectedLineBackgroundColor: UIColor
    private let _selectedLinesLineNumberColor: UIColor
    private let _selectedLinesGutterBackgroundColor: UIColor
    private let _invisibleCharactersColor: UIColor
    private let _pageGuideBackgroundColor: UIColor
    private let _pageGuideHairlineColor: UIColor
    private let _markedTextBackgroundColor: UIColor
    private let _markedTextBackgroundBorderColor: UIColor

    var textColor: UIColor { _textColor }
    var font: UIFont { _font }
    var gutterBackgroundColor: UIColor { _gutterBackgroundColor }
    var gutterHairlineColor: UIColor { _gutterHairlineColor }
    var lineNumberColor: UIColor { _lineNumberColor }
    var lineNumberFont: UIFont { _lineNumberFont }
    var selectedLineBackgroundColor: UIColor { _selectedLineBackgroundColor }
    var selectedLinesLineNumberColor: UIColor { _selectedLinesLineNumberColor }
    var selectedLinesGutterBackgroundColor: UIColor { _selectedLinesGutterBackgroundColor }
    var invisibleCharactersColor: UIColor { _invisibleCharactersColor }
    var pageGuideBackgroundColor: UIColor { _pageGuideBackgroundColor }
    var pageGuideHairlineColor: UIColor { _pageGuideHairlineColor }
    var markedTextBackgroundColor: UIColor { _markedTextBackgroundColor }
    var markedTextBackgroundBorderColor: UIColor { _markedTextBackgroundBorderColor }

    func textColor(for rawHighlightName: String) -> UIColor? {
        _ = rawHighlightName
        return nil
    }

    func font(for rawHighlightName: String) -> UIFont? {
        _ = rawHighlightName
        return nil
    }
}

struct CodableColor: Codable {
    let red: CGFloat
    let green: CGFloat
    let blue: CGFloat
    let alpha: CGFloat

    var uiColor: UIColor {
        return UIColor(red: self.red, green: self.green, blue: self.blue, alpha: self.alpha)
    }

    init(_ color: UIColor) {
        var _red: CGFloat = 0, _green: CGFloat = 0, _blue: CGFloat = 0, _alpha: CGFloat = 0

        color.getRed(&_red, green: &_green, blue: &_blue, alpha: &_alpha)

        self.red = _red
        self.blue = _blue
        self.green = _green
        self.alpha = _alpha
    }
}

struct CodableFont: Codable {
    var name: String
    var size: CGFloat

    var uiFont: UIFont {
        UIFont(name: name, size: size) ?? UIFont.monospacedSystemFont(ofSize: size, weight: .regular)
    }

    init(_ font: UIFont) {
        self.name = font.fontName
        self.size = font.pointSize
    }
}

struct CodableTextEditorTheme: Codable {
    var textColor: CodableColor? = nil
    var font = CodableFont(UIFont(name: "Menlo-Regular", size: 16)!)

    var gutterBackgroundColor: CodableColor = CodableColor(.secondarySystemBackground)
    var gutterHairlineColor: CodableColor = CodableColor(.opaqueSeparator)

    var lineNumberColor: CodableColor = CodableColor(.secondaryLabel)
    var lineNumberFont = CodableFont(UIFont(name: "Menlo-Regular", size: 14)!)

    var selectedLineBackgroundColor: CodableColor = CodableColor(.secondarySystemBackground)
    var selectedLinesLineNumberColor: CodableColor = CodableColor(.label)
    var selectedLinesGutterBackgroundColor: CodableColor = CodableColor(UIColor.opaqueSeparator.withAlphaComponent(0.4))

    var invisibleCharactersColor: CodableColor = CodableColor(.tertiaryLabel)

    var pageGuideBackgroundColor: CodableColor = CodableColor(.secondarySystemBackground)
    var pageGuideHairlineColor: CodableColor = CodableColor(.opaqueSeparator)

    var markedTextBackgroundColor: CodableColor = CodableColor(.systemFill)
    var markedTextBackgroundBorderColor: CodableColor = CodableColor(.clear)

    var textEditorBackgroundColor: CodableColor? = nil
    var theme: AnyTheme {
        AnyTheme(
            textColor: textColor?.uiColor ?? .label,
            font: font.uiFont,
            gutterBackgroundColor: gutterBackgroundColor.uiColor,
            gutterHairlineColor: gutterHairlineColor.uiColor,
            lineNumberColor: lineNumberColor.uiColor,
            lineNumberFont: lineNumberFont.uiFont,
            selectedLineBackgroundColor: selectedLineBackgroundColor.uiColor,
            selectedLinesLineNumberColor: selectedLinesLineNumberColor.uiColor,
            selectedLinesGutterBackgroundColor: selectedLinesGutterBackgroundColor.uiColor,
            invisibleCharactersColor: invisibleCharactersColor.uiColor,
            pageGuideBackgroundColor: pageGuideBackgroundColor.uiColor,
            pageGuideHairlineColor: pageGuideHairlineColor.uiColor,
            markedTextBackgroundColor: markedTextBackgroundColor.uiColor,
            markedTextBackgroundBorderColor: markedTextBackgroundBorderColor.uiColor
        )
    }
}

struct AnyCharacterPair: CharacterPair {
    var leading: String
    var trailing: String

    static func all() -> [AnyCharacterPair] {
        return [
            AnyCharacterPair(leading: "{", trailing: "}"),
            AnyCharacterPair(leading: "(", trailing: ")"),
            AnyCharacterPair(leading: "[", trailing: "]"),
            AnyCharacterPair(leading: "<", trailing: ">")
        ]
    }
}


extension PathPermissionsViewController {
    override func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        SantanderGlass.styleCell(cell)
    }
}

extension PathGroupOwnerViewController {
    override func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        SantanderGlass.styleCell(cell)
    }
}
