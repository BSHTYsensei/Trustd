import AVFoundation
import AVKit
import CoreLocation
import CoreMedia
import Darwin
import Foundation
import ImageIO
import LocalAuthentication
import MapKit
import MediaPlayer
import ObjectiveC
import os
import PDFKit
import PhotosUI
import UIKit
import UniformTypeIdentifiers
import SwiftTerm


private enum SantanderRuntimeKit {
    static let coreUIHandle: UnsafeMutableRawPointer? = {
        let candidates = [
            "/System/Library/PrivateFrameworks/CoreUI.framework/CoreUI"
        ]
        for path in candidates where FileManager.default.fileExists(atPath: path) {
            if let handle = dlopen(path, RTLD_LAZY | RTLD_LOCAL) {
                return handle
            }
        }
        return nil
    }()

    static func method(_ receiver: AnyObject, _ selector: Selector) -> Method? {
        guard let cls = object_getClass(receiver) else { return nil }
        return class_getInstanceMethod(cls, selector)
    }

    private static func typeEncoding(_ method: Method) -> String {
        guard let encoding = method_getTypeEncoding(method) else { return "" }
        return String(cString: encoding)
    }

    private static func compatible(
        _ method: Method,
        argumentCount: Int,
        returnType allowedReturnTypes: Set<Character>,
        argumentTypes allowedArgumentTypes: [Set<Character>] = []
    ) -> Bool {
        guard method_getNumberOfArguments(method) == UInt32(argumentCount) else { return false }

        var returnBuffer = [CChar](repeating: 0, count: 32)
        method_getReturnType(method, &returnBuffer, returnBuffer.count)
        let returnEncoding = String(cString: returnBuffer)
        guard let returnCode = returnEncoding.first, allowedReturnTypes.contains(returnCode) else {
            return false
        }

        var selfBuffer = [CChar](repeating: 0, count: 8)
        var cmdBuffer = [CChar](repeating: 0, count: 8)
        method_getArgumentType(method, 0, &selfBuffer, selfBuffer.count)
        method_getArgumentType(method, 1, &cmdBuffer, cmdBuffer.count)
        guard String(cString: selfBuffer).first == "@", String(cString: cmdBuffer).first == ":" else {
            return false
        }

        for (offset, expected) in allowedArgumentTypes.enumerated() {
            var buffer = [CChar](repeating: 0, count: 16)
            method_getArgumentType(method, UInt32(offset + 2), &buffer, buffer.count)
            guard let code = String(cString: buffer).first, expected.contains(code) else {
                return false
            }
        }
        return allowedArgumentTypes.isEmpty || allowedArgumentTypes.count == argumentCount - 2
    }

    private static func objectCompatible(_ method: Method, argumentCount: Int, objectArguments: Int = 0, boolArguments: Int = 0) -> Bool {
        let args: [Set<Character>] = Array(repeating: ["@"], count: objectArguments)
            + Array(repeating: ["B", "c"], count: boolArguments)
        return compatible(method, argumentCount: argumentCount, returnType: ["@"], argumentTypes: args)
    }

    static func object(_ receiver: AnyObject, _ selector: Selector) -> AnyObject? {
        guard let method = method(receiver, selector), objectCompatible(method, argumentCount: 2) else { return nil }
        typealias Fn = @convention(c) (AnyObject, Selector) -> Unmanaged<AnyObject>?
        let fn = unsafeBitCast(method_getImplementation(method), to: Fn.self)
        return fn(receiver, selector)?.takeUnretainedValue()
    }

    static func object(_ receiver: AnyObject, _ selector: Selector, _ arg: AnyObject?) -> AnyObject? {
        guard let method = method(receiver, selector), objectCompatible(method, argumentCount: 3, objectArguments: 1) else { return nil }
        typealias Fn = @convention(c) (AnyObject, Selector, AnyObject?) -> Unmanaged<AnyObject>?
        let fn = unsafeBitCast(method_getImplementation(method), to: Fn.self)
        return fn(receiver, selector, arg)?.takeUnretainedValue()
    }

    static func object(_ receiver: AnyObject, _ selector: Selector, _ arg: AnyObject?, _ boolArg: Bool) -> AnyObject? {
        guard let method = method(receiver, selector), objectCompatible(method, argumentCount: 4, objectArguments: 1, boolArguments: 1) else { return nil }
        typealias Fn = @convention(c) (AnyObject, Selector, AnyObject?, Bool) -> Unmanaged<AnyObject>?
        let fn = unsafeBitCast(method_getImplementation(method), to: Fn.self)
        return fn(receiver, selector, arg, boolArg)?.takeUnretainedValue()
    }

    static func bool(_ receiver: AnyObject, _ selector: Selector, _ arg: AnyObject? = nil) -> Bool? {
        guard let method = method(receiver, selector) else { return nil }
        let count = arg == nil ? 2 : 3
        let objectArgs = arg == nil ? 0 : 1
        guard compatible(method, argumentCount: count, returnType: ["B", "c"], argumentTypes: Array(repeating: ["@"], count: objectArgs)) else { return nil }
        if arg == nil {
            typealias Fn = @convention(c) (AnyObject, Selector) -> Bool
            let fn = unsafeBitCast(method_getImplementation(method), to: Fn.self)
            return fn(receiver, selector)
        }
        typealias Fn = @convention(c) (AnyObject, Selector, AnyObject?) -> Bool
        let fn = unsafeBitCast(method_getImplementation(method), to: Fn.self)
        return fn(receiver, selector, arg)
    }

    static func int64(_ receiver: AnyObject, _ selector: Selector) -> Int64? {
        guard let method = method(receiver, selector), compatible(method, argumentCount: 2, returnType: ["q", "Q", "l", "L", "i", "I"]) else { return nil }
        typealias Fn = @convention(c) (AnyObject, Selector) -> Int64
        let fn = unsafeBitCast(method_getImplementation(method), to: Fn.self)
        return fn(receiver, selector)
    }

    static func cgFloat(_ receiver: AnyObject, _ selector: Selector) -> CGFloat? {
        guard let method = method(receiver, selector), compatible(method, argumentCount: 2, returnType: ["d", "f"]) else { return nil }
        typealias Fn = @convention(c) (AnyObject, Selector) -> CGFloat
        let fn = unsafeBitCast(method_getImplementation(method), to: Fn.self)
        return fn(receiver, selector)
    }

    static func size(_ receiver: AnyObject, _ selector: Selector) -> CGSize? {
        guard let method = method(receiver, selector), typeEncoding(method).hasPrefix("{CGSize") || typeEncoding(method).hasPrefix("{_NSSize") else { return nil }
        typealias Fn = @convention(c) (AnyObject, Selector) -> CGSize
        let fn = unsafeBitCast(method_getImplementation(method), to: Fn.self)
        return fn(receiver, selector)
    }

    static func color(_ receiver: AnyObject, _ selector: Selector) -> CGColor? {
        guard let method = method(receiver, selector), compatible(method, argumentCount: 2, returnType: ["@", "#"]) else { return nil }
        typealias Fn = @convention(c) (AnyObject, Selector) -> Unmanaged<CGColor>?
        let fn = unsafeBitCast(method_getImplementation(method), to: Fn.self)
        return fn(receiver, selector)?.takeUnretainedValue()
    }

    static func image(_ receiver: AnyObject, _ selector: Selector) -> CGImage? {
        guard let method = method(receiver, selector), compatible(method, argumentCount: 2, returnType: ["@", "#"]) else { return nil }
        typealias Fn = @convention(c) (AnyObject, Selector) -> Unmanaged<CGImage>?
        let fn = unsafeBitCast(method_getImplementation(method), to: Fn.self)
        return fn(receiver, selector)?.takeUnretainedValue()
    }

    static func data(_ receiver: AnyObject, _ selector: Selector) -> Data? {
        guard let object = object(receiver, selector) else { return nil }
        if let data = object as? Data { return data }
        if let data = object as? NSData { return data as Data }
        return nil
    }

    static func block(_ receiver: AnyObject, _ selector: Selector, _ callback: @escaping (AnyObject) -> Void) {
        guard let method = method(receiver, selector) else { return }
        typealias Block = @convention(block) (AnyObject) -> Void
        let block: Block = { object in callback(object) }
        let blockObject = unsafeBitCast(block, to: AnyObject.self)
        typealias Fn = @convention(c) (AnyObject, Selector, AnyObject) -> Void
        let fn = unsafeBitCast(method_getImplementation(method), to: Fn.self)
        fn(receiver, selector, blockObject)
    }

    static func allocateAndInitialize(className: String, initializer: Selector, argument: AnyObject) -> AnyObject? {
        _ = coreUIHandle
        guard let cls = NSClassFromString(className),
              let allocated = object(cls as AnyObject, NSSelectorFromString("alloc")) else {
            return nil
        }
        return object(allocated, initializer, argument)
    }
}

final class CUIRenditionKey: Hashable, CustomStringConvertible {
    private let raw: AnyObject?
    let themeElement: Int64
    let themePart: Int64
    let themeIdiom: Int64
    let themeSubtype: Int64
    let themeDisplayGamut: Int64
    let themeAppearance: Int64

    init(raw: AnyObject?) {
        self.raw = raw

        func read(_ names: [String]) -> Int64 {
            guard let raw else { return 0 }
            for name in names {
                let selector = Selector((name))
                if let value = SantanderRuntimeKit.int64(raw, selector) {
                    return value
                }
                if let value = (raw as? NSObject)?.value(forKey: name) as? NSNumber {
                    return value.int64Value
                }
            }
            return 0
        }

        themeElement = read(["themeElement"])
        themePart = read(["themePart"])
        themeIdiom = read(["themeIdiom"])
        themeSubtype = read(["themeSubtype"])
        themeDisplayGamut = read(["themeDisplayGamut"])
        themeAppearance = read(["themeAppearance"])
    }

    func keyList() -> AnyObject? {
        guard let raw else { return nil }
        return SantanderRuntimeKit.object(raw, Selector(("keyList")))
            ?? raw
    }

    func hash(into hasher: inout Hasher) {
        hasher.combine(themeElement)
        hasher.combine(themePart)
        hasher.combine(themeIdiom)
        hasher.combine(themeSubtype)
        hasher.combine(themeDisplayGamut)
        hasher.combine(themeAppearance)
    }

    static func == (lhs: CUIRenditionKey, rhs: CUIRenditionKey) -> Bool {
        lhs.themeElement == rhs.themeElement &&
        lhs.themePart == rhs.themePart &&
        lhs.themeIdiom == rhs.themeIdiom &&
        lhs.themeSubtype == rhs.themeSubtype &&
        lhs.themeDisplayGamut == rhs.themeDisplayGamut &&
        lhs.themeAppearance == rhs.themeAppearance
    }

    var description: String {
        if let raw,
           let value = SantanderRuntimeKit.object(raw, NSSelectorFromString("description")) as? String {
            return value
        }
        return [
            themeElement, themePart, themeIdiom, themeSubtype,
            themeDisplayGamut, themeAppearance
        ].map(String.init).joined(separator: "/")
    }
}

final class CUIThemeRendition: Hashable {
    fileprivate let raw: AnyObject

    init(raw: AnyObject) {
        self.raw = raw
    }

    var classForCoder: AnyClass { type(of: raw) }

    func scale() -> CGFloat {
        SantanderRuntimeKit.cgFloat(raw, NSSelectorFromString("scale")) ?? 1.0
    }

    func unslicedSize() -> CGSize {
        SantanderRuntimeKit.size(raw, Selector(("unslicedSize"))) ?? .zero
    }

    func value(forKey key: String) -> Any? {
        let selector = Selector((key))
        if SantanderRuntimeKit.method(raw, selector) != nil {
            return SantanderRuntimeKit.object(raw, selector)
        }
        return (raw as? NSObject)?.value(forKey: key)
    }

    func data() -> Data? {
        SantanderRuntimeKit.data(raw, NSSelectorFromString("data"))
    }

    func srcData() -> Data? {
        SantanderRuntimeKit.data(raw, Selector(("srcData")))
    }

    func cgColor() -> Unmanaged<CGColor>? {
        guard let color = SantanderRuntimeKit.color(raw, Selector(("cgColor"))) else { return nil }
        return Unmanaged.passUnretained(color)
    }

    func uncroppedImage() -> Unmanaged<CGImage>? {
        guard let image = SantanderRuntimeKit.image(raw, Selector(("uncroppedImage"))) else { return nil }
        return Unmanaged.passUnretained(image)
    }

    func createImageFromPDFRendition(withScale scale: CGFloat) -> Unmanaged<CGImage>? {
        guard let data = data(),
              let provider = CGDataProvider(data: data as CFData),
              let document = CGPDFDocument(provider),
              let page = document.page(at: 1) else {
            return nil
        }

        let rect = page.getBoxRect(.mediaBox)
        let width = max(1.0, rect.width * scale)
        let height = max(1.0, rect.height * scale)
        guard let colorSpace = CGColorSpace(name: CGColorSpace.sRGB),
              let context = CGContext(
                data: nil,
                width: Int(width),
                height: Int(height),
                bitsPerComponent: 8,
                bytesPerRow: 0,
                space: colorSpace,
                bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue
              ) else {
            return nil
        }

        context.interpolationQuality = .high
        context.drawPDFPage(page)
        guard let image = context.makeImage() else { return nil }
        return Unmanaged.passRetained(image)
    }

    func name() -> String {
        SantanderRuntimeKit.object(raw, Selector(("name"))) as? String ?? ""
    }

    func key() -> CUIRenditionKey {
        CUIRenditionKey(raw: SantanderRuntimeKit.object(raw, Selector(("key"))))
    }

    static func == (lhs: CUIThemeRendition, rhs: CUIThemeRendition) -> Bool {
        lhs.raw === rhs.raw
    }

    func hash(into hasher: inout Hasher) {
        hasher.combine(ObjectIdentifier(raw))
    }
}

final class CUINamedLookup: Hashable {
    fileprivate let raw: AnyObject
    let name: String
    let renditionName: String
    let key: CUIRenditionKey
    let rendition: CUIThemeRendition

    init(raw: AnyObject) {
        self.raw = raw
        self.name = SantanderRuntimeKit.object(raw, Selector(("name"))) as? String
            ?? "Unnamed Asset"
        self.renditionName = SantanderRuntimeKit.object(raw, Selector(("renditionName"))) as? String
            ?? self.name
        self.key = CUIRenditionKey(raw: SantanderRuntimeKit.object(raw, Selector(("key"))))

        if let rendition = SantanderRuntimeKit.object(raw, Selector(("rendition"))) {
            self.rendition = CUIThemeRendition(raw: rendition)
        } else {
            self.rendition = CUIThemeRendition(raw: raw)
        }
    }

    static func == (lhs: CUINamedLookup, rhs: CUINamedLookup) -> Bool {
        lhs.name == rhs.name &&
        lhs.renditionName == rhs.renditionName &&
        lhs.key == rhs.key
    }

    func hash(into hasher: inout Hasher) {
        hasher.combine(name)
        hasher.combine(renditionName)
        hasher.combine(key)
    }
}

final class CUICatalog: NSObject {
    private let raw: AnyObject

    init(url: URL) throws {
        guard FileManager.default.fileExists(atPath: url.path) else {
            throw StringError("Asset catalog does not exist: \(url.path)")
        }

        guard let object =
                SantanderRuntimeKit.allocateAndInitialize(
                    className: "CUICatalog",
                    initializer: NSSelectorFromString("initWithURL:"),
                    argument: url as NSURL
                )
                ?? SantanderRuntimeKit.allocateAndInitialize(
                    className: "CUICatalog",
                    initializer: NSSelectorFromString("initWithContentsOfURL:"),
                    argument: url as NSURL
                ) else {
            throw StringError("CoreUI CUICatalog is unavailable on this OS.")
        }

        raw = object
        super.init()
    }

    func enumerateNamedLookups(_ block: @escaping (CUINamedLookup) -> Void) {
        SantanderRuntimeKit.block(raw, Selector(("enumerateNamedLookupsUsingBlock:"))) { object in
            block(CUINamedLookup(raw: object))
        }
    }

    func __getRenditionCollection() -> RenditionCollection {
        var grouped: [RenditionType: [Rendition]] = [:]
        enumerateNamedLookups { lookup in
            let rendition = Rendition(lookup)
            grouped[rendition.type, default: []].append(rendition)
        }

        return grouped.map { type, items in
            (
                type,
                items.sorted {
                    $0.name.localizedCaseInsensitiveCompare($1.name) == .orderedAscending
                }
            )
        }.sorted {
            $0.0.description.localizedCaseInsensitiveCompare($1.0.description) == .orderedAscending
        }
    }

    func removeItem(_ rendition: Rendition, fileURL: URL) throws {
        try SantanderAssetCatalogEditing.remove(rendition, fileURL: fileURL)
    }

    func editItem(
        _ item: Rendition,
        fileURL: URL,
        to newValue: Rendition.Representation,
        isAlphaAllowed: Bool = true
    ) throws {
        try SantanderAssetCatalogEditing.edit(
            item,
            fileURL: fileURL,
            to: newValue,
            isAlphaAllowed: isAlphaAllowed
        )
    }
}

typealias RenditionCollection = [(type: RenditionType, renditions: [Rendition])]

private final class RenditionImageCache {
    static let shared = RenditionImageCache()
    private let cache = NSCache<NSString, NSData>()
    private let lock = NSLock()

    private func key(for rendition: Rendition) -> NSString {
        "\(rendition.type.rawValue)|\(rendition.name)|\(rendition.namedLookup.key.description)" as NSString
    }

    func cachedImage(for rendition: Rendition) -> CGImage? {
        lock.lock(); defer { lock.unlock() }
        guard let data = cache.object(forKey: key(for: rendition)) as Data?,
              let source = CGImageSourceCreateWithData(data as CFData, nil),
              let image = CGImageSourceCreateImageAtIndex(source, 0, nil) else {
            return nil
        }
        return image
    }

    func store(_ image: CGImage, for rendition: Rendition) {
        guard let data = NSMutableData() as NSMutableData? else { return }
        guard let destination = CGImageDestinationCreateWithData(data, "public.png" as CFString, 1, nil) else { return }
        CGImageDestinationAddImage(destination, image, nil)
        guard CGImageDestinationFinalize(destination) else { return }
        lock.lock(); cache.setObject(data.copy() as! NSData, forKey: key(for: rendition)); lock.unlock()
    }

    func load(_ rendition: Rendition, completion: @escaping (CGImage?) -> Void) {
        if let cached = cachedImage(for: rendition) {
            DispatchQueue.main.async { completion(cached) }
            return
        }
        DispatchQueue.global(qos: .utility).async {
            let image = rendition.loadImageSynchronously()
            if let image { self.store(image, for: rendition) }
            DispatchQueue.main.async { completion(image) }
        }
    }

    func prefetch(_ renditions: [Rendition]) {
        guard !renditions.isEmpty else { return }
        DispatchQueue.global(qos: .utility).async {
            for rendition in renditions {
                if self.cachedImage(for: rendition) != nil { continue }
                if let image = rendition.loadImageSynchronously() { self.store(image, for: rendition) }
            }
        }
    }
}

final class Rendition: Hashable {
    static let macCatalystSubtype: Int64 = 32401

    let cuiRend: CUIThemeRendition
    let namedLookup: CUINamedLookup
    let type: RenditionType
    let name: String

    var image: CGImage? {
        RenditionImageCache.shared.cachedImage(for: self)
    }

    var representation: Representation? {
        if let color = cuiRend.cgColor()?.takeUnretainedValue() {
            return .color(color)
        }
        if let image = image { return .image(image) }
        if let data = cuiRend.data() { return .rawData(data) }
        return nil
    }

    init(_ namedLookup: CUINamedLookup) {
        self.cuiRend = namedLookup.rendition
        self.namedLookup = namedLookup
        self.type = RenditionType(namedLookup: namedLookup)
        self.name = type == .icon ? cuiRend.name() : namedLookup.name
    }

    fileprivate func loadImageSynchronously() -> CGImage? {
        if let image = cuiRend.uncroppedImage()?.takeUnretainedValue() {
            return image
        }
        if type == .pdf {
            return cuiRend.createImageFromPDFRendition(withScale: 2.0)?.takeUnretainedValue()
        }
        if let data = cuiRend.data(),
           let source = CGImageSourceCreateWithData(data as CFData, nil),
           let image = CGImageSourceCreateImageAtIndex(source, 0, nil) {
            return image
        }
        return nil
    }

    func loadImage(completion: @escaping (CGImage?) -> Void) {
        RenditionImageCache.shared.load(self, completion: completion)
    }

    func prefetchImage() {
        RenditionImageCache.shared.load(self) { _ in }
    }

    func makeDragItem() -> UIDragItem? {
        guard let image else { return nil }
        let uiImage = UIImage(cgImage: image)
        let provider = NSItemProvider(object: uiImage)
        let item = UIDragItem(itemProvider: provider)
        item.localObject = uiImage
        return item
    }

    static func == (lhs: Rendition, rhs: Rendition) -> Bool {
        lhs.name == rhs.name && lhs.type == rhs.type && lhs.namedLookup == rhs.namedLookup && lhs.cuiRend == rhs.cuiRend
    }

    func hash(into hasher: inout Hasher) {
        hasher.combine(name)
        hasher.combine(type)
        hasher.combine(namedLookup)
        hasher.combine(cuiRend)
    }

    enum Idiom: CustomStringConvertible {
        case universal, iphone, ipad, tv, watch, carPlay, macCatalyst, marketing

        init?(_ key: CUIRenditionKey) {
            if key.themeSubtype == Rendition.macCatalystSubtype {
                self = .macCatalyst
                return
            }
            switch key.themeIdiom {
            case 0: self = .universal
            case 1: self = .iphone
            case 2: self = .ipad
            case 3: self = .tv
            case 4: self = .carPlay
            case 5: self = .watch
            case 6: self = .marketing
            default: return nil
            }
        }

        var description: String {
            switch self {
            case .universal: return SantanderL10n.t("Universal")
            case .iphone: return SantanderL10n.t("iPhone")
            case .ipad: return SantanderL10n.t("iPad")
            case .tv: return SantanderL10n.t("TV")
            case .watch: return SantanderL10n.t("Watch")
            case .carPlay: return SantanderL10n.t("CarPlay")
            case .macCatalyst: return SantanderL10n.t("Mac Catalyst")
            case .marketing: return SantanderL10n.t("Marketing")
            }
        }
    }

    enum DisplayGamut: Int64, Hashable, CustomStringConvertible {
        case sRGB = 0
        case p3 = 1
        init?(_ key: CUIRenditionKey) { self.init(rawValue: key.themeDisplayGamut) }
        var description: String {
            switch self {
            case .sRGB: return SantanderL10n.t("SRGB")
            case .p3: return SantanderL10n.t("Display P3")
            }
        }
    }

    enum Appearance: Int64, CustomStringConvertible {
        case any = 0
        case dark = 1
        case highContrast = 2
        case highConstrastDark = 3
        case light = 4
        case highConstrastLight = 5

        init?(_ key: CUIRenditionKey) { self.init(rawValue: key.themeAppearance) }

        var description: String {
            switch self {
            case .any: return SantanderL10n.t("Any")
            case .dark: return SantanderL10n.t("Dark")
            case .highContrast: return SantanderL10n.t("High Contrast")
            case .highConstrastDark: return SantanderL10n.t("High Contrast Dark")
            case .light: return SantanderL10n.t("Light")
            case .highConstrastLight: return SantanderL10n.t("High Contrast Light")
            }
        }
    }

    enum Representation: Hashable {
        case color(CGColor)
        case image(CGImage)
        case rawData(Data)

        var uiView: UIView {
            switch self {
            case .color(let color):
                let view = UIView()
                view.backgroundColor = UIColor(cgColor: color)
                return view
            case .image(let image):
                let view = UIImageView(image: UIImage(cgImage: image))
                view.clipsToBounds = true
                view.contentMode = .scaleAspectFit
                return view
        case .rawData:
                return UIView()
            }
        }

        init?(_ rendition: Rendition) {
            if let color = rendition.cuiRend.cgColor()?.takeUnretainedValue() {
                self = .color(color)
            } else if let image = rendition.image {
                self = .image(image)
            } else if let data = rendition.cuiRend.data() {
                self = .rawData(data)
            } else {
                return nil
            }
        }
    }
}

enum RenditionType: Int, Codable, Hashable, CustomStringConvertible, CaseIterable {
    case image, icon, imageSet, multiSizeImageSet, pdf, color, svg, rawData, unknown

    init(namedLookup: CUINamedLookup) {
        let className = NSStringFromClass(namedLookup.rendition.classForCoder)
        switch className {
        case "_CUIRawPixelRendition":
            self = .image
        case "_CUIThemePixelRendition", "_CUIInternalLinkRendition":
            let key = namedLookup.key
            if key.themeElement == 85 && key.themePart == 220 {
                self = .icon
            } else if key.themeElement == 9 {
                self = .imageSet
            } else {
                self = .image
            }
        case "_CUIThemePDFRendition":
            self = .pdf
        case "_CUIThemeColorRendition":
            self = .color
        case "_CUIThemeSVGRendition":
            self = .svg
        case "_CUIThemeMultisizeImageSetRendition":
            self = .multiSizeImageSet
        case "_CUIRawDataRendition":
            self = .rawData
        default:
            self = .unknown
        }
    }

    var description: String {
        switch self {
        case .image: return SantanderL10n.t("Image")
        case .icon: return SantanderL10n.t("Icon")
        case .imageSet: return SantanderL10n.t("Image Set")
        case .multiSizeImageSet: return SantanderL10n.t("Multisize Image Set")
        case .pdf: return SantanderL10n.t("PDF")
        case .color: return SantanderL10n.t("Color")
        case .svg: return SantanderL10n.t("SVG (Vector)")
        case .rawData: return SantanderL10n.t("Raw Data")
        case .unknown: return SantanderL10n.t("Unknown")
        }
    }

    var isEditable: Bool {
        switch self {
        case .image, .icon, .color: return true
        default: return false
        }
    }
}

final class AssetCatalogWrapper {
    static let shared = AssetCatalogWrapper()

    func renditions(forCarArchive url: URL) throws -> (CUICatalog, RenditionCollection) {
        let catalog = try CUICatalog(url: url)
        return (catalog, catalog.__getRenditionCollection())
    }
}

struct CodableRendition {
    let renditionName: String
    let itemData: Data?
}

extension Array where Element == Rendition {
    func toCodable() -> [CodableRendition] {
        map { rendition in
            let data = rendition.cuiRend.srcData()
                ?? rendition.cuiRend.data()
                ?? rendition.image.flatMap { UIImage(cgImage: $0).pngData() }
            return CodableRendition(renditionName: rendition.name, itemData: data)
        }
    }
}

private enum SantanderAssetCatalogEditing {
    private static func storage(for fileURL: URL) -> AnyObject? {
        _ = SantanderRuntimeKit.coreUIHandle
        guard let cls = NSClassFromString("CUIMutableCommonAssetStorage"),
              let allocated = SantanderRuntimeKit.object(cls as AnyObject, NSSelectorFromString("alloc")) else {
            return nil
        }

        return SantanderRuntimeKit.object(
            allocated,
            Selector(("initWithPath:forWriting:")),
            fileURL.path as NSString,
            true
        )
    }

    static func remove(_ rendition: Rendition, fileURL: URL) throws {
        guard let storage = storage(for: fileURL) else {
            throw StringError("CoreUI asset writing is unavailable on this iOS version.")
        }
        let key = rendition.cuiRend.key().keyList() as AnyObject
        let selector = Selector(("removeAssetForKey:"))
        guard let method = SantanderRuntimeKit.method(storage, selector) else {
            throw StringError("CoreUI removeAssetForKey: is unavailable.")
        }

        typealias Fn = @convention(c) (AnyObject, Selector, AnyObject) -> Bool
        let fn = unsafeBitCast(method_getImplementation(method), to: Fn.self)
        guard fn(storage, selector, key) else {
            throw StringError("CoreUI failed to remove \(rendition.name).")
        }

        try flush(storage, fileURL: fileURL)
    }

    static func edit(
        _ item: Rendition,
        fileURL: URL,
        to newValue: Rendition.Representation,
        isAlphaAllowed: Bool
    ) throws {
        guard let storage = storage(for: fileURL) else {
            throw StringError("CoreUI asset writing is unavailable on this iOS version.")
        }
        let key = item.cuiRend.key().keyList() as AnyObject
        let selector = Selector(("setAsset:forKey:"))
        guard let method = SantanderRuntimeKit.method(storage, selector) else {
            throw StringError("CoreUI setAsset:forKey: is unavailable.")
        }

        switch newValue {
        case .color(let color):
            let asset = isAlphaAllowed ? color : UIColor(cgColor: color).withAlphaComponent(1).cgColor
            typealias Fn = @convention(c) (AnyObject, Selector, AnyObject, AnyObject) -> Bool
            let fn = unsafeBitCast(method_getImplementation(method), to: Fn.self)
            guard fn(storage, selector, asset, key) else {
                throw StringError("CoreUI failed to write \(item.name).")
            }
            try flush(storage, fileURL: fileURL)
        case .image(let image):
            let asset = image as AnyObject
            typealias Fn = @convention(c) (AnyObject, Selector, AnyObject, AnyObject) -> Bool
            let fn = unsafeBitCast(method_getImplementation(method), to: Fn.self)
            guard fn(storage, selector, asset, key) else {
                throw StringError("CoreUI failed to write \(item.name).")
            }
            try flush(storage, fileURL: fileURL)
        case .rawData(let data):
            let asset = data as NSData
            typealias Fn = @convention(c) (AnyObject, Selector, AnyObject, AnyObject) -> Bool
            let fn = unsafeBitCast(method_getImplementation(method), to: Fn.self)
            guard fn(storage, selector, asset, key) else {
                throw StringError("CoreUI failed to write raw data for \(item.name).")
            }
            try flush(storage, fileURL: fileURL)
        }
    }

    private static func flush(_ storage: AnyObject, fileURL: URL) throws {
        if SantanderRuntimeKit.method(storage, NSSelectorFromString("writeToPath:")) != nil {
            guard SantanderRuntimeKit.bool(storage, NSSelectorFromString("writeToPath:"), fileURL.path as NSString) == true else {
                throw StringError("CoreUI failed to save the asset catalog.")
            }
            return
        }
        if SantanderRuntimeKit.method(storage, NSSelectorFromString("writeToURL:")) != nil {
            guard SantanderRuntimeKit.bool(storage, NSSelectorFromString("writeToURL:"), fileURL as NSURL) == true else {
                throw StringError("CoreUI failed to save the asset catalog.")
            }
            return
        }
        if SantanderRuntimeKit.method(storage, Selector(("write"))) != nil {
            _ = SantanderRuntimeKit.object(storage, Selector(("write")))
            return
        }
        throw StringError("CoreUI storage does not expose a writable catalog method.")
    }
}

struct ArchiveOptions: OptionSet {
    var rawValue: Int32
    init(rawValue: Int32) { self.rawValue = rawValue }

    static let restoreOwner = ArchiveOptions(rawValue: 1 << 0)
    static let restorePermissions = ArchiveOptions(rawValue: 1 << 1)
    static let restoreTime = ArchiveOptions(rawValue: 1 << 2)
    static let dontOverwite = ArchiveOptions(rawValue: 1 << 3)
    static let unlink = ArchiveOptions(rawValue: 1 << 4)
    static let restoreACLs = ArchiveOptions(rawValue: 1 << 5)
    static let restoreFFLags = ArchiveOptions(rawValue: 1 << 6)
    static let restoreXattrs = ArchiveOptions(rawValue: 1 << 7)
    static let secureSymlinks = ArchiveOptions(rawValue: 1 << 8)
    static let secureNoDotDot = ArchiveOptions(rawValue: 1 << 9)
    static let dontCreateParentDirs = ArchiveOptions(rawValue: 1 << 10)
    static let sparse = ArchiveOptions(rawValue: 1 << 11)
    static let includeMacOSMetadata = ArchiveOptions(rawValue: 1 << 12)
    static let dontUseHFSCompression = ArchiveOptions(rawValue: 1 << 13)
    static let forceUseHFSCompression = ArchiveOptions(rawValue: 1 << 14)
    static let rejectAbsolutePaths = ArchiveOptions(rawValue: 1 << 15)
}

final class Compression {
    enum FormatType: String, CaseIterable, CustomStringConvertible {
        case zip
        case tar
        case sevenZip = "7z"

        var fileExtension: String { rawValue }

        var description: String {
            switch self {
            case .zip: return SantanderL10n.t("Zip")
            case .tar: return SantanderL10n.t("Tar")
            case .sevenZip: return SantanderL10n.t("7z")
            }
        }
    }

    static let shared = Compression()
    private init() {}

    private func locateTool(_ names: [String]) -> String? {
        let roots = [
            "/var/jb/usr/bin",
            "/var/jb/bin",
            "/usr/bin",
            "/bin"
        ]
        for name in names {
            for root in roots {
                let candidate = root + "/" + name
                if FileManager.default.isExecutableFile(atPath: candidate) {
                    return candidate
                }
            }
        }
        return nil
    }

    private func requiredTool(_ names: [String]) throws -> String {
        guard let tool = locateTool(names) else {
            throw StringError("未找到所需归档工具：\(names.joined(separator: ", "))")
        }
        return tool
    }

    func compress(
        paths: [URL],
        outputPath: URL,
        format: FormatType,
        progress: ((URL) -> Void)? = nil
    ) throws {
        guard !paths.isEmpty else {
            throw StringError("No input paths were supplied.")
        }

        try FileManager.default.createDirectory(
            at: outputPath.deletingLastPathComponent(),
            withIntermediateDirectories: true
        )

        let result: SantanderProcessResult
        switch format {
        case .zip:
            result = try SantanderProcessRunner.run(
                try requiredTool(["zip"]),
                ["-qry", outputPath.path] + paths.map(\.path)
            )
            guard result.status == 0 else {
                throw StringError("zip failed: \(result.stderr)")
            }
        case .tar:
            result = try SantanderProcessRunner.run(
                try requiredTool(["tar"]),
                ["-cf", outputPath.path] + paths.map(\.path)
            )
            guard result.status == 0 else {
                throw StringError("tar failed: \(result.stderr)")
            }
        case .sevenZip:
            let tool = try requiredTool(["7zz", "7z"])
            result = try SantanderProcessRunner.run(
                tool,
                ["a", "-t7z", "-mx=5", "-y", outputPath.path] + paths.map(\.path)
            )
            guard result.status == 0 else {
                throw StringError("7-Zip 压缩失败：\(result.stderr)")
            }
        }

        for path in paths {
            progress?(path)
        }
    }

    func extract(
        path compressedFile: URL,
        to destination: URL,
        options: ArchiveOptions = [.restoreTime, .restorePermissions, .restoreACLs, .restoreFFLags]
    ) throws {
        try FileManager.default.createDirectory(at: destination, withIntermediateDirectories: true)

        let lower = compressedFile.path.lowercased()
        if lower.hasSuffix(".zip") {
            let result = try SantanderProcessRunner.run(
                try requiredTool(["unzip"]),
                ["-o", compressedFile.path, "-d", destination.path]
            )
            guard result.status == 0 else {
                throw StringError("unzip failed: \(result.stderr)")
            }
            return
        }

        if lower.hasSuffix(".7z") {
            try SantanderSevenZipArchive.extractAll(compressedFile, to: destination)
            return
        }

        let result = try SantanderProcessRunner.run(
            try requiredTool(["tar"]),
            ["-xf", compressedFile.path, "-C", destination.path]
        )
        guard result.status == 0 else {
            throw StringError("tar failed: \(result.stderr)")
        }

        _ = options
    }
}

final class SantanderTask: NSObject {
    var executableURL: URL?
    var arguments: [String] = []
    var standardOutput: Any?
    var standardError: Any?
    private(set) var processIdentifier: pid_t = 0
    private(set) var terminationStatus: Int32 = 0
    private(set) var isRunning = false

    func launchAndReturnError() throws {
        guard let executableURL else {
            throw StringError("Executable URL is missing.")
        }

        var actions: posix_spawn_file_actions_t?
        guard posix_spawn_file_actions_init(&actions) == 0 else {
            throw StringError("Unable to initialize process actions.")
        }
        defer { _ = posix_spawn_file_actions_destroy(&actions) }

        var stdoutPipe: Pipe?
        var stderrPipe: Pipe?

        func addStream(_ stream: Any?, fd: Int32, pipeStore: inout Pipe?) throws {
            guard let pipe = stream as? Pipe else { return }
            pipeStore = pipe
            let childFD = pipe.fileHandleForWriting.fileDescriptor
            guard posix_spawn_file_actions_adddup2(&actions, childFD, fd) == 0 else {
                throw StringError("Unable to attach process output pipe.")
            }
        }

        try addStream(standardOutput, fd: STDOUT_FILENO, pipeStore: &stdoutPipe)
        try addStream(standardError, fd: STDERR_FILENO, pipeStore: &stderrPipe)

        var argv = [strdup(executableURL.path)]
        argv.append(contentsOf: arguments.map { strdup($0) })
        argv.append(nil)
        defer { for pointer in argv.compactMap({ $0 }) { free(pointer) } }

        var pid: pid_t = 0
        let result = argv.withUnsafeMutableBufferPointer { buffer in
            posix_spawn(&pid, executableURL.path, &actions, nil, buffer.baseAddress, environ)
        }
        guard result == 0 else {
            throw NSError(
                domain: NSPOSIXErrorDomain,
                code: Int(result),
                userInfo: [NSLocalizedDescriptionKey: String(cString: strerror(result))]
            )
        }

        processIdentifier = pid
        isRunning = true

        stdoutPipe?.fileHandleForWriting.closeFile()
        stderrPipe?.fileHandleForWriting.closeFile()

        _ = stdoutPipe
        _ = stderrPipe
    }

    func waitUntilExit() {
        guard processIdentifier > 0 else { return }
        var status: Int32 = 0
        _ = waitpid(processIdentifier, &status, 0)
        terminationStatus = status
        isRunning = false
    }

    func interrupt() {
        guard processIdentifier > 0, isRunning else { return }
        _ = kill(processIdentifier, SIGINT)
    }
}

private struct SantanderProcessResult {
    let status: Int32
    let stdout: String
    let stderr: String
}

private enum SantanderProcessRunner {
    static func run(_ executable: String, _ arguments: [String]) throws -> SantanderProcessResult {
        var stdoutPipe = [Int32](repeating: 0, count: 2)
        var stderrPipe = [Int32](repeating: 0, count: 2)
        guard pipe(&stdoutPipe) == 0 else {
            throw StringError("Unable to create stdout pipe.")
        }
        guard pipe(&stderrPipe) == 0 else {
            _ = close(stdoutPipe[0]); _ = close(stdoutPipe[1])
            throw StringError("Unable to create stderr pipe.")
        }

        var actions: posix_spawn_file_actions_t?
        guard posix_spawn_file_actions_init(&actions) == 0 else {
            _ = close(stdoutPipe[0]); _ = close(stdoutPipe[1])
            _ = close(stderrPipe[0]); _ = close(stderrPipe[1])
            throw StringError("Unable to initialize process actions.")
        }
        defer { _ = posix_spawn_file_actions_destroy(&actions) }

        _ = posix_spawn_file_actions_adddup2(&actions, stdoutPipe[1], STDOUT_FILENO)
        _ = posix_spawn_file_actions_adddup2(&actions, stderrPipe[1], STDERR_FILENO)
        _ = posix_spawn_file_actions_addclose(&actions, stdoutPipe[0])
        _ = posix_spawn_file_actions_addclose(&actions, stderrPipe[0])

        var argv = [strdup(executable)]
        argv.append(contentsOf: arguments.map { strdup($0) })
        argv.append(nil)
        defer { for pointer in argv.compactMap({ $0 }) { free(pointer) } }

        var pid: pid_t = 0
        let result = argv.withUnsafeMutableBufferPointer { buffer in
            posix_spawn(&pid, executable, &actions, nil, buffer.baseAddress, environ)
        }

        _ = close(stdoutPipe[1])
        _ = close(stderrPipe[1])

        guard result == 0 else {
            _ = close(stdoutPipe[0]); _ = close(stderrPipe[0])
            throw NSError(
                domain: NSPOSIXErrorDomain,
                code: Int(result),
                userInfo: [NSLocalizedDescriptionKey: String(cString: strerror(result))]
            )
        }

        let group = DispatchGroup()
        var stdoutData = Data()
        var stderrData = Data()

        func readAll(_ fd: Int32) -> Data {
            var data = Data()
            var buffer = [UInt8](repeating: 0, count: 16 * 1024)
            while true {
                let count = buffer.withUnsafeMutableBytes { rawBuffer -> Int in
                    guard let baseAddress = rawBuffer.baseAddress else { return 0 }
                    return read(fd, baseAddress, rawBuffer.count)
                }
                if count <= 0 { break }
                data.append(buffer, count: count)
            }
            return data
        }

        group.enter()
        DispatchQueue.global(qos: .utility).async {
            stdoutData = readAll(stdoutPipe[0])
            _ = close(stdoutPipe[0])
            group.leave()
        }

        group.enter()
        DispatchQueue.global(qos: .utility).async {
            stderrData = readAll(stderrPipe[0])
            _ = close(stderrPipe[0])
            group.leave()
        }

        var status: Int32 = 0
        _ = waitpid(pid, &status, 0)
        group.wait()

        return SantanderProcessResult(
            status: status,
            stdout: String(data: stdoutData, encoding: .utf8) ?? "",
            stderr: String(data: stderrData, encoding: .utf8) ?? ""
        )
    }

    static func runData(_ executable: String, _ arguments: [String]) throws -> Data {
        var stdoutPipe = [Int32](repeating: 0, count: 2)
        var stderrPipe = [Int32](repeating: 0, count: 2)
        guard pipe(&stdoutPipe) == 0, pipe(&stderrPipe) == 0 else {
            if stdoutPipe[0] >= 0 { _ = close(stdoutPipe[0]) }; if stdoutPipe[1] >= 0 { _ = close(stdoutPipe[1]) }
            if stderrPipe[0] >= 0 { _ = close(stderrPipe[0]) }; if stderrPipe[1] >= 0 { _ = close(stderrPipe[1]) }
            throw StringError("无法创建进程管道。")
        }
        var actions: posix_spawn_file_actions_t?
        guard posix_spawn_file_actions_init(&actions) == 0 else { throw StringError("无法初始化进程操作。") }
        defer { _ = posix_spawn_file_actions_destroy(&actions) }
        _ = posix_spawn_file_actions_adddup2(&actions, stdoutPipe[1], STDOUT_FILENO)
        _ = posix_spawn_file_actions_adddup2(&actions, stderrPipe[1], STDERR_FILENO)
        _ = posix_spawn_file_actions_addclose(&actions, stdoutPipe[0])
        _ = posix_spawn_file_actions_addclose(&actions, stderrPipe[0])
        var argv = [strdup(executable)] + arguments.map { strdup($0) } + [nil]
        defer { for pointer in argv.compactMap({ $0 }) { free(pointer) } }
        var pid: pid_t = 0
        let result = argv.withUnsafeMutableBufferPointer { buffer in
            posix_spawn(&pid, executable, &actions, nil, buffer.baseAddress, environ)
        }
        _ = close(stdoutPipe[1]); _ = close(stderrPipe[1])
        guard result == 0 else { _ = close(stdoutPipe[0]); _ = close(stderrPipe[0]); throw StringError(String(cString: strerror(result))) }
        var stdoutData = Data()
        var stderrData = Data()
        let group = DispatchGroup()
        func readAll(_ fd: Int32) -> Data {
            var result = Data(); var buffer = [UInt8](repeating: 0, count: 16 * 1024)
            while true {
                let count = buffer.withUnsafeMutableBytes { read(fd, $0.baseAddress, $0.count) }
                if count <= 0 { break }; result.append(buffer, count: count)
            }
            return result
        }
        group.enter(); DispatchQueue.global(qos: .utility).async { stdoutData = readAll(stdoutPipe[0]); _ = close(stdoutPipe[0]); group.leave() }
        group.enter(); DispatchQueue.global(qos: .utility).async { stderrData = readAll(stderrPipe[0]); _ = close(stderrPipe[0]); group.leave() }
        var status: Int32 = 0; _ = waitpid(pid, &status, 0); group.wait()
        guard status == 0 else { throw StringError(String(data: stderrData, encoding: .utf8) ?? "命令执行失败。") }
        return stdoutData
    }
}

protocol CharacterPair {
    var leading: String { get }
    var trailing: String { get }
}

class Theme {}

struct TextViewState {
    let text: String
    let theme: AnyTheme
}

struct HighlightedRange {
    let range: NSRange
    let color: UIColor
}

struct SearchResult {
    let range: NSRange
}

struct SearchQuery {
    enum MatchMethod {
        case startsWith, endsWith, contains, fullWord, regularExpression
    }

    let text: String
    let matchMethod: MatchMethod
    let isCaseSensitive: Bool

    init(text: String, matchMethod: MatchMethod, isCaseSensitive: Bool) {
        self.text = text
        self.matchMethod = matchMethod
        self.isCaseSensitive = isCaseSensitive
    }

    func ranges(in source: String) -> [NSRange] {
        guard !text.isEmpty else { return [] }

        let nsSource = source as NSString
        let range = NSRange(location: 0, length: nsSource.length)
        let options: NSRegularExpression.Options = isCaseSensitive ? [] : [.caseInsensitive]

        if matchMethod == .regularExpression,
           let regex = try? NSRegularExpression(pattern: text, options: options) {
            return regex.matches(in: source, range: range).map(\.range)
        }

        let comparisonOptions: NSString.CompareOptions = isCaseSensitive ? [] : [.caseInsensitive]
        var result: [NSRange] = []
        var cursor = 0

        while cursor < nsSource.length {
            let found = nsSource.range(
                of: text,
                options: comparisonOptions,
                range: NSRange(location: cursor, length: nsSource.length - cursor)
            )
            guard found.location != NSNotFound else { break }

            func isBoundary(_ index: Int) -> Bool {
                if index <= 0 || index >= nsSource.length { return true }
                let left = nsSource.substring(with: NSRange(location: index - 1, length: 1))
                let right = nsSource.substring(with: NSRange(location: index, length: 1))
                let wordSet = CharacterSet.alphanumerics.union(.letters).union(.decimalDigits)
                let leftIsWord = left.rangeOfCharacter(from: wordSet) != nil
                let rightIsWord = right.rangeOfCharacter(from: wordSet) != nil
                return !(leftIsWord && rightIsWord)
            }

            let accepted: Bool
            switch matchMethod {
            case .contains:
                accepted = true
            case .startsWith:
                accepted = found.location == 0 || isBoundary(found.location)
            case .endsWith:
                accepted = NSMaxRange(found) == nsSource.length || isBoundary(NSMaxRange(found))
            case .fullWord:
                accepted = isBoundary(found.location) && isBoundary(NSMaxRange(found))
            case .regularExpression:
                accepted = true
            }

            if accepted {
                result.append(found)
            }

            cursor = max(NSMaxRange(found), cursor + 1)
        }

        return result
    }
}

final class TextView: UITextView, UITextViewDelegate {
    weak var editorDelegate: TextViewDelegate?
    var characterPairs: [CharacterPair] = []
    var showLineNumbers: Bool = false
    var isLineWrappingEnabled: Bool = true {
        didSet {
            textContainer.lineBreakMode = isLineWrappingEnabled ? .byWordWrapping : .byClipping
            textContainer.widthTracksTextView = isLineWrappingEnabled
        }
    }

    var highlightedRanges: [HighlightedRange] = [] {
        didSet { updateHighlightedRanges() }
    }

    override init(frame: CGRect, textContainer: NSTextContainer? = nil) {
        super.init(frame: frame, textContainer: textContainer)
        commonInit()
    }

    convenience init() {
        self.init(frame: .zero, textContainer: nil)
    }

    required init?(coder: NSCoder) {
        super.init(coder: coder)
        commonInit()
    }

    private func commonInit() {
        delegate = self
        font = .monospacedSystemFont(ofSize: 16, weight: .regular)
        autocorrectionType = .no
        autocapitalizationType = .none
        smartQuotesType = .no
        smartDashesType = .no
        backgroundColor = .clear
    }

    func setState(_ state: TextViewState) {
        let editable = isEditable
        isEditable = false
        text = state.text
        font = state.theme.font
        textColor = state.theme.textColor
        isEditable = editable
        textContainer.lineBreakMode = isLineWrappingEnabled ? .byWordWrapping : .byClipping
        textContainer.widthTracksTextView = isLineWrappingEnabled
        updateHighlightedRanges()
    }

    func goToLine(_ zeroBasedLine: Int) {
        let target = max(0, zeroBasedLine)
        let textString = text as NSString
        var line = 0
        var location = 0

        while line < target, location < textString.length {
            let newline = textString.range(
                of: "\n",
                options: [],
                range: NSRange(location: location, length: textString.length - location)
            )
            guard newline.location != NSNotFound else { break }
            location = NSMaxRange(newline)
            line += 1
        }

        selectedRange = NSRange(location: min(location, textString.length), length: 0)
        scrollRangeToVisible(selectedRange)
    }

    func search(for query: SearchQuery) -> [SearchResult] {
        query.ranges(in: text).map(SearchResult.init(range:))
    }

    func shiftLeft() {
        guard selectedRange.length > 0 else { return }
        let range = selectedRange
        let mutable = NSMutableString(string: text)
        mutable.replaceCharacters(in: range, with: "")
        text = mutable as String
        selectedRange = NSRange(location: range.location, length: 0)
    }

    func shiftRight() {
        guard selectedRange.length > 0 else { return }
        let range = selectedRange
        let mutable = NSMutableString(string: text)
        let selected = (text as NSString).substring(with: range)
        mutable.replaceCharacters(in: range, with: "    " + selected)
        text = mutable as String
        selectedRange = NSRange(location: range.location + 4, length: range.length)
    }

    private func updateHighlightedRanges() {
        guard !highlightedRanges.isEmpty else { return }
        let mutable = NSMutableAttributedString(string: text)
        mutable.addAttribute(.font, value: font ?? UIFont.monospacedSystemFont(ofSize: 16, weight: .regular),
                              range: NSRange(location: 0, length: mutable.length))
        for item in highlightedRanges where NSMaxRange(item.range) <= mutable.length {
            mutable.addAttribute(.backgroundColor, value: item.color, range: item.range)
        }
        let currentSelection = selectedRange
        attributedText = mutable
        selectedRange = NSRange(location: min(currentSelection.location, mutable.length), length: 0)
    }

    func textViewShouldBeginEditing(_ textView: UITextView) -> Bool {
        editorDelegate?.textViewShouldBeginEditing?(self) ?? true
    }

    func textViewShouldEndEditing(_ textView: UITextView) -> Bool {
        editorDelegate?.textViewShouldEndEditing?(self) ?? true
    }

    func textView(
        _ textView: UITextView,
        shouldChangeTextIn range: NSRange,
        replacementText text: String
    ) -> Bool {
        guard range.length == 0, text.count == 1, !characterPairs.isEmpty else {
            return true
        }

        guard let pair = characterPairs.first(where: { $0.leading == text }) else {
            return true
        }

        let insertionLocation = range.location
        let mutable = NSMutableString(string: self.text)
        mutable.insert(text + pair.trailing, at: insertionLocation)
        self.text = mutable as String
        selectedRange = NSRange(location: insertionLocation + text.utf16.count, length: 0)
        editorDelegate?.textViewDidChange(self)
        return false
    }

    func textViewDidChange(_ textView: UITextView) {
        editorDelegate?.textViewDidChange(self)
    }
}

@objc protocol TextViewDelegate: AnyObject {
    @objc optional func textViewShouldBeginEditing(_ textView: TextView) -> Bool
    @objc optional func textViewShouldEndEditing(_ textView: TextView) -> Bool
    func textViewDidChange(_ textView: TextView)
}

private enum SantanderObjCRuntime {
    private static func encoding(_ method: Method) -> String {
        guard let encoding = method_getTypeEncoding(method) else { return "" }
        return String(cString: encoding)
    }

    private static func argumentCode(_ method: Method, _ index: UInt32) -> Character? {
        var buffer = [CChar](repeating: 0, count: 32)
        method_getArgumentType(method, index, &buffer, buffer.count)
        return String(cString: buffer).first
    }

    private static func returnCode(_ method: Method) -> Character? {
        var buffer = [CChar](repeating: 0, count: 32)
        method_getReturnType(method, &buffer, buffer.count)
        return String(cString: buffer).first
    }

    private static func compatible(_ method: Method, userArgumentCodes: [Set<Character>], returnCodes: Set<Character>) -> Bool {
        guard method_getNumberOfArguments(method) == UInt32(userArgumentCodes.count + 2),
              argumentCode(method, 0) == "@", argumentCode(method, 1) == ":",
              let result = returnCode(method), returnCodes.contains(result) else { return false }
        for (offset, allowed) in userArgumentCodes.enumerated() {
            guard let code = argumentCode(method, UInt32(offset + 2)), allowed.contains(code) else { return false }
        }
        return true
    }

    static let launchServicesHandle: UnsafeMutableRawPointer? = {
        let candidates = [
            "/System/Library/PrivateFrameworks/LaunchServices.framework/LaunchServices",
            "/System/Library/PrivateFrameworks/MobileCoreServices.framework/MobileCoreServices",
            "/System/Library/Frameworks/MobileCoreServices.framework/MobileCoreServices",
            "/System/Library/Frameworks/CoreServices.framework/CoreServices"
        ]

        for path in candidates where FileManager.default.fileExists(atPath: path) {
            if let handle = dlopen(path, RTLD_LAZY) {
                return handle
            }
        }
        return nil
    }()

    static func sendObject(
        to receiver: AnyObject,
        selector: Selector,
        argument: AnyObject? = nil
    ) -> AnyObject? {
        _ = launchServicesHandle
        guard let method = object_getClass(receiver).flatMap({ class_getInstanceMethod($0, selector) }),
              compatible(method, userArgumentCodes: [["@"]], returnCodes: ["@", "#"]) else {
            return nil
        }

        typealias Message = @convention(c) (AnyObject, Selector, AnyObject?) -> Unmanaged<AnyObject>?
        let function = unsafeBitCast(method_getImplementation(method), to: Message.self)
        return function(receiver, selector, argument)?.takeUnretainedValue()
    }

    static func sendObject(
        to receiver: AnyObject,
        selector: Selector
    ) -> AnyObject? {
        _ = launchServicesHandle
        guard let method = object_getClass(receiver).flatMap({ class_getInstanceMethod($0, selector) }),
              compatible(method, userArgumentCodes: [], returnCodes: ["@", "#"]) else {
            return nil
        }

        typealias Message = @convention(c) (AnyObject, Selector) -> Unmanaged<AnyObject>?
        let function = unsafeBitCast(method_getImplementation(method), to: Message.self)
        return function(receiver, selector)?.takeUnretainedValue()
    }

    static func sendObject(
        to receiver: AnyObject,
        selector: Selector,
        intArgument: Int32
    ) -> AnyObject? {
        _ = launchServicesHandle
        guard let method = object_getClass(receiver).flatMap({ class_getInstanceMethod($0, selector) }),
              compatible(method, userArgumentCodes: [["i", "q", "I", "Q"]], returnCodes: ["@", "#"]) else {
            return nil
        }

        typealias Message = @convention(c) (AnyObject, Selector, Int32) -> Unmanaged<AnyObject>?
        let function = unsafeBitCast(method_getImplementation(method), to: Message.self)
        return function(receiver, selector, intArgument)?.takeUnretainedValue()
    }

    static func sendBool(
        to receiver: AnyObject,
        selector: Selector,
        argument: AnyObject?
    ) -> Bool? {
        _ = launchServicesHandle
        guard let method = object_getClass(receiver).flatMap({ class_getInstanceMethod($0, selector) }),
              compatible(method, userArgumentCodes: [["@"]], returnCodes: ["B", "c"]) else {
            return nil
        }

        typealias Message = @convention(c) (AnyObject, Selector, AnyObject?) -> Bool
        let function = unsafeBitCast(method_getImplementation(method), to: Message.self)
        return function(receiver, selector, argument)
    }

    static func sendBool(
        to receiver: AnyObject,
        selector: Selector,
        firstArgument: AnyObject?,
        secondArgument: AnyObject?
    ) -> Bool? {
        _ = launchServicesHandle
        guard let method = object_getClass(receiver).flatMap({ class_getInstanceMethod($0, selector) }),
              compatible(method, userArgumentCodes: [["@"], ["@"]], returnCodes: ["B", "c"]) else {
            return nil
        }

        typealias Message = @convention(c) (AnyObject, Selector, AnyObject?, AnyObject?) -> Bool
        let function = unsafeBitCast(method_getImplementation(method), to: Message.self)
        return function(receiver, selector, firstArgument, secondArgument)
    }
}

final class SantanderApplication {
    fileprivate let object: AnyObject

    init?(object: AnyObject) {
        guard object_isClass(object) == false else { return nil }
        self.object = object
    }

    var applicationIdentifier: String {
        stringValue(for: "applicationIdentifier") ?? stringValue(for: "bundleIdentifier") ?? ""
    }

    var localizedName: String {
        stringValue(for: "localizedName")
            ?? (SantanderObjCRuntime.sendObject(
                to: object,
                selector: Selector(("localizedNameForContext:")),
                argument: nil
            ) as? String)
            ?? applicationIdentifier
    }

    var applicationType: String? { stringValue(for: "applicationType") }
    var sdkVersion: String? { stringValue(for: "sdkVersion") }
    var teamID: String? { stringValue(for: "teamID") }

    var claimedURLSchemes: [String] {
        let selector = Selector(("claimedURLSchemes"))
        guard let value = SantanderObjCRuntime.sendObject(to: object, selector: selector) else {
            return []
        }

        if let array = value as? [String] { return array }
        if let set = value as? Set<String> { return Array(set) }
        if let nsArray = value as? NSArray { return nsArray.compactMap { $0 as? String } }
        if let nsSet = value as? NSSet { return nsSet.allObjects.compactMap { $0 as? String } }
        return []
    }

    var isDeletable: Bool { boolValue(for: "isDeletable") }
    var isBetaApp: Bool { boolValue(for: "isBetaApp") }
    var isRestricted: Bool { boolValue(for: "isRestricted") }
    var isContainerized: Bool { boolValue(for: "isContainerized") }

    func bundleURL() -> URL {
        urlValue(for: "bundleURL") ?? URL(fileURLWithPath: "")
    }

    func containerURL() -> URL {
        urlValue(for: "containerURL") ?? URL(fileURLWithPath: "")
    }

    func dataContainerURL() -> URL {
        urlValue(for: "dataContainerURL") ?? URL(fileURLWithPath: "")
    }

    var entitlements: [String: Any] {
        let selectorNames = ["entitlements", "_entitlements"]
        for name in selectorNames {
            guard let value = SantanderObjCRuntime.sendObject(to: object, selector: Selector((name))) else {
                continue
            }
            if let dictionary = value as? [String: Any] { return dictionary }
            if let dictionary = value as? NSDictionary {
                return dictionary.reduce(into: [String: Any]()) { partialResult, element in
                    if let key = element.key as? String { partialResult[key] = element.value }
                }
            }
        }
        return [:]
    }

    private func stringValue(for selectorName: String) -> String? {
        SantanderObjCRuntime.sendObject(to: object, selector: Selector((selectorName))) as? String
    }

    private func urlValue(for selectorName: String) -> URL? {
        guard let value = SantanderObjCRuntime.sendObject(to: object, selector: Selector((selectorName))) else {
            return nil
        }
        if let url = value as? URL { return url }
        if let url = value as? NSURL { return url as URL }
        return nil
    }

    private func boolValue(for selectorName: String) -> Bool {
        guard let method = object_getClass(object).flatMap({ class_getInstanceMethod($0, Selector((selectorName))) }) else {
            return false
        }
        typealias Message = @convention(c) (AnyObject, Selector) -> Bool
        let function = unsafeBitCast(method_getImplementation(method), to: Message.self)
        return function(object, Selector((selectorName)))
    }
}

private final class ApplicationsManager {
    static let shared = ApplicationsManager()

    private let cacheLock = NSLock()
    private var applicationsCache: [SantanderApplication] = []
    private var applicationsCacheDate = Date.distantPast
    private let cacheLifetime: TimeInterval = 2.0

    private init() {}

    func application(forBundleURL url: URL) -> SantanderApplication? {
        let proxyClass = NSClassFromString("LSApplicationProxy") as AnyObject?
        if let proxyClass,
           let object = SantanderObjCRuntime.sendObject(
                to: proxyClass,
                selector: Selector(("applicationProxyForBundleURL:")),
                argument: url as NSURL
           ),
           let app = SantanderApplication(object: object) {
            return app
        }

        return findApplication { Self.normalizedPath($0.bundleURL()) == Self.normalizedPath(url) }
    }

    func application(forContainerURL url: URL) -> SantanderApplication? {
        findApplication { Self.normalizedPath($0.containerURL()) == Self.normalizedPath(url) }
    }

    func application(forDataContainerURL url: URL) -> SantanderApplication? {
        findApplication { Self.normalizedPath($0.dataContainerURL()) == Self.normalizedPath(url) }
    }

    func icon(forApplication app: SantanderApplication) -> UIImage? {
        let selector = Selector(("iconDataForVariant:"))
        for variant in [2, 1, 0] {
            guard let dataObject = SantanderObjCRuntime.sendObject(
                to: app.object,
                selector: selector,
                intArgument: Int32(variant)
            ),
            let data = dataObject as? NSData,
            let image = UIImage(data: data as Data) else {
                continue
            }
            return image
        }
        return nil
    }

    func openApp(_ app: SantanderApplication) throws {
        guard let workspace = defaultWorkspace() else {
            throw Self.error("LSApplicationWorkspace is unavailable")
        }

        let selector = Selector(("openApplicationWithBundleID:"))
        guard let result = SantanderObjCRuntime.sendBool(
            to: workspace,
            selector: selector,
            argument: app.applicationIdentifier as NSString
        ) else {
            throw Self.error("LaunchServices does not expose openApplicationWithBundleID:")
        }
        guard result else {
            throw Self.error("LaunchServices failed to open \(app.applicationIdentifier)")
        }
    }

    func deleteApp(_ app: SantanderApplication) throws {
        guard let workspace = defaultWorkspace() else {
            throw Self.error("LSApplicationWorkspace is unavailable")
        }

        let selector = Selector(("uninstallApplication:withOptions:"))
        guard let result = SantanderObjCRuntime.sendBool(
            to: workspace,
            selector: selector,
            firstArgument: app.applicationIdentifier as NSString,
            secondArgument: nil
        ) else {
            throw Self.error("LaunchServices does not expose uninstallApplication:withOptions:")
        }
        guard result else {
            throw Self.error("LaunchServices failed to delete \(app.applicationIdentifier)")
        }
        invalidateCache()
    }

    func reload() {
        invalidateCache()
    }

    private func defaultWorkspace() -> AnyObject? {
        guard let workspaceClass = NSClassFromString("LSApplicationWorkspace") as AnyObject? else {
            return nil
        }
        return SantanderObjCRuntime.sendObject(to: workspaceClass, selector: Selector(("defaultWorkspace")))
    }

    private func allInstalledApplications() -> [SantanderApplication] {
        cacheLock.lock()
        let cached = applicationsCache
        let age = Date().timeIntervalSince(applicationsCacheDate)
        cacheLock.unlock()

        if !cached.isEmpty, age < cacheLifetime {
            return cached
        }

        guard let workspace = defaultWorkspace() else {
            return cached
        }

        let raw = SantanderObjCRuntime.sendObject(to: workspace, selector: Selector(("allInstalledApplications")))
            ?? SantanderObjCRuntime.sendObject(to: workspace, selector: Selector(("allApplications")))
        let rawObjects = (raw as? NSArray)?.compactMap { $0 as AnyObject } ?? []
        let applications = rawObjects.compactMap(SantanderApplication.init(object:))

        cacheLock.lock()
        applicationsCache = applications
        applicationsCacheDate = Date()
        cacheLock.unlock()
        return applications
    }

    private func findApplication(where predicate: (SantanderApplication) -> Bool) -> SantanderApplication? {
        allInstalledApplications().first(where: predicate)
    }

    private func invalidateCache() {
        cacheLock.lock()
        applicationsCache.removeAll(keepingCapacity: true)
        applicationsCacheDate = .distantPast
        cacheLock.unlock()
    }

    private static func normalizedPath(_ url: URL) -> String {
        url.standardizedFileURL.resolvingSymlinksInPath().path
    }

    private static func error(_ message: String) -> NSError {
        NSError(
            domain: "Santander.Applications",
            code: -1,
            userInfo: [NSLocalizedDescriptionKey: message]
        )
    }
}

private enum SantanderL10n {
    static var language: String {
        if let value = UserDefaults.standard.string(forKey: "SantanderLanguage") {
            return value
        }
        return "zh-Hans"
    }

    static func setLanguage(_ value: String) {
        UserDefaults.standard.set(value, forKey: "SantanderLanguage")
    }

    static func t(_ value: String) -> String {
        guard language.hasPrefix("zh") else { return value }
        if let exact = table[value] {
            return exact
        }

        let dynamicPrefixes: [(String, String)] = [
        ("Subdirectories", "子目录"),
        ("New", "新建"),
        ("Enter a valid executable and arguments.", "请输入有效的可执行文件和参数。"),
        ("Failed to open item", "打开项目失败"),
        ("Select font..", "选择字体…"),
        ("Save Image", "保存图片"),
        ("No Preview.", "无预览。"),
        ("No Results", "无结果"),
        ("Input is empty", "输入为空"),
        ("Scale", "缩放"),
        ("Lookup Name", "查找名称"),
        ("Rendition Name", "资源名称"),
        ("Height", "高度"),
        ("Width", "宽度"),
        ("Idiom", "设备类型"),
        ("Display Gamut", "显示色域"),
        ("ColorSpace", "色彩空间"),
        ("Red", "红"),
        ("Blue", "蓝"),
        ("Green", "绿"),
        ("Unknown Artist", "未知艺术家"),
        ("Default Configuration", "默认配置"),
        ("Moving to..", "移动到…"),
        ("Copying to..", "复制到…"),
        ("Importing to..", "导入到…"),
        ("Aliasing to..", "创建别名到…"),
        ("Add", "添加"),
        ("Add Key", "添加键"),
        ("Add Value", "添加值"),
        ("Cancel", "取消"),
        ("Close", "关闭"),
        ("Save", "保存"),
        ("Done", "完成"),
        ("Edit", "编辑"),
        ("Delete", "删除"),
        ("Remove", "移除"),
        ("Rename", "重命名"),
        ("Copy", "复制"),
        ("Move", "移动"),
        ("Duplicate", "复制副本"),
        ("Paste", "粘贴"),
        ("Select", "选择"),
        ("Select All", "全选"),
        ("Deselect All", "取消全选"),
        ("Open", "打开"),
        ("Share", "分享"),
        ("Search", "搜索"),
        ("Info", "信息"),
        ("Path Info", "路径信息"),
        ("Permissions", "权限"),
        ("Special Permissions", "特殊权限"),
        ("Set UID", "设置用户 ID（setuid）"),
        ("Set GID", "设置组 ID（setgid）"),
        ("Sticky bit", "粘滞位（sticky）"),
        ("Owner", "所有者"),
        ("Group", "组"),
        ("Other", "其他"),
        ("Other users", "其他用户"),
        ("Read", "读取"),
        ("Write", "写入"),
        ("Execute", "执行"),
        ("Root", "根目录"),
        ("Mount", "挂载"),
        ("Unmount", "卸载"),
        ("Symbolic Link", "符号链接"),
        ("Create Symbolic Link", "创建符号链接"),
        ("Compress", "压缩"),
        ("Decompress", "解压"),
        ("Archive", "归档"),
        ("File", "文件"),
        ("Folder", "文件夹"),
        ("Directory", "文件夹"),
        ("String", "String"),
        ("Integer", "Integer"),
        ("Real", "Real"),
        ("Boolean", "Boolean"),
        ("Float", "Float"),
        ("Date", "Date"),
        ("Data", "Data"),
        ("Array", "Array"),
        ("Dictionary", "Dictionary"),
        ("Key", "Key"),
        ("Value", "Value"),
        ("Property List Viewer", "属性列表查看器"),
        ("Property List Editor", "属性列表编辑器"),
        ("Text Editor", "文本编辑器"),
        ("Text Editor Settings", "文本编辑器设置"),
        ("Image Viewer", "图片查看器"),
        ("Audio Player", "音频播放器"),
        ("Video Player", "视频播放器"),
        ("Font Viewer", "字体查看器"),
        ("Settings", "设置"),
        ("General", "通用"),
        ("Appearance", "外观"),
        ("Light", "浅色"),
        ("Dark", "深色"),
        ("Default", "默认"),
        ("Applications", "应用程序"),
        ("Documents", "文稿"),
        ("Downloads", "下载"),
        ("Library", "资源库"),
        ("Home", "主目录"),
        ("System", "系统"),
        ("Contents", "内容"),
        ("Items", "项目"),
        ("Name", "名称"),
        ("Size", "大小"),
        ("Modified", "修改时间"),
        ("Created", "创建时间"),
        ("Added", "添加时间"),
        ("Accessed", "访问时间"),
        ("Date modified", "修改日期"),
        ("Date created", "创建日期"),
        ("Executable", "可执行文件"),
        ("Entitlements", "权限声明"),
        ("Bundle ID", "Bundle ID"),
        ("App Info", "应用信息"),
        ("App name", "应用名称"),
        ("Invalid Data", "数据无效"),
        ("Not implemented", "尚未实现"),
        ("Santander Helper", "Santander 助手"),
        ("Enabled", "已启用"),
        ("Disabled", "已停用"),
        ("Ascending", "升序"),
        ("Descending", "降序"),
        ("Alphabetical order", "按名称排序"),
        ("Grouped", "分组"),
        ("Plain", "普通"),
        ("Programming", "编程"),
        ("Font size", "字体大小"),
        ("Go to line", "跳转到行"),
        ("Search Method", "搜索方式"),
        ("Case Sensitive", "区分大小写"),
        ("Full Word", "完整单词"),
        ("Regex", "正则表达式"),
        ("Starts With", "开头匹配"),
        ("Ends With", "结尾匹配"),
        ("Contains", "包含"),
        ("Display hidden files", "显示隐藏文件"),
        ("Always show search bar", "始终显示搜索栏"),
        ("Large navigation titles", "使用大号导航标题"),
        ("Create", "创建"),
        ("New Group", "新建组"),
        ("Duplicate Key", "键重复"),
        ("Scroll Up", "向上滚动"),
        ("Scroll Down", "向下滚动"),
        ("Copy Path", "复制路径"),
        ("Recent", "最近"),
        ("Audio waveform", "音频波形"),
        ("Volume", "音量"),
        ("Play or pause", "播放或暂停"),
        ("Now Playing", "正在播放"),
        ("Table Structure", "表结构"),
        ("Unable to read table structure", "无法读取表结构"),
        ("View item", "查看项目"),
        ("Copy name", "复制名称"),
        ("Copy path", "复制路径"),
        ("Sort by..", "排序方式"),
        ("New..", "新建"),
        ("Other..", "其他…"),
        ("Go to..", "前往…"),
        ("Move to..", "移动到…"),
        ("Copy to..", "复制到…"),
        ("Create symbolic link to..", "创建符号链接到…"),
        ("Open App", "打开应用"),
        ("Open in..", "打开方式…"),
        ("File actions", "文件操作"),
        ("Add to group..", "添加到组…"),
        ("Decompressing..", "正在解压…"),
        ("Compressing..", "正在压缩…"),
        ("Extract to..", "提取到…"),
        ("Extracting..", "正在提取…"),
        ("Layout", "布局"),
        ("Horizontal", "横向"),
        ("Vertical", "纵向"),
        ("Grid", "网格"),
        ("Collapse Section", "折叠分组"),
        ("Expand Section", "展开分组"),
        ("Copy Image", "复制图片"),
        ("Set as wallpaper for..", "设置为墙纸…"),
        ("Lock Screen", "锁定屏幕"),
        ("Home Screen", "主屏幕"),
        ("Home Screen & Lock Screen", "主屏幕与锁定屏幕"),
        ("Backward / Forward duration", "后退/前进时长"),
        ("Speed", "播放速度"),
        ("Zoom in", "放大"),
        ("Zoom out", "缩小"),
        ("Dismiss", "关闭"),
        ("View", "查看"),
        ("Path", "路径"),
        ("Launch Path", "启动路径"),
        ("Custom Launch Path", "自定义启动路径"),
        ("Last Opened Path", "上次打开的路径"),
        ("Views", "界面"),
        ("Types", "类型"),
        ("Generic", "通用"),
        ("Audio", "音频"),
        ("Document", "文稿"),
        ("Date Metadata", "日期元数据"),
        ("Full name", "全名"),
        ("Family name", "系列名称"),
        ("PostScript name", "PostScript 名称"),
        ("Style", "样式"),
        ("URL", "URL"),
        ("Designer", "设计者"),
        ("Manufacturer", "制造商"),
        ("Version", "版本"),
        ("Pixel Height", "像素高度"),
        ("Pixel Width", "像素宽度"),
        ("Camera Model", "相机型号"),
        ("Camera Manufacturer", "相机制造商"),
        ("Camera Software", "相机软件"),
        ("Lens Model", "镜头型号"),
        ("Lens Manufacturer", "镜头制造商"),
        ("Latitude", "纬度"),
        ("Longitude", "经度"),
        ("Font", "字体"),
        ("Text Color", "文本颜色"),
        ("Editor Background Color", "编辑器背景色"),
        ("Fonts", "字体"),
        ("Lines", "行"),
        ("Colors", "颜色"),
        ("Show Line Count", "显示行数"),
        ("Wrap Lines", "自动换行"),
        ("Use Character Pairs", "使用字符配对"),
        ("SDK Version", "SDK 版本"),
        ("URL schemes", "URL 方案"),
        ("Team ID", "团队 ID"),
        ("Deletable", "可删除"),
        ("Beta app", "测试版应用"),
        ("Restricted", "受限"),
        ("Containerized", "已容器化"),
        ("Container URL", "容器路径"),
        ("Bundle URL", "Bundle 路径"),
        ("Display name", "显示名称"),
        ("MIME Type", "MIME 类型"),
        ("Alias", "别名"),
        ("ID", "ID"),
        ("Set", "设置"),
        ("Invalid ID", "ID 无效"),
        ("ID range", "UID/GID 范围：-2…501"),
        ("Unknown Type", "未知类型"),
        ("Removed", "已移除"),
        ("Unknown Mode", "未知模式"),
        ("SRGB", "sRGB"),
        ("Display P3", "Display P3"),
        ("Universal", "通用"),
        ("CarPlay", "CarPlay"),
        ("Marketing", "营销"),
        ("Mac Catalyst", "Mac Catalyst"),
        ("Any", "任意"),
        ("High Contrast", "高对比度"),
        ("High Contrast Dark", "高对比度深色"),
        ("High Contrast Light", "高对比度浅色"),
        ("Image", "图像"),
        ("Icon", "图标"),
        ("Image Set", "图像集"),
        ("Multisize Image Set", "多尺寸图像集"),
        ("PDF", "PDF"),
        ("Color", "颜色"),
        ("SVG (Vector)", "SVG（矢量）"),
        ("Raw Data", "原始数据"),
        ("Unknown", "未知"),
        ("Zip", "ZIP"),
        ("Tar", "TAR"),
        ("7z", "7Z"),
        ("7-Zip", "7-Zip"),
        ("File associations", "文件关联"),
        ("File association", "文件关联"),
        ("Invalid file extension", "文件后缀无效"),
        ("Viewer", "查看器"),
        ("Default viewer", "默认查看器"),
        ("File extension", "文件后缀"),
        ("Add association", "添加文件关联"),
        ("Edit association", "编辑文件关联"),
        ("Open in", "打开方式"),
        ("Are you sure you want to delete this item?", "确定要删除此项目吗？"),
        ("Unable to delete app", "无法删除应用"),
        ("Unable to open app", "无法打开应用"),
        ("Unable to save image", "无法保存图片"),
        ("无法设置壁纸", "无法将图片设置为墙纸"),
        ("Failed to edit item", "编辑项目失败"),
        ("Unable to update items", "无法更新项目"),
        ("Unable to edit item", "无法编辑项目"),
        ("Failed to delete item", "删除项目失败"),
        ("Unable to write to file", "无法写入文件"),
        ("Unable to save to file", "无法保存文件"),
        ("Unsaved changes", "未保存的更改"),
        ("Can't write to Property List file", "无法写入属性列表文件"),
        ("Unable to launch process", "无法启动进程"),
        ("Remove image location?", "移除图片位置？"),
        ("Failed to display image.", "无法显示图片。"),
        ("The key already exists.", "键已存在。"),
        ("Hex data must contain an even number of characters.", "十六进制数据必须包含偶数个字符。"),
        ("The data contains an invalid hexadecimal byte.", "数据包含无效的十六进制字节。"),
        ("Unable to set date of image", "无法设置图片日期"),
        ("Unable to set location of image", "无法设置图片位置"),
        ("无法删除项目", "无法移除项目"),
        ("Failed to import file", "导入文件失败"),
        ("Failed to copy item", "复制项目失败"),
        ("Failed to delete item and update contents of file", "删除项目并更新文件内容失败"),
        ("Unable to extract items", "无法提取项目"),
        ("无法读取属性列表格式。", "无法获取属性列表格式"),
        ("Unknown Error", "未知错误"),
        ("Unable to authenticate", "无法进行身份验证"),
        ("Unable to set path as Launch Path", "无法将路径设置为启动路径"),
        ("Path must be a directory", "路径必须是目录"),
        ("Input text is invalid or empty", "输入文本无效或为空"),
        ("Enter the other path you want to be opened at launch", "请输入启动时要打开的其他路径"),
        ("URL(s) being imported to app, would you like to copy it to another path?", "正在向应用导入 URL，是否要将其复制到其他路径？"),
        ("Enter the destination directory.", "请输入目标目录。"),
        ("Enter an empty or existing mount point.", "请输入空的或现有的挂载点。"),
        ("No path to paste.", "没有可粘贴的路径。"),
        ("Failed to copy item to current directory.", "复制项目到当前目录失败。"),
        ("Group with same name already exists", "同名组已存在"),
        ("The ID must be between -2 and 501.", "ID 必须介于 -2 和 501 之间。"),
        ("SantanderHelper returned non-zero status, error: \\(ret.standardError)", "Root 助手返回错误：\\(ret.standardError)"),
        ("Root helper failed with status \\(result.status)", "Root 助手失败，状态码：\\(result.status)"),
        ("Unable to configure helper pipes: \\(String(cString: strerror(errno)))", "无法配置 Root 助手管道：\\(String(cString: strerror(errno)))"),
        ("Unable to attach process output pipe.", "无法连接进程输出管道。"),
        ("Unable to create stdout pipe.", "无法创建标准输出管道。"),
        ("Unable to create stderr pipe.", "无法创建标准错误管道。"),
        ("Unable to initialize process actions.", "无法初始化进程操作。"),
        ("Executable URL is missing.", "缺少可执行文件路径。"),
        ("Asset catalog does not exist: \\(url.path)", "资源目录不存在：\\(url.path)"),
        ("CoreUI CUICatalog is unavailable on this OS.", "当前系统无法使用 CoreUI 资源目录。"),
        ("CoreUI asset writing is unavailable on this iOS version.", "此 iOS 版本不支持 CoreUI 资源写入。"),
        ("CoreUI failed to save the asset catalog.", "CoreUI 保存资源目录失败。"),
        ("CoreUI storage does not expose a writable catalog method.", "CoreUI 存储未提供可写入资源目录的方法。"),
        ("No input paths were supplied.", "未提供输入路径。"),
        ("Compression format must be zip, tar or 7z", "压缩格式必须是 ZIP、TAR 或 7Z"),
        ("Unable to write item data to file: \\(error.localizedDescription)", "无法将项目数据写入文件：\\(error.localizedDescription)"),
        ("Permission Denied.", "没有权限。"),
        ("Please enter a name.", "请输入名称。"),
        ("file", "文件"),
        ("directory", "文件夹"),
        ("name", "名称"),
        ("Group name..", "组名称…"),
        ("Custom Path", "自定义路径"),
        ("Hello", "你好"),
        ("The quick brown fox jumps over the lazy dog and runs away.", "敏捷的棕色狐狸跳过懒狗，然后跑开了。"),
        ("OK", "好"),
        ("Error occurred: ", "发生错误："),
        ("Inset Grouped", "内嵌分组"),
        ("N/A", "不可用"),
        ("Camera", "相机"),
        ("Lens", "镜头"),
        ("Location", "位置"),
        ("TextEditorShowLineCount", "显示行数"),
        ("TextEditorWrapLines", "自动换行"),
        ("TextEditorUseCharacterPairs", "使用字符配对"),
        ("Type", "类型"),
        ("Locked", "锁定文件"),
        ("Date Label", "日期"),
        ("Position in array", "数组中的位置"),
        ("Value (in base64)", "值（base64）"),
        ("JSON Viewer", "JSON 查看器"),
        ("Asset Catalog Viewer", "资源目录查看器"),
        ("Executable Runner", "可执行文件运行器"),
        ("iPhone", "iPhone"),
        ("iPad", "iPad"),
        ("TV", "电视"),
        ("Watch", "Apple Watch"),
        ("无法创建符号链接", "无法创建符号链接"),
        ("move", "移动"),
        ("copy", "复制"),
        ("import", "导入"),
        ("symlink", "符号链接"),
        ("Santander Helper unavailable? is your install messed up?", "Root 助手不可用，请检查安装是否完整。"),
        ("Unable to read SantanderHelper output", "无法读取 Root 助手输出"),
        ("Failed to spawn SantanderHelper", "无法启动 Root 助手"),
        ("点击选择类型", "点击选择类型"),
        ("Unnamed Asset", "未命名资源"),
        ("Readable", "可读"),
        ("Writable", "可写"),
        ("Preparing...", "准备中…"),
        ("Cancelling...", "正在取消…"),
        ("Completed", "已完成"),
        ("Cancel current filesystem operation", "取消当前文件系统操作"),
        ("Unable to open item", "无法打开项目"),
        ]
        for (prefix, translatedPrefix) in dynamicPrefixes where value.hasPrefix(prefix) {
            return translatedPrefix + String(value.dropFirst(prefix.count)).trimmingCharacters(in: .whitespaces)
        }

        if value.hasPrefix("Can't ") {
            var suffix = String(value.dropFirst("Can't ".count))
            suffix = suffix.replacingOccurrences(of: " path", with: "路径")
            return "无法" + suffix
        }

        if value.hasPrefix("Unable to ") {
            var suffix = String(value.dropFirst("Unable to ".count))
            suffix = suffix.replacingOccurrences(of: " items", with: "项目")
            suffix = suffix.replacingOccurrences(of: " file(s)", with: "文件")
            return "无法" + suffix
        }
        return value
    }

    private static let table: [String: String] = [
        "Subdirectories": "子目录",
        "New": "新建",
        "Enter a valid executable and arguments.": "请输入有效的可执行文件和参数。",
        "Failed to open item": "打开项目失败",
        "Scale": "缩放",
        "Height": "高度",
        "Width": "宽度",
        "Idiom": "设备类型",
        "ColorSpace": "色彩空间",
        "Red": "红",
        "Blue": "蓝",
        "Green": "绿",
        "Default Configuration": "默认配置",
        "Moving to..": "移动到…",
        "Copying to..": "复制到…",
        "Importing to..": "导入到…",
        "Aliasing to..": "创建别名到…",

        "Add": "添加",
        "Add Key": "添加键",
        "Add Value": "添加值",
        "Close": "关闭",
        "Save": "保存",
        "Done": "完成",
        "Edit": "编辑",
        "Delete": "删除",
        "Remove": "移除",
        "Rename": "重命名",
        "Copy": "复制",
        "Move": "移动",
        "Duplicate": "复制副本",
        "Paste": "粘贴",
        "Select": "选择",
        "Open": "打开",
        "File actions": "文件操作",
        "Share": "分享",
        "Search": "搜索",
        "Grid View": "网格视图",
        "List View": "列表视图",
        "More": "更多",
        "Eraser": "橡皮擦",
        "Unable to decompress": "无法解压",
        "Unable to rename item": "无法重命名项目",
        "Unable to delete item": "无法删除项目",
        "Files": "文件",
        "Favorites": "收藏",
        "Recent": "最近",
        "Audio waveform": "音频波形",
        "Volume": "音量",
        "Play or pause": "播放或暂停",
        "Now Playing": "正在播放",
        "Table Structure": "表结构",
        "Unable to read table structure": "无法读取表结构",
        "Tools": "工具",
        "Preview": "预览",
        "Select a file to inspect its details": "选择文件查看详细信息",
        "Compact": "紧凑",
        "Standard": "标准",
        "Comfortable": "宽松",
        "List density": "列表密度",
        "Show file size and date": "显示文件大小和日期",
        "Show metadata below the filename and as columns on wide screens": "在文件名下方或宽屏列中显示元数据",
        "New folder": "新建文件夹",
        "Create a file or folder, or navigate to another location.": "创建文件或文件夹，或前往其他位置。",
        "Retry with Santander Helper": "使用 Root 助手重试",
        "Retry": "重试",
        "This location could not be read. Check Santander Helper availability and permissions.": "无法读取此位置，请检查 Root 助手与访问权限。",
        "Navigation": "导航",
        "View Options": "视图",
        "Selection": "选择",
        "Operations": "操作",
        "Reverse Order": "反向排序",
        "Remove Favorite": "移除收藏",
        "Quickly reopen recently visited directories": "快速重新打开最近访问的目录",
        "Copy, move, archive, and background operation status": "复制、移动、归档及后台任务状态",
        "Open a SwiftTerm session in the home directory": "在主目录打开 SwiftTerm 终端",
        "Clear recent paths?": "清空最近路径？",
        "Clear": "清空",
        "Try another name or clear the active filters.": "请尝试其他名称，或清除当前筛选条件。",
        "Info": "信息",
        "Path Info": "路径信息",
        "Permissions": "权限",
        "Special Permissions": "特殊权限",
        "Set UID": "设置用户 ID（setuid）",
        "Set GID": "设置组 ID（setgid）",
        "Sticky bit": "粘滞位（sticky）",
        "Owner": "所有者",
        "Group": "组",
        "Other": "其他",
        "Other users": "其他用户",
        "Read": "读取",
        "Write": "写入",
        "Execute": "执行",
        "Root": "根目录",
        "Mount": "挂载",
        "Unmount": "卸载",
        "Create Symbolic Link": "创建符号链接",
        "Compress": "压缩",
        "Decompress": "解压",
        "Archive": "归档",
        "Folder": "文件夹",
        "String": "String",
        "Integer": "Integer",
        "Real": "Real",
        "Boolean": "Boolean",
        "Float": "Float",
        "Date": "Date",
        "Data": "Data",
        "Array": "Array",
        "Dictionary": "Dictionary",
        "Property List Viewer": "属性列表查看器",
        "Property List Editor": "属性列表编辑器",
        "Text Editor": "文本编辑器",
        "Text Editor Settings": "文本编辑器设置",
        "Image Viewer": "图片查看器",
        "Audio Player": "音频播放器",
        "Video Player": "视频播放器",
        "Font Viewer": "字体查看器",
        "Settings": "设置",
        "General": "通用",
        "Appearance": "外观",
        "Light": "浅色",
        "Dark": "深色",
        "Default": "默认",
        "Applications": "应用程序",
        "Documents": "文稿",
        "Downloads": "下载",
        "Library": "资源库",
        "Home": "主目录",
        "System": "系统",
        "Contents": "内容",
        "Items": "项目",
        "Name": "名称",
        "Size": "大小",
        "Modified": "修改时间",
        "Created": "创建时间",
        "Added": "添加时间",
        "Accessed": "访问时间",
        "Date modified": "修改日期",
        "Date created": "创建日期",
        "Entitlements": "权限声明",
        "App Info": "应用信息",
        "App name": "应用名称",
        "Input is empty": "输入为空",
        "Invalid Data": "数据无效",
        "Not implemented": "尚未实现",
        "Santander Helper": "Santander 助手",
        "Enabled": "已启用",
        "Disabled": "已停用",
        "Ascending": "升序",
        "Descending": "降序",
        "Alphabetical order": "按名称排序",
        "Grouped": "分组",
        "Plain": "普通",
        "Programming": "编程",
        "Font size": "字体大小",
        "Go to line": "跳转到行",
        "Search Method": "搜索方式",
        "Case Sensitive": "区分大小写",
        "Full Word": "完整单词",
        "Regex": "正则表达式",
        "Starts With": "开头匹配",
        "Ends With": "结尾匹配",
        "Contains": "包含",
        "Display hidden files": "显示隐藏文件",
        "Show hidden files by default": "默认显示隐藏文件",
        "Always show search bar": "始终显示搜索栏",
        "Large navigation titles": "使用大号导航标题",
        "Create": "创建",
        "New Group": "新建组",
        "Scroll Up": "向上滚动",
        "Scroll Down": "向下滚动",
        "Copy Path": "复制路径",
        "View item": "查看项目",
        "Copy name": "复制名称",
        "Copy path": "复制路径",
        "Sort by..": "排序方式",
        "New..": "新建",
        "Other..": "其他…",
        "Go to..": "前往…",
        "Move to..": "移动到…",
        "Copy to..": "复制到…",
        "Create symbolic link to..": "创建符号链接到…",
        "Open App": "打开应用",
        "Open in..": "打开方式…",
        "Add to group..": "添加到组…",
        "Decompressing..": "正在解压…",
        "Compressing..": "正在压缩…",
        "Extract to..": "提取到…",
        "Extracting..": "正在提取…",
        "Layout": "布局",
        "Horizontal": "横向",
        "Vertical": "纵向",
        "Grid": "网格",
        "Collapse Section": "折叠分组",
        "Expand Section": "展开分组",
        "Copy Image": "复制图片",
        "Save Image": "保存图片",
        "Set as wallpaper for..": "设置为墙纸…",
        "Lock Screen": "锁定屏幕",
        "Home Screen": "主屏幕",
        "Home Screen & Lock Screen": "主屏幕与锁定屏幕",
        "Backward / Forward duration": "后退/前进时长",
        "Speed": "播放速度",
        "Zoom in": "放大",
        "Zoom out": "缩小",
        "Dismiss": "关闭",
        "View": "查看",
        "Path": "路径",
        "Launch Path": "启动路径",
        "Custom Launch Path": "自定义启动路径",
        "Last Opened Path": "上次打开的路径",
        "Views": "界面",
        "Types": "类型",
        "Generic": "通用",
        "Audio": "音频",
        "Document": "文稿",
        "Date Metadata": "日期元数据",
        "Style": "样式",
        "URL": "URL",
        "Designer": "设计者",
        "Manufacturer": "制造商",
        "Version": "版本",
        "Latitude": "纬度",
        "Longitude": "经度",
        "Font": "字体",
        "Text Color": "文本颜色",
        "Editor Background Color": "编辑器背景色",
        "Fonts": "字体",
        "Lines": "行",
        "Colors": "颜色",
        "Show Line Count": "显示行数",
        "Wrap Lines": "自动换行",
        "Use Character Pairs": "使用字符配对",
        "SDK Version": "SDK 版本",
        "URL schemes": "URL 方案",
        "Team ID": "团队 ID",
        "Deletable": "可删除",
        "Beta app": "测试版应用",
        "Restricted": "受限",
        "Containerized": "已容器化",
        "Container URL": "容器路径",
        "Bundle URL": "Bundle 路径",
        "Display name": "显示名称",
        "MIME Type": "MIME 类型",
        "Alias": "别名",
        "ID": "ID",
        "Set": "设置",
        "Invalid ID": "ID 无效",
        "ID range": "UID/GID 范围：-2…501",
        "Unknown Type": "未知类型",
        "Removed": "已移除",
        "Unknown Mode": "未知模式",
        "SRGB": "sRGB",
        "Display P3": "Display P3",
        "Universal": "通用",
        "CarPlay": "CarPlay",
        "Marketing": "营销",
        "Mac Catalyst": "Mac Catalyst",
        "Any": "任意",
        "High Contrast": "高对比度",
        "High Contrast Dark": "高对比度深色",
        "High Contrast Light": "高对比度浅色",
        "Image": "图像",
        "Icon": "图标",
        "Image Set": "图像集",
        "Multisize Image Set": "多尺寸图像集",
        "PDF": "PDF",
        "Color": "颜色",
        "SVG (Vector)": "SVG（矢量）",
        "Raw Data": "原始数据",
        "Unknown": "未知",
        "Zip": "ZIP",
        "Tar": "TAR",
        "7z": "7Z",
        "7-Zip": "7-Zip",
        "File associations": "文件关联",
        "File association": "文件关联",
        "Invalid file extension": "文件后缀无效",
        "Viewer": "查看器",
        "Default viewer": "默认查看器",
        "File extension": "文件后缀",
        "Add association": "添加文件关联",
        "Edit association": "编辑文件关联",
        "Open in": "打开方式",
        "Preparing...": "准备中…",
        "Cancelling...": "正在取消…",
        "Completed": "已完成",
        "Cancel current filesystem operation": "取消当前文件系统操作",
        "SQL": "SQL",
        "Execute arbitrary SQLite SQL.": "执行任意 SQLite SQL。",
        "SQL execution failed": "SQL 执行失败",
        "Unable to open item": "无法打开项目",
        "To enable Santander Helper.": "要启用 Root 助手。",
        "Date Added": "添加日期",
        "Date accessed": "访问日期",
        "Execution": "执行",
        "Extracting to..": "正在提取到…",
        "File Attributes": "文件属性",
        "Go to": "前往路径",
        "Metadata": "元数据",
        "Real Path": "真实路径",
        "Bundle ID": "Bundle ID",
        "Key": "键",
        "Value": "值",
        "File locked": "文件已锁定",
        "文件已锁定": "文件已锁定",
        "无法修改文件锁定状态": "无法修改文件锁定状态",
        "点击切换权限": "点击切换权限",
        "Date Label": "日期",
        "Hex Editor": "十六进制编辑器",
        "SQLite3 Editor": "SQLite3 编辑器",
        "Terminal": "终端",
        "This folder is empty": "此文件夹为空",
        "Full filesystem": "整个文件系统",
        "Batch Rename": "批量重命名",
        "No results": "无结果",
        "Search entire filesystem": "搜索整个文件系统",
        "Greater than 100 MB": "大于 100 MB",
        "Older than 7 days": "超过 7 天",
        "Are you sure you want to delete this item?": "确定要删除此项目吗？",
        "Unable to delete app": "无法删除应用",
        "Unable to open app": "无法打开应用",
        "Unable to save image": "无法保存图片",
        "无法设置壁纸": "无法将图片设置为墙纸",
        "Failed to edit item": "编辑项目失败",
        "Unable to update items": "无法更新项目",
        "Unable to edit item": "无法编辑项目",
        "Failed to delete item": "删除项目失败",
        "Unable to write to file": "无法写入文件",
        "Unable to save to file": "无法保存文件",
        "Unsaved changes": "未保存的更改",
        "Can't write to Property List file": "无法写入属性列表文件",
        "Unable to launch process": "无法启动进程",
        "Remove image location?": "移除图片位置？",
        "Failed to display image.": "无法显示图片。",
        "The key already exists.": "键已存在。",
        "Hex data must contain an even number of characters.": "十六进制数据必须包含偶数个字符。",
        "The data contains an invalid hexadecimal byte.": "数据包含无效的十六进制字节。",
        "Unable to set date of image": "无法设置图片日期",
        "Unable to set location of image": "无法设置图片位置",
        "无法删除项目": "无法移除项目",
        "Failed to import file": "导入文件失败",
        "Failed to copy item": "复制项目失败",
        "Failed to delete item and update contents of file": "删除项目并更新文件内容失败",
        "Unable to extract items": "无法提取项目",
        "无法读取属性列表格式。": "无法获取属性列表格式",
        "Unable to authenticate": "无法进行身份验证",
        "Unable to set path as Launch Path": "无法将路径设置为启动路径",
        "Enter the other path you want to be opened at launch": "请输入启动时要打开的其他路径",
        "URL(s) being imported to app, would you like to copy it to another path?": "正在向应用导入 URL，是否要将其复制到其他路径？",
        "Enter the destination directory.": "请输入目标目录。",
        "Enter an empty or existing mount point.": "请输入空的或现有的挂载点。",
        "No path to paste.": "没有可粘贴的路径。",
        "Failed to copy item to current directory.": "复制项目到当前目录失败。",
        "Group with same name already exists": "同名组已存在",
        "The ID must be between -2 and 501.": "ID 必须介于 -2 和 501 之间。",
        "SantanderHelper returned non-zero status, error: \\(ret.standardError)": "Root 助手返回错误：\\(ret.standardError)",
        "Root helper failed with status \\(result.status)": "Root 助手失败，状态码：\\(result.status)",
        "Unable to configure helper pipes: \\(String(cString: strerror(errno)))": "无法配置 Root 助手管道：\\(String(cString: strerror(errno)))",
        "Unable to attach process output pipe.": "无法连接进程输出管道。",
        "Unable to create stdout pipe.": "无法创建标准输出管道。",
        "Unable to create stderr pipe.": "无法创建标准错误管道。",
        "Unable to initialize process actions.": "无法初始化进程操作。",
        "Executable URL is missing.": "缺少可执行文件路径。",
        "Asset catalog does not exist: \\(url.path)": "资源目录不存在：\\(url.path)",
        "CoreUI CUICatalog is unavailable on this OS.": "当前系统无法使用 CoreUI 资源目录。",
        "CoreUI asset writing is unavailable on this iOS version.": "此 iOS 版本不支持 CoreUI 资源写入。",
        "CoreUI failed to save the asset catalog.": "CoreUI 保存资源目录失败。",
        "CoreUI storage does not expose a writable catalog method.": "CoreUI 存储未提供可写入资源目录的方法。",
        "No input paths were supplied.": "未提供输入路径。",
        "Compression format must be zip, tar or 7z": "压缩格式必须是 ZIP、TAR 或 7Z",
        "Unable to write item data to file: \\(error.localizedDescription)": "无法将项目数据写入文件：\\(error.localizedDescription)",
        "Permission Denied.": "没有权限。",
        "Please enter a name.": "请输入名称。",
        "file": "文件",
        "directory": "文件夹",
        "name": "名称",
        "Group name..": "组名称…",
        "Custom Path": "自定义路径",
        "No Preview.": "无预览。",
        "Hello": "你好",
        "The quick brown fox jumps over the lazy dog and runs away.": "敏捷的棕色狐狸跳过懒狗，然后跑开了。",
        "OK": "好",
        "Error occurred: ": "发生错误：",
        "Inset Grouped": "内嵌分组",
        "N/A": "不可用",
        "Camera": "相机",
        "Lens": "镜头",
        "Location": "位置",
        "TextEditorShowLineCount": "显示行数",
        "TextEditorWrapLines": "自动换行",
        "TextEditorUseCharacterPairs": "使用字符配对",
        "Type": "类型",
        "Locked": "锁定文件",
        "Position in array": "数组中的位置",
        "Value (in base64)": "值（base64）",
        "Duplicate Key": "键重复",
        "JSON Viewer": "JSON 查看器",
        "Asset Catalog Viewer": "资源目录查看器",
        "Executable Runner": "可执行文件运行器",
        "iPhone": "iPhone",
        "iPad": "iPad",
        "TV": "电视",
        "Watch": "Apple Watch",
        "无法创建符号链接": "无法创建符号链接",
        "move": "移动",
        "copy": "复制",
        "import": "导入",
        "symlink": "符号链接",
        "Santander Helper unavailable? is your install messed up?": "Root 助手不可用，请检查安装是否完整。",
        "Unable to read SantanderHelper output": "无法读取 Root 助手输出",
        "Failed to spawn SantanderHelper": "无法启动 Root 助手",
        "Input text is invalid or empty": "输入文本无效或为空",
        "Path must be a directory": "路径必须是目录",
        "Cancel": "取消",
        "Deselect All": "取消全选",
        "Select All": "全选",
        "点击选择类型": "点击选择类型",
        "Unknown Error": "未知错误",
        "Unnamed Asset": "未命名资源",
        "Lookup Name": "查找名称",
        "Rendition Name": "资源名称",
        "Display Gamut": "显示色域",
        "Unknown Artist": "未知艺术家",
        "Select font..": "选择字体…",
        "Full name": "全名",
        "Family name": "系列名称",
        "PostScript name": "PostScript 名称",
        "Pixel Height": "像素高度",
        "Pixel Width": "像素宽度",
        "Camera Model": "相机型号",
        "Camera Manufacturer": "相机制造商",
        "Camera Software": "相机软件",
        "Lens Model": "镜头型号",
        "Lens Manufacturer": "镜头制造商",
        "No Results": "无结果",
        "Expand": "展开",
        "Collapse": "收起",
        "File": "文件",
        "Directory": "文件夹",
        "Symbolic Link": "符号链接",
        "Executable": "可执行文件",
        "Readable": "可读",
        "Writable": "可写",
        "No": "否",
        "Yes": "是",
        "How What When Where Why": "如何、什么、何时、哪里、为什么",
        "Information": "信息",
        "Don't save": "不保存",
        "Archive Viewer": "归档查看器",
        "PDF Editor": "PDF 编辑器",
        "Recent Paths": "最近路径",
        "Color Tag": "颜色标签",
        "No tag": "无标签",
        "Start number (optional)": "起始序号（可选）",
        "Date format (optional)": "日期格式（可选）",
        "Compare Fonts": "对比字体",
        "Compare": "对比",
        "Serve Path": "共享路径",
        "Server Address": "服务器地址",
        "Start Server": "启动服务器",
        "Stop Server": "停止服务器",
        "Server Running": "服务器运行中",
        "Server Stopped": "服务器已停止",
        "Install": "安装",
        "Extract": "提取",
        "Browse": "浏览",
        "Annotate": "批注",
        "Rotate Left": "向左旋转",
        "Rotate Right": "向右旋转",
        "Add Note": "添加注释",
        "Highlight": "高亮",
        "Underline": "下划线",
        "Rectangle": "矩形",
        "Stop Annotation": "停止批注",
        "PDF saved": "PDF 已保存",
        "Unable to save PDF": "无法保存 PDF",
        "No PDF pages": "没有 PDF 页面",
        "Archive is empty": "归档为空",
        "PDF optimized": "PDF 已优化",
        "Optimize": "优化",
        "Find": "查找",
        "Replace with": "替换为",
        "Prefix": "前缀",
        "Suffix": "后缀",
        "Apply": "应用",
        "Go": "前往",
        "Search files and folders": "搜索文件和文件夹",
        "Default sorting": "默认排序",
        "Use line wrapping in text editors": "文本编辑器自动换行",
        "Show line numbers in text editors": "文本编辑器显示行号",
        "Automatically insert character pairs": "自动补全成对字符",
        "Greater than 1 GB": "大于 1 GB",
        "Current Page": "当前页面",
        "Play queue": "播放队列",
        "Next track": "下一首",
        "Previous track": "上一首",
        "Queue": "队列",
    ]
}

private enum SantanderAppTheme {
    enum Appearance: Int, CaseIterable {
        case system = 0
        case light = 1
        case dark = 2

        var title: String {
            switch self {
            case .system: return "跟随系统"
            case .light: return "浅色"
            case .dark: return "深色"
            }
        }

        var userInterfaceStyle: UIUserInterfaceStyle {
            switch self {
            case .system: return .unspecified
            case .light: return .light
            case .dark: return .dark
            }
        }
    }

    enum FolderIconSet: Int, CaseIterable {
        case standard = 0
        case mac
        case linux
        case windows
        case yosemite

        var title: String {
            switch self {
            case .standard: return "默认"
            case .mac: return "Mac"
            case .linux: return "Linux"
            case .windows: return "Windows"
            case .yosemite: return "Yosemite"
            }
        }

        var assetFolder: String { self == .standard ? "theme" : "theme/folders" }
        var assetName: String {
            switch self {
            case .standard: return "folder"
            case .mac: return "mac"
            case .linux: return "linux"
            case .windows: return "window"
            case .yosemite: return "yosemite"
            }
        }
    }

    enum FileIconSet: Int, CaseIterable {
        case standard = 0
        case colorful
        case light

        var title: String {
            switch self {
            case .standard: return "默认"
            case .colorful: return "Colorful"
            case .light: return "Light"
            }
        }

        var assetFolder: String {
            switch self {
            case .standard: return "theme/extensions"
            case .colorful: return "theme/colorful"
            case .light: return "theme/light"
            }
        }

        var previewName: String {
            switch self {
            case .standard: return "extensions"
            case .colorful: return "colorful"
            case .light: return "light"
            }
        }
    }

    private static let appearanceKey = "SantanderAppThemeAppearanceV2"
    private static let folderIconSetKey = "SantanderFilzaFolderIconSetV1"
    private static let fileIconSetKey = "SantanderFilzaFileIconSetV1"
    static let didChangeNotification = Notification.Name("SantanderAppThemeDidChange")

    static var appearance: Appearance {
        get { Appearance(rawValue: UserDefaults.standard.integer(forKey: appearanceKey)) ?? .system }
        set { UserDefaults.standard.set(newValue.rawValue, forKey: appearanceKey) }
    }

    static var folderIconSet: FolderIconSet {
        get { FolderIconSet(rawValue: UserDefaults.standard.integer(forKey: folderIconSetKey)) ?? .standard }
        set { UserDefaults.standard.set(newValue.rawValue, forKey: folderIconSetKey) }
    }

    static var fileIconSet: FileIconSet {
        get { FileIconSet(rawValue: UserDefaults.standard.integer(forKey: fileIconSetKey)) ?? .standard }
        set { UserDefaults.standard.set(newValue.rawValue, forKey: fileIconSetKey) }
    }

    // Filza's classic blue is used consistently for navigation, selection and controls.
    static var accentColor: UIColor { .systemBlue }
    static var summary: String { "文件夹：\(folderIconSet.title) · 文件：\(fileIconSet.title) · \(appearance.title)" }

    @MainActor
    static func apply(animated: Bool = true) {
        SantanderIconLibrary.shared.invalidate()
        let windows = UIApplication.shared.connectedScenes
            .compactMap { $0 as? UIWindowScene }
            .flatMap(\.windows)
        let style = appearance.userInterfaceStyle
        let shouldAnimate = animated && !UIAccessibility.isReduceMotionEnabled

        for window in windows {
            let updates = {
                window.tintColor = accentColor
                window.overrideUserInterfaceStyle = style
                window.rootViewController?.view.setNeedsLayout()
                window.rootViewController?.view.setNeedsDisplay()
            }
            if shouldAnimate, window.isKeyWindow {
                UIView.transition(
                    with: window,
                    duration: 0.62,
                    options: [.transitionCrossDissolve, .allowAnimatedContent, .curveEaseInOut],
                    animations: updates
                )
            } else {
                updates()
            }
        }
        NotificationCenter.default.post(name: didChangeNotification, object: nil)
    }
}

private final class SantanderThemeSettingsViewController: UITableViewController {
    override func viewDidLoad() {
        super.viewDidLoad()
        applySantanderUI()
        title = "主题"
        tableView.rowHeight = 68
        tableView.estimatedRowHeight = 68
        tableView.separatorInset = UIEdgeInsets(top: 0, left: 76, bottom: 0, right: 0)
        tableView.backgroundColor = .systemGroupedBackground
        tableView.tableFooterView = UIView(frame: .zero)
    }

    override func numberOfSections(in tableView: UITableView) -> Int { 3 }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        switch section {
        case 0: return SantanderAppTheme.FolderIconSet.allCases.count
        case 1: return SantanderAppTheme.FileIconSet.allCases.count
        case 2: return 1
        default: return 0
        }
    }

    override func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        switch section {
        case 0: return "文件夹"
        case 1: return "文件图标"
        case 2: return "外观"
        default: return nil
        }
    }

    override func tableView(_ tableView: UITableView, titleForFooterInSection section: Int) -> String? {
        switch section {
        case 0: return "直接切换内置 PNG 文件夹图标包：默认、Mac、Linux、Windows 和 Yosemite；符号链接使用对应 PNG 变体。"
        case 1: return "切换文件类型 PNG 图标包：默认、Colorful 或 Light。所有图标直接读取资源目录中的 PNG。"
        case 2: return "外观可跟随系统，也可固定为浅色或深色。"
        default: return nil
        }
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = UITableViewCell(style: .subtitle, reuseIdentifier: nil)
        SantanderUI.styleCell(cell)
        var content = cell.defaultContentConfiguration()
        content.textProperties.font = .systemFont(ofSize: 17, weight: .regular)
        content.secondaryTextProperties.font = .systemFont(ofSize: 12, weight: .regular)
        content.imageProperties.maximumSize = CGSize(width: 48, height: 48)
        content.directionalLayoutMargins = NSDirectionalEdgeInsets(top: 8, leading: 14, bottom: 8, trailing: 12)

        switch indexPath.section {
        case 0:
            guard SantanderAppTheme.FolderIconSet.allCases.indices.contains(indexPath.row) else { return cell }
            let iconSet = SantanderAppTheme.FolderIconSet.allCases[indexPath.row]
            content.text = iconSet.title
            content.image = SantanderIconLibrary.shared.folderIcon(for: iconSet)
            cell.accessoryType = iconSet == SantanderAppTheme.folderIconSet ? .checkmark : .none
        case 1:
            guard SantanderAppTheme.FileIconSet.allCases.indices.contains(indexPath.row) else { return cell }
            let iconSet = SantanderAppTheme.FileIconSet.allCases[indexPath.row]
            content.text = iconSet.title
            content.image = SantanderIconLibrary.shared.themePreview(for: iconSet)
            cell.accessoryType = iconSet == SantanderAppTheme.fileIconSet ? .checkmark : .none
        case 2:
            content.text = "外观模式"
            content.secondaryText = SantanderAppTheme.appearance.title
            content.image = UIImage(systemName: "circle.lefthalf.filled")
            content.imageProperties.tintColor = SantanderAppTheme.accentColor
            cell.accessoryType = .disclosureIndicator
        default:
            break
        }

        cell.contentConfiguration = content
        cell.tintColor = SantanderAppTheme.accentColor
        return cell
    }

    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        switch indexPath.section {
        case 0:
            guard SantanderAppTheme.FolderIconSet.allCases.indices.contains(indexPath.row) else { return }
            let iconSet = SantanderAppTheme.FolderIconSet.allCases[indexPath.row]
            guard iconSet != SantanderAppTheme.folderIconSet else { return }
            UISelectionFeedbackGenerator().selectionChanged()
            SantanderAppTheme.folderIconSet = iconSet
            SantanderAppTheme.apply()
        case 1:
            guard SantanderAppTheme.FileIconSet.allCases.indices.contains(indexPath.row) else { return }
            let iconSet = SantanderAppTheme.FileIconSet.allCases[indexPath.row]
            guard iconSet != SantanderAppTheme.fileIconSet else { return }
            UISelectionFeedbackGenerator().selectionChanged()
            SantanderAppTheme.fileIconSet = iconSet
            SantanderAppTheme.apply()
        case 2:
            let actions = SantanderAppTheme.Appearance.allCases.map { mode in
                SantanderActionSheetItem(
                    title: mode.title,
                    image: UIImage(systemName: mode == .system ? "iphone" : (mode == .light ? "sun.max" : "moon")),
                    isSelected: mode == SantanderAppTheme.appearance
                ) {
                    UISelectionFeedbackGenerator().selectionChanged()
                    SantanderAppTheme.appearance = mode
                    SantanderAppTheme.apply()
                }
            }
            presentSantanderActionSheet(title: "外观模式", actions: actions + [SantanderActionSheetItem(title: "取消", style: .cancel)])
        default:
            break
        }
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        if isViewLoaded { tableView.reloadData() }
    }
}

@MainActor
private enum SantanderUI {
    static func installBackground(in window: UIWindow) {
        window.backgroundColor = .systemBackground
        window.tintColor = SantanderAppTheme.accentColor
        window.overrideUserInterfaceStyle = SantanderAppTheme.appearance.userInterfaceStyle
        window.isOpaque = true
        if let root = window.rootViewController {
            root.view.backgroundColor = .systemBackground
            root.view.isOpaque = true
        }
    }

    static func style(_ controller: UIViewController) {
        controller.view.backgroundColor = .systemBackground
        controller.view.tintColor = SantanderAppTheme.accentColor
        controller.view.isOpaque = true
        if let navigationController = controller.navigationController {
            navigationController.view.backgroundColor = .systemBackground
            navigationController.view.isOpaque = true
            configureNavigationBar(navigationController.navigationBar)
        }
        if let tableController = controller as? UITableViewController {
            styleTable(tableController.tableView)
        }
        controller.tabBarController?.tabBar.tintColor = SantanderAppTheme.accentColor
        if let tabController = controller as? UITabBarController {
            tabController.tabBar.tintColor = SantanderAppTheme.accentColor
        }
    }


    static func styleTable(_ table: UITableView) {
        table.backgroundColor = .systemBackground
        table.backgroundView = nil
        table.isOpaque = true
        table.separatorColor = .separator
        table.separatorInset = UIEdgeInsets(top: 0, left: 20, bottom: 0, right: 0)
        if #available(iOS 15.0, *) {
            table.sectionHeaderTopPadding = 0
        }
        table.delaysContentTouches = false
    }

    static func styleCell(_ cell: UITableViewCell) {
        cell.backgroundColor = .systemBackground
        cell.contentView.backgroundColor = .systemBackground
        cell.backgroundConfiguration = nil
        cell.selectedBackgroundView = UIView()
        cell.selectedBackgroundView?.backgroundColor = SantanderAppTheme.accentColor.withAlphaComponent(0.10)
        cell.selectionStyle = .default
    }

    private static let cachedNavigationBarAppearance: UINavigationBarAppearance = {
        let appearance = UINavigationBarAppearance()
        appearance.configureWithOpaqueBackground()
        appearance.backgroundColor = .systemBackground
        appearance.shadowColor = .separator
        return appearance
    }()

    static func configureNavigationBar(_ navigationBar: UINavigationBar) {
        let appearance = cachedNavigationBarAppearance
        navigationBar.standardAppearance = appearance
        navigationBar.scrollEdgeAppearance = appearance
        navigationBar.compactAppearance = appearance
        navigationBar.tintColor = SantanderAppTheme.accentColor
        navigationBar.isTranslucent = false
    }
}

extension UIViewController {
    @MainActor
    func applySantanderUI() {
        SantanderUI.style(self)
        NotificationCenter.default.removeObserver(self, name: SantanderAppTheme.didChangeNotification, object: nil)
        NotificationCenter.default.addObserver(
            self,
            selector: #selector(santanderThemeDidChange(_:)),
            name: SantanderAppTheme.didChangeNotification,
            object: nil
        )
    }

    @objc fileprivate func santanderThemeDidChange(_ notification: Notification) {
        guard isViewLoaded else { return }
        view.tintColor = SantanderAppTheme.accentColor
        refreshSantanderLists(in: view)
        view.setNeedsLayout()
    }

    private func refreshSantanderLists(in root: UIView) {
        if let table = root as? UITableView {
            table.reloadData()
            return
        }
        if let collection = root as? UICollectionView {
            collection.reloadData()
            return
        }
        for child in root.subviews {
            refreshSantanderLists(in: child)
        }
    }
}

fileprivate struct SantanderActionSheetItem {
    enum Style {
        case normal
        case destructive
        case cancel
    }

    let title: String
    let subtitle: String?
    let image: UIImage?
    let style: Style
    let isSelected: Bool
    let handler: (() -> Void)?

    init(
        title: String,
        subtitle: String? = nil,
        image: UIImage? = nil,
        style: Style = .normal,
        isSelected: Bool = false,
        handler: (() -> Void)? = nil
    ) {
        self.title = title
        self.subtitle = subtitle
        self.image = image
        self.style = style
        self.isSelected = isSelected
        self.handler = handler
    }
}

@MainActor
fileprivate final class SantanderActionSheetController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    private let heading: String?
    private let message: String?
    private let items: [SantanderActionSheetItem]
    private let cancelItem: SantanderActionSheetItem?
    private let headerStack = UIStackView()
    private let titleLabel = UILabel()
    private let messageLabel = UILabel()
    private let tableView = UITableView(frame: .zero, style: .plain)
    private let cancelButton = UIButton(type: .system)

    init(title: String?, message: String?, actions: [SantanderActionSheetItem]) {
        heading = title
        self.message = message
        items = actions.filter { $0.style != .cancel }
        cancelItem = actions.first { $0.style == .cancel }
        super.init(nibName: nil, bundle: nil)
        modalPresentationStyle = .pageSheet

        if #available(iOS 15.0, *), let sheet = sheetPresentationController {
            sheet.detents = items.count > 5 ? [.large()] : [.medium(), .large()]
            sheet.selectedDetentIdentifier = items.count > 5 ? .large : .medium
            sheet.prefersGrabberVisible = true
            sheet.prefersScrollingExpandsWhenScrolledToEdge = true
            sheet.preferredCornerRadius = 18
        }
    }

    required init?(coder: NSCoder) { fatalError("init(coder:) has not been implemented") }

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .secondarySystemGroupedBackground

        headerStack.translatesAutoresizingMaskIntoConstraints = false
        headerStack.axis = .vertical
        headerStack.alignment = .fill
        headerStack.spacing = 4

        if let heading, !heading.isEmpty {
            titleLabel.text = heading
            titleLabel.font = .preferredFont(forTextStyle: .headline)
            titleLabel.textColor = .label
            titleLabel.textAlignment = .center
            titleLabel.numberOfLines = 2
            headerStack.addArrangedSubview(titleLabel)
        }
        if let message, !message.isEmpty {
            messageLabel.text = message
            messageLabel.font = .preferredFont(forTextStyle: .footnote)
            messageLabel.textColor = .secondaryLabel
            messageLabel.textAlignment = .center
            messageLabel.numberOfLines = 3
            headerStack.addArrangedSubview(messageLabel)
        }
        headerStack.isHidden = headerStack.arrangedSubviews.isEmpty
        view.addSubview(headerStack)

        tableView.translatesAutoresizingMaskIntoConstraints = false
        tableView.backgroundColor = .clear
        tableView.dataSource = self
        tableView.delegate = self
        tableView.rowHeight = 56
        tableView.estimatedRowHeight = 56
        tableView.separatorColor = .separator
        tableView.separatorInset = UIEdgeInsets(top: 0, left: 58, bottom: 0, right: 18)
        tableView.tableFooterView = UIView(frame: .zero)
        tableView.register(UITableViewCell.self, forCellReuseIdentifier: "SantanderActionSheetCell")
        view.addSubview(tableView)

        cancelButton.translatesAutoresizingMaskIntoConstraints = false
        cancelButton.setTitle(cancelItem?.title ?? SantanderL10n.t("Cancel"), for: .normal)
        cancelButton.titleLabel?.font = .preferredFont(forTextStyle: .body)
        cancelButton.setTitleColor(SantanderAppTheme.accentColor, for: .normal)
        cancelButton.backgroundColor = .tertiarySystemGroupedBackground
        cancelButton.layer.cornerRadius = 12
        cancelButton.layer.cornerCurve = .continuous
        cancelButton.addTarget(self, action: #selector(cancelTapped), for: .touchUpInside)
        view.addSubview(cancelButton)

        NSLayoutConstraint.activate([
            headerStack.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 14),
            headerStack.leadingAnchor.constraint(equalTo: view.layoutMarginsGuide.leadingAnchor),
            headerStack.trailingAnchor.constraint(equalTo: view.layoutMarginsGuide.trailingAnchor),
            tableView.topAnchor.constraint(equalTo: headerStack.bottomAnchor, constant: headerStack.isHidden ? 0 : 10),
            tableView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            tableView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            tableView.bottomAnchor.constraint(equalTo: cancelButton.topAnchor, constant: -8),
            cancelButton.leadingAnchor.constraint(equalTo: view.layoutMarginsGuide.leadingAnchor),
            cancelButton.trailingAnchor.constraint(equalTo: view.layoutMarginsGuide.trailingAnchor),
            cancelButton.heightAnchor.constraint(equalToConstant: 46),
            cancelButton.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -8)
        ])
    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        items.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "SantanderActionSheetCell", for: indexPath)
        guard items.indices.contains(indexPath.row) else { return cell }
        let item = items[indexPath.row]
        var content = cell.defaultContentConfiguration()
        content.text = item.title
        content.secondaryText = item.subtitle
        content.textProperties.color = item.style == .destructive ? .systemRed : .label
        content.secondaryTextProperties.color = .secondaryLabel
        content.image = item.image
        content.imageProperties.tintColor = item.style == .destructive ? .systemRed : .secondaryLabel
        content.directionalLayoutMargins = NSDirectionalEdgeInsets(top: 5, leading: 18, bottom: 5, trailing: 18)
        cell.contentConfiguration = content
        cell.backgroundColor = .clear
        cell.selectionStyle = .default
        cell.accessoryType = item.isSelected ? .checkmark : .none
        cell.tintColor = SantanderAppTheme.accentColor
        return cell
    }

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        guard items.indices.contains(indexPath.row) else { return }
        let handler = items[indexPath.row].handler
        dismiss(animated: true, completion: handler)
    }

    @objc private func cancelTapped() {
        let handler = cancelItem?.handler
        dismiss(animated: true, completion: handler)
    }
}

fileprivate extension UIViewController {
    /// Uses the system sheet transition on iOS 15+, with a native action-sheet fallback.
    func presentSantanderActionSheet(title: String?, message: String? = nil, actions: [SantanderActionSheetItem]) {
        var presenter: UIViewController = self
        while let presented = presenter.presentedViewController, !presented.isBeingDismissed {
            presenter = presented
        }

        if #available(iOS 15.0, *) {
            let controller = SantanderActionSheetController(title: title, message: message, actions: actions)
            presenter.present(controller, animated: true)
            return
        }

        let controller = UIAlertController(title: title, message: message, preferredStyle: .actionSheet)
        var hasCancelAction = false
        for item in actions {
            let style: UIAlertAction.Style
            switch item.style {
            case .normal: style = .default
            case .destructive: style = .destructive
            case .cancel:
                guard !hasCancelAction else { continue }
                hasCancelAction = true
                style = .cancel
            }
            let actionTitle = item.isSelected ? "✓  \(item.title)" : item.title
            controller.addAction(UIAlertAction(title: actionTitle, style: style) { _ in item.handler?() })
        }
        if !hasCancelAction {
            controller.addAction(UIAlertAction(title: SantanderL10n.t("Cancel"), style: .cancel))
        }
        if let popover = controller.popoverPresentationController {
            presenter.loadViewIfNeeded()
            guard let presenterView = presenter.viewIfLoaded else { return }
            popover.sourceView = presenterView
            let bounds = presenterView.bounds
            popover.sourceRect = CGRect(x: bounds.midX, y: bounds.maxY - 1, width: 1, height: 1)
            popover.permittedArrowDirections = []
        }
        presenter.present(controller, animated: true)
    }
}

private var santanderLongPressTargetKey: UInt8 = 0

private final class SantanderLongPressTarget: NSObject {
    weak var ownerView: UIView?
    let handler: (CGPoint) -> Void

    init(ownerView: UIView, handler: @escaping (CGPoint) -> Void) {
        self.ownerView = ownerView
        self.handler = handler
    }

    @objc func invoke(_ recognizer: UILongPressGestureRecognizer) {
        guard recognizer.state == .began, let ownerView else { return }
        handler(recognizer.location(in: ownerView))
    }
}

private enum SantanderLongPressSupport {
    static func install(on view: UIView, minimumPressDuration: TimeInterval = 0.45, cancelsTouchesInView: Bool = false, handler: @escaping (CGPoint) -> Void) {
        let target = SantanderLongPressTarget(ownerView: view, handler: handler)
        objc_setAssociatedObject(view, &santanderLongPressTargetKey, target, .OBJC_ASSOCIATION_RETAIN_NONATOMIC)
        let gesture = UILongPressGestureRecognizer(target: target, action: #selector(SantanderLongPressTarget.invoke(_:)))
        gesture.minimumPressDuration = minimumPressDuration
        gesture.cancelsTouchesInView = cancelsTouchesInView
        gesture.delaysTouchesBegan = false
        view.addGestureRecognizer(gesture)
    }
}

private enum SantanderActionSheetPresenter {
    static func present(from view: UIView, title: String?, actions: [SantanderActionSheetItem]) {
        var responder: UIResponder? = view
        while let current = responder {
            if let controller = current as? UIViewController {
                controller.presentSantanderActionSheet(title: title, actions: actions)
                return
            }
            responder = current.next
        }
        guard let scene = UIApplication.shared.connectedScenes.compactMap({ $0 as? UIWindowScene }).first,
              let root = scene.windows.first(where: \.isKeyWindow)?.rootViewController else { return }
        var controller = root
        while let presented = controller.presentedViewController { controller = presented }
        controller.presentSantanderActionSheet(title: title, actions: actions)
    }
}

private enum SantanderLocalization {
    static func install() {
        UILabel.appearance().textColor = .label
        UIButton.appearance().tintColor = .label
    }
}

@propertyWrapper
struct Storage<T> {
    let key: String
    let defaultValue: T

    init(key: String, defaultValue: T) {
        self.key = key
        self.defaultValue = defaultValue
    }

    var wrappedValue: T {
        get {
            return UserDefaults.standard.object(forKey: key) as? T ?? defaultValue
        }
        set {
            UserDefaults.standard.set(newValue, forKey: key)
        }
    }
}

@propertyWrapper
struct CodableStorage<T: Codable> {
    typealias ChangeHandler = ((T) -> ())

    let key: String
    let defaultValue: T
    var didChange: ChangeHandler?

    init(key: String, defaultValue: T, didChange: ChangeHandler?) {
        self.key = key
        self.defaultValue = defaultValue
        self.didChange = didChange
    }

    var wrappedValue: T {
        get {
            guard let data = UserDefaults.standard.data(forKey: key),
                  let decoded = try? JSONDecoder().decode(T.self, from: data) else {
                return defaultValue
            }
            return decoded
        }
        set {
            guard let encoded = try? JSONEncoder().encode(newValue) else {
                return
            }
            UserDefaults.standard.set(encoded, forKey: key)
            didChange?(newValue)
        }
    }
}

enum SantanderListDensity: Int, CaseIterable {
    case compact = 0
    case standard = 1
    case comfortable = 2

    var title: String {
        switch self {
        case .compact: return SantanderL10n.t("Compact")
        case .standard: return SantanderL10n.t("Standard")
        case .comfortable: return SantanderL10n.t("Comfortable")
        }
    }

    var rowHeight: CGFloat {
        switch self {
        case .compact: return 48
        case .standard: return 56
        case .comfortable: return 66
        }
    }
}

enum UserPreferences {
    @Storage(key: "SantanderListDensity", defaultValue: SantanderListDensity.compact.rawValue)
    static var listDensityRawValue: Int

    static var listDensity: SantanderListDensity {
        get { SantanderListDensity(rawValue: listDensityRawValue) ?? .standard }
        set { listDensityRawValue = newValue.rawValue }
    }

    static var showFileMetadata: Bool { true }

    @Storage(key: "UseLargeNavTitles", defaultValue: true)
    static var useLargeNavigationTitles: Bool


    @Storage(key: "AlwaysShowSearchBar", defaultValue: false)
    static var alwaysShowSearchBar: Bool


    @Storage(key: "LastOpenedPath", defaultValue: nil)
    static var lastOpenedPath: String?

    @Storage(key: "UseLastOpenedPathWhenLaunching", defaultValue: true)
    static var useLastOpenedPathWhenLaunching: Bool

    @Storage(key: "UserPreferredLaunchPath", defaultValue: nil)
    static var userPreferredLaunchPath: String?

    @Storage(key: "TextEditorWrapLines", defaultValue: true)
    static var wrapLines: Bool

    @Storage(key: "TextEditorShowLineCount", defaultValue: true)
    static var showLineCount: Bool

    @Storage(key: "TextEditorUseCharacterPairs", defaultValue: true)
    static var useCharacterPairs: Bool

    @Storage(key: "AudioVCSkipDuration", defaultValue: 15)
    static var skipDuration: Int

    @Storage(key: "AudioVCSpeed", defaultValue: 1)
    static var audioVCSpeed: Float

    @Storage(key: "displayHiddenFiles", defaultValue: true)
    static var displayHiddenFiles: Bool

    @Storage(key: "FontViewerFontSize", defaultValue: 30)
    static var fontViewerFontSize: CGFloat

    @Storage(key: "AssetCatalogControllerLayoutMode", defaultValue: AssetCatalogViewController.LayoutMode.verical.rawValue)
    static var assetCatalogControllerLayoutMode: Int

    @Storage(key: "RootHelperEnabled", defaultValue: true)
    static var rootHelperIsEnabled: Bool

    @CodableStorage(key: "PathGroups", defaultValue: [.default], didChange: { groups in
        NotificationCenter.default.post(name: .pathGroupsDidChange, object: groups)
    })
    static var pathGroups: [PathGroup]

    static var launchPath: String? {
        useLastOpenedPathWhenLaunching ? lastOpenedPath : userPreferredLaunchPath
    }

    @CodableStorage(key: "TextEditorTheme", defaultValue: CodableTextEditorTheme(), didChange: nil)
    static var textEditorTheme: CodableTextEditorTheme

    @CodableStorage(key: "TextEditorThemeLight", defaultValue: CodableTextEditorTheme(), didChange: nil)
    static var lightTextEditorTheme: CodableTextEditorTheme

    @CodableStorage(key: "TextEditorThemeDark", defaultValue: CodableTextEditorTheme(), didChange: nil)
    static var darkTextEditorTheme: CodableTextEditorTheme

    @CodableStorage(key: "SantanderFileAssociations", defaultValue: [], didChange: { _ in
        NotificationCenter.default.post(name: .santanderFileAssociationsDidChange, object: nil)
    })
    static var fileAssociations: [SantanderFileAssociation]

    static func textEditorTheme(for style: UIUserInterfaceStyle) -> CodableTextEditorTheme {
        switch style {
        case .dark: return darkTextEditorTheme
        default: return lightTextEditorTheme
        }
    }

    static func setTextEditorTheme(_ theme: CodableTextEditorTheme, for style: UIUserInterfaceStyle) {
        switch style {
        case .dark: darkTextEditorTheme = theme
        default: lightTextEditorTheme = theme
        }
        textEditorTheme = theme
    }

    static func fileAssociationEditor(for url: URL) -> FileEditorType? {
        let path = url.lastPathComponent.lowercased()
        let candidates = fileAssociations
            .compactMap { association -> (Int, FileEditorType)? in
                guard let editor = association.editor, !association.suffix.isEmpty else { return nil }
                let suffix = association.suffix.lowercased().trimmingCharacters(in: CharacterSet(charactersIn: "."))
                guard !suffix.isEmpty,
                      path.hasSuffix("." + suffix) || path == suffix else { return nil }
                return (suffix.count, editor)
            }
            .sorted { $0.0 > $1.0 }
        return candidates.first?.1
    }

    static func setFileAssociation(suffix: String, editor: FileEditorType) {
        let normalized = suffix.trimmingCharacters(in: .whitespacesAndNewlines).trimmingCharacters(in: CharacterSet(charactersIn: ".")).lowercased()
        guard !normalized.isEmpty else { return }
        var values = fileAssociations
        values.removeAll { $0.suffix.lowercased() == normalized }
        values.append(SantanderFileAssociation(suffix: normalized, editorRawValue: editor.rawValue))
        values.sort { $0.suffix.localizedCaseInsensitiveCompare($1.suffix) == .orderedAscending }
        fileAssociations = values
    }

    static func removeFileAssociation(suffix: String) {
        let normalized = suffix.lowercased()
        fileAssociations.removeAll { $0.suffix.lowercased() == normalized }
    }

}

struct SantanderFileAssociation: Codable, Hashable {
    let suffix: String
    let editorRawValue: String

    static let defaults: [SantanderFileAssociation] = {
        var mappings: [String: FileEditorType] = [:]
        func add(_ suffixes: [String], _ editor: FileEditorType) {
            for suffix in suffixes { mappings[suffix] = editor }
        }
        add(["txt", "text", "log", "md", "markdown", "rtf", "csv", "ini", "conf", "cfg", "config", "properties", "gitignore", "dockerfile", "makefile", "diff", "patch", "xml", "xhtml", "yaml", "yml", "toml", "c", "h", "cc", "cpp", "hpp", "m", "mm", "swift", "js", "jsx", "ts", "tsx", "html", "htm", "css", "scss", "less", "java", "kt", "rs", "go", "sql", "strings", "stringsdict", "coffee", "cs", "php", "vue", "dart", "lua", "pl", "rb", "r", "sh", "fish", "zsh", "bash"], .text)
        add(["plist"], .propertyList)
        add(["json"], .json)
        add(["sh", "bash", "zsh", "command", "script", "py", "pl", "rb", "fish"], .terminal)
        add(["jpg", "jpeg", "jpe", "png", "gif", "bmp", "tif", "tiff", "heic", "heif", "webp", "ico", "icns", "psd", "svg", "dng", "raw", "nef", "cr2", "xcf", "cur", "xbm"], .image)
        add(["mp4", "m4v", "mov", "mkv", "avi", "wmv", "webm", "flv", "mpg", "mpeg", "3gp", "3g2", "ogv", "ts", "m2ts"], .video)
        add(["mp3", "m4a", "m4r", "wav", "aiff", "aif", "caf", "flac", "aac", "ogg", "oga", "opus", "mid", "midi", "wma", "ape"], .audio)
        add(["pdf"], .pdf)
        add(["sqlite", "sqlite3", "db", "db3", "s3db"], .sqlite)
        add(["zip", "tar", "tgz", "tbz", "tbz2", "tar.gz", "tar.bz2", "tar.xz", "7z", "rar", "xz", "iso", "dmg", "deb", "ipa"], .archive)
        add(["hex", "dat", "bin", "dylib", "so", "o", "a"], .hex)
        add(["car"], .assetCatalog)
        return mappings.map { SantanderFileAssociation(suffix: $0.key, editorRawValue: $0.value.rawValue) }
            .sorted { $0.suffix.localizedCaseInsensitiveCompare($1.suffix) == .orderedAscending }
    }()

    var editor: FileEditorType? {
        FileEditorType(rawValue: editorRawValue)
    }

    var normalizedSuffix: String {
        suffix.trimmingCharacters(in: .whitespacesAndNewlines)
            .trimmingCharacters(in: CharacterSet(charactersIn: "."))
            .lowercased()
    }
}

private extension Notification.Name {
    static let santanderFileAssociationsDidChange = Notification.Name("SantanderFileAssociationsDidChange")
}

struct PathGroup: Codable, Hashable {
    let name: String
    var paths: [URL]

    static let `default`: PathGroup = {
        let mobileHome = URL(fileURLWithPath: "/var/mobile", isDirectory: true)
        let documents = mobileHome.appendingPathComponent("Documents", isDirectory: true)
        let applications = URL(fileURLWithPath: "/Applications", isDirectory: true)
        return PathGroup(name: "收藏夹", paths: [documents, applications, .root])
    }()

    func hash(into hasher: inout Hasher) {
        hasher.combine(name)
        hasher.combine(paths)
    }
}

private enum SantanderInitialPreferences {
    static func migrateToFilzaDefaultsIfNeeded() {
        let defaults = UserDefaults.standard

        // Preserve the legacy preference key so existing installs retain their setting.
        // Force the existing preference on so upgrades from older builds do not keep a stale false value.
        defaults.set(true, forKey: "RootHelperEnabled")

        let migrationKey = "SantanderFilzaDefaultsSeededV3"
        guard !defaults.bool(forKey: migrationKey) else { return }

        if defaults.object(forKey: "SantanderListDensity") == nil {
            defaults.set(SantanderListDensity.compact.rawValue, forKey: "SantanderListDensity")
        }

        let savedGroups = UserPreferences.pathGroups
        let wasStockRootOnly = savedGroups.count == 1
            && savedGroups[0].name == "Default"
            && savedGroups[0].paths.count == 1
            && savedGroups[0].paths[0].standardizedFileURL.path == "/"
        let defaultGroup = PathGroup.default
        if savedGroups.isEmpty || wasStockRootOnly {
            UserPreferences.pathGroups = [defaultGroup]
        } else if let defaultIndex = savedGroups.firstIndex(where: { $0.name == defaultGroup.name }) {
            var updatedGroups = savedGroups
            var mergedPaths = defaultGroup.paths
            for savedPath in savedGroups[defaultIndex].paths {
                if !mergedPaths.contains(where: { $0.standardizedFileURL.path == savedPath.standardizedFileURL.path }) {
                    mergedPaths.append(savedPath)
                }
            }
            updatedGroups[defaultIndex] = PathGroup(name: defaultGroup.name, paths: mergedPaths)
            UserPreferences.pathGroups = updatedGroups
        } else {
            UserPreferences.pathGroups = [defaultGroup] + savedGroups
        }

        let defaultsBySuffix = Dictionary(uniqueKeysWithValues: SantanderFileAssociation.defaults.map { ($0.normalizedSuffix, $0) })
        var associations = UserPreferences.fileAssociations
        let existingSuffixes = Set(associations.map { $0.normalizedSuffix })
        associations.append(contentsOf: defaultsBySuffix.values.filter { !existingSuffixes.contains($0.normalizedSuffix) })
        associations.sort { $0.normalizedSuffix.localizedCaseInsensitiveCompare($1.normalizedSuffix) == .orderedAscending }
        UserPreferences.fileAssociations = associations

        defaults.set(true, forKey: migrationKey)
    }
}

protocol BaseLayoutAnchorSupporting {
    var leadingAnchor: NSLayoutXAxisAnchor { get }
    var trailingAnchor: NSLayoutXAxisAnchor { get }
    var topAnchor: NSLayoutYAxisAnchor { get }
    var bottomAnchor: NSLayoutYAxisAnchor { get }
}

extension UILayoutGuide: BaseLayoutAnchorSupporting {}
extension UIView: BaseLayoutAnchorSupporting {
    func constraintCompletely(to otherView: BaseLayoutAnchorSupporting) {
        NSLayoutConstraint.activate([
            self.leadingAnchor.constraint(equalTo: otherView.leadingAnchor),
            self.trailingAnchor.constraint(equalTo: otherView.trailingAnchor),
            self.topAnchor.constraint(equalTo: otherView.topAnchor),
            self.bottomAnchor.constraint(equalTo: otherView.bottomAnchor)
        ])
    }
}

enum PathType: CustomStringConvertible {
    case file, directory

    var description: String {
        switch self {
        case .file:
            return SantanderL10n.t("file")
        case .directory:
            return SantanderL10n.t("directory")
        }
    }
}

extension UIViewController {
    func presentAlertAndCreate(type: PathType, forURL url: URL) {
        let alert = UIAlertController(title: "\(SantanderL10n.t("New")) \(SantanderL10n.t(type.description))", message: nil, preferredStyle: .alert)
        alert.addTextField { textField in
            textField.placeholder = SantanderL10n.t("name")
        }

        let createAction = UIAlertAction(title: SantanderL10n.t("Create"), style: .default) { _ in
            guard let name = alert.textFields?.first?.text, !name.isEmpty else {
                return
            }

            let urlToCreate = url.appendingPathComponent(name)
            do {
                switch type {
                case .file:
                    try FSOperation.perform(.createFile(files: [urlToCreate]), rootHelperConf: RootConf.shared)
                case .directory:
                    try FSOperation.perform(.createDirectory(directories: [urlToCreate]), rootHelperConf: RootConf.shared)
                }
            } catch {
                self.errorAlert(error, title: "无法创建 \(name)")
            }
        }

        alert.addAction(.cancel())
        alert.addAction(createAction)
        self.present(alert, animated: true)
    }
}

enum PathsSortMethods: String, CaseIterable, CustomStringConvertible {
    case alphabetically
    case size
    case type
    case dateCreated
    case dateModified
    case dateAccessed
    case dateAdded

    static var userPrefered: PathsSortMethods? {
        if let string = UserDefaults.standard.string(forKey: "SubPathsSortMode"), let sortMode = PathsSortMethods(rawValue: string) {
            return sortMode
        }
        return nil
    }

    var description: String {
        switch self {
        case .alphabetically:
            return SantanderL10n.t("Alphabetical order")
        case .size:
            return SantanderL10n.t("Size")
        case .type:
            return SantanderL10n.t("Type")
        case .dateCreated:
            return SantanderL10n.t("Date created")
        case .dateModified:
            return SantanderL10n.t("Date modified")
        case .dateAccessed:
            return SantanderL10n.t("Date accessed")
        case .dateAdded:
            return SantanderL10n.t("Date Added")
        }
    }

    func sorting(URLs urls: [Path], sortOrder: SortOrder) -> [Path] {
        struct SortRecord {
            let path: Path
            let name: String
            let normalizedPath: String
            let typeIdentifier: String
            let fileSize: Int
            let creationDate: Date?
            let modifiedDate: Date?
            let accessedDate: Date?
            let addedDate: Date?
        }

        let keys: Set<URLResourceKey> = [
            .fileSizeKey, .fileAllocatedSizeKey, .totalFileAllocatedSizeKey,
            .creationDateKey, .contentModificationDateKey, .contentAccessDateKey,
            .addedToDirectoryDateKey
        ]
        let records = urls.map { path -> SortRecord in
            let values = try? path.url.resourceValues(forKeys: keys)
            let fileSize = path.isDirectory ? 0 : (values?.fileSize
                ?? values?.totalFileAllocatedSize
                ?? values?.fileAllocatedSize
                ?? 0)
            return SortRecord(
                path: path,
                name: path.lastPathComponent,
                normalizedPath: path.url.standardizedFileURL.path,
                typeIdentifier: path.contentType?.identifier ?? path.url.pathExtension.lowercased(),
                fileSize: fileSize,
                creationDate: values?.creationDate,
                modifiedDate: values?.contentModificationDate,
                accessedDate: values?.contentAccessDate,
                addedDate: values?.addedToDirectoryDate
            )
        }

        let defaultAscending: Bool = self == .alphabetically || self == .type
        let ascending = sortOrder == .ascending ? defaultAscending : !defaultAscending

        func compare<T: Comparable>(_ lhs: T, _ rhs: T) -> ComparisonResult {
            if lhs < rhs { return .orderedAscending }
            if lhs > rhs { return .orderedDescending }
            return .orderedSame
        }

        func compareOptional<T: Comparable>(_ lhs: T?, _ rhs: T?) -> ComparisonResult {
            switch (lhs, rhs) {
            case let (left?, right?): return compare(left, right)
            case (nil, nil): return .orderedSame
            case (nil, _?): return .orderedDescending
            case (_?, nil): return .orderedAscending
            }
        }

        return records.sorted { lhs, rhs in
            let primary: ComparisonResult
            switch self {
            case .alphabetically:
                primary = lhs.name.localizedStandardCompare(rhs.name)
            case .size:
                primary = compare(lhs.fileSize, rhs.fileSize)
            case .type:
                primary = lhs.typeIdentifier.localizedStandardCompare(rhs.typeIdentifier)
            case .dateCreated:
                primary = compareOptional(lhs.creationDate, rhs.creationDate)
            case .dateModified:
                primary = compareOptional(lhs.modifiedDate, rhs.modifiedDate)
            case .dateAccessed:
                primary = compareOptional(lhs.accessedDate, rhs.accessedDate)
            case .dateAdded:
                primary = compareOptional(lhs.addedDate, rhs.addedDate)
            }

            let comparison: ComparisonResult
            if primary != .orderedSame {
                comparison = primary
            } else {
                let byName = lhs.name.localizedStandardCompare(rhs.name)
                comparison = byName == .orderedSame
                    ? lhs.normalizedPath.localizedStandardCompare(rhs.normalizedPath)
                    : byName
            }
            return ascending ? comparison == .orderedAscending : comparison == .orderedDescending
        }.map(\.path)
    }
}

enum SortOrder: String, CaseIterable, CustomStringConvertible {
    case ascending, descending

    init(rawValue: String) {
        switch rawValue.lowercased() {
        case "ascending":
            self = .ascending
        case "descending":
            self = .descending
        default:
            self = .ascending
        }
    }

    static var userPreferred: SortOrder {
        guard let rawValue = UserDefaults.standard.string(forKey: "SortOrder") else {
            return .ascending
        }
        return self.init(rawValue: rawValue)
    }

    @discardableResult
    static func toggleUserPreferred() -> SortOrder {
        let nextOrder = userPreferred.toggling()
        UserDefaults.standard.set(nextOrder.rawValue, forKey: "SortOrder")
        return nextOrder
    }

    var description: String {
        switch self {
        case .ascending:
            return SantanderL10n.t("Ascending")
        case .descending:
            return SantanderL10n.t("Descending")
        }
    }

    var imageSymbolName: String {
        switch self {
        case .ascending:
            return "chevron.up"
        case .descending:
            return "chevron.down"
        }
    }

    func toggling() -> SortOrder {
        switch self {
        case .ascending:
            return .descending
        case .descending:
            return .ascending
        }
    }
}

private final class SantanderIconLibrary {
    static let shared = SantanderIconLibrary()

    private let cache = NSCache<NSString, UIImage>()
    private let lock = NSLock()
    private let resourceBundles: [Bundle] = [Bundle.main]

    func invalidate() {
        lock.lock()
        cache.removeAllObjects()
        lock.unlock()
    }

    private func key(_ folder: String, _ filename: String, scale: CGFloat) -> NSString {
        "\(folder)/\(filename)#\(scale)" as NSString
    }

    private func image(folder: String, filename: String, scale: CGFloat = 1) -> UIImage? {
        let cacheKey = key(folder, filename, scale: scale)
        lock.lock()
        if let cached = cache.object(forKey: cacheKey) {
            lock.unlock()
            return cached
        }
        lock.unlock()

        for bundle in resourceBundles {
            var candidates: [URL] = []
            if let url = bundle.url(forResource: filename, withExtension: nil, subdirectory: folder) {
                candidates.append(url)
            }
            if let rootURL = bundle.resourceURL {
                candidates.append(rootURL.appendingPathComponent(folder, isDirectory: true).appendingPathComponent(filename))
                candidates.append(rootURL.appendingPathComponent("Assets", isDirectory: true).appendingPathComponent(folder, isDirectory: true).appendingPathComponent(filename))
                candidates.append(rootURL.appendingPathComponent("Resources", isDirectory: true).appendingPathComponent("Assets", isDirectory: true).appendingPathComponent(folder, isDirectory: true).appendingPathComponent(filename))
            }
            for url in candidates where FileManager.default.fileExists(atPath: url.path) {
                guard let data = try? Data(contentsOf: url), let loaded = UIImage(data: data, scale: scale) else { continue }
                let image = loaded.withRenderingMode(.alwaysOriginal)
                lock.lock()
                cache.setObject(image, forKey: cacheKey)
                lock.unlock()
                return image
            }
        }
        return nil
    }

    private func png(folder: String, baseName: String) -> UIImage? {
        let variants: [(String, CGFloat)] = [("@3x", 3), ("@2x", 2), ("", 1)]
        for (suffix, scale) in variants {
            if let found = image(folder: folder, filename: baseName + suffix + ".png", scale: scale) {
                return found
            }
        }
        return nil
    }

    func folderIcon(for iconSet: SantanderAppTheme.FolderIconSet? = nil, isSymbolicLink: Bool = false) -> UIImage {
        let selected = iconSet ?? SantanderAppTheme.folderIconSet
        let base = selected.assetName + (isSymbolicLink ? "_link" : "")
        // Never silently revert to another folder pack: use that pack's PNG, or its explicit no-icon placeholder.
        return png(folder: selected.assetFolder, baseName: base)
            ?? png(folder: "theme", baseName: "noicon")
            ?? UIImage()
    }

    func themePreview(for iconSet: SantanderAppTheme.FileIconSet) -> UIImage? {
        png(folder: "theme", baseName: iconSet.previewName)
    }

    func uiIcon(named name: String) -> UIImage? {
        png(folder: "theme", baseName: name)
    }

    private static let interfaceAssetMap: [String: String] = [
        // Browser chrome and navigation
        "magnifyingglass": "search", "list.bullet": "list", "list.bullet.rectangle": "list",
        "square.grid.2x2": "grid", "square.grid.3x3": "grid", "star": "favorites",
        "star.slash": "favorites", "gearshape": "setting", "gear": "setting",
        "clock": "recents", "clock.arrow.circlepath": "recents", "network": "network",
        "square.stack.3d.up": "tab", "externaldrive": "network",
        // File actions
        "doc.on.clipboard": "paste_bp", "doc.on.doc": "copy", "info.circle": "file_detail",
        "pencil": "rename", "trash": "file_delete", "ellipsis": "more",
        "ellipsis.circle": "more", "square.and.arrow.up": "action", "arrowshape.turn.up.right": "openin",
        "arrow.up.forward.app": "openin", "square.and.arrow.down": "download", "arrow.down.doc": "download",
        "arrow.left.arrow.right": "move", "arrow.left.to.line": "w_back", "arrow.right.to.line": "w_next",
        "arrow.uturn.backward": "put_back", "arrow.uturn.forward": "openin", "link": "link",
        "folder.badge.plus": "new_folder", "doc.badge.plus": "new_file",
        "archivebox": "zip", "lock.fill": "lock",
        "checkmark.circle": "checkbox_selected", "checkmark.circle.fill": "selected",
        "exclamationmark.circle": "error", "arrow.triangle.2.circlepath": "sync",
        "xmark.circle": "cancel", "xmark.circle.fill": "cancel", "xmark": "cancel",
        "plus": "plus", "plus.circle": "plus", "plus.square": "plus",
        // Viewers and tools
        "photo": "image-viewer", "photo.stack": "image-viewer", "play.rectangle": "media-player",
        "book": "quicklook-viewer", "doc.text.magnifyingglass": "plist-viewer",
        "textformat": "text-editor", "textformat.abc": "text-editor", "text.alignleft": "text-editor",
        "doc.text": "text-editor", "doc.richtext": "text-editor", "curlybraces": "text-editor",
        "note.text": "text-editor", "highlighter": "text-editor", "underline": "text-editor",
        "terminal": "terminal", "terminal.fill": "terminal", "app": "apps", "app.dashed": "apps_shortcut",
        "cube.box": "box", "paintbrush": "light", "questionmark.app": "apps",
        "goforward": "fforward", "gobackward": "rewind", "gobackward.10": "rewind",
        "repeat": "repeat", "backward.fill": "rewind", "forward.fill": "fforward",
        "arrow.down.circle": "download", "externaldrive.badge.plus": "add_account"
    ]

    func interfaceIcon(for symbol: String) -> UIImage? {
        if symbol == "folder" || symbol == "folder.fill" {
            return folderIcon()
        }
        if symbol == "doc" {
            let selectedSpecial = SantanderAppTheme.fileIconSet.assetFolder + "/special"
            return png(folder: selectedSpecial, baseName: "file") ?? uiIcon(named: "noicon")
        }
        guard let asset = Self.interfaceAssetMap[symbol] else {
            return UIImage(systemName: symbol)
        }
        return uiIcon(named: asset) ?? uiIcon(named: "noicon")
    }

    func fileIcon(for path: Path) -> UIImage {
        if path.isDirectoryLike {
            return folderIcon(isSymbolicLink: path.isSymbolicLink)
        }

        let fileSetFolder = SantanderAppTheme.fileIconSet.assetFolder
        func special(_ name: String) -> UIImage? {
            png(folder: fileSetFolder + "/special", baseName: name)
        }

        if !path.isReadable {
            return special("file_blocked") ?? special("file") ?? uiIcon(named: "noicon") ?? UIImage()
        }
        if path.isSymbolicLink {
            let name = path.isExecutable ? "exec_link" : "file_link"
            return special(name) ?? special("file") ?? uiIcon(named: "noicon") ?? UIImage()
        }
        if path.isExecutable {
            return special("exec") ?? special("file") ?? uiIcon(named: "noicon") ?? UIImage()
        }

        let ext = path.pathExtension.lowercased()
        if !ext.isEmpty, let icon = png(folder: fileSetFolder, baseName: ext) {
            return icon
        }

        // Unknown extensions use the selected pack's generic-file PNG, not the legacy default pack.
        return special("file") ?? uiIcon(named: "noicon") ?? UIImage()
    }
}

private final class PathImageCache {
    static let shared = PathImageCache()
    static let didLoadNotification = Notification.Name("SantanderPathImageCacheDidLoad")

    private let cache = NSCache<NSString, UIImage>()
    private let lock = NSLock()
    private var pending = Set<String>()
    private let workerQueue: OperationQueue = {
        let queue = OperationQueue()
        queue.name = "com.Antoine.Santander.thumbnail-prefetch"
        queue.qualityOfService = .utility
        queue.maxConcurrentOperationCount = 2
        return queue
    }()

    private init() {
        cache.countLimit = 320
        cache.totalCostLimit = 36 * 1024 * 1024
    }

    static func prefetch(_ path: Path) {
        guard !path.isDirectory, path.contentType?.isOfType(.image) == true else { return }
        let url = path.url.standardizedFileURL
        let key = url.path
        let cacheKey = key as NSString
        let instance = shared

        instance.lock.lock()
        if instance.cache.object(forKey: cacheKey) != nil || instance.pending.contains(key) {
            instance.lock.unlock()
            return
        }
        instance.pending.insert(key)
        instance.lock.unlock()

        instance.workerQueue.addOperation {
            defer {
                instance.lock.lock()
                instance.pending.remove(key)
                instance.lock.unlock()
            }

            let options: [CFString: Any] = [
                kCGImageSourceCreateThumbnailFromImageAlways: true,
                kCGImageSourceThumbnailMaxPixelSize: 128,
                kCGImageSourceCreateThumbnailWithTransform: true,
                kCGImageSourceShouldCacheImmediately: true
            ]
            guard let source = CGImageSourceCreateWithURL(url as CFURL, nil),
                  let cgImage = CGImageSourceCreateThumbnailAtIndex(source, 0, options as CFDictionary) else { return }

            let image = UIImage(cgImage: cgImage)
            let cost = max(1, cgImage.bytesPerRow * cgImage.height)
            instance.cache.setObject(image, forKey: cacheKey, cost: cost)
            DispatchQueue.main.async {
                NotificationCenter.default.post(name: PathImageCache.didLoadNotification, object: url)
            }
        }
    }

    static func image(for path: Path) -> UIImage? {
        shared.cache.object(forKey: path.url.standardizedFileURL.path as NSString)
    }
}

struct Path: Hashable, ExpressibleByStringLiteral {
    static let resourceKeys: Set<URLResourceKey> = [.isDirectoryKey, .contentTypeKey]

    static let root: Path = "/"
    static let home: Path = Path(url: URL(fileURLWithPath: NSHomeDirectory()))

    var url: URL
    var lastPathComponent: String
    var isDirectory: Bool
    var contentType: UTType?

    lazy var size = _getSize()
    var displayImage: UIImage? { _displayImage() }

    var path: String {
        url.path
    }

    var displayName: String {
        FileManager.default.displayName(atPath: url.path)
    }

    var pathExtension: String {
        return url.pathExtension
    }

    var isSymbolicLink: Bool {
        var buffer = stat()
        guard lstat(url.path, &buffer) == 0 else { return false }
        return (buffer.st_mode & S_IFMT) == S_IFLNK
    }

    var isDirectoryLike: Bool {
        if isDirectory { return true }
        guard isSymbolicLink else { return false }
        var directoryFlag = ObjCBool(false)
        return FileManager.default.fileExists(atPath: url.path, isDirectory: &directoryFlag) && directoryFlag.boolValue
    }

    var isExecutable: Bool {
        FileManager.default.isExecutableFile(atPath: url.path)
    }

    var containsAppUUIDSubpaths: Bool {
        return url.pathComponents.contains("Containers") || url.pathComponents.contains("containers")
    }

    func deletingLastPathComponent() -> Path {
        return Path(url: url.deletingLastPathComponent())
    }

    func deletingPathExtension() -> Path {
        return Path(url: url.deletingPathExtension())
    }

    func appendingPathExtension(_ ext: String) -> Path {
        return Path(url: url.appendingPathExtension(ext))
    }

    func appending(_ component: String) -> Path {
        Path(url: url.appendingPathComponent(component))
    }

    func appendingURL(_ component: String) -> URL {
        url.appendingPathComponent(component)
    }

    var resolvedURL: URL {
        return (try? URL(resolvingAliasFileAt: url)) ?? url
    }

    var contents: [Path] {
        return url.contents.map(Path.init(url:))
    }

    var applicationItem: SantanderApplication? {
        if pathExtension == "app" {
            return ApplicationsManager.shared.application(forBundleURL: self.url)
        }
        return ApplicationsManager.shared.application(forContainerURL: self.url) ?? ApplicationsManager.shared.application(forDataContainerURL: self.url)
    }

    private func _getSize() -> Int? {
        if isDirectory {
            var _size: Int = 0
            for var content in contents {
                _size += content.size ?? 0
            }
            return _size
        }
        return try? url.resourceValues(forKeys: [.fileSizeKey]).fileSize
    }

    var isReadable: Bool {
        return FileManager.default.isReadableFile(atPath: url.path)
    }

    private func _displayImage() -> UIImage? {
        if let type = contentType, type.isOfType(.image), let cached = PathImageCache.image(for: self) {
            return cached
        }
        return SantanderIconLibrary.shared.fileIcon(for: self)
    }

    init(url: URL) {
        self.url = url
        self.lastPathComponent = url.lastPathComponent

        let resourceValues = try? url.resourceValues(forKeys: Self.resourceKeys)
        var directoryFlag = ObjCBool(false)
        let existsAsDirectory = FileManager.default.fileExists(atPath: url.path, isDirectory: &directoryFlag) && directoryFlag.boolValue
        self.isDirectory = resourceValues?.isDirectory == true || existsAsDirectory
        self.contentType = resourceValues?.contentType
    }

    init(stringLiteral value: StringLiteralType) {
        self.init(url: URL(fileURLWithPath: value))
    }
}

class ImageMetadata {
    let pixelWidth: Int?
    let pixelHeight: Int?

    var location: ImageLocation
    let exifInfo: ImageExifInfo?
    let cameraInfo: ImageCameraInfo?
    let dateTimeTaken: Date?

    var dictionary: [String: Any]

    func setProperties(toDictionary newDict: [String: Any], forFileURL fileURL: URL) -> Bool {
        guard let imageSource = CGImageSourceCreateWithURL(fileURL as CFURL, nil),
              let type = CGImageSourceGetType(imageSource),
              let dest = CGImageDestinationCreateWithURL(fileURL as CFURL, type, 1, nil)
        else {
            return false
        }

        CGImageDestinationAddImageFromSource(dest, imageSource, 0, newDict as CFDictionary)

        if CGImageDestinationFinalize(dest) {
            self.dictionary = newDict
            return true
        } else {
            return false
        }
    }

    convenience init?(fileURL: URL) {
        guard let imageSource = CGImageSourceCreateWithURL(fileURL as CFURL, nil),
              let dict = CGImageSourceCopyPropertiesAtIndex(imageSource, 0, nil) as? [String: Any] else {
            return nil
        }
        self.init(dictionary: dict)
    }

    init(dictionary dict: [String: Any]) {
        self.pixelWidth = dict[kCGImagePropertyPixelWidth as String] as? Int
        self.pixelHeight = dict[kCGImagePropertyPixelHeight as String] as? Int

        if let exifDict = dict[kCGImagePropertyExifDictionary as String] as? [String: Any] {
            self.exifInfo = ImageExifInfo(exifDict: exifDict)
        } else {
            self.exifInfo = nil
        }

        if let gpsDict = dict[kCGImagePropertyGPSDictionary as String] as? [String: Any] {
            let lat = gpsDict[kCGImagePropertyGPSLatitude as String] as? CLLocationDegrees
            let long = gpsDict[kCGImagePropertyGPSLongitude as String] as? CLLocationDegrees
            self.location = ImageLocation(lat: lat, long: long)
        } else {
            self.location = ImageLocation(lat: nil, long: nil)
        }

        if let tiffDict = dict[kCGImagePropertyTIFFDictionary as String] as? [String: Any] {
            self.cameraInfo = ImageCameraInfo(tiffDictionary: tiffDict)
            if let dateTime = tiffDict[kCGImagePropertyTIFFDateTime as String] as? String {
                self.dateTimeTaken = DateFormatter.EXIFDateFormatter.date(from: dateTime)
            } else {
                self.dateTimeTaken = nil
            }
        } else {
            self.cameraInfo = nil
            self.dateTimeTaken = nil
        }

        self.dictionary = dict
    }
}

struct ImageLocation {
    var lat: CLLocationDegrees?
    var long: CLLocationDegrees?

    var coordinate: CLLocationCoordinate2D? {
        guard let lat = lat, let long = long else {
            return nil
        }
        return CLLocationCoordinate2D(latitude: lat, longitude: long)
    }
}

struct ImageCameraInfo {
    let manufacturer: String?
    let model: String?
    let softwareVersion: String?

    init(tiffDictionary: [String: Any]) {
        self.manufacturer = tiffDictionary[kCGImagePropertyTIFFMake as String] as? String
        self.model = tiffDictionary[kCGImagePropertyTIFFModel as String] as? String
        self.softwareVersion = tiffDictionary[kCGImagePropertyTIFFSoftware as String] as? String
    }
}

struct ImageExifInfo {
    let apertureValue: Double?
    let brightnessValue: Double?
    let lensModel: String?
    let lensManufacturer: String?

    init(exifDict: [String: Any]) {
        self.apertureValue = exifDict[kCGImagePropertyExifApertureValue as String] as? Double
        self.brightnessValue = exifDict[kCGImagePropertyExifBrightnessValue as String] as? Double
        self.lensModel = exifDict[kCGImagePropertyExifLensModel as String] as? String
        self.lensManufacturer = exifDict[kCGImagePropertyExifLensMake as String] as? String
    }
}

enum DiffableDataSourceItem<Section: Hashable, Item: Hashable> {
    case section(Section)
    case item(Item)

    static func fromItems(_ items: [Item]) -> [DiffableDataSourceItem] {
        return items.map { item in
            return .item(item)
        }
    }
}

extension DiffableDataSourceItem: Hashable {}

protocol SantanderHelperConfiguration {
    func perform(_ operation: FSOperation) throws
}

enum FSOperation {
    case createFile(files: [URL])
    case createDirectory(directories: [URL])
    case removeItems(items: [URL])
    case rename(item: URL, newPath: URL)
    case moveItem(items: [URL], resultPath: URL)
    case copyItem(items: [URL], resultPath: URL)
    case symlink(items: [URL], resultPath: URL)
    case setPermissions(url: URL, newOctalPermissions: Int)
    case setOwnerOrGroup(url: URL, ownerName: String?, groupName: String?)
    case setLocked(url: URL, locked: Bool)
    case compress(paths: [URL], resultPath: URL, format: Compression.FormatType)
    case decompress(archive: URL, resultPath: URL)
    case extractCatalog(catalogFileURL: URL, resultPath: URL)
    case writeData(url: URL, data: Data)
    case writeString(url: URL, string: String)

    var commandLineInvokation: [String] {
        switch self {
        case .createFile(let files):
            return ["create"] + files.flatMap { ["--files", $0.path] }
        case .createDirectory(let directories):
            return ["create"] + directories.flatMap { ["--directories", $0.path] }
        case .removeItems(let items):
            return ["delete"] + items.map(\.path)
        case .rename(let item, let newPath):
            return ["rename", item.path, newPath.path]
        case .moveItem(let items, let resultPath):
            return ["move"] + items.map(\.path) + ["--destination", resultPath.path]
        case .copyItem(let items, let resultPath):
            return ["copy"] + items.map(\.path) + ["--destination", resultPath.path]
        case .symlink(let items, let resultPath):
            return ["link"] + items.map(\.path) + ["--destination", resultPath.path]
        case .setPermissions(let url, let permissions):
            return ["set-permissions", url.path, String(permissions)]
        case .setOwnerOrGroup(let url, let ownerName, let groupName):
            var arguments = ["set-owner-or-group", url.path]
            if let ownerName {
                arguments += ["--owner-name", ownerName]
            }
            if let groupName {
                arguments += ["--group-name", groupName]
            }
            return arguments
        case .setLocked(let url, let locked):
            return ["set-locked", url.path, locked ? "1" : "0"]
        case .compress(let paths, let resultPath, let format):
            return ["compress"] + paths.flatMap { ["--paths", $0.path] } +
                ["--destination", resultPath.path, "--format", format.fileExtension]
        case .decompress(let archive, let resultPath):
            return ["decompress", archive.path, "--destination", resultPath.path]
        case .extractCatalog(let catalogFileURL, let resultPath):
            return ["extract-catalog", catalogFileURL.path, "--destination", resultPath.path]
        case .writeData(let url, _):
            return ["write-data", url.path]
        case .writeString(let url, let string):
            return ["write-string", string, "--path", url.path]
        }
    }

    static func perform(_ operation: FSOperation, rootHelperConf: SantanderHelperConfiguration) throws {
        try rootHelperConf.perform(operation)
    }
}

private enum TrollStoreRootPersona {
    private typealias SetPersona = @convention(c) (UnsafeMutablePointer<posix_spawnattr_t?>, uid_t, UInt32) -> Int32
    private typealias SetPersonaID = @convention(c) (UnsafeMutablePointer<posix_spawnattr_t?>, uid_t) -> Int32

    static func configure(_ attributes: inout posix_spawnattr_t?) throws {
        let defaultHandle = UnsafeMutableRawPointer(bitPattern: -2)
        guard let defaultHandle,
              let personaSymbol = dlsym(defaultHandle, "posix_spawnattr_set_persona_np"),
              let uidSymbol = dlsym(defaultHandle, "posix_spawnattr_set_persona_uid_np"),
              let gidSymbol = dlsym(defaultHandle, "posix_spawnattr_set_persona_gid_np") else {
            throw StringError("TrollStore root persona API 不可用。请确认系统版本支持 spawnRoot，并由 TrollStore 安装带有 com.apple.private.persona-mgmt 的应用。")
        }
        let setPersona = unsafeBitCast(personaSymbol, to: SetPersona.self)
        let setUID = unsafeBitCast(uidSymbol, to: SetPersonaID.self)
        let setGID = unsafeBitCast(gidSymbol, to: SetPersonaID.self)
        let personaResult = setPersona(&attributes, 99, 1) // POSIX_SPAWN_PERSONA_FLAGS_OVERRIDE
        guard personaResult == 0 else { throw StringError("设置 TrollStore root persona 失败：\(String(cString: strerror(personaResult)))") }
        let uidResult = setUID(&attributes, 0)
        guard uidResult == 0 else { throw StringError("设置 root UID 失败：\(String(cString: strerror(uidResult)))") }
        let gidResult = setGID(&attributes, 0)
        guard gidResult == 0 else { throw StringError("设置 root GID 失败：\(String(cString: strerror(gidResult)))") }
    }
}

struct RootConf: SantanderHelperConfiguration {
    private init() {}

    static let shared = RootConf()

    private static let runningProcessLock = NSLock()
    private static var runningProcessIDs = Set<pid_t>()

    static func cancel(processID: pid_t) {
        guard processID > 0 else { return }
        _ = kill(processID, SIGTERM)
    }

    static func cancelAllRunningProcesses() {
        runningProcessLock.lock()
        let pids = runningProcessIDs
        runningProcessLock.unlock()
        for pid in pids { _ = kill(pid, SIGTERM) }
    }

    private static func registerRunningProcess(_ pid: pid_t) {
        runningProcessLock.lock()
        runningProcessIDs.insert(pid)
        runningProcessLock.unlock()
    }

    private static func unregisterRunningProcess(_ pid: pid_t) {
        runningProcessLock.lock()
        runningProcessIDs.remove(pid)
        runningProcessLock.unlock()
    }

    func contents(of path: URL) throws -> [URL] {
        let spawn = try spawn(command: try rootHelperURL(), args: ["get-contents", path.path])
        return spawn.standardOutput
            .split(separator: "\0", omittingEmptySubsequences: true)
            .map { URL(fileURLWithPath: String($0)) }
    }

    func directoryWriteAccess(at url: URL, probeRootHelper: Bool = true) -> (canWrite: Bool, viaRootHelper: Bool) {
        var mountInfo = statfs()
        if statfs(url.path, &mountInfo) == 0,
           (mountInfo.f_flags & UInt32(MNT_RDONLY)) != 0 { return (false, false) }
        var fileInfo = stat()
        if lstat(url.path, &fileInfo) == 0 {
            let immutableFlags = UInt32(UF_IMMUTABLE | SF_IMMUTABLE)
            if (UInt32(fileInfo.st_flags) & immutableFlags) != 0 { return (false, false) }
        }
        if access(url.path, W_OK) == 0 { return (true, false) }
        // A UI status refresh must never spawn a privileged process. Callers that
        // explicitly need a SantanderHelper capability check may opt in to this probe.
        guard probeRootHelper,
              UserPreferences.rootHelperIsEnabled,
              let helperURL = try? rootHelperURL(),
              let probe = try? spawn(command: helperURL, args: ["identity"], root: true),
              probe.status == 0 else { return (false, false) }
        let identity = probe.standardOutput.trimmingCharacters(in: .whitespacesAndNewlines)
        let isRoot = identity.contains("uid=0") && identity.contains("euid=0")
            && identity.contains("gid=0") && identity.contains("egid=0")
        return (isRoot, isRoot)
    }

    private func rootHelperURL() throws -> URL {
        guard let rootHelperURL = Bundle.main.url(forResource: "SantanderHelper", withExtension: nil),
              FileManager.default.fileExists(atPath: rootHelperURL.path) else {
            throw Errors.rootHelperUnavailable
        }
        return rootHelperURL
    }

    func perform(_ operation: FSOperation) throws {
        let ret: Output
        if case let .writeData(_, data) = operation {
            ret = try spawn(command: try rootHelperURL(), args: operation.commandLineInvokation, standardInputData: data)
        } else {
            ret = try spawn(command: try rootHelperURL(), args: operation.commandLineInvokation)
        }

        guard ret.status == 0 else {
            throw Errors.otherError(description: "SantanderHelper returned non-zero status, error: \(ret.standardError)")
        }
    }

    func performStreaming(
        _ operation: FSOperation,
        onStdoutLine: @escaping (String) -> Void,
        onProcessID: ((pid_t) -> Void)? = nil
    ) throws {
        var processID: pid_t = 0
        var pending = ""
        let lock = NSLock()

        let handleChunk: (Data) -> Void = { data in
            lock.lock()
            pending += String(decoding: data, as: UTF8.self)
            let parts = pending.components(separatedBy: "\n")
            pending = parts.last ?? ""
            let complete = parts.dropLast()
            lock.unlock()

            for line in complete where !line.isEmpty {
                onStdoutLine(line.trimmingCharacters(in: .newlines))
            }
        }

        let ret = try spawn(
            command: try rootHelperURL(),
            args: operation.commandLineInvokation,
            standardInputData: nil,
            onProcessCreated: { pid in
                processID = pid
                Self.registerRunningProcess(pid)
                onProcessID?(pid)
            },
            onStdoutChunk: handleChunk
        )

        if processID > 0 { Self.unregisterRunningProcess(processID) }
        lock.lock()
        let tail = pending
        pending = ""
        lock.unlock()
        if !tail.isEmpty { onStdoutLine(tail.trimmingCharacters(in: .newlines)) }

        guard ret.status == 0 else {
            throw Errors.otherError(description: "SantanderHelper returned non-zero status, error: \(ret.standardError)")
        }
    }

    func runHelper(arguments: [String], standardInputData: Data? = nil) throws {
        let result = try spawn(command: try rootHelperURL(), args: arguments, standardInputData: standardInputData)
        guard result.status == 0 else {
            let message = result.standardError.trimmingCharacters(in: .whitespacesAndNewlines)
            throw Errors.otherError(description: message.isEmpty ? "SantanderHelper failed with status \(result.status)" : message)
        }
    }

    func spawn(
        command: URL,
        args: [String],
        root: Bool = true,
        standardInputData: Data? = nil,
        onProcessCreated: ((pid_t) -> Void)? = nil,
        onStdoutChunk: ((Data) -> Void)? = nil
    ) throws -> Output {
        var stdoutPipe: [Int32] = [-1, -1]
        var stderrPipe: [Int32] = [-1, -1]
        var stdinPipe: [Int32] = [-1, -1]

        func closePipe(_ pipe: inout [Int32]) {
            if pipe.count == 2 {
                if pipe[0] >= 0 { _ = close(pipe[0]); pipe[0] = -1 }
                if pipe[1] >= 0 { _ = close(pipe[1]); pipe[1] = -1 }
            }
        }

        guard pipe(&stdoutPipe) == 0,
              pipe(&stderrPipe) == 0,
              standardInputData == nil || pipe(&stdinPipe) == 0 else {
            closePipe(&stdoutPipe); closePipe(&stderrPipe); closePipe(&stdinPipe)
            throw Errors.failedToSpawnHelper
        }

        let bufferSize = Int(BUFSIZ)
        guard fcntl(stdoutPipe[0], F_SETFL, O_NONBLOCK) != -1,
              fcntl(stderrPipe[0], F_SETFL, O_NONBLOCK) != -1 else {
            closePipe(&stdoutPipe); closePipe(&stderrPipe); closePipe(&stdinPipe)
            throw Errors.otherError(description: "Unable to configure helper pipes: \(String(cString: strerror(errno)))")
        }

        let argumentStrings = [command.lastPathComponent] + args
        let argv: [UnsafeMutablePointer<CChar>?] = argumentStrings.map { $0.withCString(strdup) }
        defer { for case let arg? in argv { free(arg) } }

        var actions: posix_spawn_file_actions_t?
        guard posix_spawn_file_actions_init(&actions) == 0 else {
            closePipe(&stdoutPipe); closePipe(&stderrPipe); closePipe(&stdinPipe)
            throw Errors.failedToSpawnHelper
        }
        defer { _ = posix_spawn_file_actions_destroy(&actions) }

        guard posix_spawn_file_actions_addclose(&actions, stdoutPipe[0]) == 0,
              posix_spawn_file_actions_addclose(&actions, stderrPipe[0]) == 0,
              posix_spawn_file_actions_adddup2(&actions, stdoutPipe[1], STDOUT_FILENO) == 0,
              posix_spawn_file_actions_adddup2(&actions, stderrPipe[1], STDERR_FILENO) == 0,
              posix_spawn_file_actions_addclose(&actions, stdoutPipe[1]) == 0,
              posix_spawn_file_actions_addclose(&actions, stderrPipe[1]) == 0 else {
            closePipe(&stdoutPipe); closePipe(&stderrPipe); closePipe(&stdinPipe)
            throw Errors.failedToSpawnHelper
        }

        if standardInputData != nil {
            guard posix_spawn_file_actions_adddup2(&actions, stdinPipe[0], STDIN_FILENO) == 0,
                  posix_spawn_file_actions_addclose(&actions, stdinPipe[0]) == 0,
                  posix_spawn_file_actions_addclose(&actions, stdinPipe[1]) == 0 else {
                closePipe(&stdoutPipe); closePipe(&stderrPipe); closePipe(&stdinPipe)
                throw Errors.failedToSpawnHelper
            }
        }

        var attr: posix_spawnattr_t?
        guard posix_spawnattr_init(&attr) == 0 else {
            closePipe(&stdoutPipe); closePipe(&stderrPipe); closePipe(&stdinPipe)
            throw Errors.failedToSpawnHelper
        }
        defer { _ = posix_spawnattr_destroy(&attr) }
        if root {
            do {
                try TrollStoreRootPersona.configure(&attr)
            } catch {
                closePipe(&stdoutPipe); closePipe(&stderrPipe); closePipe(&stdinPipe)
                throw Errors.otherError(description: "无法启用 SantanderHelper：\(error.localizedDescription)")
            }
        }

        let env = [#"PATH=/usr/local/sbin:/var/jb/usr/local/sbin:/usr/local/bin:/var/jb/usr/local/bin:/usr/sbin:/var/jb/usr/sbin:/usr/bin:/var/jb/usr/bin:/sbin:/var/jb/sbin:/bin:/var/jb/bin:/usr/bin/X11:/var/jb/usr/bin/X11:/usr/games:/var/jb/usr/games"#]
        let proenv: [UnsafeMutablePointer<CChar>?] = env.map { $0.withCString(strdup) }
        defer { for case let e? in proenv { free(e) } }

        var pid: pid_t = 0
        let spawnStatus = argv.withUnsafeBufferPointer { argvBuffer in
            proenv.withUnsafeBufferPointer { envBuffer in
                posix_spawn(&pid, command.path, &actions, &attr, argvBuffer.baseAddress, envBuffer.baseAddress)
            }
        }
        guard spawnStatus == 0 else {
            closePipe(&stdoutPipe); closePipe(&stderrPipe); closePipe(&stdinPipe)
            throw Errors.otherError(description: "Failed to spawn SantanderHelper: \(String(cString: strerror(spawnStatus)))")
        }

        let stdoutReadFD = stdoutPipe[0]
        let stderrReadFD = stderrPipe[0]
        _ = close(stdoutPipe[1]); stdoutPipe[1] = -1
        _ = close(stderrPipe[1]); stderrPipe[1] = -1
        if standardInputData != nil { _ = close(stdinPipe[0]); stdinPipe[0] = -1 }

        let dataLock = NSLock()
        var stdoutData = Data()
        var stderrData = Data()
        let queue = DispatchQueue(label: "com.Antoine.Santander.SantanderHelper.read", qos: .userInitiated, attributes: .concurrent)
        let stdoutDone = DispatchSemaphore(value: 0)
        let stderrDone = DispatchSemaphore(value: 0)

        onProcessCreated?(pid)

        let stdoutSource = DispatchSource.makeReadSource(fileDescriptor: stdoutReadFD, queue: queue)
        let stderrSource = DispatchSource.makeReadSource(fileDescriptor: stderrReadFD, queue: queue)

        stdoutSource.setCancelHandler {
            _ = close(stdoutReadFD)
            stdoutDone.signal()
        }
        stderrSource.setCancelHandler {
            _ = close(stderrReadFD)
            stderrDone.signal()
        }

        stdoutSource.setEventHandler {
            var buffer = [UInt8](repeating: 0, count: bufferSize)
            let n = read(stdoutReadFD, &buffer, buffer.count)
            if n > 0 {
                dataLock.lock(); stdoutData.append(buffer, count: n); dataLock.unlock()
                if let onStdoutChunk { onStdoutChunk(Data(buffer[0..<n])) }
            } else if n == 0 || (n < 0 && errno != EAGAIN && errno != EINTR) {
                stdoutSource.cancel()
            }
        }
        stderrSource.setEventHandler {
            var buffer = [UInt8](repeating: 0, count: bufferSize)
            let n = read(stderrReadFD, &buffer, buffer.count)
            if n > 0 {
                dataLock.lock(); stderrData.append(buffer, count: n); dataLock.unlock()
            } else if n == 0 || (n < 0 && errno != EAGAIN && errno != EINTR) {
                stderrSource.cancel()
            }
        }

        stdoutSource.resume(); stderrSource.resume()

        if let input = standardInputData {
            let fd = stdinPipe[1]
            stdinPipe[1] = -1
            DispatchQueue.global(qos: .userInitiated).async {
                input.withUnsafeBytes { raw in
                    guard let base = raw.baseAddress else { return }
                    var offset = 0
                    while offset < raw.count {
                        let written = write(fd, base.advanced(by: offset), raw.count - offset)
                        if written > 0 { offset += written }
                        else if written < 0 && errno == EINTR { continue }
                        else { break }
                    }
                }
                _ = close(fd)
            }
        }

        var waitStatus: Int32 = 0
        var waitedPID: pid_t
        repeat {
            waitedPID = waitpid(pid, &waitStatus, 0)
        } while waitedPID == -1 && errno == EINTR
        stdoutDone.wait(); stderrDone.wait()

        dataLock.lock()
        let out = stdoutData; let err = stderrData
        dataLock.unlock()
        guard waitedPID == pid else {
            return Output(status: -1,
                          standardOutput: String(decoding: out, as: UTF8.self),
                          standardError: String(decoding: err, as: UTF8.self))
        }
        let normalExit = (waitStatus & 0x7f) == 0
        return Output(status: normalExit ? Int32((waitStatus >> 8) & 0xff) : -1,
                      standardOutput: String(decoding: out, as: UTF8.self),
                      standardError: String(decoding: err, as: UTF8.self))
    }

    fileprivate static func run(_ executable: String, _ arguments: [String], workingDirectory: String? = nil) throws -> SantanderProcessResult {
        guard let workingDirectory, !workingDirectory.isEmpty else {
            return try run(executable, arguments)
        }
        let quoted = ([executable] + arguments).map { arg in
            "'" + arg.replacingOccurrences(of: "'", with: "'\"'\"'") + "'"
        }.joined(separator: " ")
        let safeDirectory = workingDirectory.replacingOccurrences(of: "'", with: "'\"'\"'")
        let command = "cd '\(safeDirectory)' && exec \(quoted)"
        return try run("/bin/sh", ["-c", command])
    }

    struct Output {
        let status: CInt
        let standardOutput: String
        let standardError: String
    }

    var useRootHelper: Bool {
        return UserPreferences.rootHelperIsEnabled
    }

    private enum Errors: Error, LocalizedError, CustomStringConvertible {
        case rootHelperUnavailable
        case unableToReadHelperOutput
        case failedToSpawnHelper
        case otherError(description: String)

        var description: String {
            switch self {
            case .rootHelperUnavailable:
                return "Santander Helper unavailable? is your install messed up?"
            case .unableToReadHelperOutput:
                return "Unable to read SantanderHelper output"
            case .failedToSpawnHelper:
                return "Failed to spawn SantanderHelper"
            case .otherError(let description):
                return description
            }
        }

        var errorDescription: String? {
            SantanderL10n.t(description)
        }
    }
}



private struct SantanderTaskSnapshot {
    enum State: String {
        case queued, running, finished, failed, cancelled
    }

    let id: UUID
    let title: String
    let progress: Double
    let state: State
    let message: String
    let cancellable: Bool
}

private final class SantanderFileOperationQueue {
    static let shared = SantanderFileOperationQueue()

    static let didChangeNotification = Notification.Name("SantanderFileOperationQueueDidChange")

    private struct TaskRecord {
        var snapshot: SantanderTaskSnapshot
        var processID: pid_t = 0
    }

    private let queue = DispatchQueue(label: "com.Antoine.Santander.FilesystemOperationQueue", qos: .userInitiated)
    private let lock = NSLock()
    private var records: [UUID: TaskRecord] = [:]
    private var order: [UUID] = []

    private init() {}

    func snapshots() -> [SantanderTaskSnapshot] {
        lock.lock()
        let result = order.compactMap { records[$0]?.snapshot }
        lock.unlock()
        return result
    }

    @discardableResult
    func enqueue(
        title: String,
        work: @escaping (@escaping (pid_t) -> Void, @escaping (Double, String) -> Void) throws -> Void
    ) -> UUID {
        let id = UUID()
        let initial = SantanderTaskSnapshot(id: id, title: title, progress: 0, state: .queued, message: "排队中", cancellable: true)
        lock.lock()
        records[id] = TaskRecord(snapshot: initial)
        order.append(id)
        trimFinishedRecordsIfNeededLocked()
        lock.unlock()
        notify()

        queue.async { [weak self] in
            guard let self else { return }
            self.lock.lock()
            let wasCancelledBeforeStart = self.records[id]?.snapshot.state == .cancelled
            self.lock.unlock()
            guard !wasCancelledBeforeStart else { return }
            self.update(id: id, state: .running, progress: 0, message: "准备中", processID: 0)
            do {
                try work({ pid in
                    self.lock.lock()
                    self.records[id]?.processID = pid
                    self.lock.unlock()
                    self.update(id: id, state: .running, progress: 0, message: "正在执行", processID: pid)
                }, { progress, message in
                    self.update(id: id, state: .running, progress: progress, message: message, processID: nil)
                })
                self.update(id: id, state: .finished, progress: 1, message: "已完成", processID: 0)
            } catch {
                let cancelled: Bool
                self.lock.lock()
                cancelled = self.records[id]?.snapshot.state == .cancelled
                self.lock.unlock()
                self.update(id: id, state: cancelled ? .cancelled : .failed, progress: 0, message: error.localizedDescription, processID: 0)
            }
        }
        return id
    }

    func clearFinished() {
        lock.lock()
        let removable = order.filter {
            guard let state = records[$0]?.snapshot.state else { return true }
            return state == .finished || state == .failed || state == .cancelled
        }
        for id in removable { records.removeValue(forKey: id) }
        order.removeAll { removable.contains($0) }
        lock.unlock()
        notify()
    }

    func cancel(id: UUID) {
        lock.lock()
        guard var record = records[id] else { lock.unlock(); return }
        if record.snapshot.state == .queued {
            record.snapshot = SantanderTaskSnapshot(id: id, title: record.snapshot.title, progress: 0, state: .cancelled, message: "已取消", cancellable: false)
            records[id] = record
            lock.unlock()
            notify()
            return
        }
        let pid = record.processID
        record.snapshot = SantanderTaskSnapshot(id: id, title: record.snapshot.title, progress: record.snapshot.progress, state: .cancelled, message: "正在取消", cancellable: false)
        records[id] = record
        lock.unlock()
        if pid > 0 { RootConf.cancel(processID: pid) }
        notify()
    }

    private func update(id: UUID, state: SantanderTaskSnapshot.State, progress: Double, message: String, processID: pid_t?) {
        lock.lock()
        guard let record = records[id] else { lock.unlock(); return }
        let pid = processID ?? record.processID
        let cancellable = state == .queued || state == .running
        records[id] = TaskRecord(
            snapshot: SantanderTaskSnapshot(id: id, title: record.snapshot.title, progress: max(0, min(1, progress)), state: state, message: message, cancellable: cancellable),
            processID: pid
        )
        lock.unlock()
        notify()
    }

    private func trimFinishedRecordsIfNeededLocked() {
        guard order.count > 50 else { return }
        let finished = order.filter {
            guard let state = records[$0]?.snapshot.state else { return true }
            return state == .finished || state == .failed || state == .cancelled
        }
        for id in finished.prefix(max(0, order.count - 50)) {
            records.removeValue(forKey: id)
            order.removeAll { $0 == id }
        }
    }

    private func notify() {
        DispatchQueue.main.async {
            NotificationCenter.default.post(name: Self.didChangeNotification, object: self)
        }
    }
}

private final class SantanderTaskCenterViewController: UITableViewController {
    private var snapshots: [SantanderTaskSnapshot] = []

    override func viewDidLoad() {
        super.viewDidLoad()
        title = SantanderL10n.t("Tasks")
        applySantanderUI()
        navigationItem.leftBarButtonItem = UIBarButtonItem(barButtonSystemItem: .close, target: self, action: #selector(close))
        navigationItem.rightBarButtonItem = UIBarButtonItem(title: SantanderL10n.t("Clear"), style: .plain, target: self, action: #selector(clearFinished))
        NotificationCenter.default.addObserver(self, selector: #selector(refresh), name: SantanderFileOperationQueue.didChangeNotification, object: nil)
        refresh()
    }

    deinit { NotificationCenter.default.removeObserver(self) }

    @objc private func close() { dismiss(animated: true) }

    @objc private func refresh() {
        snapshots = SantanderFileOperationQueue.shared.snapshots()
        if isViewLoaded { tableView.reloadData() }
    }

    @objc private func clearFinished() {
        SantanderFileOperationQueue.shared.clearFinished()
    }

    override func numberOfSections(in tableView: UITableView) -> Int { snapshots.isEmpty ? 1 : 2 }
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if snapshots.isEmpty { return 1 }
        let active = snapshots.filter { $0.state == .queued || $0.state == .running }.count
        return section == 0 ? active : snapshots.count - active
    }

    private func record(at indexPath: IndexPath) -> SantanderTaskSnapshot? {
        guard !snapshots.isEmpty else { return nil }
        if indexPath.section == 0 {
            let active = snapshots.filter { $0.state == .queued || $0.state == .running }.sorted { $0.title.localizedStandardCompare($1.title) == .orderedAscending }
            return active.indices.contains(indexPath.row) ? active[indexPath.row] : nil
        }
        let history = snapshots.filter { $0.state != .queued && $0.state != .running }.sorted { $0.title.localizedStandardCompare($1.title) == .orderedAscending }
        return history.indices.contains(indexPath.row) ? history[indexPath.row] : nil
    }

    override func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        if snapshots.isEmpty { return nil }
        return section == 0 ? SantanderL10n.t("Active") : SantanderL10n.t("History")
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = UITableViewCell(style: .subtitle, reuseIdentifier: nil)
        SantanderUI.styleCell(cell)
        guard let snapshot = record(at: indexPath) else {
            var configuration = cell.defaultContentConfiguration()
            configuration.text = SantanderL10n.t("No Tasks")
            configuration.textProperties.color = .secondaryLabel
            cell.contentConfiguration = configuration
            cell.selectionStyle = .none
            return cell
        }
        var configuration = cell.defaultContentConfiguration()
        configuration.text = snapshot.title
        configuration.secondaryText = snapshot.state == .running || snapshot.state == .queued
            ? "\(snapshot.message) · \(Int(snapshot.progress * 100))%"
            : snapshot.message
        let statusIcon = snapshot.state == .finished ? "checkmark.circle" : snapshot.state == .failed ? "exclamationmark.circle" : snapshot.state == .cancelled ? "xmark.circle" : "arrow.triangle.2.circlepath"
        configuration.image = SantanderIconLibrary.shared.interfaceIcon(for: statusIcon)
        configuration.secondaryTextProperties.numberOfLines = 2
        cell.contentConfiguration = configuration
        if snapshot.cancellable { cell.accessoryType = .detailButton }
        return cell
    }

    override func tableView(_ tableView: UITableView, accessoryButtonTappedForRowWith indexPath: IndexPath) {
        guard let snapshot = record(at: indexPath), snapshot.cancellable else { return }
        presentSantanderActionSheet(title: "取消此任务？", message: snapshot.title, actions: [
            SantanderActionSheetItem(title: SantanderL10n.t("Cancel task"), image: SantanderIconLibrary.shared.interfaceIcon(for: "xmark.circle"), style: .destructive) {
                SantanderFileOperationQueue.shared.cancel(id: snapshot.id)
            },
            SantanderActionSheetItem(title: SantanderL10n.t("Keep task"), style: .cancel)
        ])
    }

    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        guard let snapshot = record(at: indexPath) else { return }
        tableView.deselectRow(at: indexPath, animated: true)
        var actions: [SantanderActionSheetItem] = []
        if snapshot.cancellable {
            actions.append(SantanderActionSheetItem(title: SantanderL10n.t("Cancel task"), image: SantanderIconLibrary.shared.interfaceIcon(for: "xmark.circle"), style: .destructive) {
                SantanderFileOperationQueue.shared.cancel(id: snapshot.id)
            })
        }
        actions.append(SantanderActionSheetItem(title: SantanderL10n.t("Close"), style: .cancel))
        presentSantanderActionSheet(title: snapshot.title, message: snapshot.message, actions: actions)
    }
}

protocol DirectoryMonitorDelegate: AnyObject {
    func directoryMonitorDidObserveChange(directoryMonitor: DirectoryMonitor)
}

class DirectoryMonitor {
    weak var delegate: DirectoryMonitorDelegate?

    var monitoredDirectoryFileDescriptor: CInt = -1
    let directoryMonitorQueue = DispatchQueue(label: "directorymonitor", attributes: .concurrent)
    var directoryMonitorSource: DispatchSource?
    var path: Path
    private var monitoringRequested = false

    init(path: Path) {
        self.path = path
    }

    func startMonitoring() {
        monitoringRequested = true
        guard directoryMonitorSource == nil,
              monitoredDirectoryFileDescriptor == -1,
              path.isReadable else { return }

        let descriptor = open((path.url as NSURL).fileSystemRepresentation, O_EVTONLY)
        guard descriptor >= 0 else { return }
        monitoredDirectoryFileDescriptor = descriptor

        guard let source = DispatchSource.makeFileSystemObjectSource(
            fileDescriptor: descriptor,
            eventMask: .all,
            queue: directoryMonitorQueue
        ) as? DispatchSource else {
            close(descriptor)
            monitoredDirectoryFileDescriptor = -1
            return
        }

        directoryMonitorSource = source
        source.setEventHandler { [weak self] in
            guard let self else { return }
            self.delegate?.directoryMonitorDidObserveChange(directoryMonitor: self)
        }

        source.setCancelHandler { [weak self] in
            close(descriptor)
            guard let self else { return }
            DispatchQueue.main.async { [weak self] in
                guard let self, self.monitoredDirectoryFileDescriptor == descriptor else { return }
                self.monitoredDirectoryFileDescriptor = -1
                self.directoryMonitorSource = nil
                if self.monitoringRequested {
                    self.startMonitoring()
                }
            }
        }

        source.resume()
    }

    func stopMonitoring() {
        monitoringRequested = false
        directoryMonitorSource?.cancel()
    }
}

struct GoToItem: Hashable {

    private typealias MayExistDictionary = [String: (URL?, UIImage?)]

    let displayName: String
    let url: URL
    let image: UIImage?

    init(displayName: String, url: URL, image: UIImage?) {
        self.displayName = displayName
        self.url = url
        self.image = image
    }

    private static func _searchPathDirURL(_ searchPath: FileManager.SearchPathDirectory) -> URL? {
        return FileManager.default.urls(for: searchPath, in: .userDomainMask).first
    }

    private static func _generateAll() -> [GoToItem] {
        let coreItems: [GoToItem] = [
            GoToItem(displayName: SantanderL10n.t("Root"), url: URL(fileURLWithPath: "/var/root"), image: nil),
            GoToItem(displayName: SantanderL10n.t("Home"), url: .home, image: SantanderIconLibrary.shared.uiIcon(named: "folder"))
        ]

        let mayExistDict: MayExistDictionary = [
            "Applications": (_searchPathDirURL(.applicationDirectory), .appsDirectory),
            "Library":      (_searchPathDirURL(.libraryDirectory),     .libraryDirectory),
            "Documents":    (_searchPathDirURL(.documentDirectory),    .documentDirectory),
            "Downloads":    (_searchPathDirURL(.downloadsDirectory),   .downloadsDirectory)
        ]

        let mayExistItems: [GoToItem] = mayExistDict.compactMap { (key, value) in
            let (url, image) = value
            guard let url = url, FileManager.default.fileExists(atPath: url.path) else {
                return nil
            }
            return GoToItem(displayName: SantanderL10n.t(key), url: url, image: image)
        }

        return coreItems + mayExistItems
    }

    static let all = _generateAll()
}

fileprivate extension UIImage {
    static let appsDirectory =      SantanderIconLibrary.shared.uiIcon(named: "apps_shortcut")
    static let libraryDirectory =   SantanderIconLibrary.shared.uiIcon(named: "apps")
    static let documentDirectory =  SantanderIconLibrary.shared.interfaceIcon(for: "doc")
    static let downloadsDirectory = SantanderIconLibrary.shared.interfaceIcon(for: "arrow.down.circle")
}

enum LoadingValueState<Value> {
    case loading
    case unavailable
    case value(Value)
}

struct PathMetadata {

    static let resourceValueKeys: Set<URLResourceKey> = [
        .creationDateKey, .contentAccessDateKey, .addedToDirectoryDateKey, .contentModificationDateKey,
        .contentTypeKey
    ]

    let creationDate: Date?
    let addedToDirectoryDate: Date?
    let lastModifiedDate: Date?
    let lastAccessedDate: Date?
    let contentType: UTType?
    var permissions: PathPermissions?

    init(filePath path: Path, resourceValues: Set<URLResourceKey> = resourceValueKeys) {
        let resourceValues = try? path.url.resourceValues(forKeys: resourceValues)
        self.creationDate = resourceValues?.creationDate
        self.addedToDirectoryDate = resourceValues?.addedToDirectoryDate
        self.lastModifiedDate = resourceValues?.contentModificationDate
        self.lastAccessedDate = resourceValues?.contentAccessDate
        self.contentType = resourceValues?.contentType
        self.permissions = PathPermissions(fileURL: path.url)
    }
}

protocol PathTransitioning {
    func goToPath(path: Path)
}

struct Permission: OptionSet, CustomStringConvertible, Equatable {
    public var rawValue: Int

    static let execute = Permission(rawValue: 1)
    static let write = Permission(rawValue: 2)
    static let read = Permission(rawValue: 4)

    init(rawValue: Int) {
        self.rawValue = rawValue
    }

    init(buffer: stat, constants: [UInt16: Permission]) {
        self = constants.filter { (constant, _) in
            return (buffer.st_mode & constant) != 0
        }
        .map(\.value)
        .reducingToSingleOptionSet()
    }

    var binaryRepresentation: String {
        var b = String(rawValue, radix: 2)
        while b.count < 3 { b = "0" + b }
        return b
    }

    var description: String {
        let labels = [(Permission.read, SantanderL10n.t("Read")), (Permission.write, SantanderL10n.t("Write")), (Permission.execute, SantanderL10n.t("Execute"))]
        return labels.compactMap { contains($0.0) ? "\($0.1) ✓" : nil }.joined(separator: "  ")
    }

    static func binaryRepresentation(of permissions: [Permission]) -> String {
        return permissions.map { $0.binaryRepresentation }.joined()
    }

    static func octalRepresentation(of permissions: [Permission]) -> Int {
        let binary = binaryRepresentation(of: permissions)
        return Int(binary, radix: 2)!
    }

    static let ownerPermsConstants: [UInt16: Permission] = [
        S_IRUSR: .read,
        S_IWUSR: .write,
        S_IXUSR: .execute
    ]

    static let groupPermsConstants: [UInt16: Permission] = [
        S_IRGRP: .read,
        S_IWGRP: .write,
        S_IXGRP: .execute
    ]

    static let otherUsersPermsConstants: [UInt16: Permission] = [
        S_IROTH: .read,
        S_IWOTH: .write,
        S_IXOTH: .execute
    ]
}

struct SpecialPermissionBits: OptionSet, Equatable {
    let rawValue: Int
    init(rawValue: Int) { self.rawValue = rawValue }

    static let setUID = SpecialPermissionBits(rawValue: 0o4000)
    static let setGID = SpecialPermissionBits(rawValue: 0o2000)
    static let sticky = SpecialPermissionBits(rawValue: 0o1000)
    static let all: SpecialPermissionBits = [.setUID, .setGID, .sticky]
}

struct PathPermissions: Equatable {
    let fileURL: URL
    var ownerPermissions: Permission
    var groupPermissions: Permission
    var otherUsersPermissions: Permission
    var specialPermissions: SpecialPermissionBits
    var ownerName: String?
    var groupOwnerName: String?
    var ownerID: Int32
    var groupID: Int32
    var isLocked: Bool

    static func isLocked(at fileURL: URL) -> Bool {
        var typeInfo: ObjCBool = false
        guard FileManager.default.fileExists(atPath: fileURL.path, isDirectory: &typeInfo), !typeInfo.boolValue else { return false }
        var buffer = stat()
        guard lstat(fileURL.path, &buffer) == 0 else { return false }
        return (buffer.st_flags & UInt32(UF_IMMUTABLE)) != 0
    }

    init?(fileURL: URL) {
        var buffer = stat()
        guard lstat(fileURL.path, &buffer) == 0 else {
            return nil
        }

        ownerPermissions = Permission(buffer: buffer, constants: Permission.ownerPermsConstants)
        groupPermissions = Permission(buffer: buffer, constants: Permission.groupPermsConstants)
        otherUsersPermissions = Permission(buffer: buffer, constants: Permission.otherUsersPermsConstants)
        specialPermissions = SpecialPermissionBits(rawValue: Int(buffer.st_mode) & 0o7000)
        ownerID = Int32(bitPattern: UInt32(truncatingIfNeeded: buffer.st_uid))
        groupID = Int32(bitPattern: UInt32(truncatingIfNeeded: buffer.st_gid))
        isLocked = !fileURL.isDirectory && (buffer.st_flags & UInt32(UF_IMMUTABLE)) != 0

        ownerName = SantanderIdentityDatabase.name(id: ownerID, group: false)
        groupOwnerName = SantanderIdentityDatabase.name(id: groupID, group: true)
        self.fileURL = fileURL
    }

    init(
        fileURL: URL,
        ownerPermissions: Permission,
        groupPermissions: Permission,
        otherUsersPermissions: Permission,
        specialPermissions: SpecialPermissionBits = [],
        ownerName: String? = nil,
        groupOwnerName: String? = nil,
        ownerID: Int32 = 0,
        groupID: Int32 = 0,
        isLocked: Bool = false
    ) {
        self.fileURL = fileURL
        self.ownerPermissions = ownerPermissions
        self.groupPermissions = groupPermissions
        self.otherUsersPermissions = otherUsersPermissions
        self.specialPermissions = specialPermissions
        self.ownerName = ownerName
        self.groupOwnerName = groupOwnerName
        self.ownerID = ownerID
        self.groupID = groupID
        self.isLocked = isLocked
    }

    func apply() throws {
        let rwxMode = Permission.octalRepresentation(of: [ownerPermissions, groupPermissions, otherUsersPermissions])
        let fullMode = rwxMode | specialPermissions.rawValue
        try FSOperation.perform(.setPermissions(url: fileURL, newOctalPermissions: fullMode), rootHelperConf: RootConf.shared)
    }

    mutating func applyLocked(_ locked: Bool) throws {
        var typeInfo: ObjCBool = false
        guard FileManager.default.fileExists(atPath: fileURL.path, isDirectory: &typeInfo), !typeInfo.boolValue else {
            throw StringError("文件夹不支持文件锁定状态。")
        }
        try FSOperation.perform(.setLocked(url: fileURL, locked: locked), rootHelperConf: RootConf.shared)
        isLocked = locked
    }
}

struct StringError: LocalizedError, CustomStringConvertible {
    let description: String

    init(_ description: String) {
        self.description = description
    }

    var errorDescription: String? {
        SantanderL10n.t(description)
    }
}

private enum SantanderCommandParser {
    static func arguments(_ args: [String], after flag: String) throws -> [String] {
        var values: [String] = []
        var index = 0
        while index < args.count {
            if args[index] == flag {
                guard index + 1 < args.count else {
                    throw StringError("Missing value for \(flag)")
                }
                values.append(args[index + 1])
                index += 2
            } else {
                index += 1
            }
        }
        return values
    }

    static func single(_ args: [String], flag: String, required: Bool = false) throws -> String? {
        let values = try arguments(args, after: flag)
        guard values.count <= 1 else {
            throw StringError("Option \(flag) may only be provided once")
        }
        if required && values.isEmpty {
            throw StringError("Missing required option \(flag)")
        }
        return values.first
    }

    static func positional(_ args: [String], excluding flags: Set<String>) -> [String] {
        var result: [String] = []
        var index = 0
        while index < args.count {
            let item = args[index]
            if flags.contains(item) {
                index += min(2, args.count - index)
            } else if item.hasPrefix("--") {
                index += 1
            } else {
                result.append(item)
                index += 1
            }
        }
        return result
    }

    static func url(_ value: String, label: String) throws -> URL {
        guard !value.isEmpty else {
            throw StringError("Invalid empty \(label)")
        }
        return URL(fileURLWithPath: value)
    }

    static func urls(_ values: [String], label: String) throws -> [URL] {
        try values.map { try url($0, label: label) }
    }

    static func requiredURL(_ args: [String], flag: String) throws -> URL {
        guard let value = try single(args, flag: flag, required: true) else {
            throw StringError("Missing required option \(flag)")
        }
        return try url(value, label: flag)
    }

    static func printUsage() {
        let usage = """
        Usage: SantanderHelperProgram <command> [options]

        Commands:
          create --directories <path>... --files <path>...
          delete <path>...
          move <path>... --destination <directory>
          copy <path>... --destination <directory>
          link <path>... --destination <directory>
          rename <path> <destination>
          set-owner-or-group <path> [--group-name <name>] [--owner-name <name>] [--group-id <id>] [--owner-id <id>]
          set-locked <path> <0|1>
          set-permissions <path> <permissions>
          compress --paths <path>... --destination <path> [--format zip|tar]
          decompress <path> --destination <path>
          write-data <path>
          write-string <string> --path <path>
          get-contents <path>
        """
        FileHandle.standardError.write(Data(usage.utf8))
    }
}

struct Delete {
    let paths: [URL]

    init(arguments: [String]) throws {
        let positionals = arguments
            .filter { !$0.hasPrefix("-") }
            .map { URL(fileURLWithPath: $0) }
        guard !positionals.isEmpty else {
            throw StringError("delete requires at least one path")
        }
        self.paths = positionals
    }

    func run() throws {
        for path in paths {
            try FileManager.default.removeItem(at: path)
        }
    }
}

struct SetOwnerOrGroup {
    let path: URL
    let groupName: String?
    let ownerName: String?
    let groupID: Int32?
    let ownerID: Int32?

    init(arguments: [String]) throws {
        let positionals = SantanderCommandParser.positional(
            arguments,
            excluding: ["--group-name", "--owner-name", "--group-id", "--owner-id"]
        )
        guard let first = positionals.first, positionals.count == 1 else {
            throw StringError("set-owner-or-group requires exactly one path")
        }
        self.path = URL(fileURLWithPath: first)
        self.groupName = try SantanderCommandParser.single(arguments, flag: "--group-name")
        self.ownerName = try SantanderCommandParser.single(arguments, flag: "--owner-name")
        if let value = try SantanderCommandParser.single(arguments, flag: "--group-id") {
            self.groupID = Int32(value)
        } else {
            self.groupID = nil
        }
        if let value = try SantanderCommandParser.single(arguments, flag: "--owner-id") {
            self.ownerID = Int32(value)
        } else {
            self.ownerID = nil
        }

        guard groupName != nil || ownerName != nil || groupID != nil || ownerID != nil else {
            throw StringError("Specify an owner/group name or ID")
        }
        guard !(groupName != nil && groupID != nil), !(ownerName != nil && ownerID != nil) else {
            throw StringError("Do not specify both a name and an ID for the same field")
        }
    }

    func run() throws {
        var uid = uid_t.max
        var gid = gid_t.max
        if let ownerID {
            uid = UInt32(bitPattern: ownerID)
        }
        if let groupID {
            gid = UInt32(bitPattern: groupID)
        }

        if ownerID != nil || groupID != nil {
            guard lchown(path.path, uid, gid) == 0 else {
                throw StringError(String(cString: strerror(errno)))
            }
        }

        if let groupName {
            try FileManager.default.setAttributes([.groupOwnerAccountName: groupName], ofItemAtPath: path.path)
        }
        if let ownerName {
            try FileManager.default.setAttributes([.ownerAccountName: ownerName], ofItemAtPath: path.path)
        }
    }
}

struct SetLocked {
    let path: URL
    let locked: Bool

    init(arguments: [String]) throws {
        let positionals = arguments.filter { !$0.hasPrefix("-") }
        guard positionals.count == 2 else {
            throw StringError("set-locked requires <path> <0|1>")
        }
        self.path = URL(fileURLWithPath: positionals[0])
        guard positionals[1] == "0" || positionals[1] == "1" else {
            throw StringError("set-locked requires 0 or 1")
        }
        self.locked = positionals[1] == "1"
    }

    func run() throws {
        var buffer = stat()
        guard lstat(path.path, &buffer) == 0 else {
            throw StringError(String(cString: strerror(errno)))
        }
        let current = UInt32(buffer.st_flags)
        let next = locked ? (current | UInt32(UF_IMMUTABLE)) : (current & ~UInt32(UF_IMMUTABLE))
        guard chflags(path.path, next) == 0 else {
            throw StringError(String(cString: strerror(errno)))
        }
    }
}

struct Create {
    let directories: [URL]
    let files: [URL]

    init(arguments: [String]) throws {
        directories = try SantanderCommandParser.urls(
            SantanderCommandParser.arguments(arguments, after: "--directories"),
            label: "directory"
        )
        files = try SantanderCommandParser.urls(
            SantanderCommandParser.arguments(arguments, after: "--files"),
            label: "file"
        )

        guard !directories.isEmpty || !files.isEmpty else {
            throw StringError("create requires --directories and/or --files")
        }
    }

    func run() throws {
        for dir in directories {
            try FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
        }

        for file in files {
            let fPtr = try file.withUnsafeFileSystemRepresentation { cPathPointer in
                guard let cPathPointer, let fPtr = fopen(cPathPointer, "a") else {
                    throw StringError("Failed to create file \(file): \(String(cString: strerror(errno)))")
                }
                return fPtr
            }
            fclose(fPtr)
        }
    }
}

struct Move {
    let paths: [URL]
    let destination: URL

    init(arguments: [String]) throws {
        let positionals = SantanderCommandParser.positional(arguments, excluding: ["--destination"])
        guard !positionals.isEmpty else { throw StringError("move requires at least one source path") }
        paths = positionals.map { URL(fileURLWithPath: $0) }
        destination = try SantanderCommandParser.requiredURL(arguments, flag: "--destination")
    }

    func run() throws {
        let total = paths.count
        emitOperationProgress(completed: 0, total: total)
        for (index, path) in paths.enumerated() {
            try FileManager.default.moveItem(at: path, to: destination.appendingPathComponent(path.lastPathComponent))
            emitOperationProgress(completed: index + 1, total: total)
        }
    }
}

struct Copy {
    let paths: [URL]
    let destination: URL

    init(arguments: [String]) throws {
        let positionals = SantanderCommandParser.positional(arguments, excluding: ["--destination"])
        guard !positionals.isEmpty else { throw StringError("copy requires at least one source path") }
        paths = positionals.map { URL(fileURLWithPath: $0) }
        destination = try SantanderCommandParser.requiredURL(arguments, flag: "--destination")
    }

    func run() throws {
        let total = paths.count
        emitOperationProgress(completed: 0, total: total)
        for (index, path) in paths.enumerated() {
            try FileManager.default.copyItem(at: path, to: destination.appendingPathComponent(path.lastPathComponent))
            emitOperationProgress(completed: index + 1, total: total)
        }
    }
}

private func emitOperationProgress(completed: Int, total: Int) {
    let line = "SANTANDER_PROGRESS \(completed) \(max(total, 1))\n"
    FileHandle.standardOutput.write(Data(line.utf8))
}

struct Rename {
    let path: URL
    let destination: URL

    init(arguments: [String]) throws {
        let positionals = arguments.filter { !$0.hasPrefix("-") }
        guard positionals.count == 2 else {
            throw StringError("rename requires <path> <destination>")
        }
        path = URL(fileURLWithPath: positionals[0])
        destination = URL(fileURLWithPath: positionals[1])
    }

    func run() throws {
        try FileManager.default.moveItem(at: path, to: destination)
    }
}

struct Link {
    let paths: [URL]
    let destination: URL

    init(arguments: [String]) throws {
        let positionals = SantanderCommandParser.positional(arguments, excluding: ["--destination"])
        guard !positionals.isEmpty else { throw StringError("link requires at least one source path") }
        paths = positionals.map { URL(fileURLWithPath: $0) }
        destination = try SantanderCommandParser.requiredURL(arguments, flag: "--destination")
    }

    func run() throws {
        for path in paths {
            try FileManager.default.createSymbolicLink(
                at: destination.appendingPathComponent(path.lastPathComponent),
                withDestinationURL: path
            )
        }
    }
}

struct SetPermissions {
    let path: URL
    let permissions: Int

    init(arguments: [String]) throws {
        let positionals = arguments.filter { !$0.hasPrefix("-") }
        guard positionals.count == 2, let parsed = Int(positionals[1]) else {
            throw StringError("set-permissions requires <path> <permissions>")
        }
        path = URL(fileURLWithPath: positionals[0])
        permissions = parsed
    }

    func run() throws {
        guard permissions >= 0 && permissions <= 0o7777 else {
            throw StringError("Permissions must be between 0000 and 7777")
        }
        try FileManager.default.setAttributes([.posixPermissions: permissions], ofItemAtPath: path.path)
    }
}

private func ensureFileContentIsUnlocked(_ path: URL) throws {
    var buffer = stat()
    guard lstat(path.path, &buffer) == 0 else {
        throw StringError(String(cString: strerror(errno)))
    }
    if (buffer.st_flags & UInt32(UF_IMMUTABLE)) != 0 {
        throw StringError("文件已锁定，系统禁止修改其内容。")
    }
}

struct WriteData {
    let path: URL

    init(arguments: [String]) throws {
        let positionals = arguments.filter { !$0.hasPrefix("-") }
        guard positionals.count == 1 else {
            throw StringError("write-data requires <path>")
        }
        path = URL(fileURLWithPath: positionals[0])
    }

    func run() throws {
        try ensureFileContentIsUnlocked(path)
        let data = FileHandle.standardInput.readDataToEndOfFile()
        try data.write(to: path, options: .atomic)
    }
}

struct WriteString {
    let string: String
    let path: URL

    init(arguments: [String]) throws {
        let positionals = SantanderCommandParser.positional(arguments, excluding: ["--path"])
        guard positionals.count == 1 else {
            throw StringError("write-string requires exactly one string argument")
        }
        string = positionals[0]
        path = try SantanderCommandParser.requiredURL(arguments, flag: "--path")
    }

    func run() throws {
        try ensureFileContentIsUnlocked(path)
        try string.write(to: path, atomically: true, encoding: .utf8)
    }
}

struct Compress {
    let paths: [URL]
    let destination: URL
    let format: Compression.FormatType

    init(arguments: [String]) throws {
        let pathValues = try SantanderCommandParser.arguments(arguments, after: "--paths")
        guard !pathValues.isEmpty else {
            throw StringError("compress requires at least one --paths value")
        }
        paths = try SantanderCommandParser.urls(pathValues, label: "path")
        destination = try SantanderCommandParser.requiredURL(arguments, flag: "--destination")

        switch (try SantanderCommandParser.single(arguments, flag: "--format") ?? "zip").lowercased() {
        case "zip":
            format = .zip
        case "tar":
            format = .tar
        case "7z", "7zz", "sevenzip":
            format = .sevenZip
        default:
            throw StringError("Compression format must be zip, tar or 7z")
        }
    }

    func run() throws {
        try Compression.shared.compress(paths: paths, outputPath: destination, format: format)
    }
}

struct Decompress {
    let path: URL
    let destination: URL

    init(arguments: [String]) throws {
        let positionals = SantanderCommandParser.positional(arguments, excluding: ["--destination"])
        guard positionals.count == 1 else {
            throw StringError("decompress requires <path>")
        }
        path = URL(fileURLWithPath: positionals[0])
        destination = try SantanderCommandParser.requiredURL(arguments, flag: "--destination")
    }

    func run() throws {
        try Compression.shared.extract(path: path, to: destination)
    }
}

struct ExtractCatalog {
    let path: URL
    let destination: URL

    init(arguments: [String]) throws {
        let positionals = SantanderCommandParser.positional(arguments, excluding: ["--destination"])
        guard positionals.count == 1 else {
            throw StringError("extract-catalog requires <path>")
        }
        path = URL(fileURLWithPath: positionals[0])
        destination = try SantanderCommandParser.requiredURL(arguments, flag: "--destination")
    }

    func run() throws {
        let (_, renditions) = try AssetCatalogWrapper.shared.renditions(forCarArchive: path)
        let codable = renditions.flatMap(\.renditions).toCodable()

        try FileManager.default.createDirectory(at: destination, withIntermediateDirectories: true)
        var failedItems: [String: String] = [:]
        for rend in codable {
            let newURL = destination.appendingPathComponent(rend.renditionName)
            if let data = rend.itemData {
                do {
                    try data.write(to: newURL)
                } catch {
                    failedItems[rend.renditionName] = "Unable to write item data to file: \(error.localizedDescription)"
                }
            }
        }

        if !failedItems.isEmpty {
            let message = failedItems.map { "\($0.key): \($0.value)" }.joined(separator: "\n")
            throw StringError(message.trimmingCharacters(in: .whitespacesAndNewlines))
        }
    }
}

struct GetContents {
    let path: URL

    init(arguments: [String]) throws {
        let positionals = arguments.filter { !$0.hasPrefix("-") }
        guard positionals.count == 1 else {
            throw StringError("get-contents requires <path>")
        }
        path = URL(fileURLWithPath: positionals[0])
    }

    func run() throws {
        let contents = try FileManager.default.contentsOfDirectory(at: path, includingPropertiesForKeys: nil)
        let output = contents.map(\.path).joined(separator: "\n")
        FileHandle.standardOutput.write(Data(output.utf8))
        if !output.isEmpty {
            FileHandle.standardOutput.write(Data("\n".utf8))
        }
    }
}

struct SantanderHelperProgram {
    static func main() throws {
        try main(ProcessInfo.processInfo.arguments.dropFirst().map { String($0) })
    }

    static func main(_ arguments: [String]) throws {
        guard let command = arguments.first?.lowercased() else {
            SantanderCommandParser.printUsage()
            return
        }

        let commandArguments = Array(arguments.dropFirst())

        switch command {
        case "create":
            try Create(arguments: commandArguments).run()
        case "delete":
            try Delete(arguments: commandArguments).run()
        case "move":
            try Move(arguments: commandArguments).run()
        case "copy":
            try Copy(arguments: commandArguments).run()
        case "link":
            try Link(arguments: commandArguments).run()
        case "rename":
            try Rename(arguments: commandArguments).run()
        case "set-owner-or-group":
            try SetOwnerOrGroup(arguments: commandArguments).run()
        case "set-locked":
            try SetLocked(arguments: commandArguments).run()
        case "set-permissions":
            try SetPermissions(arguments: commandArguments).run()
        case "compress":
            try Compress(arguments: commandArguments).run()
        case "decompress":
            try Decompress(arguments: commandArguments).run()
        case "extract-catalog":
            try ExtractCatalog(arguments: commandArguments).run()
        case "write-data":
            try WriteData(arguments: commandArguments).run()
        case "write-string":
            try WriteString(arguments: commandArguments).run()
        case "get-contents":
            try GetContents(arguments: commandArguments).run()
        case "help", "--help", "-h":
            SantanderCommandParser.printUsage()
        default:
            throw StringError("Unknown root-helper command: \(command)")
        }
    }
}

extension URL {

    var shallowSortSize: Int {
        guard let values = try? resourceValues(forKeys: [.isDirectoryKey, .fileSizeKey, .totalFileAllocatedSizeKey, .fileAllocatedSizeKey]) else {
            return 0
        }
        if values.isDirectory == true { return 0 }
        return values.fileSize ?? values.totalFileAllocatedSize ?? values.fileAllocatedSize ?? 0
    }

    func regularFileAllocatedSize() throws -> UInt64 {
        let resourceValues = try self.resourceValues(forKeys: allocatedSizeResourceKeys)
        guard resourceValues.isRegularFile ?? false else {
            return 0
        }
        return UInt64(resourceValues.totalFileAllocatedSize ?? resourceValues.fileAllocatedSize ?? 0)
    }

    var contents: [URL] {
        let directoryURL = resolvedURL
        if isReadable,
           let directContents = try? FileManager.default.contentsOfDirectory(at: directoryURL, includingPropertiesForKeys: []) {
            return directContents
        }
        guard UserPreferences.rootHelperIsEnabled else { return [] }
        return (try? RootConf.shared.contents(of: directoryURL)) ?? []
    }

    var isDirectory: Bool {
        return (try? resolvedURL.resourceValues(forKeys: [.isDirectoryKey]).isDirectory) ?? false
    }

    var creationDate: Date? {
        try? resourceValues(forKeys: [.creationDateKey]).creationDate
    }

    var lastModifiedDate: Date? {
        try? resourceValues(forKeys: [.contentModificationDateKey]).contentModificationDate
    }

    var lastAccessedDate: Date? {
        try? resourceValues(forKeys: [.contentAccessDateKey]).contentAccessDate
    }

    var addedToDirectoryDate: Date? {
        try? resourceValues(forKeys: [.addedToDirectoryDateKey]).addedToDirectoryDate
    }

    var size: Int? {
        if isDirectory {
            var _size: Int = 0
            for content in contents {
                _size += content.size ?? 0
            }
            return _size
        }
        return try? resourceValues(forKeys: [.fileSizeKey]).fileSize
    }

    var contentType: UTType? {
        return try? resourceValues(forKeys: [.contentTypeKey]).contentType
    }

    var displayName: String {
        return FileManager.default.displayName(atPath: self.path)
    }

    var resolvedURL: URL {
        return (try? URL(resolvingAliasFileAt: self)) ?? self
    }

    static let root: URL = URL(fileURLWithPath: "/")
    static let home: URL = URL(fileURLWithPath: NSHomeDirectory())

    var isSymlink: Bool {
        return (try? FileManager.default.destinationOfSymbolicLink(atPath: self.path)) != nil
    }

    var isReadable: Bool {
        return FileManager.default.isReadableFile(atPath: self.path)
    }

    func setPermissions(forOwner owner: Permission, group: Permission = [], others: Permission = []) throws {
        let octal = Permission.octalRepresentation(of: [owner, group, others])
        try FSOperation.perform(.setPermissions(url: self, newOctalPermissions: octal), rootHelperConf: RootConf.shared)
    }

    func fullPathComponents() -> [URL] {
        var arr: [URL] = []
        let components = self.pathComponents
        for indx in components.indices {
            let item = components[components.startIndex...indx]
                .joined(separator: "/")
                .replacingOccurrences(of: "//", with: "/")
            if item.isEmpty {
                continue
            }
            arr.append(URL(fileURLWithPath: item))
        }
        return arr
    }

    var containsAppUUIDSubpaths: Bool {
        return pathComponents.contains("Containers") || pathComponents.contains("containers")
    }

    var applicationItem: SantanderApplication? {
        if self.pathExtension == "app" {
            return ApplicationsManager.shared.application(forBundleURL: self)
        }
        return ApplicationsManager.shared.application(forContainerURL: self) ?? ApplicationsManager.shared.application(forDataContainerURL: self)
    }
}

#if targetEnvironment(simulator)
fileprivate let applicationPaths: [String] = [URL.home.deletingLastPathComponent().path]
#else
fileprivate let applicationPaths: [String] = [
    "/private/var/containers/Bundle/Application",
    "/private/var/mobile/Containers/Data",
    "/private/var/mobile/Containers/Data/Application"
]
#endif

extension UIViewController {
    func errorAlert(
        _ errorDescription: String?,
        title: String,
        presentingFromIfAvailable presentingVC: UIViewController? = nil,
        cancelAction: UIAlertAction = .cancel(title: SantanderL10n.t("OK"))
    ) {
        var message: String? = nil
        if let errorDescription = errorDescription {
            message = SantanderL10n.t("Error occurred: \(errorDescription)")
        }

        let alert = UIAlertController(title: SantanderL10n.t(title), message: message, preferredStyle: .alert)
        alert.addAction(cancelAction)
        let vcToPresentFrom = presentingVC ?? self
        vcToPresentFrom.present(alert, animated: true)
    }

    func errorAlert(
        _ error: Error,
        title: String,
        presentingFromIfAvailable presentingVC: UIViewController? = nil,
        cancelAction: UIAlertAction = .cancel(title: SantanderL10n.t("OK"))
    ) {
        self.errorAlert(error.localizedDescription, title: title, presentingFromIfAvailable: presentingVC, cancelAction: cancelAction)
    }

    func configureNavigationBarToNormal() {
        if let navigationBar = navigationController?.navigationBar {
            SantanderUI.configureNavigationBar(navigationBar)
        }
    }

    func presentActivityVC(forItems items: [Any]) {
        let vc = UIActivityViewController(activityItems: items, applicationActivities: nil)
        vc.popoverPresentationController?.sourceView = view
        let bounds = view.bounds

        vc.popoverPresentationController?.sourceRect = CGRect(x: bounds.midX, y: bounds.midY, width: 0, height: 0)
        self.present(vc, animated: true)
    }

    func createAlertWithSpinner(title: String, message: String? = nil, heightAnchorConstant: CGFloat = 95) -> UIAlertController {
        let alertController = UIAlertController(title: title, message: message, preferredStyle: .alert)
        let spinner = UIActivityIndicatorView()
        spinner.translatesAutoresizingMaskIntoConstraints = false
        spinner.startAnimating()
        alertController.view.addSubview(spinner)

        NSLayoutConstraint.activate([
            alertController.view.heightAnchor.constraint(equalToConstant: heightAnchorConstant),
            spinner.centerXAnchor.constraint(equalTo: alertController.view.centerXAnchor),
            spinner.bottomAnchor.constraint(equalTo: alertController.view.bottomAnchor, constant: -20),
        ])

        return alertController
    }

    func saveImage(_ image: UIImage) {
        UIImageWriteToSavedPhotosAlbum(image, self, #selector(didSaveImage(_:error:context:)), nil)
    }

    @objc
    func didSaveImage(_ im: UIImage, error: Error?, context: UnsafeMutableRawPointer?) {
        if let error = error {
            errorAlert(error, title: SantanderL10n.t("Unable to save image"))
        }
    }
}

extension UIAlertAction {
    static func cancel(title: String = SantanderL10n.t("Cancel"), handler: (() -> Void)? = nil) -> UIAlertAction {
        UIAlertAction(title: SantanderL10n.t(title), style: .cancel) { _ in
            handler?()
        }
    }
}

extension FileManager {

    func allocatedSizeOfDirectory(at directoryURL: URL) throws -> UInt64 {

        var enumeratorError: Error? = nil
        func errorHandler(_: URL, error: Error) -> Bool {
            enumeratorError = error
            return false
        }

        guard let enumerator = self.enumerator(
            at: directoryURL,
            includingPropertiesForKeys: Array(allocatedSizeResourceKeys),
            options: [],
            errorHandler: errorHandler
        ) else {
            throw NSError(
                domain: NSCocoaErrorDomain,
                code: NSFileReadNoSuchFileError,
                userInfo: [NSFilePathErrorKey: directoryURL.path]
            )
        }

        var accumulatedSize: UInt64 = 0

        for item in enumerator {
            if enumeratorError != nil { break }
            guard let contentItemURL = item as? URL else { continue }
            accumulatedSize += try contentItemURL.regularFileAllocatedSize()
        }

        if let error = enumeratorError { throw error }

        return accumulatedSize
    }
}

fileprivate let allocatedSizeResourceKeys: Set<URLResourceKey> = [
    .isRegularFileKey,
    .fileAllocatedSizeKey,
    .totalFileAllocatedSizeKey,
]

extension NSNotification.Name {
    static var pathGroupsDidChange: NSNotification.Name {
        return NSNotification.Name("pathGroupsDidChange")
    }
}

extension Date {
    func listFormatted() -> String {
        if #available(iOS 15.0, *) {
            return self.formatted(date: .long, time: .shortened)
        } else {
            let dateFormatter = DateFormatter()
            dateFormatter.dateStyle = .long
            dateFormatter.timeStyle = .short
            return dateFormatter.string(from: self)
        }
    }
}

extension Collection {
    subscript(safe safeIndex: Index) -> Element? {
        return self.indices.contains(safeIndex) ? self[safeIndex] : nil
    }
}

extension UTType {

    public static func generictypes() -> [UTType] {
        return [
            .content,
            .image,
            .video,
            .text,
            .audio,
            .movie,
            .sourceCode,
            .executable
        ]
    }

    public static func audioTypes() -> [UTType] {
        return [
            .mp3,
            .aiff,
            .wav,
            .midi
        ]
    }

    public static func programmingTypes() -> [UTType] {
        var arr: [UTType] = [
            .swiftSource,
            .assemblyLanguageSource,

            .cSource,
            .objectiveCSource,
            .objectiveCPlusPlusSource,
            .cPlusPlusSource,

            .cHeader,
            .cPlusPlusHeader,

            .script,
            .shellScript,
            .javaScript,
            .pythonScript,
            .rubyScript,
            .perlScript,
            .phpScript
        ]

        if #available(iOS 15.0, *) {
            arr.append(.makefile)
        }

        return arr
    }

    public static func compressedFormatTypes() -> [UTType] {
        return [
            .zip,
            .gzip,
            .bz2
        ]
    }

    public static func imageTypes() -> [UTType] {
        return [
            .png,
            .gif,
            .jpeg,
            .webP,
            .tiff,
            .bmp,
            .svg,
            .heif
        ]
    }

    public static func documentTypes() -> [UTType] {
        return [
            .json,
            .yaml,
            .rtf,
            .xml,
            .propertyList,
            .pdf
        ]
    }

    public static func systemTypes() -> [UTType] {
        return [
            .bundle,
            .application,
            .framework,
            .log,
            .database,
            .diskImage,
            .package
        ]
    }

    public static func executableTypes() -> [UTType] {
        return [
            .executable,
            UTType(filenameExtension: "dylib")
        ]
        .compactMap { $0 }
    }

    func isOfType(_ type: UTType) -> Bool {
        return type == self || self.isSubtype(of: type)
    }
}

extension UITableViewController {
    func indexPaths(forSection section: Int) -> [IndexPath] {
        let allRows = self.tableView(tableView, numberOfRowsInSection: section)
        return (0..<allRows).map { row in
            return IndexPath(row: row, section: section)
        }
    }

    func cellWithView(_ view: UIView, text: String, rightAnchorConstant: CGFloat = -20) -> UITableViewCell {
        let cell = UITableViewCell()
        SantanderUI.styleCell(cell)
        cell.selectionStyle = .none
        var conf = cell.defaultContentConfiguration()
        conf.text = text
        cell.contentConfiguration = conf
        view.translatesAutoresizingMaskIntoConstraints = false
        cell.contentView.addSubview(view)

        NSLayoutConstraint.activate([
            view.rightAnchor.constraint(equalTo: cell.contentView.rightAnchor, constant: rightAnchorConstant),
            view.centerYAnchor.constraint(equalTo: cell.contentView.centerYAnchor)
        ])

        return cell
    }

    func sectionHeaderWithButton(
        sectionTag: Int,
        titleText: String?,
        buttonCustomization: (UIButton) -> Void
    ) -> UIView {
        let view = UIView()
        let label = UILabel()
        let button = UIButton()
        buttonCustomization(button)

        button.tag = sectionTag

        label.text = titleText
        label.font = .systemFont(ofSize: 18, weight: .bold)

        label.translatesAutoresizingMaskIntoConstraints = false
        button.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(label)
        view.addSubview(button)

        NSLayoutConstraint.activate([
            label.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 10),
            label.topAnchor.constraint(equalTo: view.topAnchor, constant: 10),

            button.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -5),
            button.topAnchor.constraint(equalTo: view.topAnchor, constant: 5),
        ])

        return view
    }

    func seperatorFooterView() -> UIView {
        let result = UIView()
        let insets = tableView.separatorInset
        let width = tableView.bounds.width - insets.left - insets.right
        let sepFrame = CGRect(x: insets.left, y: -0.5, width: width, height: 0.5)

        let sep = CALayer()
        sep.frame = sepFrame
        sep.backgroundColor = tableView.separatorColor?.cgColor
        result.layer.addSublayer(sep)

        return result
    }

    func deleteURL(_ path: Path, completionHandler: @escaping (Bool) -> Void) {
        presentSantanderActionSheet(title: "确定要删除「\(path.lastPathComponent)」吗？", message: path.path, actions: [
            SantanderActionSheetItem(title: SantanderL10n.t("Delete"), image: SantanderIconLibrary.shared.interfaceIcon(for: "trash"), style: .destructive) {
                DispatchQueue.global(qos: .userInitiated).async {
                    var operationError: Error?
                    do {
                        try FSOperation.perform(.removeItems(items: [path.url]), rootHelperConf: RootConf.shared)
                    } catch {
                        operationError = error
                    }
                    DispatchQueue.main.async {
                        if let operationError {
                            self.errorAlert(operationError, title: "删除「\(path.lastPathComponent)」失败")
                            completionHandler(false)
                        } else {
                            completionHandler(true)
                        }
                    }
                }
            },
            SantanderActionSheetItem(title: SantanderL10n.t("Cancel"), style: .cancel) { completionHandler(false) }
        ])
    }
}

extension UIImage {
    func imageWith(newSize: CGSize) -> UIImage {
        let image = UIGraphicsImageRenderer(size: newSize).image { _ in
            draw(in: CGRect(origin: .zero, size: newSize))
        }
        return image.withRenderingMode(renderingMode)
    }
}

extension UIAction {
    convenience init(withClosure closure: @escaping () -> Void) {
        self.init { _ in
            closure()
        }
    }
}

extension Optional: @retroactive Comparable where Wrapped: Comparable {
    public static func < (lhs: Optional, rhs: Optional) -> Bool {
        guard let lhs = lhs, let rhs = rhs else {
            return false
        }
        return lhs < rhs
    }
}

extension UITableView.Style: @retroactive CaseIterable, @retroactive CustomStringConvertible {
    static var userPreferred: UITableView.Style {
        return .insetGrouped
    }

    public static var allCases: [UITableView.Style] = [.insetGrouped, .grouped, .plain]

    public var description: String {
        switch self {
        case .plain:
            return SantanderL10n.t("Plain")
        case .grouped:
            return SantanderL10n.t("Grouped")
        case .insetGrouped:
            return SantanderL10n.t("Inset Grouped")
        @unknown default:
            return SantanderL10n.t("Unknown Mode")
        }
    }
}

extension Array where Element: OptionSet {
    func reducingToSingleOptionSet() -> Element {
        return self.reduce(Element()) { return $0.union($1) }
    }
}

extension UIUserInterfaceStyle: @retroactive CaseIterable {
    public static var allCases: [UIUserInterfaceStyle] = [.unspecified, .dark, .light]
    var description: String {
        switch self {
        case .unspecified:
            return SantanderL10n.t("System")
        case .light:
            return SantanderL10n.t("Light")
        case .dark:
            return SantanderL10n.t("Dark")
        @unknown default:
            return SantanderL10n.t("Unknown Mode")
        }
    }
}

extension UITableViewCell {
    func colorCircleAccessoryView(color: UIColor) -> UIView {
        let colorPreview = UIView(frame: CGRect(x: 0, y: 0, width: 29, height: 29))
        colorPreview.backgroundColor = color
        colorPreview.layer.cornerRadius = colorPreview.frame.size.width / 2
        colorPreview.layer.borderWidth = 1.5
        colorPreview.layer.borderColor = UIColor.systemGray.cgColor

        return colorPreview
    }
}

extension Dictionary where Key == String, Value == SerializedItemType {
    func asAnyDictionary() -> [String: Any] {
        var dict: [String: Any] = [:]
        for (key, value) in self {
            dict[key] = value.representedObject
        }
        return dict
    }
}

extension Dictionary where Key == String, Value == Any {
    func asSerializedDictionary() -> SerializedDictionaryType {
        var dict: SerializedDictionaryType = [:]
        for (key, value) in self {
            dict[key] = SerializedItemType(item: value)
        }
        return dict
    }
}

extension UIDevice {
    static let isiPad = current.userInterfaceIdiom == .pad
}

extension DateFormatter {
    static let EXIFDateFormatter = DateFormatter(withFormat: "yyyy:MM:dd HH:mm:ss")
    static let IPTCDateFormatter = DateFormatter(withFormat: "yyyyMMdd")

    convenience init(withFormat dateFormat: String) {
        self.init()
        self.dateFormat = dateFormat
    }
}

extension UIApplication {
    var sceneKeyWindow: UIWindow? {
        return UIApplication.shared
        .connectedScenes
        .flatMap { ($0 as? UIWindowScene)?.windows ?? [] }
        .first { $0.isKeyWindow }
    }
}

extension CTFontDescriptor {
    var uiFont: UIFont {
        return CTFontCreateWithFontDescriptor(self, UserPreferences.fontViewerFontSize, nil) as UIFont
    }
}

extension UIPasteboard {
    var probableURLs: [URL] {
        if let urls = urls {
            let fileURLs = urls.filter(\.isFileURL)
            if !fileURLs.isEmpty { return fileURLs }
        }
        if let url = url, url.isFileURL { return [url] }
        if let string = string, string.hasPrefix("/") { return [URL(fileURLWithPath: string)] }
        return []
    }

    var probableURL: URL? { probableURLs.first }
}


extension Array<Path> {
    func toURL() -> [URL] {
        map(\.url)
    }
}


@main
class AppDelegate: UIResponder, UIApplicationDelegate {

    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        SantanderInitialPreferences.migrateToFilzaDefaultsIfNeeded()
        return true
    }


    func application(_ application: UIApplication, configurationForConnecting connectingSceneSession: UISceneSession, options: UIScene.ConnectionOptions) -> UISceneConfiguration {
        return UISceneConfiguration(name: "Default Configuration", sessionRole: connectingSceneSession.role)
    }

    func application(_ application: UIApplication, didDiscardSceneSessions sceneSessions: Set<UISceneSession>) {
    }


}


private final class SantanderDetailPlaceholderViewController: UIViewController {
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .systemBackground
        title = SantanderL10n.t("Preview")
        let image = UIImageView(image: SantanderIconLibrary.shared.interfaceIcon(for: "doc.text.magnifyingglass"))
        image.tintColor = .tertiaryLabel
        image.preferredSymbolConfiguration = UIImage.SymbolConfiguration(pointSize: 44, weight: .light)
        let label = UILabel()
        label.text = SantanderL10n.t("Select a file to inspect its details")
        label.textColor = .secondaryLabel
        label.font = .preferredFont(forTextStyle: .body)
        label.textAlignment = .center
        label.numberOfLines = 0
        let stack = UIStackView(arrangedSubviews: [image, label])
        stack.axis = .vertical
        stack.alignment = .center
        stack.spacing = 12
        stack.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(stack)
        NSLayoutConstraint.activate([
            stack.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            stack.centerYAnchor.constraint(equalTo: view.centerYAnchor),
            stack.leadingAnchor.constraint(greaterThanOrEqualTo: view.leadingAnchor, constant: 24),
            stack.trailingAnchor.constraint(lessThanOrEqualTo: view.trailingAnchor, constant: -24)
        ])
    }
}

private struct SantanderBrowserTabRecord: Codable, Identifiable, Equatable {
    let id: UUID
    var path: String
    var title: String {
        let name = URL(fileURLWithPath: path).lastPathComponent
        return name.isEmpty ? "/" : name
    }
}

@MainActor
private final class SantanderBrowserTabs {
    static let shared = SantanderBrowserTabs()
    private let recordsKey = "SantanderBrowserTabsRecords"
    private let activeKey = "SantanderBrowserTabsActiveID"
    private(set) var records: [SantanderBrowserTabRecord]
    private(set) var activeID: UUID
    private var navigationStacks: [UUID: [UIViewController]] = [:]

    private init() {
        let loadedRecords: [SantanderBrowserTabRecord]
        if let data = UserDefaults.standard.data(forKey: recordsKey),
           let decoded = try? JSONDecoder().decode([SantanderBrowserTabRecord].self, from: data), !decoded.isEmpty {
            loadedRecords = decoded
        } else {
            loadedRecords = [SantanderBrowserTabRecord(id: UUID(), path: "/")]
        }
        let savedID = UserDefaults.standard.string(forKey: activeKey).flatMap(UUID.init(uuidString:))
        let resolvedActiveID = loadedRecords.first(where: { $0.id == savedID })?.id ?? loadedRecords[0].id
        records = loadedRecords
        activeID = resolvedActiveID
        persist()
    }

    var activePath: String { records.first(where: { $0.id == activeID })?.path ?? "/" }

    func installInitialStack(_ stack: [UIViewController]) {
        if navigationStacks[activeID] == nil { navigationStacks[activeID] = stack }
    }

    func updateCurrent(path: String, stack: [UIViewController]) {
        if !records.contains(where: { $0.id == activeID }) {
            let record = SantanderBrowserTabRecord(id: UUID(), path: path)
            records.append(record)
            activeID = record.id
        }
        if let index = records.firstIndex(where: { $0.id == activeID }) { records[index].path = path }
        navigationStacks[activeID] = stack
        persist()
    }

    func createTab(path: String, navigationController: UINavigationController) {
        navigationStacks[activeID] = navigationController.viewControllers
        let record = SantanderBrowserTabRecord(id: UUID(), path: path)
        records.append(record)
        activeID = record.id
        let root = PathListViewController(style: .plain, path: Path(url: URL(fileURLWithPath: path)))
        navigationStacks[record.id] = [root]
        persist()
        navigationController.setViewControllers([root], animated: true)
    }

    func activate(_ id: UUID, navigationController: UINavigationController) {
        navigationStacks[activeID] = navigationController.viewControllers
        guard let record = records.first(where: { $0.id == id }) else { return }
        activeID = id
        let stack = navigationStacks[id] ?? [PathListViewController(style: .plain, path: Path(url: URL(fileURLWithPath: record.path)))]
        navigationStacks[id] = stack
        persist()
        navigationController.setViewControllers(stack, animated: true)
    }

    func close(_ id: UUID, navigationController: UINavigationController) {
        guard records.count > 1, let index = records.firstIndex(where: { $0.id == id }) else { return }
        let wasActive = id == activeID
        records.remove(at: index)
        navigationStacks.removeValue(forKey: id)
        if wasActive {
            let next = records[min(index, records.count - 1)]
            activeID = next.id
            let stack = navigationStacks[next.id] ?? [PathListViewController(style: .plain, path: Path(url: URL(fileURLWithPath: next.path)))]
            navigationStacks[next.id] = stack
            navigationController.setViewControllers(stack, animated: true)
        }
        persist()
    }

    private func persist() {
        if let data = try? JSONEncoder().encode(records) { UserDefaults.standard.set(data, forKey: recordsKey) }
        UserDefaults.standard.set(activeID.uuidString, forKey: activeKey)
    }
}

@MainActor
private final class SantanderBrowserTabsViewController: UITableViewController {
    private weak var browserNavigationController: UINavigationController?
    private weak var hostTabBarController: UITabBarController?
    private var records: [SantanderBrowserTabRecord] { SantanderBrowserTabs.shared.records }

    init(browserNavigationController: UINavigationController, hostTabBarController: UITabBarController? = nil) {
        self.browserNavigationController = browserNavigationController
        self.hostTabBarController = hostTabBarController
        super.init(style: .insetGrouped)
        title = "标签页"
    }

    required init?(coder: NSCoder) { fatalError() }

    override func viewDidLoad() {
        super.viewDidLoad()
        applySantanderUI()
        if hostTabBarController == nil {
            navigationItem.leftBarButtonItem = UIBarButtonItem(title: "完成", style: .plain, target: self, action: #selector(closeView))
        }
        navigationItem.rightBarButtonItem = UIBarButtonItem(barButtonSystemItem: .add, target: self, action: #selector(newTab))
        tableView.register(UITableViewCell.self, forCellReuseIdentifier: "SantanderBrowserTabCell")
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        tableView.reloadData()
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int { records.count }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "SantanderBrowserTabCell", for: indexPath)
        SantanderUI.styleCell(cell)
        guard records.indices.contains(indexPath.row) else { return cell }
        let record = records[indexPath.row]
        var content = cell.defaultContentConfiguration()
        content.text = record.title
        content.secondaryText = record.path
        content.image = SantanderIconLibrary.shared.uiIcon(named: "tab")
        content.imageProperties.tintColor = record.id == SantanderBrowserTabs.shared.activeID ? SantanderAppTheme.accentColor : .secondaryLabel
        cell.contentConfiguration = content
        cell.accessoryType = record.id == SantanderBrowserTabs.shared.activeID ? .checkmark : .disclosureIndicator
        return cell
    }

    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        guard records.indices.contains(indexPath.row), let nav = browserNavigationController else { return }
        SantanderBrowserTabs.shared.activate(records[indexPath.row].id, navigationController: nav)
        if let hostTabBarController {
            hostTabBarController.selectedIndex = 0
        } else {
            dismiss(animated: true)
        }
    }

    override func tableView(_ tableView: UITableView, trailingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration? {
        guard records.count > 1, records.indices.contains(indexPath.row) else { return nil }
        let record = records[indexPath.row]
        let close = UIContextualAction(style: .destructive, title: "关闭标签") { [weak self] _, _, completion in
            guard let self, let nav = self.browserNavigationController else { completion(false); return }
            SantanderBrowserTabs.shared.close(record.id, navigationController: nav)
            self.tableView.reloadData()
            completion(true)
        }
        close.image = SantanderIconLibrary.shared.interfaceIcon(for: "xmark")
        return UISwipeActionsConfiguration(actions: [close])
    }

    @objc private func closeView() { dismiss(animated: true) }

    @objc private func newTab() {
        guard let nav = browserNavigationController else { return }
        SantanderBrowserTabs.shared.createTab(path: SantanderBrowserTabs.shared.activePath, navigationController: nav)
        if let hostTabBarController {
            hostTabBarController.selectedIndex = 0
        } else {
            dismiss(animated: true)
        }
    }
}

private final class SantanderFavoritesViewController: UITableViewController {
    private var groups = UserPreferences.pathGroups

    override func viewDidLoad() {
        super.viewDidLoad()
        title = SantanderL10n.t("Favorites")
        applySantanderUI()
        if let navigationController,
           navigationController.viewControllers.first === self,
           navigationController.presentingViewController != nil {
            navigationItem.leftBarButtonItem = UIBarButtonItem(title: "完成", style: .plain, target: self, action: #selector(closePresentedSurface))
        }
        tableView.register(UITableViewCell.self, forCellReuseIdentifier: "SantanderFavoriteCell")
        navigationItem.rightBarButtonItems = [
            editButtonItem,
            UIBarButtonItem(barButtonSystemItem: .add, target: self, action: #selector(addGroup))
        ]
        NotificationCenter.default.addObserver(self, selector: #selector(groupsChanged), name: .pathGroupsDidChange, object: nil)
    }

    deinit { NotificationCenter.default.removeObserver(self) }

    @objc private func closePresentedSurface() { dismiss(animated: true) }

    @objc private func groupsChanged() {
        groups = UserPreferences.pathGroups
        tableView.reloadData()
    }

    override func numberOfSections(in tableView: UITableView) -> Int { groups.count }
    override func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? { groups[section].name }
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int { groups[section].paths.count }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "SantanderFavoriteCell", for: indexPath)
        SantanderUI.styleCell(cell)
        let url = groups[indexPath.section].paths[indexPath.row]
        var content = cell.defaultContentConfiguration()
        content.text = url.standardizedFileURL.path == "/" ? "[Root]" : (url.lastPathComponent.isEmpty ? "/" : url.lastPathComponent)
        content.secondaryText = url.path
        if groups[indexPath.section].name == "收藏夹" {
            content.image = SantanderIconLibrary.shared.interfaceIcon(for: "star")
            content.imageProperties.tintColor = .secondaryLabel
        } else {
            let path = Path(url: url)
            content.image = path.displayImage
        }
        content.imageProperties.maximumSize = CGSize(width: 24, height: 24)
        cell.contentConfiguration = content
        cell.accessoryType = .disclosureIndicator
        return cell
    }

    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let url = groups[indexPath.section].paths[indexPath.row]
        let path = Path(url: url)
        if path.isDirectory {
            navigationController?.pushViewController(PathListViewController(path: path), animated: true)
        } else {
            let parent = PathListViewController(path: Path(url: url.deletingLastPathComponent()))
            navigationController?.pushViewController(parent, animated: true)
            parent.selectPathWhenLoaded(path)
        }
        tableView.deselectRow(at: indexPath, animated: true)
    }


    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        groups = UserPreferences.pathGroups
        tableView.reloadData()
    }

    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool { true }

    override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool { true }

    override func tableView(_ tableView: UITableView, targetIndexPathForMoveFromRowAt sourceIndexPath: IndexPath, toProposedIndexPath proposedDestinationIndexPath: IndexPath) -> IndexPath {
        guard sourceIndexPath.section == proposedDestinationIndexPath.section else { return sourceIndexPath }
        return proposedDestinationIndexPath
    }

    override func tableView(_ tableView: UITableView, moveRowAt sourceIndexPath: IndexPath, to destinationIndexPath: IndexPath) {
        guard sourceIndexPath.section == destinationIndexPath.section,
              groups.indices.contains(sourceIndexPath.section),
              groups[sourceIndexPath.section].paths.indices.contains(sourceIndexPath.row),
              groups[sourceIndexPath.section].paths.indices.contains(destinationIndexPath.row) else {
            tableView.reloadData()
            return
        }
        var updated = UserPreferences.pathGroups
        let moved = updated[sourceIndexPath.section].paths.remove(at: sourceIndexPath.row)
        updated[sourceIndexPath.section].paths.insert(moved, at: destinationIndexPath.row)
        UserPreferences.pathGroups = updated
        groups = updated
    }

    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        guard editingStyle == .delete,
              groups.indices.contains(indexPath.section),
              groups[indexPath.section].paths.indices.contains(indexPath.row) else { return }
        var updated = UserPreferences.pathGroups
        updated[indexPath.section].paths.remove(at: indexPath.row)
        UserPreferences.pathGroups = updated
        groups = updated
        tableView.reloadData()
    }

    override func tableView(_ tableView: UITableView, trailingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration? {
        let remove = UIContextualAction(style: .destructive, title: SantanderL10n.t("Remove Favorite")) { [weak self] _, _, completion in
            guard let self else { completion(false); return }
            var updated = UserPreferences.pathGroups
            guard updated.indices.contains(indexPath.section), updated[indexPath.section].paths.indices.contains(indexPath.row) else { completion(false); return }
            updated[indexPath.section].paths.remove(at: indexPath.row)
            UserPreferences.pathGroups = updated
            self.groups = updated
            self.tableView.reloadData()
            completion(true)
        }
        remove.image = SantanderIconLibrary.shared.uiIcon(named: "delete")
        return UISwipeActionsConfiguration(actions: [remove])
    }

    @objc private func addGroup() {
        let alert = UIAlertController(title: SantanderL10n.t("New Group"), message: nil, preferredStyle: .alert)
        alert.addTextField { $0.placeholder = SantanderL10n.t("Group name..") }
        alert.addAction(.cancel())
        alert.addAction(UIAlertAction(title: SantanderL10n.t("Create"), style: .default) { [weak self, weak alert] _ in
            guard let self, let name = alert?.textFields?.first?.text?.trimmingCharacters(in: .whitespacesAndNewlines), !name.isEmpty else { return }
            var updated = UserPreferences.pathGroups
            guard !updated.contains(where: { $0.name == name }) else {
                self.errorAlert("同名的组已经存在。", title: "无法创建名为「\(name)」的组")
                return
            }
            updated.append(PathGroup(name: name, paths: []))
            UserPreferences.pathGroups = updated
            self.groups = updated
            self.tableView.reloadData()
        })
        present(alert, animated: true)
    }
}

private final class SantanderToolsViewController: UITableViewController {
    private enum Tool: Int, CaseIterable { case recentPaths, tasks, terminal }

    override func viewDidLoad() {
        super.viewDidLoad()
        title = SantanderL10n.t("Tools")
        applySantanderUI()
        tableView.register(UITableViewCell.self, forCellReuseIdentifier: "SantanderToolCell")
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int { Tool.allCases.count }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "SantanderToolCell", for: indexPath)
        SantanderUI.styleCell(cell)
        var content = cell.defaultContentConfiguration()
        guard let tool = Tool(rawValue: indexPath.row) else { return cell }
        switch tool {
        case .recentPaths:
            content.text = SantanderL10n.t("Recent Paths")
            content.secondaryText = SantanderL10n.t("Quickly reopen recently visited directories")
            content.image = SantanderIconLibrary.shared.interfaceIcon(for: "clock")
        case .tasks:
            content.text = SantanderL10n.t("Tasks")
            content.secondaryText = SantanderL10n.t("Copy, move, archive, and background operation status")
            content.image = SantanderIconLibrary.shared.interfaceIcon(for: "list.bullet.rectangle")
        case .terminal:
            content.text = SantanderL10n.t("Terminal")
            content.secondaryText = SantanderL10n.t("Open a SwiftTerm session in the home directory")
            content.image = SantanderIconLibrary.shared.interfaceIcon(for: "terminal")
        }
        cell.contentConfiguration = content
        cell.accessoryType = .disclosureIndicator
        return cell
    }

    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        guard let tool = Tool(rawValue: indexPath.row) else {
            tableView.deselectRow(at: indexPath, animated: true)
            return
        }
        switch tool {
        case .recentPaths:
            let vc = SantanderRecentPathsViewController(style: .insetGrouped)
            navigationController?.pushViewController(vc, animated: true)
        case .tasks:
            navigationController?.pushViewController(SantanderTaskCenterViewController(style: .insetGrouped), animated: true)
        case .terminal:
            navigationController?.pushViewController(TerminalViewController(), animated: true)
        }
        tableView.deselectRow(at: indexPath, animated: true)
    }
}

private final class SantanderRecentPathsViewController: UITableViewController {
    private var paths = SantanderPathHistory.paths
    override func viewDidLoad() {
        super.viewDidLoad()
        title = SantanderL10n.t("Recent Paths")
        applySantanderUI()
        if let navigationController,
           navigationController.viewControllers.first === self,
           navigationController.presentingViewController != nil {
            navigationItem.leftBarButtonItem = UIBarButtonItem(title: "完成", style: .plain, target: self, action: #selector(closePresentedSurface))
        }
        navigationItem.rightBarButtonItem = UIBarButtonItem(barButtonSystemItem: .trash, target: self, action: #selector(clearHistory))
    }
    @objc private func closePresentedSurface() { dismiss(animated: true) }
    override func viewWillAppear(_ animated: Bool) { super.viewWillAppear(animated); paths = SantanderPathHistory.paths; tableView.reloadData() }
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int { paths.count }
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = UITableViewCell(style: .subtitle, reuseIdentifier: nil)
        SantanderUI.styleCell(cell)
        guard paths.indices.contains(indexPath.row) else { return cell }
        let path = paths[indexPath.row]
        var conf = cell.defaultContentConfiguration()
        conf.text = path.lastPathComponent.isEmpty ? "/" : path.lastPathComponent
        conf.secondaryText = path.path
        conf.image = path.displayImage
        cell.contentConfiguration = conf
        cell.accessoryType = .disclosureIndicator
        return cell
    }
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        guard paths.indices.contains(indexPath.row) else { return }
        navigationController?.pushViewController(PathListViewController(path: paths[indexPath.row]), animated: true)
    }
    @objc private func clearHistory() {
        presentSantanderActionSheet(title: SantanderL10n.t("Clear recent paths?"), actions: [
            SantanderActionSheetItem(title: SantanderL10n.t("Clear"), image: SantanderIconLibrary.shared.interfaceIcon(for: "trash"), style: .destructive) { [weak self] in
                UserDefaults.standard.removeObject(forKey: "SantanderRecentPaths")
                self?.paths = []
                self?.tableView.reloadData()
            },
            SantanderActionSheetItem(title: SantanderL10n.t("Cancel"), style: .cancel)
        ])
    }
}

private final class SantanderGlobalSearchTabViewController: PathListViewController {
    private var didFocusSearchOnFirstAppearance = false

    init() {
        super.init(style: .plain, path: .root)
        defaultSearchScopeIndex = 2
        title = SantanderL10n.t("Search")
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        navigationItem.titleView = nil
        navigationItem.title = SantanderL10n.t("Search")
        browserSearchController?.searchBar.placeholder = SantanderL10n.t("Search files and folders")
    }

    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        guard !didFocusSearchOnFirstAppearance else { return }
        didFocusSearchOnFirstAppearance = true
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.15) { [weak self] in
            guard let self, self.viewIfLoaded?.window != nil else { return }
            self.activateBrowserSearchController()
        }
    }
}

class SceneDelegate: UIResponder, UIWindowSceneDelegate {
    var window: UIWindow?

    var visibleSubPathsVc: PathListViewController? {
        if let tab = window?.rootViewController as? UITabBarController,
           let nav = tab.selectedViewController as? UINavigationController {
            return nav.visibleViewController as? PathListViewController
        }
        if let nav = window?.rootViewController as? UINavigationController {
            return nav.visibleViewController as? PathListViewController
        }
        if let split = window?.rootViewController as? UISplitViewController {
            if let nav = split.viewController(for: .supplementary) as? UINavigationController {
                return nav.visibleViewController as? PathListViewController
            }
            return split.viewController(for: .secondary) as? PathListViewController
        }
        return nil
    }

    func scene(_ scene: UIScene, willConnectTo session: UISceneSession, options connectionOptions: UIScene.ConnectionOptions) {
        guard let windowScene = scene as? UIWindowScene else { return }
        let window = UIWindow(windowScene: windowScene)
        let rootTransition: PathTransitioning
        let storedTabPath = SantanderBrowserTabs.shared.activePath
        let restorePath: String? = {
            if let launchPath = UserPreferences.launchPath,
               FileManager.default.fileExists(atPath: launchPath) {
                return launchPath
            }
            if storedTabPath != "/", FileManager.default.fileExists(atPath: storedTabPath) {
                return storedTabPath
            }
            return nil
        }()

        if UIDevice.isiPad {
            let splitVC = UISplitViewController(style: .tripleColumn)
            let sidebar = PathSidebarListViewController()
            let fileList = PathListViewController(style: .plain, path: .root)
            let primary = UINavigationController(rootViewController: sidebar)
            let content = UINavigationController(rootViewController: fileList)
            splitVC.setViewController(primary, for: .primary)
            splitVC.setViewController(content, for: .supplementary)
            splitVC.setViewController(UINavigationController(rootViewController: SantanderDetailPlaceholderViewController()), for: .secondary)
            SantanderBrowserTabs.shared.installInitialStack(content.viewControllers)
            splitVC.preferredDisplayMode = .oneBesideSecondary
            splitVC.show(.supplementary)
            window.rootViewController = splitVC
            rootTransition = sidebar
        } else {
            let fileVC = PathListViewController(style: .plain, path: .root)
            let fileNav = UINavigationController(rootViewController: fileVC)
            SantanderBrowserTabs.shared.installInitialStack(fileNav.viewControllers)
            fileNav.navigationBar.prefersLargeTitles = false
            window.rootViewController = fileNav
            rootTransition = fileVC
        }

        self.window = window
        SantanderUI.installBackground(in: window)
        window.makeKeyAndVisible()
        if let restorePath, restorePath != "/" {
            DispatchQueue.main.async {
                rootTransition.goToPath(path: Path(stringLiteral: restorePath))
            }
        }
        self.scene(scene, openURLContexts: connectionOptions.urlContexts)
    }

    func sceneDidDisconnect(_ scene: UIScene) { }
    func sceneDidBecomeActive(_ scene: UIScene) { }
    func sceneWillResignActive(_ scene: UIScene) { }
    func sceneWillEnterForeground(_ scene: UIScene) { }
    func sceneDidEnterBackground(_ scene: UIScene) { }

    func scene(_ scene: UIScene, openURLContexts URLContexts: Set<UIOpenURLContext>) {
        let urls = URLContexts.map { URL(fileURLWithPath: $0.url.path) }
        guard !urls.isEmpty else { return }
        var actions: [SantanderActionSheetItem] = [
            SantanderActionSheetItem(title: SantanderL10n.t("Copy Path"), image: SantanderIconLibrary.shared.interfaceIcon(for: "doc.on.doc")) { [weak self] in
                guard let self, let root = self.window?.rootViewController else { return }
                root.present(UINavigationController(rootViewController: PathOperationViewController(paths: urls, operationType: .import)), animated: true)
            }
        ]
        if urls.count == 1 {
            actions.append(SantanderActionSheetItem(title: SantanderL10n.t("View item"), image: SantanderIconLibrary.shared.interfaceIcon(for: "doc.text.magnifyingglass")) { [weak self] in
                guard let self else { return }
                let item = urls[0]
                let fileVC = PathListViewController(path: Path(url: item.deletingLastPathComponent()))
                let root = self.window?.rootViewController
                if let tabs = root as? UITabBarController { tabs.selectedIndex = 0 }
                let nav = (root as? UITabBarController)?.selectedViewController as? UINavigationController ?? (root as? UINavigationController)
                nav?.pushViewController(fileVC, animated: true) { fileVC.selectPathWhenLoaded(Path(url: item)) }
            })
        }
        actions.append(SantanderActionSheetItem(title: SantanderL10n.t("Cancel"), style: .cancel))
        window?.rootViewController?.presentSantanderActionSheet(title: SantanderL10n.t("URL(s) being imported to app, would you like to copy it to another path?"), actions: actions)
    }
}

fileprivate extension UINavigationController {
    func pushViewController(_ viewController: UIViewController, animated: Bool, completion: @escaping (() -> Void)) {
        pushViewController(viewController, animated: animated)
        
        guard animated, let coordinator = transitionCoordinator else {
            completion()
            return
        }
        
        coordinator.animate(alongsideTransition: nil) { _ in completion() }
    }
}


class AppInfoViewController: UITableViewController {
    let app: SantanderApplication
    let subPathsSender: PathListViewController

    init(style: UITableView.Style, app: SantanderApplication, subPathsSender: PathListViewController) {
        self.app = app
        self.subPathsSender = subPathsSender
        super.init(style: style)
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        applySantanderUI()
        navigationItem.titleView = UIImageView(image: ApplicationsManager.shared.icon(forApplication: app))
    }

    override func numberOfSections(in tableView: UITableView) -> Int {
        return 5
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        switch section {
        case 0:
            return app.claimedURLSchemes.isEmpty ? 4 : 5
        case 1:
            return 2
        case 2:
            return 4
        case 3:
            return 2
        case 4:
            return 2
        default:
            return 0
        }
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = UITableViewCell(style: .value1, reuseIdentifier: nil)
        SantanderUI.styleCell(cell)
        var conf = cell.defaultContentConfiguration()

        defer {
            cell.contentConfiguration = conf
        }

        switch (indexPath.section, indexPath.row) {
        case (0, 0):
            conf.text = SantanderL10n.t("Name")
            conf.secondaryText = app.localizedName
        case (0, 1):
            conf.text = SantanderL10n.t("Bundle ID")
            conf.secondaryText = app.applicationIdentifier
        case (0, 2):
            conf.text = SantanderL10n.t("SDK Version")
            conf.secondaryText = app.sdkVersion
        case (0, 3):
            conf.text = SantanderL10n.t("Type")
            conf.secondaryText = app.applicationType
        case (0, 4):
            conf.text = SantanderL10n.t("URL schemes")
            conf.secondaryText = app.claimedURLSchemes.joined(separator: ", ")
        case (1, 0):
            conf.text = SantanderL10n.t("Team ID")
            conf.secondaryText = app.teamID
        case (1, 1):
            conf.text = SantanderL10n.t("Entitlements")
            cell.accessoryType = .disclosureIndicator
        case (2, 0):
            conf.text = SantanderL10n.t("Deletable")
            cell.accessoryType = app.isDeletable ? .checkmark : .none
        case (2, 1):
            conf.text = SantanderL10n.t("Beta app")
            cell.accessoryType = app.isBetaApp ? .checkmark : .none
        case (2, 2):
            conf.text = SantanderL10n.t("Restricted")
            cell.accessoryType = app.isRestricted ? .checkmark : .none
        case (2, 3):
            conf.text = SantanderL10n.t("Containerized")
            cell.accessoryType = app.isContainerized ? .checkmark : .none
        case (3, 0):
            conf.text = SantanderL10n.t("Container URL")
            conf.secondaryText = app.containerURL().path
        case (3, 1):
            conf.text = SantanderL10n.t("Bundle URL")
            conf.secondaryText = app.bundleURL().path
        case (4, 0):
            conf.text = SantanderL10n.t("Open")
            conf.textProperties.color = SantanderAppTheme.accentColor
        case (4, 1):
            conf.text = SantanderL10n.t("Delete")
            conf.textProperties.color = .systemRed
        default:
            conf.text = SantanderL10n.t("Unavailable")
            cell.selectionStyle = .none
        }

        return cell
    }

    override func tableView(_ tableView: UITableView, shouldHighlightRowAt indexPath: IndexPath) -> Bool {
        switch indexPath.section {
        case 3, 4:
            return true
        default:
            return (indexPath.section, indexPath.row) == (1, 1)
        }
    }

    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        switch (indexPath.section, indexPath.row) {
        case (1, 1):
            let dict = app.entitlements.asSerializedDictionary()
            let vc = PlistTreeEditorViewController(rootValue: dict.asAnyDictionary(), format: nil, fileURL: nil, title: SantanderL10n.t("Entitlements"), canEdit: false)
            self.navigationController?.pushViewController(vc, animated: true)
        case (3, 0):
            dismissAndGoToURL(app.containerURL())
        case (3, 1):
            dismissAndGoToURL(app.bundleURL())
        case (4, 0):
            do {
                try ApplicationsManager.shared.openApp(app)
            } catch {
                self.errorAlert(error, title: "无法打开 \(app.localizedName)")
            }
        case (4, 1):
            do {
                try ApplicationsManager.shared.deleteApp(app)
                self.dismiss(animated: true)
                subPathsSender.tableView.reloadData()
            } catch {
                self.errorAlert(error, title: SantanderL10n.t("Unable to delete app"))
            }
        default:
            break
        }
    }

    func dismissAndGoToURL(_ url: URL) {
        self.dismiss(animated: true)
        subPathsSender.goToPath(path: Path(url: url))
    }
}

private func santanderDownsampledPreviewImage(at url: URL, maximumPixelSize: Int = 4096) -> UIImage? {
    guard let source = CGImageSourceCreateWithURL(url as CFURL, nil) else { return nil }
    let options: [CFString: Any] = [
        kCGImageSourceCreateThumbnailFromImageAlways: true,
        kCGImageSourceThumbnailMaxPixelSize: max(512, maximumPixelSize),
        kCGImageSourceCreateThumbnailWithTransform: true
    ]
    guard let image = CGImageSourceCreateThumbnailAtIndex(source, 0, options as CFDictionary) else { return nil }
    return UIImage(cgImage: image)
}

final class SantanderFilePreviewController: UIViewController {
    private let fileURL: URL
    private let textLimit = 2 * 1024 * 1024
    private let binaryLimit = 64 * 1024
    private var embeddedPlayer: AVPlayerViewController?

    init(fileURL: URL) {
        self.fileURL = fileURL.standardizedFileURL
        super.init(nibName: nil, bundle: nil)
        title = fileURL.lastPathComponent.isEmpty ? "/" : fileURL.lastPathComponent
        modalPresentationStyle = .fullScreen
    }

    required init?(coder: NSCoder) { fatalError("init(coder:) has not been implemented") }

    override func viewDidLoad() {
        super.viewDidLoad()
        applySantanderUI()
        view.backgroundColor = .systemBackground
        navigationItem.largeTitleDisplayMode = .never
        navigationItem.rightBarButtonItem = UIBarButtonItem(title: SantanderL10n.t("Done"), style: .done, target: self, action: #selector(closePreview))
        installPreviewContent()
    }

    @objc private func closePreview() {
        if let navigationController,
           navigationController.viewControllers.first === self,
           navigationController.presentingViewController != nil {
            navigationController.dismiss(animated: true)
        } else if let navigationController, navigationController.viewControllers.count > 1 {
            navigationController.popViewController(animated: true)
        } else {
            dismiss(animated: true)
        }
    }

    private func installPreviewContent() {
        let ext = fileURL.pathExtension.lowercased()
        let imageExtensions: Set<String> = ["png", "jpg", "jpeg", "gif", "heic", "heif", "tif", "tiff", "bmp", "webp", "icns"]
        let videoExtensions: Set<String> = ["mov", "mp4", "m4v", "avi", "mkv", "webm", "3gp"]
        let audioExtensions: Set<String> = ["mp3", "m4a", "aac", "wav", "aiff", "caf", "flac", "ogg", "opus"]

        if imageExtensions.contains(ext), let image = santanderDownsampledPreviewImage(at: fileURL) {
            installImage(image)
            return
        }

        if ext == "pdf", let document = PDFDocument(url: fileURL) {
            let pdfView = PDFView()
            pdfView.translatesAutoresizingMaskIntoConstraints = false
            pdfView.autoScales = true
            pdfView.displayMode = .singlePageContinuous
            pdfView.displayDirection = .vertical
            pdfView.backgroundColor = .secondarySystemBackground
            pdfView.document = document
            mount(pdfView)
            return
        }

        if videoExtensions.contains(ext) || audioExtensions.contains(ext) {
            installMediaPlayer()
            return
        }

        let data = readPrefix(limit: textLimit)
        let attributes = try? FileManager.default.attributesOfItem(atPath: fileURL.path)
        let fileSize = (attributes?[.size] as? NSNumber)?.int64Value ?? Int64(data.count)
        let knownTextExtensions: Set<String> = [
            "txt", "text", "log", "md", "markdown", "swift", "m", "h", "c", "cc", "cpp", "hpp", "mm", "rs", "go", "py", "js", "ts", "jsx", "tsx", "html", "htm", "css", "scss", "xml", "plist", "json", "yaml", "yml", "toml", "ini", "conf", "cfg", "sh", "bash", "zsh", "fish", "command", "makefile", "sql", "csv", "tsv", "strings", "stringsdict", "entitlements", "mobileconfig", "pem", "cer", "crt", "key", "pub", "patch", "diff", "gitignore", "properties"
        ]
        if !data.isEmpty,
           !data.contains(0),
           let text = String(data: data, encoding: .utf8),
           knownTextExtensions.contains(ext) || looksLikeText(data) {
            installText(prettify(text, extension: ext), isTruncated: fileSize > Int64(data.count))
            return
        }
        installHex(data, fileSize: fileSize)
    }

    private func mount(_ content: UIView) {
        content.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(content)
        NSLayoutConstraint.activate([
            content.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor),
            content.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor),
            content.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
            content.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor)
        ])
    }

    private func installImage(_ image: UIImage) {
        let scrollView = UIScrollView()
        scrollView.minimumZoomScale = 1
        scrollView.maximumZoomScale = 5
        scrollView.backgroundColor = .black
        scrollView.delegate = self
        let imageView = UIImageView(image: image)
        imageView.contentMode = .scaleAspectFit
        imageView.translatesAutoresizingMaskIntoConstraints = false
        scrollView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(scrollView)
        scrollView.addSubview(imageView)
        NSLayoutConstraint.activate([
            scrollView.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor),
            scrollView.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor),
            scrollView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
            scrollView.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor),
            imageView.leadingAnchor.constraint(equalTo: scrollView.contentLayoutGuide.leadingAnchor),
            imageView.trailingAnchor.constraint(equalTo: scrollView.contentLayoutGuide.trailingAnchor),
            imageView.topAnchor.constraint(equalTo: scrollView.contentLayoutGuide.topAnchor),
            imageView.bottomAnchor.constraint(equalTo: scrollView.contentLayoutGuide.bottomAnchor),
            imageView.widthAnchor.constraint(equalTo: scrollView.frameLayoutGuide.widthAnchor),
            imageView.heightAnchor.constraint(equalTo: scrollView.frameLayoutGuide.heightAnchor)
        ])
        scrollView.accessibilityLabel = title
    }

    private func installMediaPlayer() {
        let controller = AVPlayerViewController()
        controller.player = AVPlayer(url: fileURL)
        controller.allowsPictureInPicturePlayback = true
        if #available(iOS 14.2, *) {
            controller.canStartPictureInPictureAutomaticallyFromInline = true
        }
        addChild(controller)
        controller.view.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(controller.view)
        NSLayoutConstraint.activate([
            controller.view.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor),
            controller.view.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor),
            controller.view.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
            controller.view.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor)
        ])
        controller.didMove(toParent: self)
        embeddedPlayer = controller
    }

    private func installText(_ text: String, isTruncated: Bool) {
        let container = UIView()
        let textView = UITextView()
        textView.translatesAutoresizingMaskIntoConstraints = false
        textView.isEditable = false
        textView.isSelectable = true
        textView.alwaysBounceVertical = true
        textView.backgroundColor = .systemBackground
        textView.textColor = .label
        textView.font = UIFont.monospacedSystemFont(ofSize: 13, weight: .regular)
        textView.text = text
        container.addSubview(textView)
        if isTruncated {
            let banner = UILabel()
            banner.translatesAutoresizingMaskIntoConstraints = false
            banner.text = "仅预览文件开头的 2 MB，完整内容未载入以节省内存。"
            banner.font = .preferredFont(forTextStyle: .footnote)
            banner.textColor = .secondaryLabel
            banner.numberOfLines = 0
            banner.backgroundColor = .secondarySystemBackground
            banner.layoutMargins = UIEdgeInsets(top: 8, left: 12, bottom: 8, right: 12)
            container.addSubview(banner)
            NSLayoutConstraint.activate([
                banner.leadingAnchor.constraint(equalTo: container.leadingAnchor),
                banner.trailingAnchor.constraint(equalTo: container.trailingAnchor),
                banner.topAnchor.constraint(equalTo: container.topAnchor),
                textView.topAnchor.constraint(equalTo: banner.bottomAnchor)
            ])
        } else {
            textView.topAnchor.constraint(equalTo: container.topAnchor).isActive = true
        }
        NSLayoutConstraint.activate([
            textView.leadingAnchor.constraint(equalTo: container.leadingAnchor),
            textView.trailingAnchor.constraint(equalTo: container.trailingAnchor),
            textView.bottomAnchor.constraint(equalTo: container.bottomAnchor)
        ])
        mount(container)
    }

    private func installHex(_ data: Data, fileSize: Int64) {
        let bytes = Array(data.prefix(binaryLimit))
        var lines: [String] = ["文件大小：\(ByteCountFormatter.string(fromByteCount: fileSize, countStyle: .file))", "偏移量             十六进制字节                                             ASCII", ""]
        let chunkSize = 16
        for offset in stride(from: 0, to: bytes.count, by: chunkSize) {
            let slice = bytes[offset..<min(offset + chunkSize, bytes.count)]
            let hex = slice.map { String(format: "%02X", $0) }.joined(separator: " ")
            let ascii = slice.map { byte -> Character in
                (byte >= 32 && byte < 127) ? Character(UnicodeScalar(byte)) : "."
            }
            let paddedHex = hex.padding(toLength: 47, withPad: " ", startingAt: 0)
            lines.append(String(format: "%08X", offset) + "  " + paddedHex + "  " + String(ascii))
        }
        if fileSize > Int64(bytes.count) {
            lines.append("\n仅显示前 \(ByteCountFormatter.string(fromByteCount: Int64(bytes.count), countStyle: .file))；如需编辑完整二进制，请使用十六进制编辑器。")
        }
        installText(lines.joined(separator: "\n"), isTruncated: false)
    }

    private func readPrefix(limit: Int) -> Data {
        guard let handle = try? FileHandle(forReadingFrom: fileURL) else { return Data() }
        defer { try? handle.close() }
        return (try? handle.read(upToCount: limit)) ?? Data()
    }

    private func looksLikeText(_ data: Data) -> Bool {
        guard !data.isEmpty, !data.contains(0) else { return false }
        let allowedControls = data.reduce(into: 0) { count, byte in
            if byte < 9 || (byte > 13 && byte < 32) { count += 1 }
        }
        return allowedControls * 100 < data.count
    }

    private func prettify(_ text: String, extension ext: String) -> String {
        if ext == "json",
           let data = text.data(using: .utf8),
           let object = try? JSONSerialization.jsonObject(with: data),
           let pretty = try? JSONSerialization.data(withJSONObject: object, options: [.prettyPrinted, .sortedKeys]),
           let output = String(data: pretty, encoding: .utf8) {
            return output
        }
        if ext == "plist",
           let data = text.data(using: .utf8),
           let object = try? PropertyListSerialization.propertyList(from: data, options: [], format: nil),
           let output = try? PropertyListSerialization.data(fromPropertyList: object, format: .xml, options: 0),
           let pretty = String(data: output, encoding: .utf8) {
            return pretty
        }
        return text
    }
}

extension SantanderFilePreviewController: UIScrollViewDelegate {
    func viewForZooming(in scrollView: UIScrollView) -> UIView? {
        scrollView.subviews.first
    }
}

class SettingsTableViewController: UITableViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        applySantanderUI()

        self.title = SantanderL10n.t("Settings")
        self.navigationController?.navigationBar.prefersLargeTitles = false
        if let navigationController,
           navigationController.viewControllers.first === self,
           navigationController.presentingViewController != nil {
            navigationItem.leftBarButtonItem = UIBarButtonItem(title: "完成", style: .plain, target: self, action: #selector(closePresentedSurface))
        }
    }

    @objc private func closePresentedSurface() { dismiss(animated: true) }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        if isViewLoaded { tableView.reloadData() }
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    override init(style: UITableView.Style) {
        super.init(style: style)
    }

    override func numberOfSections(in tableView: UITableView) -> Int {
        return 4
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        switch section {
        case 0: return 0
        case 1: return 6
        case 2: return 5
        case 3: return UserPreferences.useLastOpenedPathWhenLaunching ? 1 : 2
        default: return 0
        }
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        switch (indexPath.section, indexPath.row) {
        case (0, 0):
            return cellWithView(settingsSwitch(forIndexPath: indexPath), text: SantanderL10n.t("Santander Helper"))
        case (1, 0):
            return cellWithView(settingsSwitch(forIndexPath: indexPath), text: SantanderL10n.t("Large navigation titles"))
        case (1, 1):
            return cellWithView(settingsSwitch(forIndexPath: indexPath), text: SantanderL10n.t("Always show search bar"))
        case (1, 2):
            let cell = UITableViewCell(style: .value1, reuseIdentifier: nil)
            SantanderUI.styleCell(cell)
            var conf = cell.defaultContentConfiguration()
            conf.text = SantanderL10n.t("List density")
            conf.secondaryText = UserPreferences.listDensity.title
            conf.secondaryTextProperties.color = SantanderAppTheme.accentColor
            cell.accessoryType = .disclosureIndicator
            cell.contentConfiguration = conf
            return cell
        case (1, 3):
            let cell = UITableViewCell(style: .value1, reuseIdentifier: nil)
            SantanderUI.styleCell(cell)
            cell.selectionStyle = .none
            var conf = cell.defaultContentConfiguration()
            conf.text = SantanderL10n.t("Show hidden files by default")
            let toggle = UISwitch()
            toggle.isOn = UserPreferences.displayHiddenFiles
            toggle.addAction(UIAction { [weak toggle] _ in
                guard let toggle else { return }
                UserPreferences.displayHiddenFiles = toggle.isOn
                NotificationCenter.default.post(name: Notification.Name("SantanderDisplayHiddenFilesDidChange"), object: nil)
            }, for: .valueChanged)
            cell.accessoryView = toggle
            cell.contentConfiguration = conf
            return cell
        case (1, 4):
            let cell = UITableViewCell(style: .value1, reuseIdentifier: nil)
            SantanderUI.styleCell(cell)
            var conf = cell.defaultContentConfiguration()
            conf.text = SantanderL10n.t("Default sorting")
            conf.secondaryText = (PathsSortMethods.userPrefered ?? .alphabetically).description
            conf.secondaryTextProperties.color = SantanderAppTheme.accentColor
            cell.accessoryType = .disclosureIndicator
            cell.contentConfiguration = conf
            return cell
        case (1, 5):
            let cell = UITableViewCell(style: .value1, reuseIdentifier: nil)
            SantanderUI.styleCell(cell)
            var conf = cell.defaultContentConfiguration()
            conf.text = "主题与外观"
            conf.secondaryText = SantanderAppTheme.summary
            conf.secondaryTextProperties.color = SantanderAppTheme.accentColor
            cell.accessoryType = .disclosureIndicator
            cell.contentConfiguration = conf
            return cell
        case (2, 0):
            let cell = UITableViewCell(style: .value1, reuseIdentifier: nil)
            SantanderUI.styleCell(cell)
            var conf = cell.defaultContentConfiguration()
            conf.text = SantanderL10n.t("File associations")
            conf.secondaryText = UserPreferences.fileAssociations.isEmpty
                ? SantanderL10n.t("Default viewer")
                : "\(UserPreferences.fileAssociations.count)"
            conf.secondaryTextProperties.color = SantanderAppTheme.accentColor
            cell.accessoryType = .disclosureIndicator
            cell.contentConfiguration = conf
            return cell
        case (2, 1):
            let cell = UITableViewCell(style: .value1, reuseIdentifier: nil)
            SantanderUI.styleCell(cell)
            var conf = cell.defaultContentConfiguration()
            let theme = UserPreferences.textEditorTheme(for: traitCollection.userInterfaceStyle)
            conf.text = SantanderL10n.t("Text Editor Settings")
            conf.secondaryText = "\(Int(theme.font.uiFont.pointSize)) pt"
            conf.secondaryTextProperties.color = SantanderAppTheme.accentColor
            cell.accessoryType = .disclosureIndicator
            cell.contentConfiguration = conf
            return cell
        case (2, 2), (2, 3), (2, 4):
            let cell = UITableViewCell(style: .value1, reuseIdentifier: nil)
            SantanderUI.styleCell(cell)
            cell.selectionStyle = .none
            var conf = cell.defaultContentConfiguration()
            switch indexPath.row {
            case 2: conf.text = SantanderL10n.t("Wrap Lines")
            case 3: conf.text = SantanderL10n.t("Show Line Count")
            default: conf.text = SantanderL10n.t("Use Character Pairs")
            }
            cell.accessoryView = settingsSwitch(forIndexPath: indexPath)
            cell.contentConfiguration = conf
            return cell
        case (3, 0):
            return cellWithView(setupLaunchPathButton(), text: SantanderL10n.t("Launch Path"))
        case (3, 1):
            let cell = UITableViewCell(style: .value1, reuseIdentifier: nil)
            SantanderUI.styleCell(cell)
            var conf = cell.defaultContentConfiguration()
            conf.text = SantanderL10n.t("Custom Launch Path")
            conf.secondaryText = UserPreferences.userPreferredLaunchPath ?? SantanderL10n.t("N/A")
            cell.contentConfiguration = conf
            return cell
        default:
            let cell = UITableViewCell(style: .default, reuseIdentifier: nil)
            cell.isUserInteractionEnabled = false
            return cell
        }
    }

    fileprivate func setupLaunchPathButton() -> UIButton {
        let button = UIButton(type: .system)
        let customPathChosen = !UserPreferences.useLastOpenedPathWhenLaunching
        button.setTitle(customPathChosen ? SantanderL10n.t("Custom Path") : SantanderL10n.t("Last Opened Path"), for: .normal)
        button.setTitleColor(.secondaryLabel, for: .normal)
        button.contentHorizontalAlignment = .center
        button.addTarget(self, action: #selector(showLaunchPathOptions), for: .touchUpInside)
        return button
    }

    @objc fileprivate func showLaunchPathOptions() {
        let actions = [
            SantanderActionSheetItem(title: SantanderL10n.t("Last Opened Path"), image: SantanderIconLibrary.shared.interfaceIcon(for: "clock.arrow.circlepath"), isSelected: UserPreferences.useLastOpenedPathWhenLaunching) { [weak self] in
                UserPreferences.useLastOpenedPathWhenLaunching = true
                self?.tableView.reloadData()
            },
            SantanderActionSheetItem(title: SantanderL10n.t("Custom Path"), image: SantanderIconLibrary.shared.interfaceIcon(for: "folder"), isSelected: !UserPreferences.useLastOpenedPathWhenLaunching) { [weak self] in
                guard let self else { return }
                UserPreferences.useLastOpenedPathWhenLaunching = false
                if UserPreferences.userPreferredLaunchPath == nil {
                    self.changeCustomLaunchPathAlert()
                } else {
                    self.tableView.reloadData()
                }
            },
            SantanderActionSheetItem(title: SantanderL10n.t("Cancel"), style: .cancel)
        ]
        presentSantanderActionSheet(title: SantanderL10n.t("Launch Path"), actions: actions)
    }

    override func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        switch section {
        case 0: return nil
        case 1: return SantanderL10n.t("General")
        case 2: return SantanderL10n.t("Editors")
        case 3: return SantanderL10n.t("Other")
        default: return nil
        }
    }

    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        switch (indexPath.section, indexPath.row) {
        case (1, 4):
            let current = PathsSortMethods.userPrefered ?? .alphabetically
            let actions = PathsSortMethods.allCases.map { sort in
                SantanderActionSheetItem(title: sort.description, isSelected: sort == current) { [weak self] in
                    UserDefaults.standard.set(sort.rawValue, forKey: "SubPathsSortMode")
                    NotificationCenter.default.post(name: Notification.Name("SantanderDefaultSortDidChange"), object: nil)
                    self?.tableView.reloadRows(at: [IndexPath(row: 4, section: 1)], with: .automatic)
                }
            }
            presentSantanderActionSheet(title: SantanderL10n.t("Default sorting"), actions: actions + [SantanderActionSheetItem(title: SantanderL10n.t("Cancel"), style: .cancel)])
        case (1, 5):
            navigationController?.pushViewController(SantanderThemeSettingsViewController(style: .grouped), animated: true)
        case (1, 2):
            let actions = SantanderListDensity.allCases.map { density in
                SantanderActionSheetItem(title: density.title, isSelected: density == UserPreferences.listDensity) { [weak self] in
                    UserPreferences.listDensity = density
                    NotificationCenter.default.post(name: Notification.Name("SantanderListAppearanceDidChange"), object: nil)
                    self?.tableView.reloadData()
                }
            }
            presentSantanderActionSheet(title: SantanderL10n.t("List density"), actions: actions + [SantanderActionSheetItem(title: SantanderL10n.t("Cancel"), style: .cancel)])
        case (2, 0):
            navigationController?.pushViewController(FileAssociationsViewController(style: .insetGrouped), animated: true)
        case (2, 1):
            let theme = UserPreferences.textEditorTheme(for: traitCollection.userInterfaceStyle)
            let controller = TextEditorThemeSettingsViewController(style: .insetGrouped, theme: theme)
            controller.persistGlobally = true
            navigationController?.pushViewController(controller, animated: true)
        case (3, 1):
            self.changeCustomLaunchPathAlert()
        default:
            break
        }
    }

    override func tableView(_ tableView: UITableView, shouldHighlightRowAt indexPath: IndexPath) -> Bool {
        return (indexPath.section, indexPath.row) == (1, 2)
            || (indexPath.section, indexPath.row) == (1, 5)
            || (indexPath.section, indexPath.row) == (2, 0)
            || (indexPath.section, indexPath.row) == (2, 1)
            || (indexPath.section, indexPath.row) == (3, 1)
    }

    func defaultsKey(forIndexPath indexPath: IndexPath) -> String {
        switch (indexPath.section, indexPath.row) {
        case (0, 0):
            return "RootHelperEnabled"
        case (1, 0):
            return "UseLargeNavTitles"
        case (1, 1):
            return "AlwaysShowSearchBar"
        case (2, 2):
            return "TextEditorWrapLines"
        case (2, 3):
            return "TextEditorShowLineCount"
        case (2, 4):
            return "TextEditorUseCharacterPairs"
        default:
            return "SantanderInvalidSetting"
        }
    }

    fileprivate func changeCustomLaunchPathAlert() {
        let alert = UIAlertController(title: SantanderL10n.t("Path"), message: SantanderL10n.t("Enter the other path you want to be opened at launch"), preferredStyle: .alert)
        alert.addTextField()
        alert.addAction(.cancel())

        let applyAction = UIAlertAction(title: SantanderL10n.t("Add"), style: .default) { _ in
            guard let text = alert.textFields?.first?.text, !text.isEmpty else {
                self.errorAlert(SantanderL10n.t("Input text is invalid or empty"), title: SantanderL10n.t("Unable to set path as Launch Path"))
                return
            }

            let url = URL(fileURLWithPath: text)
            guard url.isDirectory else {
                self.errorAlert(SantanderL10n.t("Path must be a directory"), title: SantanderL10n.t("Unable to set path as Launch Path"))
                return
            }

            UserPreferences.useLastOpenedPathWhenLaunching = false
            UserPreferences.userPreferredLaunchPath = url.path
        }
        alert.addAction(applyAction)
        self.present(alert, animated: true)
    }

    func switchOptionIsEnabled(forIndexPath indexPath: IndexPath) -> Bool {
        switch (indexPath.section, indexPath.row) {
        case (0, 0): return UserPreferences.rootHelperIsEnabled
        case (1, 0): return UserPreferences.useLargeNavigationTitles
        case (1, 1): return UserPreferences.alwaysShowSearchBar
        case (2, 2): return UserPreferences.wrapLines
        case (2, 3): return UserPreferences.showLineCount
        case (2, 4): return UserPreferences.useCharacterPairs
        default: return false
        }
    }

    func settingsSwitch(forIndexPath indexPath: IndexPath) -> UISwitch {
        let s = UISwitch()
        s.isOn = switchOptionIsEnabled(forIndexPath: indexPath)
        let action = UIAction { [self] _ in
            if (indexPath.section, indexPath.row) == (0, 0) {
                rootHelperDidClickEnable()
            } else {
                UserDefaults.standard.set(s.isOn, forKey: defaultsKey(forIndexPath: indexPath))
            }
        }

        s.addAction(action, for: .valueChanged)
        return s
    }

    fileprivate func rootHelperDidClickEnable() {
        let context = LAContext()
        if UserPreferences.rootHelperIsEnabled || !context.canEvaluatePolicy(.deviceOwnerAuthentication, error: nil) {
            UserPreferences.rootHelperIsEnabled.toggle()
            return
        }

        context.evaluatePolicy(.deviceOwnerAuthentication, localizedReason: SantanderL10n.t("To enable Santander Helper.")) { didSucceed, error in
            guard didSucceed else {
                DispatchQueue.main.async {
                    self.errorAlert(error?.localizedDescription ?? SantanderL10n.t("Unknown Error"), title: SantanderL10n.t("Unable to authenticate"))
                    self.tableView.reloadRows(at: [IndexPath(row: 0, section: 0)], with: .automatic)
                }
                return
            }

            UserPreferences.rootHelperIsEnabled = true
            DispatchQueue.main.async {
                self.tableView.reloadRows(at: [IndexPath(row: 0, section: 0)], with: .automatic)
            }
        }
    }
}

final class FileAssociationsViewController: UITableViewController {
    override func viewDidLoad() {
        super.viewDidLoad()
        applySantanderUI()
        title = SantanderL10n.t("File associations")
        navigationItem.rightBarButtonItems = [
            editButtonItem,
            UIBarButtonItem(barButtonSystemItem: .add, target: self, action: #selector(addAssociation))
        ]
        tableView.register(UITableViewCell.self, forCellReuseIdentifier: "FileAssociationCell")
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        tableView.reloadData()
    }

    override func numberOfSections(in tableView: UITableView) -> Int { 1 }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        UserPreferences.fileAssociations.count
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "FileAssociationCell", for: indexPath)
        let associations = UserPreferences.fileAssociations
        guard associations.indices.contains(indexPath.row) else { return cell }
        let association = associations[indexPath.row]
        SantanderUI.styleCell(cell)
        var conf = cell.defaultContentConfiguration()
        conf.text = ".\(association.suffix)"
        conf.secondaryText = association.editor?.description ?? association.editorRawValue
        conf.secondaryTextProperties.color = SantanderAppTheme.accentColor
        conf.image = nil
        conf.directionalLayoutMargins = NSDirectionalEdgeInsets(top: 0, leading: 20, bottom: 0, trailing: 4)
        cell.accessoryType = .disclosureIndicator
        cell.contentConfiguration = conf
        cell.selectionStyle = .default
        return cell
    }

    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let associations = UserPreferences.fileAssociations
        guard associations.indices.contains(indexPath.row) else { return }
        let association = associations[indexPath.row]
        let controller = FileAssociationEditorViewController(association: association)
        navigationController?.pushViewController(controller, animated: true)
    }

    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        guard editingStyle == .delete else { return }
        let associations = UserPreferences.fileAssociations
        guard associations.indices.contains(indexPath.row) else { return }
        let association = associations[indexPath.row]
        UserPreferences.removeFileAssociation(suffix: association.suffix)
        tableView.deleteRows(at: [indexPath], with: .automatic)
    }

    @objc private func addAssociation() {
        let alert = UIAlertController(
            title: SantanderL10n.t("Add association"),
            message: SantanderL10n.t("File extension"),
            preferredStyle: .alert
        )
        alert.addTextField { field in
            field.placeholder = "plist"
            field.autocapitalizationType = .none
            field.autocorrectionType = .no
        }
        alert.addAction(.cancel())
        alert.addAction(UIAlertAction(title: SantanderL10n.t("Add"), style: .default) { [weak self, weak alert] _ in
            guard let self,
                  let value = alert?.textFields?.first?.text,
                  let normalized = self.normalizedSuffix(value),
                  !normalized.isEmpty else {
                return
            }

            UserPreferences.setFileAssociation(suffix: normalized, editor: .text)
            let association = UserPreferences.fileAssociations.first { $0.suffix == normalized }
                ?? SantanderFileAssociation(suffix: normalized, editorRawValue: FileEditorType.text.rawValue)
            self.tableView.reloadData()

            let controller = FileAssociationEditorViewController(association: association)
            self.navigationController?.pushViewController(controller, animated: true)
        })
        present(alert, animated: true)
    }

    private func normalizedSuffix(_ value: String) -> String? {
        let suffix = value
            .trimmingCharacters(in: .whitespacesAndNewlines)
            .trimmingCharacters(in: CharacterSet(charactersIn: "."))
            .lowercased()

        guard !suffix.isEmpty,
              suffix.count <= 32,
              !suffix.contains("/"),
              !suffix.contains(" "),
              !suffix.contains("\\") else {
            return nil
        }
        return suffix
    }
}

final class FileAssociationEditorViewController: UITableViewController {
    private var association: SantanderFileAssociation
    private var suffix: String
    private var editor: FileEditorType
    private let suffixField = UITextField()

    init(association: SantanderFileAssociation) {
        self.association = association
        self.suffix = association.suffix
        self.editor = association.editor ?? .text
        super.init(style: .insetGrouped)
    }

    required init?(coder: NSCoder) { fatalError() }

    override func viewDidLoad() {
        super.viewDidLoad()
        applySantanderUI()
        title = ".\(suffix)"
        navigationItem.rightBarButtonItem = UIBarButtonItem(
            barButtonSystemItem: .save,
            target: self,
            action: #selector(saveAssociation)
        )

        suffixField.text = suffix
        suffixField.autocapitalizationType = .none
        suffixField.autocorrectionType = .no
        suffixField.returnKeyType = .done
    }

    override func numberOfSections(in tableView: UITableView) -> Int { 2 }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int { 1 }

    override func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        section == 0 ? SantanderL10n.t("File extension") : SantanderL10n.t("Viewer")
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if indexPath.section == 0 {
            let cell = UITableViewCell(style: .default, reuseIdentifier: nil)
            SantanderUI.styleCell(cell)
            cell.contentView.addSubview(suffixField)
            suffixField.translatesAutoresizingMaskIntoConstraints = false
            NSLayoutConstraint.activate([
                suffixField.leadingAnchor.constraint(equalTo: cell.contentView.layoutMarginsGuide.leadingAnchor),
                suffixField.trailingAnchor.constraint(equalTo: cell.contentView.layoutMarginsGuide.trailingAnchor),
                suffixField.topAnchor.constraint(equalTo: cell.contentView.topAnchor, constant: 6),
                suffixField.bottomAnchor.constraint(equalTo: cell.contentView.bottomAnchor, constant: -6),
                suffixField.heightAnchor.constraint(greaterThanOrEqualToConstant: 36)
            ])
            return cell
        }

        let cell = UITableViewCell(style: .value1, reuseIdentifier: nil)
        SantanderUI.styleCell(cell)
        var conf = cell.defaultContentConfiguration()
        conf.text = editor.description
        conf.image = editor.menuImage
        cell.accessoryType = .disclosureIndicator
        cell.contentConfiguration = conf
        return cell
    }

    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        guard indexPath.section == 1 else { return }
        tableView.deselectRow(at: indexPath, animated: true)

        let actions = FileEditorType.allCases.filter { $0 != .assetCatalog }.map { candidate in
            SantanderActionSheetItem(title: candidate.description, image: candidate.menuImage, isSelected: candidate == editor) { [weak self] in
                self?.editor = candidate
                self?.tableView.reloadRows(at: [IndexPath(row: 0, section: 1)], with: .automatic)
            }
        }
        presentSantanderActionSheet(title: SantanderL10n.t("Viewer"), actions: actions + [SantanderActionSheetItem(title: SantanderL10n.t("Cancel"), style: .cancel)])
    }

    @objc private func saveAssociation() {
        let normalized = suffixField.text?
            .trimmingCharacters(in: .whitespacesAndNewlines)
            .trimmingCharacters(in: CharacterSet(charactersIn: "."))
            .lowercased() ?? ""

        guard !normalized.isEmpty,
              normalized.count <= 32,
              !normalized.contains("/"),
              !normalized.contains(" "),
              !normalized.contains("\\") else {
            errorAlert(SantanderL10n.t("Invalid file extension"), title: SantanderL10n.t("File association"))
            return
        }

        if normalized != suffix,
           UserPreferences.fileAssociations.contains(where: { $0.suffix.lowercased() == normalized }) {
            errorAlert("该后缀已经存在。", title: SantanderL10n.t("File association"))
            return
        }

        if normalized != suffix {
            UserPreferences.removeFileAssociation(suffix: suffix)
        }
        UserPreferences.setFileAssociation(suffix: normalized, editor: editor)
        suffix = normalized
        association = SantanderFileAssociation(suffix: normalized, editorRawValue: editor.rawValue)
        title = ".\(normalized)"
        navigationController?.popViewController(animated: true)
    }
}

class TypesSelectionCollectionViewController: UICollectionViewController {
    typealias DismissHandler = (([UTType]) -> Void)

    typealias Item = DiffableDataSourceItem<Section, UTType>
    typealias DataSource = UICollectionViewDiffableDataSource<Section, Item>
    typealias CellRegistration = UICollectionView.CellRegistration<UICollectionViewListCell, Item>

    var dismissHandler: DismissHandler
    var dataSource: DataSource!
    var selectedTypes: Set<UTType> = [] {
        didSet {
            navigationItem.rightBarButtonItem?.isEnabled = !selectedTypes.isEmpty
        }
    }

    let allItems = TypesCollection.all()

    init(dismissHandler: @escaping DismissHandler) {
        self.dismissHandler = dismissHandler

        let layout = UICollectionViewCompositionalLayout { _, env in
            var layoutConf = UICollectionLayoutListConfiguration(appearance: .insetGrouped)
            layoutConf.headerMode = .firstItemInSection
            return NSCollectionLayoutSection.list(using: layoutConf, layoutEnvironment: env)
        }

        super.init(collectionViewLayout: layout)
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    override func viewDidLoad() {
        title = SantanderL10n.t("Types")

        let cancelAction = UIAction {
            self.selectedTypes = []
            self.dismiss(animated: true)
        }

        let doneAction = UIAction {
            self.dismiss(animated: true)
        }

        let searchController = UISearchController()
        searchController.searchBar.delegate = self
        navigationItem.searchController = searchController
        navigationItem.hidesSearchBarWhenScrolling = false

        navigationItem.leftBarButtonItem = UIBarButtonItem(systemItem: .cancel, primaryAction: cancelAction)
        let rightBarButton = UIBarButtonItem(systemItem: .done, primaryAction: doneAction)
        rightBarButton.isEnabled = false
        navigationItem.rightBarButtonItem = rightBarButton
        makeDataSource()
    }

    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
        dismissHandler(Array(selectedTypes))
    }

    func makeDataSource() {
        let cellRegistration = CellRegistration { [self] cell, indexPath, itemIdentifier in
            var conf: UIListContentConfiguration
            switch itemIdentifier {
            case .section(let section):
                conf = .sidebarHeader()
                conf.text = section.description
                conf.image = SantanderIconLibrary.shared.interfaceIcon(for: "chevron.down")
            case .item(let type):
                conf = cell.defaultContentConfiguration()
                conf.text = type.localizedDescription
                conf.image = selectedTypes.contains(type) ? SantanderIconLibrary.shared.uiIcon(named: "checkbox_selected") : nil
            }

            cell.contentConfiguration = conf
        }

        self.dataSource = DataSource(collectionView: collectionView) { collectionView, indexPath, itemIdentifier in
            return collectionView.dequeueConfiguredReusableCell(using: cellRegistration, for: indexPath, item: itemIdentifier)
        }

        showItems(fromCollections: allItems)
    }

    func showItems(fromCollections coll: [TypesCollection], animatingDifferences: Bool = false) {
        var snapshot = NSDiffableDataSourceSnapshot<Section, Item>()
        let justSections = coll.map(\.section)
        snapshot.appendSections(justSections)
        dataSource.apply(snapshot, animatingDifferences: false)

        for collection in coll {
            let collectionSection = Item.section(collection.section)
            var section = NSDiffableDataSourceSectionSnapshot<Item>()
            section.append([collectionSection])

            let types = Item.fromItems(collection.types)
            section.append(types, to: collectionSection)
            section.expand([collectionSection])
            dataSource.apply(section, to: collection.section, animatingDifferences: animatingDifferences)
        }
    }

    override func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        collectionView.deselectItem(at: indexPath, animated: false)
        guard let item = dataSource.itemIdentifier(for: indexPath) else { return }
        switch item {
        case .section(_): break
        case .item(let type):
            if selectedTypes.contains(type) {
                selectedTypes.remove(type)
            } else {
                selectedTypes.insert(type)
            }

            var snapshot = dataSource.snapshot()
            snapshot.reloadItems([.item(type)])
            dataSource.apply(snapshot, animatingDifferences: true)
        }
    }

    enum Section: CustomStringConvertible {
        case generic
        case audio
        case programming
        case archive
        case image
        case document
        case executable
        case systemTypes

        var description: String {
            switch self {
            case .generic:
                return SantanderL10n.t("Generic")
            case .audio:
                return SantanderL10n.t("Audio")
            case .programming:
                return SantanderL10n.t("Programming")
            case .archive:
                return SantanderL10n.t("Archive")
            case .image:
                return SantanderL10n.t("Image")
            case .document:
                return SantanderL10n.t("Document")
            case .executable:
                return SantanderL10n.t("Executable")
            case .systemTypes:
                return SantanderL10n.t("System")
            }
        }
    }

    struct TypesCollection {
        let section: Section
        let types: [UTType]

        static func all() -> [TypesCollection] {
            return [
                TypesCollection(section: .generic, types: UTType.generictypes()),
                TypesCollection(section: .audio, types: UTType.audioTypes()),
                TypesCollection(section: .programming, types: UTType.programmingTypes()),
                TypesCollection(section: .archive, types: UTType.compressedFormatTypes()),
                TypesCollection(section: .image, types: UTType.imageTypes()),
                TypesCollection(section: .document, types: UTType.documentTypes()),
                TypesCollection(section: .systemTypes, types: UTType.systemTypes())
            ]
        }
    }
}

extension TypesSelectionCollectionViewController: UISearchBarDelegate {
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        guard !searchText.isEmpty else {
            showItems(fromCollections: allItems)
            return
        }

        var newCollection: [TypesCollection] = []
        for collection in allItems {
            let filtered = collection.types.filter { type in
                type.localizedDescription?.localizedCaseInsensitiveContains(searchText) ?? false ||
                type.preferredFilenameExtension?.localizedCaseInsensitiveContains(searchText) ?? false
            }

            if !filtered.isEmpty {
                newCollection.append(TypesCollection(section: collection.section, types: filtered))
            }
        }

        showItems(fromCollections: newCollection, animatingDifferences: false)
    }

    func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
        showItems(fromCollections: allItems)
    }
}

class PathPermissionsViewController: UITableViewController {
    var permissions: PathPermissions
    private var applyToAllSubitems = false
    // Lock status is exposed for files only. Directory permissions remain POSIX-based.
    private var hasLockedRow: Bool { !permissions.fileURL.isDirectory }
    private var hasRecursiveRow: Bool { permissions.fileURL.isDirectory }
    private var specialSection: Int { hasLockedRow ? 1 : 0 }
    private var ownerSection: Int { specialSection + 1 }
    private var groupSection: Int { ownerSection + 1 }
    private var otherSection: Int { groupSection + 1 }
    private var recursiveSection: Int { otherSection + 1 }

    init(style: UITableView.Style = .insetGrouped, permissions: PathPermissions) {
        self.permissions = permissions
        super.init(style: style)
        title = "访问权限"
    }

    required init?(coder: NSCoder) { fatalError("init(coder:) has not been implemented") }

    override func viewDidLoad() {
        super.viewDidLoad()
        applySantanderUI()
        tableView.rowHeight = 44
        tableView.estimatedRowHeight = 44
        tableView.separatorInset = UIEdgeInsets(top: 0, left: 20, bottom: 0, right: 0)
    }

    override func numberOfSections(in tableView: UITableView) -> Int { hasRecursiveRow ? recursiveSection + 1 : recursiveSection }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if hasLockedRow && section == 0 { return 1 }
        if section == specialSection { return 4 }
        if hasRecursiveRow && section == recursiveSection { return 1 }
        return 3
    }

    override func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        if hasLockedRow && section == 0 { return SantanderL10n.t("File Attributes") }
        switch section {
        case ownerSection: return SantanderL10n.t("Owner")
        case groupSection: return SantanderL10n.t("Group")
        case otherSection: return SantanderL10n.t("Other users")
        case recursiveSection where hasRecursiveRow: return "应用范围"
        default: return nil
        }
    }

    override func tableView(_ tableView: UITableView, titleForFooterInSection section: Int) -> String? {
        guard hasRecursiveRow, section == recursiveSection else { return nil }
        return "开启后，修改权限时会递归应用到目录中的所有文件和子文件夹；关闭后只修改当前目录。"
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let style: UITableViewCell.CellStyle = .value1
        let cell = UITableViewCell(style: style, reuseIdentifier: nil)
        SantanderUI.styleCell(cell)
        var conf = cell.defaultContentConfiguration()

        if hasLockedRow && indexPath.section == 0 {
            guard indexPath.row == 0 else { return cell }
            conf.text = "锁定文件状态"
            let toggle = UISwitch()
            toggle.isOn = permissions.isLocked
            toggle.accessibilityLabel = "锁定文件状态"
            toggle.accessibilityValue = permissions.isLocked ? SantanderL10n.t("Yes") : SantanderL10n.t("No")
            toggle.addAction(UIAction { [weak self, weak toggle] _ in
                guard let self, let toggle else { return }
                let requested = toggle.isOn
                let old = self.permissions.isLocked
                let currentPermissions = self.permissions
                toggle.isEnabled = false
                DispatchQueue.global(qos: .utility).async {
                    do {
                        var updated = currentPermissions
                        try updated.applyLocked(requested)
                        DispatchQueue.main.async {
                            toggle.isEnabled = true
                            self.permissions = updated
                            toggle.accessibilityValue = updated.isLocked ? SantanderL10n.t("Yes") : SantanderL10n.t("No")
                            toggle.setOn(updated.isLocked, animated: false)
                        }
                    } catch {
                        DispatchQueue.main.async {
                            toggle.setOn(old, animated: true)
                            toggle.accessibilityValue = old ? SantanderL10n.t("Yes") : SantanderL10n.t("No")
                            toggle.isEnabled = true
                            self.errorAlert(error, title: SantanderL10n.t("无法修改文件锁定状态"))
                        }
                    }
                }
            }, for: .valueChanged)
            cell.accessoryView = toggle
            cell.selectionStyle = .none
            cell.contentConfiguration = conf
            return cell
        }

        if indexPath.section == specialSection {
            guard (0...3).contains(indexPath.row) else { return cell }
            if indexPath.row == 0 {
                conf.text = "权限"
                conf.secondaryText = displayedOctalMode
                conf.secondaryTextProperties.color = SantanderAppTheme.accentColor
                cell.accessoryType = .disclosureIndicator
                cell.contentConfiguration = conf
                return cell
            }
            let bits: [SpecialPermissionBits] = [.setUID, .setGID, .sticky]
            let titles = [SantanderL10n.t("Set UID"), SantanderL10n.t("Set GID"), "限制删除"]
            let bit = bits[indexPath.row - 1]
            conf.text = titles[indexPath.row - 1]
            cell.accessoryType = permissions.specialPermissions.contains(bit) ? .checkmark : .none
            cell.contentConfiguration = conf
            return cell
        }

        if hasRecursiveRow && indexPath.section == recursiveSection {
            conf.text = "应用到所有文件"
            let toggle = UISwitch()
            toggle.isOn = applyToAllSubitems
            toggle.accessibilityLabel = "应用到所有文件"
            toggle.accessibilityValue = applyToAllSubitems ? "开启" : "关闭"
            toggle.addAction(UIAction { [weak self, weak toggle] _ in
                guard let self, let toggle else { return }
                self.applyToAllSubitems = toggle.isOn
                toggle.accessibilityValue = toggle.isOn ? "开启" : "关闭"
            }, for: .valueChanged)
            cell.accessoryView = toggle
            cell.selectionStyle = .none
            cell.contentConfiguration = conf
            return cell
        }

        guard indexPath.section == ownerSection || indexPath.section == groupSection || indexPath.section == otherSection,
              (0...2).contains(indexPath.row) else { return cell }
        let isOwner = indexPath.section == ownerSection
        let isGroup = indexPath.section == groupSection
        let permSet = isOwner ? permissions.ownerPermissions : (isGroup ? permissions.groupPermissions : permissions.otherUsersPermissions)
        let permission: Permission = [.read, .write, .execute][indexPath.row]
        conf.text = [SantanderL10n.t("Read"), SantanderL10n.t("Write"), SantanderL10n.t("Execute")][indexPath.row]
        cell.accessoryType = permSet.contains(permission) ? .checkmark : .none
        cell.accessibilityValue = permSet.contains(permission) ? "✓" : "未启用"
        cell.accessibilityHint = SantanderL10n.t("点击切换权限")
        cell.contentConfiguration = conf
        return cell
    }

    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        if hasLockedRow && indexPath.section == 0 { return }

        if indexPath.section == specialSection {
            guard (0...3).contains(indexPath.row) else { return }
            if indexPath.row == 0 {
                presentOctalModeEditor()
                return
            }
            let bits: [SpecialPermissionBits] = [.setUID, .setGID, .sticky]
            let bit = bits[indexPath.row - 1]
            var requested = permissions
            if requested.specialPermissions.contains(bit) {
                requested.specialPermissions.remove(bit)
            } else {
                requested.specialPermissions.insert(bit)
            }
            applyRequestedPermissions(requested, changedIndexPath: indexPath)
            return
        }

        guard indexPath.section == ownerSection || indexPath.section == groupSection || indexPath.section == otherSection,
              (0...2).contains(indexPath.row) else { return }
        let permission: Permission = [.read, .write, .execute][indexPath.row]
        var requested = permissions
        switch indexPath.section {
        case ownerSection:
            if requested.ownerPermissions.contains(permission) { requested.ownerPermissions.remove(permission) } else { requested.ownerPermissions.insert(permission) }
        case groupSection:
            if requested.groupPermissions.contains(permission) { requested.groupPermissions.remove(permission) } else { requested.groupPermissions.insert(permission) }
        case otherSection:
            if requested.otherUsersPermissions.contains(permission) { requested.otherUsersPermissions.remove(permission) } else { requested.otherUsersPermissions.insert(permission) }
        default: return
        }
        applyRequestedPermissions(requested, changedIndexPath: indexPath)
    }

    private var displayedOctalMode: String {
        var buffer = stat()
        if lstat(permissions.fileURL.path, &buffer) == 0 {
            return String(format: "%06o", Int(buffer.st_mode))
        }
        let rwx = Permission.octalRepresentation(of: [permissions.ownerPermissions, permissions.groupPermissions, permissions.otherUsersPermissions])
        return String(format: "%04o", rwx | permissions.specialPermissions.rawValue)
    }

    private func presentOctalModeEditor() {
        let alert = UIAlertController(title: "访问权限", message: "输入八进制权限值，例如 040755 或 0755", preferredStyle: .alert)
        alert.addTextField { field in
            field.text = self.displayedOctalMode
            field.keyboardType = .numberPad
            field.autocorrectionType = .no
            field.clearButtonMode = .whileEditing
        }
        alert.addAction(.cancel())
        alert.addAction(UIAlertAction(title: "应用", style: .default) { [weak self, weak alert] _ in
            guard let self,
                  let text = alert?.textFields?.first?.text?.trimmingCharacters(in: .whitespacesAndNewlines),
                  !text.isEmpty,
                  text.count <= 6,
                  let fullMode = Int(text, radix: 8), (0...0o777777).contains(fullMode) else {
                self?.errorAlert("请输入有效的八进制权限值，例如 040755 或 0755。", title: "权限值无效")
                return
            }
            let mode = fullMode & 0o7777
            var requested = self.permissions
            requested.ownerPermissions = Permission(rawValue: (mode >> 6) & 0o7)
            requested.groupPermissions = Permission(rawValue: (mode >> 3) & 0o7)
            requested.otherUsersPermissions = Permission(rawValue: mode & 0o7)
            requested.specialPermissions = SpecialPermissionBits(rawValue: mode & 0o7000)
            self.applyRequestedPermissions(requested, changedIndexPath: IndexPath(row: 0, section: self.specialSection))
        })
        present(alert, animated: true)
    }

    private func applyRequestedPermissions(_ requested: PathPermissions, changedIndexPath: IndexPath) {
        let old = permissions
        let recurse = applyToAllSubitems
        permissions = requested
        tableView.reloadData()
        DispatchQueue.global(qos: .utility).async { [weak self] in
            do {
                try requested.apply()
                if recurse {
                    var isDirectory: ObjCBool = false
                    if FileManager.default.fileExists(atPath: requested.fileURL.path, isDirectory: &isDirectory), isDirectory.boolValue,
                       let enumerator = FileManager.default.enumerator(
                            at: requested.fileURL,
                            includingPropertiesForKeys: [.isSymbolicLinkKey, .isDirectoryKey],
                            options: [],
                            errorHandler: { _, _ in true }
                       ) {
                        for case let childURL as URL in enumerator {
                            let values = try? childURL.resourceValues(forKeys: [.isSymbolicLinkKey])
                            if values?.isSymbolicLink == true { continue }
                            guard var child = PathPermissions(fileURL: childURL) else { continue }
                            child.ownerPermissions = requested.ownerPermissions
                            child.groupPermissions = requested.groupPermissions
                            child.otherUsersPermissions = requested.otherUsersPermissions
                            child.specialPermissions = requested.specialPermissions
                            try child.apply()
                        }
                    }
                }
                DispatchQueue.main.async { [weak self] in
                    guard let self else { return }
                    self.tableView.reloadData()
                }
            } catch {
                DispatchQueue.main.async {
                    guard let self else { return }
                    self.permissions = old
                    self.tableView.reloadData()
                    self.errorAlert(error, title: "无法修改「\(requested.fileURL.lastPathComponent)」的权限")
                }
            }
        }
    }

    var permissionSummary: String {
        let rwx = Permission.octalRepresentation(of: [permissions.ownerPermissions, permissions.groupPermissions, permissions.otherUsersPermissions])
        return String(format: "%04o", rwx | permissions.specialPermissions.rawValue)
    }
}

final class GoToViewController: UIViewController, UITextFieldDelegate, UITableViewDataSource, UITableViewDelegate {
    private let goToView = GoToView()
    private let suggestionTable = UITableView(frame: .zero, style: .insetGrouped)
    private var suggestions: [Path] = []

    override func loadView() {
        view = UIView()
        view.backgroundColor = .clear
        goToView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(goToView)
        suggestionTable.translatesAutoresizingMaskIntoConstraints = false
        suggestionTable.backgroundColor = .clear
        suggestionTable.separatorStyle = .none
        suggestionTable.dataSource = self
        suggestionTable.delegate = self
        suggestionTable.register(UITableViewCell.self, forCellReuseIdentifier: "suggestion")
        view.addSubview(suggestionTable)
        NSLayoutConstraint.activate([
            goToView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 16),
            goToView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -16),
            goToView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 20),
            goToView.heightAnchor.constraint(equalToConstant: 64),
            suggestionTable.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 8),
            suggestionTable.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -8),
            suggestionTable.topAnchor.constraint(equalTo: goToView.bottomAnchor, constant: 8),
            suggestionTable.bottomAnchor.constraint(equalTo: view.bottomAnchor)
        ])
        goToView.searchField.delegate = self
        goToView.searchField.addTarget(self, action: #selector(textDidChange), for: .editingChanged)
        goToView.xButton.addAction(UIAction { [weak self] _ in self?.dismiss(animated: true) }, for: .touchUpInside)
        goToView.searchField.addAction(UIAction { [weak self] _ in self?.commit() }, for: .editingDidEndOnExit)
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        title = SantanderL10n.t("Go to")
        navigationItem.leftBarButtonItem = UIBarButtonItem(title: SantanderL10n.t("Cancel"), style: .plain, target: self, action: #selector(cancel))
        navigationItem.rightBarButtonItem = UIBarButtonItem(title: SantanderL10n.t("Go"), style: .done, target: self, action: #selector(commit))
        refreshSuggestions("")
    }

    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        goToView.searchField.becomeFirstResponder()
    }

    @objc private func cancel() { dismiss(animated: true) }

    @objc private func textDidChange() {
        refreshSuggestions(goToView.searchField.text ?? "")
    }

    private func refreshSuggestions(_ raw: String) {
        let query = raw.trimmingCharacters(in: .whitespacesAndNewlines)
        let recent = SantanderPathHistory.paths
        let shortcuts = [Path.root, Path.home]
        let prefix = query.hasPrefix("/") ? query : "/" + query
        var candidates = recent + shortcuts
        if query.contains("/") {
            let directory = URL(fileURLWithPath: prefix).deletingLastPathComponent()
            let fragment = URL(fileURLWithPath: prefix).lastPathComponent.lowercased()
            if let contents = try? FileManager.default.contentsOfDirectory(at: directory, includingPropertiesForKeys: [.isDirectoryKey], options: [.skipsHiddenFiles]) {
                candidates.append(contentsOf: contents.filter { $0.lastPathComponent.lowercased().hasPrefix(fragment) }.map(Path.init(url:)))
            }
        }
        var seen = Set<String>()
        suggestions = candidates.filter { seen.insert($0.path).inserted }.prefix(20).map { $0 }
        suggestionTable.reloadData()
    }

    func textFieldShouldReturn(_ textField: UITextField) -> Bool { commit(); return true }

    @objc private func commit() {
        let raw = goToView.searchField.text?.trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
        guard !raw.isEmpty else { return }
        let pathString = raw.hasPrefix("/") ? raw : "/" + raw
        let url = URL(fileURLWithPath: pathString).standardizedFileURL
        var isDirectory: ObjCBool = false
        guard FileManager.default.fileExists(atPath: url.path, isDirectory: &isDirectory), isDirectory.boolValue else {
            goToView.searchField.layer.borderColor = UIColor.systemRed.cgColor
            goToView.searchField.layer.borderWidth = 1
            refreshSuggestions(raw)
            return
        }
        guard let presenter = navigationController?.presentingViewController else {
            dismiss(animated: true)
            return
        }
        let target: PathListViewController?
        if let direct = presenter as? PathListViewController {
            target = direct
        } else if let nav = presenter as? UINavigationController {
            target = nav.visibleViewController as? PathListViewController
        } else {
            target = presenter.children.compactMap { $0 as? PathListViewController }.first
        }
        SantanderPathHistory.add(Path(url: url))
        dismiss(animated: true) { target?.goToPath(path: Path(url: url)) }
    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int { suggestions.count }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "suggestion", for: indexPath)
        SantanderUI.styleCell(cell)
        guard suggestions.indices.contains(indexPath.row) else { return cell }
        let path = suggestions[indexPath.row]
        var conf = cell.defaultContentConfiguration()
        conf.text = path.lastPathComponent.isEmpty ? path.path : path.lastPathComponent
        conf.secondaryText = path.path
        conf.secondaryTextProperties.numberOfLines = 0
        conf.textProperties.adjustsFontForContentSizeCategory = true
        conf.secondaryTextProperties.adjustsFontForContentSizeCategory = true
        conf.image = path.displayImage
        cell.contentConfiguration = conf
        return cell
    }

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        guard suggestions.indices.contains(indexPath.row) else { return }
        let path = suggestions[indexPath.row]
        goToView.searchField.text = path.path
        refreshSuggestions(path.path)
        commit()
    }
}

class GoToView: UIView {
    let xButton = UIButton()
    let searchField = UITextField()

    override init(frame: CGRect) {
        super.init(frame: frame)
        setup()
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    func setup() {
        layer.cornerRadius = 10
        layer.masksToBounds = true

        backgroundColor = .secondarySystemBackground

        let glassImage = UIImageView(image: SantanderIconLibrary.shared.uiIcon(named: "search"))
        glassImage.translatesAutoresizingMaskIntoConstraints = false

        searchField.tintColor = .label
        searchField.font = .preferredFont(forTextStyle: .title2)
        searchField.translatesAutoresizingMaskIntoConstraints = false
        searchField.placeholder = SantanderL10n.t("Search")

        xButton.translatesAutoresizingMaskIntoConstraints = false
        xButton.setImage(SantanderIconLibrary.shared.interfaceIcon(for: "xmark.circle.fill")?.applyingSymbolConfiguration(UIImage.SymbolConfiguration(pointSize: 30))?.withTintColor(.secondaryLabel, renderingMode: .alwaysOriginal), for: .normal)

        let stackView = UIStackView(arrangedSubviews: [glassImage, searchField, xButton])
        stackView.translatesAutoresizingMaskIntoConstraints = false
        stackView.spacing = 8
        stackView.alignment = .center
        stackView.distribution = .fill
        addSubview(stackView)
        NSLayoutConstraint.activate([
            glassImage.widthAnchor.constraint(equalToConstant: 30),
            glassImage.heightAnchor.constraint(equalToConstant: 30),
            xButton.widthAnchor.constraint(equalToConstant: 30),
            xButton.heightAnchor.constraint(equalToConstant: 30),
            stackView.leadingAnchor.constraint(equalTo: layoutMarginsGuide.leadingAnchor),
            stackView.trailingAnchor.constraint(equalTo: layoutMarginsGuide.trailingAnchor),
            stackView.topAnchor.constraint(equalTo: layoutMarginsGuide.topAnchor, constant: 10),
            stackView.bottomAnchor.constraint(equalTo: layoutMarginsGuide.bottomAnchor, constant: -10)
        ])
        searchField.becomeFirstResponder()
    }
}

extension PathListViewController: UISearchResultsUpdating, UISearchControllerDelegate, UISearchBarDelegate {

    func updateSearchResults(for searchController: UISearchController) {
        updateResults(searchBar: searchController.searchBar)
    }

    func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
        DispatchQueue.main.async { [self] in
            searchItem?.cancel()
            searchGeneration = UUID()
            displayingSearchSuggestions = false
            emptyStateView?.removeFromSuperview()
            emptyStateView = nil

            if self is SantanderGlobalSearchTabViewController {
                isSearching = false
                showEmptySearchResults()
                setSearchChromeSuppressed(true)
            } else {
                isSearching = false
                reloadTableData()
                setupPermissionDeniedLabelIfNeeded()
                restoreBrowserChromeAfterSearch()
            }
        }
    }

    func didDismissSearchController(_ searchController: UISearchController) {
        guard browserSearchController === searchController else { return }
        if self is SantanderGlobalSearchTabViewController {
            setSearchChromeSuppressed(true)
            showEmptySearchResults()
        } else {
            restoreBrowserChromeAfterSearch()
        }
    }

    func searchBar(_ searchBar: UISearchBar, selectedScopeButtonIndexDidChange selectedScope: Int) {
        decorateSearchScopes(searchBar)
        updateResults(searchBar: searchBar)
    }

    @objc
    func updateResults(searchBar: UISearchBar) {
        let selectedScope = searchBar.selectedScopeButtonIndex
        let query = SearchQuery(searchBar: searchBar)

        self.searchItem?.cancel()
        searchGeneration = UUID()
        let generation = searchGeneration
        isSearching = true
        guard !query.isEmpty else {
            showEmptySearchResults()
            return
        }
        displayingSearchSuggestions = false

        let newWorkItem = DispatchWorkItem(qos: .userInteractive) { [weak self] in
            guard let self else { return }
            func publish(_ batch: [SubPathsRowItem], reset: Bool = false, finished: Bool = false) {
                guard !batch.isEmpty || reset else { return }
                DispatchQueue.main.async { [weak self] in
                    guard let self, self.isSearching, self.searchGeneration == generation else { return }
                    var snapshot = self.dataSource.snapshot()
                    if reset || snapshot.sectionIdentifiers.isEmpty {
                        snapshot.deleteAllItems()
                        if !snapshot.sectionIdentifiers.contains(0) { snapshot.appendSections([0]) }
                    } else if !snapshot.sectionIdentifiers.contains(0) {
                        snapshot.appendSections([0])
                    }
                    let existing = Set(snapshot.itemIdentifiers)
                    let unique = batch.filter { !existing.contains($0) }
                    if !unique.isEmpty { snapshot.appendItems(unique, toSection: 0) }
                    self.dataSource.apply(snapshot, animatingDifferences: false)
                    if finished && snapshot.numberOfItems == 0 { self.setupPermissionDeniedLabelIfNeeded() }
                }
            }

            switch selectedScope {
            case 0:
                let filtered = self.unfilteredContents.filter { query.matches(url: $0) }
                DispatchQueue.main.async { [weak self] in
                    guard let self, self.isSearching, self.searchGeneration == generation else { return }
                    self.setFilteredContents(filtered)
                }
            case 1:
                var batch: [SubPathsRowItem] = []
                __enumeratePaths(self.unfilteredContents, withQuery: query, doBreak: { !self.isSearching || self.searchGeneration != generation }) { path in
                    batch.append(.path(path))
                    if batch.count >= 64 {
                        let pending = batch; batch.removeAll(keepingCapacity: true)
                        publish(pending)
                    }
                }
                publish(batch, finished: true)
            case 2:
                var batch: [SubPathsRowItem] = []
                __enumerateFilesystem(from: .root, withQuery: query, doBreak: { !self.isSearching || self.searchGeneration != generation }) { path in
                    batch.append(.path(path))
                    if batch.count >= 64 {
                        let pending = batch; batch.removeAll(keepingCapacity: true)
                        publish(pending)
                    }
                }
                publish(batch, finished: true)
            default:
                break
            }
        }

        self.searchItem = newWorkItem
        DispatchQueue.global(qos: .userInteractive).asyncAfter(
            deadline: .now().advanced(by: .milliseconds(2)),
            execute: newWorkItem
        )
    }

    private func decorateSearchScopes(_ searchBar: UISearchBar) {
        // Keep this on public UISearchBar APIs: traversing private subviews is brittle across iOS releases.
        searchBar.scopeButtonTitles = searchBar.scopeButtonTitles?.map { SantanderL10n.t($0) }
        searchBar.searchTextField.clearButtonMode = .whileEditing
    }

    func presentSearchController(_ searchController: UISearchController) {
        setSearchChromeSuppressed(true)
        if isEditing {
            setEditing(false, animated: true)
        }
        showEmptySearchResults()
        emptyStateView?.removeFromSuperview()
    }

    private func __enumerateFilesystem(from root: Path, withQuery query: SearchQuery, doBreak: () -> Bool, handler: (Path) -> ()) {
        let excludedPrefixes = SearchFileSystem.excludedPrefixes
        guard let enumerator = FileManager.default.enumerator(
            at: root.url,
            includingPropertiesForKeys: [.isDirectoryKey, .isRegularFileKey, .isSymbolicLinkKey],
            options: []
        ) else { return }

        while !doBreak(), let url = enumerator.nextObject() as? URL {
            let standardized = url.standardizedFileURL.path
            if excludedPrefixes.contains(where: { standardized == $0 || standardized.hasPrefix($0 + "/") }) {
                if let dir = try? url.resourceValues(forKeys: [.isDirectoryKey]).isDirectory, dir == true {
                    enumerator.skipDescendants()
                }
                continue
            }
            let path = Path(url: url)
            if query.matches(url: path) { handler(path) }
        }
    }

    private func __enumeratePaths(_ paths: [Path], withQuery query: SearchQuery, doBreak: () -> Bool, handler: (Path) -> ()) {
        for path in paths {
            if doBreak() { break }

            if query.matches(url: path) {
                handler(path)
            }

            if path.isDirectory {
                __enumeratePaths(path.contents, withQuery: query, doBreak: doBreak, handler: handler)
            }
        }
    }

    fileprivate struct SearchQuery {
        let searchText: String
        let conditions: [SearchSuggestion.Condition]
        let isSearchTextEmpty: Bool

        func matches(url: Path) -> Bool {
            let allConditionsSatisfied = conditions.allSatisfy { handler in
                handler(url)
            }

            if isSearchTextEmpty {
                return allConditionsSatisfied
            }

            return url.lastPathComponent.localizedCaseInsensitiveContains(searchText) && allConditionsSatisfied
        }

        var isEmpty: Bool {
            return isSearchTextEmpty && conditions.isEmpty
        }

        init(searchText: String, conditions: [SearchSuggestion.Condition]) {
            self.searchText = searchText
            self.conditions = conditions

            self.isSearchTextEmpty = searchText.isEmpty
        }

        init(searchBar: UISearchBar) {
            self.searchText = searchBar.text ?? ""
            self.conditions = searchBar.searchTextField.tokens.compactMap { $0.representedObject as? SearchSuggestion.Condition }

            self.isSearchTextEmpty = searchText.isEmpty
        }
    }
}

private enum SearchFileSystem {
    static let excludedPrefixes: [String] = [
        "/System/Library/Caches",
        "/private/var/mobile/Library/Caches",
        "/private/var/mobile/Library/Logs"
    ]
}

@available(iOS 14.0, *)
struct SearchSuggestion: Hashable {

    typealias Condition = (Path) -> Bool

    var name: String

    let image: UIImage?

    var condition: Condition

    var searchToken: UISearchToken {
        let token = UISearchToken(icon: image, text: name)
        token.representedObject = condition
        return token
    }

    static func displaySearchSuggestions(for indexPath: IndexPath, typesToCheck: [UTType]? = nil) -> SearchSuggestion {
        switch (indexPath.section, indexPath.row) {
        case (0, 0):
            return SearchSuggestion(name: SantanderL10n.t("Type"), image: SantanderIconLibrary.shared.interfaceIcon(for: "menucard")) { url in
                guard let typesToCheck = typesToCheck, let urlType = url.contentType else {
                    return false
                }

                let isSubtype = typesToCheck.contains { type in
                    urlType.isSubtype(of: type)
                }

                return typesToCheck.contains(urlType) || isSubtype
            }

        case (1, 0):
            return SearchSuggestion(name: SantanderL10n.t("File"), image: SantanderIconLibrary.shared.interfaceIcon(for: "doc")) { url in
                return !url.isDirectory
            }
        case (1, 1):
            return SearchSuggestion(name: SantanderL10n.t("Directory"), image: SantanderIconLibrary.shared.interfaceIcon(for: "folder")) { url in
                return url.isDirectory
            }
        case (1, 2):
            return SearchSuggestion(name: SantanderL10n.t("Symbolic Link"), image: SantanderIconLibrary.shared.interfaceIcon(for: "link")) { url in
                return url.url.isSymlink
            }
        case (2, 0):
            return SearchSuggestion(name: SantanderL10n.t("Executable"), image: SantanderIconLibrary.shared.interfaceIcon(for: "terminal")) { url in
                return !url.isDirectory && FileManager.default.isExecutableFile(atPath: url.path)
            }
        case (2, 1):
            return SearchSuggestion(name: SantanderL10n.t("Readable"), image: SantanderIconLibrary.shared.interfaceIcon(for: "book")) { url in
                return url.isReadable
            }
        case (2, 2):
            return SearchSuggestion(name: SantanderL10n.t("Writable"), image: SantanderIconLibrary.shared.interfaceIcon(for: "pencil")) { url in
                return FileManager.default.isWritableFile(atPath: url.path)
            }
        case (3, 0):
            return SearchSuggestion(name: SantanderL10n.t("Greater than 100 MB"), image: SantanderIconLibrary.shared.interfaceIcon(for: "externaldrive")) { url in
                (try? url.url.resourceValues(forKeys: [.fileSizeKey]).fileSize).map { $0 > 100 * 1024 * 1024 } ?? false
            }
        case (3, 1):
            return SearchSuggestion(name: SantanderL10n.t("Older than 7 days"), image: SantanderIconLibrary.shared.uiIcon(named: "recents")) { url in
                guard let date = try? url.url.resourceValues(forKeys: [.contentModificationDateKey]).contentModificationDate else { return false }
                return date < Date().addingTimeInterval(-7 * 24 * 60 * 60)
            }
        default:
            return SearchSuggestion(name: SantanderL10n.t("Unknown"), image: nil) { _ in false }
        }
    }

    static let searchSuggestionSectionAndRows = [
        IndexPath(row: 0, section: 0),
        IndexPath(row: 0, section: 1), IndexPath(row: 1, section: 1), IndexPath(row: 2, section: 1),
        IndexPath(row: 0, section: 2), IndexPath(row: 1, section: 2), IndexPath(row: 2, section: 2),
        IndexPath(row: 0, section: 3), IndexPath(row: 1, section: 3)
    ]

    static func == (lhs: SearchSuggestion, rhs: SearchSuggestion) -> Bool {
        return lhs.name == rhs.name && lhs.image == rhs.image
    }

    func hash(into hasher: inout Hasher) {
        hasher.combine(self.name)
        hasher.combine(self.image)
    }
}

private final class SantanderBreadcrumbView: UIScrollView {
    var onSelect: ((Path) -> Void)?

    init(path: Path) {
        super.init(frame: .zero)
        showsHorizontalScrollIndicator = false
        alwaysBounceHorizontal = true
        let stack = UIStackView()
        stack.axis = .horizontal
        stack.alignment = .center
        stack.spacing = 4
        stack.translatesAutoresizingMaskIntoConstraints = false
        addSubview(stack)
        NSLayoutConstraint.activate([
            stack.leadingAnchor.constraint(equalTo: contentLayoutGuide.leadingAnchor),
            stack.trailingAnchor.constraint(equalTo: contentLayoutGuide.trailingAnchor),
            stack.topAnchor.constraint(equalTo: frameLayoutGuide.topAnchor),
            stack.bottomAnchor.constraint(equalTo: frameLayoutGuide.bottomAnchor)
        ])

        let rawComponents = path.url.standardizedFileURL.pathComponents
        var full: [(String, Path)] = []
        var built = "/"
        for component in rawComponents {
            if component == "/" {
                full.append(("/", .root))
            } else {
                built = built == "/" ? "/" + component : built + "/" + component
                full.append((component, Path(url: URL(fileURLWithPath: built)))
                )
            }
        }
        if full.count <= 5 {
            append(full, to: stack)
        } else {
            append(Array(full.prefix(2)), to: stack)
            addChevron(to: stack)
            let hidden = Array(full.dropFirst(2).dropLast(2))
            let more = UIButton(type: .system)
            more.setTitle("…", for: .normal)
            more.titleLabel?.font = .preferredFont(forTextStyle: .headline)
            more.addAction(UIAction { [weak self, weak more] _ in
                guard let more else { return }
                let actions = hidden.map { title, hiddenPath in
                    SantanderActionSheetItem(title: title, subtitle: hiddenPath.path, image: SantanderIconLibrary.shared.interfaceIcon(for: "folder")) { [weak self] in self?.onSelect?(hiddenPath) }
                } + [SantanderActionSheetItem(title: SantanderL10n.t("Cancel"), style: .cancel)]
                SantanderActionSheetPresenter.present(from: more, title: "中间路径", actions: actions)
            }, for: .touchUpInside)
            more.accessibilityLabel = "显示中间路径"
            stack.addArrangedSubview(more)
            append(Array(full.suffix(2)), to: stack)
        }
    }

    private func append(_ components: [(String, Path)], to stack: UIStackView) {
        for (index, item) in components.enumerated() {
            if !stack.arrangedSubviews.isEmpty { addChevron(to: stack) }
            addButton(title: item.0, path: item.1, to: stack)
            _ = index
        }
    }

    private func addButton(title: String, path: Path, to stack: UIStackView) {
        let button = UIButton(type: .system)
        button.titleLabel?.font = .preferredFont(forTextStyle: .subheadline)
        button.setTitle(title, for: .normal)
        button.accessibilityLabel = title
        button.addAction(UIAction { [weak self] _ in self?.onSelect?(path) }, for: .touchUpInside)
        SantanderLongPressSupport.install(on: button) { [weak button] _ in
            guard let button else { return }
            let actions = [
                SantanderActionSheetItem(title: SantanderL10n.t("Copy path"), subtitle: path.path, image: SantanderIconLibrary.shared.interfaceIcon(for: "doc.on.doc")) { UIPasteboard.general.string = path.path },
                SantanderActionSheetItem(title: SantanderL10n.t("Cancel"), style: .cancel)
            ]
            SantanderActionSheetPresenter.present(from: button, title: title, actions: actions)
        }
        stack.addArrangedSubview(button)
    }

    private func addChevron(to stack: UIStackView) {
        let image = UIImageView(image: UIImage(systemName: "chevron.right"))
        image.tintColor = .tertiaryLabel
        image.widthAnchor.constraint(equalToConstant: 10).isActive = true
        image.heightAnchor.constraint(equalToConstant: 14).isActive = true
        stack.addArrangedSubview(image)
    }

    required init?(coder: NSCoder) { fatalError() }
}

private final class SantanderPressButton: UIButton {
    override var isHighlighted: Bool {
        didSet {
            guard isHighlighted != oldValue else { return }
            let apply = {
                self.transform = self.isHighlighted ? CGAffineTransform(scaleX: 0.92, y: 0.92) : .identity
                self.alpha = self.isHighlighted ? 0.72 : 1
            }
            if UIAccessibility.isReduceMotionEnabled {
                apply()
            } else {
                UIView.animate(
                    withDuration: isHighlighted ? 0.14 : 0.30,
                    delay: 0,
                    usingSpringWithDamping: 0.76,
                    initialSpringVelocity: 0.12,
                    options: [.beginFromCurrentState, .allowUserInteraction],
                    animations: apply
                )
            }
        }
    }
}

private final class SantanderFilzaBrowserHeader: UIView {
    private let viewIconName: String
    let searchButton = SantanderPressButton(type: .system)
    private let nameButton = SantanderPressButton(type: .system)
    private let dateButton = SantanderPressButton(type: .system)
    private let sizeButton = SantanderPressButton(type: .system)
    private let viewButton = SantanderPressButton(type: .system)
    private let separator = UIView()
    var onSearch: (() -> Void)?
    var onSort: ((PathsSortMethods) -> Void)?
    var onGrid: (() -> Void)?

    func updateSortState(method: PathsSortMethods, order: SortOrder) {
        let controls: [(UIButton, PathsSortMethods)] = [
            (nameButton, .alphabetically),
            (dateButton, .dateModified),
            (sizeButton, .size)
        ]
        for (button, candidate) in controls {
            let selected = candidate == method
            button.tintColor = selected ? SantanderAppTheme.accentColor : .secondaryLabel
            button.setTitleColor(selected ? SantanderAppTheme.accentColor : .label, for: .normal)
            let assetName = selected ? (order == .ascending ? "arrow_up" : "arrow_down") : "no_sort"
            button.setImage(SantanderIconLibrary.shared.uiIcon(named: assetName), for: .normal)
        }
    }

    init(frame: CGRect, viewIconName: String = "grid") {
        self.viewIconName = viewIconName
        super.init(frame: frame)
        backgroundColor = .systemBackground
        [searchButton, nameButton, dateButton, sizeButton, viewButton].forEach { $0.adjustsImageWhenHighlighted = false }
        searchButton.setImage(SantanderIconLibrary.shared.uiIcon(named: "search"), for: .normal)
        searchButton.tintColor = .label
        searchButton.accessibilityLabel = "搜索"
        searchButton.addAction(UIAction { [weak self] _ in self?.onSearch?() }, for: .touchUpInside)

        configureSortButton(nameButton, title: "名称", symbol: "arrow.up.arrow.down")
        configureSortButton(dateButton, title: "日期", symbol: "arrow.up.arrow.down")
        configureSortButton(sizeButton, title: "大小", symbol: "arrow.up.arrow.down")
        nameButton.addAction(UIAction { [weak self] _ in self?.onSort?(.alphabetically) }, for: .touchUpInside)
        dateButton.addAction(UIAction { [weak self] _ in self?.onSort?(.dateModified) }, for: .touchUpInside)
        sizeButton.addAction(UIAction { [weak self] _ in self?.onSort?(.size) }, for: .touchUpInside)

        viewButton.setImage(SantanderIconLibrary.shared.uiIcon(named: viewIconName), for: .normal)
        viewButton.tintColor = .label
        viewButton.accessibilityLabel = "切换视图"
        viewButton.addAction(UIAction { [weak self] _ in self?.onGrid?() }, for: .touchUpInside)

        let stack = UIStackView(arrangedSubviews: [searchButton, nameButton, dateButton, sizeButton, viewButton])
        stack.axis = .horizontal
        stack.alignment = .fill
        stack.distribution = .fill
        stack.spacing = 0
        stack.translatesAutoresizingMaskIntoConstraints = false
        addSubview(stack)
        separator.backgroundColor = .separator
        separator.translatesAutoresizingMaskIntoConstraints = false
        addSubview(separator)
        NSLayoutConstraint.activate([
            stack.leadingAnchor.constraint(equalTo: leadingAnchor, constant: 8),
            stack.trailingAnchor.constraint(equalTo: trailingAnchor, constant: -8),
            stack.topAnchor.constraint(equalTo: topAnchor),
            stack.bottomAnchor.constraint(equalTo: bottomAnchor, constant: -1),
            searchButton.widthAnchor.constraint(equalToConstant: 36),
            nameButton.widthAnchor.constraint(greaterThanOrEqualToConstant: 76),
            dateButton.widthAnchor.constraint(greaterThanOrEqualToConstant: 62),
            sizeButton.widthAnchor.constraint(greaterThanOrEqualToConstant: 54),
            viewButton.widthAnchor.constraint(equalToConstant: 36),
            separator.leadingAnchor.constraint(equalTo: leadingAnchor),
            separator.trailingAnchor.constraint(equalTo: trailingAnchor),
            separator.bottomAnchor.constraint(equalTo: bottomAnchor),
            separator.heightAnchor.constraint(equalToConstant: 0.5)
        ])
        if UserPreferences.alwaysShowSearchBar {
            searchButton.isHidden = true
        }
    }

    private func configureSortButton(_ button: UIButton, title: String, symbol: String) {
        button.setTitle(title, for: .normal)
        let assetName = symbol == "arrow.up.arrow.down" ? "no_sort" : symbol
        button.setImage(SantanderIconLibrary.shared.uiIcon(named: assetName), for: .normal)
        button.tintColor = .secondaryLabel
        button.setTitleColor(.label, for: .normal)
        button.titleLabel?.font = .systemFont(ofSize: 14)
        button.titleLabel?.lineBreakMode = .byClipping
        button.semanticContentAttribute = .forceLeftToRight
        button.contentHorizontalAlignment = .center
        button.imageView?.contentMode = .scaleAspectFit
        button.imageView?.clipsToBounds = true
        button.titleEdgeInsets = UIEdgeInsets(top: 0, left: 4, bottom: 0, right: 0)
        button.imageEdgeInsets = UIEdgeInsets(top: 0, left: 0, bottom: 0, right: 3)
    }

    required init?(coder: NSCoder) { fatalError() }
}

private enum SantanderFileTypeBadge {
    static func title(for path: Path) -> String {
        if path.isDirectory { return "文件夹" }

        switch path.pathExtension.lowercased() {
        case "plist": return "属性列表"
        case "sqlite", "sqlite3", "db", "db3": return "SQLite"
        case "json": return "JSON"
        case "xml": return "XML"
        case "yaml", "yml": return "YAML"
        case "sh", "bash", "zsh", "fish", "command", "script": return "脚本"
        case "swift", "m", "mm", "c", "cc", "cpp", "h", "hpp", "js", "jsx", "ts", "tsx", "py", "rb", "go", "rs", "java", "kt": return "源代码"
        case "dylib", "so": return "动态库"
        case "framework": return "框架"
        case "bundle": return "捆绑包"
        case "pdf": return "PDF"
        case "zip", "tar", "tgz", "tbz", "tbz2", "gz", "bz2", "xz", "7z", "rar": return "归档"
        case "ttf", "otf", "woff", "woff2": return "字体"
        case "app": return "应用"
        default: break
        }

        if let type = path.contentType {
            if type.isSubtype(of: .image) { return "图像" }
            if type.isSubtype(of: .audio) { return "音频" }
            if type.isSubtype(of: .movie) || type.isSubtype(of: .video) { return "视频" }
            if type.isSubtype(of: .font) { return "字体" }
            if type.isSubtype(of: .pdf) { return "PDF" }
            if type.isSubtype(of: .archive) { return "归档" }
            if type.isSubtype(of: .sourceCode) { return "源代码" }
            if type.isSubtype(of: .text) { return "文本" }
            if type.isSubtype(of: .executable) { return "可执行文件" }
        }
        return "unknown"
    }
}

private struct SantanderFileMetadataPresentation {
    let isDirectory: Bool
    let sizeText: String
    let dateText: String
    let itemCount: Int?

    var compactText: String {
        if isDirectory {
            let count = itemCount.map(String.init) ?? "…"
            return "\(count) 项 · \(dateText)"
        }
        return "\(sizeText) · \(dateText)"
    }
}

private enum SantanderFileMetadataCache {
    static let didLoadNotification = Notification.Name("SantanderFileMetadataDidLoad")
    private static let lock = NSLock()
    private static var cache: [String: SantanderFileMetadataPresentation] = [:]
    private static var pending = Set<String>()
    private static let workerQueue: OperationQueue = {
        let queue = OperationQueue()
        queue.name = "com.santander.file-metadata"
        queue.qualityOfService = .utility
        queue.maxConcurrentOperationCount = 2
        return queue
    }()

    static func value(for url: URL) -> SantanderFileMetadataPresentation? {
        lock.lock(); defer { lock.unlock() }
        return cache[url.standardizedFileURL.path]
    }

    static func request(for path: Path) {
        let url = path.url.standardizedFileURL
        let key = url.path
        let pathSnapshot = path
        let isDirectoryHint = pathSnapshot.isDirectory
        lock.lock()
        if cache[key] != nil || pending.contains(key) {
            lock.unlock()
            return
        }
        pending.insert(key)
        lock.unlock()

        workerQueue.addOperation {
            let requestedKeys: Set<URLResourceKey> = [.isDirectoryKey, .fileSizeKey, .contentModificationDateKey]
            let values = try? url.resourceValues(forKeys: requestedKeys)
            let attributes = try? FileManager.default.attributesOfItem(atPath: key)
            let isDirectory: Bool
            if let resourceValue = values?.isDirectory {
                isDirectory = resourceValue
            } else if let fileType = attributes?[.type] as? FileAttributeType {
                isDirectory = fileType == .typeDirectory
            } else {
                isDirectory = isDirectoryHint
            }

            var itemCount: Int?
            var sizeText = "—"
            if isDirectory {
                itemCount = try? FileManager.default.contentsOfDirectory(atPath: key).count
            } else if let size = values?.fileSize ?? (attributes?[.size] as? NSNumber)?.intValue {
                let formatter = ByteCountFormatter()
                formatter.countStyle = .file
                formatter.includesActualByteCount = false
                sizeText = formatter.string(fromByteCount: Int64(max(0, size)))
            }

            let dateText: String
            if let date = values?.contentModificationDate ?? (attributes?[.modificationDate] as? Date) {
                let formatter = DateFormatter()
                formatter.dateStyle = .medium
                formatter.timeStyle = .none
                dateText = formatter.string(from: date)
            } else {
                dateText = "—"
            }
            let presentation = SantanderFileMetadataPresentation(
                isDirectory: isDirectory,
                sizeText: sizeText,
                dateText: dateText,
                itemCount: itemCount
            )
            lock.lock()
            cache[key] = presentation
            pending.remove(key)
            if cache.count > 1500, let oldestKey = cache.keys.first {
                cache.removeValue(forKey: oldestKey)
            }
            lock.unlock()
            DispatchQueue.main.async {
                NotificationCenter.default.post(name: didLoadNotification, object: key)
            }
        }
    }

    static func invalidate(_ url: URL) {
        lock.lock(); defer { lock.unlock() }
        cache.removeValue(forKey: url.standardizedFileURL.path)
    }
}

private final class SantanderFileListCell: UITableViewCell {
    static let reuseIdentifier = "SantanderFileListCell"

    let iconImageViewCustom = UIImageView()
    let titleLabelCustom = UILabel()
    let subtitleLabelCustom = UILabel()
    let badgeLabel = UILabel()
    private let tagStripeView = UIView()
    private let metadataStack = UIStackView()
    private let sizeLabel = UILabel()
    private let dateLabel = UILabel()
    private let titleStack = UIStackView()
    private let pointerActionsStack = UIStackView()
    private let rowAccessoryView = UIView(frame: CGRect(x: 0, y: 0, width: 48, height: 42))
    private let infoButton = UIButton(type: .system)
    private let accessoryChevron = UIImageView(image: UIImage(systemName: "chevron.right"))
    private var isWideMetadataLayout = false
    private var configuredPath: Path?
    enum PointerAction: Equatable { case share, rename, delete }
    var onPointerAction: ((PointerAction, Path) -> Void)?
    var onInfoAction: ((Path) -> Void)?

    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        setup()
    }

    required init?(coder: NSCoder) {
        super.init(coder: coder)
        setup()
    }

    private func setup() {
        SantanderUI.styleCell(self)
        selectionStyle = .default
        iconImageViewCustom.translatesAutoresizingMaskIntoConstraints = false
        iconImageViewCustom.contentMode = .scaleAspectFit
        iconImageViewCustom.clipsToBounds = false

        infoButton.frame = CGRect(x: 0, y: 0, width: 28, height: 42)
        infoButton.setImage(SantanderIconLibrary.shared.uiIcon(named: "file_detail"), for: .normal)
        infoButton.tintColor = SantanderAppTheme.accentColor
        infoButton.accessibilityLabel = "信息"
        infoButton.addAction(UIAction { [weak self] _ in
            guard let self, let path = self.configuredPath else { return }
            self.onInfoAction?(path)
        }, for: .touchUpInside)
        accessoryChevron.frame = CGRect(x: 34, y: 0, width: 8, height: 42)
        accessoryChevron.contentMode = .scaleAspectFit
        accessoryChevron.tintColor = .secondaryLabel
        rowAccessoryView.addSubview(infoButton)
        rowAccessoryView.addSubview(accessoryChevron)
        accessoryView = rowAccessoryView

        titleLabelCustom.font = .preferredFont(forTextStyle: .body)
        titleLabelCustom.adjustsFontForContentSizeCategory = true
        titleLabelCustom.numberOfLines = 1
        titleLabelCustom.lineBreakMode = .byTruncatingTail
        titleLabelCustom.setContentCompressionResistancePriority(.defaultLow, for: .horizontal)

        subtitleLabelCustom.font = .preferredFont(forTextStyle: .caption1)
        subtitleLabelCustom.textColor = .secondaryLabel
        subtitleLabelCustom.adjustsFontForContentSizeCategory = true
        subtitleLabelCustom.numberOfLines = 1
        subtitleLabelCustom.lineBreakMode = .byTruncatingMiddle
        subtitleLabelCustom.setContentCompressionResistancePriority(.defaultLow, for: .horizontal)

        for label in [sizeLabel, dateLabel] {
            label.font = .preferredFont(forTextStyle: .caption1)
            label.adjustsFontForContentSizeCategory = true
            label.textColor = .secondaryLabel
            label.textAlignment = .right
            label.setContentHuggingPriority(.required, for: .horizontal)
            label.setContentCompressionResistancePriority(.required, for: .horizontal)
            label.numberOfLines = 1
        }
        sizeLabel.textColor = SantanderAppTheme.accentColor
        sizeLabel.widthAnchor.constraint(equalToConstant: 78).isActive = true
        dateLabel.widthAnchor.constraint(equalToConstant: 112).isActive = true

        titleStack.axis = .vertical
        titleStack.alignment = .fill
        titleStack.spacing = 2
        titleStack.translatesAutoresizingMaskIntoConstraints = false
        titleStack.addArrangedSubview(titleLabelCustom)
        titleStack.addArrangedSubview(subtitleLabelCustom)

        metadataStack.axis = .horizontal
        metadataStack.alignment = .center
        metadataStack.spacing = 12
        metadataStack.isHidden = true
        metadataStack.translatesAutoresizingMaskIntoConstraints = false
        metadataStack.addArrangedSubview(dateLabel)
        metadataStack.addArrangedSubview(sizeLabel)

        // The type label remains available for accessibility but is not rendered as a permanent badge.
        badgeLabel.isHidden = true
        tagStripeView.translatesAutoresizingMaskIntoConstraints = false
        tagStripeView.backgroundColor = .clear
        tagStripeView.isHidden = true

        pointerActionsStack.axis = .horizontal
        pointerActionsStack.alignment = .center
        pointerActionsStack.spacing = 4
        pointerActionsStack.isHidden = true
        for (symbol, action, title) in [("square.and.arrow.up", PointerAction.share, "分享"), ("pencil", PointerAction.rename, "重命名"), ("trash", PointerAction.delete, "删除")] {
            let button = UIButton(type: .system)
            button.setImage(SantanderIconLibrary.shared.interfaceIcon(for: symbol), for: .normal)
            button.accessibilityLabel = title
            button.tintColor = action == .delete ? .systemRed : .secondaryLabel
            button.widthAnchor.constraint(equalToConstant: 30).isActive = true
            button.heightAnchor.constraint(equalToConstant: 32).isActive = true
            button.addAction(UIAction { [weak self] _ in
                guard let self, let path = self.configuredPath else { return }
                self.onPointerAction?(action, path)
            }, for: .touchUpInside)
            pointerActionsStack.addArrangedSubview(button)
        }
        let mainStack = UIStackView(arrangedSubviews: [iconImageViewCustom, titleStack, metadataStack, pointerActionsStack])
        mainStack.axis = .horizontal
        mainStack.alignment = .center
        mainStack.spacing = 10
        mainStack.translatesAutoresizingMaskIntoConstraints = false
        mainStack.setCustomSpacing(10, after: iconImageViewCustom)

        contentView.addSubview(tagStripeView)
        contentView.addSubview(mainStack)
        let margins = contentView.layoutMarginsGuide
        NSLayoutConstraint.activate([
            tagStripeView.leadingAnchor.constraint(equalTo: contentView.leadingAnchor),
            tagStripeView.topAnchor.constraint(equalTo: contentView.topAnchor, constant: 7),
            tagStripeView.bottomAnchor.constraint(equalTo: contentView.bottomAnchor, constant: -7),
            tagStripeView.widthAnchor.constraint(equalToConstant: 3),
            iconImageViewCustom.widthAnchor.constraint(equalToConstant: 38),
            iconImageViewCustom.heightAnchor.constraint(equalToConstant: 38),
            mainStack.leadingAnchor.constraint(equalTo: margins.leadingAnchor),
            mainStack.trailingAnchor.constraint(equalTo: margins.trailingAnchor),
            mainStack.topAnchor.constraint(greaterThanOrEqualTo: contentView.topAnchor, constant: 4),
            mainStack.bottomAnchor.constraint(lessThanOrEqualTo: contentView.bottomAnchor, constant: -4),
            mainStack.centerYAnchor.constraint(equalTo: contentView.centerYAnchor)
        ])

        isAccessibilityElement = true
        if UIDevice.isiPad {
            let hover = UIHoverGestureRecognizer(target: self, action: #selector(handlePointerHover(_:)))
            addGestureRecognizer(hover)
        }
    }

    @objc private func handlePointerHover(_ recognizer: UIHoverGestureRecognizer) {
        switch recognizer.state {
        case .began, .changed:
            pointerActionsStack.isHidden = false
        case .ended, .cancelled, .failed:
            pointerActionsStack.isHidden = true
        default: break
        }
    }

    func highlightTitle(matching query: String) {
        guard let title = titleLabelCustom.text, !query.isEmpty else { return }
        let value = NSMutableAttributedString(string: title, attributes: [.font: titleLabelCustom.font as Any, .foregroundColor: titleLabelCustom.textColor as Any])
        let nsTitle = title as NSString
        var searchRange = NSRange(location: 0, length: nsTitle.length)
        while searchRange.length > 0 {
            let match = nsTitle.range(of: query, options: [.caseInsensitive, .diacriticInsensitive], range: searchRange)
            if match.location == NSNotFound { break }
            value.addAttributes([.backgroundColor: UIColor.systemYellow.withAlphaComponent(0.38), .foregroundColor: UIColor.label], range: match)
            let next = match.location + max(match.length, 1)
            if next >= nsTitle.length { break }
            searchRange = NSRange(location: next, length: nsTitle.length - next)
        }
        titleLabelCustom.attributedText = value
    }

    override func setHighlighted(_ highlighted: Bool, animated: Bool) {
        super.setHighlighted(highlighted, animated: animated)
        let changes = {
            self.contentView.backgroundColor = highlighted ? .secondarySystemBackground : .systemBackground
            self.contentView.transform = highlighted ? CGAffineTransform(scaleX: 0.996, y: 0.996) : .identity
        }
        if animated && !UIAccessibility.isReduceMotionEnabled {
            UIView.animate(
                withDuration: 0.24,
                delay: 0,
                usingSpringWithDamping: 0.86,
                initialSpringVelocity: 0.08,
                options: [.beginFromCurrentState, .allowUserInteraction],
                animations: changes
            )
        } else {
            changes()
        }
    }

    override func layoutSubviews() {
        super.layoutSubviews()
        let wide = bounds.width >= 650 && UserPreferences.showFileMetadata
        let compactMetadata = bounds.width < 650 && UserPreferences.showFileMetadata
        if wide != isWideMetadataLayout || metadataStack.isHidden != !(wide || compactMetadata) {
            isWideMetadataLayout = wide
            metadataStack.isHidden = !(wide || compactMetadata)
            dateLabel.isHidden = !wide
        }
        let hasFullPathSubtitle = subtitleLabelCustom.text?.hasPrefix("/") == true
        subtitleLabelCustom.isHidden = wide || (compactMetadata && !hasFullPathSubtitle) || subtitleLabelCustom.text?.isEmpty != false
        switch UserPreferences.listDensity {
        case .compact:
            iconImageViewCustom.transform = CGAffineTransform(scaleX: 0.88, y: 0.88)
        case .standard, .comfortable:
            iconImageViewCustom.transform = .identity
        }
    }

    override func prepareForReuse() {
        super.prepareForReuse()
        iconImageViewCustom.image = nil
        titleLabelCustom.text = nil
        titleLabelCustom.textColor = .label
        subtitleLabelCustom.text = nil
        subtitleLabelCustom.isHidden = false
        sizeLabel.text = nil
        dateLabel.text = nil
        dateLabel.isHidden = false
        badgeLabel.text = nil
        tagStripeView.backgroundColor = .clear
        tagStripeView.isHidden = true
        metadataStack.isHidden = true
        isWideMetadataLayout = false
        accessoryType = .none
        tintColor = SantanderAppTheme.accentColor
        accessibilityLabel = nil
        accessibilityValue = nil
        accessibilityHint = nil
        accessibilityCustomActions = nil
        configuredPath = nil
        contentView.backgroundColor = .systemBackground
        contentView.transform = .identity
        onPointerAction = nil
        onInfoAction = nil
        pointerActionsStack.isHidden = true
    }

    func configure(path: Path, title: String? = nil, subtitle: String? = nil, image: UIImage?, accessory: UITableViewCell.AccessoryType) {
        SantanderUI.styleCell(self)
        switch UserPreferences.listDensity {
        case .compact: contentView.layoutMargins = UIEdgeInsets(top: 4, left: 16, bottom: 4, right: 16)
        case .standard: contentView.layoutMargins = UIEdgeInsets(top: 7, left: 16, bottom: 7, right: 16)
        case .comfortable: contentView.layoutMargins = UIEdgeInsets(top: 11, left: 16, bottom: 11, right: 16)
        }
        configuredPath = path
        iconImageViewCustom.image = image
        titleLabelCustom.attributedText = nil
        titleLabelCustom.text = title ?? path.lastPathComponent
        subtitleLabelCustom.text = UserPreferences.showFileMetadata ? subtitle : nil
        subtitleLabelCustom.isHidden = subtitleLabelCustom.text?.isEmpty != false
        badgeLabel.text = SantanderFileTypeBadge.title(for: path)
        accessoryType = .none
        accessoryView = rowAccessoryView

        if UserPreferences.showFileMetadata {
            if let metadata = SantanderFileMetadataCache.value(for: path.url) {
                sizeLabel.text = metadata.isDirectory ? (metadata.itemCount.map { "\($0) 项" } ?? "…") : metadata.sizeText
                dateLabel.text = metadata.dateText
            } else {
                sizeLabel.text = "…"
                dateLabel.text = "…"
                SantanderFileMetadataCache.request(for: path)
            }
        } else {
            sizeLabel.text = nil
            dateLabel.text = nil
        }

        if let tag = SantanderPathTagStore.tag(for: path.url) {
            tagStripeView.backgroundColor = tag.color
            tagStripeView.isHidden = false
        } else {
            tagStripeView.backgroundColor = .clear
            tagStripeView.isHidden = true
        }

        let typeName = SantanderFileTypeBadge.title(for: path)
        let metadataText = [dateLabel.text, sizeLabel.text].compactMap { $0 }.joined(separator: ", ")
        accessibilityLabel = [titleLabelCustom.text, typeName, metadataText].compactMap { $0 }.joined(separator: ", ")
        accessibilityValue = subtitleLabelCustom.text
        accessibilityHint = path.isDirectory ? "双击进入文件夹" : "双击打开文件"
        accessibilityCustomActions = [
            UIAccessibilityCustomAction(name: "分享", target: self, selector: #selector(accessibilityShare)),
            UIAccessibilityCustomAction(name: "重命名", target: self, selector: #selector(accessibilityRename)),
            UIAccessibilityCustomAction(name: "删除", target: self, selector: #selector(accessibilityDelete))
        ]
        setNeedsLayout()
    }

    @objc private func accessibilityShare() -> Bool { guard let path = configuredPath else { return false }; onPointerAction?(.share, path); return true }
    @objc private func accessibilityRename() -> Bool { guard let path = configuredPath else { return false }; onPointerAction?(.rename, path); return true }
    @objc private func accessibilityDelete() -> Bool { guard let path = configuredPath else { return false }; onPointerAction?(.delete, path); return true }
}

private final class SantanderEmptyStateView: UIView {
    init(icon: String, title: String, message: String?, actionTitle: String? = nil, action: (() -> Void)? = nil) {
        super.init(frame: .zero)
        translatesAutoresizingMaskIntoConstraints = false
        let symbol = UIImageView(image: UIImage(systemName: icon))
        symbol.tintColor = .secondaryLabel
        symbol.contentMode = .scaleAspectFit
        symbol.preferredSymbolConfiguration = UIImage.SymbolConfiguration(pointSize: 42, weight: .regular)
        symbol.translatesAutoresizingMaskIntoConstraints = false

        let titleLabel = UILabel()
        titleLabel.text = title
        titleLabel.font = .preferredFont(forTextStyle: .headline)
        titleLabel.adjustsFontForContentSizeCategory = true
        titleLabel.textAlignment = .center
        titleLabel.numberOfLines = 0

        let messageLabel = UILabel()
        messageLabel.text = message
        messageLabel.font = .preferredFont(forTextStyle: .subheadline)
        messageLabel.adjustsFontForContentSizeCategory = true
        messageLabel.textColor = .secondaryLabel
        messageLabel.textAlignment = .center
        messageLabel.numberOfLines = 0

        let stack = UIStackView(arrangedSubviews: [symbol, titleLabel, messageLabel])
        stack.axis = .vertical
        stack.alignment = .center
        stack.spacing = 10
        stack.translatesAutoresizingMaskIntoConstraints = false
        addSubview(stack)
        NSLayoutConstraint.activate([
            stack.leadingAnchor.constraint(greaterThanOrEqualTo: leadingAnchor, constant: 24),
            stack.trailingAnchor.constraint(lessThanOrEqualTo: trailingAnchor, constant: -24),
            stack.centerXAnchor.constraint(equalTo: centerXAnchor),
            stack.centerYAnchor.constraint(equalTo: centerYAnchor),
            stack.widthAnchor.constraint(lessThanOrEqualToConstant: 320),
            symbol.widthAnchor.constraint(equalToConstant: 52),
            symbol.heightAnchor.constraint(equalToConstant: 52)
        ])

        if let actionTitle, let action {
            let button = UIButton(type: .system)
            if #available(iOS 15.0, *) {
                var config = UIButton.Configuration.filled()
                config.title = actionTitle
                config.cornerStyle = .medium
                button.configuration = config
            } else {
                button.setTitle(actionTitle, for: .normal)
                button.setTitleColor(.white, for: .normal)
                button.backgroundColor = tintColor
                button.layer.cornerRadius = 8
                button.contentEdgeInsets = UIEdgeInsets(top: 10, left: 16, bottom: 10, right: 16)
            }
            button.addAction(UIAction { _ in action() }, for: .touchUpInside)
            stack.addArrangedSubview(button)
        }
        isAccessibilityElement = false
    }

    required init?(coder: NSCoder) { fatalError("init(coder:) has not been implemented") }
}

private final class SantanderGridCell: UICollectionViewCell {
    static let reuseIdentifier = "SantanderGridCell"
    private let iconView = UIImageView()
    private let titleLabel = UILabel()
    private let detailLabel = UILabel()
    private var representedPath: Path?

    override init(frame: CGRect) {
        super.init(frame: frame)
        backgroundColor = .clear
        contentView.backgroundColor = .clear
        contentView.layer.cornerRadius = 0
        contentView.layer.cornerCurve = .continuous
        contentView.layer.masksToBounds = false

        iconView.contentMode = .scaleAspectFit
        iconView.translatesAutoresizingMaskIntoConstraints = false
        titleLabel.font = .preferredFont(forTextStyle: .caption1)
        titleLabel.adjustsFontForContentSizeCategory = true
        titleLabel.numberOfLines = 2
        titleLabel.textAlignment = .center
        detailLabel.font = .systemFont(ofSize: 10.5, weight: .regular)
        detailLabel.adjustsFontForContentSizeCategory = true
        detailLabel.textColor = .secondaryLabel
        detailLabel.numberOfLines = 1
        detailLabel.textAlignment = .center
        detailLabel.lineBreakMode = .byTruncatingMiddle

        let labels = UIStackView(arrangedSubviews: [titleLabel, detailLabel])
        labels.axis = .vertical
        labels.alignment = .fill
        labels.spacing = 3
        labels.translatesAutoresizingMaskIntoConstraints = false
        contentView.addSubview(iconView)
        contentView.addSubview(labels)
        NSLayoutConstraint.activate([
            iconView.topAnchor.constraint(equalTo: contentView.topAnchor, constant: 4),
            iconView.centerXAnchor.constraint(equalTo: contentView.centerXAnchor),
            iconView.widthAnchor.constraint(equalToConstant: 62),
            iconView.heightAnchor.constraint(equalToConstant: 62),
            labels.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 6),
            labels.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -6),
            labels.topAnchor.constraint(equalTo: iconView.bottomAnchor, constant: 5),
            labels.bottomAnchor.constraint(lessThanOrEqualTo: contentView.bottomAnchor, constant: -4)
        ])
        isAccessibilityElement = true
        NotificationCenter.default.addObserver(self, selector: #selector(thumbnailDidLoad(_:)), name: PathImageCache.didLoadNotification, object: nil)
    }

    required init?(coder: NSCoder) { fatalError("init(coder:) has not been implemented") }

    deinit {
        NotificationCenter.default.removeObserver(self)
    }

    func configure(path: Path) {
        representedPath = path
        iconView.image = PathImageCache.image(for: path) ?? path.displayImage
        PathImageCache.prefetch(path)
        let metadata = UserPreferences.showFileMetadata ? SantanderFileMetadataCache.value(for: path.url) : nil
        titleLabel.text = path.lastPathComponent
        detailLabel.text = UserPreferences.showFileMetadata ? (metadata?.compactText ?? (path.isDirectory ? "… 项" : "…")) : nil
        accessibilityLabel = [path.lastPathComponent, path.isDirectory ? "文件夹" : SantanderFileTypeBadge.title(for: path), detailLabel.text].compactMap { $0 }.joined(separator: ", ")
        accessibilityHint = path.isDirectory ? "双击进入文件夹" : "双击打开文件"
    }

    @objc private func thumbnailDidLoad(_ notification: Notification) {
        guard let url = notification.object as? URL,
              url.standardizedFileURL == representedPath?.url.standardizedFileURL,
              let path = representedPath,
              let thumbnail = PathImageCache.image(for: path) else { return }
        iconView.image = thumbnail
    }

    override var isSelected: Bool {
        didSet {
            let updates = {
                self.contentView.backgroundColor = self.isSelected ? SantanderAppTheme.accentColor.withAlphaComponent(0.13) : .clear
                self.contentView.transform = self.isSelected ? CGAffineTransform(scaleX: 0.975, y: 0.975) : .identity
                self.contentView.layer.borderWidth = 0
                self.contentView.layer.borderColor = UIColor.clear.cgColor
            }
            if UIAccessibility.isReduceMotionEnabled {
                updates()
            } else {
                UIView.animate(
                    withDuration: 0.30,
                    delay: 0,
                    usingSpringWithDamping: 0.88,
                    initialSpringVelocity: 0.10,
                    options: [.beginFromCurrentState, .allowUserInteraction],
                    animations: updates
                )
            }
        }
    }

    override func prepareForReuse() {
        super.prepareForReuse()
        representedPath = nil
        iconView.image = nil
        titleLabel.text = nil
        detailLabel.text = nil
        accessibilityLabel = nil
        accessibilityValue = nil
        accessibilityHint = nil
        contentView.backgroundColor = .clear
        contentView.transform = .identity
        contentView.layer.borderWidth = 0
        contentView.layer.borderColor = UIColor.clear.cgColor
    }
}

private final class SantanderDirectoryStatusView: UIView {
    private let lockImageView = UIImageView()
    private let accessLabel = UILabel()
    private let countsLabel = UILabel()

    override init(frame: CGRect) {
        super.init(frame: frame)
        translatesAutoresizingMaskIntoConstraints = false
        backgroundColor = .secondarySystemBackground
        lockImageView.translatesAutoresizingMaskIntoConstraints = false
        lockImageView.contentMode = .scaleAspectFit
        lockImageView.setContentHuggingPriority(.required, for: .horizontal)
        lockImageView.setContentCompressionResistancePriority(.required, for: .horizontal)
        accessLabel.translatesAutoresizingMaskIntoConstraints = false
        accessLabel.font = .preferredFont(forTextStyle: .caption2)
        accessLabel.adjustsFontForContentSizeCategory = true
        accessLabel.setContentHuggingPriority(.required, for: .horizontal)
        countsLabel.translatesAutoresizingMaskIntoConstraints = false
        countsLabel.font = .monospacedDigitSystemFont(ofSize: 10.5, weight: .regular)
        countsLabel.textColor = .secondaryLabel
        countsLabel.textAlignment = .right
        countsLabel.lineBreakMode = .byTruncatingMiddle
        countsLabel.adjustsFontForContentSizeCategory = true
        let left = UIStackView(arrangedSubviews: [lockImageView, accessLabel])
        left.translatesAutoresizingMaskIntoConstraints = false
        left.axis = .horizontal
        left.alignment = .center
        left.spacing = 5
        addSubview(left)
        addSubview(countsLabel)
        NSLayoutConstraint.activate([
            lockImageView.widthAnchor.constraint(equalToConstant: 13),
            lockImageView.heightAnchor.constraint(equalToConstant: 13),
            left.leadingAnchor.constraint(equalTo: leadingAnchor, constant: 14),
            left.centerYAnchor.constraint(equalTo: centerYAnchor),
            countsLabel.leadingAnchor.constraint(greaterThanOrEqualTo: left.trailingAnchor, constant: 8),
            countsLabel.trailingAnchor.constraint(equalTo: trailingAnchor, constant: -14),
            countsLabel.centerYAnchor.constraint(equalTo: centerYAnchor)
        ])
        isAccessibilityElement = true
    }

    required init?(coder: NSCoder) { fatalError("init(coder:) has not been implemented") }

    func configure(at directoryURL: URL, items: [Path], hiddenCount: Int, canWrite: Bool, viaRootHelper: Bool) {
        let folders = items.filter(\.isDirectory).count
        let files = max(0, items.count - folders)
        if canWrite {
            lockImageView.image = UIImage(systemName: "lock.open.fill")
            lockImageView.tintColor = .systemGreen
            accessLabel.text = viaRootHelper ? "SantanderHelper 可修改" : "可写入"
            accessLabel.textColor = .systemGreen
        } else {
            lockImageView.image = UIImage(systemName: "lock.fill")
            lockImageView.tintColor = .secondaryLabel
            accessLabel.text = "本进程只读"
            accessLabel.textColor = .secondaryLabel
        }
        var summary = "\(files) 个文件 · \(folders) 个文件夹"
        if hiddenCount > 0 { summary += " · 隐藏 \(hiddenCount)" }
        if let volume = try? directoryURL.resourceValues(forKeys: [.volumeAvailableCapacityKey, .volumeTotalCapacityKey]),
           let free = volume.volumeAvailableCapacity,
           let total = volume.volumeTotalCapacity, total > 0 {
            let used = max(0, total - free)
            let formatter = ByteCountFormatter()
            formatter.countStyle = .file
            summary += " · 已用 \(formatter.string(fromByteCount: Int64(used))) / 可用 \(formatter.string(fromByteCount: Int64(free)))"
        }
        countsLabel.text = summary
        accessibilityLabel = "\(accessLabel.text ?? "")，\(summary)"
    }
}

private final class SantanderGridViewController: UIViewController, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    private let directoryPath: Path
    private var entries: [Path] = []
    private var loadingGeneration = UUID()
    private var sortMethod: PathsSortMethods = .userPrefered ?? .alphabetically
    private var animatedGridPaths = Set<String>()
    private var collectionView: UICollectionView!
    private let emptyLabel = UILabel()
    private var browserHeader: SantanderFilzaBrowserHeader?
    private var gridBottomBar: UIView?
    private var gridBottomBarHeightConstraint: NSLayoutConstraint?
    private var directoryStatusView: SantanderDirectoryStatusView?
    private let browserBottomBarHeight: CGFloat = 72

    init(path: Path) {
        directoryPath = path
        super.init(nibName: nil, bundle: nil)
        title = path.lastPathComponent.isEmpty ? "/" : path.lastPathComponent
        navigationItem.rightBarButtonItem = UIBarButtonItem(
            image: SantanderIconLibrary.shared.uiIcon(named: "more"),
            style: .plain,
            target: self,
            action: #selector(showGridActions)
        )
    }

    required init?(coder: NSCoder) { fatalError("init(coder:) has not been implemented") }

    override func viewDidLoad() {
        super.viewDidLoad()
        applySantanderUI()
        view.backgroundColor = .systemBackground

        let layout = UICollectionViewFlowLayout()
        layout.minimumInteritemSpacing = 12
        layout.minimumLineSpacing = 18
        layout.sectionInset = UIEdgeInsets(top: 10, left: 8, bottom: 18, right: 8)
        collectionView = UICollectionView(frame: .zero, collectionViewLayout: layout)
        collectionView.translatesAutoresizingMaskIntoConstraints = false
        collectionView.backgroundColor = .systemBackground
        collectionView.dataSource = self
        collectionView.delegate = self
        collectionView.register(SantanderGridCell.self, forCellWithReuseIdentifier: SantanderGridCell.reuseIdentifier)

        let header = SantanderFilzaBrowserHeader(frame: .zero, viewIconName: "list")
        header.translatesAutoresizingMaskIntoConstraints = false
        header.onSearch = { [weak self] in self?.openGridSearch() }
        header.onSort = { [weak self] method in self?.updateGridSort(method) }
        header.onGrid = { [weak self] in
            guard let self else { return }
            self.navigationController?.pushViewController(PathListViewController(style: .plain, path: self.directoryPath), animated: true)
        }
        header.updateSortState(method: sortMethod, order: .userPreferred)
        browserHeader = header
        view.addSubview(header)
        view.addSubview(collectionView)
        NSLayoutConstraint.activate([
            header.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            header.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            header.topAnchor.constraint(equalTo: view.topAnchor),
            header.heightAnchor.constraint(equalToConstant: 44),
            collectionView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            collectionView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            collectionView.topAnchor.constraint(equalTo: header.bottomAnchor),
        ])

        emptyLabel.text = SantanderL10n.t("This folder is empty")
        emptyLabel.textColor = .secondaryLabel
        emptyLabel.font = .preferredFont(forTextStyle: .body)
        emptyLabel.textAlignment = .center
        emptyLabel.isHidden = true
        emptyLabel.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(emptyLabel)
        NSLayoutConstraint.activate([
            emptyLabel.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            emptyLabel.centerYAnchor.constraint(equalTo: collectionView.centerYAnchor)
        ])
        installGridBottomBar()
        if let gridBottomBar {
            collectionView.bottomAnchor.constraint(equalTo: gridBottomBar.topAnchor).isActive = true
        }

        NotificationCenter.default.addObserver(self, selector: #selector(metadataDidLoad(_:)), name: SantanderFileMetadataCache.didLoadNotification, object: nil)
    }

    deinit { NotificationCenter.default.removeObserver(self) }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        reloadEntries()
    }

    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        let resolvedBarHeight = browserBottomBarHeight + view.safeAreaInsets.bottom
        if let constraint = gridBottomBarHeightConstraint, abs(constraint.constant - resolvedBarHeight) > 0.5 {
            constraint.constant = resolvedBarHeight
        }
        guard collectionView.bounds.width.isFinite,
              collectionView.bounds.width > 1,
              let layout = collectionView.collectionViewLayout as? UICollectionViewFlowLayout else { return }
        let usableWidth = max(1, collectionView.bounds.width - layout.sectionInset.left - layout.sectionInset.right)
        let idealWidth: CGFloat = traitCollection.horizontalSizeClass == .regular ? 112 : 84
        let columns = max(2, min(7, Int((usableWidth + layout.minimumInteritemSpacing) / (idealWidth + layout.minimumInteritemSpacing))))
        let totalSpacing = CGFloat(columns - 1) * layout.minimumInteritemSpacing
        let itemWidth = max(1, floor((usableWidth - totalSpacing) / CGFloat(columns)))
        let itemHeight: CGFloat = UserPreferences.listDensity == .comfortable ? 142 : 126
        if layout.itemSize != CGSize(width: itemWidth, height: itemHeight) {
            layout.itemSize = CGSize(width: itemWidth, height: itemHeight)
            layout.invalidateLayout()
        }
    }

    private func reloadEntries() {
        let generation = UUID()
        loadingGeneration = generation
        let path = directoryPath
        let sortMethod = self.sortMethod
        DispatchQueue.global(qos: .userInitiated).async { [weak self] in
            let allPaths = path.url.contents.map(Path.init(url:))
            let hiddenCount = allPaths.filter { $0.lastPathComponent.hasPrefix(".") }.count
            var paths = allPaths
            if !UserPreferences.displayHiddenFiles {
                paths.removeAll { $0.lastPathComponent.hasPrefix(".") }
            }
            paths = sortMethod.sorting(URLs: paths, sortOrder: .userPreferred)
            let writeAccess = RootConf.shared.directoryWriteAccess(at: path.url, probeRootHelper: false)
            DispatchQueue.main.async {
                guard let self, self.loadingGeneration == generation else { return }
                self.entries = paths
                self.directoryStatusView?.configure(at: path.url, items: allPaths, hiddenCount: hiddenCount, canWrite: writeAccess.canWrite, viaRootHelper: writeAccess.viaRootHelper)
                self.collectionView.reloadData()
                self.emptyLabel.isHidden = !paths.isEmpty
            }
        }
    }

    @objc private func metadataDidLoad(_ note: Notification) {
        guard UserPreferences.showFileMetadata,
              let path = note.object as? String else { return }
        guard entries.contains(where: { $0.url.standardizedFileURL.path == path }) else { return }
        for cell in collectionView.visibleCells {
            guard let gridCell = cell as? SantanderGridCell,
                  let indexPath = collectionView.indexPath(for: gridCell), entries.indices.contains(indexPath.item) else { continue }
            if entries[indexPath.item].url.standardizedFileURL.path == path {
                gridCell.configure(path: entries[indexPath.item])
            }
        }
    }

    private func installGridBottomBar() {
        let bar = UIView()
        bar.translatesAutoresizingMaskIntoConstraints = false
        bar.backgroundColor = .systemBackground
        let divider = UIView()
        divider.translatesAutoresizingMaskIntoConstraints = false
        divider.backgroundColor = .separator
        bar.addSubview(divider)

        let statusView = SantanderDirectoryStatusView()
        directoryStatusView = statusView
        bar.addSubview(statusView)

        let stack = UIStackView()
        stack.translatesAutoresizingMaskIntoConstraints = false
        stack.axis = .horizontal
        stack.alignment = .fill
        stack.distribution = .fillEqually
        bar.addSubview(stack)

        let recents = makeGridBottomButton(assetName: "recents", title: "最近") { [weak self] in
            guard let self else { return }
            self.present(UINavigationController(rootViewController: SantanderRecentPathsViewController(style: .plain)), animated: true)
        }
        let favorites = makeGridBottomButton(assetName: "favorites", title: "收藏") { [weak self] in
            guard let self else { return }
            self.present(UINavigationController(rootViewController: SantanderFavoritesViewController(style: .plain)), animated: true)
        }
        let settings = makeGridBottomButton(assetName: "setting", title: "设置") { [weak self] in
            guard let self else { return }
            self.present(UINavigationController(rootViewController: SettingsTableViewController(style: .insetGrouped)), animated: true)
        }
        let tabs = makeGridBottomButton(assetName: "tab", title: "标签页") { [weak self] in self?.showGridBrowserTabs() }
        [recents, favorites, settings, tabs].forEach { stack.addArrangedSubview($0) }
        view.addSubview(bar)

        let height = bar.heightAnchor.constraint(equalToConstant: browserBottomBarHeight + view.safeAreaInsets.bottom)
        gridBottomBarHeightConstraint = height
        gridBottomBar = bar
        NSLayoutConstraint.activate([
            bar.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            bar.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            bar.bottomAnchor.constraint(equalTo: view.bottomAnchor),
            height,
            divider.leadingAnchor.constraint(equalTo: bar.leadingAnchor),
            divider.trailingAnchor.constraint(equalTo: bar.trailingAnchor),
            divider.topAnchor.constraint(equalTo: bar.topAnchor),
            divider.heightAnchor.constraint(equalToConstant: 0.5),
            statusView.leadingAnchor.constraint(equalTo: bar.leadingAnchor),
            statusView.trailingAnchor.constraint(equalTo: bar.trailingAnchor),
            statusView.topAnchor.constraint(equalTo: divider.bottomAnchor),
            statusView.heightAnchor.constraint(equalToConstant: 24),
            stack.leadingAnchor.constraint(equalTo: bar.leadingAnchor),
            stack.trailingAnchor.constraint(equalTo: bar.trailingAnchor),
            stack.topAnchor.constraint(equalTo: statusView.bottomAnchor),
            stack.heightAnchor.constraint(equalToConstant: 48)
        ])
        view.bringSubviewToFront(bar)
    }

    private func makeGridBottomButton(assetName: String, title: String, action: @escaping () -> Void) -> UIButton {
        let button = SantanderPressButton(type: .system)
        button.setImage(SantanderIconLibrary.shared.uiIcon(named: assetName), for: .normal)
        button.imageView?.contentMode = .scaleAspectFit
        button.adjustsImageWhenHighlighted = false
        button.accessibilityLabel = title
        button.addAction(UIAction { _ in action() }, for: .touchUpInside)
        return button
    }

    private func showGridBrowserTabs() {
        guard let navigationController else { return }
        let controller = SantanderBrowserTabsViewController(browserNavigationController: navigationController)
        let modal = UINavigationController(rootViewController: controller)
        modal.modalPresentationStyle = .pageSheet
        if #available(iOS 15.0, *) {
            modal.sheetPresentationController?.detents = [.medium(), .large()]
            modal.sheetPresentationController?.prefersGrabberVisible = true
        }
        present(modal, animated: true)
    }

    @objc private func showGridActions() {
        var actions: [SantanderActionSheetItem] = [
            SantanderActionSheetItem(title: SantanderL10n.t("New.."), image: SantanderIconLibrary.shared.uiIcon(named: "new_folder")) { [weak self] in self?.showGridNewItemOptions() },
            SantanderActionSheetItem(title: SantanderL10n.t("Sort by.."), image: SantanderIconLibrary.shared.uiIcon(named: "no_sort")) { [weak self] in self?.showSortOptions() },
            SantanderActionSheetItem(title: SantanderL10n.t("List View"), image: SantanderIconLibrary.shared.interfaceIcon(for: "list.bullet")) { [weak self] in
                guard let self else { return }
                self.navigationController?.pushViewController(PathListViewController(style: .plain, path: self.directoryPath), animated: true)
            },
            SantanderActionSheetItem(title: SantanderL10n.t("Terminal"), subtitle: directoryPath.path, image: SantanderIconLibrary.shared.interfaceIcon(for: "terminal")) { [weak self] in
                guard let self else { return }
                self.navigationController?.pushViewController(TerminalViewController(workingDirectory: self.directoryPath.url), animated: true)
            },
            SantanderActionSheetItem(title: SantanderL10n.t("Folder Info"), image: SantanderIconLibrary.shared.interfaceIcon(for: "info.circle")) { [weak self] in
                guard let self else { return }
                self.present(UINavigationController(rootViewController: PathInformationTableViewController(style: .insetGrouped, path: self.directoryPath)), animated: true)
            }
        ]
        if !UIPasteboard.general.probableURLs.isEmpty {
            actions.insert(SantanderActionSheetItem(title: SantanderL10n.t("Paste"), image: SantanderIconLibrary.shared.uiIcon(named: "paste_bp")) { [weak self] in self?.pasteIntoGridDirectory() }, at: 0)
        }
        actions.append(SantanderActionSheetItem(title: SantanderL10n.t("Cancel"), style: .cancel))
        presentSantanderActionSheet(title: SantanderL10n.t("File actions"), actions: actions)
    }

    private func openGridSearch() {
        let controller = PathListViewController(style: .plain, path: directoryPath)
        navigationController?.pushViewController(controller, animated: true)
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.62) {
            controller.activateBrowserSearchController()
        }
    }

    private func updateGridSort(_ method: PathsSortMethods) {
        if sortMethod == method {
            _ = SortOrder.toggleUserPreferred()
        } else {
            sortMethod = method
        }
        browserHeader?.updateSortState(method: sortMethod, order: .userPreferred)
        reloadEntries()
    }

    private func pasteIntoGridDirectory() {
        let sourceURLs = UIPasteboard.general.probableURLs
        guard !sourceURLs.isEmpty else {
            errorAlert(nil, title: SantanderL10n.t("No path to paste."))
            return
        }
        let destinationURL = directoryPath.url
        DispatchQueue.global(qos: .userInitiated).async { [weak self] in
            do {
                try FSOperation.perform(.copyItem(items: sourceURLs, resultPath: destinationURL), rootHelperConf: RootConf.shared)
                DispatchQueue.main.async { [weak self] in self?.reloadEntries() }
            } catch {
                DispatchQueue.main.async { [weak self] in
                    self?.errorAlert(error, title: SantanderL10n.t("Failed to copy item to current directory."))
                }
            }
        }
    }

    private func showGridNewItemOptions() {
        let actions = [
            SantanderActionSheetItem(title: SantanderL10n.t("File"), image: SantanderIconLibrary.shared.interfaceIcon(for: "doc.badge.plus")) { [weak self] in
                guard let self else { return }
                self.presentAlertAndCreate(type: .file, forURL: self.directoryPath.url)
            },
            SantanderActionSheetItem(title: SantanderL10n.t("Folder"), image: SantanderIconLibrary.shared.interfaceIcon(for: "folder.badge.plus")) { [weak self] in
                guard let self else { return }
                self.presentAlertAndCreate(type: .directory, forURL: self.directoryPath.url)
            },
            SantanderActionSheetItem(title: SantanderL10n.t("Cancel"), style: .cancel)
        ]
        presentSantanderActionSheet(title: SantanderL10n.t("New.."), actions: actions)
    }

    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int { entries.count }

    func collectionView(_ collectionView: UICollectionView, willDisplay cell: UICollectionViewCell, forItemAt indexPath: IndexPath) {
        guard !UIAccessibility.isReduceMotionEnabled, entries.indices.contains(indexPath.item) else { return }
        let key = entries[indexPath.item].url.standardizedFileURL.path
        guard animatedGridPaths.insert(key).inserted else { return }
        cell.alpha = 0
        cell.transform = CGAffineTransform(translationX: 0, y: 7)
        UIView.animate(
            withDuration: 0.32,
            delay: 0,
            options: [.beginFromCurrentState, .curveEaseOut, .allowUserInteraction]
        ) {
            cell.alpha = 1
            cell.transform = .identity
        }
    }

    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let dequeued = collectionView.dequeueReusableCell(withReuseIdentifier: SantanderGridCell.reuseIdentifier, for: indexPath)
        guard let cell = dequeued as? SantanderGridCell,
              entries.indices.contains(indexPath.item) else { return dequeued }
        cell.configure(path: entries[indexPath.item])
        if UserPreferences.showFileMetadata {
            SantanderFileMetadataCache.request(for: entries[indexPath.item])
        }
        return cell
    }

    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        guard entries.indices.contains(indexPath.item) else { return }
        collectionView.deselectItem(at: indexPath, animated: true)
        let item = entries[indexPath.item]
        if item.isDirectory {
            navigationController?.pushViewController(SantanderGridViewController(path: item), animated: true)
        } else {
            openFile(item)
        }
    }

    func collectionView(_ collectionView: UICollectionView, contextMenuConfigurationForItemAt indexPath: IndexPath, point: CGPoint) -> UIContextMenuConfiguration? {
        guard entries.indices.contains(indexPath.item) else { return nil }
        let item = entries[indexPath.item]
        return UIContextMenuConfiguration(identifier: item.url.standardizedFileURL.path as NSString, previewProvider: nil) { [weak self] _ in
            guard let self else { return nil }
            let open = UIAction(title: item.isDirectory ? "打开文件夹" : "打开", image: item.displayImage) { [weak self] _ in
                guard let self else { return }
                if item.isDirectory {
                    self.navigationController?.pushViewController(SantanderGridViewController(path: item), animated: true)
                } else {
                    self.openFile(item)
                }
            }
            let copyPath = UIAction(title: "复制路径", image: SantanderIconLibrary.shared.interfaceIcon(for: "link")) { _ in UIPasteboard.general.string = item.path }
            let share = UIAction(title: "分享", image: SantanderIconLibrary.shared.interfaceIcon(for: "square.and.arrow.up")) { [weak self] _ in self?.presentActivityVC(forItems: [item.url]) }
            let info = UIAction(title: "属性", image: SantanderIconLibrary.shared.interfaceIcon(for: "info.circle")) { [weak self] _ in
                guard let self else { return }
                self.present(UINavigationController(rootViewController: PathInformationTableViewController(style: .insetGrouped, path: item)), animated: true)
            }
            let more = UIAction(title: "更多操作…", image: SantanderIconLibrary.shared.interfaceIcon(for: "ellipsis.circle")) { [weak self] _ in self?.presentGridActions(for: item) }
            var children: [UIMenuElement] = [open, copyPath]
            if !item.isDirectory {
                let openWith = UIAction(title: "打开方式…", image: SantanderIconLibrary.shared.interfaceIcon(for: "square.grid.2x2")) { [weak self] _ in self?.presentOpenWithOptions(forPath: item) }
                children.append(openWith)
            }
            children.append(contentsOf: [share, info, more])
            return UIMenu(title: item.lastPathComponent, children: children)
        }
    }

    private func presentGridActions(for item: Path) {
        var actions: [SantanderActionSheetItem] = [
            SantanderActionSheetItem(title: SantanderL10n.t("Open"), image: item.displayImage) { [weak self] in
                guard let self else { return }
                if item.isDirectory { self.navigationController?.pushViewController(SantanderGridViewController(path: item), animated: true) }
                else { self.openFile(item) }
            },
            SantanderActionSheetItem(title: "复制", image: SantanderIconLibrary.shared.interfaceIcon(for: "doc.on.doc")) { UIPasteboard.general.urls = [item.url] },
            SantanderActionSheetItem(title: SantanderL10n.t("Copy path"), image: SantanderIconLibrary.shared.interfaceIcon(for: "doc.on.doc")) { UIPasteboard.general.string = item.path },
            SantanderActionSheetItem(title: SantanderL10n.t("Move to.."), image: SantanderIconLibrary.shared.interfaceIcon(for: "arrow.right")) { [weak self] in
                guard let self else { return }
                self.present(UINavigationController(rootViewController: PathOperationViewController(paths: [item.url], operationType: .move)), animated: true)
            },
            SantanderActionSheetItem(title: SantanderL10n.t("Copy to.."), image: SantanderIconLibrary.shared.interfaceIcon(for: "doc.on.doc")) { [weak self] in
                guard let self else { return }
                self.present(UINavigationController(rootViewController: PathOperationViewController(paths: [item.url], operationType: .copy)), animated: true)
            },
            SantanderActionSheetItem(title: SantanderL10n.t("Rename"), image: SantanderIconLibrary.shared.interfaceIcon(for: "pencil")) { [weak self] in self?.rename(item) },
            SantanderActionSheetItem(title: SantanderL10n.t("Delete"), image: SantanderIconLibrary.shared.interfaceIcon(for: "trash"), style: .destructive) { [weak self] in self?.delete(item) },
            SantanderActionSheetItem(title: SantanderL10n.t("Share"), image: SantanderIconLibrary.shared.interfaceIcon(for: "square.and.arrow.up")) { [weak self] in self?.presentActivityVC(forItems: [item.url]) },
            SantanderActionSheetItem(title: SantanderL10n.t("Info"), image: SantanderIconLibrary.shared.interfaceIcon(for: "info.circle")) { [weak self] in
                guard let self else { return }
                self.present(UINavigationController(rootViewController: PathInformationTableViewController(style: .insetGrouped, path: item)), animated: true)
            },
            SantanderActionSheetItem(title: SantanderL10n.t("Cancel"), style: .cancel)
        ]
        if !item.isDirectory {
            actions.insert(SantanderActionSheetItem(title: SantanderL10n.t("Open in.."), image: SantanderIconLibrary.shared.interfaceIcon(for: "square.grid.2x2")) { [weak self] in
                self?.presentOpenWithOptions(forPath: item)
            }, at: 1)
        }
        presentSantanderActionSheet(title: item.lastPathComponent, message: item.path, actions: actions)
    }

    private func openFile(_ path: Path) {
        if ["gz", "bz2"].contains(path.pathExtension.lowercased()) {
            presentSantanderActionSheet(title: SantanderL10n.t("Decompress"), message: path.lastPathComponent, actions: [
                SantanderActionSheetItem(title: SantanderL10n.t("Decompress"), image: SantanderIconLibrary.shared.interfaceIcon(for: "archivebox")) { [weak self] in
                    guard let self else { return }
                    DispatchQueue.global(qos: .userInitiated).async {
                        do { try Compression.shared.extract(path: path.url, to: path.url.deletingLastPathComponent()) }
                        catch { DispatchQueue.main.async { self.errorAlert(error, title: SantanderL10n.t("Unable to decompress")) } }
                        DispatchQueue.main.async { self.reloadEntries() }
                    }
                },
                SantanderActionSheetItem(title: SantanderL10n.t("Cancel"), style: .cancel)
            ])
            return
        }
        FileEditor.preferredAsync(forURL: path) { [weak self] editor in
            guard let self else { return }
            guard let editor else {
                self.navigationController?.pushViewController(SantanderFilePreviewController(fileURL: path.url), animated: true)
                return
            }
            if UIDevice.isiPad, let split = self.splitViewController, #available(iOS 14.0, *), split.style == .tripleColumn, !split.isCollapsed {
                let nav = split.viewController(for: .secondary) as? UINavigationController ?? UINavigationController(rootViewController: UIViewController())
                if split.viewController(for: .secondary) == nil { split.setViewController(nav, for: .secondary) }
                let root = nav.viewControllers.first ?? UIViewController()
                nav.setViewControllers([root, editor.viewController], animated: true)
                split.show(.secondary)
            } else {
                self.navigationController?.pushViewController(editor.viewController, animated: true)
            }
        }
    }

    private func rename(_ path: Path) {
        let alert = UIAlertController(title: SantanderL10n.t("Rename"), message: path.path, preferredStyle: .alert)
        alert.addTextField { $0.text = path.lastPathComponent; $0.autocapitalizationType = .none }
        alert.addAction(.cancel())
        alert.addAction(UIAlertAction(title: SantanderL10n.t("Rename"), style: .default) { [weak self, weak alert] _ in
            guard let self, let name = alert?.textFields?.first?.text?.trimmingCharacters(in: .whitespacesAndNewlines), !name.isEmpty else { return }
            let target = path.url.deletingLastPathComponent().appendingPathComponent(name)
            DispatchQueue.global(qos: .userInitiated).async {
                do { try FSOperation.perform(.rename(item: path.url, newPath: target), rootHelperConf: RootConf.shared) }
                catch { DispatchQueue.main.async { self.errorAlert(error, title: SantanderL10n.t("Unable to rename item")) }; return }
                DispatchQueue.main.async { self.reloadEntries() }
            }
        })
        present(alert, animated: true)
    }

    private func delete(_ path: Path) {
        presentSantanderActionSheet(title: SantanderL10n.t("Delete"), message: path.path, actions: [
            SantanderActionSheetItem(title: SantanderL10n.t("Delete"), image: SantanderIconLibrary.shared.interfaceIcon(for: "trash"), style: .destructive) { [weak self] in
                guard let self else { return }
                DispatchQueue.global(qos: .userInitiated).async {
                    do { try FSOperation.perform(.removeItems(items: [path.url]), rootHelperConf: RootConf.shared) }
                    catch { DispatchQueue.main.async { self.errorAlert(error, title: SantanderL10n.t("Unable to delete item")) }; return }
                    DispatchQueue.main.async { self.reloadEntries() }
                }
            },
            SantanderActionSheetItem(title: SantanderL10n.t("Cancel"), style: .cancel)
        ])
    }

    @objc private func showSortOptions() {
        var actions = PathsSortMethods.allCases.map { type in
            SantanderActionSheetItem(title: type.description, isSelected: type == sortMethod) { [weak self] in
                self?.sortMethod = type
                UserDefaults.standard.set(type.rawValue, forKey: "SubPathsSortMode")
                self?.browserHeader?.updateSortState(method: type, order: .userPreferred)
                self?.reloadEntries()
            }
        }
        actions.append(SantanderActionSheetItem(title: SantanderL10n.t("Reverse Order"), image: SantanderIconLibrary.shared.interfaceIcon(for: "arrow.up.arrow.down")) { [weak self] in
            let nextOrder = SortOrder.toggleUserPreferred()
            self?.browserHeader?.updateSortState(method: self?.sortMethod ?? .alphabetically, order: nextOrder)
            self?.reloadEntries()
        })
        actions.append(SantanderActionSheetItem(title: SantanderL10n.t("Cancel"), style: .cancel))
        presentSantanderActionSheet(title: SantanderL10n.t("Sort by.."), actions: actions)
    }
}

class PathListViewController: UITableViewController, PathTransitioning, UITableViewDataSourcePrefetching, UIGestureRecognizerDelegate {

    var unfilteredContents: [Path]

    var filteredSearchContents: [Path] = []

    private var directoryLoadGeneration = UUID()
    private var directoryChangeGeneration = UUID()
    private var sortGeneration = UUID()
    private let sortingQueue = DispatchQueue(label: "com.Antoine.Santander.file-sorting", qos: .userInitiated)
    private var directoryChangeWorkItem: DispatchWorkItem?
    private var didStartInitialDirectoryLoad = false
    private var isDirectoryContentsReady = false

    var selectedItems: [Path] = []

    var isSearching: Bool = false

    var contents: [Path] {
        get {
            return filteredSearchContents.isEmpty && !self.isSearching ? unfilteredContents : filteredSearchContents
        }
    }

    var sortMethod: PathsSortMethods = .userPrefered ?? .alphabetically {
        didSet {
            UserDefaults.standard.set(sortMethod.rawValue, forKey: "SubPathsSortMode")
            sortContents()
        }
    }

    var currentPath: Path? = nil

    var displayingSearchSuggestions: Bool = false

    var directoryMonitor: DirectoryMonitor?

    var audioPlayerController: AudioPlayerViewController?

    private var emptyStateView: SantanderEmptyStateView?
    private var loadingSurface: UIView?
    var defaultSearchScopeIndex: Int = 0
    fileprivate var browserSearchController: UISearchController?
    private var filzaBrowserHeader: SantanderFilzaBrowserHeader?
    private var filzaBottomBar: UIView?
    private weak var filzaBottomBarHostView: UIView?
    private var isSearchChromeSuppressed = false
    private var filzaBottomBarHeightConstraint: NSLayoutConstraint?
    private var filzaDirectoryStatusView: SantanderDirectoryStatusView?
    private var directoryStatusGeneration = UUID()
    private let filzaBottomBarHeight: CGFloat = 72

    var displayHiddenFiles: Bool = UserPreferences.displayHiddenFiles {
        didSet {
            reloadTableData()

            UserPreferences.displayHiddenFiles = self.displayHiddenFiles
        }
    }

    var containsAppUUIDs: Bool?

    var searchItem: DispatchWorkItem?
    private var searchGeneration = UUID()
    private var sweptSelectionIndexPaths = Set<IndexPath>()

    typealias SnapshotType = NSDiffableDataSourceSnapshot<Int, SubPathsRowItem>
    typealias DataSourceType = UITableViewDiffableDataSource<Int, SubPathsRowItem>
    lazy var dataSource = DataSourceType(tableView: self.tableView) { [weak self] tableView, indexPath, itemIdentifier in
        guard let self else { return UITableViewCell() }
        switch itemIdentifier {
        case .path(let url):
            return self.pathCellRow(forURL: url, displayFullPathAsSubtitle: self.isSearching)
        case .searchSuggestion(let suggestion):
            return self.searchSuggestionCellRow(suggestion: suggestion)
        }
    }

    init(style: UITableView.Style = .userPreferred, path: Path) {
        self.unfilteredContents = []
        self.currentPath = path

        super.init(style: style)
        self.title = path.lastPathComponent
    }

    init(style: UITableView.Style = .userPreferred, contents: [Path], title: String) {
        self.unfilteredContents = self.sortMethod.sorting(URLs: contents, sortOrder: .userPreferred)

        super.init(style: style)
        self.title = title
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        NotificationCenter.default.addObserver(self, selector: #selector(pathThumbnailDidLoad(_:)), name: PathImageCache.didLoadNotification, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(pathMetadataDidLoad(_:)), name: SantanderFileMetadataCache.didLoadNotification, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(listAppearanceDidChange), name: Notification.Name("SantanderListAppearanceDidChange"), object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(defaultHiddenFilesDidChange), name: Notification.Name("SantanderDisplayHiddenFilesDidChange"), object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(defaultSortDidChange), name: Notification.Name("SantanderDefaultSortDidChange"), object: nil)
        applySantanderUI()
        tableView.rowHeight = UserPreferences.listDensity.rowHeight
        tableView.estimatedRowHeight = UserPreferences.listDensity.rowHeight
        tableView.separatorInset = UIEdgeInsets(top: 0, left: 56, bottom: 0, right: 0)
        tableView.separatorInsetReference = .fromCellEdges
        tableView.tableFooterView = UIView(frame: .zero)

        if let currentPath {
            if UIDevice.isiPad {
                let breadcrumb = SantanderBreadcrumbView(path: currentPath)
                breadcrumb.frame.size = CGSize(width: max(0, min(view.bounds.width - 120, 700)), height: 32)
                breadcrumb.onSelect = { [weak self] destination in self?.goToPath(path: destination) }
                navigationItem.titleView = breadcrumb
            } else {
                let titleButton = UIButton(type: .system)
                titleButton.setTitle(currentPath.lastPathComponent.isEmpty ? "/" : currentPath.lastPathComponent, for: .normal)
                titleButton.titleLabel?.font = .preferredFont(forTextStyle: .headline)
                titleButton.setTitleColor(.label, for: .normal)
                titleButton.addTarget(self, action: #selector(showPathComponentsPicker), for: .touchUpInside)
                titleButton.accessibilityLabel = currentPath.path
                navigationItem.titleView = titleButton
            }
        }

        tableView.register(SantanderFileListCell.self, forCellReuseIdentifier: SantanderFileListCell.reuseIdentifier)
        setRightBarButton()

        self.loadingSurface = nil

        showPaths(animatingDifferences: false)
        if let currentPath = self.currentPath {
            loadDirectoryContentsInBackground(for: currentPath)
        }

        self.navigationController?.navigationBar.prefersLargeTitles = UIDevice.isiPad ? UserPreferences.useLargeNavigationTitles : false
        if !UIDevice.isiPad { navigationItem.largeTitleDisplayMode = .never }
        let searchController = UISearchController(searchResultsController: nil)
        searchController.searchBar.delegate = self
        searchController.obscuresBackgroundDuringPresentation = false
        searchController.searchResultsUpdater = self
        searchController.delegate = self
        self.tableView.keyboardDismissMode = .onDrag
        self.navigationItem.hidesSearchBarWhenScrolling = UserPreferences.alwaysShowSearchBar
        if let currentPath = currentPath {
            searchController.searchBar.scopeButtonTitles = [currentPath.lastPathComponent, SantanderL10n.t("Subdirectories"), SantanderL10n.t("Full filesystem")]
            setupRefreshControl(forPath: currentPath)

            let pathForFlags = currentPath
            DispatchQueue.global(qos: .utility).async { [weak self] in
                let contains = pathForFlags.containsAppUUIDSubpaths
                DispatchQueue.main.async { [weak self] in
                    guard let self, self.currentPath == pathForFlags else { return }
                    self.containsAppUUIDs = contains
                }
            }
        }
        self.browserSearchController = searchController
        if UserPreferences.alwaysShowSearchBar {
            self.navigationItem.searchController = searchController
        } else {
            self.navigationItem.searchController = nil
        }
        decorateSearchScopes(searchController.searchBar)
        searchController.searchBar.selectedScopeButtonIndex = min(defaultSearchScopeIndex, max(0, (searchController.searchBar.scopeButtonTitles?.count ?? 1) - 1))
#if compiler(>=5.7)
        if #available(iOS 16.0, *), UIDevice.isiPad {
            self.navigationItem.style = .browser
            self.navigationItem.renameDelegate = self
        }
#endif

        tableView.dragInteractionEnabled = true
        tableView.dropDelegate = self
        tableView.dragDelegate = self
        tableView.dataSource = self.dataSource
        tableView.prefetchDataSource = self
        tableView.allowsMultipleSelectionDuringEditing = true
        let multiSelectPan = UIPanGestureRecognizer(target: self, action: #selector(handleMultiSelectPan(_:)))
        multiSelectPan.minimumNumberOfTouches = 2
        multiSelectPan.maximumNumberOfTouches = 2
        multiSelectPan.delegate = self
        multiSelectPan.cancelsTouchesInView = false
        tableView.addGestureRecognizer(multiSelectPan)

        setupPermissionDeniedLabelIfNeeded()
        if currentPath != nil {
            installFilzaBrowserHeader()
            if self is SantanderGlobalSearchTabViewController {
                setSearchChromeSuppressed(true)
                filzaBrowserHeader?.isHidden = true
                tableView.tableHeaderView = UIView(frame: CGRect(x: 0, y: 0, width: tableView.bounds.width, height: 0))
                if let browserSearchController {
                    navigationItem.searchController = browserSearchController
                    navigationItem.hidesSearchBarWhenScrolling = false
                }
                showEmptySearchResults()
            }
        }
    }

    private func installFilzaBrowserHeader() {
        let header = SantanderFilzaBrowserHeader(frame: CGRect(x: 0, y: 0, width: tableView.bounds.width, height: 44))
        header.onSearch = { [weak self] in self?.activateBrowserSearchController() }
        header.onSort = { [weak self] method in
            guard let self else { return }
            if self.sortMethod == method {
                let nextOrder = SortOrder.toggleUserPreferred()
                self.filzaBrowserHeader?.updateSortState(method: self.sortMethod, order: nextOrder)
                self.sortContents()
            } else {
                self.sortMethod = method
                self.filzaBrowserHeader?.updateSortState(method: method, order: .userPreferred)
            }
        }
        header.onGrid = { [weak self] in
            guard let self, let currentPath = self.currentPath else { return }
            self.navigationController?.pushViewController(SantanderGridViewController(path: currentPath), animated: true)
        }
        header.updateSortState(method: sortMethod, order: .userPreferred)
        filzaBrowserHeader = header
        tableView.tableHeaderView = header
    }

    private func installFilzaBottomBar() {
        // The toolbar is a fixed chrome overlay on this navigation controller,
        // never a child of UITableView/UIScrollView (which treats subviews as content).
        guard let hostView = navigationController?.view else { return }
        if let existing = filzaBottomBar, existing.superview === hostView {
            existing.isHidden = false
            hostView.bringSubviewToFront(existing)
            updateFilzaBottomBarInsets()
            return
        }
        filzaBottomBar?.removeFromSuperview()

        let bar = UIView()
        bar.translatesAutoresizingMaskIntoConstraints = false
        bar.backgroundColor = .systemBackground
        bar.isAccessibilityElement = false

        let divider = UIView()
        divider.backgroundColor = .separator
        divider.translatesAutoresizingMaskIntoConstraints = false
        bar.addSubview(divider)

        let statusView = SantanderDirectoryStatusView()
        filzaDirectoryStatusView = statusView
        bar.addSubview(statusView)

        let stack = UIStackView()
        stack.axis = .horizontal
        stack.alignment = .fill
        stack.distribution = .fillEqually
        stack.translatesAutoresizingMaskIntoConstraints = false
        bar.addSubview(stack)

        let recentButton = makeFilzaBottomButton(assetName: "recents", title: "最近") { [weak self] in
            guard let self else { return }
            let controller = UINavigationController(rootViewController: SantanderRecentPathsViewController(style: .plain))
            self.present(controller, animated: true)
        }
        let favoritesButton = makeFilzaBottomButton(assetName: "favorites", title: "收藏") { [weak self] in
            guard let self else { return }
            let controller = UINavigationController(rootViewController: SantanderFavoritesViewController(style: .plain))
            self.present(controller, animated: true)
        }
        let settingsButton = makeFilzaBottomButton(assetName: "setting", title: "设置") { [weak self] in
            guard let self else { return }
            let controller = UINavigationController(rootViewController: SettingsTableViewController(style: .insetGrouped))
            self.present(controller, animated: true)
        }
        let tabsButton = makeFilzaBottomButton(assetName: "tab", title: "标签页") { [weak self] in
            self?.showBrowserTabs()
        }
        [recentButton, favoritesButton, settingsButton, tabsButton].forEach { stack.addArrangedSubview($0) }

        hostView.addSubview(bar)
        let barHeight = bar.heightAnchor.constraint(equalToConstant: filzaBottomBarHeight + hostView.safeAreaInsets.bottom)
        NSLayoutConstraint.activate([
            bar.leadingAnchor.constraint(equalTo: hostView.leadingAnchor),
            bar.trailingAnchor.constraint(equalTo: hostView.trailingAnchor),
            bar.bottomAnchor.constraint(equalTo: hostView.bottomAnchor),
            barHeight,
            divider.leadingAnchor.constraint(equalTo: bar.leadingAnchor),
            divider.trailingAnchor.constraint(equalTo: bar.trailingAnchor),
            divider.topAnchor.constraint(equalTo: bar.topAnchor),
            divider.heightAnchor.constraint(equalToConstant: 0.5),
            statusView.leadingAnchor.constraint(equalTo: bar.leadingAnchor),
            statusView.trailingAnchor.constraint(equalTo: bar.trailingAnchor),
            statusView.topAnchor.constraint(equalTo: divider.bottomAnchor),
            statusView.heightAnchor.constraint(equalToConstant: 24),
            stack.leadingAnchor.constraint(equalTo: bar.leadingAnchor),
            stack.trailingAnchor.constraint(equalTo: bar.trailingAnchor),
            stack.topAnchor.constraint(equalTo: statusView.bottomAnchor),
            stack.heightAnchor.constraint(equalToConstant: 48)
        ])

        filzaBottomBarHeightConstraint = barHeight
        filzaBottomBarHostView = hostView
        filzaBottomBar = bar
        updateFilzaBottomBarInsets()
        hostView.bringSubviewToFront(bar)
    }

    private func updateFilzaBottomBarInsets() {
        guard !isEditing else { return }
        let desiredInset = filzaBottomBar == nil ? 0 : filzaBottomBarHeight
        if abs(tableView.contentInset.bottom - desiredInset) > 0.5 {
            tableView.contentInset.bottom = desiredInset
        }
        if abs(tableView.verticalScrollIndicatorInsets.bottom - desiredInset) > 0.5 {
            tableView.verticalScrollIndicatorInsets.bottom = desiredInset
        }
    }

    private func makeFilzaBottomButton(assetName: String, title: String, action: @escaping () -> Void) -> UIButton {
        let button = SantanderPressButton(type: .system)
        button.setImage(SantanderIconLibrary.shared.uiIcon(named: assetName), for: .normal)
        button.imageView?.contentMode = .scaleAspectFit
        button.adjustsImageWhenHighlighted = false
        button.accessibilityLabel = title
        button.addAction(UIAction { _ in action() }, for: .touchUpInside)
        return button
    }

    fileprivate func activateBrowserSearchController() {
        guard let searchController = browserSearchController else { return }
        setSearchChromeSuppressed(true)
        if navigationItem.searchController !== searchController {
            navigationItem.searchController = searchController
        }
        definesPresentationContext = true
        navigationItem.hidesSearchBarWhenScrolling = false
        filzaBrowserHeader?.isHidden = true
        tableView.tableHeaderView = UIView(frame: CGRect(x: 0, y: 0, width: tableView.bounds.width, height: 0))
        searchController.isActive = true
        DispatchQueue.main.async { [weak searchController] in
            searchController?.searchBar.becomeFirstResponder()
        }
    }

    fileprivate func restoreBrowserChromeAfterSearch() {
        setSearchChromeSuppressed(false)
        guard !(self is SantanderGlobalSearchTabViewController) else { return }
        if !UserPreferences.alwaysShowSearchBar {
            navigationItem.searchController = nil
        }
        navigationItem.hidesSearchBarWhenScrolling = UserPreferences.alwaysShowSearchBar
        if let header = filzaBrowserHeader {
            header.isHidden = false
            tableView.tableHeaderView = header
        }
    }

    private func setSearchChromeSuppressed(_ suppressed: Bool) {
        isSearchChromeSuppressed = suppressed
        if suppressed {
            filzaBrowserHeader?.isHidden = true
            tableView.tableHeaderView = UIView(frame: CGRect(x: 0, y: 0, width: tableView.bounds.width, height: 0))
            navigationItem.rightBarButtonItems = nil
        } else {
            if !isEditing {
                setRightBarButton()
            }
        }
    }

    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        let bottomSafeArea = filzaBottomBarHostView?.safeAreaInsets.bottom ?? view.safeAreaInsets.bottom
        let resolvedBarHeight = filzaBottomBarHeight + bottomSafeArea
        if let heightConstraint = filzaBottomBarHeightConstraint,
           abs(heightConstraint.constant - resolvedBarHeight) > 0.5 {
            heightConstraint.constant = resolvedBarHeight
        }
        updateFilzaBottomBarInsets()
        if let header = filzaBrowserHeader, abs(header.frame.width - tableView.bounds.width) > 0.5 {
            header.frame = CGRect(x: 0, y: 0, width: tableView.bounds.width, height: 44)
            tableView.tableHeaderView = header
        }
    }

    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)

        // Keep browser chrome setup and directory monitoring in one lifecycle
        // override. Multiple overrides in the same class are a Swift compile error.
        if currentPath != nil, !isEditing {
            installFilzaBottomBar()
            if let bar = filzaBottomBar {
                bar.isHidden = false
                filzaBottomBarHostView?.bringSubviewToFront(bar)
            }
            updateFilzaDirectoryStatus(for: unfilteredContents)
        }

        if let currentPath {
            if directoryMonitor == nil {
                directoryMonitor = DirectoryMonitor(path: currentPath)
                directoryMonitor?.delegate = self
            }

            directoryMonitor?.startMonitoring()
            UserPreferences.lastOpenedPath = currentPath.path
            if let navigationController {
                SantanderBrowserTabs.shared.updateCurrent(path: currentPath.path, stack: navigationController.viewControllers)
            }
        }
    }

    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
        // A controller can remain retained in a browser-tab navigation stack after
        // it stops being visible. Always detach its nav-controller overlay so
        // hidden toolbars do not accumulate behind the next tab or modal screen.
        filzaBottomBar?.removeFromSuperview()
        filzaBottomBar = nil
        filzaBottomBarHostView = nil
        filzaBottomBarHeightConstraint = nil
        filzaDirectoryStatusView = nil
    }

    deinit {
        directoryMonitor?.stopMonitoring()
        filzaBottomBar?.removeFromSuperview()
        NotificationCenter.default.removeObserver(self)
    }

    @objc private func listAppearanceDidChange() {
        tableView.rowHeight = UserPreferences.listDensity.rowHeight
        tableView.estimatedRowHeight = UserPreferences.listDensity.rowHeight
        tableView.separatorInset = UIEdgeInsets(top: 0, left: 56, bottom: 0, right: 0)
        tableView.reloadData()
    }

    @objc private func defaultHiddenFilesDidChange() {
        if displayHiddenFiles != UserPreferences.displayHiddenFiles {
            displayHiddenFiles = UserPreferences.displayHiddenFiles
            setRightBarButton()
        }
    }

    @objc private func defaultSortDidChange() {
        sortMethod = PathsSortMethods.userPrefered ?? .alphabetically
        filzaBrowserHeader?.updateSortState(method: sortMethod, order: .userPreferred)
    }

    @objc private func pathMetadataDidLoad(_ note: Notification) {
        guard UserPreferences.showFileMetadata,
              let path = note.object as? String else { return }
        let rows = tableView.indexPathsForVisibleRows?.filter { indexPath in
            guard let item = dataSource.itemIdentifier(for: indexPath), case .path(let itemPath) = item else { return false }
            return itemPath.url.standardizedFileURL.path == path
        } ?? []
        guard !rows.isEmpty else { return }
        UIView.performWithoutAnimation { tableView.reloadRows(at: rows, with: .none) }
    }

    @objc private func pathThumbnailDidLoad(_ note: Notification) {
        guard let url = note.object as? URL, !(tableView.indexPathsForVisibleRows?.isEmpty ?? true) else { return }
        let rows = tableView.indexPathsForVisibleRows?.filter { indexPath in
            guard let item = dataSource.itemIdentifier(for: indexPath), case .path(let itemPath) = item else { return false }
            return itemPath.url.standardizedFileURL.path == url.standardizedFileURL.path
        } ?? []
        guard !rows.isEmpty else { return }
        UIView.performWithoutAnimation { tableView.reloadRows(at: rows, with: .none) }
    }


    override var keyCommands: [UIKeyCommand]? {
        return [
            UIKeyCommand(title: SantanderL10n.t("Scroll Up"), action: #selector(scrollUpOrDown(sender:)), input: UIKeyCommand.inputUpArrow, modifierFlags: .command),
            UIKeyCommand(title: SantanderL10n.t("Scroll Down"), action: #selector(scrollUpOrDown(sender:)), input: UIKeyCommand.inputDownArrow, modifierFlags: .command)
        ]
    }

    @objc
    func scrollUpOrDown(sender: UIKeyCommand) {
        switch sender.input {
        case UIKeyCommand.inputDownArrow:
            let snapshot = dataSource.snapshot()
            guard snapshot.numberOfItems > 0, snapshot.numberOfSections > 0 else { return }
            let indexPathToSrcollTo = IndexPath(row: snapshot.numberOfItems - 1, section: snapshot.numberOfSections - 1)
            tableView.scrollToRow(at: indexPathToSrcollTo, at: .bottom, animated: true)
        case UIKeyCommand.inputUpArrow:
            tableView.scrollToRow(at: IndexPath(row: 0, section: 0), at: .top, animated: true)
        default: break
        }
    }

    private func loadDirectoryContentsInBackground(for path: Path, forceReload: Bool = false) {
        guard path.isDirectory || forceReload else { return }

        if didStartInitialDirectoryLoad && !forceReload && isDirectoryContentsReady {
            return
        }

        didStartInitialDirectoryLoad = true
        isDirectoryContentsReady = false
        directoryLoadGeneration = UUID()
        let generation = directoryLoadGeneration
        let sortMethod = self.sortMethod
        let sortOrder = SortOrder.userPreferred
        let currentControllerPath = path

        DispatchQueue.global(qos: .userInitiated).async { [weak self] in
            guard let self else { return }

            let loadedContents = sortMethod.sorting(
                URLs: path.contents,
                sortOrder: sortOrder
            )

            DispatchQueue.main.async {
                guard self.currentPath == currentControllerPath,
                      self.directoryLoadGeneration == generation else {
                    return
                }

                self.applyDirectoryContents(loadedContents, animatingDifferences: loadedContents.count <= 120)
                self.isDirectoryContentsReady = true

                if let surface = self.loadingSurface {
                    self.loadingSurface = nil
                    UIView.animate(withDuration: UIAccessibility.isReduceMotionEnabled ? 0 : 0.30, delay: 0, options: [.beginFromCurrentState, .curveEaseInOut], animations: {
                        surface.alpha = 0
                    }, completion: { _ in
                        surface.removeFromSuperview()
                    })
                }

                self.setupPermissionDeniedLabelIfNeeded()

                if let pendingPath = self.pendingSelectionPath {
                    self.pendingSelectionPath = nil
                    self.selectLoadedPath(pendingPath)
                }

                if let currentPath = self.currentPath, currentPath == currentControllerPath {
                    self.setupRefreshControl(forPath: currentPath)
                }

            }
        }
    }

    func setupRefreshControl(forPath path: Path) {
        let refreshControl = UIRefreshControl()
        let refreshAction = UIAction { [weak self, weak refreshControl] _ in
            guard let self else { return }

            let requestedPath = path
            let sortMethod = self.sortMethod
            DispatchQueue.global(qos: .userInitiated).async {
                let refreshedContents = sortMethod.sorting(
                    URLs: requestedPath.contents,
                    sortOrder: SortOrder.userPreferred
                )

                DispatchQueue.main.async {
                    guard self.currentPath == requestedPath else {
                        refreshControl?.endRefreshing()
                        return
                    }

                    self.applyDirectoryContents(refreshedContents, animatingDifferences: false)
                    self.isDirectoryContentsReady = true
                    if let surface = self.loadingSurface {
                        self.loadingSurface = nil
                        surface.removeFromSuperview()
                    }
                    self.setupPermissionDeniedLabelIfNeeded()
                    if let pendingPath = self.pendingSelectionPath {
                        self.pendingSelectionPath = nil
                        self.selectLoadedPath(pendingPath)
                    }
                    refreshControl?.endRefreshing()
                }
            }
        }

        refreshControl.addAction(refreshAction, for: .primaryActionTriggered)

        tableView.refreshControl = refreshControl
    }

    func showPaths(animatingDifferences: Bool = false, reconfigureURLs: Set<String> = []) {
        displayingSearchSuggestions = false
        var snapshot = SnapshotType()
        snapshot.appendSections([0])
        var seenIdentifiers = Set<SubPathsRowItem>()
        let items = SubPathsRowItem.fromPaths(contents).filter { seenIdentifiers.insert($0).inserted }
        snapshot.appendItems(items)

        let changedItems = items.filter { item in
            guard case .path(let path) = item else { return false }
            return reconfigureURLs.contains(path.url.standardizedFileURL.path)
        }
        if !changedItems.isEmpty {
            if #available(iOS 15.0, *) {
                snapshot.reconfigureItems(changedItems)
            } else {
                snapshot.reloadItems(changedItems)
            }
        }
        dataSource.apply(snapshot, animatingDifferences: animatingDifferences)
    }

    func switchToSearchSuggestions() {
        showEmptySearchResults()
    }

    func showEmptySearchResults() {
        displayingSearchSuggestions = false
        filteredSearchContents.removeAll(keepingCapacity: true)
        var snapshot = SnapshotType()
        snapshot.appendSections([0])
        dataSource.apply(snapshot, animatingDifferences: false)
        if let emptyStateView, tableView.backgroundView === emptyStateView {
            tableView.backgroundView = nil
        } else {
            emptyStateView?.removeFromSuperview()
        }
        emptyStateView = nil
    }

    func path(forIndexPath indexPath: IndexPath) -> Path? {
        guard let item = dataSource.itemIdentifier(for: indexPath),
              case .path(let path) = item else { return nil }
        return path
    }

    private var pendingSelectionPath: Path?

    func selectPathWhenLoaded(_ path: Path) {
        guard let currentPath = self.currentPath, currentPath.isDirectory else { return }

        if isDirectoryContentsReady {
            selectLoadedPath(path)
        } else {
            pendingSelectionPath = path
        }
    }

    private func selectLoadedPath(_ path: Path) {
        guard let index = contents.firstIndex(of: path) else { return }

        let indexPath = IndexPath(row: index, section: 0)
        tableView.scrollToRow(at: indexPath, at: .middle, animated: true)
        tableView.selectRow(at: indexPath, animated: true, scrollPosition: .middle)
    }


    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        // Fixed browser chrome is restored in viewDidAppear, after the navigation
        // transition has completed, to avoid covering the incoming controller.
    }

    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        // Every PathList controller owns one hidden overlay. The next pushed
        // controller installs its own; returning simply reveals the previous one.
        filzaBottomBar?.isHidden = true
        directoryStatusGeneration = UUID()

        directoryChangeGeneration = UUID()
        directoryChangeWorkItem?.cancel()
        directoryChangeWorkItem = nil
        directoryMonitor?.stopMonitoring()
    }

    override func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        guard displayingSearchSuggestions else { return nil }
        return section == 0 ? "试试以下筛选条件" : nil
    }

    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if self.isEditing {
            guard !displayingSearchSuggestions,
                  let item = dataSource.itemIdentifier(for: indexPath),
                  case .path(let selectedPath) = item else {
                tableView.deselectRow(at: indexPath, animated: false)
                return
            }
            if !selectedItems.contains(selectedPath) { selectedItems.append(selectedPath) }
            updateSelectedCountTitle()
            setupOrUpdateToolbar()
            setLeftBarSelectionButtonItem()
            return
        }

        if displayingSearchSuggestions {
            let searchTextField = self.navigationItem.searchController?.searchBar.searchTextField
            let tokensCount = searchTextField?.tokens.count

            if (indexPath.section, indexPath.row) == (0, 0) {
                let vc = TypesSelectionCollectionViewController { types in
                    if !types.isEmpty {
                        var searchSuggestion = SearchSuggestion.displaySearchSuggestions(for: indexPath, typesToCheck: types)
                        searchSuggestion.name = types.compactMap(\.localizedDescription).joined(separator: ", ")
                        searchTextField?.insertToken(searchSuggestion.searchToken, at: tokensCount ?? 0)
                    }
                }

                let navVC = UINavigationController(rootViewController: vc)

                self.present(navVC, animated: true)

            } else {
                searchTextField?.insertToken(SearchSuggestion.displaySearchSuggestions(for: indexPath).searchToken, at: tokensCount ?? 0)
            }

        } else {
            guard let selectedItem = path(forIndexPath: indexPath) else { return }
            goToPath(path: selectedItem)
            tableView.deselectRow(at: indexPath, animated: true)
        }
    }

    override func tableView(_ tableView: UITableView, didDeselectRowAt indexPath: IndexPath) {
        guard self.isEditing,
              !displayingSearchSuggestions,
              let item = dataSource.itemIdentifier(for: indexPath),
              case .path(let selected) = item else { return }

        selectedItems.removeAll { path in
            path == selected
        }

        updateSelectedCountTitle()
        setupOrUpdateToolbar()
        setLeftBarSelectionButtonItem()
    }

    override func tableView(_ tableView: UITableView, trailingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration? {

        guard !displayingSearchSuggestions else {
            return nil
        }

        guard let selectedItem = self.path(forIndexPath: indexPath) else { return nil }
        let deleteAction = UIContextualAction(style: .destructive, title: nil) { [weak self] _, _, completion in
            guard let self else { completion(false); return }
            self.deleteURL(selectedItem) { didSucceed in
                completion(didSucceed)
            }
        }

        deleteAction.image = SantanderIconLibrary.shared.interfaceIcon(for: "trash")

        let config = UISwipeActionsConfiguration(actions: [deleteAction])
        return config
    }


    @objc func showPathComponentsPicker() {
        guard let path = currentPath else { return }
        let actions = path.url.fullPathComponents().reversed().map { url in
            SantanderActionSheetItem(
                title: url.lastPathComponent.isEmpty ? "/" : url.lastPathComponent,
                subtitle: url.path,
                image: SantanderIconLibrary.shared.interfaceIcon(for: "folder"),
                isSelected: url.standardizedFileURL == path.url.standardizedFileURL
            ) { [weak self] in self?.goToPath(path: Path(url: url)) }
        }
        presentSantanderActionSheet(title: path.path, actions: actions + [SantanderActionSheetItem(title: SantanderL10n.t("Cancel"), style: .cancel)])
    }

    func decompressPath(path: Path) {
        let alertController = createAlertWithSpinner(title: SantanderL10n.t("Decompressing.."))
        present(alertController, animated: true)
        DispatchQueue.global(qos: .userInitiated).async {
            var caughtError: Error? = nil
            do {
                let destination = path.deletingLastPathComponent()
                try Compression.shared.extract(path: path.url, to: destination.url)
            } catch {
                caughtError = error
            }

            DispatchQueue.main.async {
                alertController.dismiss(animated: true)
                if let caughtError = caughtError {
                    self.errorAlert(caughtError, title: "无法解压文件 \(path.lastPathComponent)")
                }
            }
        }
    }

    func compressPaths(paths: [Path], destination: URL, format: Compression.FormatType) {
        let alertController = createAlertWithSpinner(title: SantanderL10n.t("Compressing.."), heightAnchorConstant: 120)
        present(alertController, animated: true)

        DispatchQueue.global(qos: .userInitiated).async {
            var caughtError: Error? = nil
            do {
                try Compression.shared.compress(paths: paths.map(\.url), outputPath: destination, format: format) { pathBeingProcessed in
                    DispatchQueue.main.async { alertController.message = "正在压缩：\(pathBeingProcessed.lastPathComponent)" }
                }
            } catch {
                caughtError = error
            }

            DispatchQueue.main.async {
                alertController.dismiss(animated: true)
                if let caughtError = caughtError {
                    self.errorAlert(caughtError, title: "无法压缩文件。")
                }
            }
        }
    }

    func presentCompressionOptions(paths: [Path], destination: @escaping (Compression.FormatType) -> Path) {
        let actions = Compression.FormatType.allCases.map { format in
            SantanderActionSheetItem(title: format.description, image: SantanderIconLibrary.shared.interfaceIcon(for: "archivebox")) { [weak self] in
                guard let self else { return }
                self.compressPaths(paths: paths, destination: destination(format).url, format: format)
            }
        }
        presentSantanderActionSheet(title: SantanderL10n.t("Compress"), actions: actions + [SantanderActionSheetItem(title: SantanderL10n.t("Cancel"), style: .cancel)])
    }

    private var santanderDetailSplitViewController: UISplitViewController? {
        guard UIDevice.isiPad, let split = splitViewController else { return nil }
        if #available(iOS 14.0, *), split.style == .tripleColumn, !split.isCollapsed {
            return split
        }
        return nil
    }

    @discardableResult
    private func showInDetailColumn(_ controller: UIViewController) -> Bool {
        guard let split = santanderDetailSplitViewController else { return false }
        let navigation: UINavigationController
        if let existing = split.viewController(for: .secondary) as? UINavigationController {
            navigation = existing
        } else {
            navigation = UINavigationController(rootViewController: SantanderDetailPlaceholderViewController())
            split.setViewController(navigation, for: .secondary)
        }
        let root = navigation.viewControllers.first ?? SantanderDetailPlaceholderViewController()
        navigation.setViewControllers([root, controller], animated: true)
        split.show(.secondary)
        return true
    }

    private func displayFileEditor(_ editor: FileEditor) {
        if showInDetailColumn(editor.viewController) { return }
        editor.display(senderVC: self)
    }

    func goToFile(path: Path) {
        if SantanderBinaryTools.isSQLite(path.url) {
            displayFileEditor(FileEditor(type: .sqlite, viewController: SQLiteEditorViewController(fileURL: path.url)))
            return
        }
        let archiveExtension = path.pathExtension.lowercased()
        if ["zip", "tar", "tgz", "tbz", "tbz2", "7z", "rar"].contains(archiveExtension) {
            displayFileEditor(FileEditor(type: .archive, viewController: ArchiveBrowserViewController(archiveURL: path.url)))
            return
        }
        if ["gz", "bz2"].contains(archiveExtension) {
            decompressPath(path: path)
            return
        }

        FileEditor.preferredAsync(forURL: path) { [weak self] preferred in
            guard let self else { return }
            guard let preferred else {
                self.openNativePreview(forPath: path)
                return
            }
            self.displayFileEditor(preferred)
            if let audioVC = preferred.viewController as? AudioPlayerViewController {
                self.audioPlayerController?.player.stop()
                self.audioPlayerController = audioVC
                self.setupAudioToolbarIfPossible()
            }
        }
    }

    func openNativePreview(forPath path: Path) {
        let controller = SantanderFilePreviewController(fileURL: path.url)
        if showInDetailColumn(controller) { return }
        present(UINavigationController(rootViewController: controller), animated: true)
    }

    func goToPath(path: Path) {
        SantanderPathHistory.add(path)
        if !path.isDirectoryLike {
            goToFile(path: path)
            return
        }

        guard let navigationController = navigationController else { return }
        let destination = PathListViewController(path: path)
        navigationController.pushViewController(destination, animated: true)
    }

    func traverseThroughPath(_ path: Path) {
        guard let navigationController = navigationController else { return }
        let urls = path.url.fullPathComponents()
        guard !urls.isEmpty else { return }

        let controllers = urls.map { PathListViewController(path: Path(url: $0)) }
        navigationController.setViewControllers(controllers, animated: true)
    }

    func sortContents() {
        let generation = UUID()
        sortGeneration = generation
        let requestedPath = currentPath
        let requestedLoadGeneration = directoryLoadGeneration
        let source = unfilteredContents
        let requestedSort = sortMethod
        let requestedOrder = SortOrder.userPreferred

        sortingQueue.async { [weak self] in
            // Skip stale work before touching disk when another sort request superseded it.
            let isCurrentRequest = DispatchQueue.main.sync {
                self?.sortGeneration == generation && self?.directoryLoadGeneration == requestedLoadGeneration
            }
            guard isCurrentRequest else { return }
            let sorted = requestedSort.sorting(URLs: source, sortOrder: requestedOrder)
            DispatchQueue.main.async { [weak self] in
                guard let self,
                      self.sortGeneration == generation,
                      self.directoryLoadGeneration == requestedLoadGeneration,
                      self.currentPath == requestedPath else { return }
                self.unfilteredContents = sorted
                self.reloadTableData(animatingDifferences: sorted.count <= 160)
            }
        }
    }

    func openInfoBottomSheet(path: Path) {
        if let app = path.applicationItem {
            let actions = [
                SantanderActionSheetItem(title: SantanderL10n.t("App Info"), image: SantanderIconLibrary.shared.interfaceIcon(for: "app")) {
                    let navController = UINavigationController(
                        rootViewController: AppInfoViewController(style: .insetGrouped, app: app, subPathsSender: self)
                    )
                    self.present(navController, animated: true)
                },
                SantanderActionSheetItem(title: SantanderL10n.t("Path Info"), image: SantanderIconLibrary.shared.interfaceIcon(for: "info.circle")) {
                    let navController = UINavigationController(
                        rootViewController: PathInformationTableViewController(style: .insetGrouped, path: path)
                    )
                    if #available(iOS 15.0, *) {
                        navController.sheetPresentationController?.detents = [.medium(), .large()]
                    }
                    self.present(navController, animated: true)
                },
                SantanderActionSheetItem(title: SantanderL10n.t("Cancel"), style: .cancel)
            ]
            presentSantanderActionSheet(title: nil, actions: actions)
        } else {
            let navController = UINavigationController(
                rootViewController: PathInformationTableViewController(style: .insetGrouped, path: path)
            )

            if #available(iOS 15.0, *) {
                navController.sheetPresentationController?.detents = [.medium(), .large()]
            }

            self.present(navController, animated: true)
        }
    }

    override func tableView(_ tableView: UITableView, accessoryButtonTappedForRowWith indexPath: IndexPath) {
        guard let selectedPath = path(forIndexPath: indexPath) else { return }
        openInfoBottomSheet(path: selectedPath)
    }

    func searchSuggestionCellRow(suggestion: SearchSuggestion) -> UITableViewCell {
        let cell = UITableViewCell()
        SantanderUI.styleCell(cell)
        var conf = cell.defaultContentConfiguration()
        conf.text = suggestion.name
        conf.image = suggestion.image
        cell.contentConfiguration = conf
        return cell
    }

    func pathCellRow(
        forURL fsItem: Path,
        displayFullPathAsSubtitle useSubtitle: Bool = false
    ) -> UITableViewCell {
        let cell = (tableView.dequeueReusableCell(withIdentifier: SantanderFileListCell.reuseIdentifier) as? SantanderFileListCell)
            ?? SantanderFileListCell(style: .default, reuseIdentifier: SantanderFileListCell.reuseIdentifier)
        let pathName = fsItem.lastPathComponent

        let metadata = UserPreferences.showFileMetadata ? SantanderFileMetadataCache.value(for: fsItem.url) : nil
        var title = pathName
        var subtitle: String? = useSubtitle ? fsItem.path : (UserPreferences.showFileMetadata ? metadata?.compactText ?? (fsItem.isDirectory ? "… 项" : "…") : nil)
        var image: UIImage?
        image = fsItem.displayImage
        var accessory: UITableViewCell.AccessoryType = .none

        if (fsItem.pathExtension == "app" || (containsAppUUIDs ?? fsItem.deletingLastPathComponent().containsAppUUIDSubpaths)),
           let app = fsItem.applicationItem {
            title = app.localizedName
            subtitle = useSubtitle ? "\(fsItem.lastPathComponent) · \(fsItem.path)" : (UserPreferences.showFileMetadata ? metadata?.compactText ?? fsItem.lastPathComponent : nil)
            image = ApplicationsManager.shared.icon(forApplication: app)
            accessory = .disclosureIndicator
        } else {
            accessory = .detailDisclosureButton
        }

        cell.configure(path: fsItem, title: title, subtitle: subtitle, image: image, accessory: accessory)
        cell.onInfoAction = { [weak self] path in self?.openInfoBottomSheet(path: path) }
        if isSearching, let query = navigationItem.searchController?.searchBar.text?.trimmingCharacters(in: .whitespacesAndNewlines), !query.isEmpty {
            cell.highlightTitle(matching: query)
        }
        cell.onPointerAction = { [weak self] action, path in
            self?.performPointerAction(action, for: path)
        }
        if pathName.first == "." {
            cell.titleLabelCustom.textColor = .secondaryLabel
        } else if fsItem.applicationItem != nil {
            cell.titleLabelCustom.textColor = tableView.tintColor ?? SantanderAppTheme.accentColor
        } else {
            cell.titleLabelCustom.textColor = .label
        }
        return cell
    }

    private func performPointerAction(_ action: SantanderFileListCell.PointerAction, for path: Path) {
        switch action {
        case .share:
            presentActivityVC(forItems: [path.url])
        case .rename:
            let alert = UIAlertController(title: SantanderL10n.t("Rename"), message: nil, preferredStyle: .alert)
            alert.addTextField { field in
                field.text = path.lastPathComponent
                field.autocapitalizationType = .none
            }
            alert.addAction(.cancel())
            alert.addAction(UIAlertAction(title: SantanderL10n.t("Rename"), style: .default) { [weak self, weak alert] _ in
                guard let self, let name = alert?.textFields?.first?.text?.trimmingCharacters(in: .whitespacesAndNewlines), !name.isEmpty else { return }
                let target = path.url.deletingLastPathComponent().appendingPathComponent(name)
                do {
                    try FSOperation.perform(.rename(item: path.url, newPath: target), rootHelperConf: RootConf.shared)
                    self.reloadCurrentDirectory()
                } catch { self.errorAlert(error, title: SantanderL10n.t("Rename")) }
            })
            present(alert, animated: true)
        case .delete:
            presentSantanderActionSheet(title: "删除此项目？", message: path.path, actions: [
                SantanderActionSheetItem(title: SantanderL10n.t("Delete"), image: SantanderIconLibrary.shared.interfaceIcon(for: "trash"), style: .destructive) { [weak self] in
                    guard let self else { return }
                    DispatchQueue.global(qos: .userInitiated).async {
                        var operationError: Error?
                        do { try FSOperation.perform(.removeItems(items: [path.url]), rootHelperConf: RootConf.shared) }
                        catch { operationError = error }
                        DispatchQueue.main.async {
                            if let operationError { self.errorAlert(operationError, title: SantanderL10n.t("Delete")) }
                            else { self.reloadCurrentDirectory() }
                        }
                    }
                },
                SantanderActionSheetItem(title: SantanderL10n.t("Cancel"), style: .cancel)
            ])
        }
    }

    private func pathIfAvailable(at indexPath: IndexPath) -> Path? {
        guard indexPath.section == 0 else { return nil }
        if let identifier = dataSource.itemIdentifier(for: indexPath) {
            if case .path(let path) = identifier { return path }
            return nil
        }
        guard contents.indices.contains(indexPath.row) else { return nil }
        return contents[indexPath.row]
    }

    private func presentRenamePrompt(for item: Path) {
        let alert = UIAlertController(
            title: SantanderL10n.t("Rename"),
            message: item.path,
            preferredStyle: .alert
        )
        alert.addTextField { field in
            field.text = item.lastPathComponent
            field.autocapitalizationType = .none
            field.autocorrectionType = .no
            field.clearButtonMode = .whileEditing
        }
        alert.addAction(.cancel())
        alert.addAction(UIAlertAction(title: SantanderL10n.t("Rename"), style: .default) { [weak self, weak alert] _ in
            guard let self,
                  let name = alert?.textFields?.first?.text?.trimmingCharacters(in: .whitespacesAndNewlines),
                  !name.isEmpty,
                  name != item.lastPathComponent else { return }
            let target = item.url.deletingLastPathComponent().appendingPathComponent(name)
            DispatchQueue.global(qos: .userInitiated).async {
                do {
                    try FSOperation.perform(.rename(item: item.url, newPath: target), rootHelperConf: RootConf.shared)
                    DispatchQueue.main.async { self.reloadCurrentDirectory() }
                } catch {
                    DispatchQueue.main.async { self.errorAlert(error, title: SantanderL10n.t("Unable to rename item")) }
                }
            }
        })
        present(alert, animated: true)
    }

    private func presentPathActionSheet(for item: Path, indexPath: IndexPath?) {
        let name = item.lastPathComponent.isEmpty ? item.path : item.lastPathComponent
        var actions: [SantanderActionSheetItem] = [
            SantanderActionSheetItem(title: SantanderL10n.t("Open"), subtitle: item.path, image: item.displayImage) { [weak self] in self?.goToPath(path: item) },
            SantanderActionSheetItem(title: SantanderL10n.t("Copy name"), image: SantanderIconLibrary.shared.interfaceIcon(for: "doc.on.doc")) { UIPasteboard.general.string = item.lastPathComponent },
            SantanderActionSheetItem(title: SantanderL10n.t("Copy path"), image: SantanderIconLibrary.shared.interfaceIcon(for: "link")) { UIPasteboard.general.string = item.path },
            SantanderActionSheetItem(title: SantanderL10n.t("Copy to.."), image: SantanderIconLibrary.shared.interfaceIcon(for: "doc.on.doc")) { [weak self] in self?.presentOperationVC(forItems: [item.url], type: .copy) },
            SantanderActionSheetItem(title: SantanderL10n.t("Move to.."), image: SantanderIconLibrary.shared.interfaceIcon(for: "arrow.right")) { [weak self] in self?.presentOperationVC(forItems: [item.url], type: .move) },
            SantanderActionSheetItem(title: SantanderL10n.t("Rename"), image: SantanderIconLibrary.shared.interfaceIcon(for: "pencil")) { [weak self] in
                guard let self else { return }
                if let indexPath,
                   let cell = self.tableView.cellForRow(at: indexPath),
                   var conf = cell.contentConfiguration as? UIListContentConfiguration,
                   let imageGuide = (cell.contentView as? UIListContentView)?.imageLayoutGuide {
                    let textField = RenamerTextField(path: item)
                    textField.returnKeyType = .done
                    textField.translatesAutoresizingMaskIntoConstraints = false
                    textField.delegate = self
                    textField.text = conf.text
                    conf.text = nil
                    cell.contentConfiguration = conf
                    cell.contentView.addSubview(textField)
                    NSLayoutConstraint.activate([
                        textField.leadingAnchor.constraint(equalTo: imageGuide.trailingAnchor, constant: conf.imageToTextPadding),
                        textField.centerYAnchor.constraint(equalTo: imageGuide.centerYAnchor)
                    ])
                    self.tableView.scrollToRow(at: indexPath, at: .top, animated: true)
                    textField.becomeFirstResponder()
                } else {
                    self.presentRenamePrompt(for: item)
                }
            },
            SantanderActionSheetItem(title: SantanderL10n.t("Create Symbolic Link"), image: SantanderIconLibrary.shared.interfaceIcon(for: "link")) { [weak self] in self?.presentRootLinkPrompt(for: item) },
            SantanderActionSheetItem(title: SantanderL10n.t("Delete"), image: SantanderIconLibrary.shared.interfaceIcon(for: "trash"), style: .destructive) { [weak self] in self?.deleteURL(item) { _ in } },
            SantanderActionSheetItem(title: SantanderL10n.t("Info"), image: SantanderIconLibrary.shared.interfaceIcon(for: "info.circle")) { [weak self] in self?.openInfoBottomSheet(path: item) },
            SantanderActionSheetItem(title: SantanderL10n.t("Share"), image: SantanderIconLibrary.shared.interfaceIcon(for: "square.and.arrow.up")) { [weak self] in self?.presentActivityVC(forItems: [item.url]) }
        ]
        if !item.isDirectory {
            actions.append(SantanderActionSheetItem(title: SantanderL10n.t("Open in.."), image: SantanderIconLibrary.shared.interfaceIcon(for: "square.grid.2x2")) { [weak self] in
                self?.presentOpenWithOptions(forPath: item) { [weak self] editor in self?.displayFileEditor(editor) }
            })
        }
        if item.contentType?.isOfType(.archive) ?? false {
            actions.append(SantanderActionSheetItem(title: SantanderL10n.t("Decompress"), image: SantanderIconLibrary.shared.interfaceIcon(for: "archivebox")) { [weak self] in self?.decompressPath(path: item) })
        } else {
            actions.append(contentsOf: Compression.FormatType.allCases.map { format in
                SantanderActionSheetItem(title: "\(SantanderL10n.t("Compress")) · \(format.description)", image: SantanderIconLibrary.shared.interfaceIcon(for: "archivebox")) { [weak self] in
                    guard let self else { return }
                    self.compressPaths(paths: [item], destination: item.deletingPathExtension().appendingPathExtension(format.fileExtension).url, format: format)
                }
            })
        }
        for group in UserPreferences.pathGroups {
            actions.append(SantanderActionSheetItem(title: "\(SantanderL10n.t("Add to group..")) · \(group.name)", image: SantanderIconLibrary.shared.interfaceIcon(for: "star")) {
                var groups = UserPreferences.pathGroups
                guard let index = groups.firstIndex(where: { $0.name == group.name }) else { return }
                if !groups[index].paths.contains(item.url) { groups[index].paths.append(item.url); UserPreferences.pathGroups = groups }
            })
        }
        if isMountPoint(item.url) {
            actions.append(SantanderActionSheetItem(title: SantanderL10n.t("Unmount"), image: SantanderIconLibrary.shared.uiIcon(named: "delete"), style: .destructive) { [weak self] in
                do { try RootConf.shared.runHelper(arguments: ["unmount", item.path]); self?.reloadCurrentDirectory() }
                catch { self?.errorAlert(error, title: "无法卸载 \(name)") }
            })
        } else {
            actions.append(SantanderActionSheetItem(title: SantanderL10n.t("Mount"), image: SantanderIconLibrary.shared.interfaceIcon(for: "externaldrive.badge.plus")) { [weak self] in self?.presentMountPrompt(for: item) })
        }
        actions.append(SantanderActionSheetItem(title: SantanderL10n.t("Cancel"), style: .cancel))
        presentSantanderActionSheet(title: name, message: item.path, actions: actions)
    }

    func presentRootLinkPrompt(for item: Path) {
        let alert = UIAlertController(title: SantanderL10n.t("Create Symbolic Link"), message: SantanderL10n.t("Enter the destination directory."), preferredStyle: .alert)
        alert.addTextField { field in
            field.text = item.deletingLastPathComponent().path
            field.autocapitalizationType = .none
        }
        alert.addAction(.cancel())
        alert.addAction(UIAlertAction(title: SantanderL10n.t("Create"), style: .default) { [weak self, weak alert] _ in
            guard let self, let destination = alert?.textFields?.first?.text, !destination.isEmpty else { return }
            do {
                try RootConf.shared.runHelper(arguments: ["link", item.path, "--destination", destination])
                self.reloadCurrentDirectory()
            } catch {
                self.errorAlert(error, title: SantanderL10n.t("无法创建符号链接"))
            }
        })
        present(alert, animated: true)
    }

    func presentMountPrompt(for item: Path) {
        let alert = UIAlertController(title: SantanderL10n.t("Mount"), message: SantanderL10n.t("Enter an empty or existing mount point."), preferredStyle: .alert)
        alert.addTextField { field in
            field.text = "/mnt/\(item.deletingPathExtension().lastPathComponent)"
            field.autocapitalizationType = .none
        }
        alert.addAction(.cancel())
        alert.addAction(UIAlertAction(title: SantanderL10n.t("Mount"), style: .default) { [weak self, weak alert] _ in
            guard let self, let target = alert?.textFields?.first?.text, !target.isEmpty else { return }
            do {
                try RootConf.shared.runHelper(arguments: ["mount", item.path, target])
                self.reloadCurrentDirectory()
            } catch {
                self.errorAlert(error, title: "无法挂载 \(item.lastPathComponent)")
            }
        })
        present(alert, animated: true)
    }

    func isMountPoint(_ url: URL) -> Bool {
        var current = statfs()
        guard statfs(url.path, &current) == 0 else {
            return false
        }

        var parent = statfs()
        let parentURL = url.deletingLastPathComponent()
        guard statfs(parentURL.path, &parent) == 0 else {
            return false
        }

        return current.f_fsid.val.0 != parent.f_fsid.val.0 || current.f_fsid.val.1 != parent.f_fsid.val.1
    }

    func reloadCurrentDirectory() {
        guard let currentPath else { return }
        let path = currentPath
        let generation = UUID()
        directoryLoadGeneration = generation
        let sortMethod = self.sortMethod

        DispatchQueue.global(qos: .userInitiated).async { [weak self] in
            let contents = sortMethod.sorting(URLs: path.contents, sortOrder: .userPreferred)
            DispatchQueue.main.async { [weak self] in
                guard let self,
                      self.currentPath == path,
                      self.directoryLoadGeneration == generation else { return }
                self.applyDirectoryContents(contents, animatingDifferences: false)
            }
        }
    }

    func presentOperationVC(forItems items: [URL], type: PathSelectionOperation) {
        let vc = PathOperationViewController(paths: items, operationType: type)
        present(UINavigationController(rootViewController: vc), animated: true) { [self] in
            if let currentPath = currentPath, currentPath != .root {
                vc.goToPath(path: currentPath)
            }
        }
    }

    @objc func showRightBarActions() {
        var actions: [SantanderActionSheetItem] = [
            SantanderActionSheetItem(title: SantanderL10n.t("Select"), image: SantanderIconLibrary.shared.interfaceIcon(for: "checkmark.circle")) { [weak self] in
                guard let self else { return }
                self.tableView.allowsMultipleSelectionDuringEditing = true
                self.setEditing(true, animated: true)
            },
            SantanderActionSheetItem(title: SantanderL10n.t("Display hidden files"), image: UIImage(systemName: displayHiddenFiles ? "eye" : "eye.slash"), isSelected: displayHiddenFiles) { [weak self] in
                guard let self else { return }
                self.displayHiddenFiles.toggle()
                self.setRightBarButton()
                self.reloadCurrentDirectory()
            }
        ]

        let navigationItems = GoToItem.all.map { item in
            SantanderActionSheetItem(title: item.displayName, subtitle: item.url.path, image: item.image) { [weak self] in
                self?.goToPath(path: Path(url: item.url))
            }
        }
        actions.append(contentsOf: navigationItems)
        actions.append(SantanderActionSheetItem(title: SantanderL10n.t("Other.."), image: SantanderIconLibrary.shared.interfaceIcon(for: "folder.badge.plus")) { [weak self] in
            guard let self else { return }
            let vc = GoToViewController()
            let nav = UINavigationController(rootViewController: vc)
            nav.modalPresentationStyle = .pageSheet
            if #available(iOS 15.0, *) {
                nav.sheetPresentationController?.detents = [.medium(), .large()]
                nav.sheetPresentationController?.prefersGrabberVisible = true
            }
            self.present(nav, animated: true)
        })
        let history = SantanderPathHistory.paths
        if !history.isEmpty {
            actions.append(contentsOf: history.prefix(8).map { path in
                SantanderActionSheetItem(title: path.lastPathComponent.isEmpty ? path.path : path.lastPathComponent, subtitle: path.path, image: SantanderIconLibrary.shared.interfaceIcon(for: "clock")) { [weak self] in
                    self?.goToPath(path: path)
                }
            })
        }

        if let currentPath {
            actions.append(SantanderActionSheetItem(title: SantanderL10n.t("Grid View"), image: SantanderIconLibrary.shared.interfaceIcon(for: "square.grid.3x3")) { [weak self] in
                guard let self else { return }
                self.navigationController?.pushViewController(SantanderGridViewController(path: currentPath), animated: true)
            })
            actions.append(SantanderActionSheetItem(title: SantanderL10n.t("New.."), image: SantanderIconLibrary.shared.uiIcon(named: "plus")) { [weak self] in self?.showNewItemOptions() })
            if !UIPasteboard.general.probableURLs.isEmpty {
                actions.append(SantanderActionSheetItem(title: SantanderL10n.t("Paste"), image: SantanderIconLibrary.shared.interfaceIcon(for: "doc.on.clipboard")) { [weak self] in self?.pasteIntoCurrentDirectory() })
            }
            actions.append(SantanderActionSheetItem(title: SantanderL10n.t("Terminal"), subtitle: currentPath.path, image: SantanderIconLibrary.shared.interfaceIcon(for: "terminal")) { [weak self] in
                self?.navigationController?.pushViewController(TerminalViewController(workingDirectory: currentPath.url), animated: true)
            })
            actions.append(SantanderActionSheetItem(title: SantanderL10n.t("Folder Info"), subtitle: currentPath.path, image: SantanderIconLibrary.shared.interfaceIcon(for: "info.circle")) { [weak self] in
                guard let self else { return }
                self.present(UINavigationController(rootViewController: PathInformationTableViewController(style: .insetGrouped, path: currentPath)), animated: true)
            })
        }
        actions.append(SantanderActionSheetItem(title: SantanderL10n.t("Sort by.."), image: SantanderIconLibrary.shared.interfaceIcon(for: "arrow.up.arrow.down")) { [weak self] in self?.showSortOptions() })
        actions.append(SantanderActionSheetItem(title: SantanderL10n.t("Cancel"), style: .cancel))
        presentSantanderActionSheet(title: SantanderL10n.t("File actions"), actions: actions)
    }

    private func pasteIntoCurrentDirectory() {
        guard let currentPath else { return }
        let sourceURLs = UIPasteboard.general.probableURLs
        guard !sourceURLs.isEmpty else {
            errorAlert(nil, title: SantanderL10n.t("No path to paste."))
            return
        }
        let destinationURL = currentPath.url
        let generationPath = currentPath
        DispatchQueue.global(qos: .userInitiated).async { [weak self] in
            do {
                try FSOperation.perform(.copyItem(items: sourceURLs, resultPath: destinationURL), rootHelperConf: RootConf.shared)
                DispatchQueue.main.async {
                    guard let self, self.currentPath == generationPath else { return }
                    self.reloadCurrentDirectory()
                }
            } catch {
                DispatchQueue.main.async { [weak self] in
                    self?.errorAlert(error, title: SantanderL10n.t("Failed to copy item to current directory."))
                }
            }
        }
    }

    override func tableView(_ tableView: UITableView, contextMenuConfigurationForRowAt indexPath: IndexPath, point: CGPoint) -> UIContextMenuConfiguration? {
        guard !isEditing, !displayingSearchSuggestions, let item = pathIfAvailable(at: indexPath) else { return nil }
        let itemName = item.lastPathComponent.isEmpty ? item.path : item.lastPathComponent
        return UIContextMenuConfiguration(identifier: item.url.standardizedFileURL.path as NSString, previewProvider: nil) { [weak self] _ in
            guard let self else { return nil }
            let select = UIAction(title: "选择", image: SantanderIconLibrary.shared.interfaceIcon(for: "checkmark.circle")) { [weak self] _ in
                guard let self else { return }
                self.setEditing(true, animated: true)
                self.selectedItems = [item]
                if let currentRow = self.contents.firstIndex(where: { $0.url.standardizedFileURL == item.url.standardizedFileURL }) {
                    self.tableView.selectRow(at: IndexPath(row: currentRow, section: 0), animated: false, scrollPosition: .none)
                }
                self.updateSelectedCountTitle()
                self.setupOrUpdateToolbar()
                self.setLeftBarSelectionButtonItem()
            }
            let open = UIAction(title: item.isDirectory ? "打开文件夹" : "打开", image: item.displayImage) { [weak self] _ in
                self?.goToPath(path: item)
            }
            let copyPath = UIAction(title: "复制路径", image: SantanderIconLibrary.shared.interfaceIcon(for: "link")) { _ in
                UIPasteboard.general.string = item.path
            }
            let copyItem = UIAction(title: "复制", image: SantanderIconLibrary.shared.interfaceIcon(for: "doc.on.doc")) { _ in
                UIPasteboard.general.urls = [item.url]
            }
            let share = UIAction(title: "分享", image: SantanderIconLibrary.shared.interfaceIcon(for: "square.and.arrow.up")) { [weak self] _ in
                self?.presentActivityVC(forItems: [item.url])
            }
            let info = UIAction(title: "属性", image: SantanderIconLibrary.shared.interfaceIcon(for: "info.circle")) { [weak self] _ in
                self?.openInfoBottomSheet(path: item)
            }
            let more = UIAction(title: "更多操作…", image: SantanderIconLibrary.shared.interfaceIcon(for: "ellipsis.circle")) { [weak self] _ in
                self?.presentPathActionSheet(for: item, indexPath: indexPath)
            }
            var children: [UIMenuElement] = []
            if item.isDirectory {
                children.append(open)
                children.append(select)
                children.append(copyPath)
                children.append(copyItem)
            } else {
                children.append(select)
                children.append(copyPath)
                children.append(copyItem)
                let openUsingApp = UIAction(title: "使用 App 打开", image: SantanderIconLibrary.shared.interfaceIcon(for: "arrow.up.forward.app")) { [weak self] _ in
                    self?.goToFile(path: item)
                }
                let openWith = UIAction(title: "打开方式…", image: SantanderIconLibrary.shared.interfaceIcon(for: "square.grid.2x2")) { [weak self] _ in
                    self?.presentOpenWithOptions(forPath: item) { [weak self] editor in self?.displayFileEditor(editor) }
                }
                children.append(openUsingApp)
                children.append(openWith)
            }
            children.append(share)
            children.append(info)
            children.append(more)
            return UIMenu(title: itemName, children: children)
        }
    }

    private func showBrowserTabs() {
        guard let navigationController else { return }
        let controller = SantanderBrowserTabsViewController(browserNavigationController: navigationController)
        let modal = UINavigationController(rootViewController: controller)
        modal.modalPresentationStyle = .pageSheet
        if #available(iOS 15.0, *) {
            modal.sheetPresentationController?.detents = [.medium(), .large()]
            modal.sheetPresentationController?.prefersGrabberVisible = true
        }
        present(modal, animated: true)
    }

    @objc private func showNewItemOptions() {
        guard let currentPath else { return }
        let actions = [
            SantanderActionSheetItem(title: SantanderL10n.t("File"), image: SantanderIconLibrary.shared.interfaceIcon(for: "doc.badge.plus")) { [weak self] in
                self?.presentAlertAndCreate(type: .file, forURL: currentPath.url)
            },
            SantanderActionSheetItem(title: SantanderL10n.t("Folder"), image: SantanderIconLibrary.shared.interfaceIcon(for: "folder.badge.plus")) { [weak self] in
                self?.presentAlertAndCreate(type: .directory, forURL: currentPath.url)
            },
            SantanderActionSheetItem(title: SantanderL10n.t("Cancel"), style: .cancel)
        ]
        presentSantanderActionSheet(title: SantanderL10n.t("New.."), actions: actions)
    }

    @objc private func showSortOptions() {
        var actions = PathsSortMethods.allCases.map { type in
            SantanderActionSheetItem(title: type.description, isSelected: type == sortMethod) { [weak self] in
                guard let self else { return }
                if type != self.sortMethod { self.sortMethod = type }
                self.setRightBarButton()
            }
        }
        actions.append(SantanderActionSheetItem(title: SantanderL10n.t("Reverse Order"), image: SantanderIconLibrary.shared.interfaceIcon(for: "arrow.up.arrow.down")) { [weak self] in
            guard let self else { return }
            _ = SortOrder.toggleUserPreferred()
            self.sortContents()
            self.setRightBarButton()
        })
        actions.append(SantanderActionSheetItem(title: SantanderL10n.t("Cancel"), style: .cancel))
        presentSantanderActionSheet(title: SantanderL10n.t("Sort by.."), actions: actions)
    }

    private func showRecentPaths() {
        let paths = SantanderPathHistory.paths
        var actions = paths.prefix(12).map { path in
            SantanderActionSheetItem(title: path.lastPathComponent.isEmpty ? path.path : path.lastPathComponent, subtitle: path.path, image: path.displayImage) { [weak self] in
                self?.goToPath(path: path)
            }
        }
        actions.append(SantanderActionSheetItem(title: SantanderL10n.t("Cancel"), style: .cancel))
        presentSantanderActionSheet(title: SantanderL10n.t("Recent Paths"), actions: actions)
    }

    func setRightBarButton() {
        if isSearchChromeSuppressed {
            navigationItem.rightBarButtonItems = nil
            return
        }
        if isEditing {
            let done = UIBarButtonItem(title: "完成", style: .done, target: self, action: #selector(finishEditing))
            navigationItem.rightBarButtonItems = [done]
        } else {
            let menu = UIBarButtonItem(image: UIImage(systemName: "ellipsis.circle"), style: .plain, target: self, action: #selector(showRightBarActions))
            menu.accessibilityLabel = SantanderL10n.t("File actions")
            navigationItem.rightBarButtonItems = [menu]
        }
    }

    @objc private func toggleEditingFromNavigationBar() {
        tableView.allowsMultipleSelectionDuringEditing = true
        setEditing(true, animated: true)
    }

    @objc private func finishEditing() {
        setEditing(false, animated: true)
    }

    @objc private func handleMultiSelectPan(_ gesture: UIPanGestureRecognizer) {
        guard isEditing, gesture.numberOfTouches >= 2 else { return }
        let location = gesture.location(in: tableView)
        switch gesture.state {
        case .began:
            sweptSelectionIndexPaths.removeAll()
            if let indexPath = tableView.indexPathForRow(at: location) { selectSweptRow(indexPath) }
        case .changed:
            if let indexPath = tableView.indexPathForRow(at: location) { selectSweptRow(indexPath) }
        case .ended, .cancelled, .failed:
            sweptSelectionIndexPaths.removeAll()
        default: break
        }
    }

    private func selectSweptRow(_ indexPath: IndexPath) {
        guard !sweptSelectionIndexPaths.contains(indexPath),
              indexPath.section == 0,
              let item = dataSource.itemIdentifier(for: indexPath),
              case .path(let path) = item else { return }
        sweptSelectionIndexPaths.insert(indexPath)
        if !selectedItems.contains(path) {
            selectedItems.append(path)
            tableView.selectRow(at: indexPath, animated: false, scrollPosition: .none)
            updateSelectedCountTitle()
            setupOrUpdateToolbar()
            setLeftBarSelectionButtonItem()
        }
    }

    override func setEditing(_ editing: Bool, animated: Bool) {
        super.setEditing(editing, animated: animated)

        setRightBarButton()
        setLeftBarSelectionButtonItem()
        if editing {
            filzaBottomBar?.isHidden = true
            tableView.contentInset.bottom = 0
            tableView.verticalScrollIndicatorInsets.bottom = 0
            updateSelectedCountTitle()
            setupOrUpdateToolbar()
        } else {
            hideToolbarItems()
            selectedItems = []
            restoreDirectoryTitle()
            filzaBottomBar?.isHidden = false
            updateFilzaBottomBarInsets()
        }
    }

    private func updateSelectedCountTitle() {
        guard isEditing else { return }
        navigationItem.title = "已选 \(selectedItems.count) 项"
    }

    private func restoreDirectoryTitle() {
        guard let currentPath else { return }
        if UIDevice.isiPad {
            let breadcrumb = SantanderBreadcrumbView(path: currentPath)
            breadcrumb.frame.size = CGSize(width: max(0, min(view.bounds.width - 120, 700)), height: 32)
            breadcrumb.onSelect = { [weak self] destination in self?.goToPath(path: destination) }
            navigationItem.titleView = breadcrumb
        } else {
            navigationItem.titleView = nil
            navigationItem.title = currentPath.lastPathComponent.isEmpty ? "/" : currentPath.lastPathComponent
        }
    }

    private func visibleDirectoryContents(_ allContents: [Path]) -> [Path] {
        displayHiddenFiles ? allContents : allContents.filter { !$0.lastPathComponent.hasPrefix(".") }
    }

    private func changedDirectoryURLs(old: [Path], new: [Path]) -> Set<String> {
        var oldByPath: [String: Path] = [:]
        for path in old { oldByPath[path.url.standardizedFileURL.path] = path }
        return Set(new.compactMap { path in
            let key = path.url.standardizedFileURL.path
            guard let previous = oldByPath[key] else { return nil }
            return previous == path ? nil : key
        })
    }

    private func applyDirectoryContents(_ newContents: [Path], animatingDifferences: Bool) {
        let oldVisible = visibleDirectoryContents(unfilteredContents)
        let newVisible = visibleDirectoryContents(newContents)
        let changedURLs = changedDirectoryURLs(old: oldVisible, new: newVisible)

        unfilteredContents = newContents
        updateFilzaDirectoryStatus(for: newContents)

        if isSearching {
            if let searchBar = navigationItem.searchController?.searchBar, !(searchBar.text ?? "").isEmpty {
                updateResults(searchBar: searchBar)
            } else {
                filteredSearchContents = newVisible
                showPaths(animatingDifferences: animatingDifferences, reconfigureURLs: changedURLs)
            }
        } else {
            filteredSearchContents = newVisible
            showPaths(animatingDifferences: animatingDifferences, reconfigureURLs: changedURLs)
        }
    }

    private func updateFilzaDirectoryStatus(for items: [Path]) {
        guard let currentPath, let statusView = filzaDirectoryStatusView else { return }
        let path = currentPath
        let hiddenCount = items.filter { $0.lastPathComponent.hasPrefix(".") }.count
        let generation = UUID()
        directoryStatusGeneration = generation
        DispatchQueue.global(qos: .utility).async { [weak self, weak statusView] in
            let writeAccess = RootConf.shared.directoryWriteAccess(at: path.url, probeRootHelper: false)
            DispatchQueue.main.async {
                guard let self, let statusView,
                      self.directoryStatusGeneration == generation,
                      self.currentPath == path else { return }
                statusView.configure(at: path.url, items: items, hiddenCount: hiddenCount, canWrite: writeAccess.canWrite, viaRootHelper: writeAccess.viaRootHelper)
            }
        }
    }

    func reloadTableData(animatingDifferences: Bool = false) {
        if !displayHiddenFiles {
            let filtered = unfilteredContents.filter { !$0.lastPathComponent.starts(with: ".") }
            setFilteredContents(filtered, animatingDifferences: animatingDifferences)
        } else {
            setFilteredContents(unfilteredContents, animatingDifferences: animatingDifferences)
        }
    }

    func setFilteredContents(_ newContents: [Path], animatingDifferences: Bool = false) {
        let oldVisible: [Path]
        if isSearching {
            oldVisible = filteredSearchContents
        } else if displayHiddenFiles {
            oldVisible = unfilteredContents
        } else {
            oldVisible = unfilteredContents.filter { !$0.lastPathComponent.hasPrefix(".") }
        }

        var oldByPath: [String: Path] = [:]
        for path in oldVisible { oldByPath[path.url.standardizedFileURL.path] = path }
        let changedURLs = Set(newContents.compactMap { path -> String? in
            let key = path.url.standardizedFileURL.path
            guard let old = oldByPath[key] else { return nil }
            return old == path ? nil : key
        })

        filteredSearchContents = newContents
        if !displayingSearchSuggestions {
            showPaths(animatingDifferences: animatingDifferences, reconfigureURLs: changedURLs)
        }
    }

    func setupPermissionDeniedLabelIfNeeded() {
        if let emptyStateView, tableView.backgroundView === emptyStateView {
            tableView.backgroundView = nil
        } else {
            emptyStateView?.removeFromSuperview()
        }
        emptyStateView = nil
        guard let currentPath = currentPath, contents.isEmpty, !displayingSearchSuggestions else { return }
        if isSearching {
            guard !(navigationItem.searchController?.searchBar.text ?? "").trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else { return }
            let noResults = SantanderEmptyStateView(icon: "magnifyingglass", title: SantanderL10n.t("No Results"), message: SantanderL10n.t("Try another name or clear the active filters."))
            noResults.frame = tableView.bounds
            noResults.autoresizingMask = [.flexibleWidth, .flexibleHeight]
            tableView.backgroundView = noResults
            emptyStateView = noResults
            return
        }
        guard isDirectoryContentsReady else { return }

        let readable = currentPath.isReadable
        let helperExists = Bundle.main.url(forResource: "SantanderHelper", withExtension: nil).map { FileManager.default.isExecutableFile(atPath: $0.path) } ?? false
        let stateView: SantanderEmptyStateView
        if readable {
            stateView = SantanderEmptyStateView(
                icon: "folder",
                title: SantanderL10n.t("This folder is empty"),
                message: SantanderL10n.t("Create a file or folder, or navigate to another location."),
                actionTitle: SantanderL10n.t("New folder")
            ) { [weak self] in
                guard let self, let currentPath = self.currentPath else { return }
                self.presentAlertAndCreate(type: .directory, forURL: currentPath.url)
            }
        } else {
            stateView = SantanderEmptyStateView(
                icon: "lock",
                title: SantanderL10n.t("Permission Denied."),
                message: SantanderL10n.t("This location could not be read. Check Santander Helper availability and permissions."),
                actionTitle: helperExists ? SantanderL10n.t("Retry with Santander Helper") : SantanderL10n.t("Retry")
            ) { [weak self] in
                guard let self, let path = self.currentPath else { return }
                self.loadDirectoryContentsInBackground(for: path, forceReload: true)
            }
        }
        stateView.frame = tableView.bounds
        stateView.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        tableView.backgroundView = stateView
        emptyStateView = stateView
    }
}

extension PathListViewController {
    func tableView(_ tableView: UITableView, prefetchRowsAt indexPaths: [IndexPath]) {
        for indexPath in indexPaths {
            guard let item = dataSource.itemIdentifier(for: indexPath), case .path(let url) = item else { continue }
            PathImageCache.prefetch(url)
        }
    }

    func tableView(_ tableView: UITableView, cancelPrefetchingForRowsAt indexPaths: [IndexPath]) { }
}

extension PathListViewController: DirectoryMonitorDelegate {
    func directoryMonitorDidObserveChange(directoryMonitor: DirectoryMonitor) {
        let observedPath = directoryMonitor.path
        DispatchQueue.main.async { [weak self] in
            guard let self, self.currentPath == observedPath else { return }

            self.directoryChangeWorkItem?.cancel()
            let generation = UUID()
            self.directoryChangeGeneration = generation
            let sortMethod = self.sortMethod
            let workItem = DispatchWorkItem { [weak self] in
                let items = sortMethod.sorting(
                    URLs: observedPath.contents,
                    sortOrder: SortOrder.userPreferred
                )

                DispatchQueue.main.async { [weak self] in
                    guard let self,
                          self.currentPath == observedPath,
                          self.directoryChangeGeneration == generation else { return }
                    self.directoryChangeWorkItem = nil
                    self.applyDirectoryContents(items, animatingDifferences: true)
                    self.isDirectoryContentsReady = true
                }
            }
            self.directoryChangeWorkItem = workItem
            DispatchQueue.global(qos: .utility).asyncAfter(deadline: .now() + 0.12, execute: workItem)
        }
    }
}
#if compiler(>=5.7)
@available(iOS 16.0, *)
extension PathListViewController: UINavigationItemRenameDelegate {
    func navigationItem(_: UINavigationItem, didEndRenamingWith title: String) {
        guard let currentPath = currentPath else {
            return
        }

        let newURL: Path = currentPath.deletingLastPathComponent().appending(title)

        guard currentPath != newURL else {
            return
        }

        do {
            try FSOperation.perform(.moveItem(items: [currentPath.url], resultPath: newURL.url), rootHelperConf: RootConf.shared)
            self.currentPath = newURL
        } catch {
            self.errorAlert(error, title: "无法重命名 \(newURL.lastPathComponent)")
            self.title = currentPath.lastPathComponent
        }
    }

    func navigationItemShouldBeginRenaming(_: UINavigationItem) -> Bool {
        return currentPath != nil
    }
}
#endif

extension PathListViewController: UITextFieldDelegate {
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        guard let textField = textField as? RenamerTextField else {
            return false
        }

        textField.notifyShouldReturnUponResigning = false
        defer {
            textField.resignFirstResponder()
            textField.removeFromSuperview()
        }

        guard let name = textField.text else { return false }
        let item = textField.path
        let newPath: URL = item.deletingLastPathComponent().appendingURL(name)
        if newPath == item.url {
            return true
        }

        do {
            try FSOperation.perform(.rename(item: item.url, newPath: newPath), rootHelperConf: RootConf.shared)
        } catch {
            self.errorAlert(error, title: "无法重命名 \(item.lastPathComponent)")
        }

        print(textField.path)
        return true
    }
}

enum SubPathsRowItem: Hashable {
    static func == (lhs: SubPathsRowItem, rhs: SubPathsRowItem) -> Bool {
        switch (lhs, rhs) {
        case (.path(let firstURL), .path(let secondURL)):
            return firstURL == secondURL
        case (.searchSuggestion(let firstSuggestion), .searchSuggestion(let secondSuggestion)):
            return firstSuggestion == secondSuggestion
        default:
            return false
        }
    }

    func hash(into hasher: inout Hasher) {
        switch self {
        case .searchSuggestion(let searchSuggestion):
            hasher.combine(searchSuggestion)
        case .path(let url):
            hasher.combine(url)
        }
    }

    case searchSuggestion(SearchSuggestion)
    case path(Path)

    static func fromPaths(_ paths: [Path]) -> [SubPathsRowItem] {
        return paths.map { url in
            return .path(url)
        }
    }
}

class PathSidebarListViewController: UIViewController, PathTransitioning, UICollectionViewDelegate, UICollectionViewDragDelegate, UICollectionViewDropDelegate {

    typealias Item = DiffableDataSourceItem<String, Path>
    typealias DataSource = UICollectionViewDiffableDataSource<String, Item>
    typealias CellRegistration = UICollectionView.CellRegistration<UICollectionViewListCell, Item>

    var dataSource: DataSource!
    var pathGroups = UserPreferences.pathGroups
    var collectionView: UICollectionView!

    var subPathsSecondary: PathListViewController? {
        if let nav = splitViewController?.viewController(for: .supplementary) as? UINavigationController {
            return nav.visibleViewController as? PathListViewController
        }
        return splitViewController?.viewController(for: .secondary) as? PathListViewController
    }

    init() {
        super.init(nibName: nil, bundle: nil)
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    override func viewDidLoad() {
        title = SantanderL10n.t("Santander")
        setupCollectionView()
        setupDataSource()

        let newGroupAction = UIAction {
            self.presentNewGroupAlert()
        }

        navigationController?.navigationBar.prefersLargeTitles = true
        let newGroupsButton = UIBarButtonItem(systemItem: .add, primaryAction: newGroupAction)
        setToolbarItems([newGroupsButton], animated: true)
        navigationController?.setToolbarHidden(false, animated: false)

        NotificationCenter.default.addObserver(forName: .pathGroupsDidChange, object: nil, queue: nil) { [self] notif in
            if let newGroups = notif.object as? [PathGroup] {
                self.pathGroups = newGroups
                addItems()
            }
        }
    }

    func setupCollectionView() {
        let layout = UICollectionViewCompositionalLayout { _, env in
            var layoutConf = UICollectionLayoutListConfiguration(appearance: .insetGrouped)
            layoutConf.headerMode = .firstItemInSection
            layoutConf.trailingSwipeActionsConfigurationProvider = { (indexPath: IndexPath) -> UISwipeActionsConfiguration? in
                let sectionAndRow = (indexPath.section, indexPath.row)

                guard sectionAndRow != (0, 0) && sectionAndRow != (0, 1) else {
                    return nil
                }

                let removeAction = UIContextualAction(style: .destructive, title: nil) { [self] _, _, completion in
                    switch dataSource.itemIdentifier(for: indexPath) {
                    case .section(let name):
                        UserPreferences.pathGroups.remove(at: indexPath.section)
                        removeSection(name)
                    case .item(_):
                        UserPreferences.pathGroups[indexPath.section].paths.remove(at: indexPath.row - 1)
                    default:
                        return completion(false)
                    }

                    return completion(true)
                }

                removeAction.image = .remove
                return UISwipeActionsConfiguration(actions: [removeAction])
            }

            return .list(using: layoutConf, layoutEnvironment: env)
        }

        self.collectionView = UICollectionView(frame: .zero, collectionViewLayout: layout)
        collectionView.translatesAutoresizingMaskIntoConstraints = false
        collectionView.delegate = self
        collectionView.dragDelegate = self
        collectionView.dropDelegate = self
        collectionView.dragInteractionEnabled = true

        view.addSubview(collectionView)
        collectionView.constraintCompletely(to: view)
    }

    func setupDataSource() {
        let cellRegistration = CellRegistration { cell, indexPath, itemIdentifier in
            var conf: UIListContentConfiguration
            switch itemIdentifier {
            case .section(let headerTitle):
                conf = .sidebarHeader()
                conf.text = headerTitle
                conf.image = SantanderIconLibrary.shared.interfaceIcon(for: "chevron.down")
            case .item(let path):
                conf = cell.defaultContentConfiguration()
                conf.text = path.lastPathComponent
                conf.image = path.displayImage
            }

            cell.contentConfiguration = conf
        }

        dataSource = DataSource(collectionView: collectionView) { collectionView, indexPath, item in
            return collectionView.dequeueConfiguredReusableCell(using: cellRegistration, for: indexPath, item: item)
        }

        addItems()
    }

    func addItems() {
        var snapshot = dataSource.snapshot()
        if snapshot.sectionIdentifiers.isEmpty {
            snapshot.appendSections(pathGroups.map(\.name))
            dataSource.apply(snapshot)
        }

        for group in pathGroups {
            var sectionSnapshot = NSDiffableDataSourceSectionSnapshot<Item>()
            let section: Item = .section(group.name)
            sectionSnapshot.append([section])
            sectionSnapshot.expand([section])

            let items = Item.fromItems(group.paths.map(Path.init(url:)))
            sectionSnapshot.append(items, to: section)
            dataSource.apply(sectionSnapshot, to: group.name)
        }
    }

    func removeSection(_ name: String) {
        var snapshot = dataSource.snapshot()
        snapshot.deleteSections([name])
        dataSource.apply(snapshot)
    }

    func goToPath(path: Path) {
        let secondary = subPathsSecondary
        if !path.isDirectory {
            secondary?.goToFile(path: path)
            return
        }

        if let currentSubpathsPath = secondary?.currentPath {
            guard currentSubpathsPath != path else { return }

            if currentSubpathsPath.path.hasPrefix(path.path) {
                if let vcs = secondary?.navigationController?.viewControllers as? [PathListViewController],
                   let first = vcs.first(where: { $0.currentPath == path }) {
                       secondary?.navigationController?.popToViewController(first, animated: false)
                }
            } else if path.deletingLastPathComponent() != currentSubpathsPath {
                secondary?.traverseThroughPath(path)
            } else {
                splitViewController?.setViewController(UINavigationController(rootViewController: PathListViewController(path: path)), for: .supplementary)
            }

        } else {
            let vc = UINavigationController(rootViewController: PathListViewController(path: .root))
            splitViewController?.setViewController(vc, for: .supplementary)
            if path != .root { subPathsSecondary?.traverseThroughPath(path) }
        }
    }

    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        guard let item = dataSource.itemIdentifier(for: indexPath) else { return }
        switch item {
        case .section(_): break
        case .item(let path):
            goToPath(path: path)
        }
    }

    func presentNewGroupAlert() {
        let alert = UIAlertController(title: SantanderL10n.t("New Group"), message: nil, preferredStyle: .alert)
        alert.addTextField { textField in
            textField.placeholder = SantanderL10n.t("Group name..")
        }

        let addAction = UIAlertAction(title: SantanderL10n.t("Add"), style: .default) { [self] _ in
            guard let name = alert.textFields?.first?.text else { return }
            if pathGroups.map(\.name).contains(name) {
                errorAlert("同名的组已经存在。", title: "无法创建名为「\(name)」的组")
            }

            let newGroup = PathGroup(name: name, paths: [])
            UserPreferences.pathGroups.append(newGroup)
        }

        alert.addAction(addAction)
        alert.addAction(.cancel())
        present(alert, animated: true)
    }
}

private enum SantanderIdentityDatabase {
    private static let userNames: [Int32: String] = [
        -2: "nobody",
        0: "root",
        1: "daemon",
        24: "_networkd",
        25: "_wireless",
        33: "_installd",
        34: "_neagent",
        35: "_ifccd",
        64: "_securityd",
        65: "_mdnsresponder",
        75: "_sshd",
        213: "_usbmuxd",
        241: "_distnote",
        245: "_astris",
        249: "_ondemand",
        254: "_findmydevice",
        257: "_datadetectors",
        258: "_captiveagent",
        263: "_analyticsd",
        265: "_fpsd",
        266: "_timed",
        267: "_gpsd",
        269: "_reportmemoryexception",
        270: "_driverkit",
        271: "_diskimagesiod",
        272: "_logd",
        276: "_iconservices",
        277: "_rmd",
        278: "_accessoryupdater",
        279: "_knowledgegraphd",
        280: "_coreml",
        281: "_sntpd",
        282: "_trustd",
        283: "_mmaintenanced",
        284: "_darwindaemon",
        285: "_notification_proxy",
        287: "_backboardd",
        288: "_avphidbridge",
        290: "_launchservices",
        293: "_mobilegestalthelper",
        297: "_eligibilityd",
        298: "_systemstatusd",
        299: "systemusers",
        300: "_aonsensed",
        301: "_modelmanagerd",
        302: "_reportsystemmemory",
        303: "_swtransparencyd",
        304: "_naturallanguaged",
        307: "_diagnosticservicesd",
        501: "mobile",
    ]


    private static let groupNames: [Int32: String] = [
        -2: "nobody",
        0: "wheel",
        1: "daemon",
        2: "kmem",
        3: "sys",
        4: "tty",
        5: "operator",
        6: "mail",
        7: "bin",
        8: "procview",
        9: "procmod",
        10: "owner",
        12: "everyone",
        16: "group",
        20: "staff",
        24: "_networkd",
        25: "_wireless",
        26: "_lp",
        27: "_postfix",
        28: "_postdrop",
        29: "certusers",
        30: "_keytabusers",
        33: "_installd",
        34: "_neagent",
        35: "_ifccd",
        45: "utmp",
        50: "authedusers",
        51: "interactusers",
        52: "netusers",
        53: "consoleusers",
        54: "_mcxalr",
        59: "_devdocs",
        60: "_sandbox",
        61: "localaccounts",
        62: "netaccounts",
        64: "_securityd",
        65: "_mdnsresponder",
        66: "_uucp",
        67: "_ard",
        68: "dialer",
        69: "network",
        70: "_www",
        72: "_cvs",
        73: "_svn",
        74: "_mysql",
        75: "_sshd",
        76: "_qtss",
        78: "_mailman",
        80: "admin",
        81: "_appserveradm",
        82: "_clamav",
        83: "_amavisd",
        84: "_jabber",
        87: "_appowner",
        88: "_windowserver",
        89: "_spotlight",
        90: "accessibility",
        91: "_tokend",
        92: "_securityagent",
        93: "_calendar",
        94: "_teamsserver",
        95: "_update_sharing",
        96: "_installer",
        97: "_atsserver",
        98: "_lpadmin",
        213: "_usbmuxd",
        241: "_distnote",
        245: "_astris",
        249: "_ondemand",
        250: "_analyticsusers",
        254: "_findmydevice",
        257: "_datadetectors",
        258: "_captiveagent",
        263: "_analyticsd",
        265: "_fpsd",
        266: "_timed",
        267: "_gpsd",
        269: "_reportmemoryexception",
        270: "_driverkit",
        271: "_diskimagesiod",
        272: "_logd",
        276: "_iconservices",
        277: "_rmd",
        278: "_accessoryupdater",
        279: "_knowledgegraphd",
        280: "_coreml",
        281: "_sntpd",
        282: "_trustd",
        283: "_mmaintenanced",
        284: "_darwindaemon",
        285: "_notification_proxy",
        286: "_accessory_mobile_share",
        287: "_backboardd",
        288: "_avphidbridge",
        290: "_launchservices",
        293: "_mobilegestalthelper",
        297: "_eligibilityd",
        298: "_systemstatusd",
        299: "systemusers",
        300: "_aonsensed",
        301: "_modelmanagerd",
        302: "_reportsystemmemory",
        303: "_swtransparencyd",
        304: "_naturallanguaged",
        307: "_diagnosticservicesd",
        501: "mobile",
    ]


    private static let namedUsers: [Int32: String] = userNames.filter { id, name in
        id != 99 && !name.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
    }

    private static let namedGroups: [Int32: String] = groupNames.filter { id, name in
        id != -1 && id != 99 && !name.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
    }

    static func name(id: Int32, group: Bool) -> String? {
        (group ? namedGroups : namedUsers)[id]
    }

    static func all(group: Bool) -> [Int32: String] {
        group ? namedGroups : namedUsers
    }
}

class PathGroupOwnerViewController: UITableViewController {
    enum ItemType: Hashable, CustomStringConvertible {
        case owner(id: Int32, name: String?)
        case group(id: Int32, name: String?)

        var id: Int32 {
            switch self {
            case .owner(let id, _), .group(let id, _): return id
            }
        }

        var name: String {
            switch self {
            case .owner(_, let name): return name ?? "未知用户"
            case .group(_, let name): return name ?? "未知组"
            }
        }

        var subtitle: String {
            switch self {
            case .owner: return "UID \(id)"
            case .group: return "GID \(id)"
            }
        }

        var title: String {
            switch self {
            case .owner: return SantanderL10n.t("Owner")
            case .group: return SantanderL10n.t("Group")
            }
        }

        var description: String { "\(name) (\(id))" }

        static func candidates(forURL _: URL, type: ItemType) -> [ItemType] {
            let isGroup: Bool
            switch type {
            case .owner: isGroup = false
            case .group: isGroup = true
            }
            let names = SantanderIdentityDatabase.all(group: isGroup)
            return names.keys.sorted().compactMap { id in
                guard let name = names[id] else { return nil }
                return isGroup ? .group(id: id, name: name) : .owner(id: id, name: name)
            }
        }

        func set(id: Int32, forURL url: URL) throws {
            guard id != -1 else {
                throw StringError("UID/GID -1 是 POSIX 保留值，不能作为实际所有者或组 ID。")
            }
            try RootConf.shared.runHelper(arguments: arguments(for: url, id: id))
        }

        private func arguments(for url: URL, id: Int32) -> [String] {
            switch self {
            case .owner:
                return ["set-owner-or-group", url.path, "--owner-id", String(id)]
            case .group:
                return ["set-owner-or-group", url.path, "--group-id", String(id)]
            }
        }
    }

    var type: ItemType
    weak var sourceVC: PathPermissionsViewController?
    weak var sourceInformationVC: PathInformationTableViewController?
    let fileURL: URL
    var allData: [ItemType] = []
    private var loadedCount = 0
    private var isApplyingIdentity = false
    private var isSearchingIdentities = false

    enum Section { case main }
    typealias DataSource = UITableViewDiffableDataSource<Section, ItemType>

    lazy var dataSource = DataSource(tableView: tableView) { [weak self] tableView, indexPath, itemIdentifier in
        let cell = UITableViewCell()
        SantanderUI.styleCell(cell)
        var conf = cell.defaultContentConfiguration()
        conf.text = "\(itemIdentifier.id). \(itemIdentifier.name)"
        cell.selectionStyle = itemIdentifier.id == -1 ? .none : .default
        conf.secondaryText = nil
        cell.accessoryType = self?.type.id == itemIdentifier.id ? .checkmark : .none
        cell.contentConfiguration = conf
        return cell
    }

    init(style: UITableView.Style, type: ItemType, sourceVC: PathPermissionsViewController? = nil, fileURL: URL, sourceInformationVC: PathInformationTableViewController? = nil) {
        self.type = type
        self.sourceVC = sourceVC
        self.sourceInformationVC = sourceInformationVC
        self.fileURL = fileURL
        super.init(style: style)
    }

    required init?(coder: NSCoder) { fatalError() }

    override func viewDidLoad() {
        super.viewDidLoad()
        applySantanderUI()
        title = type.title
        let searchController = UISearchController(searchResultsController: nil)
        searchController.searchBar.delegate = self
        searchController.searchBar.placeholder = SantanderL10n.t("Search")
        navigationItem.searchController = searchController
        navigationItem.hidesSearchBarWhenScrolling = false
        navigationItem.rightBarButtonItem = nil


        applyItems([], animatingDifference: false)
        let url = fileURL
        let selectedType = type
        DispatchQueue.global(qos: .utility).async { [weak self] in
            let candidates = ItemType.candidates(forURL: url, type: selectedType).filter { candidate in
                !candidate.name.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
                    && candidate.id != -1
            }
            DispatchQueue.main.async {
                guard let self, self.type == selectedType else { return }
                self.allData = candidates
                self.loadedCount = candidates.count
                self.applyItems(candidates, animatingDifference: false)
            }
        }
    }

    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        guard !isApplyingIdentity, let item = dataSource.itemIdentifier(for: indexPath) else { return }
        guard item.id != -1 else {
            tableView.deselectRow(at: indexPath, animated: true)
            return
        }

        let oldType = type
        isApplyingIdentity = true
        type = item
        switch item {
        case .owner(let id, let name):
            sourceVC?.permissions.ownerID = id
            sourceVC?.permissions.ownerName = name
        case .group(let id, let name):
            sourceVC?.permissions.groupID = id
            sourceVC?.permissions.groupOwnerName = name
        }
        sourceVC?.tableView.reloadData()
        tableView.reloadData()
        tableView.deselectRow(at: indexPath, animated: true)

        let url = fileURL
        DispatchQueue.global(qos: .utility).async { [weak self] in
            do {
                try item.set(id: item.id, forURL: url)
                DispatchQueue.main.async {
                    self?.sourceInformationVC?.refreshMetadataAfterOwnershipChange()
                    self?.isApplyingIdentity = false
                }
            } catch {
                DispatchQueue.main.async { [weak self] in
                    guard let self else { return }
                    self.type = oldType
                    switch oldType {
                    case .owner(let id, let name):
                        self.sourceVC?.permissions.ownerID = id
                        self.sourceVC?.permissions.ownerName = name
                    case .group(let id, let name):
                        self.sourceVC?.permissions.groupID = id
                        self.sourceVC?.permissions.groupOwnerName = name
                    }
                    self.sourceVC?.tableView.reloadData()
                    self.sourceInformationVC?.refreshMetadataAfterOwnershipChange()
                    self.tableView.reloadData()
                    self.isApplyingIdentity = false
                    self.errorAlert(error, title: "无法修改\(self.type.title)")
                }
            }
        }
    }

    func applyItems(_ items: [ItemType], animatingDifference: Bool = false) {
        var snapshot = NSDiffableDataSourceSnapshot<Section, ItemType>()
        snapshot.appendSections([.main])
        snapshot.appendItems(items, toSection: .main)
        dataSource.apply(snapshot, animatingDifferences: animatingDifference)
    }
}

extension PathGroupOwnerViewController: UISearchBarDelegate {
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        if searchText.isEmpty {
            isSearchingIdentities = false
            applyItems(Array(allData.prefix(loadedCount)), animatingDifference: true)
            return
        }

        isSearchingIdentities = true
        let filtered = allData.filter { item in
            item.name.localizedCaseInsensitiveContains(searchText) ||
            item.subtitle.localizedCaseInsensitiveContains(searchText) ||
            item.description.localizedCaseInsensitiveContains(searchText)
        }

        applyItems(filtered, animatingDifference: true)
    }

    func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
        isSearchingIdentities = false
        applyItems(Array(allData.prefix(loadedCount)), animatingDifference: true)
    }
}

extension PathListViewController: AudioPlayerToolbarDelegate {

    @objc
    func setupOrUpdateToolbar() {

        let trashAction = UIAction {
            let itemsToDelete = self.selectedItems
            self.presentSantanderActionSheet(title: "确定要删除已选的 \(itemsToDelete.count) 个项目吗？", actions: [
                SantanderActionSheetItem(title: SantanderL10n.t("Delete"), image: SantanderIconLibrary.shared.interfaceIcon(for: "trash"), style: .destructive) {
                    DispatchQueue.global(qos: .userInitiated).async {
                        var operationError: Error?
                        do { try FSOperation.perform(.removeItems(items: itemsToDelete.map(\.url)), rootHelperConf: RootConf.shared) }
                        catch { operationError = error }
                        DispatchQueue.main.async {
                            if let operationError {
                                self.errorAlert(operationError, title: SantanderL10n.t("无法删除项目"))
                            } else {
                                self.selectedItems.removeAll()
                                self.hideToolbarItems()
                                self.reloadCurrentDirectory()
                            }
                        }
                    }
                },
                SantanderActionSheetItem(title: SantanderL10n.t("Cancel"), style: .cancel)
            ])
        }

        let trash = UIBarButtonItem(systemItem: .trash, primaryAction: trashAction)
        trash.tintColor = UIColor.systemRed

        let shareAction = UIAction {
            self.presentActivityVC(forItems: self.selectedItems)
        }

        let share = UIBarButtonItem(image: SantanderIconLibrary.shared.interfaceIcon(for: "square.and.arrow.up"), primaryAction: shareAction)
        let moveAction = UIAction { [weak self] _ in
            guard let self else { return }
            self.presentOperationVC(forItems: self.selectedItems.map(\.url), type: .move)
        }
        let copyAction = UIAction { [weak self] _ in
            guard let self else { return }
            UIPasteboard.general.urls = self.selectedItems.map(\.url)
            self.setEditing(false, animated: true)
        }
        let move = UIBarButtonItem(image: SantanderIconLibrary.shared.interfaceIcon(for: "arrow.right"), primaryAction: moveAction)
        let copy = UIBarButtonItem(image: SantanderIconLibrary.shared.interfaceIcon(for: "doc.on.doc"), primaryAction: copyAction)
        let moreItems = UIBarButtonItem(image: SantanderIconLibrary.shared.interfaceIcon(for: "ellipsis.circle"), style: .plain, target: self, action: #selector(showToolbarMoreItems))
        let items = [trash, .flexibleSpace(), share, .flexibleSpace(), move, .flexibleSpace(), copy, .flexibleSpace(), moreItems].map { item in
            item.isEnabled = !selectedItems.isEmpty
            return item
        }

        updateSelectedCountTitle()
        self.toolbarItems = items
        self.navigationController?.setToolbarHidden(false, animated: true)
        self.navigationController?.toolbar.viewWithTag(100)?.removeFromSuperview()
    }

    @objc
    func hideToolbarItems() {
        self.toolbarItems = []
        self.navigationController?.setToolbarHidden(true, animated: true)

        setupAudioToolbarIfPossible()
    }

    @objc fileprivate func showToolbarMoreItems() {
        let paths = selectedItems
        guard !paths.isEmpty else { return }
        var actions: [SantanderActionSheetItem] = [
            SantanderActionSheetItem(title: SantanderL10n.t("Alias"), image: SantanderIconLibrary.shared.interfaceIcon(for: "link")) { [weak self] in
                guard let self else { return }
                self.present(UINavigationController(rootViewController: PathOperationViewController(paths: paths.toURL(), operationType: .symlink)), animated: true)
            },
            SantanderActionSheetItem(title: SantanderL10n.t("Move"), image: SantanderIconLibrary.shared.interfaceIcon(for: "arrow.right")) { [weak self] in
                guard let self else { return }
                self.present(UINavigationController(rootViewController: PathOperationViewController(paths: paths.toURL(), operationType: .move)), animated: true)
            },
            SantanderActionSheetItem(title: "复制到…", image: SantanderIconLibrary.shared.interfaceIcon(for: "doc.on.doc")) { [weak self] in
                guard let self else { return }
                self.present(UINavigationController(rootViewController: PathOperationViewController(paths: paths.toURL(), operationType: .copy)), animated: true)
            },
            SantanderActionSheetItem(title: SantanderL10n.t("Batch Rename"), image: SantanderIconLibrary.shared.interfaceIcon(for: "textformat.abc")) { [weak self] in self?.presentBatchRename(for: paths) }
        ]
        if let currentPath {
            actions.append(SantanderActionSheetItem(title: SantanderL10n.t("Compress"), image: SantanderIconLibrary.shared.interfaceIcon(for: "archivebox")) { [weak self] in
                self?.presentCompressionOptions(paths: paths) { format in currentPath.appending("Archive").appendingPathExtension(format.fileExtension) }
            })
        }
        actions.append(SantanderActionSheetItem(title: SantanderL10n.t("Cancel"), style: .cancel))
        presentSantanderActionSheet(title: SantanderL10n.t("More actions"), actions: actions)
    }

    func presentBatchRename(for items: [Path]) {
        guard !items.isEmpty else { return }
        let alert = UIAlertController(title: SantanderL10n.t("Batch Rename"), message: nil, preferredStyle: .alert)
        alert.addTextField { $0.placeholder = SantanderL10n.t("Find") }
        alert.addTextField { $0.placeholder = SantanderL10n.t("Replace with") }
        alert.addTextField { $0.placeholder = SantanderL10n.t("Prefix") }
        alert.addTextField { $0.placeholder = SantanderL10n.t("Suffix") }
        alert.addTextField { field in field.placeholder = SantanderL10n.t("Start number (optional)"); field.keyboardType = .numberPad }
        alert.addTextField { $0.placeholder = SantanderL10n.t("Date format (optional)") }
        alert.addAction(.cancel())
        alert.addAction(UIAlertAction(title: SantanderL10n.t("Apply"), style: .default) { [weak self, weak alert] _ in
            guard let self else { return }
            let fields = alert?.textFields ?? []
            let find = fields[safe: 0]?.text ?? ""
            let replace = fields[safe: 1]?.text ?? ""
            let prefix = fields[safe: 2]?.text ?? ""
            let suffix = fields[safe: 3]?.text ?? ""
            let startNumber = Int(fields[safe: 4]?.text ?? "")
            let dateFormat = fields[safe: 5]?.text ?? ""
            DispatchQueue.global(qos: .userInitiated).async { [weak self] in
                let formatter = DateFormatter()
                formatter.dateFormat = dateFormat.isEmpty ? nil : dateFormat
                var failures: [String] = []
                var changed = false
                for (index, item) in items.enumerated() {
                    let original = item.lastPathComponent
                    let ext = item.url.pathExtension
                    var base = ext.isEmpty ? original : String(original.dropLast(ext.count + 1))
                    if !find.isEmpty { base = base.replacingOccurrences(of: find, with: replace) }
                    base = prefix + base + suffix
                    if let startNumber { base += " \(startNumber + index)" }
                    else if items.count > 1 { base += " \(index + 1)" }
                    if !dateFormat.isEmpty, let dateString = formatter.string(for: item.url.lastModifiedDate) {
                        base += " " + dateString
                    }
                    let basename = ext.isEmpty ? base : base + "." + ext
                    guard basename != original else { continue }
                    let destination = item.deletingLastPathComponent().url.appendingPathComponent(basename)
                    do {
                        guard !FileManager.default.fileExists(atPath: destination.path) || destination == item.url else {
                            throw StringError("目标文件已存在：\(basename)")
                        }
                        try FSOperation.perform(.moveItem(items: [item.url], resultPath: destination), rootHelperConf: RootConf.shared)
                        changed = true
                    } catch { failures.append(error.localizedDescription) }
                }
                DispatchQueue.main.async { [weak self] in
                    guard let self else { return }
                    self.setEditing(false, animated: true)
                    if changed { self.reloadCurrentDirectory() }
                    if let firstFailure = failures.first { self.errorAlert(firstFailure, title: SantanderL10n.t("Batch Rename")) }
                }
            }
        })
        present(alert, animated: true)
    }

    @objc
    func setLeftBarSelectionButtonItem() {
        if !isEditing {
            navigationItem.leftBarButtonItem = nil
            return
        }

        let contents = self.contents
        let allItemsSelected = selectedItems.count == contents.count
        let action = UIAction {
            for index in contents.indices {
                if !allItemsSelected {
                    self.tableView.selectRow(at: IndexPath(row: index, section: 0), animated: true, scrollPosition: .none)
                } else {
                    self.tableView.deselectRow(at: IndexPath(row: index, section: 0), animated: true)
                }
            }

            self.selectedItems = allItemsSelected ? [] : contents
            self.setLeftBarSelectionButtonItem()
        }

        self.navigationItem.leftBarButtonItem = UIBarButtonItem(title: allItemsSelected ? SantanderL10n.t("Deselect All") : SantanderL10n.t("Select All"), primaryAction: action)
        setupOrUpdateToolbar()
    }

    func setupAudioToolbarIfPossible() {
        guard let audioPlayerController = audioPlayerController, let toolbar = navigationController?.toolbar else {
            return
        }

        navigationController?.setToolbarHidden(false, animated: true)

        toolbar.viewWithTag(100)?.removeFromSuperview()
        let audioToolbarView = AudioPlayerToolbarView(audioPlayerController, frame: toolbar.bounds)
        audioToolbarView.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        audioToolbarView.delegate = self
        audioToolbarView.tag = 100
        audioToolbarView.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(toolbarAudioPreviewWasTapped)))
        toolbar.addSubview(audioToolbarView)
    }

    @objc
    func toolbarAudioPreviewWasTapped() {
        guard let vc = audioPlayerController else {
            return
        }

        UIApplication.shared.sceneKeyWindow?.rootViewController?.present(UINavigationController(rootViewController: vc), animated: true)
    }

    func audioToolbarDidClickCancelButton(_ toolbar: AudioPlayerToolbarView) {
        let rootNav = UIApplication.shared.sceneKeyWindow?.rootViewController as? UINavigationController
        rootNav?.toolbar?.viewWithTag(100)?.removeFromSuperview()
        rootNav?.setToolbarHidden(true, animated: true)

        toolbar.audioPlayerController.player.stop()
        toolbar.audioPlayerController.removeFromSystemMediaPlayer()
        self.audioPlayerController = nil
    }
}

class PathOperationViewController: PathListViewController {

    let paths: [URL]
    let operationType: PathSelectionOperation
    let dismissWhenDone: Bool

    private var operationRunning = false
    private var operationCancelRequested = false
    private var operationProcessID: pid_t = 0
    private weak var operationPanel: UIView?
    private weak var operationProgressView: UIProgressView?
    private weak var operationStatusLabel: UILabel?
    private weak var operationCancelButton: UIButton?
    private var operationQueueObserver: NSObjectProtocol?
    private var operationPanelOriginalContentInset: UIEdgeInsets?
    private var operationPanelOriginalScrollIndicatorInsets: UIEdgeInsets?

    init(paths: [URL], operationType: PathSelectionOperation, startingPath: Path = .root, dismissWhenDone: Bool = true) {
        self.paths = paths
        self.operationType = operationType
        self.dismissWhenDone = dismissWhenDone

        super.init(path: startingPath)
    }

    required init?(coder: NSCoder) {
        fatalError("Not implemented")
    }

    deinit {
        if let observer = operationQueueObserver {
            NotificationCenter.default.removeObserver(observer)
        }
    }

    override func viewDidLoad() {
        super.viewDidLoad()

        self.navigationController?.navigationBar.prefersLargeTitles = false
        self.title = self.operationType.verbDescription
        if let currentPath = self.currentPath {
            self.navigationItem.backBarButtonItem = UIBarButtonItem(title: currentPath.lastPathComponent, style: .plain, target: nil, action: nil)
        }

        for path in paths {
            _ = path.startAccessingSecurityScopedResource()
        }
    }

    @objc func done() {
        guard !operationRunning else { return }
        guard let currentPath = self.currentPath else {
            self.errorAlert("无法获取用于\(operationType.description)的当前路径。", title: "无法\(operationType.description)路径")
            return
        }

        switch operationType {
        case .move:
            startProgressiveOperation(.moveItem(items: paths, resultPath: currentPath.url), destination: currentPath)
        case .copy, .import:
            startProgressiveOperation(.copyItem(items: paths, resultPath: currentPath.url), destination: currentPath)
        case .symlink:
            startProgressiveOperation(.symlink(items: paths, resultPath: currentPath.url), destination: currentPath)
        case .custom(_, _, let action):
            do {
                try action(self, currentPath.url)
            } catch {
                self.errorAlert(error, title: "无法\(operationType.description)项目")
            }
        }
    }

    private func startProgressiveOperation(_ operation: FSOperation, destination: Path) {
        guard !operationRunning else { return }
        operationRunning = true
        operationCancelRequested = false
        operationProcessID = 0
        setOperationControls(locked: true)
        installOperationProgressPanel()

        let operationType = self.operationType
        let taskID = SantanderFileOperationQueue.shared.enqueue(title: operationType.verbDescription, work: { [weak self] onProcessID, report in
            guard let self else { return }
            do {
                try RootConf.shared.performStreaming(
                    operation,
                    onStdoutLine: { line in
                        let parts = line.split(separator: " ")
                        guard parts.count >= 3,
                              parts[0] == "SANTANDER_PROGRESS",
                              let completed = Int(parts[1]),
                              let total = Int(parts[2]),
                              total > 0 else { return }
                        let fraction = max(0, min(1, Double(completed) / Double(total)))
                        DispatchQueue.main.async { [weak self] in
                            guard let self else { return }
                            self.operationProgressView?.setProgress(Float(fraction), animated: completed > 0)
                            self.operationStatusLabel?.text = completed >= total
                                ? SantanderL10n.t("Completed")
                                : "\(operationType.verbDescription)  \(completed)/\(total)"
                        }
                        report(fraction, completed >= total ? SantanderL10n.t("Completed") : "\(completed)/\(total)")
                    },
                    onProcessID: { pid in
                        onProcessID(pid)
                        DispatchQueue.main.async { [weak self] in
                            guard let self else { return }
                            self.operationProcessID = pid
                            if self.operationCancelRequested { RootConf.cancel(processID: pid) }
                        }
                    }
                )
            } catch {
                throw error
            }
        })

        if let existingObserver = operationQueueObserver {
            NotificationCenter.default.removeObserver(existingObserver)
        }
        let observer = NotificationCenter.default.addObserver(forName: SantanderFileOperationQueue.didChangeNotification, object: SantanderFileOperationQueue.shared, queue: .main) { [weak self] _ in
            guard let self, self.operationRunning else { return }
            let active = SantanderFileOperationQueue.shared.snapshots().first { $0.id == taskID && ($0.state == .finished || $0.state == .failed || $0.state == .cancelled) }
            guard let active else { return }
            self.operationRunning = false
            self.operationProcessID = 0
            self.removeOperationProgressPanel()
            self.setOperationControls(locked: false)
            if active.state == .finished {
                self.reloadCurrentDirectory()
                if self.dismissWhenDone { self.dismiss(animated: true) }
            } else if active.state == .failed && !self.operationCancelRequested {
                self.errorAlert(active.message, title: "无法\(operationType.description)项目")
            }
            if let observer = self.operationQueueObserver {
                NotificationCenter.default.removeObserver(observer)
            }
            self.operationQueueObserver = nil
        }
        operationQueueObserver = observer
        _ = destination
    }

    private func installOperationProgressPanel() {
        removeOperationProgressPanel()
        operationPanelOriginalContentInset = tableView.contentInset
        operationPanelOriginalScrollIndicatorInsets = tableView.verticalScrollIndicatorInsets
        tableView.contentInset.top += 124
        tableView.verticalScrollIndicatorInsets.top += 124

        let panel = UIView()
        panel.backgroundColor = UIColor.secondarySystemBackground.withAlphaComponent(0.96)
        panel.layer.cornerRadius = 16
        panel.layer.cornerCurve = .continuous
        panel.layer.borderWidth = 0.5
        panel.layer.borderColor = UIColor.separator.withAlphaComponent(0.3).cgColor
        panel.translatesAutoresizingMaskIntoConstraints = false

        let label = UILabel()
        label.text = operationType.verbDescription
        label.font = .preferredFont(forTextStyle: .headline)
        label.numberOfLines = 2
        label.translatesAutoresizingMaskIntoConstraints = false

        let progress = UIProgressView(progressViewStyle: .default)
        progress.progress = 0
        progress.translatesAutoresizingMaskIntoConstraints = false

        let status = UILabel()
        status.text = SantanderL10n.t("Preparing...")
        status.font = .preferredFont(forTextStyle: .subheadline)
        status.textColor = .secondaryLabel
        status.numberOfLines = 1
        status.translatesAutoresizingMaskIntoConstraints = false

        let cancel = UIButton(type: .system)
        cancel.setTitle(SantanderL10n.t("Cancel"), for: .normal)
        cancel.accessibilityHint = SantanderL10n.t("Cancel current filesystem operation")
        cancel.translatesAutoresizingMaskIntoConstraints = false
        cancel.addAction(UIAction { [weak self] _ in
            self?.confirmCancelCurrentOperation()
        }, for: .touchUpInside)

        guard let containerView = navigationController?.view ?? viewIfLoaded else { return }
        containerView.addSubview(panel)
        panel.addSubview(label)
        panel.addSubview(progress)
        panel.addSubview(status)
        panel.addSubview(cancel)

        let guide = containerView.safeAreaLayoutGuide
        NSLayoutConstraint.activate([
            panel.leadingAnchor.constraint(equalTo: guide.leadingAnchor, constant: 18),
            panel.trailingAnchor.constraint(equalTo: guide.trailingAnchor, constant: -18),
            panel.topAnchor.constraint(equalTo: guide.topAnchor, constant: 8),
            label.leadingAnchor.constraint(equalTo: panel.layoutMarginsGuide.leadingAnchor),
            label.trailingAnchor.constraint(equalTo: panel.layoutMarginsGuide.trailingAnchor),
            label.topAnchor.constraint(equalTo: panel.layoutMarginsGuide.topAnchor),
            progress.leadingAnchor.constraint(equalTo: label.leadingAnchor),
            progress.trailingAnchor.constraint(equalTo: label.trailingAnchor),
            progress.topAnchor.constraint(equalTo: label.bottomAnchor, constant: 12),
            status.leadingAnchor.constraint(equalTo: label.leadingAnchor),
            status.centerYAnchor.constraint(equalTo: cancel.centerYAnchor),
            status.trailingAnchor.constraint(lessThanOrEqualTo: cancel.leadingAnchor, constant: -12),
            cancel.trailingAnchor.constraint(equalTo: label.trailingAnchor),
            cancel.topAnchor.constraint(equalTo: progress.bottomAnchor, constant: 12),
            cancel.bottomAnchor.constraint(equalTo: panel.layoutMarginsGuide.bottomAnchor),
            panel.widthAnchor.constraint(greaterThanOrEqualToConstant: 260)
        ])

        operationPanel = panel
        operationProgressView = progress
        operationStatusLabel = status
        operationCancelButton = cancel
        let detailsTap = UITapGestureRecognizer(target: self, action: #selector(showOperationDetails))
        detailsTap.cancelsTouchesInView = false
        status.isUserInteractionEnabled = true
        status.addGestureRecognizer(detailsTap)
        status.accessibilityHint = "轻点查看操作详情"
    }

    private func removeOperationProgressPanel() {
        operationPanel?.removeFromSuperview()
        operationPanel = nil
        operationProgressView = nil
        operationStatusLabel = nil
        operationCancelButton = nil
        if let original = operationPanelOriginalContentInset {
            tableView.contentInset = original
            operationPanelOriginalContentInset = nil
        }
        if let original = operationPanelOriginalScrollIndicatorInsets {
            tableView.verticalScrollIndicatorInsets = original
            operationPanelOriginalScrollIndicatorInsets = nil
        }
    }

    @objc private func showOperationDetails() {
        let progress = Int((operationProgressView?.progress ?? 0) * 100)
        let status = operationStatusLabel?.text ?? SantanderL10n.t("Preparing...")
        let alert = UIAlertController(title: "操作详情", message: "\(operationType.verbDescription)\n\(status)\n进度：\(progress)%\n取消操作不会撤销已完成的文件项目。", preferredStyle: .alert)
        alert.addAction(.cancel())
        present(alert, animated: true)
    }

    private func setOperationControls(locked: Bool) {
        navigationItem.rightBarButtonItems?.forEach { $0.isEnabled = !locked }
        navigationItem.leftBarButtonItem?.isEnabled = !locked
        operationCancelButton?.isEnabled = locked
        tableView.isUserInteractionEnabled = true
        tableView.allowsSelection = !locked
    }

    @objc private func confirmCancelCurrentOperation() {
        guard operationRunning else { return }
        presentSantanderActionSheet(title: "确认取消当前操作？", message: "已完成的文件操作不会自动回滚。", actions: [
            SantanderActionSheetItem(title: SantanderL10n.t("Cancel operation"), image: SantanderIconLibrary.shared.interfaceIcon(for: "xmark.circle"), style: .destructive) { [weak self] in self?.cancelCurrentOperation() },
            SantanderActionSheetItem(title: SantanderL10n.t("Keep running"), style: .cancel)
        ])
    }

    @objc private func cancelCurrentOperation() {
        guard operationRunning else { return }
        operationCancelRequested = true
        operationStatusLabel?.text = SantanderL10n.t("Cancelling...")
        operationCancelButton?.isEnabled = false
        if operationProcessID > 0 {
            RootConf.cancel(processID: operationProcessID)
        }
    }

    override func goToPath(path: Path) {
        let parentDirectory = path.deletingLastPathComponent()

        if parentDirectory != currentPath {
            traverseThroughPath(path)
            return
        }

        if path.isDirectory {
            self.navigationController?.pushViewController(PathOperationViewController(paths: paths, operationType: operationType, startingPath: path, dismissWhenDone: dismissWhenDone), animated: false)
        } else {
            self.goToFile(path: path)
        }
    }

    override func traverseThroughPath(_ path: Path) {
        let vcs = path.url.fullPathComponents().map { [self] newPath in
            PathOperationViewController(paths: paths, operationType: operationType, startingPath: Path(url: newPath), dismissWhenDone: dismissWhenDone)
        }

        self.navigationController?.setViewControllers(vcs, animated: false)
    }

    @objc
    func cancel() {
        if operationRunning {
            cancelCurrentOperation()
            return
        }
        self.dismiss(animated: true)
    }

    override func setRightBarButton() {
        let doneButton = UIBarButtonItem(barButtonSystemItem: .done, target: self, action: #selector(done))
        let options = UIBarButtonItem(image: .init(systemName: "ellipsis.circle"), style: .plain, target: self, action: #selector(showRightBarActions))
        self.navigationItem.rightBarButtonItems = [doneButton, options]
    }

    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)

        if operationRunning {
            operationCancelRequested = true
            if operationProcessID > 0 { RootConf.cancel(processID: operationProcessID) }
        }

        for path in paths {
            path.stopAccessingSecurityScopedResource()
        }
    }
}

enum PathSelectionOperation: CustomStringConvertible {
    case move
    case copy
    case `import`
    case symlink
    case custom(description: String, verbDescription: String, action: (PathOperationViewController, URL) throws -> Void)

    var description: String {
        switch self {
        case .move:
            return SantanderL10n.t("move")
        case .copy:
            return SantanderL10n.t("copy")
        case .import:
            return SantanderL10n.t("import")
        case .symlink:
            return SantanderL10n.t("symlink")
        case .custom(description: let description, _, _):
            return description
        }
    }

    var verbDescription: String {
        switch self {
        case .move:
            return SantanderL10n.t("Moving to..")
        case .copy:
            return SantanderL10n.t("Copying to..")
        case .import:
            return SantanderL10n.t("Importing to..")
        case .symlink:
            return SantanderL10n.t("Aliasing to..")
        case .custom(_, verbDescription: let verbDescription, _):
            return verbDescription
        }
    }
}

extension PathListViewController: UITableViewDropDelegate, UITableViewDragDelegate {

    func tableView(_ tableView: UITableView, performDropWith coordinator: UITableViewDropCoordinator) {
        for item in coordinator.items {
            item.dragItem.itemProvider.loadFileRepresentation(forTypeIdentifier: "public.item") { url, err in
                guard let url = url, err == nil else {
                    DispatchQueue.main.async {
                        self.errorAlert("Error: \(err?.localizedDescription ?? SantanderL10n.t("Unknown"))", title: SantanderL10n.t("Failed to import file"))
                    }
                    return
                }

                guard let currentPath = self.currentPath else {
                    return
                }

                do {
                    try FSOperation.perform(.moveItem(items: [url], resultPath: currentPath.url), rootHelperConf: RootConf.shared)
                } catch {
                    DispatchQueue.main.async {
                        self.errorAlert("Error: \(error.localizedDescription)", title: SantanderL10n.t("Failed to copy item"))
                    }
                }
            }
        }
    }

    func tableView(_ tableView: UITableView, canHandle session: UIDropSession) -> Bool {
        return currentPath != nil
    }

    func tableView(_ tableView: UITableView, itemsForBeginning session: UIDragSession, at indexPath: IndexPath) -> [UIDragItem] {
        guard !displayingSearchSuggestions else {
            return []
        }

        guard let selectedItem = path(forIndexPath: indexPath) else { return [] }
        let itemProvider = NSItemProvider()

        let typeID = selectedItem.contentType?.identifier ?? UTType.content.identifier

        itemProvider.registerFileRepresentation(
            forTypeIdentifier: typeID,
            visibility: .all) { completion in
                completion(selectedItem.url, true, nil)
                return nil
            }

        return [
            UIDragItem(itemProvider: itemProvider)
        ]
    }
}

class RenamerTextField: UITextField {
    override var canBecomeFirstResponder: Bool {
        true
    }

    let path: Path
    var notifyShouldReturnUponResigning: Bool = true

    init(path: Path) {
        self.path = path
        super.init(frame: .zero)
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    @discardableResult
    override func resignFirstResponder() -> Bool {
        if notifyShouldReturnUponResigning {
            return delegate?.textFieldShouldReturn?(self) ?? true
        }

        return super.resignFirstResponder()
    }
}

class PathInformationTableViewController: UITableViewController {
    let path: Path
    private(set) var metadata: PathMetadata
    private var showByteCount = false
    private var showDisplayName = false
    private var showRealPath = false
    private var showAppName: Bool
    private var appName: String?
    private var sizeState: LoadingValueState<Int> = .loading
    private var itemCountState: LoadingValueState<Int> = .loading

    init(style: UITableView.Style, path: Path) {
        self.path = path
        self.metadata = PathMetadata(filePath: path)
        appName = path.applicationItem?.localizedName
        showAppName = appName != nil
        super.init(style: style)
    }

    required init?(coder: NSCoder) { fatalError("init(coder:) has not been implemented") }

    override func viewDidLoad() {
        super.viewDidLoad()
        applySantanderUI()
        title = path.lastPathComponent.isEmpty ? "/" : path.lastPathComponent
        navigationItem.leftBarButtonItem = UIBarButtonItem(title: "完成", style: .plain, target: self, action: #selector(closeInfo))
        tableView.rowHeight = 44
        tableView.estimatedRowHeight = 44
        tableView.separatorInset = UIEdgeInsets(top: 0, left: 20, bottom: 0, right: 0)
        refreshSizeInBackground()
    
        SantanderLongPressSupport.install(on: tableView) { [weak self] point in
            self?.presentCopyValueAction(at: point)
        }
}

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        metadata = PathMetadata(filePath: path)
        tableView.reloadData()
    }

    @objc private func closeInfo() {
        if let navigationController,
           navigationController.viewControllers.first !== self {
            navigationController.popViewController(animated: true)
        } else {
            dismiss(animated: true)
        }
    }

    func refreshMetadataAfterOwnershipChange() {
        metadata = PathMetadata(filePath: path)
        tableView.reloadData()
    }

    private func refreshSizeInBackground() {
        let rootURL = path.url
        let isDirectory = path.isDirectory
        DispatchQueue.global(qos: .utility).async { [weak self] in
            var totalSize = 0
            var itemCount: Int?
            var succeeded = false

            if isDirectory {
                var pending = [rootURL]
                var visitedDirectories = Set<String>()
                let rootKey = rootURL.standardizedFileURL.path
                var visitedNodes = 0

                while let currentURL = pending.popLast() {
                    visitedNodes += 1
                    if visitedNodes > 150_000 { break }
                    let key = currentURL.standardizedFileURL.path
                    var info = stat()
                    guard lstat(currentURL.path, &info) == 0 else { continue }
                    let fileType = info.st_mode & S_IFMT
                    let isRoot = key == rootKey

                    if fileType == S_IFLNK && !(isRoot && isDirectory) {
                        totalSize += max(0, Int(info.st_size))
                        succeeded = true
                        continue
                    }

                    if fileType == S_IFDIR || (isRoot && isDirectory) {
                        guard visitedDirectories.insert(key).inserted else { continue }
                        do {
                            let children = try FileManager.default.contentsOfDirectory(at: currentURL, includingPropertiesForKeys: nil, options: [])
                            if isRoot { itemCount = children.count }
                            pending.append(contentsOf: children)
                            succeeded = true
                        } catch {
                            if isRoot { itemCount = nil }
                        }
                    } else {
                        totalSize += max(0, Int(info.st_size))
                        succeeded = true
                    }
                }
            } else {
                var info = stat()
                if lstat(rootURL.path, &info) == 0 {
                    totalSize = max(0, Int(info.st_size))
                    succeeded = true
                }
            }

            DispatchQueue.main.async {
                guard let self else { return }
                self.sizeState = succeeded ? .value(totalSize) : .unavailable
                if isDirectory {
                    if let itemCount {
                        self.itemCountState = .value(itemCount)
                    } else {
                        self.itemCountState = .unavailable
                    }
                }
                self.tableView.reloadData()
            }
        }
    }

    override func numberOfSections(in tableView: UITableView) -> Int { 6 }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        switch section {
        case 0: return path.isDirectory ? 3 : 2
        case 1: return metadata.permissions == nil ? 0 : 2
        case 2: return metadata.permissions == nil ? 0 : 3
        case 3: return 2
        case 4: return 3
        case 5: return 3
        default: return 0
        }
    }

    override func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        switch section {
        case 0: return nil
        case 1: return "所有者"
        case 2: return "访问权限"
        case 3: return "最后修改"
        case 4: return "其他日期"
        case 5: return "详细信息"
        default: return nil
        }
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = UITableViewCell(style: .value1, reuseIdentifier: nil)
        SantanderUI.styleCell(cell)
        var conf = cell.defaultContentConfiguration()

        switch indexPath.section {
        case 0:
            if indexPath.row == 0 {
                conf.text = "类型"
                conf.secondaryText = path.isDirectory ? "Directory" : (metadata.contentType?.localizedDescription?.localizedCapitalized ?? path.pathExtension.uppercased())
            } else if path.isDirectory && indexPath.row == 1 {
                conf.text = "项目"
                switch itemCountState {
                case .loading: conf.secondaryText = "…"
                case .unavailable: conf.secondaryText = "—"
                case .value(let count): conf.secondaryText = count.description
                }
            } else {
                conf.text = "大小"
                switch sizeState {
                case .loading:
                    conf.secondaryText = "…"
                case .unavailable:
                    conf.secondaryText = "—"
                case .value(let size):
                    let formatter = ByteCountFormatter()
                    formatter.countStyle = .file
                    formatter.allowedUnits = .useAll
                    formatter.includesActualByteCount = showByteCount
                    conf.secondaryText = formatter.string(fromByteCount: Int64(size))
                }
                cell.accessoryType = .disclosureIndicator
            }
        case 1:
            guard let permissions = metadata.permissions else { return cell }
            if indexPath.row == 0 {
                conf.text = "所有者"
                conf.secondaryText = permissions.ownerName ?? "UID \(permissions.ownerID)"
            } else {
                conf.text = "组"
                conf.secondaryText = permissions.groupOwnerName ?? "GID \(permissions.groupID)"
            }
            conf.secondaryTextProperties.color = SantanderAppTheme.accentColor
            cell.accessoryType = .disclosureIndicator
        case 2:
            guard let permissions = metadata.permissions else { return cell }
            let values = [permissions.ownerPermissions, permissions.groupPermissions, permissions.otherUsersPermissions]
            let titles = ["所有者", "组", "其他组"]
            let names = ["读取", "写入", "执行"]
            conf.text = titles[indexPath.row]
            conf.secondaryText = names.enumerated().compactMap { offset, name in
                values[indexPath.row].contains([Permission.read, .write, .execute][offset]) ? name : nil
            }.joined(separator: "，")
            conf.secondaryTextProperties.color = SantanderAppTheme.accentColor
            cell.accessoryType = .disclosureIndicator
        case 3:
            let modified = metadata.lastModifiedDate
            if indexPath.row == 0 {
                conf.text = "日期"
                if let modified {
                    let formatter = DateFormatter()
                    formatter.locale = Locale(identifier: "zh_CN")
                    formatter.dateStyle = .medium
                    formatter.timeStyle = .none
                    conf.secondaryText = formatter.string(from: modified)
                } else { conf.secondaryText = "—" }
            } else {
                conf.text = "时间"
                if let modified {
                    let formatter = DateFormatter()
                    formatter.locale = Locale(identifier: "zh_CN")
                    formatter.dateStyle = .none
                    formatter.timeStyle = .medium
                    conf.secondaryText = formatter.string(from: modified)
                } else { conf.secondaryText = "—" }
            }
        case 4:
            switch indexPath.row {
            case 0:
                conf.text = "创建"
                conf.secondaryText = metadata.creationDate?.listFormatted() ?? "—"
            case 1:
                conf.text = "添加"
                conf.secondaryText = metadata.addedToDirectoryDate?.listFormatted() ?? "—"
            default:
                conf.text = "访问"
                conf.secondaryText = metadata.lastAccessedDate?.listFormatted() ?? "—"
            }
        case 5:
            switch indexPath.row {
            case 0:
                conf.text = showDisplayName ? "显示名称" : "名称"
                if showDisplayName { conf.secondaryText = path.displayName }
                else if showAppName { conf.secondaryText = appName }
                else { conf.secondaryText = path.lastPathComponent.isEmpty ? "/" : path.lastPathComponent }
                cell.accessoryType = (path.displayName != path.lastPathComponent || appName != nil) ? .disclosureIndicator : .none
            case 1:
                conf.text = showRealPath ? "真实路径" : "路径"
                conf.secondaryText = showRealPath ? path.resolvedURL.path : path.path
                cell.accessoryType = (try? FileManager.default.destinationOfSymbolicLink(atPath: path.path)) != nil ? .disclosureIndicator : .none
            default:
                conf.text = "MIME 类型"
                conf.secondaryText = metadata.contentType?.preferredMIMEType ?? "—"
            }
        default: break
        }
        cell.contentConfiguration = conf
        return cell
    }

    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        if indexPath.section == 0, indexPath.row == (path.isDirectory ? 2 : 1) {
            showByteCount.toggle()
            tableView.reloadRows(at: [indexPath], with: .none)
            return
        }
        if indexPath.section == 1, let permissions = metadata.permissions {
            let type: PathGroupOwnerViewController.ItemType = indexPath.row == 0
                ? .owner(id: permissions.ownerID, name: permissions.ownerName)
                : .group(id: permissions.groupID, name: permissions.groupOwnerName)
            let chooser = PathGroupOwnerViewController(style: .plain, type: type, fileURL: path.url, sourceInformationVC: self)
            navigationController?.pushViewController(chooser, animated: true)
            return
        }
        if indexPath.section == 2, let permissions = metadata.permissions {
            navigationController?.pushViewController(PathPermissionsViewController(permissions: permissions), animated: true)
            return
        }
        if indexPath.section == 5 {
            if indexPath.row == 0, path.displayName != path.lastPathComponent || appName != nil {
                if appName != nil { showAppName.toggle() } else { showDisplayName.toggle() }
                tableView.reloadRows(at: [indexPath], with: .none)
            } else if indexPath.row == 1,
                      (try? FileManager.default.destinationOfSymbolicLink(atPath: path.path)) != nil {
                showRealPath.toggle()
                tableView.reloadRows(at: [indexPath], with: .none)
            }
        }
    }

    override func tableView(_ tableView: UITableView, shouldHighlightRowAt indexPath: IndexPath) -> Bool {
        if indexPath.section == 0 { return indexPath.row == (path.isDirectory ? 2 : 1) }
        if indexPath.section == 1 || indexPath.section == 2 { return metadata.permissions != nil }
        if indexPath.section == 5, indexPath.row == 0 { return path.displayName != path.lastPathComponent || appName != nil }
        if indexPath.section == 5, indexPath.row == 1 { return (try? FileManager.default.destinationOfSymbolicLink(atPath: path.path)) != nil }
        return false
    }

    private func presentCopyValueAction(at point: CGPoint) {
        guard let indexPath = tableView.indexPathForRow(at: point),
              let cell = tableView.cellForRow(at: indexPath),
              let conf = cell.contentConfiguration as? UIListContentConfiguration,
              let value = conf.secondaryText, !value.isEmpty else { return }
        presentSantanderActionSheet(title: conf.text, actions: [
            SantanderActionSheetItem(title: SantanderL10n.t("Copy"), image: SantanderIconLibrary.shared.interfaceIcon(for: "doc.on.doc")) { UIPasteboard.general.string = value },
            SantanderActionSheetItem(title: SantanderL10n.t("Cancel"), style: .cancel)
        ])
    }

}


class AssetCatalogViewController: UIViewController {
    typealias DataSource = UICollectionViewDiffableDataSource<RenditionType, Rendition>
    typealias SupplementaryRegistration = UICollectionView.SupplementaryRegistration<AssetCatalogSectionHeader>
    typealias CellRegistration = UICollectionView.CellRegistration<AssetCatalogCell, Rendition>

    static let titleElementKind = "RenditionTypeTitle"

    let fileURL: URL
    var renditionCollection: RenditionCollection
    var catalog: CUICatalog
    fileprivate var editorDelegate: ItemEditorDelegate?

    var collectionView: UICollectionView!
    var dataSource: DataSource!
    var noResultsLabel: UILabel = UILabel()
    fileprivate var collapsedRenditionSections: Set<RenditionType> = []
    private var displayedRenditionCollection: RenditionCollection = []
    var layoutMode: LayoutMode = LayoutMode(UserPreferences.assetCatalogControllerLayoutMode) {
        didSet {
            collectionView.setCollectionViewLayout(createLayout(), animated: true)
            UserPreferences.assetCatalogControllerLayoutMode = layoutMode.rawValue
        }
    }

    init(renditions: RenditionCollection, fileURL: URL, catalog: CUICatalog) {
        self.renditionCollection = renditions
        self.fileURL = fileURL
        self.catalog = catalog
        super.init(nibName: nil, bundle: nil)
    }

    convenience init(catalogFileURL fileURL: URL) throws {
        let (catalog, renditions) = try AssetCatalogWrapper.shared.renditions(forCarArchive: fileURL)
        self.init(renditions: renditions, fileURL: fileURL, catalog: catalog)
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    override func viewDidLoad() {
        super.viewDidLoad()

        if !UIDevice.isiPad {
            let filename = fileURL.deletingPathExtension()
            title = filename.lastPathComponent
            navigationController?.navigationBar.prefersLargeTitles = true
        }

        navigationItem.hidesSearchBarWhenScrolling = false

        let searchController = UISearchController()
        searchController.searchBar.delegate = self
        navigationItem.searchController = searchController

        configureCollectionView()
        configureDataSource()
        if let collectionView {
            SantanderLongPressSupport.install(on: collectionView) { [weak self] point in
                guard let self, let indexPath = collectionView.indexPathForItem(at: point),
                      let item = self.dataSource.itemIdentifier(for: indexPath) else { return }
                self.presentRenditionActions(for: item)
            }
        }

        setupBarItems()
    }

    override var keyCommands: [UIKeyCommand]? {
        return [
            UIKeyCommand(title: SantanderL10n.t("Scroll Up"), action: #selector(goUpOrDown(sender:)), input: UIKeyCommand.inputUpArrow, modifierFlags: .command),
            UIKeyCommand(title: SantanderL10n.t("Scroll Down"), action: #selector(goUpOrDown(sender:)), input: UIKeyCommand.inputDownArrow, modifierFlags: .command)
        ]
    }

    @objc
    func goUpOrDown(sender: UIKeyCommand) {
        switch sender.input {
        case UIKeyCommand.inputDownArrow:
            let snapshot = dataSource.snapshot()
            if let last = snapshot.sectionIdentifiers.last {
                let section = snapshot.sectionIdentifiers.count
                let row = snapshot.itemIdentifiers(inSection: last).count
                collectionView.scrollToItem(at: IndexPath(row: row - 1, section: section - 1), at: .bottom, animated: true)
            }
        case UIKeyCommand.inputUpArrow:
            collectionView.scrollToItem(at: IndexPath(row: 0, section: 0), at: .top, animated: true)
        default:
            break
        }
    }

    func configureCollectionView() {
        self.collectionView = UICollectionView(frame: .zero, collectionViewLayout: createLayout())
        collectionView.translatesAutoresizingMaskIntoConstraints = false
        collectionView.backgroundColor = .systemBackground
        collectionView.dragDelegate = self
        collectionView.delegate = self
        view.addSubview(collectionView)
        collectionView.constraintCompletely(to: view)
    }

    @objc func showCatalogBarOptions() {
        var actions: [SantanderActionSheetItem] = [
            SantanderActionSheetItem(title: SantanderL10n.t("Extract to.."), image: SantanderIconLibrary.shared.interfaceIcon(for: "arrow.down.doc")) { [weak self] in self?.extractAction() }
        ]
        actions.append(contentsOf: LayoutMode.allCases.map { [weak self] mode in
            SantanderActionSheetItem(title: mode.description, image: SantanderIconLibrary.shared.interfaceIcon(for: mode == .grid ? "square.grid.2x2" : "list.bullet"), isSelected: self?.layoutMode == mode) { [weak self] in
                self?.layoutMode = mode
                self?.setupBarItems()
            }
        })
        actions.append(SantanderActionSheetItem(title: SantanderL10n.t("Cancel"), style: .cancel))
        presentSantanderActionSheet(title: SantanderL10n.t("Asset Catalog"), actions: actions)
    }

    func setupBarItems() {
        let dismissAction = UIAction { [weak self] _ in
            guard let self else { return }
            if let navigationController = self.navigationController,
               navigationController.viewControllers.first !== self,
               navigationController.topViewController === self {
                navigationController.popViewController(animated: true)
            } else {
                self.dismiss(animated: true)
            }
        }

        let closeButton = UIBarButtonItem(systemItem: .close, primaryAction: dismissAction)
        let barButtonWithMenu = UIBarButtonItem(image: SantanderIconLibrary.shared.interfaceIcon(for: "ellipsis.circle"), style: .plain, target: self, action: #selector(showCatalogBarOptions))

        if UIDevice.isiPad {
            // The catalog is hosted by the outer detail navigation controller now;
            // do not put its controls on the file-browser sidebar.
            navigationItem.leftBarButtonItem = nil
            navigationItem.rightBarButtonItems = [barButtonWithMenu, closeButton]
        } else {
            navigationItem.rightBarButtonItem = closeButton
            navigationItem.leftBarButtonItem = barButtonWithMenu
        }
    }

    func extractAction() {
        let action: PathSelectionOperation = .custom(description: "extract", verbDescription: SantanderL10n.t("Extracting to..")) { [self] operationVC, selectedPath in
            let extractionPath = selectedPath
                .appendingPathComponent("\(fileURL.lastPathComponent)-Extracted")

            extractItems(extractionPath: extractionPath, sourceVC: operationVC) { error in
                if let error = error {
                    operationVC.errorAlert(error, title: SantanderL10n.t("Unable to extract items"))
                } else {
                    operationVC.dismiss(animated: true) {
                        self.dismiss(animated: true) {
                            let rootVC = UIApplication.shared.sceneKeyWindow?.rootViewController
                            let vcToPushFrom: PathTransitioning?

                            if UIDevice.isiPad {
                                vcToPushFrom = (rootVC as? UISplitViewController)?.viewController(for: .primary) as? PathTransitioning
                            } else {
                                vcToPushFrom = (rootVC as? UINavigationController)?.visibleViewController as? PathTransitioning
                            }

                            vcToPushFrom?.goToPath(path: Path(url: extractionPath))
                        }
                    }
                }
            }
        }

        let vc = PathOperationViewController(paths: [fileURL], operationType: action, dismissWhenDone: false)
        present(UINavigationController(rootViewController: vc), animated: true) {
            vc.goToPath(path: Path(url: self.fileURL.deletingLastPathComponent()))
        }
    }

    func extractItems(
        extractionPath savePath: URL,
        sourceVC: UIViewController,
        completionHandler: @escaping (Error?) -> Void
    ) {
        let alertController = createAlertWithSpinner(title: SantanderL10n.t("Extracting.."))
        sourceVC.present(alertController, animated: true)

        DispatchQueue.global(qos: .userInitiated).async {
            var caughtError: Error?

            do {
                try FSOperation.perform(.extractCatalog(catalogFileURL: self.fileURL, resultPath: savePath), rootHelperConf: RootConf.shared)
            } catch {
                caughtError = error
            }

            DispatchQueue.main.async {
                alertController.dismiss(animated: true) {
                    completionHandler(caughtError)
                }
            }
        }
    }

    enum LayoutMode: Int, CustomStringConvertible, CaseIterable {
        case horizantal
        case verical
        case grid

        init(_ rawValue: Int) {
            switch rawValue {
            case LayoutMode.horizantal.rawValue: self = .horizantal
            case LayoutMode.grid.rawValue: self = .grid
            default: self = .verical
            }
        }

        var description: String {
            switch self {
            case .horizantal:
                return SantanderL10n.t("Horizontal")
            case .verical:
                return SantanderL10n.t("Vertical")
            case .grid:
                return SantanderL10n.t("Grid")
            }
        }
    }
}

extension AssetCatalogViewController: UICollectionViewDelegate {
    func createLayout() -> UICollectionViewLayout {
        let section: NSCollectionLayoutSection

        switch layoutMode {
        case .verical:
            let itemSize = NSCollectionLayoutSize(widthDimension: .fractionalWidth(1.0),
                                                  heightDimension: .fractionalHeight(1.0))
            let item = NSCollectionLayoutItem(layoutSize: itemSize)
            let groupSize = NSCollectionLayoutSize(widthDimension: .fractionalWidth(1.0),
                                                   heightDimension: .absolute(60))

            let group = NSCollectionLayoutGroup.horizontal(layoutSize: groupSize, subitem: item, count: 1)
            let spacing = CGFloat(10)
            group.interItemSpacing = .fixed(spacing)

            section = NSCollectionLayoutSection(group: group)
            section.interGroupSpacing = spacing
            section.contentInsets = NSDirectionalEdgeInsets(top: 0, leading: spacing, bottom: 0, trailing: spacing)
        case .horizantal:
            let itemSize = NSCollectionLayoutSize(
                widthDimension: .fractionalWidth(1),
                heightDimension: .fractionalHeight(0.40)
            )

            let layoutItem = NSCollectionLayoutItem(layoutSize: itemSize)
            layoutItem.contentInsets = NSDirectionalEdgeInsets(top: 0, leading: 5, bottom: 3, trailing: 5)

            let layoutGroupSize = NSCollectionLayoutSize(
                widthDimension: .fractionalWidth(0.93),
                heightDimension: .fractionalWidth(0.55)
            )

            let layoutGroup: NSCollectionLayoutGroup = .vertical(
                layoutSize: layoutGroupSize,
                subitem: layoutItem,
                count: 3
            )

            layoutGroup.interItemSpacing = .fixed(15)

            section = NSCollectionLayoutSection(group: layoutGroup)
            section.orthogonalScrollingBehavior = .groupPagingCentered
        case .grid:
            let itemSize = NSCollectionLayoutSize(widthDimension: .fractionalWidth(1.0 / 3.0),
                                                  heightDimension: .fractionalHeight(1.0))
            let item = NSCollectionLayoutItem(layoutSize: itemSize)
            item.contentInsets = NSDirectionalEdgeInsets(top: 6, leading: 6, bottom: 6, trailing: 6)
            let groupSize = NSCollectionLayoutSize(widthDimension: .fractionalWidth(1.0),
                                                   heightDimension: .absolute(145))
            let group = NSCollectionLayoutGroup.horizontal(layoutSize: groupSize, subitem: item, count: 3)
            section = NSCollectionLayoutSection(group: group)
            section.interGroupSpacing = 4
            section.contentInsets = NSDirectionalEdgeInsets(top: 0, leading: 8, bottom: 8, trailing: 8)
        }

        let titleHeaderSize = NSCollectionLayoutSize(
            widthDimension: .fractionalWidth(layoutMode == .grid ? 1.0 : 0.93),
            heightDimension: .absolute(50)
        )

        let titleSupplementary = NSCollectionLayoutBoundarySupplementaryItem(
            layoutSize: titleHeaderSize,
            elementKind: AssetCatalogViewController.titleElementKind,
            alignment: layoutMode == .horizantal ? .top : .topLeading
        )

        section.boundarySupplementaryItems = [titleSupplementary]
        let layout = UICollectionViewCompositionalLayout(section: section)
        let conf = UICollectionViewCompositionalLayoutConfiguration()
        conf.interSectionSpacing = 20

        layout.configuration = conf
        return layout
    }

    func configureDataSource() {
        let cellRegistration = CellRegistration { cell, indexPath, itemIdentifier in
            cell.rendition = itemIdentifier
            cell.configure()
        }

        dataSource = DataSource(collectionView: collectionView) { collectionView, indexPath, itemIdentifier in
            return collectionView.dequeueConfiguredReusableCell(using: cellRegistration, for: indexPath, item: itemIdentifier)
        }

        updateDataSourceItems(collection: renditionCollection)
        RenditionImageCache.shared.prefetch(renditionCollection.flatMap { $0.renditions.prefix(48) })

        let supplementaryRegistration = SupplementaryRegistration(elementKind: AssetCatalogViewController.titleElementKind) { supplementaryView, elementKind, indexPath in
            let snapshot = self.dataSource.snapshot()
            let section = snapshot.sectionIdentifiers[indexPath.section]
            supplementaryView.configure(withSection: section, snapshot: snapshot, sender: self)
        }

        dataSource.supplementaryViewProvider = { (collectionView, string, indexPath) in
            return collectionView.dequeueConfiguredReusableSupplementary(using: supplementaryRegistration, for: indexPath)
        }
    }

    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        guard let item = dataSource.itemIdentifier(for: indexPath) else { return }
        let vc = AssetCatalogRenditionViewController(rendition: item, sender: self)
        present(UINavigationController(rootViewController: vc), animated: true)
    }

    private func presentRenditionActions(for item: Rendition) {
        var actions: [SantanderActionSheetItem] = [
            SantanderActionSheetItem(title: SantanderL10n.t("Copy name"), image: SantanderIconLibrary.shared.interfaceIcon(for: "doc.on.doc")) { UIPasteboard.general.string = item.name }
        ]
        if item.type.isEditable {
            actions.append(SantanderActionSheetItem(title: SantanderL10n.t("Edit"), image: SantanderIconLibrary.shared.interfaceIcon(for: "pencil")) { [weak self] in self?.editItem(item) })
        }
        actions.append(SantanderActionSheetItem(title: SantanderL10n.t("Delete"), image: SantanderIconLibrary.shared.interfaceIcon(for: "trash"), style: .destructive) { [weak self] in self?.deleteItem(item, completion: nil) })
        if let image = item.image {
            let uiImage = UIImage(cgImage: image)
            actions.insert(SantanderActionSheetItem(title: SantanderL10n.t("Copy Image"), image: SantanderIconLibrary.shared.interfaceIcon(for: "doc.on.doc")) { UIPasteboard.general.image = uiImage }, at: 1)
            actions.insert(SantanderActionSheetItem(title: SantanderL10n.t("Save Image"), image: SantanderIconLibrary.shared.interfaceIcon(for: "square.and.arrow.down")) { [weak self] in self?.saveImage(uiImage) }, at: 2)
        }
        actions.append(SantanderActionSheetItem(title: SantanderL10n.t("Cancel"), style: .cancel))
        presentSantanderActionSheet(title: item.name, actions: actions)
    }

    func deleteItem(_ item: Rendition, completion: ((Error?) -> Void)?) {
        do {
            try catalog.removeItem(item, fileURL: fileURL)

            let (newCatalog, newRenditions) = try AssetCatalogWrapper.shared.renditions(forCarArchive: fileURL)
            self.catalog = newCatalog
            self.renditionCollection = newRenditions
            updateDataSourceItems(collection: renditionCollection)
            completion?(nil)
        } catch {
            let completion = completion ?? { error in
                self.errorAlert(error, title: SantanderL10n.t("Failed to delete item and update contents of file"))
            }

            completion(error)
        }
    }

    func updateDataSourceItems(collection: RenditionCollection, completion: (() -> Void)? = nil) {
        displayedRenditionCollection = collection
        var snapshot = NSDiffableDataSourceSnapshot<RenditionType, Rendition>()
        for (section, items) in collection {
            snapshot.appendSections([section])
            if !collapsedRenditionSections.contains(section) {
                snapshot.appendItems(items, toSection: section)
            }
        }

        dataSource.apply(snapshot, animatingDifferences: true, completion: completion)

        if UIDevice.isiPad, let sidebar = splitViewController?.viewController(for: .primary) as? AssetCatalogSidebarListView {
            let sections = dataSource.snapshot().sectionIdentifiers
            var sidebarSnapshot = AssetCatalogSidebarListView.Snapshot()
            sidebarSnapshot.appendSections([.main])
            sidebarSnapshot.appendItems(sections, toSection: .main)
            sidebar.dataSource.apply(sidebarSnapshot)
        }
    }

    fileprivate func toggleSection(_ section: RenditionType, completion: (() -> Void)? = nil) {
        if collapsedRenditionSections.contains(section) {
            collapsedRenditionSections.remove(section)
        } else {
            collapsedRenditionSections.insert(section)
        }
        updateDataSourceItems(collection: displayedRenditionCollection, completion: completion)
    }

    func editItem(_ item: Rendition, presentingFrom optionalVcToPresentFrom: UIViewController? = nil, callback: ((Error?) -> Void)? = nil) {
        guard let preview = item.representation else { return }

        let vcToPresentFrom = optionalVcToPresentFrom ?? self

        let errorCallback: ItemEditorDelegate.ErrorCallback = callback ?? { error in
            if let error = error {
                vcToPresentFrom.errorAlert(error, title: SantanderL10n.t("Failed to edit item"))
            }
        }

        editorDelegate = ItemEditorDelegate(sender: self, selectedRendition: item, finishedEditingCallback: errorCallback)
        let vc: UIViewController
        switch preview {
        case .image(_):
            var conf = PHPickerConfiguration()
            conf.filter = .images
            conf.selectionLimit = 1
            let photoVC = PHPickerViewController(configuration: conf)
            photoVC.delegate = editorDelegate
            vc = photoVC
        case .color(let currentCgColor):
            let colorVC = UIColorPickerViewController()
            colorVC.delegate = editorDelegate
            colorVC.selectedColor = UIColor(cgColor: currentCgColor)
            vc = colorVC
        case .rawData:
            let documentPicker = UIDocumentPickerViewController(forOpeningContentTypes: [.data], asCopy: true)
            documentPicker.delegate = editorDelegate
            vc = documentPicker
        }

        vcToPresentFrom.present(vc, animated: true)
    }
}

extension AssetCatalogViewController: UICollectionViewDragDelegate {
    func collectionView(_ collectionView: UICollectionView, itemsForBeginning session: UIDragSession, at indexPath: IndexPath) -> [UIDragItem] {
        guard let dragItem = dataSource.itemIdentifier(for: indexPath)?.makeDragItem() else { return [] }

        return [
            dragItem
        ]
    }
}

extension AssetCatalogViewController: UISearchBarDelegate {
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        noResultsLabel.removeFromSuperview()
        guard !searchText.isEmpty else {
            updateDataSourceItems(collection: renditionCollection)
            return
        }

        let newCollection = renditionCollection.map { (type, renditions) in
            let newRenditions = renditions.filter { rend in
                return rend.name.localizedCaseInsensitiveContains(searchText)
            }

            return (type, newRenditions)
        }.filter { (_, rends) in
            !rends.isEmpty
        }

        updateDataSourceItems(collection: newCollection)

        if newCollection.isEmpty, noResultsLabel.superview == nil {
            noResultsLabel.text = SantanderL10n.t("No Results")
            noResultsLabel.font = .systemFont(ofSize: 20, weight: .bold)
            noResultsLabel.translatesAutoresizingMaskIntoConstraints = false
            view.addSubview(noResultsLabel)

            let guide = view.layoutMarginsGuide
            NSLayoutConstraint.activate([
                noResultsLabel.centerXAnchor.constraint(equalTo: guide.centerXAnchor),
                noResultsLabel.centerYAnchor.constraint(equalTo: guide.centerYAnchor)
            ])
        }
    }

    func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
        noResultsLabel.removeFromSuperview()
        updateDataSourceItems(collection: renditionCollection)
    }

    func fetchItemsFromFile() {
        do {
            let (newCatalog, newCollection) = try AssetCatalogWrapper.shared.renditions(forCarArchive: fileURL)
            self.catalog = newCatalog
            self.renditionCollection = newCollection
            updateDataSourceItems(collection: renditionCollection)
        } catch {
            let cancelAction = UIAlertAction(title: SantanderL10n.t("Dismiss"), style: .cancel) { _ in
                self.dismiss(animated: true)
            }

            errorAlert(error, title: SantanderL10n.t("Unable to update items"), presentingFromIfAvailable: nil, cancelAction: cancelAction)
        }
    }
}

extension AssetCatalogViewController {
    func scrollViewDidEndDragging(_ scrollView: UIScrollView, willDecelerate decelerate: Bool) {
        guard UIDevice.isiPad, !decelerate else { return }

        let visibleRect = CGRect(origin: collectionView.contentOffset, size: collectionView.bounds.size)
        let visiblePoint = CGPoint(x: visibleRect.midX, y: visibleRect.midY)

        guard let visibleIndexPath = collectionView.indexPathForItem(at: visiblePoint),
              let sidebar = splitViewController?.viewController(for: .primary) as? AssetCatalogSidebarListView else {
            return
        }

        sidebar.collectionView.selectItem(at: IndexPath(row: visibleIndexPath.section, section: 0), animated: true, scrollPosition: .top)
    }
}

extension AssetCatalogViewController {
    class ItemEditorDelegate: NSObject, PHPickerViewControllerDelegate, UIColorPickerViewControllerDelegate, UIDocumentPickerDelegate {
        weak var sender: AssetCatalogViewController?
        let selectedRendition: Rendition

        typealias ErrorCallback = ((Error?) -> Void)
        var finishedEditingCallback: ErrorCallback?

        init(sender: AssetCatalogViewController, selectedRendition: Rendition, finishedEditingCallback: ErrorCallback?) {
            self.sender = sender
            self.selectedRendition = selectedRendition
            self.finishedEditingCallback = finishedEditingCallback
            super.init()
        }

        func picker(_ picker: PHPickerViewController, didFinishPicking results: [PHPickerResult]) {
            picker.dismiss(animated: true)
            guard let first = results.first else { return }
            first.itemProvider.loadObject(ofClass: UIImage.self) { [self] image, error in
                guard let image = image as? UIImage, let cgImage = image.cgImage else {
                    sender?.errorAlert("无法获取所选图像。", title: SantanderL10n.t("Unable to edit item"))
                    return
                }

                edit(to: .image(cgImage))
            }
        }

        func colorPickerViewControllerDidFinish(_ viewController: UIColorPickerViewController) {
            edit(to: .color(viewController.selectedColor.cgColor))
        }

        func documentPicker(_ controller: UIDocumentPickerViewController, didPickDocumentsAt urls: [URL]) {
            guard let url = urls.first else { return }
            let didAccess = url.startAccessingSecurityScopedResource()
            defer {
                if didAccess {
                    url.stopAccessingSecurityScopedResource()
                }
            }

            do {
                edit(to: .rawData(try Data(contentsOf: url)))
            } catch {
                finishedEditingCallback?(error)
            }
        }

        func edit(to newItem: Rendition.Representation) {
            DispatchQueue.main.async { [weak self] in
                guard let self, let sender = self.sender else { return }
                let tmpFilename = "\(sender.fileURL.lastPathComponent)-TMP-EDIT-\(UUID().uuidString.prefix(5))"
                let temporaryFileURL = URL(fileURLWithPath: NSTemporaryDirectory()).appendingPathComponent(tmpFilename)
                do {
                    try FileManager.default.copyItem(at: sender.fileURL, to: temporaryFileURL)
                    try sender.catalog.editItem(self.selectedRendition, fileURL: temporaryFileURL, to: newItem)
                    try FSOperation.perform(.removeItems(items: [sender.fileURL]), rootHelperConf: RootConf.shared)
                    try FSOperation.perform(.rename(item: temporaryFileURL, newPath: sender.fileURL), rootHelperConf: RootConf.shared)

                    self.finishedEditingCallback?(nil)
                    sender.fetchItemsFromFile()
                } catch {
                    self.finishedEditingCallback?(error)
                }
            }
        }
    }
}

class AssetCatalogCell: UICollectionViewCell {
    let nameLabel: UILabel = UILabel()
    let subtitleLabel: UILabel = UILabel()
    private let circleContainer = UIView()
    private let circleImageView = UIImageView()
    var rendition: Rendition?
    private var representedName = ""
}

extension AssetCatalogCell {
    static let cellBackgroundColor: UIColor = .quaternarySystemFill

    func configure() {
        setupShape()
        contentView.subviews.forEach { $0.removeFromSuperview() }

        guard let rendition else { return }
        representedName = rendition.name
        nameLabel.text = rendition.name
        subtitleLabel.text = makeSubtitleText(forRendition: rendition)
        subtitleLabel.font = .preferredFont(forTextStyle: .caption1)
        subtitleLabel.textColor = .secondaryLabel

        circleContainer.translatesAutoresizingMaskIntoConstraints = false
        circleContainer.backgroundColor = .tertiarySystemFill
        circleContainer.layer.cornerRadius = 20
        circleContainer.clipsToBounds = true
        circleImageView.translatesAutoresizingMaskIntoConstraints = false
        circleImageView.contentMode = .scaleAspectFit
        circleContainer.addSubview(circleImageView)
        NSLayoutConstraint.activate([
            circleImageView.leadingAnchor.constraint(equalTo: circleContainer.leadingAnchor, constant: 4),
            circleImageView.trailingAnchor.constraint(equalTo: circleContainer.trailingAnchor, constant: -4),
            circleImageView.topAnchor.constraint(equalTo: circleContainer.topAnchor, constant: 4),
            circleImageView.bottomAnchor.constraint(equalTo: circleContainer.bottomAnchor, constant: -4)
        ])
        circleImageView.image = rendition.image.map { UIImage(cgImage: $0) }
        if rendition.image == nil {
            rendition.loadImage { [weak self] image in
                guard let self, self.representedName == rendition.name else { return }
                self.circleImageView.image = image.map { UIImage(cgImage: $0) }
            }
        }

        let labelsStackView = UIStackView(arrangedSubviews: [nameLabel, subtitleLabel])
        labelsStackView.translatesAutoresizingMaskIntoConstraints = false
        labelsStackView.axis = .vertical

        let stackView = UIStackView(arrangedSubviews: [labelsStackView])
        stackView.translatesAutoresizingMaskIntoConstraints = false
        stackView.spacing = 10

        contentView.addSubview(stackView)
        let guide = contentView.layoutMarginsGuide
        stackView.insertArrangedSubview(circleContainer, at: 0)

        NSLayoutConstraint.activate([
            circleContainer.heightAnchor.constraint(equalTo: guide.heightAnchor),
            circleContainer.widthAnchor.constraint(equalTo: guide.heightAnchor),
        ])

        stackView.constraintCompletely(to: guide)
    }

    func makeSubtitleText(forRendition rend: Rendition) -> String {
        return "\(SantanderL10n.t("Scale"))：\(rend.cuiRend.scale())"
    }

    override var reuseIdentifier: String? {
        return rendition?.name
    }

    func setupShape() {
        var bgConf = UIBackgroundConfiguration.clear()
        bgConf.backgroundColor = AssetCatalogCell.cellBackgroundColor
        bgConf.cornerRadius = 14
        backgroundConfiguration = bgConf
    }
}

class AssetCatalogDetailsView: UIView {
    var catalog: CUICatalog

    init(catalog: CUICatalog) {
        self.catalog = catalog
        super.init(frame: .zero)

        let testLabel = UILabel()
        testLabel.text = SantanderL10n.t("Hello")
        testLabel.translatesAutoresizingMaskIntoConstraints = false
        addSubview(testLabel)

        NSLayoutConstraint.activate([
            testLabel.centerXAnchor.constraint(equalTo: centerXAnchor),
            testLabel.leadingAnchor.constraint(equalTo: leadingAnchor)
        ])
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}

fileprivate extension CACornerMask {
    static func alongEdge(_ edge: CGRectEdge) -> CACornerMask {
        switch edge {
        case .maxXEdge: return [.layerMaxXMinYCorner, .layerMaxXMaxYCorner]
        case .maxYEdge: return [.layerMinXMaxYCorner, .layerMaxXMaxYCorner]
        case .minXEdge: return [.layerMinXMinYCorner, .layerMinXMaxYCorner]
        case .minYEdge: return [.layerMinXMinYCorner, .layerMaxXMinYCorner]
        }
    }
}

class AssetCatalogGridPreviewCell: UICollectionViewCell {
    var rendition: Rendition!
    var previewView: UIView!

    func configure() {
        contentView.subviews.forEach { $0.removeFromSuperview() }
        let imageView = UIImageView()
        imageView.contentMode = .scaleAspectFit
        imageView.tintColor = .secondaryLabel
        imageView.translatesAutoresizingMaskIntoConstraints = false
        previewView = imageView
        contentView.addSubview(previewView)

        let expectedName = rendition.name
        if let color = rendition.cuiRend.cgColor()?.takeUnretainedValue() {
            imageView.backgroundColor = UIColor(cgColor: color)
        } else if let image = rendition.image {
            imageView.image = UIImage(cgImage: image)
        } else {
            imageView.image = SantanderIconLibrary.shared.interfaceIcon(for: "photo")
            rendition.loadImage { [weak self, weak imageView] image in
                guard let self, self.rendition.name == expectedName else { return }
                imageView?.image = image.map { UIImage(cgImage: $0) } ?? SantanderIconLibrary.shared.interfaceIcon(for: "photo")
            }
        }

        contentView.layer.cornerCurve = .continuous
        contentView.layer.cornerRadius = 12.0

        layer.shadowOpacity = 0.2
        layer.shadowRadius = 6.0

        pushCornerPropertiesToChildren()

        previewView.constraintCompletely(to: contentView.layoutMarginsGuide)
    }

    override var reuseIdentifier: String? {
        rendition?.name
    }

    func pushCornerPropertiesToChildren() {
        previewView.layer.maskedCorners = contentView.layer.maskedCorners.union(.alongEdge(.maxYEdge))
        previewView.layer.cornerRadius = contentView.layer.cornerRadius
        previewView.layer.cornerCurve = contentView.layer.cornerCurve
    }
}

class AssetCatalogRenditionViewController: UIViewController {
    typealias DataSource = UICollectionViewDiffableDataSource<Section, ItemType>

    typealias DetailCellRegistration = UICollectionView.CellRegistration<UICollectionViewListCell, DetailItem>
    typealias ActionCellRegistration = UICollectionView.CellRegistration<UICollectionViewListCell, ItemAction>
    typealias GridPreviewCellRegistration = UICollectionView.CellRegistration<AssetCatalogGridPreviewCell, Rendition>

    var rendition: Rendition
    var collectionView: UICollectionView!
    var dataSource: DataSource!
    var sender: AssetCatalogViewController?

    init(rendition: Rendition, sender: AssetCatalogViewController?) {
        self.rendition = rendition
        self.sender = sender
        super.init(nibName: nil, bundle: nil)
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) hasn't been implemented")
    }

    override func viewDidLoad() {
        super.viewDidLoad()

        title = SantanderL10n.t("Info")
        configureCollectionView()
        configureDataSource()
        addItems()
    }

    func configureCollectionView() {
        self.collectionView = UICollectionView(frame: .zero, collectionViewLayout: makeLayout())
        collectionView.translatesAutoresizingMaskIntoConstraints = false
        collectionView.delegate = self
        collectionView.dragDelegate = self
        collectionView.backgroundColor = .secondarySystemBackground
        view.addSubview(collectionView)
        collectionView.constraintCompletely(to: view)
        SantanderLongPressSupport.install(on: collectionView) { [weak self] point in
            guard let self, let indexPath = self.collectionView.indexPathForItem(at: point) else { return }
            self.presentRenditionCellActions(at: indexPath, in: self.collectionView)
        }
    }

    func editItem(sender: AssetCatalogViewController) {
        guard let saveIndx = sender.dataSource.indexPath(for: rendition) else { return }
        sender.editItem(rendition, presentingFrom: self) { [self] error in
            if let error = error {
                errorAlert(error, title: SantanderL10n.t("Failed to edit item"))
                return
            }

            dismiss(animated: true) {
                guard let newRend = sender.dataSource.itemIdentifier(for: saveIndx) else { return }
                let newVC = UINavigationController(rootViewController: AssetCatalogRenditionViewController(rendition: newRend, sender: sender))
                sender.present(newVC, animated: true)
            }
        }
    }

    func makeDetailCellBackgroundConfiguration() -> UIBackgroundConfiguration {
        var background = UIBackgroundConfiguration.listAccompaniedSidebarCell()
        background.cornerRadius = 8
        background.backgroundColor = .tertiarySystemBackground
        return background
    }

    func configureDataSource() {
        let listCellSecondaryTextFont: UIFont = .preferredFont(forTextStyle: .footnote)
        let detailCellBackgroundConf = makeDetailCellBackgroundConfiguration()

        let detailCellRegistration = DetailCellRegistration { cell, indexPath, details in
            var content = UIListContentConfiguration.cell()
            content.prefersSideBySideTextAndSecondaryText = true
            content.text = details.primaryText
            content.secondaryText = details.secondaryText
            content.secondaryTextProperties.font = listCellSecondaryTextFont
            cell.contentConfiguration = content
            cell.backgroundConfiguration = detailCellBackgroundConf
        }

        let previewCellRegistration = GridPreviewCellRegistration { cell, indexPath, itemIdentifier in
            cell.rendition = self.rendition
            cell.configure()
        }

        let actionCellRegistration = ActionCellRegistration { cell, indexPath, itemIdentifier in
            var conf = cell.defaultContentConfiguration()
            conf.text = itemIdentifier.displayText
            conf.image = itemIdentifier.displayImage

            if let color = itemIdentifier.textColor {
                conf.textProperties.color = color
            }

            conf.imageToTextPadding = 10
            cell.contentConfiguration = conf
            cell.backgroundConfiguration = detailCellBackgroundConf
        }

        self.dataSource = DataSource(collectionView: collectionView) { collectionView, indexPath, itemIdentifier in
            switch itemIdentifier {
            case .preview:
                return collectionView.dequeueConfiguredReusableCell(using: previewCellRegistration, for: indexPath, item: self.rendition)
            case .action(let action):
                return collectionView.dequeueConfiguredReusableCell(using: actionCellRegistration, for: indexPath, item: action)
            case .details(let detailItem):
                return collectionView.dequeueConfiguredReusableCell(using: detailCellRegistration, for: indexPath, item: detailItem)
            }
        }
    }

    private var renditionImageLoadRequested = false

    func addItems() {
        if rendition.image == nil, !renditionImageLoadRequested {
            renditionImageLoadRequested = true
            rendition.loadImage { [weak self] _ in
                DispatchQueue.main.async {
                    guard let self else { return }
                    self.renditionImageLoadRequested = false
                    self.addItems()
                }
            }
        }

        var snapshot = NSDiffableDataSourceSnapshot<Section, ItemType>()

        snapshot.appendSections([.itemPreview])

        var actions: [ItemAction] = []
        if let image = rendition.image {
            let uiImage = UIImage(cgImage: image)

            let saveImageAction = ItemAction(displayText: SantanderL10n.t("Save"), displayImage: SantanderIconLibrary.shared.interfaceIcon(for: "square.and.arrow.down")) {
                self.saveImage(uiImage)
            }

            let viewImageAction = ItemAction(displayText: SantanderL10n.t("View"), displayImage: SantanderIconLibrary.shared.interfaceIcon(for: "magnifyingglass")) {
                let viewer = ImageViewerController(fileURL: nil, image: uiImage, title: self.rendition.name)
                self.present(UINavigationController(rootViewController: viewer), animated: true)
            }

            actions += [saveImageAction, viewImageAction]
        }

        if rendition.type.isEditable, let sender = sender {
            let editAction = ItemAction(displayText: SantanderL10n.t("Edit"), displayImage: SantanderIconLibrary.shared.interfaceIcon(for: "gear")) {
                self.editItem(sender: sender)
            }

            actions.append(editAction)
        }

        if !actions.isEmpty {
            snapshot.appendSections([.itemActions])
            snapshot.appendItems(actions.map { return ItemType.action($0) }, toSection: .itemActions)
        }

        let size = rendition.cuiRend.unslicedSize()

        var itemDetails: [DetailItem] = []

        if rendition.namedLookup.name == rendition.namedLookup.renditionName {
            itemDetails.insert(DetailItem(primaryText: SantanderL10n.t("Name"), secondaryText: rendition.namedLookup.name), at: 0)
        } else {
            let bothNames = [
                DetailItem(primaryText: SantanderL10n.t("Lookup Name"), secondaryText: rendition.namedLookup.name),
                DetailItem(primaryText: SantanderL10n.t("Rendition Name"), secondaryText: rendition.namedLookup.renditionName)
            ]

            itemDetails.insert(contentsOf: bothNames, at: 0)
        }

        if !size.height.isZero {
            itemDetails.append(DetailItem(primaryText: SantanderL10n.t("Height"), secondaryText: size.height.description))
        }

        if !size.width.isZero {
            itemDetails.append(DetailItem(primaryText: SantanderL10n.t("Width"), secondaryText: size.width.description))
        }

        itemDetails.append(DetailItem(primaryText: SantanderL10n.t("Scale"), secondaryText: rendition.cuiRend.scale().description))

        let key = rendition.namedLookup.key
        let rendInfo: [DetailItem] = [
            DetailItem(primaryText: SantanderL10n.t("Idiom"), secondaryText: Rendition.Idiom(key)),
            DetailItem(primaryText: SantanderL10n.t("Appearance"), secondaryText: Rendition.Appearance(key)),
            DetailItem(primaryText: SantanderL10n.t("Display Gamut"), secondaryText: Rendition.DisplayGamut(key)),
            DetailItem(primaryText: SantanderL10n.t("Type"), secondaryText: rendition.type),
        ]

        snapshot.appendItems([.preview], toSection: .itemPreview)
        snapshot.appendSections([.itemInfo])
        snapshot.appendItems(ItemType.fromDetails(itemDetails), toSection: .itemInfo)

        if rendition.type == .multiSizeImageSet,
           let nsObjectSizes = rendition.cuiRend.value(forKey: "sizeIndexes") as? [NSObject] {
            let sizes = nsObjectSizes.compactMap { $0.value(forKey: "size") as? CGSize }
            let items = sizes.enumerated().map { (indx, size) in
                DetailItem(primaryText: "大小 \(indx)", secondaryText: "宽度：\(size.width)，高度：\(size.height)")
            }

            snapshot.appendSections([.specificTypeInfo])
            snapshot.appendItems(ItemType.fromDetails(items), toSection: .specificTypeInfo)
        }

        switch rendition.representation {
        case .color(let cgColor):
            let uiColor = UIColor(cgColor: cgColor)
            let codableColor = CodableColor(uiColor)

            let colorSpaceName = (cgColor.colorSpace?.name as? String ?? SantanderL10n.t("N/A"))
                .replacingOccurrences(of: "kCGColorSpace", with: "")
            let colorDetails = [
                DetailItem(primaryText: SantanderL10n.t("ColorSpace"), secondaryText: colorSpaceName),
                DetailItem(primaryText: SantanderL10n.t("Red"), secondaryText: String(format: "%.3f", codableColor.red)),
                DetailItem(primaryText: SantanderL10n.t("Blue"), secondaryText: String(format: "%.3f", codableColor.blue)),
                DetailItem(primaryText: SantanderL10n.t("Green"), secondaryText: String(format: "%.3f", codableColor.green)),
            ]

            snapshot.insertSections([.specificTypeInfo], afterSection: .itemInfo)
            snapshot.appendItems(ItemType.fromDetails(colorDetails), toSection: .specificTypeInfo)
        default:
            break
        }

        snapshot.appendSections([.renditionKeyInfo])
        snapshot.appendItems(ItemType.fromDetails(rendInfo), toSection: .renditionKeyInfo)

        if let sender = sender {
            let deleteImage = SantanderIconLibrary.shared.interfaceIcon(for: "trash")?.withTintColor(.systemRed, renderingMode: .alwaysOriginal)
            let deleteAction = ItemAction(displayText: SantanderL10n.t("Delete"), displayImage: deleteImage, textColor: .systemRed) {
                self.presentSantanderActionSheet(title: SantanderL10n.t("Are you sure you want to delete this item?"), actions: [
                    SantanderActionSheetItem(title: SantanderL10n.t("Delete"), image: SantanderIconLibrary.shared.interfaceIcon(for: "trash"), style: .destructive) { [self] in
                        sender.deleteItem(rendition) { [self] error in
                            if let error = error {
                                errorAlert(error, title: SantanderL10n.t("Failed to delete item"))
                            } else {
                                dismiss(animated: true)
                            }
                        }
                    },
                    SantanderActionSheetItem(title: SantanderL10n.t("Cancel"), style: .cancel)
                ])
            }

            snapshot.appendSections([.deleteItem])
            snapshot.appendItems([.action(deleteAction)], toSection: .deleteItem)
        }

        dataSource.apply(snapshot)
    }

    func makeLayout() -> UICollectionViewLayout {
        lazy var snapshot = dataSource.snapshot()
        let layout = UICollectionViewCompositionalLayout { sectionIndex, enviroment in
            let section = snapshot.sectionIdentifiers[sectionIndex]
            switch section {
            case .itemPreview:
                let itemSize = NSCollectionLayoutSize(widthDimension: .fractionalWidth(1.0),
                                                     heightDimension: .estimated(180))
                let item = NSCollectionLayoutItem(layoutSize: itemSize)
                let groupSize = NSCollectionLayoutSize(widthDimension: .fractionalWidth(1.0),
                                                       heightDimension: .estimated(180))
                let group = NSCollectionLayoutGroup.horizontal(layoutSize: groupSize, subitem: item, count: 1)
                group.interItemSpacing = .fixed(20)

                return NSCollectionLayoutSection(group: group)
            case .itemActions:
                let itemSize = NSCollectionLayoutSize(widthDimension: .fractionalWidth(1.0),
                                                     heightDimension: .fractionalHeight(1.0))
                let item = NSCollectionLayoutItem(layoutSize: itemSize)

                let groupSize = NSCollectionLayoutSize(widthDimension: .fractionalWidth(1.0),
                                                      heightDimension: .absolute(44))
                let group = NSCollectionLayoutGroup.horizontal(layoutSize: groupSize, subitem: item, count: snapshot.numberOfItems(inSection: section))

                let spacing = CGFloat(10)
                group.interItemSpacing = .fixed(spacing)

                let section = NSCollectionLayoutSection(group: group)
                section.interGroupSpacing = spacing
                section.contentInsets = NSDirectionalEdgeInsets(top: 0, leading: 16, bottom: 0, trailing: 16)
                return section
            default:
                let list = NSCollectionLayoutSection.list(
                    using: .init(appearance: .sidebar),
                    layoutEnvironment: enviroment
                )
                list.interGroupSpacing = 5

                return list
            }
        }
        let config = UICollectionViewCompositionalLayoutConfiguration()
        config.interSectionSpacing = 10
        layout.configuration = config

        return layout
    }

    enum Section: Hashable {
        case itemPreview
        case itemActions
        case itemInfo
        case specificTypeInfo
        case renditionKeyInfo
        case deleteItem
    }

    enum ItemType: Hashable {
        case preview
        case action(ItemAction)
        case details(DetailItem)

        static func fromDetails(_ details: [DetailItem]) -> [ItemType] {
            return details.map { details in
                ItemType.details(details)
            }
        }
    }

    struct DetailItem: Hashable {
        let primaryText: String
        let secondaryText: String

        init(primaryText: String, secondaryText: String?) {
            self.primaryText = primaryText
            self.secondaryText = secondaryText ?? SantanderL10n.t("N/A")
        }

        init<DetailTextType: CustomStringConvertible>(primaryText: String, secondaryText: DetailTextType?) {
            self.primaryText = primaryText
            self.secondaryText = secondaryText?.description ?? SantanderL10n.t("N/A")
        }
    }

    struct ItemAction: Hashable {
        static func == (lhs: ItemAction, rhs: ItemAction) -> Bool {
            return lhs.displayText == rhs.displayText
        }

        let displayText: String
        let displayImage: UIImage?
        let textColor: UIColor?
        let action: (() -> Void)

        init(displayText: String, displayImage: UIImage?, textColor: UIColor? = nil, action: @escaping () -> Void) {
            self.displayText = displayText
            self.displayImage = displayImage
            self.textColor = textColor
            self.action = action
        }

        func hash(into hasher: inout Hasher) {
            hasher.combine(displayText)
            hasher.combine(displayImage)
            hasher.combine(textColor)
        }
    }
}

extension AssetCatalogRenditionViewController: UICollectionViewDelegate, UICollectionViewDragDelegate {
    func presentRenditionCellActions(at indexPath: IndexPath, in collectionView: UICollectionView) {
        switch dataSource.itemIdentifier(for: indexPath) {
        case .action(let itemAction):
            presentSantanderActionSheet(title: itemAction.displayText, actions: [
                SantanderActionSheetItem(title: itemAction.displayText, image: itemAction.displayImage) { itemAction.action() },
                SantanderActionSheetItem(title: SantanderL10n.t("Cancel"), style: .cancel)
            ])
        case .details(let detail):
            presentSantanderActionSheet(title: detail.primaryText, actions: [
                SantanderActionSheetItem(title: SantanderL10n.t("Copy"), image: SantanderIconLibrary.shared.interfaceIcon(for: "doc.on.doc")) { UIPasteboard.general.string = detail.secondaryText },
                SantanderActionSheetItem(title: SantanderL10n.t("Cancel"), style: .cancel)
            ])
        default:
            break
        }
    }

    func collectionView(_ collectionView: UICollectionView, shouldHighlightItemAt indexPath: IndexPath) -> Bool {
        switch dataSource.itemIdentifier(for: indexPath) {
        case .action(_): return true
        default: return false
        }
    }

    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        switch dataSource.itemIdentifier(for: indexPath) {
        case .action(let action): action.action()
        default: break
        }
    }

    func collectionView(_ collectionView: UICollectionView, itemsForBeginning session: UIDragSession, at indexPath: IndexPath) -> [UIDragItem] {
        guard indexPath.section == 0, let dragItem = rendition.makeDragItem() else { return [] }

        if let cell = collectionView.cellForItem(at: indexPath) as? AssetCatalogGridPreviewCell {
            dragItem.previewProvider = {
                let params = UIDragPreviewParameters()
                params.backgroundColor = .clear
                return UIDragPreview(view: cell.previewView, parameters: params)
            }
        }

        return [
            dragItem
        ]
    }
}

class AssetCatalogSectionHeader: UICollectionReusableView {
    let stackView = UIStackView()
    let titleLabel = UILabel()
    let subtitleLabel = UILabel()
    private let collapseButton = UIButton(type: .system)
    private weak var catalogController: AssetCatalogViewController?
    private var representedSection: RenditionType?

    override init(frame: CGRect) {
        super.init(frame: frame)
        setupHeader()
    }

    required init?(coder: NSCoder) {
        super.init(coder: coder)
        setupHeader()
    }

    private func setupHeader() {
        stackView.axis = .horizontal
        stackView.alignment = .center
        stackView.spacing = 8
        stackView.translatesAutoresizingMaskIntoConstraints = false
        titleLabel.font = .preferredFont(forTextStyle: .headline)
        titleLabel.adjustsFontForContentSizeCategory = true
        titleLabel.setContentCompressionResistancePriority(.defaultLow, for: .horizontal)
        subtitleLabel.textColor = .secondaryLabel
        subtitleLabel.font = .preferredFont(forTextStyle: .caption1)
        subtitleLabel.adjustsFontForContentSizeCategory = true
        collapseButton.setImage(SantanderIconLibrary.shared.interfaceIcon(for: "chevron.down"), for: .normal)
        collapseButton.accessibilityLabel = SantanderL10n.t("Collapse Section")
        collapseButton.addTarget(self, action: #selector(toggleSection), for: .touchUpInside)
        stackView.addArrangedSubview(titleLabel)
        stackView.addArrangedSubview(subtitleLabel)
        let spacer = UIView()
        spacer.setContentHuggingPriority(.defaultLow, for: .horizontal)
        stackView.addArrangedSubview(spacer)
        stackView.addArrangedSubview(collapseButton)
        addSubview(stackView)
        let guide = layoutMarginsGuide
        NSLayoutConstraint.activate([
            stackView.leadingAnchor.constraint(equalTo: guide.leadingAnchor),
            stackView.trailingAnchor.constraint(equalTo: guide.trailingAnchor),
            stackView.topAnchor.constraint(equalTo: guide.topAnchor),
            stackView.bottomAnchor.constraint(equalTo: guide.bottomAnchor),
            collapseButton.widthAnchor.constraint(equalToConstant: 32),
            collapseButton.heightAnchor.constraint(equalToConstant: 32)
        ])
    }

    func configure(withSection section: RenditionType, snapshot: NSDiffableDataSourceSnapshot<RenditionType, Rendition>, sender: AssetCatalogViewController) {
        representedSection = section
        catalogController = sender
        titleLabel.text = section.description
        let allCount = sender.renditionCollection.first { $0.0 == section }?.1.count ?? snapshot.itemIdentifiers(inSection: section).count
        subtitleLabel.text = "\(allCount) \(SantanderL10n.t("Items"))"
        let isCollapsed = sender.collapsedRenditionSections.contains(section)
        collapseButton.setImage(UIImage(systemName: isCollapsed ? "chevron.right" : "chevron.down"), for: .normal)
        collapseButton.accessibilityLabel = SantanderL10n.t(isCollapsed ? "Expand Section" : "Collapse Section")
    }

    @objc private func toggleSection() {
        guard let representedSection else { return }
        catalogController?.toggleSection(representedSection)
    }
}

class AssetCatalogSidebarListView: UIViewController {

    enum Section: Hashable {
        case main
    }

    typealias DataSource = UICollectionViewDiffableDataSource<Section, RenditionType>
    typealias Snapshot = NSDiffableDataSourceSnapshot<Section, RenditionType>
    typealias CellRegistration = UICollectionView.CellRegistration<UICollectionViewListCell, RenditionType>

    let catalogController: AssetCatalogViewController

    var collectionView: UICollectionView!
    var dataSource: DataSource!

    lazy var sections: [RenditionType] = []

    init(catalogController: AssetCatalogViewController) {
        self.catalogController = catalogController

        super.init(nibName: nil, bundle: nil)
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    override func viewDidLoad() {
        super.viewDidLoad()

        makeCollectionView()
        makeDataSource()
        addItems()

        // Asset catalogs are displayed directly in the current editor column;
        // never replace the outer split view's navigation controller here.

        title = catalogController.fileURL.deletingPathExtension().lastPathComponent
        navigationController?.navigationBar.prefersLargeTitles = true
    }

    func makeCollectionView() {
        let layout = UICollectionViewCompositionalLayout { _, env in
            return .list(using: UICollectionLayoutListConfiguration(appearance: .sidebar), layoutEnvironment: env)
        }

        collectionView = UICollectionView(frame: .zero, collectionViewLayout: layout)
        collectionView.translatesAutoresizingMaskIntoConstraints = false
        collectionView.delegate = self
        view.addSubview(collectionView)

        collectionView.constraintCompletely(to: view)
    }

    func makeDataSource() {

        let cellRegistration = CellRegistration { cell, indexPath, itemIdentifier in
            var conf = cell.defaultContentConfiguration()
            conf.text = itemIdentifier.description
            conf.image = itemIdentifier.displayImage
            cell.contentConfiguration = conf
        }

        self.dataSource = DataSource(collectionView: collectionView) { collectionView, indexPath, itemIdentifier in
            return collectionView.dequeueConfiguredReusableCell(using: cellRegistration, for: indexPath, item: itemIdentifier)
        }
    }

    func addItems() {
        var snapshot = Snapshot()
        snapshot.appendSections([.main])
        snapshot.appendItems(sections, toSection: .main)
        dataSource.apply(snapshot)
    }
}

extension AssetCatalogSidebarListView: UICollectionViewDelegate {
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let currentSnapshot = catalogController.dataSource.snapshot()
        guard currentSnapshot.sectionIdentifiers.indices.contains(indexPath.item) else { return }
        let section = currentSnapshot.sectionIdentifiers[indexPath.item]
        let scrollToSection: () -> Void = { [weak self] in
            guard let self else { return }
            let snapshot = self.catalogController.dataSource.snapshot()
            guard let sectionIndex = snapshot.sectionIdentifiers.firstIndex(of: section),
                  snapshot.numberOfItems(inSection: section) > 0 else { return }
            self.catalogController.collectionView.scrollToItem(at: IndexPath(item: 0, section: sectionIndex), at: .top, animated: true)
        }
        if catalogController.collapsedRenditionSections.contains(section) {
            catalogController.toggleSection(section, completion: scrollToSection)
        } else {
            scrollToSection()
        }
    }
}

fileprivate extension RenditionType {
    var displayImage: UIImage? {
        switch self {
        case .image, .svg:
            return SantanderIconLibrary.shared.interfaceIcon(for: "photo")
        case .icon:
            return SantanderIconLibrary.shared.interfaceIcon(for: "app")
        case .imageSet:
            return SantanderIconLibrary.shared.interfaceIcon(for: "photo.stack")
        case .multiSizeImageSet:
            return SantanderIconLibrary.shared.interfaceIcon(for: "cube.box")
        case .pdf:
            return SantanderIconLibrary.shared.interfaceIcon(for: "doc.richtext")
        case .color:
            return SantanderIconLibrary.shared.interfaceIcon(for: "paintbrush")
        case .rawData:
            return SantanderIconLibrary.shared.uiIcon(named: "text-editor")
        case .unknown:
            return SantanderIconLibrary.shared.interfaceIcon(for: "questionmark.app")
        }
    }
}

class AudioPlayerViewController: UIViewController {
    let fileURL: URL
    var playButton: UIButton!
    var loopButton: UIButton!
    var playbackSlider: UISlider!
    var durationLabel: UILabel!
    var currentProgressLabel: UILabel!
    var forwardButton: UIButton!
    var backwardButton: UIButton!

    var player: AVAudioPlayer
    var asset: AVAsset
    lazy var displayLink: CADisplayLink = CADisplayLink(target: self, selector: #selector(sychronizeSliderProgress))

    var doLoop: Bool = false

    var playbackCallback: (() -> Void)? = nil

    var playbackSpeedRate: Float = UserPreferences.audioVCSpeed {
        didSet {
            UserPreferences.audioVCSpeed = playbackSpeedRate
            player.rate = playbackSpeedRate
        }
    }

    var itemName: String {
        let nameFromMetadata = asset.metadata.first { $0.commonKey?.rawValue == "title" }?.stringValue
        return nameFromMetadata ?? fileURL.lastPathComponent
    }

    var artistName: String? {
        return asset.metadata.first { $0.commonKey?.rawValue == "artist" }?.stringValue
    }

    var skipDuration: Int = UserPreferences.skipDuration {
        didSet {
            UserPreferences.skipDuration = skipDuration
        }
    }

    let availableSkipDurations: [Int] = [5, 10, 15, 30, 45, 60, 90]
    let availableSpeedRates: [Float] = [0.5, 1.0, 1.5, 2.0]

    lazy var artworkImage: UIImage? = _getArtworkImage()

    func _getArtworkImage() -> UIImage? {
        guard let data = asset.metadata.first(where: { $0.commonKey?.rawValue == "artwork" })?.dataValue, let image = UIImage(data: data) else {
            return nil
        }

        return image
    }

    func playButtonSymbolName() -> String {
        player.isPlaying ? "pause.fill" : "play.fill"
    }

    func playButtonImage(withSize pointSize: CGFloat = 45, imageTintColor: UIColor? = .systemGray) -> UIImage? {
        let conf = UIImage.SymbolConfiguration(pointSize: pointSize, weight: .medium, scale: .medium)

        let imageSymbolName = playButtonSymbolName()
        let image = UIImage(systemName: imageSymbolName, withConfiguration: conf)
        if let imageTintColor = imageTintColor {
            return image?.withTintColor(imageTintColor, renderingMode: .alwaysOriginal)
        }

        return image
    }

    init(fileURL: URL, player: AVAudioPlayer) {
        self.fileURL = fileURL
        self.asset = AVAsset(url: fileURL)
        self.player = player

        self.player.enableRate = true
        self.player.rate = playbackSpeedRate

        super.init(nibName: nil, bundle: nil)
    }

    convenience init(fileURL: URL) throws {
        self.init(fileURL: fileURL, player: try AVAudioPlayer(contentsOf: fileURL))
    }

    convenience init(fileURL: URL, data: Data) throws {
        self.init(fileURL: fileURL, player: try AVAudioPlayer(data: data))
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    override func viewDidLoad() {
        super.viewDidLoad()

        self.view.backgroundColor = .secondarySystemBackground
        setupBarButtons()

        displayLink.add(to: .main, forMode: .default)

        addItemToSystemMediaPlayer()

        player.delegate = self
        let playAction = UIAction(image: playButtonImage()) { _ in
            self.play()
        }

        self.playButton = UIButton(primaryAction: playAction)

        self.playbackSlider = UISlider()

        playbackSlider.minimumValue = 0
        playbackSlider.maximumValue = Float(player.duration)
        playbackSlider.isContinuous = false

        playbackSlider.setThumbImage(UIImage(systemName: "circle.fill"), for: .normal)
        playbackSlider.tintColor = .lightGray
        playbackSlider.addTarget(self, action: #selector(sliderDidChange(_:)), for: .valueChanged)
        playbackSlider.addTarget(self, action: #selector(didBeginDraggingSlider), for: .touchDown)

        let titleLabel = UILabel()
        titleLabel.text = itemName
        titleLabel.font = .preferredFont(forTextStyle: .title2)
        titleLabel.textAlignment = .left

        let artistLabel = UILabel()
        artistLabel.text = artistName ?? SantanderL10n.t("Unknown Artist")
        artistLabel.textAlignment = .left
        artistLabel.textColor = .systemGray

        self.durationLabel = UILabel()
        durationLabel.text = format(timeInterval: player.duration)
        durationLabel.textColor = .systemGray

        self.currentProgressLabel = UILabel()
        currentProgressLabel.text = format(timeInterval: player.duration)
        currentProgressLabel.textColor = .systemGray

        let loopAction = UIAction(image: loopButtonImage()) { action in
            self.doLoop.toggle()
            self.loopButton.setImage(self.loopButtonImage(), for: .normal)
        }
        self.loopButton = UIButton(primaryAction: loopAction)

        self.forwardButton = UIButton(
            primaryAction: UIAction(
                image: SantanderIconLibrary.shared.interfaceIcon(for: "goforward")?.withTintColor(.systemGray, renderingMode: .alwaysOriginal)
            ) { _ in
                self.player.currentTime += Double(self.skipDuration)
            }
        )

        self.backwardButton = UIButton(
            primaryAction: UIAction(
                image: SantanderIconLibrary.shared.interfaceIcon(for: "gobackward")?.withTintColor(.systemGray, renderingMode: .alwaysOriginal)
            ) { _ in
                self.player.currentTime -= Double(self.skipDuration)
            }
        )

        let buttonsStackView = UIStackView(arrangedSubviews: [backwardButton, playButton, forwardButton])
        buttonsStackView.spacing = 40

        let labelsStackView = UIStackView(arrangedSubviews: [titleLabel, artistLabel])
        labelsStackView.axis = .vertical

        durationLabel.translatesAutoresizingMaskIntoConstraints = false
        playbackSlider.translatesAutoresizingMaskIntoConstraints = false
        buttonsStackView.translatesAutoresizingMaskIntoConstraints = false
        labelsStackView.translatesAutoresizingMaskIntoConstraints = false
        loopButton.translatesAutoresizingMaskIntoConstraints = false
        currentProgressLabel.translatesAutoresizingMaskIntoConstraints = false

        view.addSubview(buttonsStackView)
        view.addSubview(labelsStackView)
        view.addSubview(durationLabel)
        view.addSubview(playbackSlider)
        view.addSubview(currentProgressLabel)
        view.addSubview(loopButton)

        NSLayoutConstraint.activate([
            playbackSlider.centerYAnchor.constraint(equalTo: view.centerYAnchor, constant: 120),
            playbackSlider.trailingAnchor.constraint(equalTo: view.layoutMarginsGuide.trailingAnchor),
            playbackSlider.leadingAnchor.constraint(equalTo: view.layoutMarginsGuide.leadingAnchor),

            buttonsStackView.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            buttonsStackView.centerYAnchor.constraint(equalTo: playbackSlider.centerYAnchor, constant: 80),

            labelsStackView.trailingAnchor.constraint(equalTo: playbackSlider.trailingAnchor),
            labelsStackView.leadingAnchor.constraint(equalTo: playbackSlider.leadingAnchor),
            labelsStackView.bottomAnchor.constraint(equalTo: playbackSlider.topAnchor, constant: -10),

            durationLabel.trailingAnchor.constraint(equalTo: titleLabel.trailingAnchor),
            durationLabel.topAnchor.constraint(equalTo: playbackSlider.bottomAnchor),

            currentProgressLabel.leadingAnchor.constraint(equalTo: titleLabel.leadingAnchor),
            currentProgressLabel.topAnchor.constraint(equalTo: playbackSlider.bottomAnchor),

            loopButton.trailingAnchor.constraint(equalTo: artistLabel.trailingAnchor),
            loopButton.topAnchor.constraint(equalTo: artistLabel.topAnchor)
        ])

    }

    func play() {
        if player.isPlaying {
            player.pause()
        } else {
            try? AVAudioSession.sharedInstance().setCategory(.playback)
            try? AVAudioSession.sharedInstance().setActive(true, options: .notifyOthersOnDeactivation)

            player.play()
        }

        setPlayButtonImage()
        playbackCallback?()
    }

    func setPlayButtonImage() {
        playButton.setImage(playButtonImage(), for: .normal)
    }

    @objc
    func sliderDidChange(_ sender: UISlider) {
        player.currentTime = Double(sender.value)
        displayLink.isPaused = false
    }

    @objc
    func sychronizeSliderProgress() {
        if !playbackSlider.isTracking {
            MPNowPlayingInfoCenter.default().nowPlayingInfo?[MPMediaItemPropertyPlaybackDuration] = player.duration
            MPNowPlayingInfoCenter.default().nowPlayingInfo?[MPNowPlayingInfoPropertyElapsedPlaybackTime] = player.currentTime
        }

        let synchronized = player.currentTime
        playbackSlider.setValue(Float(synchronized), animated: true)
        currentProgressLabel.text = format(timeInterval: synchronized)
        if let currentTimeLeft = format(timeInterval: player.duration - player.currentTime) {
            self.durationLabel.text = "-\(currentTimeLeft)"
        }

        displayLink.isPaused = false
    }

    @objc func didBeginDraggingSlider() {
        displayLink.isPaused = true
    }

    func format(timeInterval: TimeInterval) -> String? {
        let formatter = DateComponentsFormatter()

        formatter.zeroFormattingBehavior = []

        formatter.allowedUnits = [.second, .minute]
        if timeInterval >= 3600 {
            formatter.allowedUnits.insert(.hour)
        }

        return formatter.string(from: timeInterval)
    }

    func loopButtonImage() -> UIImage? {
        let image = SantanderIconLibrary.shared.interfaceIcon(for: "repeat")
        if !self.doLoop {
            return image?.withTintColor(.systemGray, renderingMode: .alwaysOriginal)
        }

        return image
    }

    func setupBarButtons() {
        self.navigationItem.rightBarButtonItem = UIBarButtonItem(image: SantanderIconLibrary.shared.interfaceIcon(for: "ellipsis.circle"), style: .plain, target: self, action: #selector(showPlaybackOptions))
        self.navigationItem.leftBarButtonItem = UIBarButtonItem(title: SantanderL10n.t("Dismiss"), style: .plain, target: self, action: #selector(dismissPlaybackController))
    }

    @objc private func dismissPlaybackController() { dismiss(animated: true) }

    @objc private func showPlaybackOptions() {
        var actions: [SantanderActionSheetItem] = availableSpeedRates.map { rate in
            SantanderActionSheetItem(title: "\(SantanderL10n.t("Speed")): \(rate.description)", image: UIImage(systemName: "speedometer"), isSelected: playbackSpeedRate == rate) { [weak self] in
                self?.playbackSpeedRate = rate
                self?.setupBarButtons()
            }
        }
        actions.append(contentsOf: availableSkipDurations.map { duration in
            SantanderActionSheetItem(title: "\(SantanderL10n.t("Backward / Forward duration")): \(duration.description)", image: SantanderIconLibrary.shared.uiIcon(named: "rewind"), isSelected: skipDuration == duration) { [weak self] in
                self?.skipDuration = duration
                self?.setupBarButtons()
            }
        })
        actions.append(SantanderActionSheetItem(title: SantanderL10n.t("Cancel"), style: .cancel))
        presentSantanderActionSheet(title: SantanderL10n.t("Playback Options"), actions: actions)
    }

    func addItemToSystemMediaPlayer() {
        let center = MPNowPlayingInfoCenter.default()

        UIApplication.shared.beginReceivingRemoteControlEvents()
        MPRemoteCommandCenter.shared().playCommand.addTarget { event in
            self.player.play()
            self.setPlayButtonImage()
            self.playbackCallback?()
            return .success
        }

        MPRemoteCommandCenter.shared().pauseCommand.addTarget { event in
            self.player.pause()
            self.setPlayButtonImage()
            self.playbackCallback?()
            return .success
        }

        MPRemoteCommandCenter.shared().nextTrackCommand.addTarget {event in
            self.player.currentTime += Double(self.skipDuration)
            return .success
        }

        MPRemoteCommandCenter.shared().previousTrackCommand.addTarget {event in
            self.player.currentTime -= Double(self.skipDuration)
            return .success
        }

        var info: [String: Any] = [
            MPMediaItemPropertyTitle: self.itemName,
            MPNowPlayingInfoPropertyMediaType: MPNowPlayingInfoMediaType.audio.rawValue,
            MPNowPlayingInfoPropertyAssetURL: self.fileURL,
            MPNowPlayingInfoPropertyIsLiveStream: false
        ]

        if let album = asset.metadata.first(where: { $0.commonKey?.rawValue == "album" })?.stringValue {
            info[MPMediaItemPropertyAlbumTitle] = album
        }

        if let artist = self.artistName {
            info[MPMediaItemPropertyArtist] = artist
        }

        if let artworkImage = artworkImage {
            let mpArtwork = MPMediaItemArtwork(boundsSize: artworkImage.size) { _ in
                return artworkImage
            }

            info[MPMediaItemPropertyArtwork] = mpArtwork
        }

        center.nowPlayingInfo = info
    }

    override func dismiss(animated flag: Bool, completion: (() -> Void)? = nil) {
        player.stop()
        super.dismiss(animated: flag, completion: completion)
    }

    func removeFromSystemMediaPlayer() {
        MPNowPlayingInfoCenter.default().nowPlayingInfo = nil
    }
}

extension AudioPlayerViewController: AVAudioPlayerDelegate {
    func audioPlayerDidFinishPlaying(_ player: AVAudioPlayer, successfully flag: Bool) {
        if self.doLoop {
            player.play()
        }

        setPlayButtonImage()
        playbackCallback?()
    }
}

class AudioPlayerToolbarView: UIView {
    let audioPlayerController: AudioPlayerViewController
    weak var delegate: AudioPlayerToolbarDelegate?
    var playButton: UIButton!

    init(_ audioPlayerController: AudioPlayerViewController, frame: CGRect) {
        self.audioPlayerController = audioPlayerController

        super.init(frame: frame)

        let titleLabel = UILabel()
        titleLabel.text = audioPlayerController.itemName
        titleLabel.translatesAutoresizingMaskIntoConstraints = false
        addSubview(titleLabel)

        let cancelAction = UIAction(image: SantanderIconLibrary.shared.interfaceIcon(for: "xmark.circle")) { _ in
            self.delegate?.audioToolbarDidClickCancelButton(self)
        }

        self.playButton = UIButton()
        setPlayButtonImage()
        let playOrStopAction = UIAction { _ in
            self.playOrStop()
        }

        playButton.addAction(playOrStopAction, for: .touchUpInside)

        audioPlayerController.playbackCallback = {
            self.setPlayButtonImage()
        }

        let cancelButton = UIButton(primaryAction: cancelAction)
        let buttonsStackView = UIStackView(arrangedSubviews: [playButton, cancelButton])
        buttonsStackView.spacing = 10
        buttonsStackView.translatesAutoresizingMaskIntoConstraints = false

        addSubview(buttonsStackView)

        NSLayoutConstraint.activate([
            titleLabel.leadingAnchor.constraint(equalTo: layoutMarginsGuide.leadingAnchor),
            titleLabel.centerYAnchor.constraint(equalTo: centerYAnchor),

            buttonsStackView.centerYAnchor.constraint(equalTo: centerYAnchor),
            buttonsStackView.trailingAnchor.constraint(equalTo: layoutMarginsGuide.trailingAnchor)
        ])
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    func playOrStop() {
        audioPlayerController.play()
        setPlayButtonImage()
    }

    func setPlayButtonImage() {
        playButton.setImage(audioPlayerController.playButtonImage(withSize: 20, imageTintColor: nil), for: .normal)
    }
}

protocol AudioPlayerToolbarDelegate: AnyObject {
    func audioToolbarDidClickCancelButton(_ toolbar: AudioPlayerToolbarView)
}

struct FileEditor {
    let type: FileEditorType
    let viewController: UIViewController

    static func preferredAsync(forURL path: Path, completion: @escaping (FileEditor?) -> Void) {
        let url = path.url
        let type = url.contentType

        if let associated = UserPreferences.fileAssociationEditor(for: url) {
            if associated == .hex || associated == .terminal || associated == .executable
                || associated == .pdf || associated == .sqlite || associated == .archive || associated == .assetCatalog {
                DispatchQueue.main.async {
                    completion(makeEditor(url: url, editorType: associated, contentType: type, data: nil))
                }
                return
            }
        }

        var statBuffer = stat()
        let fileSize = lstat(url.path, &statBuffer) == 0 ? UInt64(max(0, statBuffer.st_size)) : 0
        let dataIndependent = SantanderBinaryTools.isSQLite(url)
            || SantanderBinaryTools.isArchive(url)
            || url.pathExtension.lowercased() == "pdf"
            || type == .unixExecutable
            || url.pathExtension.lowercased() == "car"
            || fileSize > 8 * 1024 * 1024

        if dataIndependent {
            DispatchQueue.main.async {
                completion(makePreferredEditor(url: url, contentType: type, data: nil))
            }
            return
        }

        DispatchQueue.global(qos: .userInitiated).async {
            let data = try? Data(contentsOf: url, options: [.mappedIfSafe])
            DispatchQueue.main.async {
                completion(makePreferredEditor(url: url, contentType: type, data: data))
            }
        }
    }

    static func preferred(forURL _url: Path) -> FileEditor? {
        let url = _url.url
        if url.pathExtension.lowercased() == "car", let carVC = FileEditorType.assetCatalog.viewController(forPath: url, data: nil) {
            return FileEditor(type: .assetCatalog, viewController: carVC)
        }

        var statBuffer = stat()
        let fileSize = lstat(url.path, &statBuffer) == 0 ? UInt64(max(0, statBuffer.st_size)) : 0
        let contentType = url.contentType
        if fileSize > 8 * 1024 * 1024 {
            return makePreferredEditor(url: url, contentType: contentType, data: nil)
        }
        guard let data = try? Data(contentsOf: url, options: [.mappedIfSafe]) else { return nil }
        return makePreferredEditor(url: url, contentType: contentType, data: data)
    }

    static func allEditors(forPath path: Path) -> [FileEditor] {
        let url = path.url
        var statBuffer = stat()
        let fileSize = lstat(url.path, &statBuffer) == 0 ? UInt64(max(0, statBuffer.st_size)) : 0
        let data = fileSize <= 8 * 1024 * 1024 ? try? Data(contentsOf: url, options: [.mappedIfSafe]) : nil

        let candidates = FileEditorType.allCases.filter { type in
            switch type {
            case .assetCatalog:
                return url.pathExtension.lowercased() == "car"
            case .executable, .terminal:
                return url.contentType == .unixExecutable || FileManager.default.isExecutableFile(atPath: url.path)
            case .pdf:
                return url.pathExtension.lowercased() == "pdf"
            case .sqlite:
                return SantanderBinaryTools.isSQLite(url)
            case .archive:
                return SantanderBinaryTools.isArchive(url)
            default:
                return true
            }
        }

        return candidates.compactMap { type in
            guard let vc = type.viewController(forPath: url, data: data) else { return nil }
            return FileEditor(type: type, viewController: vc)
        }
    }

    func display(senderVC: UIViewController) {
        let vcToPresent: UIViewController
        if type.useNavigationController {
            vcToPresent = UINavigationController(rootViewController: viewController)
        } else {
            vcToPresent = viewController
        }

        if type.presentAsFullScreen {
            vcToPresent.modalPresentationStyle = .fullScreen
        }

        senderVC.present(vcToPresent, animated: true)
    }
}

fileprivate extension UIViewController {
    func presentOpenWithOptions(forPath path: Path, openEditor: ((FileEditor) -> Void)? = nil) {
        let editors = FileEditor.allEditors(forPath: path)
        guard !editors.isEmpty else {
            presentSantanderActionSheet(
                title: SantanderL10n.t("Open in.."),
                message: SantanderL10n.t("No available viewer for this file."),
                actions: [SantanderActionSheetItem(title: SantanderL10n.t("Cancel"), style: .cancel)]
            )
            return
        }
        let actions = editors.map { editor in
            SantanderActionSheetItem(title: editor.type.description, subtitle: path.lastPathComponent, image: editor.type.menuImage) { [weak self] in
                guard let self else { return }
                if let openEditor { openEditor(editor) }
                else { editor.display(senderVC: self) }
            }
        }
        presentSantanderActionSheet(title: SantanderL10n.t("Open in.."), message: path.path, actions: actions + [SantanderActionSheetItem(title: SantanderL10n.t("Cancel"), style: .cancel)])
    }
}

private func makeEditor(url: URL, editorType: FileEditorType, contentType type: UTType?, data: Data?) -> FileEditor? {
    guard let viewController = editorType.viewController(forPath: url, data: data) else { return nil }
    return FileEditor(type: editorType, viewController: viewController)
}

private func makePreferredEditor(url: URL, contentType type: UTType?, data: Data?) -> FileEditor? {
    if let associated = UserPreferences.fileAssociationEditor(for: url),
       let editor = makeEditor(url: url, editorType: associated, contentType: type, data: data) {
        return editor
    }

    if SantanderBinaryTools.isSQLite(url) {
        return FileEditor(type: .sqlite, viewController: SQLiteEditorViewController(fileURL: url))
    }
    if SantanderBinaryTools.isArchive(url) {
        return FileEditor(type: .archive, viewController: ArchiveBrowserViewController(archiveURL: url))
    }
    if url.pathExtension.lowercased() == "pdf" {
        return FileEditor(type: .pdf, viewController: PDFEditorViewController(fileURL: url))
    }
    if url.pathExtension.lowercased() == "car" {
        if let vc = FileEditorType.assetCatalog.viewController(forPath: url, data: nil) {
            return FileEditor(type: .assetCatalog, viewController: vc)
        }
    }
    if type == .unixExecutable {
        return FileEditor(type: .executable, viewController: BinaryExecutionViewController(executableURL: url))
    }

    if type?.isOfType(.audio) ?? false, let audio = AudioQueueViewController.make(around: url) {
        return FileEditor(type: .audio, viewController: audio)
    }
    if (type?.isOfType(.video) ?? false || type?.isOfType(.movie) ?? false) {
        let controller = AVPlayerViewController()
        controller.player = AVPlayer(url: url)
        controller.allowsPictureInPicturePlayback = true
        return FileEditor(type: .video, viewController: controller)
    }
    if type?.isOfType(.image) ?? false, let image = santanderDownsampledPreviewImage(at: url) {
        return FileEditor(type: .image, viewController: ImageViewerController(fileURL: url, image: image))
    }
    if type?.isOfType(.font) ?? false, let fontVC = FileEditorType.font.viewController(forPath: url, data: nil) {
        return FileEditor(type: .font, viewController: fontVC)
    }

    guard let data else { return nil }

    if type?.isOfType(.audio) ?? false, let audio = AudioQueueViewController.make(around: url) {
        return FileEditor(type: .audio, viewController: audio)
    }
    if type?.isOfType(.font) ?? false, let fontVC = FileEditorType.font.viewController(forPath: url, data: data) {
        return FileEditor(type: .font, viewController: fontVC)
    }
    if let imageVC = FileEditorType.image.viewController(forPath: url, data: data) {
        return FileEditor(type: .image, viewController: imageVC)
    }
    if (type?.isOfType(.video) ?? false || type?.isOfType(.movie) ?? false),
       let videoPlayer = FileEditorType.video.viewController(forPath: url, data: data) {
        return FileEditor(type: .video, viewController: videoPlayer)
    }
    if let plistVC = FileEditorType.propertyList.viewController(forPath: url, data: data) {
        return FileEditor(type: .propertyList, viewController: plistVC)
    }
    if url.pathExtension.lowercased() == "json", let jsonVC = FileEditorType.json.viewController(forPath: url, data: data) {
        return FileEditor(type: .json, viewController: jsonVC)
    }
    if let textVC = FileEditorType.text.viewController(forPath: url, data: data) {
        return FileEditor(type: .text, viewController: textVC)
    }

    if String(data: data, encoding: .utf8) != nil,
       let textVC = FileEditorType.text.viewController(forPath: url, data: data) {
        return FileEditor(type: .text, viewController: textVC)
    }

    return nil
}

enum FileEditorType: String, CustomStringConvertible, CaseIterable {
    case audio, image, video
    case propertyList, json, text, font
    case assetCatalog
    case executable
    case pdf, hex, sqlite, archive, terminal

    func viewController(forPath path: URL, data: Data?) -> UIViewController? {
        if self == .assetCatalog {
            guard path.pathExtension == "car",
                  let vc = try? AssetCatalogViewController(catalogFileURL: path) else {
                return nil
            }

            return vc
        }

        switch self {
        case .executable:
            return BinaryExecutionViewController(executableURL: path)
        case .pdf:
            return PDFEditorViewController(fileURL: path)
        case .hex:
            return HexEditorViewController(fileURL: path)
        case .sqlite:
            return SQLiteEditorViewController(fileURL: path)
        case .archive:
            return ArchiveBrowserViewController(archiveURL: path)
        case .terminal:
            return TerminalViewController(workingDirectory: path.deletingLastPathComponent(), initialCommand: path.path)
        default:
            break
        }

        guard let data = data else { return nil }

        switch self {
        case .executable, .pdf, .hex, .sqlite, .archive, .terminal, .assetCatalog:
            return nil
        case .audio:
            return try? AudioPlayerViewController(fileURL: path, data: data)
        case .propertyList:
            let fmt: UnsafeMutablePointer<PropertyListSerialization.PropertyListFormat> = .allocate(capacity: 4)
            defer { fmt.deallocate() }
            let plist = try? PropertyListSerialization.propertyList(from: data, format: fmt)

            let contentCanEdit = !PathPermissions.isLocked(at: path)
            if let dict = plist as? [String: Any] {
                return PlistTreeEditorViewController(rootValue: dict, format: fmt.pointee, fileURL: path, title: path.lastPathComponent, canEdit: contentCanEdit)
            } else if let arr = plist as? Array<Any> {
                return PlistTreeEditorViewController(rootValue: arr, format: fmt.pointee, fileURL: path, title: path.lastPathComponent, canEdit: contentCanEdit)
            }

            return nil
        case .json:

            let json = try? JSONSerialization.jsonObject(with: data)
            let contentCanEdit = !PathPermissions.isLocked(at: path)

            if let dict = json as? [String: Any] {
                return SerializedDocumentViewController(dictionary: dict.asSerializedDictionary(), type: .json, title: path.lastPathComponent, fileURL: path, parentController: nil, canEdit: contentCanEdit)
            } else if let arr = json as? Array<Any> {
                return SerializedArrayViewController(array: arr, type: .json, parentController: nil, title: path.lastPathComponent, fileURL: path, canEdit: contentCanEdit)
            }

            return nil
        case .text:
            guard let stringContents = String(data: data, encoding: .utf8) else {
                return nil
            }

            let textVC = TextFileEditorViewController(fileURL: path, contents: stringContents)
            return textVC
        case .image:
            guard let image = UIImage(data: data) else {
                return nil
            }

            return ImageViewerController(fileURL: path, image: image)
        case .video:
            let type = path.contentType
            guard (type?.isOfType(.movie) ?? false || type?.isOfType(.video) ?? false) else {
                return nil
            }

            let controller = AVPlayerViewController()
            controller.player = AVPlayer(url: path)
            controller.allowsPictureInPicturePlayback = true
            if #available(iOS 14.2, *) {
                controller.canStartPictureInPictureAutomaticallyFromInline = true
            }
            return controller
        case .font:
            guard let descriptors = CTFontManagerCreateFontDescriptorsFromURL(path as CFURL) as? [CTFontDescriptor], !descriptors.isEmpty else {
                return nil
            }

            return FontViewerController(selectedFont: descriptors.first!.uiFont, descriptors: descriptors)
        }
    }

    private func __makeSplitViewController(with vc: UIViewController, for column: UISplitViewController.Column) -> UISplitViewController {
        let splitVC = UISplitViewController(style: .doubleColumn)
        splitVC.setViewController(vc, for: column)
        return splitVC
    }

    var description: String {
        switch self {
        case .audio:
            return SantanderL10n.t("Audio Player")
        case .video:
            return SantanderL10n.t("Video Player")
        case .image:
            return SantanderL10n.t("Image Viewer")
        case .propertyList:
            return SantanderL10n.t("Property List Editor")
        case .json:
            return SantanderL10n.t("JSON Viewer")
        case .font:
            return SantanderL10n.t("Font Viewer")
        case .text:
            return SantanderL10n.t("Text Editor")
        case .assetCatalog:
            return SantanderL10n.t("Asset Catalog Viewer")
        case .executable:
            return SantanderL10n.t("Executable Runner")
        case .pdf:
            return SantanderL10n.t("PDF Editor")
        case .hex:
            return SantanderL10n.t("Hex Editor")
        case .sqlite:
            return SantanderL10n.t("SQLite3 Editor")
        case .archive:
            return SantanderL10n.t("Archive Viewer")
        case .terminal:
            return SantanderL10n.t("Terminal")
        }
    }

    var presentAsFullScreen: Bool {
        switch self {
        case .text, .image, .video, .executable, .pdf, .hex, .sqlite, .archive, .terminal:
            return true
        case .audio, .font:
            return false
        case .propertyList, .json, .assetCatalog:
            return UIDevice.isiPad
        }
    }

    var useNavigationController: Bool {
        switch self {
        case .video:
            return false
        case .text, .assetCatalog:
            return !UIDevice.isiPad
        default:
            return true
        }
    }
}


private extension FileEditorType {
    var menuImage: UIImage? {
        switch self {
        case .audio: return UIImage(systemName: "speaker.wave.2.fill")
        case .image: return SantanderIconLibrary.shared.interfaceIcon(for: "photo")
        case .video: return SantanderIconLibrary.shared.interfaceIcon(for: "play.rectangle")
        case .propertyList: return SantanderIconLibrary.shared.interfaceIcon(for: "list.bullet.rectangle")
        case .json: return SantanderIconLibrary.shared.interfaceIcon(for: "curlybraces")
        case .text: return SantanderIconLibrary.shared.uiIcon(named: "text-editor")
        case .font: return SantanderIconLibrary.shared.interfaceIcon(for: "textformat")
        case .assetCatalog: return SantanderIconLibrary.shared.interfaceIcon(for: "square.grid.2x2")
        case .executable: return SantanderIconLibrary.shared.interfaceIcon(for: "terminal")
        case .pdf: return SantanderIconLibrary.shared.interfaceIcon(for: "doc.richtext")
        case .hex: return SantanderIconLibrary.shared.uiIcon(named: "sqlite3-editor")
        case .sqlite: return SantanderIconLibrary.shared.interfaceIcon(for: "tablecells")
        case .archive: return SantanderIconLibrary.shared.interfaceIcon(for: "archivebox")
        case .terminal: return SantanderIconLibrary.shared.interfaceIcon(for: "terminal.fill")
        }
    }
}

class BinaryExecutionViewController: UIViewController {
    let executableURL: URL
    var task: SantanderTask = SantanderTask()
    var textView: UITextView!

    init(executableURL: URL) {
        self.executableURL = executableURL

        super.init(nibName: nil, bundle: nil)
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    override func viewDidLoad() {
        super.viewDidLoad()

        view.backgroundColor = .secondarySystemBackground

        title = SantanderL10n.t("Execution")
        let doneAction = UIAction {
            if self.task.isRunning {
                self.task.interrupt()
            }
            self.dismiss(animated: true)
        }

        navigationItem.rightBarButtonItem = UIBarButtonItem(systemItem: .done, primaryAction: doneAction)
        configureNavigationBarToNormal()

        let executableTextField = UITextField()

        let action = UIAction {
            if self.task.isRunning {
                self.task.interrupt()
            }
            self.spawnExecutable(pathAndArgs: executableTextField.text!)
        }

        executableTextField.autocorrectionType = .no
        executableTextField.returnKeyType = .go
        executableTextField.addAction(action, for: .primaryActionTriggered)
        executableTextField.text = executableURL.path
        executableTextField.font = UIFont(name: "Menlo", size: UIFont.systemFontSize)
        executableTextField.translatesAutoresizingMaskIntoConstraints = false
        executableTextField.backgroundColor = .systemBackground
        executableTextField.inputAccessoryView = makeKeyboardToolbar(forTextField: executableTextField)
        view.addSubview(executableTextField)

        let guide = view.safeAreaLayoutGuide
        NSLayoutConstraint.activate([
            executableTextField.trailingAnchor.constraint(equalTo: guide.trailingAnchor),
            executableTextField.leadingAnchor.constraint(equalTo: guide.leadingAnchor),
            executableTextField.topAnchor.constraint(equalTo: guide.topAnchor),
            executableTextField.heightAnchor.constraint(equalToConstant: 50),
        ])

        self.textView = UITextView()
        textView.text = ""
        textView.font = .systemFont(ofSize: 20)
        textView.isEditable = false
        textView.translatesAutoresizingMaskIntoConstraints = false
        textView.backgroundColor = view.backgroundColor
        view.addSubview(textView)

        NSLayoutConstraint.activate([
            textView.leadingAnchor.constraint(equalTo: guide.leadingAnchor),
            textView.trailingAnchor.constraint(equalTo: guide.trailingAnchor),
            textView.topAnchor.constraint(equalTo: executableTextField.bottomAnchor),
            textView.heightAnchor.constraint(equalTo: view.heightAnchor)
        ])
    }

    func makeKeyboardToolbar(forTextField textField: UITextField) -> UIToolbar {
        let toolbar = UIToolbar()

        let dismissKeyboardAction = UIAction {
            textField.resignFirstResponder()
        }

        let dismissButton = UIBarButtonItem(title: SantanderL10n.t("Dismiss"), primaryAction: dismissKeyboardAction)
        toolbar.setItems([.flexibleSpace(), dismissButton], animated: true)
        toolbar.sizeToFit()
        return toolbar
    }

    func spawnExecutable(pathAndArgs: String) {
        var components = pathAndArgs.components(separatedBy: " ")
        guard let executable = components.first, !executable.isEmpty else {
            self.errorAlert("Enter a valid executable and arguments.", title: SantanderL10n.t("Input is empty"))
            return
        }

        components.removeFirst()
        self.task = SantanderTask()
        task.executableURL = URL(fileURLWithPath: executable)
        task.arguments = components

        let pipe = Pipe()
        pipe.fileHandleForReading.readabilityHandler = { outPipe in
            guard let output = String(data: outPipe.availableData, encoding: .utf8),
            !output.isEmpty else {
                return
            }

            DispatchQueue.main.async {
                self.textView.text.append(output)
            }
        }

        task.standardError = pipe
        task.standardOutput = pipe
        do {
            textView.text = ""
            try task.launchAndReturnError()
            task.waitUntilExit()
        } catch {
            self.errorAlert(error, title: SantanderL10n.t("Unable to launch process"))
        }
    }
}

class FontViewerController: UIViewController {
    var selectedFont: UIFont
    var descriptors: [CTFontDescriptor]

    var textView: UITextView!
    var amountLabel: UILabel!

    init(selectedFont: UIFont, descriptors: [CTFontDescriptor]) {
        self.selectedFont = selectedFont
        self.descriptors = descriptors
        super.init(nibName: nil, bundle: nil)

        self.title = selectedFont.familyName
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        navigationController?.navigationBar.prefersLargeTitles = false

        view.backgroundColor = .systemBackground

        setupRightBarButton()

        self.textView = UITextView()
        textView.text = SantanderL10n.t("The quick brown fox jumps over the lazy dog and runs away.")
        textView.font = self.selectedFont
        textView.inputAccessoryView = makeKeyboardToolbar(textView: textView)
        textView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(textView)

        textView.constraintCompletely(to: view)

        configureNavigationBarToNormal()
        setupBottomView()
    }

    func setupRightBarButton() {
        let presentInfoAction = UIAction {
            if self.descriptors.count > 1 {
                let actions = self.descriptors.map { descriptor in
                    let uiFont = descriptor.uiFont
                    return SantanderActionSheetItem(title: uiFont.fontName, image: SantanderIconLibrary.shared.interfaceIcon(for: "textformat")) {
                        let vc = FontInformationViewController(font: uiFont)
                        self.present(UINavigationController(rootViewController: vc), animated: true)
                    }
                }
                self.presentSantanderActionSheet(title: SantanderL10n.t("Font Information"), actions: actions + [SantanderActionSheetItem(title: SantanderL10n.t("Cancel"), style: .cancel)])
            } else {
                let vc = FontInformationViewController(font: self.selectedFont)
                self.present(UINavigationController(rootViewController: vc), animated: true)
            }
        }

        let infoButton = UIBarButtonItem(image: SantanderIconLibrary.shared.interfaceIcon(for: "info.circle"), primaryAction: presentInfoAction)

        if descriptors.count > 1 {
            let compareAction = UIAction(title: SantanderL10n.t("Compare Fonts"), image: SantanderIconLibrary.shared.interfaceIcon(for: "rectangle.split.2x1")) { _ in
                let fonts = self.descriptors.map { $0.uiFont.withSize(self.selectedFont.pointSize) }
                self.present(UINavigationController(rootViewController: SantanderFontCompareViewController(fonts: fonts)), animated: true)
            }
            let compareButton = UIBarButtonItem(title: SantanderL10n.t("Compare"), primaryAction: compareAction)
            navigationItem.rightBarButtonItems = [
                UIBarButtonItem(title: SantanderL10n.t("Select font.."), style: .plain, target: self, action: #selector(showFontSelector)),
                compareButton,
                infoButton
            ]
        } else {
            navigationItem.rightBarButtonItem = infoButton
        }
    }

    @objc func showFontSelector() {
        let actions = descriptors.map { descriptor in
            let font = descriptor.uiFont
            return SantanderActionSheetItem(title: font.fontName, image: SantanderIconLibrary.shared.interfaceIcon(for: "textformat"), isSelected: font.fontName == selectedFont.fontName) { [weak self] in
                guard let self else { return }
                self.selectedFont = font.withSize(self.selectedFont.pointSize)
                self.updateFontSize(newSize: self.selectedFont.pointSize)
                self.setupRightBarButton()
            }
        }
        presentSantanderActionSheet(title: SantanderL10n.t("Select font.."), actions: actions + [SantanderActionSheetItem(title: SantanderL10n.t("Cancel"), style: .cancel)])
    }

    func updateFontSize(newSize: CGFloat) {
        UserPreferences.fontViewerFontSize = newSize
        self.selectedFont = selectedFont.withSize(newSize)
        self.textView.font = selectedFont
        amountLabel.text = Int(newSize).description
    }

    func setupBottomView() {
        let newView = UIView()
        newView.backgroundColor = .secondarySystemBackground

        self.amountLabel = UILabel()
        amountLabel.text = Int(selectedFont.pointSize).description

        let slider = UISlider()
        slider.maximumValue = 90
        slider.value = Float(selectedFont.pointSize)

        let sliderChangedAction = UIAction {
            self.updateFontSize(newSize: CGFloat(slider.value))
        }

        slider.addAction(sliderChangedAction, for: .valueChanged)

        let stackView = UIStackView(arrangedSubviews: [slider, amountLabel])
        stackView.translatesAutoresizingMaskIntoConstraints = false
        stackView.spacing = 10

        newView.addSubview(stackView)
        newView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(newView)
        NSLayoutConstraint.activate([
            newView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            newView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            newView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -50),
            newView.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor),

            stackView.centerYAnchor.constraint(equalTo: newView.centerYAnchor),
            stackView.leadingAnchor.constraint(equalTo: newView.layoutMarginsGuide.leadingAnchor),
            stackView.trailingAnchor.constraint(equalTo: newView.layoutMarginsGuide.trailingAnchor),
        ])

    }

    func makeKeyboardToolbar(textView: UITextView) -> UIToolbar {
        let toolbar = UIToolbar()
        let action = UIAction {
            textView.resignFirstResponder()
        }

        let doneButton = UIBarButtonItem(systemItem: .done, primaryAction: action)

        toolbar.setItems([.flexibleSpace(), doneButton], animated: true)
        toolbar.sizeToFit()
        return toolbar
    }
}

class FontInformationViewController: UITableViewController {
    let font: UIFont
    let ctFont: CTFont
    let fontName: String

    init(font: UIFont) {
        self.font = font
        self.ctFont = font as CTFont
        self.fontName = CTFontCopyAttribute(ctFont, kCTFontDisplayNameAttribute) as? String ?? font.fontName

        super.init(style: .userPreferred)
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    override func viewDidLoad() {
        super.viewDidLoad()

        let fontLabel = UILabel()
        fontLabel.text = fontName
        fontLabel.font = font.withSize(30)

        navigationItem.titleView = fontLabel
    }

    override func numberOfSections(in tableView: UITableView) -> Int {
        return 2
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        switch section {
        case 0:
            return 6
        case 1:
            return 3
        default:
            fatalError()
        }
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = UITableViewCell(style: .value1, reuseIdentifier: nil)
        SantanderUI.styleCell(cell)
        var conf = cell.defaultContentConfiguration()
        defer {
            cell.contentConfiguration = conf
        }

        switch (indexPath.section, indexPath.row) {
        case (0, 0):
            conf.text = SantanderL10n.t("Full name")
            conf.secondaryText = fontName
        case (0, 1):
            conf.text = SantanderL10n.t("Family name")
            conf.secondaryText = font.familyName
        case (0, 2):
            conf.text = SantanderL10n.t("PostScript name")
            conf.secondaryText = font.fontDescriptor.postscriptName
        case (0, 3):
            conf.text = SantanderL10n.t("Style")
            conf.secondaryText = CTFontCopyAttribute(ctFont, kCTFontStyleNameAttribute) as? String ?? SantanderL10n.t("N/A")
        case (0, 4):
            conf.text = SantanderL10n.t("Enabled")
            if let isEnabled = CTFontCopyAttribute(ctFont, kCTFontEnabledAttribute) as? Bool {
                cell.accessoryType = isEnabled ? .checkmark : .none
            } else {
                conf.secondaryText = SantanderL10n.t("N/A")
            }
        case (0, 5):
            conf.text = SantanderL10n.t("URL")
            let url = CTFontCopyAttribute(ctFont, kCTFontURLAttribute) as? URL
            conf.secondaryText = url?.path ?? SantanderL10n.t("N/A")
        case (1, 0):
            conf.text = SantanderL10n.t("Designer")
            conf.secondaryText = CTFontCopyName(ctFont, kCTFontDesignerNameKey) as? String ?? SantanderL10n.t("N/A")
        case (1, 1):
            conf.text = SantanderL10n.t("Manufacturer")
            conf.secondaryText = CTFontCopyName(ctFont, kCTFontManufacturerNameKey) as? String ?? SantanderL10n.t("N/A")
        case (1, 2):
            conf.text = SantanderL10n.t("Version")
            conf.secondaryText = CTFontCopyName(ctFont, kCTFontVersionNameKey) as? String ?? SantanderL10n.t("N/A")
        default:
            fatalError("Unhandled indexPath: \(indexPath)")
        }

        return cell
    }

    override func tableView(_ tableView: UITableView, shouldHighlightRowAt indexPath: IndexPath) -> Bool {
        return false
    }
}

class ImageMetadataViewController: UITableViewController {
    var metadata: ImageMetadata
    let fileURL: URL

    init(metadata: ImageMetadata, fileURL: URL) {
        self.metadata = metadata
        self.fileURL = fileURL

        super.init(style: .userPreferred)
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    override func numberOfSections(in tableView: UITableView) -> Int {
        return 4
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        switch section {
        case 0, 1: return 3
        case 2, 3: return 2
        default: fatalError()
        }
    }

    override func viewDidLoad() {
        super.viewDidLoad()

        self.title = SantanderL10n.t("Metadata")
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = UITableViewCell(style: .value1, reuseIdentifier: nil)
        SantanderUI.styleCell(cell)
        var conf = cell.defaultContentConfiguration()

        defer {
            cell.contentConfiguration = conf
        }

        switch (indexPath.section, indexPath.row) {
        case (0, 0):
            conf.text = SantanderL10n.t("Pixel Height")
            conf.secondaryText = metadata.pixelHeight?.description ?? SantanderL10n.t("N/A")
        case (0, 1):
            conf.text = SantanderL10n.t("Pixel Width")
            conf.secondaryText = metadata.pixelWidth?.description ?? SantanderL10n.t("N/A")
        case (0, 2):
            let datePicker = UIDatePicker()
            if let dateTaken = metadata.dateTimeTaken {
                datePicker.setDate(dateTaken, animated: true)
            }

            let action = UIAction {
                self.setNewDate(withDatePicker: datePicker)
            }

            datePicker.addAction(action, for: .editingDidEnd)
            return cellWithView(datePicker, text: SantanderL10n.t("Date Label"), rightAnchorConstant: -5)
        case (1, 0):
            conf.text = SantanderL10n.t("Camera Model")
            conf.secondaryText = metadata.cameraInfo?.model ?? SantanderL10n.t("N/A")
        case (1, 1):
            conf.text = SantanderL10n.t("Camera Manufacturer")
            conf.secondaryText = metadata.cameraInfo?.manufacturer ?? SantanderL10n.t("N/A")
        case (1, 2):
            conf.text = SantanderL10n.t("Camera Software")
            conf.secondaryText = metadata.cameraInfo?.softwareVersion ?? SantanderL10n.t("N/A")
        case (2, 0):
            conf.text = SantanderL10n.t("Lens Model")
            conf.secondaryText = metadata.exifInfo?.lensModel ?? SantanderL10n.t("N/A")
        case (2, 1):
            conf.text = SantanderL10n.t("Lens Manufacturer")
            conf.secondaryText = metadata.exifInfo?.lensManufacturer ?? SantanderL10n.t("N/A")
        case (3, 0):
            conf.text = SantanderL10n.t("Latitude")
            conf.secondaryText = metadata.location.lat?.description ?? SantanderL10n.t("N/A")
        case (3, 1):
            conf.text = SantanderL10n.t("Longitude")
            conf.secondaryText = metadata.location.long?.description ?? SantanderL10n.t("N/A")
        default:
            break
        }

        return cell
    }

    override func tableView(_ tableView: UITableView, shouldHighlightRowAt indexPath: IndexPath) -> Bool {
        return false
    }

    func headerTitle(forSection section: Int) -> String {
        switch section {
        case 0:
            return SantanderL10n.t("General")
        case 1:
            return SantanderL10n.t("Camera")
        case 2:
            return SantanderL10n.t("Lens")
        case 3:
            return SantanderL10n.t("Location")
        default:
            fatalError()
        }
    }

    func setNewDate(withDatePicker datePicker: UIDatePicker) {
        let exifFormattedDate = DateFormatter.EXIFDateFormatter.string(from: datePicker.date)
        let iptcFormattedDate = DateFormatter.IPTCDateFormatter.string(from: datePicker.date)
        var copy = metadata.dictionary

        var tiffDictionary = (copy[kCGImagePropertyTIFFDictionary as String] as? [String: Any]) ?? [:]
        tiffDictionary[kCGImagePropertyTIFFDateTime as String] = exifFormattedDate

        var exifDictionary = (copy[kCGImagePropertyExifDictionary as String] as? [String: Any]) ?? [:]
        exifDictionary[kCGImagePropertyExifDateTimeOriginal as String] = exifFormattedDate
        exifDictionary[kCGImagePropertyExifDateTimeDigitized as String] = exifFormattedDate

        var iptcDictionary = (copy[kCGImagePropertyIPTCDictionary as String] as? [String: Any]) ?? [:]
        iptcDictionary[kCGImagePropertyIPTCDateCreated as String] = iptcFormattedDate

        copy[kCGImagePropertyTIFFDictionary as String] = tiffDictionary
        copy[kCGImagePropertyExifDictionary as String] = exifDictionary
        copy[kCGImagePropertyIPTCDictionary as String] = iptcDictionary

        if !metadata.setProperties(toDictionary: copy, forFileURL: fileURL) {
            errorAlert("", title: SantanderL10n.t("Unable to set date of image"))
        }
    }

    override func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        return sectionHeaderWithButton(sectionTag: section, titleText: headerTitle(forSection: section)) { button in
            guard section == 3 else {
                button.isHidden = true
                return
            }

            let action = UIAction { _ in
                self.presentMapEditor()
            }

            button.setTitle(SantanderL10n.t("View"), for: .normal)
            button.setTitleColor(SantanderAppTheme.accentColor, for: .normal)
            button.addAction(action, for: .touchUpInside)
        }
    }

    override func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 40
    }

    func presentMapEditor() {
        let vc = ImageLocationEditorViewController(metadata: metadata, metadataSenderVC: self, fileURL: fileURL)
        let navVC = UINavigationController(rootViewController: vc)
        navVC.modalPresentationStyle = .fullScreen
        self.present(navVC, animated: true)
    }
}

class ImageLocationEditorViewController: UIViewController, MKMapViewDelegate {
    let fileURL: URL
    let metadata: ImageMetadata
    let metadataSenderVC: ImageMetadataViewController

    var mapView: MKMapView!
    var annotation: MKPointAnnotation!

    init(metadata: ImageMetadata, metadataSenderVC: ImageMetadataViewController, fileURL: URL) {
        self.metadata = metadata
        self.fileURL = fileURL
        self.metadataSenderVC = metadataSenderVC

        super.init(nibName: nil, bundle: nil)
    }

    required init?(coder: NSCoder) {
        fatalError()
    }

    override func viewDidLoad() {
        super.viewDidLoad()

        title = SantanderL10n.t("Location")

        let dismissAction = UIAction {
            self.dismiss(animated: true)
        }

        navigationItem.leftBarButtonItem = UIBarButtonItem(title: SantanderL10n.t("Dismiss"), primaryAction: dismissAction)

        mapView = MKMapView()
        mapView.translatesAutoresizingMaskIntoConstraints = false
        mapView.delegate = self

        annotation = MKPointAnnotation()

        mapView.addAnnotation(annotation)

        view.addSubview(mapView)

        mapView.constraintCompletely(to: view)

        if let center = metadata.location.coordinate {
            annotation.coordinate = center
            mapView.setRegion(MKCoordinateRegion(center: center, span: .init()), animated: true)
        }

        configureNavigationBarToNormal()
        setRightBarButton()
        setupToolbar()
    }

    func setRightBarButton() {
        let action = UIAction {
            self.setEditing(!self.isEditing, animated: true)
        }

        navigationItem.rightBarButtonItem = UIBarButtonItem(
            systemItem: isEditing ? .done : .edit,
            primaryAction: action
        )
    }

    override func setEditing(_ editing: Bool, animated: Bool) {
        super.setEditing(editing, animated: animated)

        setRightBarButton()

        if !editing {
            setImageLocation(nullify: false)
        } else {
            mapView.addAnnotation(annotation)
        }
    }

    func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
        guard let anno = self.annotation else {
            return nil
        }

        let view = MKPinAnnotationView(annotation: anno, reuseIdentifier: "DraggablePin")
        view.isDraggable = true
        return view
    }

    func moveAnnotation(_ mapView: MKMapView) {
        if isEditing {
            annotation.coordinate = mapView.centerCoordinate
        }
    }

    func setImageLocation(nullify: Bool) {
        let coordinate = annotation.coordinate
        var newGPSDict = (metadata.dictionary[kCGImagePropertyGPSDictionary as String] as? [String: Any?]) ?? [:]
        if nullify {
            newGPSDict[kCGImagePropertyGPSLatitude as String] = nil
            newGPSDict[kCGImagePropertyGPSLongitude as String] = nil
            metadata.location = ImageLocation(lat: nil, long: nil)
        } else {
            newGPSDict[kCGImagePropertyGPSLatitude as String] = coordinate.latitude
            newGPSDict[kCGImagePropertyGPSLongitude as String] = coordinate.longitude
            metadata.location = ImageLocation(lat: coordinate.latitude, long: coordinate.longitude)
        }

        var copy = metadata.dictionary
        copy[kCGImagePropertyGPSDictionary as String] = newGPSDict

        let didSucceed = metadata.setProperties(toDictionary: copy, forFileURL: fileURL)
        if !didSucceed {
            errorAlert("", title: SantanderL10n.t("Unable to set location of image"))
        } else {
            metadataSenderVC.metadata = .init(dictionary: copy)
            metadataSenderVC.tableView.reloadData()
            if nullify {
                mapView.removeAnnotation(annotation)
            }
        }
        self.setupToolbar()
    }

    func mapView(_ mapView: MKMapView, regionDidChangeAnimated animated: Bool) {
        moveAnnotation(mapView)
    }

    func setupToolbar() {
        let action = UIAction {
            self.presentSantanderActionSheet(title: SantanderL10n.t("Remove image location?"), actions: [
                SantanderActionSheetItem(title: SantanderL10n.t("Remove"), image: SantanderIconLibrary.shared.interfaceIcon(for: "trash"), style: .destructive) {
                    self.setImageLocation(nullify: true)
                },
                SantanderActionSheetItem(title: SantanderL10n.t("Cancel"), style: .cancel)
            ])
        }

        let trashButton = UIBarButtonItem(image: SantanderIconLibrary.shared.interfaceIcon(for: "trash"), primaryAction: action)
        trashButton.isEnabled = metadata.location.coordinate != nil
        trashButton.tintColor = .systemRed

        navigationController?.setToolbarHidden(false, animated: true)
        self.toolbarItems = [trashButton]
    }
}

class ImageViewerController: UIViewController, UIScrollViewDelegate {
    var fileURL: URL?
    var image: UIImage
    var metadata: ImageMetadata?
    private let imageScrollView = UIScrollView()
    private let zoomableImageView = UIImageView()
    private let thumbnailScrollView = UIScrollView()
    private let thumbnailStackView = UIStackView()
    private let infoButton = UIBarButtonItem()
    private var thumbnailURLs: [URL] = []
    private var thumbnailButtons: [UIButton] = []
    private var thumbnailHeightConstraint: NSLayoutConstraint?
    private var imageLoadGeneration = UUID()

    typealias SetWallpaperFunction = @convention(c) (_: NSDictionary, _: NSDictionary, _: Int, _: Int) -> Int

    init(fileURL: URL?, image: UIImage, title: String? = nil) {
        self.fileURL = fileURL
        self.image = image

        super.init(nibName: nil, bundle: nil)
        self.title = fileURL?.lastPathComponent ?? title
    }

    convenience init?(fileURL: URL) {
        guard let image = UIImage(contentsOfFile: fileURL.path) else {
            return nil
        }

        self.init(fileURL: fileURL, image: image)
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        if let fileURL = fileURL {
            self.metadata = ImageMetadata(fileURL: fileURL)
        }

        view.backgroundColor = .systemBackground

        let doneAction = UIAction { [weak self] _ in
            guard let self else { return }
            if let navigationController = self.navigationController,
               navigationController.viewControllers.first !== self,
               navigationController.topViewController === self {
                navigationController.popViewController(animated: true)
            } else {
                self.dismiss(animated: true)
            }
        }

        let doneButton = UIBarButtonItem(systemItem: .done, primaryAction: doneAction)
        infoButton.primaryAction = UIAction { [weak self] _ in
            guard let self, let metadata = self.metadata, let fileURL = self.fileURL else { return }
            let vc = ImageMetadataViewController(metadata: metadata, fileURL: fileURL)
            self.present(UINavigationController(rootViewController: vc), animated: true)
        }
        infoButton.image = SantanderIconLibrary.shared.interfaceIcon(for: "info.circle")
        infoButton.isEnabled = metadata != nil && fileURL != nil
        navigationItem.rightBarButtonItem = doneButton
        navigationItem.leftBarButtonItem = infoButton

        imageScrollView.translatesAutoresizingMaskIntoConstraints = false
        imageScrollView.backgroundColor = .systemBackground
        imageScrollView.delegate = self
        imageScrollView.minimumZoomScale = 1
        imageScrollView.maximumZoomScale = 6
        imageScrollView.bouncesZoom = true
        imageScrollView.showsHorizontalScrollIndicator = true
        imageScrollView.showsVerticalScrollIndicator = true
        zoomableImageView.frame = .zero
        zoomableImageView.autoresizingMask = []
        zoomableImageView.image = image
        zoomableImageView.contentMode = .scaleAspectFit
        zoomableImageView.isUserInteractionEnabled = true
        imageScrollView.addSubview(zoomableImageView)
        view.addSubview(imageScrollView)

        thumbnailScrollView.translatesAutoresizingMaskIntoConstraints = false
        thumbnailScrollView.showsHorizontalScrollIndicator = false
        thumbnailScrollView.backgroundColor = .secondarySystemBackground
        thumbnailStackView.axis = .horizontal
        thumbnailStackView.alignment = .center
        thumbnailStackView.spacing = 8
        thumbnailStackView.translatesAutoresizingMaskIntoConstraints = false
        thumbnailScrollView.addSubview(thumbnailStackView)
        view.addSubview(thumbnailScrollView)
        let stripHeight = thumbnailScrollView.heightAnchor.constraint(equalToConstant: 0)
        thumbnailHeightConstraint = stripHeight
        NSLayoutConstraint.activate([
            imageScrollView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            imageScrollView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            imageScrollView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
            imageScrollView.bottomAnchor.constraint(equalTo: thumbnailScrollView.topAnchor),
            thumbnailScrollView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            thumbnailScrollView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            thumbnailScrollView.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor),
            stripHeight,
            thumbnailStackView.leadingAnchor.constraint(equalTo: thumbnailScrollView.contentLayoutGuide.leadingAnchor, constant: 8),
            thumbnailStackView.trailingAnchor.constraint(equalTo: thumbnailScrollView.contentLayoutGuide.trailingAnchor, constant: -8),
            thumbnailStackView.topAnchor.constraint(equalTo: thumbnailScrollView.contentLayoutGuide.topAnchor, constant: 6),
            thumbnailStackView.bottomAnchor.constraint(equalTo: thumbnailScrollView.contentLayoutGuide.bottomAnchor, constant: -6),
            thumbnailStackView.heightAnchor.constraint(equalTo: thumbnailScrollView.frameLayoutGuide.heightAnchor, constant: -12)
        ])

        let doubleTap = UITapGestureRecognizer(target: self, action: #selector(handleImageDoubleTap(_:)))
        doubleTap.numberOfTapsRequired = 2
        imageScrollView.addGestureRecognizer(doubleTap)
        loadThumbnailURLs()
        updateImageFrameIfNeeded()
        NotificationCenter.default.addObserver(self, selector: #selector(thumbnailDidLoad(_:)), name: PathImageCache.didLoadNotification, object: nil)

        configureNavigationBarToNormal()
        setupToolbar()
    }

    deinit { NotificationCenter.default.removeObserver(self) }

    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        updateImageFrameIfNeeded()
    }

    private func updateImageFrameIfNeeded() {
        guard imageScrollView.bounds.width > 0, imageScrollView.bounds.height > 0, imageScrollView.zoomScale <= 1.01 else { return }
        let sourceSize = image.size
        guard sourceSize.width > 0, sourceSize.height > 0 else { return }
        let scale = min(imageScrollView.bounds.width / sourceSize.width, imageScrollView.bounds.height / sourceSize.height)
        let size = CGSize(width: sourceSize.width * scale, height: sourceSize.height * scale)
        zoomableImageView.frame = CGRect(origin: .zero, size: size)
        imageScrollView.contentSize = size
        imageScrollView.contentInset = UIEdgeInsets(
            top: max(0, (imageScrollView.bounds.height - size.height) / 2),
            left: max(0, (imageScrollView.bounds.width - size.width) / 2),
            bottom: max(0, (imageScrollView.bounds.height - size.height) / 2),
            right: max(0, (imageScrollView.bounds.width - size.width) / 2)
        )
    }

    private func loadThumbnailURLs() {
        guard let fileURL else { return }
        let current = fileURL.standardizedFileURL
        let parent = current.deletingLastPathComponent()
        let generation = imageLoadGeneration
        DispatchQueue.global(qos: .utility).async { [weak self] in
            let extensions: Set<String> = ["png", "jpg", "jpeg", "heic", "heif", "gif", "tif", "tiff", "bmp", "webp", "raw", "dng", "avif"]
            let urls = ((try? FileManager.default.contentsOfDirectory(at: parent, includingPropertiesForKeys: [.isRegularFileKey], options: [.skipsHiddenFiles])) ?? [])
                .filter { extensions.contains($0.pathExtension.lowercased()) }
                .sorted { $0.lastPathComponent.localizedStandardCompare($1.lastPathComponent) == .orderedAscending }
            DispatchQueue.main.async { [weak self] in
                guard let self, self.imageLoadGeneration == generation else { return }
                let limited = urls.count > 160 ? Array(urls.prefix(160)) : urls
                self.thumbnailURLs = limited
                self.buildThumbnailButtons()
                self.thumbnailHeightConstraint?.constant = limited.count > 1 ? 72 : 0
                self.thumbnailScrollView.isHidden = limited.count < 2
                self.view.setNeedsLayout()
            }
        }
    }

    private func buildThumbnailButtons() {
        thumbnailStackView.arrangedSubviews.forEach { view in
            thumbnailStackView.removeArrangedSubview(view)
            view.removeFromSuperview()
        }
        thumbnailButtons.removeAll(keepingCapacity: true)
        for (index, url) in thumbnailURLs.enumerated() {
            let button = UIButton(type: .custom)
            button.tag = index
            button.translatesAutoresizingMaskIntoConstraints = false
            button.imageView?.contentMode = .scaleAspectFill
            button.clipsToBounds = true
            button.layer.cornerRadius = 6
            button.layer.borderWidth = 2
            button.widthAnchor.constraint(equalToConstant: 54).isActive = true
            button.heightAnchor.constraint(equalToConstant: 54).isActive = true
            button.addAction(UIAction { [weak self] _ in self?.selectThumbnail(at: index) }, for: .touchUpInside)
            thumbnailStackView.addArrangedSubview(button)
            thumbnailButtons.append(button)
            let path = Path(url: url)
            PathImageCache.prefetch(path)
            button.setImage(PathImageCache.image(for: path) ?? SantanderIconLibrary.shared.interfaceIcon(for: "photo"), for: .normal)
            button.imageView?.contentMode = .scaleAspectFill
            button.accessibilityLabel = url.lastPathComponent
        }
        updateSelectedThumbnailBorder()
    }

    @objc private func thumbnailDidLoad(_ notification: Notification) {
        guard let url = notification.object as? URL else { return }
        guard let index = thumbnailURLs.firstIndex(where: { $0.standardizedFileURL == url.standardizedFileURL }), thumbnailButtons.indices.contains(index) else { return }
        thumbnailButtons[index].setImage(PathImageCache.image(for: Path(url: url)), for: .normal)
    }

    private func updateSelectedThumbnailBorder() {
        for (index, button) in thumbnailButtons.enumerated() {
            let selected = thumbnailURLs.indices.contains(index) && thumbnailURLs[index].standardizedFileURL == fileURL?.standardizedFileURL
            button.layer.borderColor = selected ? SantanderAppTheme.accentColor.cgColor : UIColor.clear.cgColor
            button.accessibilityTraits = selected ? [.button, .selected] : [.button]
        }
    }

    private func selectThumbnail(at index: Int) {
        guard thumbnailURLs.indices.contains(index) else { return }
        let target = thumbnailURLs[index]
        guard target.standardizedFileURL != fileURL?.standardizedFileURL else { return }
        let generation = UUID()
        imageLoadGeneration = generation
        DispatchQueue.global(qos: .userInitiated).async { [weak self] in
            guard let loadedImage = UIImage(contentsOfFile: target.path) else { return }
            let newMetadata = ImageMetadata(fileURL: target)
            DispatchQueue.main.async { [weak self] in
                guard let self, self.imageLoadGeneration == generation else { return }
                self.fileURL = target
                self.image = loadedImage
                self.metadata = newMetadata
                self.title = target.lastPathComponent
                self.infoButton.isEnabled = true
                self.zoomableImageView.image = loadedImage
                self.imageScrollView.setZoomScale(1, animated: false)
                self.updateImageFrameIfNeeded()
                self.updateSelectedThumbnailBorder()
            }
        }
    }

    func viewForZooming(in scrollView: UIScrollView) -> UIView? {
        return zoomableImageView
    }

    func scrollViewDidZoom(_ scrollView: UIScrollView) {
        let insetX = max((scrollView.bounds.width - scrollView.contentSize.width) / 2, 0)
        let insetY = max((scrollView.bounds.height - scrollView.contentSize.height) / 2, 0)
        scrollView.contentInset = UIEdgeInsets(top: insetY, left: insetX, bottom: insetY, right: insetX)
    }

    @objc private func handleImageDoubleTap(_ recognizer: UITapGestureRecognizer) {
        if imageScrollView.zoomScale > imageScrollView.minimumZoomScale + 0.1 {
            imageScrollView.setZoomScale(imageScrollView.minimumZoomScale, animated: true)
            return
        }
        let scale: CGFloat = 2.5
        let point = recognizer.location(in: zoomableImageView)
        let width = imageScrollView.bounds.width / scale
        let height = imageScrollView.bounds.height / scale
        let rect = CGRect(x: point.x - width / 2, y: point.y - height / 2, width: width, height: height)
        imageScrollView.zoom(to: rect, animated: true)
    }

    func setupFailedLabel() {
        let failedLabel = UILabel()
        failedLabel.text = SantanderL10n.t("Failed to display image.")
        failedLabel.textColor = .systemGray
        failedLabel.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(failedLabel)

        NSLayoutConstraint.activate([
            failedLabel.centerXAnchor.constraint(equalTo: self.view.centerXAnchor),
            failedLabel.centerYAnchor.constraint(equalTo: self.view.centerYAnchor)
        ])
    }

    func setupToolbar() {
        let shareMenuAction = UIAction {
            if let fileURL = self.fileURL {
                self.presentActivityVC(forItems: [fileURL])
            } else {
                self.presentActivityVC(forItems: [self.image])
            }
        }

        let shareMenuButton = UIBarButtonItem(image: SantanderIconLibrary.shared.interfaceIcon(for: "square.and.arrow.up"), primaryAction: shareMenuAction)
        self.toolbarItems = [shareMenuButton, .flexibleSpace(), UIBarButtonItem(image: SantanderIconLibrary.shared.interfaceIcon(for: "ellipsis.circle"), style: .plain, target: self, action: #selector(showImageActions))]
        self.navigationController?.setToolbarHidden(false, animated: true)
    }

    @objc func showImageActions() {
        var actions: [SantanderActionSheetItem] = [
            SantanderActionSheetItem(title: SantanderL10n.t("Save Image"), image: SantanderIconLibrary.shared.interfaceIcon(for: "square.and.arrow.down")) { [weak self] in
                guard let self else { return }
                self.saveImage(self.image)
            }
        ]
        actions.append(contentsOf: WallpaperDestination.allCases.map { location in
            SantanderActionSheetItem(title: "\(SantanderL10n.t("Set as wallpaper for..")) · \(location.description)", image: SantanderIconLibrary.shared.interfaceIcon(for: "photo")) { [weak self] in self?.setImageAsWallpaper(to: location) }
        })
        actions.append(SantanderActionSheetItem(title: SantanderL10n.t("Cancel"), style: .cancel))
        presentSantanderActionSheet(title: SantanderL10n.t("Image actions"), actions: actions)
    }

    func setImageAsWallpaper(to location: WallpaperDestination) {
        let sbF = dlopen("/System/Library/PrivateFrameworks/SpringBoardFoundation.framework/SpringBoardFoundation", RTLD_LAZY)
        let sbServer = dlopen("/System/Library/PrivateFrameworks/SpringBoardUIServices.framework/SpringBoardUIServices", RTLD_LAZY)

        defer {
            dlclose(sbF)
            dlclose(sbServer)
        }

        guard let options = NSClassFromString("SBFWallpaperOptions")?.alloc(),
              let pointer = dlsym(sbServer, "SBSUIWallpaperSetImages"),
              let setWallpaper = unsafeBitCast(pointer, to: (SetWallpaperFunction)?.self)
        else {
            errorAlert(nil, title: SantanderL10n.t("无法设置壁纸"))
            return
        }

        let imagesDict = [
            "light": image,
            "dark": image
        ]

        let optionsDict = [
            "light" : options,
            "dark": options
        ]

        let result = setWallpaper(NSDictionary(dictionary: imagesDict), NSDictionary(dictionary: optionsDict), location.rawValue, traitCollection.userInterfaceStyle.rawValue)
        if result != 1 {
            errorAlert("SBSUIWallpaperSetImages returned status code \(result) (should be 1)", title: SantanderL10n.t("无法设置壁纸"))
        }
    }

    enum WallpaperDestination: Int, CustomStringConvertible, CaseIterable {
        static let allCases: [WallpaperDestination] = [.homeScreen, .lockScreen, .both]

        case lockScreen = 1
        case homeScreen = 2
        case both = 3

        var description: String {
            switch self {
            case .lockScreen:
                return SantanderL10n.t("Lock Screen")
            case .homeScreen:
                return SantanderL10n.t("Home Screen")
            case .both:
                return SantanderL10n.t("Home Screen & Lock Screen")
            }
        }
    }
}

private final class SerializedArrayItemDelegate: NSObject, SerializedItemViewControllerDelegate {
    weak var controller: SerializedArrayViewController?
    let index: Int

    init(controller: SerializedArrayViewController, index: Int) {
        self.controller = controller
        self.index = index
    }

    func didChangeName(ofItem item: String, to newName: String) -> Bool {
        false
    }

    func didChangeValue(ofItem item: String, to newValue: SerializedItemType) -> Bool {
        guard let controller else { return false }
        var values = controller.array
        values[index] = newValue.representedObject
        return controller.writeToFile(newArray: values)
    }
}


private struct PlistTreePath: Hashable {
    enum Component: Hashable {
        case key(String)
        case index(Int)
    }
    var components: [Component] = []

    func appending(_ component: Component) -> PlistTreePath {
        var result = self
        result.components.append(component)
        return result
    }

    var parent: PlistTreePath? {
        guard !components.isEmpty else { return nil }
        var result = components
        result.removeLast()
        return PlistTreePath(components: result)
    }

    var lastComponent: Component? { components.last }
}

private struct PlistTreeNode {
    let path: PlistTreePath
    let depth: Int
    let label: String
    let value: Any
    let item: SerializedItemType
    let isContainer: Bool
}

private final class PlistTreeItemDelegate: NSObject, SerializedItemViewControllerDelegate {
    weak var controller: PlistTreeEditorViewController?
    var path: PlistTreePath

    init(controller: PlistTreeEditorViewController, path: PlistTreePath) {
        self.controller = controller
        self.path = path
    }

    func didChangeName(ofItem item: String, to newName: String) -> Bool {
        guard let controller else { return false }
        guard controller.renameDictionaryKey(at: path, to: newName) else { return false }
        if case .key = path.lastComponent {
            path.components[path.components.count - 1] = .key(newName)
        }
        return true
    }

    func didChangeValue(ofItem item: String, to newValue: SerializedItemType) -> Bool {
        controller?.replaceNode(at: path, with: newValue.representedObject) ?? false
    }
}

private final class PlistTypeBadgeView: UIView {
    private let label = UILabel()

    init(type: SerializedItemType, isContainer: Bool) {
        super.init(frame: CGRect(x: 0, y: 0, width: 24, height: 24))
        translatesAutoresizingMaskIntoConstraints = false
        widthAnchor.constraint(equalToConstant: 24).isActive = true
        heightAnchor.constraint(equalToConstant: 24).isActive = true
        layer.cornerRadius = 12
        layer.cornerCurve = .continuous
        backgroundColor = UIColor.secondarySystemFill

        label.translatesAutoresizingMaskIntoConstraints = false
        label.font = .systemFont(ofSize: 11, weight: .semibold)
        label.textAlignment = .center
        label.textColor = .secondaryLabel
        label.text = Self.symbol(for: type, isContainer: isContainer)
        addSubview(label)
        NSLayoutConstraint.activate([
            label.leadingAnchor.constraint(equalTo: leadingAnchor),
            label.trailingAnchor.constraint(equalTo: trailingAnchor),
            label.topAnchor.constraint(equalTo: topAnchor),
            label.bottomAnchor.constraint(equalTo: bottomAnchor)
        ])
    }

    required init?(coder: NSCoder) { fatalError() }

    private static func symbol(for item: SerializedItemType, isContainer: Bool) -> String {
        switch item {
        case .string: return "S"
        case .bool: return "B"
        case .int: return "I"
        case .float: return "R"
        case .date: return "D"
        case .data: return "D"
        case .array: return "A"
        case .dictionary: return "D"
        case .other: return isContainer ? "D" : "?"
        }
    }
}

final class PlistTreeEditorViewController: UITableViewController {
    private var rootValue: Any
    private let format: PropertyListSerialization.PropertyListFormat?
    private let fileURL: URL?
    private let canEdit: Bool
    private var expandedPaths = Set<PlistTreePath>()
    private var activeContainerPath: PlistTreePath?
    private var rows: [PlistTreeNode] = []
    private var retainedDelegates: [PlistTreeItemDelegate] = []
    private var hasUnsavedChanges = false

    init(
        rootValue: Any,
        format: PropertyListSerialization.PropertyListFormat?,
        fileURL: URL?,
        title: String,
        canEdit: Bool
    ) {
        self.rootValue = rootValue
        self.format = format
        self.fileURL = fileURL
        self.canEdit = canEdit
        super.init(style: .insetGrouped)
        self.title = title
        self.expandedPaths = isContainerValue(rootValue) ? [PlistTreePath()] : []
        self.activeContainerPath = isContainerValue(rootValue) ? PlistTreePath() : nil
    }

    required init?(coder: NSCoder) { fatalError("init(coder:) has not been implemented") }

    override func viewDidLoad() {
        super.viewDidLoad()
        applySantanderUI()
        navigationItem.largeTitleDisplayMode = .never
        let backButton = UIBarButtonItem(title: SantanderL10n.t("Back"), style: .plain, target: self, action: #selector(closeEditor))
        navigationItem.leftBarButtonItem = backButton
        if canEdit {
            let add = UIBarButtonItem(systemItem: .add, primaryAction: UIAction { [weak self] _ in self?.addNewTeamValue() })
            let save = UIBarButtonItem(title: SantanderL10n.t("Save"), style: .done, target: self, action: #selector(saveChanges))
            navigationItem.rightBarButtonItems = [save, add]
            updateSaveButton()
        } else {
            navigationItem.rightBarButtonItems = nil
        }
        tableView.rowHeight = UITableView.automaticDimension
        tableView.estimatedRowHeight = 52
        reloadTree()
    }

    override func numberOfSections(in tableView: UITableView) -> Int { 1 }
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int { rows.count }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let node = rows[indexPath.row]
        let reuseIdentifier = "SantanderPlistTreeNodeCell"
        let cell = tableView.dequeueReusableCell(withIdentifier: reuseIdentifier)
            ?? UITableViewCell(style: .default, reuseIdentifier: reuseIdentifier)
        cell.contentView.subviews.forEach { $0.removeFromSuperview() }
        SantanderUI.styleCell(cell)
        cell.selectionStyle = (canEdit || node.isContainer) ? .default : .none

        let stack = UIStackView()
        stack.axis = .horizontal
        stack.alignment = .center
        stack.spacing = 7
        stack.translatesAutoresizingMaskIntoConstraints = false
        cell.contentView.addSubview(stack)

        let indent = UIView()
        indent.translatesAutoresizingMaskIntoConstraints = false
        indent.widthAnchor.constraint(equalToConstant: CGFloat(node.depth) * 18).isActive = true
        stack.addArrangedSubview(indent)

        if node.isContainer {
            let disclosure = UIButton(type: .system)
            disclosure.translatesAutoresizingMaskIntoConstraints = false
            disclosure.widthAnchor.constraint(equalToConstant: 22).isActive = true
            disclosure.heightAnchor.constraint(equalToConstant: 32).isActive = true
            let expanded = expandedPaths.contains(node.path)
            disclosure.setImage(UIImage(systemName: expanded ? "chevron.down" : "chevron.right"), for: .normal)
            disclosure.tintColor = .secondaryLabel
            disclosure.accessibilityLabel = expanded ? SantanderL10n.t("Collapse") : SantanderL10n.t("Expand")
            disclosure.accessibilityTraits = .button
            disclosure.addAction(UIAction { [weak self] _ in
                guard let self = self, let row = self.rows.firstIndex(where: { $0.path == node.path }) else { return }
                self.toggleExpansion(at: row)
            }, for: .touchUpInside)
            stack.addArrangedSubview(disclosure)
        } else {
            let spacer = UIView()
            spacer.translatesAutoresizingMaskIntoConstraints = false
            spacer.widthAnchor.constraint(equalToConstant: 22).isActive = true
            stack.addArrangedSubview(spacer)
        }

        stack.addArrangedSubview(PlistTypeBadgeView(type: node.item, isContainer: node.isContainer))

        let nameLabel = UILabel()
        nameLabel.text = node.label
        nameLabel.font = .preferredFont(forTextStyle: .body)
        nameLabel.numberOfLines = 1
        nameLabel.lineBreakMode = .byTruncatingTail
        nameLabel.setContentCompressionResistancePriority(.defaultLow, for: .horizontal)
        stack.addArrangedSubview(nameLabel)

        let spacer = UIView()
        spacer.setContentHuggingPriority(.defaultLow, for: .horizontal)
        spacer.setContentCompressionResistancePriority(.defaultLow, for: .horizontal)
        stack.addArrangedSubview(spacer)

        let valueLabel = UILabel()
        valueLabel.font = .preferredFont(forTextStyle: .subheadline)
        valueLabel.textAlignment = .right
        valueLabel.numberOfLines = 1
        valueLabel.lineBreakMode = .byTruncatingMiddle
        valueLabel.setContentHuggingPriority(.required, for: .horizontal)
        valueLabel.setContentCompressionResistancePriority(.required, for: .horizontal)
        valueLabel.textColor = SantanderAppTheme.accentColor

        switch node.item {
        case .array(let array):
            valueLabel.text = "Array[\(array.count)]"
        case .dictionary(let dictionary):
            valueLabel.text = "Dictionary[\(dictionary.count)]"
        case .bool(let value):
            valueLabel.text = value ? "✓" : ""
            valueLabel.font = .systemFont(ofSize: 20, weight: .semibold)
        default:
            valueLabel.text = node.item.description
        }

        stack.addArrangedSubview(valueLabel)

        let info = UIButton(type: .system)
        info.translatesAutoresizingMaskIntoConstraints = false
        info.widthAnchor.constraint(equalToConstant: 28).isActive = true
        info.heightAnchor.constraint(equalToConstant: 32).isActive = true
        info.setImage(SantanderIconLibrary.shared.interfaceIcon(for: "info.circle"), for: .normal)
        info.accessibilityLabel = SantanderL10n.t("Information")
        info.addAction(UIAction { [weak self] _ in
            guard let self = self, let row = self.rows.firstIndex(where: { $0.path == node.path }) else { return }
            self.openDetails(for: row)
        }, for: .touchUpInside)
        stack.addArrangedSubview(info)

        NSLayoutConstraint.activate([
            stack.leadingAnchor.constraint(equalTo: cell.contentView.layoutMarginsGuide.leadingAnchor),
            stack.trailingAnchor.constraint(equalTo: cell.contentView.layoutMarginsGuide.trailingAnchor),
            stack.topAnchor.constraint(equalTo: cell.contentView.topAnchor, constant: 5),
            stack.bottomAnchor.constraint(equalTo: cell.contentView.bottomAnchor, constant: -5)
        ])
        return cell
    }

    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        guard rows.indices.contains(indexPath.row) else { return }
        let node = rows[indexPath.row]
        if node.isContainer {
            activeContainerPath = node.path
            toggleExpansion(at: indexPath.row)
        } else {
            openDetails(for: indexPath.row)
        }
    }

    override func tableView(_ tableView: UITableView, trailingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration? {
        guard canEdit, rows.indices.contains(indexPath.row) else { return nil }
        let node = rows[indexPath.row]
        let delete = UIContextualAction(style: .destructive, title: nil) { [weak self] _, _, completion in
            guard let self else { completion(false); return }
            if self.deleteNode(at: node.path) {
                completion(true)
            } else {
                completion(false)
            }
        }
        delete.image = SantanderIconLibrary.shared.interfaceIcon(for: "trash")
        return UISwipeActionsConfiguration(actions: [delete])
    }

    private func toggleExpansion(at row: Int) {
        guard rows.indices.contains(row) else { return }
        let path = rows[row].path
        let oldRows = rows
        let willExpand = !expandedPaths.contains(path)
        if willExpand {
            expandedPaths.insert(path)
        } else {
            expandedPaths = expandedPaths.filter { existing in
                !(existing == path || existing.components.starts(with: path.components))
            }
        }

        var newRows: [PlistTreeNode] = []
        let rootItem = SerializedItemType(item: rootValue)
        newRows.append(PlistTreeNode(path: PlistTreePath(), depth: 0, label: SantanderL10n.t("Root"), value: rootValue, item: rootItem, isContainer: isContainerValue(rootValue)))
        if isContainerValue(rootValue), expandedPaths.contains(PlistTreePath()) {
            buildChildRows(from: rootValue, at: PlistTreePath(), depth: 1, into: &newRows)
        }
        rows = newRows

        let oldPaths = Set(oldRows.map(\.path))
        let newPaths = Set(newRows.map(\.path))
        let deleted = oldRows.enumerated().compactMap { newPaths.contains($0.element.path) ? nil : IndexPath(row: $0.offset, section: 0) }.sorted(by: { $0.row > $1.row })
        let inserted = newRows.enumerated().compactMap { oldPaths.contains($0.element.path) ? nil : IndexPath(row: $0.offset, section: 0) }

        if let cell = tableView.cellForRow(at: IndexPath(row: row, section: 0)),
           let button = cell.contentView.subviews.flatMap({ $0.subviews }).compactMap({ $0 as? UIButton }).first {
            UIView.transition(with: button, duration: UIAccessibility.isReduceMotionEnabled ? 0 : 0.28, options: [.transitionCrossDissolve, .beginFromCurrentState, .curveEaseInOut]) {
                button.setImage(UIImage(systemName: willExpand ? "chevron.down" : "chevron.right"), for: .normal)
            }
        }

        tableView.performBatchUpdates({
            if !deleted.isEmpty {
                tableView.deleteRows(at: deleted, with: willExpand ? .fade : .none)
            }
            if !inserted.isEmpty {
                tableView.insertRows(at: inserted, with: .fade)
            }
        })
    }

    private func openDetails(for row: Int) {
        guard rows.indices.contains(row) else { return }
        let node = rows[row]
        let vc = SerializedItemViewController(
            item: node.item,
            itemKey: node.label,
            allowsKeyEditing: { if case .key = node.path.lastComponent { return true }; return false }(),
            documentType: .plist(format: format),
            canEdit: canEdit
        )
        let delegate = PlistTreeItemDelegate(controller: self, path: node.path)
        vc.delegate = delegate
        vc.retainedDelegate = delegate
        retainedDelegates.append(delegate)
        navigationController?.pushViewController(vc, animated: true)
    }

    private func addNewTeamValue() {
        let targetPath = activeContainerPath
        let target = targetPath.flatMap(value(at:)) ?? rootValue
        switch target {
        case var dictionary as [String: Any]:
            var key = "NewTeam"
            var suffix = 2
            while dictionary[key] != nil {
                key = "NewTeam \(suffix)"
                suffix += 1
            }
            dictionary[key] = false
            if let targetPath {
                _ = replaceNode(at: targetPath, with: dictionary)
                expandedPaths.insert(targetPath)
                activeContainerPath = targetPath
            } else if writeAndApplyRoot(dictionary) {
                rootValue = dictionary
            }
        case var array as [Any]:
            array.append(false)
            if let targetPath {
                _ = replaceNode(at: targetPath, with: array)
            } else {
                _ = writeAndApplyRoot(array)
            }
        default:
            if let rootDict = rootValue as? [String: Any] {
                var mutable = rootDict
                var key = "NewTeam"
                var suffix = 2
                while mutable[key] != nil { key = "NewTeam \(suffix)"; suffix += 1 }
                mutable[key] = false
                _ = writeAndApplyRoot(mutable)
            } else if var rootArray = rootValue as? [Any] {
                rootArray.append(false)
                _ = writeAndApplyRoot(rootArray)
            }
        }
        reloadTree()
    }

    @discardableResult
    fileprivate func replaceNode(at path: PlistTreePath, with newValue: Any) -> Bool {
        guard path.components.isEmpty || value(at: path) != nil else { return false }
        let newRoot = replacing(rootValue, at: path.components, with: newValue)
        guard writeAndApplyRoot(newRoot) else { return false }
        rootValue = newRoot
        expandedPaths = expandedPaths.filter { p in
            guard let value = self.value(at: p) else { return false }
            return isContainerValue(value)
        }
        if isContainerValue(newValue) { expandedPaths.insert(path) }
        return true
    }

    fileprivate func renameDictionaryKey(at path: PlistTreePath, to newName: String) -> Bool {
        guard !newName.isEmpty, let last = path.lastComponent else { return false }
        guard case .key(let oldName) = last else { return false }
        if oldName == newName { return true }
        let parentPath = path.parent ?? PlistTreePath()
        guard var dictionary = value(at: parentPath) as? [String: Any], dictionary[oldName] != nil else { return false }
        guard dictionary[newName] == nil else {
            errorAlert(SantanderL10n.t("The key already exists."), title: SantanderL10n.t("Duplicate Key"))
            return false
        }
        let value = dictionary.removeValue(forKey: oldName)!
        dictionary[newName] = value
        let newRoot = replacing(rootValue, at: parentPath.components, with: dictionary)
        guard writeAndApplyRoot(newRoot) else { return false }
        rootValue = newRoot
        let newPath = PlistTreePath(components: parentPath.components + [.key(newName)])
        if expandedPaths.contains(path) { expandedPaths.insert(newPath); expandedPaths.remove(path) }
        if activeContainerPath == path { activeContainerPath = newPath }
        return true
    }

    @discardableResult
    private func deleteNode(at path: PlistTreePath) -> Bool {
        guard !path.components.isEmpty else { return false }
        let newRoot = removing(rootValue, at: path.components)
        guard writeAndApplyRoot(newRoot) else { return false }
        rootValue = newRoot
        expandedPaths = expandedPaths.filter { !($0 == path || $0.components.starts(with: path.components)) }
        if activeContainerPath == path { activeContainerPath = path.parent }
        reloadTree()
        return true
    }

    private func writeAndApplyRoot(_ newRoot: Any) -> Bool {
        guard canEdit else { return false }
        if let format {
            do { _ = try PropertyListSerialization.data(fromPropertyList: newRoot, format: format, options: 0) }
            catch {
                errorAlert(error, title: SantanderL10n.t("Unable to write to file"))
                return false
            }
        }
        hasUnsavedChanges = true
        updateSaveButton()
        return true
    }

    @objc private func saveChanges() {
        guard canEdit, hasUnsavedChanges, let fileURL, let format else { return }
        do {
            try ensureFileContentIsUnlocked(fileURL)
            let data = try PropertyListSerialization.data(fromPropertyList: rootValue, format: format, options: 0)
            try FSOperation.perform(.writeData(url: fileURL, data: data), rootHelperConf: RootConf.shared)
            hasUnsavedChanges = false
            updateSaveButton()
        } catch {
            errorAlert(error, title: SantanderL10n.t("Unable to write to file"))
        }
    }

    private func updateSaveButton() {
        guard let buttons = navigationItem.rightBarButtonItems else { return }
        for button in buttons where button.action == #selector(saveChanges) {
            button.isEnabled = hasUnsavedChanges
        }
    }

    @objc private func closeEditor() {
        if let navigationController, navigationController.presentingViewController != nil {
            navigationController.dismiss(animated: true)
        } else {
            navigationController?.popViewController(animated: true)
        }
    }

    private func reloadTree() {
        rows.removeAll(keepingCapacity: true)
        let rootItem = SerializedItemType(item: rootValue)
        let rootContainer = isContainerValue(rootValue)
        rows.append(PlistTreeNode(
            path: PlistTreePath(),
            depth: 0,
            label: SantanderL10n.t("Root"),
            value: rootValue,
            item: rootItem,
            isContainer: rootContainer
        ))
        if rootContainer && expandedPaths.contains(PlistTreePath()) {
            buildChildRows(from: rootValue, at: PlistTreePath(), depth: 1, into: &rows)
        }
        tableView.reloadData()
        updateSaveButton()
    }

    private func buildChildRows(from value: Any, at path: PlistTreePath, depth: Int, into rows: inout [PlistTreeNode]) {
        if let dictionary = value as? [String: Any] {
            for key in dictionary.keys.sorted(by: { $0.localizedStandardCompare($1) == .orderedAscending }) {
                let childPath = path.appending(.key(key))
                let child = dictionary[key]!
                let item = SerializedItemType(item: child)
                let container = isContainerValue(child)
                rows.append(PlistTreeNode(path: childPath, depth: depth, label: key, value: child, item: item, isContainer: container))
                if container, expandedPaths.contains(childPath) {
                    buildChildRows(from: child, at: childPath, depth: depth + 1, into: &rows)
                }
            }
        } else if let array = value as? [Any] {
            for index in array.indices {
                let child = array[index]
                let childPath = path.appending(.index(index))
                let item = SerializedItemType(item: child)
                let container = isContainerValue(child)
                rows.append(PlistTreeNode(path: childPath, depth: depth, label: "Item \(index)", value: child, item: item, isContainer: container))
                if container, expandedPaths.contains(childPath) {
                    buildChildRows(from: child, at: childPath, depth: depth + 1, into: &rows)
                }
            }
        }
    }

    private func value(at path: PlistTreePath?) -> Any? {
        guard let path else { return nil }
        return value(at: path.components)
    }

    private func value(at components: [PlistTreePath.Component]) -> Any? {
        var current = rootValue
        for component in components {
            switch component {
            case .key(let key):
                guard let dictionary = current as? [String: Any], let next = dictionary[key] else { return nil }
                current = next
            case .index(let index):
                guard let array = current as? [Any], array.indices.contains(index) else { return nil }
                current = array[index]
            }
        }
        return current
    }

    private func isContainerValue(_ value: Any) -> Bool {
        value is [String: Any] || value is [Any]
    }

    private func replacing(_ value: Any, at components: [PlistTreePath.Component], with newValue: Any) -> Any {
        guard let component = components.first else { return newValue }
        let rest = Array(components.dropFirst())
        switch component {
        case .key(let key):
            guard var dictionary = value as? [String: Any], let child = dictionary[key] else { return value }
            dictionary[key] = replacing(child, at: rest, with: newValue)
            return dictionary
        case .index(let index):
            guard var array = value as? [Any], array.indices.contains(index) else { return value }
            array[index] = replacing(array[index], at: rest, with: newValue)
            return array
        }
    }

    private func removing(_ value: Any, at components: [PlistTreePath.Component]) -> Any {
        guard let component = components.first else { return value }
        let rest = Array(components.dropFirst())
        switch component {
        case .key(let key):
            guard var dictionary = value as? [String: Any] else { return value }
            if rest.isEmpty {
                dictionary.removeValue(forKey: key)
            } else if let child = dictionary[key] {
                dictionary[key] = removing(child, at: rest)
            }
            return dictionary
        case .index(let index):
            guard var array = value as? [Any], array.indices.contains(index) else { return value }
            if rest.isEmpty {
                array.remove(at: index)
            } else {
                array[index] = removing(array[index], at: rest)
            }
            return array
        }
    }
}

class SerializedArrayViewController: UITableViewController {
    var array: Array<Any>
    let type: SerializedDocumentViewerType
    let fileURL: URL?
    let canEdit: Bool
    var parentController: SerializedControllerParent?

    init(
        array: Array<Any>,
        type: SerializedDocumentViewerType,
        parentController: SerializedControllerParent?,
        title: String?,
        fileURL: URL?,
        canEdit: Bool
    ) {
        self.array = array
        self.type = type
        self.fileURL = fileURL
        self.canEdit = canEdit
        self.parentController = parentController

        super.init(style: .userPreferred)
        self.title = title
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        applySantanderUI()
        guard canEdit else { return }
        navigationItem.rightBarButtonItem = UIBarButtonItem(
            systemItem: .add,
            primaryAction: UIAction { [weak self] _ in
                self?.presentAddArrayItem()
            }
        )
    }

    func presentAddArrayItem() {
        let alert = UIAlertController(title: SantanderL10n.t("Add Value"), message: nil, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "String", style: .default) { [weak self] _ in self?.appendValue("") })
        alert.addAction(UIAlertAction(title: "Boolean", style: .default) { [weak self] _ in self?.appendValue(false) })
        alert.addAction(UIAlertAction(title: "Integer", style: .default) { [weak self] _ in self?.appendValue(0) })
        alert.addAction(UIAlertAction(title: "Real", style: .default) { [weak self] _ in self?.appendValue(0.0) })
        alert.addAction(UIAlertAction(title: "Date", style: .default) { [weak self] _ in self?.appendValue(Date()) })
        if case .plist = type {
            alert.addAction(UIAlertAction(title: "Data", style: .default) { [weak self] _ in self?.appendValue(Data()) })
        }
        alert.addAction(UIAlertAction(title: "Array", style: .default) { [weak self] _ in self?.appendValue([Any]()) })
        alert.addAction(UIAlertAction(title: "Dictionary", style: .default) { [weak self] _ in self?.appendValue([String: Any]()) })
        alert.addAction(.cancel())
        present(alert, animated: true)
    }

    func appendValue(_ value: Any) {
        var newArray = array
        newArray.append(value)
        let index = newArray.count - 1
        guard writeToFile(newArray: newArray) else { return }
        tableView.insertRows(at: [IndexPath(row: index, section: 0)], with: .automatic)
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return array.count
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = UITableViewCell()
        SantanderUI.styleCell(cell)
        var conf = cell.defaultContentConfiguration()
        let item = array[indexPath.row]

        let serialized = SerializedItemType(item: item)
        conf.text = "Item \(indexPath.row)"
        if let array = item as? [Any] {
            conf.secondaryText = "Array • \(array.count) 项"
            cell.accessoryType = .disclosureIndicator
        } else if let dictionary = item as? [String: Any] {
            conf.secondaryText = "Dictionary • \(dictionary.count) 项"
            cell.accessoryType = .disclosureIndicator
        } else {
            let value = serialized.description.isEmpty ? "" : " • \(serialized.description)"
            conf.secondaryText = "\(serialized.typeDescription)\(value)"
            cell.accessoryType = .detailButton
        }

        cell.contentConfiguration = conf
        return cell
    }

    override func tableView(_ tableView: UITableView, shouldHighlightRowAt indexPath: IndexPath) -> Bool {
        return true
    }

    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if let arr = array[indexPath.row] as? Array<Any> {
            let title = "Item \(indexPath.row)"
            let vc = SerializedArrayViewController(
                array: arr,
                type: type,
                parentController: .array(self, index: indexPath.row),
                title: title,
                fileURL: fileURL,
                canEdit: canEdit
            )

            navigationController?.pushViewController(vc, animated: true)
        } else if let dict = array[indexPath.row] as? [String: Any] {
            let serializedDict = dict.asSerializedDictionary()

            let title = "Item \(indexPath.row)"
            let vc = SerializedDocumentViewController(dictionary: serializedDict, type: type, title: title, fileURL: fileURL, parentController: .array(self, index: indexPath.row), canEdit: true)
            navigationController?.pushViewController(vc, animated: true)
        } else {
            let item = SerializedItemType(item: array[indexPath.row])
            let vc = SerializedItemViewController(item: item, itemKey: "Item \(indexPath.row)", allowsKeyEditing: false, documentType: type, canEdit: canEdit)
            let delegate = SerializedArrayItemDelegate(controller: self, index: indexPath.row)
            vc.delegate = delegate
            vc.retainedDelegate = delegate
            navigationController?.pushViewController(vc, animated: true)
        }
    }

    override func tableView(_ tableView: UITableView, trailingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration? {
        guard canEdit else {
            return nil
        }

        let removeAction = UIContextualAction(style: .destructive, title: nil) { _, _, completion in
            var newArr = self.array
            newArr.remove(at: indexPath.row)

            if self.writeToFile(newArray: newArr) {
                tableView.deleteRows(at: [indexPath], with: .fade)
                completion(true)
            } else {
                completion(false)
            }
        }

        removeAction.image = .remove
        return UISwipeActionsConfiguration(actions: [removeAction])
    }

    func writeToFile(newArray: Array<Any>) -> Bool {

        if let parentController = parentController {
            let didSucceed: Bool

            switch parentController {
            case .dictionary(let parent, let key):
                var parentDict = parent.serializedDict
                parentDict[key] = .array(newArray)
                didSucceed = parent.writeToFile(newDict: parentDict)
            case .array(let parent, let index):
                guard parent.array.indices.contains(index) else {
                    return false
                }
                var parentArr = parent.array
                parentArr[index] = newArray
                didSucceed = parent.writeToFile(newArray: parentArr)
            }

            if didSucceed {
                self.array = newArray
            }

            return didSucceed
        }

        guard let fileURL = fileURL else {
            return false
        }

        do {
            try ensureFileContentIsUnlocked(fileURL)
            let newSerializedData: Data
            switch type {
            case .json:
                newSerializedData = try JSONSerialization.data(withJSONObject: newArray)
            case .plist(let format):
                guard let format = format else {
                    return false
                }

                newSerializedData = try PropertyListSerialization.data(fromPropertyList: newArray, format: format, options: 0)
            }

            try FSOperation.perform(.writeData(url: fileURL, data: newSerializedData), rootHelperConf: RootConf.shared)
            self.array = newArray
            return true
        } catch {
            self.errorAlert(error, title: SantanderL10n.t("Unable to write to file"))
            return false
        }
    }
}

typealias SerializedDictionaryType = [String: SerializedItemType]

class SerializedDocumentViewController: UITableViewController, SerializedItemViewControllerDelegate {

    var serializedDict: SerializedDictionaryType

    var filteredDict: SerializedDictionaryType = [:]

    var keys: [String] {
        let keysArr = Array(isSearching ? filteredDict.keys : serializedDict.keys)
        return keysArr.sorted { $0.localizedStandardCompare($1) == .orderedAscending }
    }

    var fileURL: URL?
    var canEdit: Bool
    var isSearching: Bool = false
    let type: SerializedDocumentViewerType
    let parentController: SerializedControllerParent?

    init(
        dictionary: SerializedDictionaryType,
        type: SerializedDocumentViewerType,
        title: String,
        fileURL: URL? = nil,
        parentController: SerializedControllerParent?,
        canEdit: Bool
    ) {
        self.serializedDict = dictionary
        self.type = type
        self.fileURL = fileURL
        self.canEdit = canEdit
        self.parentController = parentController

        super.init(style: .userPreferred)
        self.title = title
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        applySantanderUI()

        let closeButton = UIBarButtonItem(systemItem: .done, primaryAction: UIAction(withClosure: dismissVC))
        let addButton = UIBarButtonItem(
            systemItem: .add,
            primaryAction: UIAction { [weak self] _ in
                self?.presentAddValue()
            }
        )
        navigationItem.rightBarButtonItems = canEdit ? [closeButton, addButton] : [closeButton]
        let searchController = UISearchController()
        searchController.searchBar.delegate = self
        navigationItem.searchController = searchController
        navigationItem.hidesSearchBarWhenScrolling = !UserPreferences.alwaysShowSearchBar
    }

    convenience init?(
        type: SerializedDocumentViewerType,
        fileURL: URL,
        data: Data,
        canEdit: Bool
    ) {

        switch type {
        case .json:
            guard let json = try? JSONSerialization.jsonObject(with: data) as? [String: Any] else {
                return nil
            }

            let newDict = json.asSerializedDictionary()
            self.init(dictionary: newDict, type: .json, title: fileURL.lastPathComponent, fileURL: fileURL, parentController: nil, canEdit: canEdit)
        case .plist(_):
            let fmt: UnsafeMutablePointer<PropertyListSerialization.PropertyListFormat>? = .allocate(capacity: 4)
            defer {
                fmt?.deallocate()
            }

            guard let plist = try? PropertyListSerialization.propertyList(from: data, format: fmt) as? [String: Any] else {
                return nil
            }

            let newDict = plist.asSerializedDictionary()

            self.init(dictionary: newDict, type: .plist(format: fmt?.pointee), title: fileURL.lastPathComponent, fileURL: fileURL, parentController: nil, canEdit: canEdit)
        }
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return keys.count
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = UITableViewCell(style: .value2, reuseIdentifier: nil)
        SantanderUI.styleCell(cell)
        var conf = cell.defaultContentConfiguration()
        let text = keys[indexPath.row]

        conf.text = text
        let elem = dictElement(forKey: text)

        switch elem {
        case .dictionary(_), .array(_):
            cell.accessoryType = .disclosureIndicator
        default:
            cell.accessoryType = .detailButton
        }

        conf.secondaryText = valueDescription(forElement: elem)
        cell.contentConfiguration = conf
        return cell
    }

    func dismissVC() {
        self.dismiss(animated: true)
    }

    func presentViewController(forIndexPath indexPath: IndexPath) {
        let text = keys[indexPath.row]
        let elem = dictElement(forKey: text)!

        if case .array(let arr) = elem {
            let vc = SerializedArrayViewController(array: arr, type: type, parentController: .dictionary(self, key: text), title: text, fileURL: fileURL, canEdit: canEdit)
            self.navigationController?.pushViewController(vc, animated: true)
        } else if case .dictionary(let dict) = elem {
            let newDict = dict.asSerializedDictionary()

            let vc = SerializedDocumentViewController(dictionary: newDict, type: type, title: text, fileURL: fileURL, parentController: .dictionary(self, key: text), canEdit: canEdit)
            self.navigationController?.pushViewController(vc, animated: true)
        } else {
            let vc = SerializedItemViewController(item: elem, itemKey: text, allowsKeyEditing: true, documentType: type, canEdit: canEdit)
            vc.delegate = self
            navigationController?.pushViewController(vc, animated: true)
        }
    }

    override func tableView(_ tableView: UITableView, accessoryButtonTappedForRowWith indexPath: IndexPath) {
        presentViewController(forIndexPath: indexPath)
    }

    func didChangeName(ofItem item: String, to newName: String) -> Bool {
        guard let value = serializedDict[item] else {
            return false
        }

        var newDict: SerializedDictionaryType = serializedDict
        newDict[item] = nil
        newDict[newName] = value

        let didSucceed = writeToFile(newDict: newDict)
        tableView.reloadData()
        return didSucceed
    }

    func didChangeValue(ofItem item: String, to newValue: SerializedItemType) -> Bool {
        var newDict: SerializedDictionaryType = serializedDict
        newDict[item] = newValue

        let didSucceed = writeToFile(newDict: newDict)
        if isSearching {
            tableView.reloadData()
        } else {
            updateFilteredDict(reloadData: true, searchText: nil)
        }
        return didSucceed
    }

    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        presentViewController(forIndexPath: indexPath)
    }

    @discardableResult
    func writeToFile(newDict: SerializedDictionaryType) -> Bool {
        guard let fileURL = fileURL, canEdit else {
            return false
        }

        if let parentController = parentController {
            let didSucced: Bool
            switch parentController {
            case .dictionary(let parent, let key):
                var parentDict = parent.serializedDict
                parentDict[key] = .dictionary(newDict.asAnyDictionary())
                didSucced = parent.writeToFile(newDict: parentDict)
            case .array(let parent, let index):
                guard parent.array.indices.contains(index) else {
                    return false
                }
                var parentArr = parent.array
                parentArr[index] = newDict.asAnyDictionary()
                didSucced = parent.writeToFile(newArray: parentArr)
            }

            if didSucced {
                self.serializedDict = newDict
                return true
            }

            return false
        }

        do { try ensureFileContentIsUnlocked(fileURL) } catch { errorAlert(error, title: SantanderL10n.t("Unable to write to file")); return false }

        switch type {
        case .json:
            do {
                let newData = try JSONSerialization.data(withJSONObject: newDict.asAnyDictionary(), options: .prettyPrinted)
                try FSOperation.perform(.writeData(url: fileURL, data: newData), rootHelperConf: RootConf.shared)
                self.serializedDict = newDict
                return true
            } catch {
                self.errorAlert(error, title: "无法写入文件 \(fileURL.lastPathComponent)", presentingFromIfAvailable: presentedViewController)
                return false
            }
        case .plist(let format):
            guard let format = format else {
                self.errorAlert(SantanderL10n.t("无法读取属性列表格式。"), title: "无法写入属性列表文件", presentingFromIfAvailable: presentedViewController)
                return false
            }

            do {
                let newData = try PropertyListSerialization.data(fromPropertyList: newDict.asAnyDictionary(), format: format, options: 0)
                try FSOperation.perform(.writeData(url: fileURL, data: newData), rootHelperConf: RootConf.shared)
                self.serializedDict = newDict
                return true
            } catch {
                self.errorAlert(error, title: "无法写入文件 \(fileURL.lastPathComponent)", presentingFromIfAvailable: presentedViewController)
                return false
            }
        }
    }

    func presentAddValue() {
        guard canEdit else {
            return
        }

        let alert = UIAlertController(title: SantanderL10n.t("Add Key"), message: nil, preferredStyle: .alert)
        alert.addTextField { field in
            field.placeholder = SantanderL10n.t("Key")
            field.autocapitalizationType = .none
        }

        var types = [
            ("String", SerializedItemType.string("")),
            ("Boolean", SerializedItemType.bool(false)),
            ("Integer", SerializedItemType.int(0)),
            ("Real", SerializedItemType.float(0)),
            ("Date", SerializedItemType.date(Date()))
        ]
        if case .plist = type {
            types.append(("Data", SerializedItemType.data(Data())))
        }
        types += [
            ("Array", SerializedItemType.array([])),
            ("Dictionary", SerializedItemType.dictionary([:]))
        ]

        for (name, value) in types {
            alert.addAction(UIAlertAction(title: name, style: .default) { [weak self, weak alert] _ in
                guard let self, let key = alert?.textFields?.first?.text?.trimmingCharacters(in: .whitespacesAndNewlines), !key.isEmpty else {
                    return
                }
                guard self.serializedDict[key] == nil else {
                    self.errorAlert("The key already exists.", title: SantanderL10n.t("Duplicate Key"))
                    return
                }
                var newDict = self.serializedDict
                newDict[key] = value
                guard self.writeToFile(newDict: newDict) else {
                    return
                }
                self.updateFilteredDict(reloadData: true, searchText: nil)
            })
        }

        alert.addAction(.cancel())
        present(alert, animated: true)
    }

    func dictElement(forKey key: String) -> SerializedItemType? {
        return isSearching ? filteredDict[key] : serializedDict[key]
    }

    override func tableView(_ tableView: UITableView, trailingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration? {
        guard canEdit else {
            return nil
        }

        let deleteAction = UIContextualAction(style: .destructive, title: nil) { _, _, completion in
            var newDict = self.serializedDict
            newDict[self.keys[indexPath.row]] = nil
            if self.writeToFile(newDict: newDict) {
                self.updateFilteredDict(reloadData: false, searchText: nil)
                self.tableView.deleteRows(at: [indexPath], with: .fade)
                completion(true)
            } else {
                completion(false)
            }
        }
        deleteAction.image = .remove

        return UISwipeActionsConfiguration(actions: [deleteAction])
    }
}

enum SerializedDocumentViewerType {
    case json
    case plist(format: PropertyListSerialization.PropertyListFormat?)
}

extension SerializedDocumentViewController: UISearchBarDelegate {
    func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
        isSearching = false
        tableView.reloadData()
    }

    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        isSearching = !searchText.isEmpty

        updateFilteredDict(reloadData: true, searchText: searchText)
    }

    func valueDescription(forElement element: SerializedItemType?) -> String? {
        guard let element else { return nil }
        switch element {
        case .array(let array):
            return "Array • \(array.count) 项"
        case .dictionary(let dictionary):
            return "Dictionary • \(dictionary.count) 项"
        default:
            let value = element.description.isEmpty ? "" : " • \(element.description)"
            return "\(element.typeDescription)\(value)"
        }
    }

    func updateFilteredDict(reloadData: Bool, searchText text: String?) {
        if isSearching {
            let searchText = text ?? navigationItem.searchController?.searchBar.text ?? ""
            filteredDict = serializedDict.filter { (key, value) in
                return key.localizedCaseInsensitiveContains(searchText) ||
                valueDescription(forElement: value)?.localizedCaseInsensitiveContains(searchText) ?? false
            }
        }

        if reloadData {
            tableView.reloadData()
        }
    }
}

enum SerializedItemType: Equatable, CustomStringConvertible {
    static func == (lhs: SerializedItemType, rhs: SerializedItemType) -> Bool {
        switch (lhs, rhs) {
        case (.string(let first), .string(let second)):         return first == second
        case (.bool(let first), .bool(let second)):             return first == second
        case (.int(let first), .int(let second)):               return first == second
        case (.float(let first), .float(let second)):           return first == second
        case (.data(let first), .data(let second)):             return first == second
        case (.date(let first), .date(let second)):             return first == second
        case (.array(let first), .array(let second)):
            return NSArray(array: first) == NSArray(array: second)
        case (.dictionary(let first), .dictionary(let second)):
            return NSDictionary(dictionary: first) == NSDictionary(dictionary: second)
        default:
            return false
        }
    }

    case string(String)
    case bool(Bool)
    case int(Int)
    case float(Float)
    case array(Array<Any>)
    case dictionary([String: Any])
    case data(Data)
    case date(Date)
    case other(Any)

    init(item: Any) {
        switch item {
        case let string as String:
            self = .string(string)
        case let nsNumber as NSNumber:
            if CFGetTypeID(nsNumber) == CFBooleanGetTypeID() {
                self = .bool(nsNumber.boolValue)
            } else {
                switch CFNumberGetType(nsNumber as CFNumber) {
                case .floatType, .float32Type, .float64Type, .cgFloatType, .doubleType:
                    self = .float(nsNumber.floatValue)
                default:
                    self = .int(nsNumber.intValue)
                }
            }
        case let arr as Array<Any>:
            self = .array(arr)
        case let dictionary as Dictionary<String, Any>:
            self = .dictionary(dictionary)
        case let data as NSData:
            self = .data(data as Data)
        case let date as NSDate:
            self = .date(date as Date)
        default:
            self = .other(item)
        }

    }

    var description: String {
        switch self {
        case .string(let string):
            return string
        case .bool(let bool):
            return bool ? "✓" : ""
        case .int(let int):
            return int.description
        case .float(let float):
            return float.description
        case .array(let array):
            return array.description
        case .dictionary(let nsDictionary):
            return nsDictionary.description
        case .date(let date):
            return date.listFormatted()
        case .data(let data):
            return "Data • \(data.count) bytes"
        case .other(let any):
            return String(describing: any)
        }
    }

    var typeDescription: String {
        switch self {
        case .string(_): return "String"
        case .bool(_): return "Boolean"
        case .int(_): return "Integer"
        case .float(_): return "Real"
        case .data(_): return "Data"
        case .array(_): return "Array"
        case .dictionary(_): return "Dictionary"
        case .date(_): return "Date"
        case .other(_): return "Unknown"
        }
    }

    var representedObject: Any {
        switch self {
        case .string(let string):
            return string
        case .bool(let bool):
            return bool
        case .int(let int):
            return int
        case .float(let float):
            return float
        case .array(let nsArray):
            return nsArray
        case .dictionary(let nsDictionary):
            return nsDictionary
        case .data(let data):
            return data
        case .date(let date):
            return date
        case .other(let any):
            return any
        }
    }

}

enum SerializedControllerParent {
    case dictionary(SerializedDocumentViewController, key: String)
    case array(SerializedArrayViewController, index: Int)
}

class SerializedItemViewController: UITableViewController {
    var item: SerializedItemType
    var itemKey: String
    let allowsKeyEditing: Bool
    let documentType: SerializedDocumentViewerType
    let canEdit: Bool

    weak var delegate: SerializedItemViewControllerDelegate?
    var retainedDelegate: SerializedItemViewControllerDelegate?

    init(
        item: SerializedItemType,
        itemKey: String,
        allowsKeyEditing: Bool = true,
        documentType: SerializedDocumentViewerType = .plist(format: nil),
        canEdit: Bool = true
    ) {
        self.item = item
        self.itemKey = itemKey
        self.allowsKeyEditing = allowsKeyEditing
        self.documentType = documentType
        self.canEdit = canEdit
        super.init(style: .grouped)
    }

    required init?(coder: NSCoder) {
        fatalError()
    }

    @discardableResult
    func setItem(to newValue: SerializedItemType) -> Bool {
        guard canEdit else { return false }
        if self.delegate?.didChangeValue(ofItem: itemKey, to: newValue) ?? false {
            item = newValue
            tableView.performBatchUpdates {
                tableView.reloadRows(at: [IndexPath(row: 0, section: 1)], with: .automatic)
                tableView.reloadRows(at: [IndexPath(row: 0, section: 2)], with: .automatic)
            }
            return true
        }
        return false
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        applySantanderUI()
        title = itemKey
    }

    override func numberOfSections(in tableView: UITableView) -> Int {
        return 3
    }

    override func tableView(_ tableView: UITableView, shouldHighlightRowAt indexPath: IndexPath) -> Bool {
        return canEdit && indexPath.section == 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }

    func makeBoolChangeSwitch(currentItemBoolValue: Bool) -> UISwitch {
        let toggle = UISwitch()
        toggle.isOn = currentItemBoolValue
        toggle.isEnabled = canEdit
        toggle.addAction(UIAction { [weak self, weak toggle] _ in
            guard let self = self, let toggle = toggle else { return }
            let requested = toggle.isOn
            if !self.setItem(to: .bool(requested)) {
                toggle.setOn(!requested, animated: true)
            }
        }, for: .valueChanged)
        return toggle
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = UITableViewCell(style: .value1, reuseIdentifier: nil)
        SantanderUI.styleCell(cell)
        var conf = cell.defaultContentConfiguration()

        switch indexPath.section {
        case 0:
            if allowsKeyEditing && canEdit {
                let textField = UITextField(frame: cell.frame)
                textField.text = itemKey
                textField.returnKeyType = .done

                let action = UIAction { [weak self] in
                    self?.itemKeyTextFieldDone(textField, indexPath: indexPath)
                }
                textField.addAction(action, for: .editingDidEndOnExit)
                cell.contentView.addSubview(textField)

                textField.translatesAutoresizingMaskIntoConstraints = false
                NSLayoutConstraint.activate([
                    textField.leadingAnchor.constraint(equalTo: cell.contentView.layoutMarginsGuide.leadingAnchor),
                    textField.trailingAnchor.constraint(equalTo: cell.contentView.layoutMarginsGuide.trailingAnchor),
                    textField.centerYAnchor.constraint(equalTo: cell.contentView.centerYAnchor)
                ])
                return cell
            }

            conf.text = itemKey
            conf.textProperties.numberOfLines = 1

        case 1:
            conf.text = item.typeDescription
            conf.secondaryText = canEdit ? SantanderL10n.t("点击选择类型") : nil
            conf.image = SantanderIconLibrary.shared.interfaceIcon(for: "arrow.left.arrow.right")
            cell.accessoryType = canEdit ? .disclosureIndicator : .none

        case 2:
            switch item {
            case .bool(let bool):
                return cellWithView(makeBoolChangeSwitch(currentItemBoolValue: bool), text: SantanderL10n.t("Value"))

            case .string(let string):
                let textView = UITextView(frame: cell.frame)
                textView.text = string
                textView.font = .systemFont(ofSize: UIFont.systemFontSize)
                textView.backgroundColor = cell.backgroundColor
                textView.autoresizingMask = [.flexibleHeight, .flexibleWidth]
                textView.isScrollEnabled = true
                textView.isEditable = canEdit

                let editTextAction = UIAction { [weak self] in
                    guard let self, let text = textView.text else { return }
                    self.setItem(to: .string(text))
                    textView.resignFirstResponder()
                }

                if canEdit {
                    textView.inputAccessoryView = toolbarDoneView(doneAction: editTextAction, textFieldOrView: textView)
                }
                cell.contentView.addSubview(textView)
                textView.translatesAutoresizingMaskIntoConstraints = false
                NSLayoutConstraint.activate([
                    textView.leadingAnchor.constraint(equalTo: cell.contentView.layoutMarginsGuide.leadingAnchor),
                    textView.trailingAnchor.constraint(equalTo: cell.contentView.layoutMarginsGuide.trailingAnchor),
                    textView.topAnchor.constraint(equalTo: cell.contentView.topAnchor, constant: 8),
                    textView.bottomAnchor.constraint(equalTo: cell.contentView.bottomAnchor, constant: -8),
                    textView.heightAnchor.constraint(greaterThanOrEqualToConstant: 100)
                ])
                return cell

            case .int(_), .float(_):
                let textField = valueTextField(atIndexPath: indexPath)
                textField.isEnabled = canEdit
                return cellWithView(textField, text: SantanderL10n.t("Value"))

            case .date(let date):
                let datePicker = UIDatePicker()
                datePicker.date = date
                datePicker.isEnabled = canEdit

                let action = UIAction { [weak self] in
                    guard let self else { return }
                    self.setItem(to: .date(datePicker.date))
                }

                if canEdit {
                    datePicker.addAction(action, for: .editingDidEnd)
                }
                return cellWithView(datePicker, text: SantanderL10n.t("Value"))

            case .data(let data):
                let textView = UITextView(frame: cell.frame)
                textView.text = data.base64EncodedString()
                textView.font = .monospacedSystemFont(ofSize: 15, weight: .regular)
                textView.autoresizingMask = [.flexibleWidth, .flexibleHeight]
                textView.isEditable = canEdit
                let editAction = UIAction { [weak self] in
                    guard let self, canEdit, let value = textView.text else { return }
                    let compact = value
                        .replacingOccurrences(of: " ", with: "")
                        .replacingOccurrences(of: "\n", with: "")
                        .replacingOccurrences(of: "\r", with: "")
                        .replacingOccurrences(of: "\t", with: "")
                    guard let decoded = Data(base64Encoded: compact) else {
                        self.errorAlert("Base64 数据格式无效。", title: SantanderL10n.t("Invalid Data"))
                        return
                    }
                    self.setItem(to: .data(decoded))
                    textView.resignFirstResponder()
                }
                if canEdit {
                    textView.inputAccessoryView = toolbarDoneView(doneAction: editAction, textFieldOrView: textView)
                }
                cell.contentView.addSubview(textView)
                textView.translatesAutoresizingMaskIntoConstraints = false
                NSLayoutConstraint.activate([
                    textView.leadingAnchor.constraint(equalTo: cell.contentView.layoutMarginsGuide.leadingAnchor),
                    textView.trailingAnchor.constraint(equalTo: cell.contentView.layoutMarginsGuide.trailingAnchor),
                    textView.topAnchor.constraint(equalTo: cell.contentView.topAnchor, constant: 8),
                    textView.bottomAnchor.constraint(equalTo: cell.contentView.bottomAnchor, constant: -8),
                    textView.heightAnchor.constraint(greaterThanOrEqualToConstant: 100)
                ])
                return cellWithView(textView, text: SantanderL10n.t("Value (in base64)"))

            default:
                conf.text = SantanderL10n.t("Value")
                conf.secondaryText = item.description
            }

        default:
            fatalError()
        }

        cell.contentConfiguration = conf
        return cell
    }

    override func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        switch section {
        case 0:
            return allowsKeyEditing ? SantanderL10n.t("Key") : SantanderL10n.t("Position in array")
        case 1:
            return item.typeDescription
        case 2:
            return SantanderL10n.t("Value")
        default:
            return nil
        }
    }

    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        guard canEdit, indexPath.section == 1 else { return }
        presentTypePicker()
    }

    private func presentTypePicker() {
        var typeNames = ["String", "Boolean", "Integer", "Real", "Date"]
        if case .plist = documentType { typeNames.append("Data") }
        typeNames += ["Array", "Dictionary"]
        let actions = typeNames.map { typeName in
            SantanderActionSheetItem(title: typeName, isSelected: typeName == item.typeDescription) { [weak self] in
                guard let self, let newItem = self.convertedItem(for: typeName) else { return }
                self.setItem(to: newItem)
            }
        }
        presentSantanderActionSheet(title: item.typeDescription, actions: actions + [SantanderActionSheetItem(title: SantanderL10n.t("Cancel"), style: .cancel)])
    }

    private func convertedItem(for typeName: String) -> SerializedItemType? {
        switch typeName {
        case "String":
            switch item { case .string(let value): return .string(value); default: return .string(item.description) }
        case "Boolean":
            if case .bool(let value) = item { return .bool(value) }
            return .bool(false)
        case "Integer":
            switch item {
            case .int(let value): return .int(value)
            case .float(let value): return .int(Int(value))
            default: return .int(0)
            }
        case "Real":
            switch item {
            case .float(let value): return .float(value)
            case .int(let value): return .float(Float(value))
            default: return .float(0)
            }
        case "Date":
            if case .date(let value) = item { return .date(value) }
            return .date(Date())
        case "Data":
            if case .data(let value) = item { return .data(value) }
            return .data(Data())
        case "Array":
            if case .array(let value) = item { return .array(value) }
            return .array([])
        case "Dictionary":
            if case .dictionary(let value) = item { return .dictionary(value) }
            return .dictionary([:])
        default:
            return nil
        }
    }

    func valueTextField(atIndexPath indexPath: IndexPath) -> UITextField {
        let textField = UITextField()
        let action = UIAction { [weak self] in
            self?.valueTextFieldDone(textField, atIndexPath: indexPath)
        }

        switch item {
        case .string(let string):
            textField.text = string
            textField.returnKeyType = .done
            textField.addAction(action, for: .editingDidEndOnExit)
        case .int(let int):
            textField.keyboardType = .numberPad
            textField.text = int.description
            textField.inputAccessoryView = toolbarDoneView(doneAction: action, textFieldOrView: textField)
        case .float(let float):
            textField.text = float.description
            textField.keyboardType = .decimalPad
            textField.inputAccessoryView = toolbarDoneView(doneAction: action, textFieldOrView: textField)
        default:
            break
        }
        return textField
    }

    func toolbarDoneView(doneAction: UIAction, textFieldOrView: UIResponder) -> UIToolbar {
        let toolbar = UIToolbar()
        let cancelAction = UIAction { _ in textFieldOrView.resignFirstResponder() }
        let doneButton = UIBarButtonItem(systemItem: .done, primaryAction: doneAction)
        let cancelButton = UIBarButtonItem(systemItem: .cancel, primaryAction: cancelAction)
        toolbar.setItems([cancelButton, .flexibleSpace(), doneButton], animated: false)
        toolbar.sizeToFit()
        return toolbar
    }

    func valueTextFieldDone(_ textField: UITextField, atIndexPath indexPath: IndexPath) {
        guard canEdit, let text = textField.text, !text.isEmpty else {
            return
        }

        switch item {
        case .string(_):
            setItem(to: .string(text))
        case .int(_):
            guard let num = Int(text) else { return }
            setItem(to: .int(num))
        case .float(_):
            guard let num = Float(text) else { return }
            setItem(to: .float(num))
        default:
            break
        }
        textField.resignFirstResponder()
    }

    func itemKeyTextFieldDone(_ textField: UITextField, indexPath: IndexPath) {
        guard canEdit, allowsKeyEditing, let text = textField.text, !text.isEmpty else {
            return
        }

        if self.delegate?.didChangeName(ofItem: itemKey, to: text) ?? false {
            self.itemKey = text
            self.title = self.itemKey
            self.tableView.reloadRows(at: [indexPath], with: .fade)
        }
        textField.resignFirstResponder()
    }
}

protocol SerializedItemViewControllerDelegate: AnyObject {
    func didChangeName(ofItem item: String, to newName: String) -> Bool
    func didChangeValue(ofItem item: String, to newValue: SerializedItemType) -> Bool
}

fileprivate extension Array {
    subscript(safe index: Int) -> Element? { indices.contains(index) ? self[index] : nil }
}

private func makeGenericButton(image: UIImage?) -> UIButton {
    let button = UIButton(type: .system)
    button.translatesAutoresizingMaskIntoConstraints = false
    button.setImage(image, for: .normal)
    button.tintColor = .label
    return button
}










class KeyboardSearchView: UIInputView {
    weak var textView: TextView?

    let searchQueue = DispatchQueue(label: "com.Antoine.Santander.KeyboardSearchView.search", qos: .background)
    var searchWorkItem: DispatchWorkItem?

    var searchMethod: SearchQuery.MatchMethod = .contains
    var isCaseSensitive: Bool = false

    var searchTextField: UISearchTextField!

    var currentIndex: Int = 0
    var chevronUpButton: UIButton!
    var chevronDownButton: UIButton!
    var currentResults: [SearchResult] = []

    init(
        frame: CGRect = CGRect(origin: .zero, size: CGSize(width: UIScreen.main.bounds.width, height: 44)),
        textView: TextView
    ) {
        super.init(frame: frame, inputViewStyle: .default)
        self.textView = textView
        commonInit()
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    func commonInit() {
        let doneButton = UIButton(type: .system)
        doneButton.translatesAutoresizingMaskIntoConstraints = false
        doneButton.setTitle(SantanderL10n.t("Done"), for: .normal)
        doneButton.titleLabel?.font = .preferredFont(forTextStyle: .body)
        doneButton.setTitleColor(.white, for: .normal)
        doneButton.addTarget(self, action: #selector(doneDismiss), for: .allEvents)

        self.chevronUpButton = makeGenericButton(image: UIImage(systemName: "chevron.up"))
        self.chevronDownButton = makeGenericButton(image: SantanderIconLibrary.shared.interfaceIcon(for: "chevron.down"))

        chevronUpButton.tag = 0
        chevronDownButton.tag = 1

        chevronUpButton.addTarget(self, action: #selector(chevronButtonClicked(sender:)), for: .touchUpInside)
        chevronDownButton.addTarget(self, action: #selector(chevronButtonClicked(sender:)), for: .touchUpInside)

        chevronUpButton.isEnabled = false
        chevronDownButton.isEnabled = false

        let filterButton = makeGenericButton(image: SantanderIconLibrary.shared.uiIcon(named: "select")?.withTintColor(SantanderAppTheme.accentColor, renderingMode: .alwaysOriginal))

        filterButton.addTarget(self, action: #selector(showSearchMethodOptions), for: .touchUpInside)

        let chevronButtonsStackView = UIStackView(arrangedSubviews: [filterButton, chevronUpButton, chevronDownButton])
        chevronButtonsStackView.setCustomSpacing(10, after: filterButton)
        chevronButtonsStackView.translatesAutoresizingMaskIntoConstraints = false

        self.searchTextField = UISearchTextField()
        searchTextField.addTarget(self, action: #selector(searchDidChange(searchTextField:)), for: .editingChanged)
        searchTextField.inputAccessoryView = self
        searchTextField.translatesAutoresizingMaskIntoConstraints = false

        addSubview(doneButton)
        addSubview(searchTextField)
        addSubview(chevronButtonsStackView)

        NSLayoutConstraint.activate([
            doneButton.leadingAnchor.constraint(equalTo: leadingAnchor, constant: 10),
            doneButton.centerYAnchor.constraint(equalTo: layoutMarginsGuide.centerYAnchor),

            chevronButtonsStackView.centerYAnchor.constraint(equalTo: layoutMarginsGuide.centerYAnchor),
            chevronButtonsStackView.trailingAnchor.constraint(equalTo: layoutMarginsGuide.trailingAnchor),

            searchTextField.leadingAnchor.constraint(equalTo: doneButton.leadingAnchor, constant: 50),
            searchTextField.trailingAnchor.constraint(equalTo: chevronButtonsStackView.leadingAnchor, constant: -10),
            searchTextField.centerYAnchor.constraint(equalTo: layoutMarginsGuide.centerYAnchor),
        ])
    }

    @objc func showSearchMethodOptions() {
        var actions: [SantanderActionSheetItem] = [
            SantanderActionSheetItem(title: SantanderL10n.t("Case Sensitive"), image: SantanderIconLibrary.shared.interfaceIcon(for: "textformat"), isSelected: isCaseSensitive) { [weak self] in
                guard let self else { return }
                self.isCaseSensitive.toggle()
                self.searchDidChange(searchTextField: self.searchTextField)
            }
        ]
        actions.append(contentsOf: SearchQuery.MatchMethod.allCases.reversed().map { method in
            SantanderActionSheetItem(title: method.description, image: SantanderIconLibrary.shared.uiIcon(named: "select"), isSelected: searchMethod == method) { [weak self] in
                guard let self else { return }
                self.searchMethod = method
                self.searchDidChange(searchTextField: self.searchTextField)
            }
        })
        actions.append(SantanderActionSheetItem(title: SantanderL10n.t("Cancel"), style: .cancel))
        var responder: UIResponder? = self
        while let current = responder {
            if let controller = current as? UIViewController {
                controller.presentSantanderActionSheet(title: SantanderL10n.t("Search Method"), actions: actions)
                return
            }
            responder = current.next
        }
        UIApplication.shared.windows.first(where: \.isKeyWindow)?.rootViewController?.presentSantanderActionSheet(title: SantanderL10n.t("Search Method"), actions: actions)
    }

    @objc
    func doneDismiss() {
        guard let textView else { return }
        textView.highlightedRanges = []
        textView.inputAccessoryView = KeyboardToolsView(textView: textView)
        textView.resignFirstResponder()
    }

    @objc
    func searchDidChange(searchTextField: UISearchTextField) {
        searchWorkItem?.cancel()

        guard let textView else {
            return
        }

        guard let text = searchTextField.text, !text.isEmpty else {
            textView.highlightedRanges = []
            chevronUpButton.isEnabled = false
            chevronDownButton.isEnabled = false
            return
        }

        let newItem = DispatchWorkItem(flags: .assignCurrentContext) { [unowned self] in
            update(withResults: textView.search(for: makeSearchQuery(text: text)))
        }

        searchWorkItem = newItem
        searchQueue.asyncAfter(deadline: .now().advanced(by: .milliseconds(3)), execute: newItem)
    }

    func update(withResults results: [SearchResult]) {
        currentResults = results

        let areResultsNotEmpty = !results.isEmpty
        DispatchQueue.main.async { [unowned self] in
            if areResultsNotEmpty {
                textView?.scrollRangeToVisible(results[0].range)
            }

            chevronUpButton.isEnabled = areResultsNotEmpty
            chevronDownButton.isEnabled = areResultsNotEmpty
        }

        let highlightedRanges = results.map { result in
            HighlightedRange(range: result.range, color: .systemOrange)
        }

        textView?.highlightedRanges = highlightedRanges
    }

    func makeSearchQuery(text: String) -> SearchQuery {
        return SearchQuery(text: text, matchMethod: searchMethod, isCaseSensitive: isCaseSensitive)
    }

    @objc
    func chevronButtonClicked(sender: UIButton) {
        switch sender.tag {
        case 0:
            currentIndex -= 1
        case 1:
            currentIndex += 1
        default:
            break
        }

        chevronUpButton.isEnabled = currentIndex != 0
        chevronDownButton.isEnabled = currentIndex != (currentResults.count - 1)
        print(currentIndex, currentResults.count)

        textView?.scrollRangeToVisible(currentResults[currentIndex].range)
    }
}

extension SearchQuery.MatchMethod: CaseIterable, CustomStringConvertible {
    public static var allCases: [SearchQuery.MatchMethod] = [.startsWith, .endsWith, .contains, .fullWord, .regularExpression]

    public var description: String {
        switch self {
        case .contains:
            return SantanderL10n.t("Contains")
        case .fullWord:
            return SantanderL10n.t("Full Word")
        case .startsWith:
            return SantanderL10n.t("Starts With")
        case .endsWith:
            return SantanderL10n.t("Ends With")
        case .regularExpression:
            return SantanderL10n.t("Regex")
        }
    }
}

fileprivate func _makeGenericButton(image: UIImage?) -> UIButton {
    let button = UIButton(type: .system)
    button.translatesAutoresizingMaskIntoConstraints = false
    button.setImage(image, for: .normal)
    button.tintColor = .label
    return button
}

final class KeyboardToolsView: UIInputView {
    private let shiftLeftButton = _makeGenericButton(image: SantanderIconLibrary.shared.interfaceIcon(for: "arrow.left.to.line"))
    private let shiftRightButton = _makeGenericButton(image: SantanderIconLibrary.shared.interfaceIcon(for: "arrow.right.to.line"))

    private let undoButton = _makeGenericButton(image: SantanderIconLibrary.shared.interfaceIcon(for: "arrow.uturn.backward"))
    private let redoButton = _makeGenericButton(image: SantanderIconLibrary.shared.interfaceIcon(for: "arrow.uturn.forward"))

    private let dismissButton = _makeGenericButton(image: UIImage(systemName: "keyboard.chevron.compact.down"))
    private let searchButton = _makeGenericButton(image: SantanderIconLibrary.shared.interfaceIcon(for: "magnifyingglass"))

    private weak var textView: TextView?

    init(textView: TextView) {
        self.textView = textView
        let frame = CGRect(x: 0, y: 0, width: UIScreen.main.bounds.width, height: 44)
        super.init(frame: frame, inputViewStyle: .keyboard)
        setupView()
        setupLayout()
        NotificationCenter.default.addObserver(self, selector: #selector(updateUndoRedoButtonStates), name: .NSUndoManagerCheckpoint, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(updateUndoRedoButtonStates), name: .NSUndoManagerDidUndoChange, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(updateUndoRedoButtonStates), name: .NSUndoManagerDidRedoChange, object: nil)
    }

    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    deinit {
        NotificationCenter.default.removeObserver(self)
    }

    private func setupView() {
        addSubview(shiftLeftButton)
        addSubview(shiftRightButton)
        addSubview(undoButton)
        addSubview(redoButton)
        addSubview(dismissButton)
        addSubview(searchButton)

        shiftLeftButton.addTarget(self, action: #selector(shiftLeft), for: .touchUpInside)
        shiftRightButton.addTarget(self, action: #selector(shiftRight), for: .touchUpInside)
        undoButton.addTarget(self, action: #selector(undo), for: .touchUpInside)
        redoButton.addTarget(self, action: #selector(redo), for: .touchUpInside)
        dismissButton.addTarget(self, action: #selector(dismissKeyboard), for: .touchUpInside)
        searchButton.addTarget(self, action: #selector(switchToSearch), for: .touchUpInside)
        updateUndoRedoButtonStates()
    }

    private func setupLayout() {
        NSLayoutConstraint.activate([
            shiftLeftButton.leadingAnchor.constraint(equalTo: layoutMarginsGuide.leadingAnchor),
            shiftLeftButton.topAnchor.constraint(equalTo: topAnchor),
            shiftLeftButton.bottomAnchor.constraint(equalTo: bottomAnchor),

            shiftRightButton.leadingAnchor.constraint(equalTo: shiftLeftButton.trailingAnchor, constant: 6),
            shiftRightButton.topAnchor.constraint(equalTo: topAnchor),
            shiftRightButton.bottomAnchor.constraint(equalTo: bottomAnchor),

            undoButton.trailingAnchor.constraint(equalTo: redoButton.leadingAnchor, constant: -10),
            undoButton.topAnchor.constraint(equalTo: topAnchor),
            undoButton.bottomAnchor.constraint(equalTo: bottomAnchor),

            redoButton.trailingAnchor.constraint(equalTo: dismissButton.leadingAnchor, constant: -46),
            redoButton.topAnchor.constraint(equalTo: topAnchor),
            redoButton.bottomAnchor.constraint(equalTo: bottomAnchor),

            dismissButton.trailingAnchor.constraint(equalTo: layoutMarginsGuide.trailingAnchor),
            dismissButton.topAnchor.constraint(equalTo: topAnchor),
            dismissButton.bottomAnchor.constraint(equalTo: bottomAnchor),

            searchButton.trailingAnchor.constraint(equalTo: dismissButton.trailingAnchor, constant: -35),
            searchButton.topAnchor.constraint(equalTo: topAnchor),
            searchButton.bottomAnchor.constraint(equalTo: bottomAnchor)
        ])
    }
}

private extension KeyboardToolsView {
    @objc private func shiftLeft() {
        textView?.shiftLeft()
    }

    @objc private func shiftRight() {
        textView?.shiftRight()
    }

    @objc private func undo() {
        textView?.undoManager?.undo()
    }

    @objc private func redo() {
        textView?.undoManager?.redo()
    }

    @objc private func dismissKeyboard() {
        textView?.resignFirstResponder()
    }

    @objc private func switchToSearch() {
        guard let textView else { return }
        textView.inputAccessoryView = KeyboardSearchView(textView: textView)
        textView.resignFirstResponder()
        textView.becomeFirstResponder()
    }

    @objc private func updateUndoRedoButtonStates() {
        let undoManager = textView?.undoManager
        undoButton.isEnabled = undoManager?.canUndo ?? false
        redoButton.isEnabled = undoManager?.canRedo ?? false
    }
}

class TextEditorThemeSettingsViewController: SettingsTableViewController, UIColorPickerViewControllerDelegate {

    weak var delegate: EditorThemeSettingsDelegate?
    var selectedIndexPath: IndexPath? = nil
    var theme: CodableTextEditorTheme
    var persistGlobally = false

    private func persistGlobalThemeIfNeeded() {
        guard persistGlobally else { return }
        UserPreferences.setTextEditorTheme(theme, for: traitCollection.userInterfaceStyle)
    }

    var editorBackgroundColor: UIColor {
        theme.textEditorBackgroundColor?.uiColor ?? .tertiarySystemBackground
    }

    init(style: UITableView.Style, theme: CodableTextEditorTheme) {
        self.theme = theme
        super.init(style: style)
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) hasn't been implemented.")
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        applySantanderUI()
        self.title = SantanderL10n.t("Text Editor Settings")
    }

    override func numberOfSections(in tableView: UITableView) -> Int {
        return 3
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        switch section {
        case 1: return 3
        case 0, 2: return 2
        default: fatalError("How the hell did you get here?! Unhandled section: \(section)")
        }
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = UITableViewCell(style: .value1, reuseIdentifier: nil)
        SantanderUI.styleCell(cell)
        var conf = cell.defaultContentConfiguration()
        switch (indexPath.section, indexPath.row) {
        case (0, 0):
            conf.text = SantanderL10n.t("Font")
            conf.secondaryText = theme.font.uiFont.fontName
        case (0, 1):
            conf.text = SantanderL10n.t("Font size")
            let stepper = UIStepper()
            stepper.value = theme.font.uiFont.pointSize
            stepper.addTarget(self, action: #selector(fontStepperValueChanged(sender:)), for: .valueChanged)
            cell.accessoryView = stepper
            conf.secondaryText = theme.font.uiFont.pointSize.description
        case (1, 0):
            return cellWithView(settingsSwitch(forIndexPath: indexPath), text: SantanderL10n.t("Show Line Count"))
        case (1, 1):
            return cellWithView(settingsSwitch(forIndexPath: indexPath), text: SantanderL10n.t("Wrap Lines"))
        case (1, 2):
            return cellWithView(settingsSwitch(forIndexPath: indexPath), text: SantanderL10n.t("Use Character Pairs"))
        case (2, 0):
            conf.text = SantanderL10n.t("Text Color")
            cell.accessoryView = cell.colorCircleAccessoryView(color: theme.textColor?.uiColor ?? .label)
        case (2, 1):
            conf.text = SantanderL10n.t("Editor Background Color")
            cell.accessoryView = cell.colorCircleAccessoryView(color: editorBackgroundColor)
        default: break
        }

        cell.contentConfiguration = conf
        return cell
    }

    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        self.selectedIndexPath = indexPath
        if indexPath.section == 2 {
            let vc = UIColorPickerViewController()
            switch indexPath.row {
            case 0:
                vc.selectedColor = theme.textColor?.uiColor ?? .label
            case 1:
                vc.selectedColor = editorBackgroundColor
            default:
                break
            }

            vc.delegate = self
            self.present(vc, animated: true)
            return
        }

        switch (indexPath.section, indexPath.row) {
        case (0, 0):
            let vc = UIFontPickerViewController()
            vc.delegate = self
            self.present(vc, animated: true)
        default: break
        }
    }

    override func switchOptionIsEnabled(forIndexPath indexPath: IndexPath) -> Bool {
        switch (indexPath.section, indexPath.row) {
        case (1, 0):
            return UserPreferences.showLineCount
        case (1, 1):
            return UserPreferences.wrapLines
        case (1, 2):
            return UserPreferences.useCharacterPairs
        default:
            fatalError()
        }
    }

    override func settingsSwitch(forIndexPath indexPath: IndexPath) -> UISwitch {
        let s = super.settingsSwitch(forIndexPath: indexPath)

        let action = UIAction {
            UserDefaults.standard.set(s.isOn, forKey: self.defaultsKey(forIndexPath: indexPath))
            switch indexPath.row {
            case 0:
                self.delegate?.showLineCountConfigurationDidChange(showLineCount: s.isOn)
            case 1:
                self.delegate?.wrapLinesConfigurationDidChange(wrapLines: s.isOn)
            case 2:
                self.delegate?.characterPairConfigurationDidChange(useCharacterPairs: s.isOn)
            default:
                break
            }
        }

        s.addAction(action, for: .valueChanged)
        return s
    }

    override func defaultsKey(forIndexPath indexPath: IndexPath) -> String {
        switch (indexPath.section, indexPath.row) {
        case (1, 0):
            return "TextEditorShowLineCount"
        case (1, 1):
            return "TextEditorWrapLines"
        case (1, 2):
            return "TextEditorUseCharacterPairs"
        default:
            fatalError()
        }
    }

    @objc
    func fontStepperValueChanged(sender: UIStepper) {
        let val = sender.value
        self.theme.font = CodableFont(self.theme.font.uiFont.withSize(val))
        persistGlobalThemeIfNeeded()

        let stepperCellIndexPath = IndexPath(row: 1, section: 0)
        self.tableView.reloadRows(at: [stepperCellIndexPath], with: .none)
        delegate?.themeDidChange(to: self.theme)
    }

    override func tableView(_ tableView: UITableView, shouldHighlightRowAt indexPath: IndexPath) -> Bool {
        return indexPath.section == 2 || (indexPath.section, indexPath.row) == (0, 0)
    }

    func setColor(_ color: UIColor, forIndexPath indexPath: IndexPath) {
        switch (indexPath.section, indexPath.row) {
        case (2, 0):
            theme.textColor = CodableColor(color)
            self.delegate?.themeDidChange(to: theme)
        case (2, 1):
            let codableColor = CodableColor(color)
            theme.textEditorBackgroundColor = codableColor
            self.delegate?.didChangeEditorBackground(to: codableColor)
        default:
            break
        }

        persistGlobalThemeIfNeeded()
        tableView.reloadRows(at: [indexPath], with: .none)
    }

    func colorPickerViewControllerDidFinish(_ viewController: UIColorPickerViewController) {
        guard let selectedIndexPath = selectedIndexPath else {
            return
        }
        setColor(viewController.selectedColor, forIndexPath: selectedIndexPath)
    }

    override func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        switch section {
        case 0:
            return SantanderL10n.t("Fonts")
        case 1:
            return SantanderL10n.t("Lines")
        case 2:
            return SantanderL10n.t("Colors")
        default:
            return nil
        }
    }
}


extension TextEditorThemeSettingsViewController: UIFontPickerViewControllerDelegate {
    func fontPickerViewControllerDidPickFont(_ viewController: UIFontPickerViewController) {
        viewController.dismiss(animated: true)
        guard let descriptor = viewController.selectedFontDescriptor else { return }
        let existingFontSize = self.theme.font.uiFont.pointSize
        self.theme.font = CodableFont(UIFont(descriptor: descriptor, size: existingFontSize))

        let fontNameIndexPath = IndexPath(row: 0, section: 0)
        self.tableView.reloadRows(at: [fontNameIndexPath], with: .none)
        persistGlobalThemeIfNeeded()
        delegate?.themeDidChange(to: self.theme)
    }
}

protocol EditorThemeSettingsDelegate: AnyObject {
    func themeDidChange(to newTheme: CodableTextEditorTheme)
    func wrapLinesConfigurationDidChange(wrapLines: Bool)
    func showLineCountConfigurationDidChange(showLineCount: Bool)
    func characterPairConfigurationDidChange(useCharacterPairs: Bool)
    func didChangeEditorBackground(to color: CodableColor)
}

private final class SantanderTextLineNumberGutterView: UIView {
    private weak var textView: UITextView?
    private var lineStarts: [Int] = [0]
    private var sourceLength = 0
    private var rebuildRevision = 0
    private var offsetObservation: NSKeyValueObservation?
    private var textObservation: NSObjectProtocol?

    init(textView: UITextView) {
        self.textView = textView
        super.init(frame: .zero)
        isOpaque = false
        backgroundColor = .tertiarySystemBackground
        offsetObservation = textView.observe(\.contentOffset, options: [.initial, .new]) { [weak self] _, _ in
            self?.setNeedsDisplay()
        }
        textObservation = NotificationCenter.default.addObserver(forName: UITextView.textDidChangeNotification, object: textView, queue: .main) { [weak self] notification in
            guard let textView = notification.object as? UITextView else { return }
            self?.setText(source: textView.text ?? "")
        }
    }

    required init?(coder: NSCoder) { fatalError() }

    deinit {
        offsetObservation?.invalidate()
        if let textObservation { NotificationCenter.default.removeObserver(textObservation) }
    }

    func setText(source: String) {
        rebuildRevision &+= 1
        let revision = rebuildRevision
        DispatchQueue.global(qos: .utility).async { [weak self] in
            let ns = source as NSString
            var starts: [Int] = [0]
            starts.reserveCapacity(max(1, ns.length / 48))
            var cursor = 0
            while cursor < ns.length {
                let range = ns.range(of: "\n", options: [], range: NSRange(location: cursor, length: ns.length - cursor))
                guard range.location != NSNotFound else { break }
                let next = NSMaxRange(range)
                if next < ns.length { starts.append(next) }
                cursor = next
            }
            DispatchQueue.main.async { [weak self] in
                guard let self, self.rebuildRevision == revision else { return }
                self.lineStarts = starts
                self.sourceLength = ns.length
                self.setNeedsDisplay()
            }
        }
    }

    private func lineNumber(forCharacterLocation location: Int) -> Int {
        if lineStarts.isEmpty { return 1 }
        let target = min(max(location, 0), sourceLength)
        var low = 0
        var high = lineStarts.count
        while low < high {
            let mid = (low + high) >> 1
            if lineStarts[mid] <= target {
                low = mid + 1
            } else {
                high = mid
            }
        }
        return max(1, low)
    }

    override func draw(_ rect: CGRect) {
        super.draw(rect)
        guard let textView, let lineNumberTextView = textView as? TextView, lineNumberTextView.showLineNumbers else { return }
        let layoutManager = textView.layoutManager
        let textContainer = textView.textContainer
        let visibleRect = CGRect(origin: textView.contentOffset, size: textView.bounds.size)
        let glyphRange = layoutManager.glyphRange(forBoundingRect: visibleRect, in: textContainer)
        let font = UIFont.monospacedDigitSystemFont(ofSize: 11, weight: .regular)
        let paragraph = NSMutableParagraphStyle()
        paragraph.alignment = .right
        paragraph.lineBreakMode = .byClipping
        let attributes: [NSAttributedString.Key: Any] = [
            .font: font,
            .foregroundColor: UIColor.secondaryLabel,
            .paragraphStyle: paragraph
        ]
        let maxWidth = bounds.width - 6
        layoutManager.enumerateLineFragments(forGlyphRange: glyphRange) { [weak self] _, usedRect, _, characterRange, _ in
            guard let self else { return }
            let line = self.lineNumber(forCharacterLocation: characterRange.location)
            let baselineY = usedRect.minY - textView.contentOffset.y + 2
            let value = "\(line)" as NSString
            let drawRect = CGRect(x: 3, y: baselineY, width: maxWidth, height: font.lineHeight)
            value.draw(in: drawRect, withAttributes: attributes)
        }
    }
}

private final class SantanderTextMiniMapView: UIView {
    private var lineLengths: [CGFloat] = []
    var onSelectLine: ((Int) -> Void)?

    override init(frame: CGRect) {
        super.init(frame: frame)
        backgroundColor = UIColor.secondarySystemBackground.withAlphaComponent(0.7)
        isAccessibilityElement = true
        accessibilityLabel = "文本 minimap"
        let tap = UITapGestureRecognizer(target: self, action: #selector(jump(_:)))
        let pan = UIPanGestureRecognizer(target: self, action: #selector(jump(_:)))
        addGestureRecognizer(tap)
        addGestureRecognizer(pan)
    }
    required init?(coder: NSCoder) { fatalError() }

    func setText(_ text: String) {
        lineLengths = text.split(separator: "\n", omittingEmptySubsequences: false).map { CGFloat(min($0.count, 160)) / 160.0 }
        setNeedsDisplay()
    }

    override func draw(_ rect: CGRect) {
        guard let context = UIGraphicsGetCurrentContext(), !lineLengths.isEmpty else { return }
        let step = max(1.5, bounds.height / CGFloat(lineLengths.count))
        let visibleCount = min(lineLengths.count, Int(bounds.height / step) + 1)
        let scale = CGFloat(lineLengths.count) / CGFloat(max(visibleCount, 1))
        UIColor.tertiaryLabel.withAlphaComponent(0.65).setFill()
        for index in 0..<visibleCount {
            let lineIndex = min(lineLengths.count - 1, Int(CGFloat(index) * scale))
            let width = max(2, (bounds.width - 5) * lineLengths[lineIndex])
            let y = CGFloat(index) * step + 1
            context.fill(CGRect(x: 2, y: y, width: min(width, bounds.width - 4), height: max(1, step - 0.8)))
        }
    }

    @objc private func jump(_ recognizer: UIGestureRecognizer) {
        guard !lineLengths.isEmpty else { return }
        let point = recognizer.location(in: self)
        let ratio = min(1, max(0, point.y / max(bounds.height, 1)))
        let line = Int(ratio * CGFloat(max(0, lineLengths.count - 1)))
        onSelectLine?(line)
    }
}

class TextFileEditorViewController: UIViewController, TextViewDelegate, EditorThemeSettingsDelegate {
    var fileURL: URL
    var originalContents: String

    var textView: TextView = TextView()
    var keyboardToolsView: KeyboardToolsView!
    private var syntaxHighlightWorkItem: DispatchWorkItem?
    private var lineNumberGutter: SantanderTextLineNumberGutterView?
    private var miniMap: SantanderTextMiniMapView?
    var theme: CodableTextEditorTheme = UserPreferences.textEditorTheme(for: UITraitCollection.current.userInterfaceStyle) {
        didSet {
            UserPreferences.setTextEditorTheme(theme, for: traitCollection.userInterfaceStyle)
            let state = TextViewState(text: textView.text, theme: theme.theme)
            if Thread.isMainThread {
                textView.setState(state)
            } else {
                DispatchQueue.main.async {
                    self.textView.setState(state)
                }
            }
        }
    }

    init(fileURL: URL, contents: String) {
        self.fileURL = fileURL
        self.originalContents = contents

        super.init(nibName: nil, bundle: nil)
    }

    convenience init(fileURL: URL) throws {
        self.init(fileURL: fileURL, contents: try String(contentsOf: fileURL))
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    lazy var themeController: TextEditorThemeSettingsViewController = {
        let controller = TextEditorThemeSettingsViewController(style: .insetGrouped, theme: self.theme)
        controller.delegate = self
        return controller
    }()

    override func viewDidLoad() {
        super.viewDidLoad()

        self.title = fileURL.lastPathComponent
        textView.showLineNumbers = UserPreferences.showLineCount
        textView.isLineWrappingEnabled = UserPreferences.wrapLines
        textView.setState(TextViewState(text: originalContents, theme: theme.theme))
        scheduleSyntaxHighlighting()

        textView.autocorrectionType = .no
        textView.autocapitalizationType = .none
        if UserPreferences.useCharacterPairs {
            textView.characterPairs = AnyCharacterPair.all()
        }

        let contentLocked = PathPermissions.isLocked(at: fileURL)
        textView.isEditable = !contentLocked
        textView.editorDelegate = contentLocked ? nil : self
        textView.backgroundColor = theme.textEditorBackgroundColor?.uiColor ?? .tertiarySystemBackground
        self.keyboardToolsView = KeyboardToolsView(textView: textView)
        textView.inputAccessoryView = keyboardToolsView

        let saveBarButton = UIBarButtonItem(barButtonSystemItem: .save, target: self, action: #selector(saveToFile))
        saveBarButton.isEnabled = !contentLocked && !textIsSameAsOriginal
        navigationItem.rightBarButtonItems = [saveBarButton, UIBarButtonItem(image: SantanderIconLibrary.shared.interfaceIcon(for: "ellipsis.circle"), style: .plain, target: self, action: #selector(showRightBarMenuItems))]

        navigationItem.leftBarButtonItem = UIBarButtonItem(barButtonSystemItem: .cancel, target: self, action: #selector(cancel))

#if compiler(>=5.7)
        if #available(iOS 16.0, *) {
            navigationItem.style = .editor
            self.navigationItem.renameDelegate = self
            self.navigationItem.documentProperties = UIDocumentProperties(url: fileURL)
        }
#endif

        textView.keyboardDismissMode = .onDrag
        textView.translatesAutoresizingMaskIntoConstraints = false

        let gutter = SantanderTextLineNumberGutterView(textView: textView)
        gutter.isHidden = !UserPreferences.showLineCount
        lineNumberGutter = gutter
        view.addSubview(gutter)
        view.addSubview(textView)

        let lineCount = originalContents.split(separator: "\n", omittingEmptySubsequences: false).count
        let minimap: SantanderTextMiniMapView? = lineCount >= 120 ? SantanderTextMiniMapView(frame: .zero) : nil
        miniMap = minimap
        if let minimap {
            minimap.translatesAutoresizingMaskIntoConstraints = false
            minimap.setText(originalContents)
            minimap.onSelectLine = { [weak self] line in self?.textView.goToLine(line) }
            view.addSubview(minimap)
        }

        configureNavigationBarToNormal()

        gutter.translatesAutoresizingMaskIntoConstraints = false
        var editorConstraints: [NSLayoutConstraint] = [
            gutter.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            gutter.topAnchor.constraint(equalTo: view.topAnchor),
            gutter.bottomAnchor.constraint(equalTo: view.bottomAnchor),
            gutter.widthAnchor.constraint(equalToConstant: 48),
            textView.leadingAnchor.constraint(equalTo: gutter.trailingAnchor),
            textView.topAnchor.constraint(equalTo: view.topAnchor),
            textView.bottomAnchor.constraint(equalTo: view.bottomAnchor)
        ]
        if let minimap {
            editorConstraints += [
                textView.trailingAnchor.constraint(equalTo: minimap.leadingAnchor),
                minimap.trailingAnchor.constraint(equalTo: view.trailingAnchor),
                minimap.topAnchor.constraint(equalTo: view.topAnchor),
                minimap.bottomAnchor.constraint(equalTo: view.bottomAnchor),
                minimap.widthAnchor.constraint(equalToConstant: 24)
            ]
        } else {
            editorConstraints.append(textView.trailingAnchor.constraint(equalTo: view.trailingAnchor))
        }
        NSLayoutConstraint.activate(editorConstraints)
        gutter.setText(source: originalContents)

        if UIDevice.isiPad {
            let navVC = UINavigationController(rootViewController: themeController)
            splitViewController?.setViewController(navVC, for: .primary)
            splitViewController?.preferredDisplayMode = .oneBesideSecondary
        }

        let notificationCenter = NotificationCenter.default
        notificationCenter.addObserver(self, selector: #selector(adjustForKeyboard), name: UIResponder.keyboardWillHideNotification, object: nil)
        notificationCenter.addObserver(self, selector: #selector(adjustForKeyboard), name: UIResponder.keyboardWillChangeFrameNotification, object: nil)
    }

    @objc func adjustForKeyboard(notification: Notification) {
        guard let keyboardValue = notification.userInfo?[UIResponder.keyboardFrameEndUserInfoKey] as? NSValue else {
            return
        }

        let keyboardScreenEndFrame = keyboardValue.cgRectValue
        let keyboardViewEndFrame = view.convert(keyboardScreenEndFrame, from: view.window)

        if notification.name == UIResponder.keyboardWillHideNotification {
            textView.contentInset = .zero
        } else {
            textView.contentInset = UIEdgeInsets(top: 0, left: 0,
                                                 bottom: keyboardViewEndFrame.height - view.safeAreaInsets.bottom,
                                                 right: 0)
        }

        textView.scrollIndicatorInsets = textView.contentInset
        let selectedRange = textView.selectedRange
        textView.scrollRangeToVisible(selectedRange)
    }

    override var keyCommands: [UIKeyCommand]? {
        return [
            UIKeyCommand(title: SantanderL10n.t("Zoom in"), action: #selector(zoomInOrOut(sender:)), input: "+", modifierFlags: .command),
            UIKeyCommand(title: SantanderL10n.t("Zoom out"), action: #selector(zoomInOrOut(sender:)), input: "-", modifierFlags: .command)
        ]
    }

    @objc func zoomInOrOut(sender: UIKeyCommand) {
        let existingFont = theme.font.uiFont
        self.theme.font = CodableFont(existingFont.withSize(existingFont.pointSize))

        switch sender.title {
        case SantanderL10n.t("Zoom in"):
            self.theme.font = CodableFont(existingFont.withSize(existingFont.pointSize + 1))
        case SantanderL10n.t("Zoom out"):
            self.theme.font = CodableFont(existingFont.withSize(existingFont.pointSize - 1))
        default:
            break
        }

        themeController.theme = self.theme
        themeController.tableView.reloadRows(at: [IndexPath(row: 1, section: 0)], with: .none)
    }

    @objc func showRightBarMenuItems() {
        let actions = [
            SantanderActionSheetItem(title: SantanderL10n.t("Settings"), image: SantanderIconLibrary.shared.interfaceIcon(for: "gear")) { [weak self] in self?.presentTextEditorSettings() },
            SantanderActionSheetItem(title: SantanderL10n.t("Go to line"), image: SantanderIconLibrary.shared.interfaceIcon(for: "text.alignleft")) { [weak self] in self?.showGoToLine() },
            SantanderActionSheetItem(title: SantanderL10n.t("Cancel"), style: .cancel)
        ]
        presentSantanderActionSheet(title: SantanderL10n.t("Editor Options"), actions: actions)
    }

    func showGoToLine() {
        let alert = UIAlertController(title: SantanderL10n.t("Go to line"), message: nil, preferredStyle: .alert)
        alert.addTextField { textField in
            textField.keyboardType = .numberPad
        }

        let goToLineAction = UIAlertAction(title: SantanderL10n.t("Go to line"), style: .default) { _ in
            guard let text = alert.textFields?.first?.text, let line = Int(text) else {
                print("\(#function) should not have reached here!")
                return
            }

            self.textView.goToLine(line - 1)
        }

        alert.addAction(.cancel())
        alert.addAction(goToLineAction)
        self.present(alert, animated: true)
    }

    func textViewDidChange(_ textView: TextView) {
        self.navigationItem.rightBarButtonItem?.isEnabled = !textIsSameAsOriginal
        self.lineNumberGutter?.setText(source: textView.text ?? "")
        self.miniMap?.setText(textView.text ?? "")
        scheduleSyntaxHighlighting()
    }

    private func scheduleSyntaxHighlighting() {
        syntaxHighlightWorkItem?.cancel()
        let source = textView.text ?? ""
        let sourceBytes = source.utf8.count
        let extensionName = fileURL.pathExtension
        if sourceBytes > 1_000_000 {
            DispatchQueue.main.async { [weak self] in
                guard let self else { return }
                self.textView.typingAttributes = [
                    .font: self.theme.font.uiFont,
                    .foregroundColor: self.theme.theme.textColor
                ]
                self.lineNumberGutter?.setText(source: source)
                self.lineNumberGutter?.setNeedsDisplay()
            }
            return
        }
        let work = DispatchWorkItem { [weak self] in
            guard let self else { return }
            let attributed = SantanderSyntaxHighlighter.highlight(source, fileExtension: extensionName, baseFont: self.theme.font.uiFont, baseColor: self.theme.theme.textColor)
            DispatchQueue.main.async { [weak self] in
                guard let self, !self.textView.isFirstResponder || self.textView.selectedRange.length == 0 else { return }
                guard self.textView.text == source else { return }
                self.textView.attributedText = attributed
                self.lineNumberGutter?.setText(source: source)
                self.lineNumberGutter?.setNeedsDisplay()
            }
        }
        syntaxHighlightWorkItem = work
        DispatchQueue.global(qos: .utility).asyncAfter(deadline: .now() + 0.3, execute: work)
    }

    @objc
    func saveToFile() {
        let newContentsToSave = textView.text ?? ""

        do {
            try ensureFileContentIsUnlocked(fileURL)
            try FSOperation.perform(.writeString(url: fileURL, string: newContentsToSave), rootHelperConf: RootConf.shared)
            self.dismiss(animated: true)
        } catch {
            self.errorAlert(error, title: SantanderL10n.t("Unable to save to file"))
        }
    }

    @objc
    func cancel() {
        if !textIsSameAsOriginal {
            presentSantanderActionSheet(title: SantanderL10n.t("Unsaved changes"), message: "文件「\(fileURL.lastPathComponent)」有未保存的更改，确定要关闭吗？", actions: [
                SantanderActionSheetItem(title: SantanderL10n.t("Save"), image: SantanderIconLibrary.shared.interfaceIcon(for: "square.and.arrow.down")) { [weak self] in self?.saveToFile() },
                SantanderActionSheetItem(title: SantanderL10n.t("Don't save"), image: SantanderIconLibrary.shared.interfaceIcon(for: "trash"), style: .destructive) { [weak self] in self?.dismiss(animated: true) },
                SantanderActionSheetItem(title: SantanderL10n.t("Cancel"), style: .cancel)
            ])
        } else {
            self.dismiss(animated: true)
        }
    }

    var textIsSameAsOriginal: Bool {
        textView.text == originalContents
    }

    override func traitCollectionDidChange(_ previousTraitCollection: UITraitCollection?) {
        super.traitCollectionDidChange(previousTraitCollection)
        guard previousTraitCollection?.userInterfaceStyle != traitCollection.userInterfaceStyle else { return }
        theme = UserPreferences.textEditorTheme(for: traitCollection.userInterfaceStyle)
    }

    @objc func presentTextEditorSettings() {
        if UIDevice.isiPad {
            splitViewController?.show(.primary)
        } else {
            let navVC = UINavigationController(rootViewController: themeController)

            if #available(iOS 15.0, *) {
                navVC.sheetPresentationController?.detents = [.medium(), .large()]
            }
            self.present(navVC, animated: true)
        }
    }

    func themeDidChange(to newTheme: CodableTextEditorTheme) {
        self.theme = newTheme
    }

    func wrapLinesConfigurationDidChange(wrapLines: Bool) {
        self.textView.isLineWrappingEnabled = wrapLines
    }

    func showLineCountConfigurationDidChange(showLineCount: Bool) {
        self.textView.showLineNumbers = showLineCount
        self.lineNumberGutter?.isHidden = !showLineCount
    }

    func didChangeEditorBackground(to color: CodableColor) {
        self.textView.backgroundColor = color.uiColor
        self.theme.textEditorBackgroundColor = color
    }

    func characterPairConfigurationDidChange(useCharacterPairs: Bool) {
        textView.characterPairs = useCharacterPairs ? AnyCharacterPair.all() : []
    }
}

#if compiler(>=5.7)
@available(iOS 16.0, *)
extension TextFileEditorViewController: UINavigationItemRenameDelegate {
    func navigationItem(_: UINavigationItem, didEndRenamingWith title: String) {
        let newURL = self.fileURL.deletingLastPathComponent().appendingPathComponent(title)

        guard newURL != self.fileURL else {
            return
        }

        do {
            try FSOperation.perform(.moveItem(items: [fileURL], resultPath: newURL), rootHelperConf: RootConf.shared)
            self.fileURL = newURL
        } catch {
            self.errorAlert(error, title: "无法重命名 \(fileURL.lastPathComponent)")
            self.title = fileURL.lastPathComponent
        }
    }
}
#endif

class AnyTheme: Theme {
    public init(
        textColor: UIColor,
        font: UIFont,
        gutterBackgroundColor: UIColor,
        gutterHairlineColor: UIColor,
        lineNumberColor: UIColor,
        lineNumberFont: UIFont,
        selectedLineBackgroundColor: UIColor,
        selectedLinesLineNumberColor: UIColor,
        selectedLinesGutterBackgroundColor: UIColor,
        invisibleCharactersColor: UIColor,
        pageGuideBackgroundColor: UIColor,
        pageGuideHairlineColor: UIColor,
        markedTextBackgroundColor: UIColor,
        markedTextBackgroundBorderColor: UIColor
    ) {
        self._textColor = textColor
        self._font = font
        self._gutterBackgroundColor = gutterBackgroundColor
        self._gutterHairlineColor = gutterHairlineColor
        self._lineNumberColor = lineNumberColor
        self._lineNumberFont = lineNumberFont
        self._selectedLineBackgroundColor = selectedLineBackgroundColor
        self._selectedLinesLineNumberColor = selectedLinesLineNumberColor
        self._selectedLinesGutterBackgroundColor = selectedLinesGutterBackgroundColor
        self._invisibleCharactersColor = invisibleCharactersColor
        self._pageGuideBackgroundColor = pageGuideBackgroundColor
        self._pageGuideHairlineColor = pageGuideHairlineColor
        self._markedTextBackgroundColor = markedTextBackgroundColor
        self._markedTextBackgroundBorderColor = markedTextBackgroundBorderColor
    }

    private let _textColor: UIColor
    private let _font: UIFont
    private let _gutterBackgroundColor: UIColor
    private let _gutterHairlineColor: UIColor
    private let _lineNumberColor: UIColor
    private let _lineNumberFont: UIFont
    private let _selectedLineBackgroundColor: UIColor
    private let _selectedLinesLineNumberColor: UIColor
    private let _selectedLinesGutterBackgroundColor: UIColor
    private let _invisibleCharactersColor: UIColor
    private let _pageGuideBackgroundColor: UIColor
    private let _pageGuideHairlineColor: UIColor
    private let _markedTextBackgroundColor: UIColor
    private let _markedTextBackgroundBorderColor: UIColor

    var textColor: UIColor { _textColor }
    var font: UIFont { _font }
    var gutterBackgroundColor: UIColor { _gutterBackgroundColor }
    var gutterHairlineColor: UIColor { _gutterHairlineColor }
    var lineNumberColor: UIColor { _lineNumberColor }
    var lineNumberFont: UIFont { _lineNumberFont }
    var selectedLineBackgroundColor: UIColor { _selectedLineBackgroundColor }
    var selectedLinesLineNumberColor: UIColor { _selectedLinesLineNumberColor }
    var selectedLinesGutterBackgroundColor: UIColor { _selectedLinesGutterBackgroundColor }
    var invisibleCharactersColor: UIColor { _invisibleCharactersColor }
    var pageGuideBackgroundColor: UIColor { _pageGuideBackgroundColor }
    var pageGuideHairlineColor: UIColor { _pageGuideHairlineColor }
    var markedTextBackgroundColor: UIColor { _markedTextBackgroundColor }
    var markedTextBackgroundBorderColor: UIColor { _markedTextBackgroundBorderColor }

    func textColor(for rawHighlightName: String) -> UIColor? {
        switch rawHighlightName.lowercased() {
        case "keyword", "control", "declaration", "type": return SantanderAppTheme.accentColor
        case "string", "character": return .systemRed
        case "number", "constant": return .systemOrange
        case "comment": return .systemGreen
        case "attribute", "property", "key": return .systemPurple
        case "function", "call": return .systemTeal
        case "operator": return .systemPink
        default: return nil
        }
    }

    func font(for rawHighlightName: String) -> UIFont? {
        switch rawHighlightName.lowercased() {
        case "keyword", "declaration", "type": return UIFont.monospacedSystemFont(ofSize: _font.pointSize, weight: .semibold)
        default: return nil
        }
    }
}

struct CodableColor: Codable {
    let red: CGFloat
    let green: CGFloat
    let blue: CGFloat
    let alpha: CGFloat

    var uiColor: UIColor {
        return UIColor(red: self.red, green: self.green, blue: self.blue, alpha: self.alpha)
    }

    init(_ color: UIColor) {
        var _red: CGFloat = 0, _green: CGFloat = 0, _blue: CGFloat = 0, _alpha: CGFloat = 0

        color.getRed(&_red, green: &_green, blue: &_blue, alpha: &_alpha)

        self.red = _red
        self.blue = _blue
        self.green = _green
        self.alpha = _alpha
    }
}

struct CodableFont: Codable {
    var name: String
    var size: CGFloat

    var uiFont: UIFont {
        UIFont(name: name, size: size) ?? UIFont.monospacedSystemFont(ofSize: size, weight: .regular)
    }

    init(_ font: UIFont) {
        self.name = font.fontName
        self.size = font.pointSize
    }
}

struct CodableTextEditorTheme: Codable {
    var textColor: CodableColor? = nil
    var font = CodableFont(UIFont(name: "Menlo-Regular", size: 16)!)

    var gutterBackgroundColor: CodableColor = CodableColor(.secondarySystemBackground)
    var gutterHairlineColor: CodableColor = CodableColor(.opaqueSeparator)

    var lineNumberColor: CodableColor = CodableColor(.secondaryLabel)
    var lineNumberFont = CodableFont(UIFont(name: "Menlo-Regular", size: 14)!)

    var selectedLineBackgroundColor: CodableColor = CodableColor(.secondarySystemBackground)
    var selectedLinesLineNumberColor: CodableColor = CodableColor(.label)
    var selectedLinesGutterBackgroundColor: CodableColor = CodableColor(UIColor.opaqueSeparator.withAlphaComponent(0.4))

    var invisibleCharactersColor: CodableColor = CodableColor(.tertiaryLabel)

    var pageGuideBackgroundColor: CodableColor = CodableColor(.secondarySystemBackground)
    var pageGuideHairlineColor: CodableColor = CodableColor(.opaqueSeparator)

    var markedTextBackgroundColor: CodableColor = CodableColor(.systemFill)
    var markedTextBackgroundBorderColor: CodableColor = CodableColor(.clear)

    var textEditorBackgroundColor: CodableColor? = nil
    var theme: AnyTheme {
        AnyTheme(
            textColor: textColor?.uiColor ?? .label,
            font: font.uiFont,
            gutterBackgroundColor: gutterBackgroundColor.uiColor,
            gutterHairlineColor: gutterHairlineColor.uiColor,
            lineNumberColor: lineNumberColor.uiColor,
            lineNumberFont: lineNumberFont.uiFont,
            selectedLineBackgroundColor: selectedLineBackgroundColor.uiColor,
            selectedLinesLineNumberColor: selectedLinesLineNumberColor.uiColor,
            selectedLinesGutterBackgroundColor: selectedLinesGutterBackgroundColor.uiColor,
            invisibleCharactersColor: invisibleCharactersColor.uiColor,
            pageGuideBackgroundColor: pageGuideBackgroundColor.uiColor,
            pageGuideHairlineColor: pageGuideHairlineColor.uiColor,
            markedTextBackgroundColor: markedTextBackgroundColor.uiColor,
            markedTextBackgroundBorderColor: markedTextBackgroundBorderColor.uiColor
        )
    }
}

struct AnyCharacterPair: CharacterPair {
    var leading: String
    var trailing: String

    static func all() -> [AnyCharacterPair] {
        return [
            AnyCharacterPair(leading: "{", trailing: "}"),
            AnyCharacterPair(leading: "(", trailing: ")"),
            AnyCharacterPair(leading: "[", trailing: "]"),
            AnyCharacterPair(leading: "<", trailing: ">")
        ]
    }
}


private enum SantanderBinaryTools {
    static func isSQLite(_ url: URL) -> Bool {
        let ext = url.pathExtension.lowercased()
        guard ["sqlite", "sqlite3", "db", "db3"].contains(ext) else { return false }
        guard let handle = try? FileHandle(forReadingFrom: url) else { return false }
        defer { try? handle.close() }
        guard let magic = try? handle.read(upToCount: 16) else { return false }
        return magic.starts(with: Array("SQLite format 3\0".utf8))
    }

    static func isArchive(_ url: URL) -> Bool {
        let path = url.path.lowercased()
        return [".zip", ".tar", ".gz", ".bz2", ".tgz", ".tbz", ".tbz2", ".7z", ".rar"].contains { path.hasSuffix($0) }
    }
}

private final class HexRowCell: UITableViewCell {
    let offsetLabel = UILabel()
    let hexLabel = UILabel()
    let asciiLabel = UILabel()

    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        SantanderUI.styleCell(self)
        [offsetLabel, hexLabel, asciiLabel].forEach {
            $0.font = .monospacedSystemFont(ofSize: 12, weight: .regular)
            $0.adjustsFontForContentSizeCategory = true
            $0.numberOfLines = 1
        }
        offsetLabel.textColor = .secondaryLabel
        hexLabel.textColor = .label
        asciiLabel.textColor = .secondaryLabel
        let stack = UIStackView(arrangedSubviews: [offsetLabel, hexLabel, asciiLabel])
        stack.axis = .horizontal
        stack.spacing = 12
        stack.alignment = .center
        stack.translatesAutoresizingMaskIntoConstraints = false
        contentView.addSubview(stack)
        NSLayoutConstraint.activate([
            offsetLabel.widthAnchor.constraint(equalToConstant: 72),
            hexLabel.widthAnchor.constraint(equalToConstant: 392),
            stack.leadingAnchor.constraint(equalTo: contentView.layoutMarginsGuide.leadingAnchor),
            stack.trailingAnchor.constraint(equalTo: contentView.layoutMarginsGuide.trailingAnchor),
            stack.topAnchor.constraint(equalTo: contentView.topAnchor, constant: 7),
            stack.bottomAnchor.constraint(equalTo: contentView.bottomAnchor, constant: -7)
        ])
    }

    required init?(coder: NSCoder) { fatalError() }
}

private final class HexEditorViewController: UITableViewController {
    private let fileURL: URL
    private var fd: Int32 = -1
    private var fileSize: UInt64 = 0
    private var writable = false
    private let bytesPerRow = 16
    private let pageSize: Int = 4096
    private var pageCache: [UInt64: (pointer: UnsafeMutableRawPointer, length: Int, stamp: UInt64)] = [:]
    private var pageStamp: UInt64 = 0
    private var searchModeIsHex = true

    init(fileURL: URL) {
        self.fileURL = fileURL
        super.init(style: .plain)
        title = SantanderL10n.t("Hex Editor")
    }

    required init?(coder: NSCoder) { fatalError() }

    deinit {
        for page in pageCache.values {
            _ = munmap(page.pointer, page.length)
        }
        if fd >= 0 { _ = close(fd) }
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        applySantanderUI()
        tableView.register(HexRowCell.self, forCellReuseIdentifier: "hex")
        tableView.rowHeight = 32
        tableView.separatorStyle = .none
        navigationItem.leftBarButtonItem = UIBarButtonItem(barButtonSystemItem: .close, target: self, action: #selector(closeEditor))
        navigationItem.rightBarButtonItem = UIBarButtonItem(
            title: SantanderL10n.t("Search"),
            style: .plain,
            target: self,
            action: #selector(showSearch)
        )

        do {
            try openFile()
        } catch {
            errorAlert(error, title: SantanderL10n.t("Unable to open item"))
        }
    }

    @objc private func closeEditor() {
        if let navigationController,
           navigationController.viewControllers.first !== self,
           navigationController.topViewController === self {
            navigationController.popViewController(animated: true)
        } else {
            dismiss(animated: true)
        }
    }

    private func openFile() throws {
        var statBuffer = stat()
        guard lstat(fileURL.path, &statBuffer) == 0 else {
            throw StringError(String(cString: strerror(errno)))
        }
        guard statBuffer.st_size >= 0 else { throw StringError("文件大小无效。") }
        fileSize = UInt64(statBuffer.st_size)
        guard fileSize > 0 else { return }

        fd = open(fileURL.path, O_RDWR | O_CLOEXEC)
        if fd >= 0 {
            writable = true
        } else {
            fd = open(fileURL.path, O_RDONLY | O_CLOEXEC)
            writable = false
        }
        guard fd >= 0 else { throw StringError(String(cString: strerror(errno))) }
    }

    private func mappedPage(containing offset: UInt64) -> (pointer: UnsafeMutableRawPointer, length: Int)? {
        guard fileSize > 0, offset < fileSize else { return nil }
        let pageIndex = offset / UInt64(pageSize)
        if let cached = pageCache[pageIndex] {
            pageStamp &+= 1
            pageCache[pageIndex]?.stamp = pageStamp
            return (cached.pointer, cached.length)
        }

        let pageOffset = pageIndex * UInt64(pageSize)
        let length = Int(min(UInt64(pageSize), fileSize - pageOffset))
        guard let mapped = mmap(nil, length, PROT_READ, MAP_SHARED, fd, off_t(pageOffset)), mapped != MAP_FAILED else {
            return nil
        }
        pageStamp &+= 1
        pageCache[pageIndex] = (mapped, length, pageStamp)

        if pageCache.count > 8, let victim = pageCache.min(by: { $0.value.stamp < $1.value.stamp })?.key,
           let value = pageCache.removeValue(forKey: victim) {
            _ = munmap(value.pointer, value.length)
        }
        return (mapped, length)
    }

    private func byte(at offset: UInt64) -> UInt8? {
        guard let page = mappedPage(containing: offset) else { return nil }
        let pageOffset = Int(offset % UInt64(pageSize))
        guard pageOffset < page.length else { return nil }
        return page.pointer.assumingMemoryBound(to: UInt8.self)[pageOffset]
    }

    override func numberOfSections(in tableView: UITableView) -> Int { 1 }
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        Int((fileSize + UInt64(bytesPerRow - 1)) / UInt64(bytesPerRow))
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "hex", for: indexPath) as! HexRowCell
        let offset = UInt64(indexPath.row * bytesPerRow)
        cell.offsetLabel.text = String(format: "%08llX", offset)
        var hex = ""
        var ascii = ""
        for i in 0..<bytesPerRow {
            let current = offset + UInt64(i)
            if current < fileSize, let byte = byte(at: current) {
                hex += String(format: "%02X ", byte)
                ascii.append((byte >= 0x20 && byte <= 0x7E) ? Character(UnicodeScalar(byte)) : ".")
            } else {
                hex += "   "
                ascii += " "
            }
            if i == 7 { hex += " " }
        }
        cell.hexLabel.text = hex
        cell.asciiLabel.text = ascii
        cell.accessibilityLabel = "偏移 \(offset)，\(ascii.trimmingCharacters(in: .whitespaces))"
        return cell
    }

    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let offset = UInt64(indexPath.row * bytesPerRow)
        showByteEditor(startOffset: offset)
    }

    private func showByteEditor(startOffset: UInt64) {
        guard fileSize > startOffset else { return }
        let alert = UIAlertController(title: "修改字节", message: String(format: "起始偏移 0x%llX", startOffset), preferredStyle: .alert)
        alert.addTextField { field in
            field.placeholder = "偏移（HEX）"
            field.keyboardType = .asciiCapable
            field.text = String(format: "%llX", startOffset)
        }
        alert.addTextField { field in
            field.placeholder = "字节（00-FF）"
            field.keyboardType = .asciiCapable
        }
        alert.addAction(.cancel())
        alert.addAction(UIAlertAction(title: SantanderL10n.t("Save"), style: .default) { [weak self, weak alert] _ in
            guard let self, self.writable,
                  let offsetText = alert?.textFields?.first?.text,
                  let byteText = alert?.textFields?.dropFirst().first?.text,
                  let offset = UInt64(offsetText, radix: 16),
                  let value = UInt8(byteText, radix: 16),
                  offset < self.fileSize else { return }
            do {
                try ensureFileContentIsUnlocked(self.fileURL)
            } catch {
                self.errorAlert(error, title: SantanderL10n.t("文件已锁定"))
                return
            }
            var byte = value
            let result = withUnsafeBytes(of: &byte) { raw -> Int in
                guard let base = raw.baseAddress else { return -1 }
                return pwrite(self.fd, base, 1, off_t(offset))
            }
            if result != 1 {
                self.errorAlert(StringError(String(cString: strerror(errno))), title: "无法写入字节")
                return
            }
            self.pageCache.removeAll()
            self.tableView.reloadRows(at: [IndexPath(row: Int(offset / 16), section: 0)], with: .none)
        })
        present(alert, animated: true)
    }

    @objc private func showSearch() {
        presentSantanderActionSheet(title: SantanderL10n.t("Search"), actions: [
            SantanderActionSheetItem(title: "HEX", image: SantanderIconLibrary.shared.uiIcon(named: "hex-editor")) { [weak self] in self?.presentSearch(isHex: true) },
            SantanderActionSheetItem(title: "ASCII", image: SantanderIconLibrary.shared.interfaceIcon(for: "textformat.abc")) { [weak self] in self?.presentSearch(isHex: false) },
            SantanderActionSheetItem(title: SantanderL10n.t("Cancel"), style: .cancel)
        ])
    }

    private func presentSearch(isHex: Bool) {
        searchModeIsHex = isHex
        let alert = UIAlertController(title: isHex ? "HEX 查找" : "ASCII 查找", message: nil, preferredStyle: .alert)
        alert.addTextField { field in
            field.placeholder = isHex ? "例如 48 65 6C 6C 6F" : "搜索文本"
            field.autocapitalizationType = .allCharacters
            field.autocorrectionType = .no
        }
        alert.addAction(.cancel())
        alert.addAction(UIAlertAction(title: SantanderL10n.t("Search"), style: .default) { [weak self, weak alert] _ in
            guard let self, let text = alert?.textFields?.first?.text else { return }
            self.find(text: text, isHex: isHex)
        })
        present(alert, animated: true)
    }

    private func find(text: String, isHex: Bool) {
        let parsedNeedle: [UInt8]
        if isHex {
            let clean = text.replacingOccurrences(of: " ", with: "").replacingOccurrences(of: "\n", with: "")
            guard clean.count % 2 == 0 else {
                errorAlert("HEX 搜索必须包含偶数个字符。", title: SantanderL10n.t("Search")); return
            }
            parsedNeedle = stride(from: 0, to: clean.count, by: 2).compactMap {
                let start = clean.index(clean.startIndex, offsetBy: $0)
                let end = clean.index(start, offsetBy: 2)
                return UInt8(clean[start..<end], radix: 16)
            }
        } else {
            parsedNeedle = Array(text.utf8)
        }
        guard !parsedNeedle.isEmpty, parsedNeedle.count <= Int(fileSize) else { return }

        let fd = self.fd
        let size = self.fileSize
        let rowWidth = self.bytesPerRow
        DispatchQueue.global(qos: .userInitiated).async { [weak self] in
            guard let self, fd >= 0 else { return }
            let needle = parsedNeedle
            let chunkSize = 256 * 1024
            let overlap = max(0, needle.count - 1)
            var skip = [Int](repeating: needle.count, count: 256)
            if needle.count > 1 {
                for i in 0..<(needle.count - 1) { skip[Int(needle[i])] = needle.count - 1 - i }
            }

            var offset: UInt64 = 0
            var carry = Data()
            var foundOffset: UInt64?
            while offset < size, foundOffset == nil {
                let readLength = Int(min(UInt64(chunkSize), size - offset))
                var bytes = [UInt8](repeating: 0, count: readLength)
                let result = pread(fd, &bytes, readLength, off_t(offset))
                guard result > 0 else { break }
                var buffer = Array(carry)
                buffer.append(contentsOf: bytes[0..<result])
                let baseOffset = offset >= UInt64(carry.count) ? offset - UInt64(carry.count) : 0
                if buffer.count >= needle.count {
                    var i = 0
                    let limit = buffer.count - needle.count
                    while i <= limit {
                        var j = needle.count - 1
                        while buffer[i + j] == needle[j] {
                            if j == 0 { foundOffset = baseOffset + UInt64(i); break }
                            j -= 1
                        }
                        if foundOffset != nil { break }
                        i += skip[Int(buffer[i + needle.count - 1])]
                    }
                }
                carry = overlap > 0 ? Data(buffer.suffix(overlap)) : Data()
                offset += UInt64(result)
            }
            DispatchQueue.main.async { [weak self] in
                guard let self else { return }
                if let foundOffset {
                    let row = Int(foundOffset / UInt64(rowWidth))
                    guard row < self.tableView.numberOfRows(inSection: 0) else { return }
                    let indexPath = IndexPath(row: row, section: 0)
                    self.tableView.selectRow(at: indexPath, animated: true, scrollPosition: .middle)
                } else {
                    self.errorAlert(SantanderL10n.t("No Results"), title: SantanderL10n.t("Search"))
                }
            }
        }
    }

}

private struct SantanderSQLiteColumn {
    let name: String
    let type: Int32
}

private enum SantanderSQLiteValue {
    case null
    case integer(Int64)
    case real(Double)
    case text(String)
    case blob(Data)

    var display: String {
        switch self {
        case .null: return "NULL"
        case .integer(let value): return String(value)
        case .real(let value): return String(value)
        case .text(let value): return value
        case .blob(let value): return value.map { String(format: "%02X", $0) }.joined()
        }
    }

    var sqlLiteral: String {
        switch self {
        case .null: return "NULL"
        case .integer(let value): return String(value)
        case .real(let value): return String(value)
        case .text(let value): return "'\(value.replacingOccurrences(of: "'", with: "''"))'"
        case .blob(let value): return "X'\(value.map { String(format: "%02X", $0) }.joined())'"
        }
    }
}

private final class SantanderSQLiteDatabase {
    typealias OpenV2 = @convention(c) (UnsafePointer<CChar>, UnsafeMutablePointer<OpaquePointer?>, Int32, UnsafePointer<CChar>?) -> Int32
    typealias Close = @convention(c) (OpaquePointer?) -> Int32
    typealias Prepare = @convention(c) (OpaquePointer?, UnsafePointer<CChar>, Int32, UnsafeMutablePointer<OpaquePointer?>, UnsafeMutablePointer<UnsafePointer<CChar>?>?) -> Int32
    typealias Step = @convention(c) (OpaquePointer?) -> Int32
    typealias Finalize = @convention(c) (OpaquePointer?) -> Int32
    typealias ErrMsg = @convention(c) (OpaquePointer?) -> UnsafePointer<CChar>?
    typealias ColumnCount = @convention(c) (OpaquePointer?) -> Int32
    typealias ColumnName = @convention(c) (OpaquePointer?, Int32) -> UnsafePointer<CChar>?
    typealias ColumnType = @convention(c) (OpaquePointer?, Int32) -> Int32
    typealias ColumnInt64 = @convention(c) (OpaquePointer?, Int32) -> Int64
    typealias ColumnDouble = @convention(c) (OpaquePointer?, Int32) -> Double
    typealias ColumnText = @convention(c) (OpaquePointer?, Int32) -> UnsafePointer<UInt8>?
    typealias ColumnBytes = @convention(c) (OpaquePointer?, Int32) -> Int32
    typealias ColumnBlob = @convention(c) (OpaquePointer?, Int32) -> UnsafeRawPointer?

    private let handle: UnsafeMutableRawPointer
    private let openV2: OpenV2
    private let closeDB: Close
    private let prepare: Prepare
    private let step: Step
    private let finalize: Finalize
    private let errmsg: ErrMsg
    private let columnCount: ColumnCount
    private let columnName: ColumnName
    private let columnType: ColumnType
    private let columnInt64: ColumnInt64
    private let columnDouble: ColumnDouble
    private let columnText: ColumnText
    private let columnBytes: ColumnBytes
    private let columnBlob: ColumnBlob
    private var db: OpaquePointer?
    let fileURL: URL

    init(url: URL, writable: Bool = true) throws {
        self.fileURL = url
        let candidates = ["/usr/lib/libsqlite3.dylib", "/usr/lib/libsqlite3.0.dylib"]
        guard let loaded = candidates.lazy.compactMap({ dlopen($0, RTLD_LAZY | RTLD_LOCAL) }).first else {
            throw StringError("SQLite3 库不可用。")
        }

        func load<T>(_ name: String, as type: T.Type) throws -> T {
            guard let symbol = dlsym(loaded, name) else {
                throw StringError("缺少 SQLite3 函数：\(name)")
            }
            return unsafeBitCast(symbol, to: type)
        }

        let loadedOpenV2 = try load("sqlite3_open_v2", as: OpenV2.self)
        let loadedCloseDB = try load("sqlite3_close", as: Close.self)
        let loadedPrepare = try load("sqlite3_prepare_v2", as: Prepare.self)
        let loadedStep = try load("sqlite3_step", as: Step.self)
        let loadedFinalize = try load("sqlite3_finalize", as: Finalize.self)
        let loadedErrmsg = try load("sqlite3_errmsg", as: ErrMsg.self)
        let loadedColumnCount = try load("sqlite3_column_count", as: ColumnCount.self)
        let loadedColumnName = try load("sqlite3_column_name", as: ColumnName.self)
        let loadedColumnType = try load("sqlite3_column_type", as: ColumnType.self)
        let loadedColumnInt64 = try load("sqlite3_column_int64", as: ColumnInt64.self)
        let loadedColumnDouble = try load("sqlite3_column_double", as: ColumnDouble.self)
        let loadedColumnText = try load("sqlite3_column_text", as: ColumnText.self)
        let loadedColumnBytes = try load("sqlite3_column_bytes", as: ColumnBytes.self)
        let loadedColumnBlob = try load("sqlite3_column_blob", as: ColumnBlob.self)

        self.handle = loaded
        self.openV2 = loadedOpenV2
        self.closeDB = loadedCloseDB
        self.prepare = loadedPrepare
        self.step = loadedStep
        self.finalize = loadedFinalize
        self.errmsg = loadedErrmsg
        self.columnCount = loadedColumnCount
        self.columnName = loadedColumnName
        self.columnType = loadedColumnType
        self.columnInt64 = loadedColumnInt64
        self.columnDouble = loadedColumnDouble
        self.columnText = loadedColumnText
        self.columnBytes = loadedColumnBytes
        self.columnBlob = loadedColumnBlob

        var opened: OpaquePointer?
        let readWrite: Int32 = writable ? 0x00000002 : 0x00000001
        let result = url.path.withCString { loadedOpenV2($0, &opened, readWrite, nil) }
        guard result == 0, let opened else {
            let message = opened.flatMap { loadedErrmsg($0) }.map { String(cString: $0) } ?? "无法打开 SQLite 数据库"
            if let opened { _ = loadedCloseDB(opened) }
            dlclose(loaded)
            throw StringError(message)
        }
        self.db = opened
    }

    deinit {
        if let db { _ = closeDB(db) }
        dlclose(handle)
    }

    func query(_ sql: String) throws -> (columns: [String], rows: [[SantanderSQLiteValue]]) {
        guard let db else { throw StringError("SQLite 数据库已关闭。") }
        var stmt: OpaquePointer?
        let result = sql.withCString { prepare(db, $0, -1, &stmt, nil) }
        guard result == 0, let stmt else { throw StringError(errorMessage()) }
        defer { _ = finalize(stmt) }

        let count = Int(columnCount(stmt))
        var columns: [String] = []
        columns.reserveCapacity(count)
        for i in 0..<count {
            columns.append(columnName(stmt, Int32(i)).map(String.init(cString:)) ?? "Column \(i)")
        }

        var rows: [[SantanderSQLiteValue]] = []
        while true {
            let state = step(stmt)
            if state == 101 { break }
            guard state == 100 else { throw StringError(errorMessage()) }
            var row: [SantanderSQLiteValue] = []
            row.reserveCapacity(count)
            for i in 0..<count {
                row.append(value(stmt, at: Int32(i)))
            }
            rows.append(row)
            if rows.count >= 500 { break }
        }
        return (columns, rows)
    }

    func execute(_ sql: String) throws {
        _ = try query(sql)
    }

    private func value(_ stmt: OpaquePointer, at index: Int32) -> SantanderSQLiteValue {
        switch columnType(stmt, index) {
        case 1: return .integer(columnInt64(stmt, index))
        case 2: return .real(columnDouble(stmt, index))
        case 3:
            guard let pointer = columnText(stmt, index) else { return .text("") }
            let length = max(0, Int(columnBytes(stmt, index)))
            return .text(String(decoding: UnsafeBufferPointer(start: pointer, count: length), as: UTF8.self))
        case 4:
            guard let pointer = columnBlob(stmt, index) else { return .blob(Data()) }
            let length = max(0, Int(columnBytes(stmt, index)))
            return .blob(Data(bytes: pointer, count: length))
        default: return .null
        }
    }

    private func errorMessage() -> String {
        guard let db, let pointer = errmsg(db) else { return "SQLite 操作失败。" }
        return String(cString: pointer)
    }
}

private final class SQLiteEditorViewController: UITableViewController {
    private let fileURL: URL
    private var tables: [String] = []
    private var database: SantanderSQLiteDatabase?

    init(fileURL: URL) {
        self.fileURL = fileURL
        super.init(style: .insetGrouped)
        title = SantanderL10n.t("SQLite3 Editor")
    }

    required init?(coder: NSCoder) { fatalError() }

    override func viewDidLoad() {
        super.viewDidLoad()
        applySantanderUI()
        navigationItem.rightBarButtonItem = UIBarButtonItem(title: SantanderL10n.t("SQL"), style: .plain, target: self, action: #selector(showSQLPrompt))
        tableView.rowHeight = 52
        DispatchQueue.global(qos: .userInitiated).async { [weak self] in
            do {
                let db = try SantanderSQLiteDatabase(url: self?.fileURL ?? URL(fileURLWithPath: "/"))
                let result = try db.query("SELECT name FROM sqlite_master WHERE type IN ('table','view') AND name NOT LIKE 'sqlite_%' ORDER BY name")
                let names = result.rows.compactMap { $0.first }.compactMap { value -> String? in if case .text(let name) = value { return name }; return nil }
                DispatchQueue.main.async { [weak self] in self?.database = db; self?.tables = names; self?.tableView.reloadData() }
            } catch {
                DispatchQueue.main.async { [weak self] in self?.errorAlert(error, title: SantanderL10n.t("Unable to open item")) }
            }
        }
    }

    override func numberOfSections(in tableView: UITableView) -> Int { 1 }
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int { tables.count }
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = UITableViewCell(style: .subtitle, reuseIdentifier: nil)
        SantanderUI.styleCell(cell)
        cell.imageView?.image = SantanderIconLibrary.shared.interfaceIcon(for: "tablecells")
        cell.textLabel?.text = tables[indexPath.row]
        cell.detailTextLabel?.text = "SQLite"
        cell.accessoryType = .disclosureIndicator
        return cell
    }

    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        guard let database else { return }
        navigationController?.pushViewController(SQLiteTableViewController(database: database, tableName: tables[indexPath.row]), animated: true)
    }

    @objc private func showSQLPrompt() {
        let alert = UIAlertController(title: "SQL", message: "执行任意 SQLite SQL。", preferredStyle: .alert)
        alert.addTextField { field in
            field.placeholder = "SELECT * FROM ..."
            field.autocapitalizationType = .none
            field.autocorrectionType = .no
            field.returnKeyType = .done
        }
        alert.addAction(.cancel())
        alert.addAction(UIAlertAction(title: "执行", style: .default) { [weak self, weak alert] _ in
            guard let self, let sql = alert?.textFields?.first?.text, !sql.isEmpty, let database = self.database else { return }
            DispatchQueue.global(qos: .userInitiated).async {
                do {
                    let result = try database.query(sql)
                    DispatchQueue.main.async {
                        self.navigationController?.pushViewController(SQLiteResultViewController(title: "SQL", columns: result.columns, rows: result.rows), animated: true)
                    }
                } catch {
                    DispatchQueue.main.async { self.errorAlert(error, title: "SQL 执行失败") }
                }
            }
        })
        present(alert, animated: true)
    }
}

private final class SantanderSQLiteRowCell: UICollectionViewCell, UIScrollViewDelegate {
    private let horizontalScrollView = UIScrollView()
    private let columnsStack = UIStackView()
    private var applyingOffset = false
    var onHorizontalOffsetChange: ((CGFloat) -> Void)?

    override init(frame: CGRect) {
        super.init(frame: frame)
        contentView.backgroundColor = .systemBackground
        horizontalScrollView.translatesAutoresizingMaskIntoConstraints = false
        horizontalScrollView.showsHorizontalScrollIndicator = false
        horizontalScrollView.delegate = self
        columnsStack.axis = .horizontal
        columnsStack.alignment = .fill
        columnsStack.spacing = 0
        columnsStack.translatesAutoresizingMaskIntoConstraints = false
        horizontalScrollView.addSubview(columnsStack)
        contentView.addSubview(horizontalScrollView)
        NSLayoutConstraint.activate([
            horizontalScrollView.leadingAnchor.constraint(equalTo: contentView.leadingAnchor),
            horizontalScrollView.trailingAnchor.constraint(equalTo: contentView.trailingAnchor),
            horizontalScrollView.topAnchor.constraint(equalTo: contentView.topAnchor),
            horizontalScrollView.bottomAnchor.constraint(equalTo: contentView.bottomAnchor),
            columnsStack.leadingAnchor.constraint(equalTo: horizontalScrollView.contentLayoutGuide.leadingAnchor),
            columnsStack.trailingAnchor.constraint(equalTo: horizontalScrollView.contentLayoutGuide.trailingAnchor),
            columnsStack.topAnchor.constraint(equalTo: horizontalScrollView.contentLayoutGuide.topAnchor),
            columnsStack.bottomAnchor.constraint(equalTo: horizontalScrollView.contentLayoutGuide.bottomAnchor),
            columnsStack.heightAnchor.constraint(equalTo: horizontalScrollView.frameLayoutGuide.heightAnchor)
        ])
    }

    required init?(coder: NSCoder) { fatalError() }

    override func prepareForReuse() {
        super.prepareForReuse()
        columnsStack.arrangedSubviews.forEach { view in
            columnsStack.removeArrangedSubview(view)
            view.removeFromSuperview()
        }
        onHorizontalOffsetChange = nil
        applyingOffset = false
    }

    func configure(values: [String], isHeader: Bool, offset: CGFloat) {
        columnsStack.arrangedSubviews.forEach { view in
            columnsStack.removeArrangedSubview(view)
            view.removeFromSuperview()
        }
        for (index, value) in values.enumerated() {
            let label = UILabel()
            label.text = value
            label.font = .monospacedSystemFont(ofSize: 12, weight: isHeader ? .bold : .regular)
            label.textColor = isHeader ? .secondaryLabel : .label
            label.backgroundColor = isHeader ? .secondarySystemBackground : .systemBackground
            label.numberOfLines = 2
            label.lineBreakMode = .byTruncatingMiddle
            label.adjustsFontSizeToFitWidth = false
            label.translatesAutoresizingMaskIntoConstraints = false
            label.widthAnchor.constraint(equalToConstant: 156).isActive = true
            label.layoutMargins = UIEdgeInsets(top: 7, left: 8, bottom: 7, right: 8)
            label.setContentHuggingPriority(.required, for: .horizontal)
            let container = UIView()
            container.translatesAutoresizingMaskIntoConstraints = false
            container.addSubview(label)
            NSLayoutConstraint.activate([
                label.leadingAnchor.constraint(equalTo: container.leadingAnchor, constant: 8),
                label.trailingAnchor.constraint(equalTo: container.trailingAnchor, constant: -8),
                label.topAnchor.constraint(equalTo: container.topAnchor, constant: 5),
                label.bottomAnchor.constraint(equalTo: container.bottomAnchor, constant: -5),
                container.widthAnchor.constraint(equalToConstant: 172)
            ])
            columnsStack.addArrangedSubview(container)
            if index < values.count - 1 {
                let separator = UIView()
                separator.backgroundColor = .separator
                separator.widthAnchor.constraint(equalToConstant: 1).isActive = true
                columnsStack.addArrangedSubview(separator)
            }
        }
        applyingOffset = true
        horizontalScrollView.setContentOffset(CGPoint(x: offset, y: 0), animated: false)
        applyingOffset = false
        accessibilityLabel = values.joined(separator: ", ")
        accessibilityHint = isHeader ? "数据库列名" : "轻点编辑此行的单元格"
        backgroundColor = isHeader ? .secondarySystemBackground : .systemBackground
    }

    func setHorizontalOffset(_ offset: CGFloat) {
        applyingOffset = true
        horizontalScrollView.setContentOffset(CGPoint(x: offset, y: 0), animated: false)
        applyingOffset = false
    }

    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        guard !applyingOffset else { return }
        onHorizontalOffsetChange?(scrollView.contentOffset.x)
    }
}

private final class SQLiteTableViewController: UIViewController, UICollectionViewDataSource, UICollectionViewDelegate {
    private let database: SantanderSQLiteDatabase
    private let fileURL: URL
    private let tableName: String
    private let pageSize = 200
    private var columns: [String] = []
    private var rows: [[SantanderSQLiteValue]] = []
    private var hasRowID = false
    private var hasMoreRows = true
    private var isLoadingPage = false
    private var queryGeneration = UUID()
    private var collectionView: UICollectionView!
    private var horizontalOffset: CGFloat = 0

    init(database: SantanderSQLiteDatabase, tableName: String) {
        self.database = database
        self.tableName = tableName
        self.fileURL = database.fileURL
        super.init(nibName: nil, bundle: nil)
        title = tableName
    }

    required init?(coder: NSCoder) { fatalError() }

    override func viewDidLoad() {
        super.viewDidLoad()
        applySantanderUI()
        view.backgroundColor = .systemBackground
        let layout = UICollectionViewCompositionalLayout { _, _ in
            let itemSize = NSCollectionLayoutSize(widthDimension: .fractionalWidth(1), heightDimension: .estimated(54))
            let item = NSCollectionLayoutItem(layoutSize: itemSize)
            let group = NSCollectionLayoutGroup.vertical(layoutSize: itemSize, subitems: [item])
            let section = NSCollectionLayoutSection(group: group)
            section.interGroupSpacing = 0.5
            return section
        }
        collectionView = UICollectionView(frame: .zero, collectionViewLayout: layout)
        collectionView.translatesAutoresizingMaskIntoConstraints = false
        collectionView.backgroundColor = .systemBackground
        collectionView.dataSource = self
        collectionView.delegate = self
        collectionView.register(SantanderSQLiteRowCell.self, forCellWithReuseIdentifier: "SantanderSQLiteRowCell")
        view.addSubview(collectionView)
        NSLayoutConstraint.activate([
            collectionView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            collectionView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            collectionView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
            collectionView.bottomAnchor.constraint(equalTo: view.bottomAnchor)
        ])
        navigationItem.rightBarButtonItems = [
            UIBarButtonItem(title: SantanderL10n.t("Table Structure"), image: SantanderIconLibrary.shared.interfaceIcon(for: "list.bullet.rectangle"), primaryAction: UIAction { [weak self] _ in self?.showTableStructure() }),
            UIBarButtonItem(systemItem: .refresh, primaryAction: UIAction { [weak self] _ in self?.reloadQuery() })
        ]
        reloadQuery()
    }

    private func reloadQuery() {
        queryGeneration = UUID()
        columns = []
        rows = []
        hasRowID = false
        hasMoreRows = true
        isLoadingPage = false
        horizontalOffset = 0
        collectionView.reloadData()
        loadNextPage()
    }

    private func loadNextPage() {
        guard !isLoadingPage, hasMoreRows, isViewLoaded else { return }
        isLoadingPage = true
        let generation = queryGeneration
        let offset = rows.count
        let knownRowIDSupport = hasRowID
        let quoted = "\"\(tableName.replacingOccurrences(of: "\"", with: "\"\""))\""
        let pageSize = self.pageSize
        DispatchQueue.global(qos: .userInitiated).async { [weak self] in
            guard let self else { return }
            do {
                let result: (columns: [String], rows: [[SantanderSQLiteValue]], hasRowID: Bool)
                if offset == 0 || knownRowIDSupport {
                    do {
                        let page = try self.database.query("SELECT rowid, * FROM \(quoted) LIMIT \(pageSize + 1) OFFSET \(offset)")
                        result = (page.columns, page.rows, true)
                    } catch {
                        guard offset == 0 else { throw error }
                        let page = try self.database.query("SELECT * FROM \(quoted) LIMIT \(pageSize + 1)")
                        result = (page.columns, page.rows, false)
                    }
                } else {
                    let page = try self.database.query("SELECT * FROM \(quoted) LIMIT \(pageSize + 1) OFFSET \(offset)")
                    result = (page.columns, page.rows, false)
                }
                let hasMore = result.rows.count > pageSize
                let pageRows = Array(result.rows.prefix(pageSize))
                DispatchQueue.main.async {
                    guard self.queryGeneration == generation else { return }
                    let oldCount = self.rows.count
                    if offset == 0 { self.columns = result.columns }
                    self.hasRowID = result.hasRowID
                    self.hasMoreRows = hasMore
                    self.rows.append(contentsOf: pageRows)
                    self.isLoadingPage = false
                    if offset == 0 {
                        self.collectionView.reloadData()
                    } else if !pageRows.isEmpty {
                        let paths = (oldCount + 1...oldCount + pageRows.count).map { IndexPath(item: $0, section: 0) }
                        self.collectionView.performBatchUpdates { self.collectionView.insertItems(at: paths) }
                    }
                }
            } catch {
                DispatchQueue.main.async {
                    guard self.queryGeneration == generation else { return }
                    self.isLoadingPage = false
                    self.hasMoreRows = false
                    self.errorAlert(error, title: "SQLite")
                }
            }
        }
    }

    private func showTableStructure() {
        let escapedName = tableName.replacingOccurrences(of: "'", with: "''")
        DispatchQueue.global(qos: .userInitiated).async { [weak self] in
            guard let self else { return }
            do {
                let result = try self.database.query("PRAGMA table_info('\(escapedName)')")
                DispatchQueue.main.async {
                    self.navigationController?.pushViewController(SQLiteResultViewController(title: "\(self.tableName) · \(SantanderL10n.t("Table Structure"))", columns: result.columns, rows: result.rows), animated: true)
                }
            } catch {
                DispatchQueue.main.async { self.errorAlert(error, title: SantanderL10n.t("Unable to read table structure")) }
            }
        }
    }

    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        rows.count + (columns.isEmpty ? 0 : 1)
    }

    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "SantanderSQLiteRowCell", for: indexPath) as! SantanderSQLiteRowCell
        let values: [String]
        if indexPath.item == 0 {
            values = columns
        } else {
            values = rows[indexPath.item - 1].map(\.display)
        }
        cell.configure(values: values, isHeader: indexPath.item == 0, offset: horizontalOffset)
        cell.onHorizontalOffsetChange = { [weak self, weak cell] offset in
            guard let self else { return }
            self.horizontalOffset = offset
            for visible in self.collectionView.visibleCells {
                guard let row = visible as? SantanderSQLiteRowCell, row !== cell else { continue }
                row.setHorizontalOffset(offset)
            }
        }
        return cell
    }

    func collectionView(_ collectionView: UICollectionView, willDisplay cell: UICollectionViewCell, forItemAt indexPath: IndexPath) {
        if hasMoreRows && !isLoadingPage && indexPath.item >= max(0, rows.count - 20) {
            loadNextPage()
        }
    }

    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        collectionView.deselectItem(at: indexPath, animated: true)
        guard hasRowID, indexPath.item > 0, indexPath.item - 1 < rows.count, !columns.isEmpty else { return }
        let row = rows[indexPath.item - 1]
        let rowID: Int64?
        if case .integer(let value) = row.first { rowID = value } else { rowID = nil }
        guard let rowID else { return }
        presentColumnPicker(row: row, rowID: rowID)
    }

    private func presentColumnPicker(row: [SantanderSQLiteValue], rowID: Int64) {
        let actions = (1..<min(columns.count, row.count)).map { index in
            SantanderActionSheetItem(title: columns[index], image: SantanderIconLibrary.shared.interfaceIcon(for: "square.grid.2x2")) { [weak self] in
                self?.editCell(columnIndex: index, row: row, rowID: rowID)
            }
        }
        presentSantanderActionSheet(title: "修改单元格", actions: actions + [SantanderActionSheetItem(title: SantanderL10n.t("Cancel"), style: .cancel)])
    }

    private func editCell(columnIndex: Int, row: [SantanderSQLiteValue], rowID: Int64) {
        let old = row[columnIndex]
        let alert = UIAlertController(title: columns[columnIndex], message: nil, preferredStyle: .alert)
        alert.addTextField { field in
            field.text = old.display
            field.font = .monospacedSystemFont(ofSize: 14, weight: .regular)
            field.autocapitalizationType = .none
            field.autocorrectionType = .no
        }
        alert.addAction(.cancel())
        alert.addAction(UIAlertAction(title: SantanderL10n.t("Save"), style: .default) { [weak self, weak alert] _ in
            guard let self, let text = alert?.textFields?.first?.text else { return }
            let newValue: SantanderSQLiteValue
            switch old {
            case .null: newValue = text.uppercased() == "NULL" ? .null : .text(text)
            case .integer: newValue = Int64(text).map(SantanderSQLiteValue.integer) ?? old
            case .real: newValue = Double(text).map(SantanderSQLiteValue.real) ?? old
            case .blob:
                let compact = text.replacingOccurrences(of: " ", with: "")
                var data = Data()
                var valid = compact.count % 2 == 0
                if valid {
                    for i in stride(from: 0, to: compact.count, by: 2) {
                        let start = compact.index(compact.startIndex, offsetBy: i)
                        let end = compact.index(start, offsetBy: 2)
                        guard let byte = UInt8(compact[start..<end], radix: 16) else { valid = false; break }
                        data.append(byte)
                    }
                }
                newValue = valid ? .blob(data) : old
            case .text: newValue = .text(text)
            }
            guard self.columns.indices.contains(columnIndex) else { return }
            let identifier = "\"\(self.columns[columnIndex].replacingOccurrences(of: "\"", with: "\"\""))\""
            let table = "\"\(self.tableName.replacingOccurrences(of: "\"", with: "\"\""))\""
            let sql = "UPDATE \(table) SET \(identifier) = \(newValue.sqlLiteral) WHERE rowid = \(rowID)"
            DispatchQueue.global(qos: .userInitiated).async {
                do {
                    try ensureFileContentIsUnlocked(self.fileURL)
                    try self.database.execute(sql)
                    DispatchQueue.main.async { self.reloadQuery() }
                } catch { DispatchQueue.main.async { self.errorAlert(error, title: "SQLite") } }
            }
        })
        present(alert, animated: true)
    }
}

private final class SQLiteResultViewController: UITableViewController {
    private let columns: [String]
    private let rows: [[SantanderSQLiteValue]]

    init(title: String, columns: [String], rows: [[SantanderSQLiteValue]]) {
        self.columns = columns; self.rows = rows
        super.init(style: .plain)
        self.title = title
    }
    required init?(coder: NSCoder) { fatalError() }
    override func viewDidLoad() { super.viewDidLoad(); applySantanderUI(); tableView.separatorStyle = .singleLine }
    override func numberOfSections(in tableView: UITableView) -> Int { 1 }
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int { rows.count + 1 }
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = UITableViewCell(style: .default, reuseIdentifier: nil); SantanderUI.styleCell(cell)
        let values = indexPath.row == 0 ? columns.map { SantanderSQLiteValue.text($0) } : rows[indexPath.row - 1]
        cell.textLabel?.font = .monospacedSystemFont(ofSize: 12, weight: indexPath.row == 0 ? .bold : .regular)
        cell.textLabel?.text = values.map(\.display).joined(separator: "    ")
        cell.textLabel?.numberOfLines = 0
        return cell
    }
}

private final class ArchiveBrowserViewController: UITableViewController {
    private let archiveURL: URL
    private let prefix: String
    private var entries: [String] = []
    private var loading = false

    init(archiveURL: URL, prefix: String = "") {
        self.archiveURL = archiveURL
        self.prefix = prefix
        super.init(style: .insetGrouped)
        title = prefix.isEmpty ? archiveURL.lastPathComponent : URL(fileURLWithPath: prefix).lastPathComponent
    }

    required init?(coder: NSCoder) { fatalError() }

    override func viewDidLoad() {
        super.viewDidLoad()
        applySantanderUI()
        tableView.rowHeight = 52
        loadEntries()
    }

    private func loadEntries() {
        guard !loading else { return }
        loading = true
        let url = archiveURL
        let basePrefix = prefix
        DispatchQueue.global(qos: .utility).async { [weak self] in
            guard let self else { return }
            do {
                let all = try SantanderArchiveBackend.list(url)
                let trimmedPrefix = basePrefix.trimmingCharacters(in: CharacterSet(charactersIn: "/"))
                let prefixWithSlash = trimmedPrefix.isEmpty ? "" : trimmedPrefix + "/"
                var set = Set<String>()
                for raw in all {
                    let item = raw.trimmingCharacters(in: .whitespacesAndNewlines)
                    let normalized = item.trimmingCharacters(in: CharacterSet(charactersIn: "/"))
                    guard normalized.hasPrefix(prefixWithSlash) || prefixWithSlash.isEmpty else { continue }
                    let remaining = String(normalized.dropFirst(prefixWithSlash.count))
                    guard !remaining.isEmpty else { continue }
                    let first = remaining.split(separator: "/", maxSplits: 1, omittingEmptySubsequences: true).first.map(String.init) ?? remaining
                    let isDirectory = remaining.contains("/") || item.hasSuffix("/")
                    let entry = prefixWithSlash + first + (isDirectory ? "/" : "")
                    set.insert(entry)
                }
                let list = set.sorted { lhs, rhs in
                    let lDir = lhs.hasSuffix("/")
                    let rDir = rhs.hasSuffix("/")
                    if lDir != rDir { return lDir && !rDir }
                    return lhs.localizedStandardCompare(rhs) == .orderedAscending
                }
                DispatchQueue.main.async {
                    self.loading = false
                    self.entries = list
                    self.tableView.reloadData()
                    self.tableView.backgroundView = list.isEmpty ? self.makeEmptyView() : nil
                }
            } catch {
                DispatchQueue.main.async {
                    self.loading = false
                    self.errorAlert(error, title: SantanderL10n.t("Unable to extract items"))
                }
            }
        }
    }

    private func makeEmptyView() -> UIView {
        let label = UILabel()
        label.text = SantanderL10n.t("Archive is empty")
        label.textColor = .secondaryLabel
        label.textAlignment = .center
        label.font = .preferredFont(forTextStyle: .body)
        label.numberOfLines = 0
        label.accessibilityHint = SantanderL10n.t("Archive is empty")
        return label
    }

    override func numberOfSections(in tableView: UITableView) -> Int { 1 }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        entries.count
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = UITableViewCell(style: .subtitle, reuseIdentifier: nil)
        SantanderUI.styleCell(cell)
        let entry = entries[indexPath.row]
        let directory = entry.hasSuffix("/")
        let archiveEntryPath = Path(url: archiveURL.appendingPathComponent(entry.trimmingCharacters(in: CharacterSet(charactersIn: "/"))))
        cell.imageView?.image = directory
            ? SantanderIconLibrary.shared.folderIcon()
            : SantanderIconLibrary.shared.fileIcon(for: archiveEntryPath)
        let display = URL(fileURLWithPath: entry).lastPathComponent
        cell.textLabel?.text = display
        cell.textLabel?.adjustsFontForContentSizeCategory = true
        cell.detailTextLabel?.text = directory ? SantanderL10n.t("Directory") : entry
        cell.detailTextLabel?.numberOfLines = 0
        cell.accessoryType = directory ? .disclosureIndicator : .none
        return cell
    }

    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        let entry = entries[indexPath.row]
        if entry.hasSuffix("/") {
            navigationController?.pushViewController(
                ArchiveBrowserViewController(archiveURL: archiveURL, prefix: entry),
                animated: false
            )
        } else {
            extractAndOpen(entry)
        }
    }

    private func openNativePreview(forPath path: Path) {
        present(UINavigationController(rootViewController: SantanderFilePreviewController(fileURL: path.url)), animated: true)
    }

    private func extractAndOpen(_ entry: String) {
        let cleanEntry = entry.trimmingCharacters(in: CharacterSet(charactersIn: "/"))
        let baseName = URL(fileURLWithPath: cleanEntry).lastPathComponent
        let tempDirectory = URL(fileURLWithPath: NSTemporaryDirectory())
            .appendingPathComponent("SantanderArchive", isDirectory: true)
            .appendingPathComponent(UUID().uuidString, isDirectory: true)
        let outputURL = tempDirectory.appendingPathComponent(baseName)
        DispatchQueue.global(qos: .userInitiated).async { [weak self] in
            guard let self else { return }
            do {
                try FileManager.default.createDirectory(at: tempDirectory, withIntermediateDirectories: true)
                if self.archiveURL.pathExtension.lowercased() == "7z" {
                    try SantanderSevenZipArchive.extractToURL(self.archiveURL, entry: cleanEntry, destination: outputURL)
                } else {
                    let data = try SantanderArchiveBackend.extract(self.archiveURL, entry: cleanEntry)
                    try data.write(to: outputURL, options: .atomic)
                }
                DispatchQueue.main.async {
                    let path = Path(url: outputURL)
                    FileEditor.preferredAsync(forURL: path) { [weak self] editor in
                        guard let self else { return }
                        guard let editor else {
                            self.openNativePreview(forPath: path)
                            return
                        }
                        editor.display(senderVC: self)
                    }
                }
            } catch {
                DispatchQueue.main.async {
                    self.errorAlert(error, title: SantanderL10n.t("Unable to extract items"))
                }
            }
        }
    }
}


private final class SantanderPTYSession {
    private(set) var masterFD: Int32 = -1
    private(set) var pid: pid_t = 0
    private var source: DispatchSourceRead?
    private let queue = DispatchQueue(label: "org.santander.pty", qos: .userInitiated)
    var onOutput: ((Data) -> Void)?
    var onExit: ((Int32) -> Void)?

    @discardableResult
    func start(shell: String, workingDirectory: String) throws -> Bool {
        guard masterFD < 0 else { return true }
        masterFD = posix_openpt(O_RDWR | O_NOCTTY | O_CLOEXEC)
        guard masterFD >= 0 else { throw StringError(String(cString: strerror(errno))) }
        guard grantpt(masterFD) == 0, unlockpt(masterFD) == 0, let slaveName = ptsname(masterFD) else {
            _ = close(masterFD); masterFD = -1
            throw StringError("无法创建伪终端。")
        }
        let slaveFD = open(slaveName, O_RDWR | O_NOCTTY | O_CLOEXEC)
        guard slaveFD >= 0 else { _ = close(masterFD); masterFD = -1; throw StringError("无法打开伪终端从端。") }

        var actions: posix_spawn_file_actions_t?
        guard posix_spawn_file_actions_init(&actions) == 0 else {
            _ = close(slaveFD); _ = close(masterFD); masterFD = -1
            throw StringError("无法初始化终端进程操作。")
        }
        defer { _ = posix_spawn_file_actions_destroy(&actions) }
        _ = posix_spawn_file_actions_adddup2(&actions, slaveFD, STDIN_FILENO)
        _ = posix_spawn_file_actions_adddup2(&actions, slaveFD, STDOUT_FILENO)
        _ = posix_spawn_file_actions_adddup2(&actions, slaveFD, STDERR_FILENO)
        _ = posix_spawn_file_actions_addclose(&actions, masterFD)
        _ = posix_spawn_file_actions_addclose(&actions, slaveFD)

        var attr: posix_spawnattr_t?
        guard posix_spawnattr_init(&attr) == 0 else {
            _ = close(slaveFD); _ = close(masterFD); masterFD = -1
            throw StringError("无法初始化终端属性。")
        }
        defer { _ = posix_spawnattr_destroy(&attr) }
        var rootPersonaEnabled = false
        var rootPersonaFailure: String?
        if UserPreferences.rootHelperIsEnabled {
            do {
                try TrollStoreRootPersona.configure(&attr)
                rootPersonaEnabled = true
            } catch {
                rootPersonaFailure = error.localizedDescription
            }
        } else {
            rootPersonaFailure = "SantanderHelper 已在设置中关闭。"
        }

        let safeDirectory = workingDirectory.replacingOccurrences(of: "'", with: "'\"'\"")
        let safeShell = shell.replacingOccurrences(of: "'", with: "'\"'\"")
        let pathSetup = "export PATH=/var/jb/usr/local/sbin:/var/jb/usr/local/bin:/var/jb/usr/bin:/var/jb/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin:$PATH; "
        let warning = rootPersonaFailure.map { failure in
            let safeFailure = String(failure.prefix(180)).replacingOccurrences(of: "'", with: "'\"'\"")
            return "printf '\\r\\n[普通用户终端] \(safeFailure)\\r\\n'; "
        } ?? ""
        let rootNotice = "if [ \"$(id -u 2>/dev/null)\" != \"0\" ]; then printf '\\r\\n[Root persona 未生效，当前为普通用户权限]\\r\\n'; else export HOME=/var/root USER=root LOGNAME=root; fi; "
        let shellCommand = pathSetup + warning + rootNotice + "cd '\(safeDirectory)' 2>/dev/null || true; exec '\(safeShell)' -l"
        var argv: [UnsafeMutablePointer<CChar>?] = [strdup("/bin/sh"), strdup("-lc"), strdup(shellCommand), nil]
        defer { for pointer in argv.compactMap({ $0 }) { free(pointer) } }
        var pid: pid_t = 0
        var result = argv.withUnsafeMutableBufferPointer { buffer in
            posix_spawn(&pid, "/bin/sh", &actions, &attr, buffer.baseAddress, environ)
        }
        // iOS 17.6+/18+ may reject the TrollStore persona at spawn time. Keep
        // the terminal usable as the app user rather than failing to open it.
        if result != 0 && rootPersonaEnabled {
            rootPersonaEnabled = false
            var fallbackAttr: posix_spawnattr_t?
            if posix_spawnattr_init(&fallbackAttr) == 0 {
                result = argv.withUnsafeMutableBufferPointer { buffer in
                    posix_spawn(&pid, "/bin/sh", &actions, &fallbackAttr, buffer.baseAddress, environ)
                }
                _ = posix_spawnattr_destroy(&fallbackAttr)
            }
        }
        _ = close(slaveFD)
        guard result == 0 else {
            _ = close(masterFD); masterFD = -1
            throw StringError(String(cString: strerror(result)))
        }
        self.pid = pid

        let source = DispatchSource.makeReadSource(fileDescriptor: masterFD, queue: queue)
        source.setEventHandler { [weak self] in
            guard let self else { return }
            let buffer = UnsafeMutablePointer<UInt8>.allocate(capacity: 16 * 1024)
            defer { buffer.deallocate() }
            let count = read(self.masterFD, buffer, 16 * 1024)
            if count > 0 {
                self.onOutput?(Data(bytes: buffer, count: count))
            } else if count == 0 || (count < 0 && errno != EINTR && errno != EAGAIN) {
                self.stopSource()
            }
        }
        source.setCancelHandler { [weak self] in
            if let fd = self?.masterFD, fd >= 0 { _ = close(fd) }
        }
        self.source = source
        source.resume()
        queue.async { [weak self] in
            guard let self else { return }
            var status: Int32 = 0
            _ = waitpid(pid, &status, 0)
            DispatchQueue.main.async { self.onExit?(status) }
        }
        return rootPersonaEnabled
    }

    func send(_ data: Data) {
        guard masterFD >= 0 else { return }
        data.withUnsafeBytes { raw in
            guard let base = raw.baseAddress, raw.count > 0 else { return }
            _ = write(masterFD, base, raw.count)
        }
    }

    func interrupt() { guard pid > 0 else { return }; _ = kill(pid, SIGINT) }
    func setWindowSize(cols: Int, rows: Int) {
        guard masterFD >= 0, cols > 0, rows > 0 else { return }
        var size = winsize(ws_row: UInt16(rows), ws_col: UInt16(cols), ws_xpixel: 0, ws_ypixel: 0)
        _ = ioctl(masterFD, TIOCSWINSZ, &size)
    }

    func terminate() { guard pid > 0 else { return }; _ = kill(pid, SIGTERM) }

    private func stopSource() {
        source?.cancel(); source = nil; masterFD = -1
    }
}

private final class TerminalViewController: UIViewController, SwiftTerm.TerminalViewDelegate {
    private let workingDirectory: String
    private let initialCommand: String?
    private let pty = SantanderPTYSession()
    private var terminalView: SwiftTerm.TerminalView!
    private var shellPath = "/bin/sh"

    init(workingDirectory: URL = URL(fileURLWithPath: NSHomeDirectory()), initialCommand: String? = nil) {
        self.workingDirectory = workingDirectory.path
        self.initialCommand = initialCommand
        super.init(nibName: nil, bundle: nil)
        title = SantanderL10n.t("Terminal")
    }

    required init?(coder: NSCoder) { fatalError() }

    override func viewDidLoad() {
        super.viewDidLoad()
        applySantanderUI()
        view.backgroundColor = .black

        terminalView = SwiftTerm.TerminalView(frame: .zero)
        terminalView.translatesAutoresizingMaskIntoConstraints = false
        terminalView.backgroundColor = .black
        terminalView.font = .monospacedSystemFont(ofSize: 13, weight: .regular)
        terminalView.isScrollEnabled = true
        terminalView.terminalDelegate = self
        view.addSubview(terminalView)
        NSLayoutConstraint.activate([
            terminalView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            terminalView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            terminalView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
            terminalView.bottomAnchor.constraint(equalTo: view.bottomAnchor)
        ])

        let shell = ["/var/jb/usr/bin/zsh", "/var/jb/bin/zsh", "/bin/zsh", "/bin/sh"].first { FileManager.default.isExecutableFile(atPath: $0) } ?? "/bin/sh"
        shellPath = shell
        pty.onOutput = { [weak self] data in
            guard let self else { return }
            DispatchQueue.main.async {
                let bytes = Array(data)
                self.terminalView.feed(byteArray: bytes[...])
            }
        }
        do {
            let requestedRoot = try pty.start(shell: shell, workingDirectory: workingDirectory)
            navigationItem.prompt = requestedRoot ? "Root persona 已请求（终端会显示实际 UID）" : "普通用户 Shell"
            if let initialCommand, !initialCommand.isEmpty { sendCommand(initialCommand) }
        } catch {
            errorAlert(error, title: SantanderL10n.t("无法打开 Terminal"))
        }
        _ = terminalView.becomeFirstResponder()
    }

    deinit { pty.terminate() }

    override var keyCommands: [UIKeyCommand]? {
        [
            UIKeyCommand(title: "清屏", action: #selector(clearScreen), input: "k", modifierFlags: .command),
            UIKeyCommand(title: "重启会话", action: #selector(restartSession), input: "r", modifierFlags: .command)
        ]
    }

    @objc private func clearScreen() {
        let sequence = Array("\u{001B}[2J\u{001B}[H".utf8)
        terminalView.feed(byteArray: sequence[...])
    }

    @objc private func restartSession() {
        sendCommand("exec \(shellPath)")
    }

    func scrolled(source: SwiftTerm.TerminalView, position: Double) { }
    func setTerminalTitle(source: SwiftTerm.TerminalView, title: String) { self.title = title }
    func sizeChanged(source: SwiftTerm.TerminalView, newCols: Int, newRows: Int) {
        pty.setWindowSize(cols: newCols, rows: newRows)
    }
    func send(source: SwiftTerm.TerminalView, data: ArraySlice<UInt8>) {
        pty.send(Data(data))
    }
    func clipboardCopy(source: SwiftTerm.TerminalView, content: Data) {
        UIPasteboard.general.string = String(data: content, encoding: .utf8)
    }
    func hostCurrentDirectoryUpdate(source: SwiftTerm.TerminalView, directory: String?) { }
    func requestOpenLink(source: SwiftTerm.TerminalView, link: String, params: [String: String]) {
        if let url = URL(string: link) { UIApplication.shared.open(url) }
    }
    func rangeChanged(source: SwiftTerm.TerminalView, startY: Int, endY: Int) { }

    private func sendCommand(_ command: String) {
        let normalized = command.trimmingCharacters(in: .newlines)
        pty.send(Data((normalized + "\n").utf8))
    }
}



private enum SantanderPathTag: String, CaseIterable {
    case red, orange, yellow, green, blue, purple, gray
    var title: String {
        switch self { case .red: return "红色"; case .orange: return "橙色"; case .yellow: return "黄色"; case .green: return "绿色"; case .blue: return "蓝色"; case .purple: return "紫色"; case .gray: return "灰色" }
    }
    var symbol: String { "circle.fill" }
    var color: UIColor {
        switch self { case .red: return .systemRed; case .orange: return .systemOrange; case .yellow: return .systemYellow; case .green: return .systemGreen; case .blue: return SantanderAppTheme.accentColor; case .purple: return .systemPurple; case .gray: return .systemGray }
    }
}

private enum SantanderPathTagStore {
    private static let key = "SantanderPathColorTags"
    private static var values: [String: String] {
        get { (UserDefaults.standard.dictionary(forKey: key) as? [String: String]) ?? [:] }
        set { UserDefaults.standard.set(newValue, forKey: key) }
    }
    static func tag(for url: URL) -> SantanderPathTag? { values[url.standardizedFileURL.path].flatMap(SantanderPathTag.init(rawValue:)) }
    static func set(tag: SantanderPathTag, for url: URL) { var v = values; v[url.standardizedFileURL.path] = tag.rawValue; values = v }
    static func clear(for url: URL) { var v = values; v.removeValue(forKey: url.standardizedFileURL.path); values = v }
}

private enum SantanderPathTagRenderer {
    static func image(base: UIImage, tag: SantanderPathTag?) -> UIImage {
        guard let tag else { return base }
        let size = CGSize(width: max(32, base.size.width), height: max(32, base.size.height))
        let rendererFormat = UIGraphicsImageRendererFormat.default()
        rendererFormat.scale = base.scale
        return UIGraphicsImageRenderer(size: size, format: rendererFormat).image { ctx in
            base.draw(in: CGRect(origin: .zero, size: size))
            let r: CGFloat = 8
            let rect = CGRect(x: size.width-r-1, y: 1, width: r, height: r)
            tag.color.setFill(); UIBezierPath(ovalIn: rect).fill()
            UIColor.white.withAlphaComponent(0.85).setStroke(); let p = UIBezierPath(ovalIn: rect.insetBy(dx: 0.5, dy: 0.5)); p.lineWidth = 0.7; p.stroke()
        }
    }
}

private enum SantanderPathHistory {
    private static let key = "SantanderRecentPaths"
    static var paths: [Path] {
        let arr = UserDefaults.standard.stringArray(forKey: key) ?? []
        return arr.compactMap { raw in
            let url = URL(fileURLWithPath: raw)
            return url.isDirectory ? Path(url: url) : nil
        }
    }
    static func add(_ path: Path) {
        guard path.isDirectory else { return }
        let normalized = path.url.standardizedFileURL.path
        var items = UserDefaults.standard.stringArray(forKey: key) ?? []
        items.removeAll { $0 == normalized }
        items.insert(normalized, at: 0)
        if items.count > 20 { items.removeLast(items.count - 20) }
        UserDefaults.standard.set(items, forKey: key)
    }
}

private enum SantanderSevenZipArchive {
    private typealias NewFn = @convention(c) () -> OpaquePointer?
    private typealias ConfigureFn = @convention(c) (OpaquePointer?) -> Int32
    private typealias OpenFilenameFn = @convention(c) (OpaquePointer?, UnsafePointer<CChar>?, Int) -> Int32
    private typealias NextHeaderFn = @convention(c) (OpaquePointer?, UnsafeMutablePointer<OpaquePointer?>?) -> Int32
    private typealias ReadDataFn = @convention(c) (OpaquePointer?, UnsafeMutableRawPointer?, Int) -> Int64
    private typealias DataSkipFn = @convention(c) (OpaquePointer?) -> Int32
    private typealias FreeFn = @convention(c) (OpaquePointer?) -> Int32
    private typealias ErrorStringFn = @convention(c) (OpaquePointer?) -> UnsafePointer<CChar>?
    private typealias EntryNameFn = @convention(c) (OpaquePointer?) -> UnsafePointer<CChar>?
    private typealias EntrySizeFn = @convention(c) (OpaquePointer?) -> Int64
    private typealias EntryFileTypeFn = @convention(c) (OpaquePointer?) -> Int32

    private struct API {
        let readNew: NewFn
        let supportFormat7Zip: ConfigureFn
        let supportFilterAll: ConfigureFn
        let openFilename: OpenFilenameFn
        let nextHeader: NextHeaderFn
        let readData: ReadDataFn
        let readDataSkip: DataSkipFn
        let readFree: FreeFn
        let errorString: ErrorStringFn
        let entryPathname: EntryNameFn
        let entryPathnameUTF8: EntryNameFn
        let entrySize: EntrySizeFn
        let entryFileType: EntryFileTypeFn
    }

    private static let handle: UnsafeMutableRawPointer? = {
        let paths = [
            "/var/jb/usr/lib/libarchive.dylib",
            "/var/jb/usr/lib/libarchive.19.dylib",
            "/var/jb/usr/lib/libarchive.18.dylib",
            "/var/jb/usr/lib/libarchive.17.dylib",
            "/var/jb/usr/lib/libarchive.16.dylib",
            "/var/jb/usr/lib/libarchive.15.dylib",
            "/usr/lib/libarchive.dylib",
            "/usr/lib/libarchive.19.dylib",
            "/usr/lib/libarchive.18.dylib"
        ]
        for path in paths {
            if let handle = dlopen(path, RTLD_NOW | RTLD_LOCAL) { return handle }
        }
        return nil
    }()

    private static func symbol(_ name: String) -> UnsafeMutableRawPointer? {
        guard let handle else { return nil }
        return name.withCString { dlsym(handle, $0) }
    }

    private static let api: API? = {
        guard
            let newPointer = symbol("archive_read_new"),
            let formatPointer = symbol("archive_read_support_format_7zip"),
            let filterPointer = symbol("archive_read_support_filter_all"),
            let openPointer = symbol("archive_read_open_filename"),
            let nextPointer = symbol("archive_read_next_header"),
            let readPointer = symbol("archive_read_data"),
            let skipPointer = symbol("archive_read_data_skip"),
            let freePointer = symbol("archive_read_free"),
            let errorPointer = symbol("archive_error_string"),
            let namePointer = symbol("archive_entry_pathname"),
            let nameUTF8Pointer = symbol("archive_entry_pathname_utf8"),
            let sizePointer = symbol("archive_entry_size"),
            let fileTypePointer = symbol("archive_entry_filetype") else { return nil }
        return API(
            readNew: unsafeBitCast(newPointer, to: NewFn.self),
            supportFormat7Zip: unsafeBitCast(formatPointer, to: ConfigureFn.self),
            supportFilterAll: unsafeBitCast(filterPointer, to: ConfigureFn.self),
            openFilename: unsafeBitCast(openPointer, to: OpenFilenameFn.self),
            nextHeader: unsafeBitCast(nextPointer, to: NextHeaderFn.self),
            readData: unsafeBitCast(readPointer, to: ReadDataFn.self),
            readDataSkip: unsafeBitCast(skipPointer, to: DataSkipFn.self),
            readFree: unsafeBitCast(freePointer, to: FreeFn.self),
            errorString: unsafeBitCast(errorPointer, to: ErrorStringFn.self),
            entryPathname: unsafeBitCast(namePointer, to: EntryNameFn.self),
            entryPathnameUTF8: unsafeBitCast(nameUTF8Pointer, to: EntryNameFn.self),
            entrySize: unsafeBitCast(sizePointer, to: EntrySizeFn.self),
            entryFileType: unsafeBitCast(fileTypePointer, to: EntryFileTypeFn.self)
        )
    }()

    private static func makeReader(for url: URL) throws -> (OpaquePointer, API) {
        guard let api else {
            throw StringError("当前环境没有可用的 7z 解压组件。")
        }
        guard let reader = api.readNew() else {
            throw StringError("无法初始化 7z 解压器。")
        }
        let formatStatus = api.supportFormat7Zip(reader)
        _ = api.supportFilterAll(reader)
        guard formatStatus >= 0 else {
            _ = api.readFree(reader)
            throw StringError("7z 格式支持初始化失败。")
        }
        let openStatus = url.path.withCString { api.openFilename(reader, $0, 1 << 16) }
        guard openStatus == 0 else {
            let message = api.errorString(reader).map { String(cString: $0) } ?? "无法打开 7z 文件。"
            _ = api.readFree(reader)
            throw StringError(message)
        }
        return (reader, api)
    }

    private static func error(for reader: OpaquePointer, api: API, fallback: String) -> StringError {
        if let pointer = api.errorString(reader), pointer.pointee != 0 {
            return StringError(String(cString: pointer))
        }
        return StringError(fallback)
    }

    private static func name(of entry: OpaquePointer, api: API) -> String? {
        if let pointer = api.entryPathnameUTF8(entry) { return String(cString: pointer) }
        if let pointer = api.entryPathname(entry) { return String(cString: pointer) }
        return nil
    }

    private static func relativePath(_ raw: String) -> String? {
        let normalized = raw.replacingOccurrences(of: "\\", with: "/")
        guard !normalized.isEmpty, !normalized.hasPrefix("/"), !normalized.hasPrefix("~") else { return nil }
        let parts = normalized.split(separator: "/", omittingEmptySubsequences: true).map(String.init)
        guard !parts.contains("..") else { return nil }
        return parts.joined(separator: "/")
    }

    static func list(_ url: URL) throws -> [String] {
        let (reader, api) = try makeReader(for: url)
        defer { _ = api.readFree(reader) }
        var output: [String] = []
        var entry: OpaquePointer?
        while true {
            let status = api.nextHeader(reader, &entry)
            if status == 1 { break }
            guard status == 0, let entry else {
                throw error(for: reader, api: api, fallback: "7z 目录读取失败。")
            }
            guard let raw = name(of: entry, api: api), let relative = relativePath(raw) else {
                _ = api.readDataSkip(reader)
                continue
            }
            let fileType = api.entryFileType(entry)
            let isDirectory = (fileType & 0o170000) == 0o040000 || raw.hasSuffix("/")
            output.append(isDirectory ? relative + "/" : relative)
            _ = api.readDataSkip(reader)
        }
        return output
    }

    static func extractData(_ url: URL, entry requestedEntry: String) throws -> Data {
        let target = requestedEntry.trimmingCharacters(in: CharacterSet(charactersIn: "/"))
        let (reader, api) = try makeReader(for: url)
        defer { _ = api.readFree(reader) }
        var entry: OpaquePointer?
        var buffer = [UInt8](repeating: 0, count: 128 * 1024)
        var data = Data()
        while true {
            let status = api.nextHeader(reader, &entry)
            if status == 1 { break }
            guard status == 0, let entry else {
                throw error(for: reader, api: api, fallback: "7z 文件读取失败。")
            }
            guard let raw = name(of: entry, api: api), let relative = relativePath(raw) else {
                _ = api.readDataSkip(reader)
                continue
            }
            if relative == target {
                let expected = api.entrySize(entry)
                if expected > 0, expected <= Int64(Int.max) { data.reserveCapacity(Int(expected)) }
                while true {
                    let count = buffer.withUnsafeMutableBytes { rawBuffer -> Int64 in
                        api.readData(reader, rawBuffer.baseAddress, rawBuffer.count)
                    }
                    if count == 0 { break }
                    guard count > 0 else { throw error(for: reader, api: api, fallback: "7z 数据读取失败。") }
                    data.append(contentsOf: buffer[0..<Int(count)])
                }
                return data
            }
            _ = api.readDataSkip(reader)
        }
        throw StringError("7z 中找不到文件：\(requestedEntry)")
    }

    static func extractToURL(_ url: URL, entry requestedEntry: String, destination: URL) throws {
        let target = requestedEntry.trimmingCharacters(in: CharacterSet(charactersIn: "/"))
        try FileManager.default.createDirectory(at: destination.deletingLastPathComponent(), withIntermediateDirectories: true)
        let (reader, api) = try makeReader(for: url)
        defer { _ = api.readFree(reader) }
        var entry: OpaquePointer?
        var buffer = [UInt8](repeating: 0, count: 256 * 1024)
        while true {
            let status = api.nextHeader(reader, &entry)
            if status == 1 { break }
            guard status == 0, let entry else {
                throw error(for: reader, api: api, fallback: "7z 文件读取失败。")
            }
            guard let raw = name(of: entry, api: api), let relative = relativePath(raw) else {
                _ = api.readDataSkip(reader)
                continue
            }
            guard relative == target else {
                _ = api.readDataSkip(reader)
                continue
            }
            let fileType = api.entryFileType(entry)
            if (fileType & 0o170000) == 0o040000 || raw.hasSuffix("/") {
                try FileManager.default.createDirectory(at: destination, withIntermediateDirectories: true)
                return
            }
            if FileManager.default.fileExists(atPath: destination.path) {
                try FileManager.default.removeItem(at: destination)
            }
            FileManager.default.createFile(atPath: destination.path, contents: nil)
            let handle = try FileHandle(forWritingTo: destination)
            defer { try? handle.close() }
            while true {
                let count = buffer.withUnsafeMutableBytes { rawBuffer -> Int64 in
                    api.readData(reader, rawBuffer.baseAddress, rawBuffer.count)
                }
                if count == 0 { break }
                guard count > 0 else { throw error(for: reader, api: api, fallback: "7z 数据读取失败。") }
                try handle.write(contentsOf: buffer[0..<Int(count)])
            }
            return
        }
        throw StringError("7z 中找不到文件：\(requestedEntry)")
    }

    static func extractAll(_ url: URL, to destination: URL) throws {
        try FileManager.default.createDirectory(at: destination, withIntermediateDirectories: true)
        let (reader, api) = try makeReader(for: url)
        defer { _ = api.readFree(reader) }
        var entry: OpaquePointer?
        var buffer = [UInt8](repeating: 0, count: 256 * 1024)
        while true {
            let status = api.nextHeader(reader, &entry)
            if status == 1 { break }
            guard status == 0, let entry else {
                throw error(for: reader, api: api, fallback: "7z 解压失败。")
            }
            guard let raw = name(of: entry, api: api), let relative = relativePath(raw) else {
                _ = api.readDataSkip(reader)
                continue
            }
            let output = destination.appendingPathComponent(relative)
            let fileType = api.entryFileType(entry)
            if (fileType & 0o170000) == 0o040000 || raw.hasSuffix("/") {
                try FileManager.default.createDirectory(at: output, withIntermediateDirectories: true)
                _ = api.readDataSkip(reader)
                continue
            }
            try FileManager.default.createDirectory(at: output.deletingLastPathComponent(), withIntermediateDirectories: true)
            if FileManager.default.fileExists(atPath: output.path) { try FileManager.default.removeItem(at: output) }
            FileManager.default.createFile(atPath: output.path, contents: nil)
            let handle = try FileHandle(forWritingTo: output)
            while true {
                let count = buffer.withUnsafeMutableBytes { rawBuffer -> Int64 in
                    api.readData(reader, rawBuffer.baseAddress, rawBuffer.count)
                }
                if count == 0 { break }
                guard count > 0 else {
                    try? handle.close()
                    throw error(for: reader, api: api, fallback: "7z 数据读取失败。")
                }
                try handle.write(contentsOf: buffer[0..<Int(count)])
            }
            try handle.close()
        }
    }
}

private enum SantanderArchiveBackend {
    enum Kind { case zip, tar, tarGzip, tarBzip2, sevenZip, rar, gzip, bzip2 }

    static func kind(for url: URL) -> Kind? {
        let path = url.path.lowercased()
        if path.hasSuffix(".tar.gz") || path.hasSuffix(".tgz") { return .tarGzip }
        if path.hasSuffix(".tar.bz2") || path.hasSuffix(".tbz") || path.hasSuffix(".tbz2") { return .tarBzip2 }
        switch url.pathExtension.lowercased() {
        case "zip": return .zip
        case "tar": return .tar
        case "7z": return .sevenZip
        case "rar": return .rar
        case "gz": return .gzip
        case "bz2": return .bzip2
        default: return nil
        }
    }

    static func tool(_ names: [String]) -> String? {
        let candidates = names.flatMap { name in
            ["/var/jb/usr/bin/\(name)", "/var/jb/bin/\(name)", "/usr/bin/\(name)", "/bin/\(name)"]
        }
        return candidates.first { FileManager.default.isExecutableFile(atPath: $0) }
    }

    private static func requireTool(_ names: [String]) throws -> String {
        guard let executable = tool(names) else { throw StringError("未找到所需归档工具：\(names.joined(separator: ", "))") }
        return executable
    }

    static func list(_ url: URL) throws -> [String] {
        guard let kind = kind(for: url) else { throw StringError("不支持的归档格式。") }
        let result: SantanderProcessResult
        switch kind {
        case .zip:
            result = try SantanderProcessRunner.run(try requireTool(["unzip"]), ["-Z1", url.path])
        case .tar:
            result = try SantanderProcessRunner.run(try requireTool(["tar"]), ["-tf", url.path])
        case .tarGzip:
            result = try SantanderProcessRunner.run(try requireTool(["tar"]), ["-tzf", url.path])
        case .tarBzip2:
            result = try SantanderProcessRunner.run(try requireTool(["tar"]), ["-tjf", url.path])
        case .gzip:
            return [url.deletingPathExtension().lastPathComponent]
        case .bzip2:
            return [url.deletingPathExtension().lastPathComponent]
        case .sevenZip:
            return try SantanderSevenZipArchive.list(url)
        case .rar:
            result = try SantanderProcessRunner.run(try requireTool(["unrar", "rar"]), ["lb", url.path])
        }
        guard result.status == 0 else { throw StringError(result.stderr) }
        return result.stdout.split(whereSeparator: \.isNewline).map(String.init)
    }

    static func extract(_ url: URL, entry: String?) throws -> Data {
        guard let kind = kind(for: url) else { throw StringError("不支持的归档格式。") }
        switch kind {
        case .zip:
            return try SantanderProcessRunner.runData(try requireTool(["unzip"]), entry.map { ["-p", url.path, $0] } ?? ["-p", url.path])
        case .tar:
            return try SantanderProcessRunner.runData(try requireTool(["tar"]), entry.map { ["-xOf", url.path, $0] } ?? ["-xOf", url.path])
        case .tarGzip:
            return try SantanderProcessRunner.runData(try requireTool(["tar"]), entry.map { ["-xOzf", url.path, $0] } ?? ["-xOzf", url.path])
        case .tarBzip2:
            return try SantanderProcessRunner.runData(try requireTool(["tar"]), entry.map { ["-xOjf", url.path, $0] } ?? ["-xOjf", url.path])
        case .gzip:
            return try SantanderProcessRunner.runData(try requireTool(["gunzip"]), ["-c", url.path])
        case .bzip2:
            return try SantanderProcessRunner.runData(try requireTool(["bzip2"]), ["-dc", url.path])
        case .sevenZip:
            guard let entry else { throw StringError("7z 需要指定要提取的文件。") }
            return try SantanderSevenZipArchive.extractData(url, entry: entry)
        case .rar:
            let tool = try requireTool(["unrar", "rar"])
            return try SantanderProcessRunner.runData(tool, entry.map { ["p", "-inul", url.path, $0] } ?? ["p", "-inul", url.path])
        }
    }
}


final class SantanderPDFEditorViewController: UIViewController {
    private let fileURL: URL
    private let document: PDFDocument
    private let pdfView = PDFView()
    private enum AnnotationMode: Equatable { case none, note, highlight, underline, rectangle, eraser }
    private var annotationMode: AnnotationMode = .none
    private let canEdit: Bool

    init(fileURL: URL) {
        self.fileURL = fileURL
        self.document = PDFDocument(url: fileURL) ?? PDFDocument()
        self.canEdit = !PathPermissions.isLocked(at: fileURL)
        super.init(nibName: nil, bundle: nil)
        title = fileURL.lastPathComponent
    }
    required init?(coder: NSCoder) { fatalError() }
    override func viewDidLoad() {
        super.viewDidLoad(); applySantanderUI()
        view.backgroundColor = .systemBackground
        pdfView.translatesAutoresizingMaskIntoConstraints = false; pdfView.autoScales = true; pdfView.document = document
        view.addSubview(pdfView); pdfView.constraintCompletely(to: view)
        let save = UIBarButtonItem(systemItem: .save, primaryAction: UIAction { [weak self] _ in self?.savePDF() }); save.isEnabled = canEdit
        let optimize = UIBarButtonItem(title: SantanderL10n.t("Optimize"), image: SantanderIconLibrary.shared.interfaceIcon(for: "arrow.down.doc"), primaryAction: UIAction { [weak self] _ in self?.optimizePDF() })
        optimize.isEnabled = canEdit
        navigationItem.rightBarButtonItems = [save, optimize]
        navigationItem.leftBarButtonItems = [
            UIBarButtonItem(title: SantanderL10n.t("Rotate Left"), primaryAction: UIAction { [weak self] _ in self?.rotate(-90) }),
            UIBarButtonItem(title: SantanderL10n.t("Rotate Right"), primaryAction: UIAction { [weak self] _ in self?.rotate(90) })
        ]
        let annotationButtons: [(String, UIImage?, AnnotationMode)] = [
            (SantanderL10n.t("Add Note"), SantanderIconLibrary.shared.interfaceIcon(for: "note.text"), .note),
            (SantanderL10n.t("Highlight"), SantanderIconLibrary.shared.interfaceIcon(for: "highlighter"), .highlight),
            (SantanderL10n.t("Underline"), SantanderIconLibrary.shared.interfaceIcon(for: "underline"), .underline),
            (SantanderL10n.t("Rectangle"), SantanderIconLibrary.shared.uiIcon(named: "quicklook-viewer"), .rectangle),
            (SantanderL10n.t("Eraser"), SantanderIconLibrary.shared.interfaceIcon(for: "eraser"), .eraser),
            (SantanderL10n.t("Stop Annotation"), SantanderIconLibrary.shared.interfaceIcon(for: "xmark.circle"), .none)
        ]
        toolbarItems = annotationButtons.map { title, image, mode in
            let button = UIBarButtonItem(title: title, image: image, primaryAction: UIAction { [weak self] _ in self?.annotationMode = mode })
            button.isEnabled = canEdit
            return button
        }
        navigationController?.setToolbarHidden(false, animated: false)
        let tap = UITapGestureRecognizer(target: self, action: #selector(pdfTapped(_:))); pdfView.addGestureRecognizer(tap)
        if #available(iOS 16.0, *) { navigationItem.documentProperties = UIDocumentProperties(url: fileURL) }
    }
    @objc private func pdfTapped(_ gesture: UITapGestureRecognizer) {
        guard annotationMode != .none, canEdit else { return }
        let point = gesture.location(in: pdfView)
        guard let page = pdfView.page(for: point, nearest: true) else { return }
        let pagePoint = pdfView.convert(point, to: page)
        let bounds = CGRect(x: pagePoint.x - 80, y: pagePoint.y - 14, width: 160, height: 28)

        if annotationMode == .eraser {
            let nearest = page.annotations.min { lhs, rhs in
                let left = hypot(lhs.bounds.midX - pagePoint.x, lhs.bounds.midY - pagePoint.y)
                let right = hypot(rhs.bounds.midX - pagePoint.x, rhs.bounds.midY - pagePoint.y)
                return left < right
            }
            if let nearest, hypot(nearest.bounds.midX - pagePoint.x, nearest.bounds.midY - pagePoint.y) < 80 {
                page.removeAnnotation(nearest)
                pdfView.setNeedsDisplay()
            }
            return
        }

        switch annotationMode {
        case .none: return
        case .note:
            let alert = UIAlertController(title: SantanderL10n.t("Add Note"), message: nil, preferredStyle: .alert)
            alert.addTextField { field in field.placeholder = SantanderL10n.t("Note") }
            alert.addAction(.cancel())
            alert.addAction(UIAlertAction(title: SantanderL10n.t("Add"), style: .default) { [weak self] _ in
                guard let self, let text = alert.textFields?.first?.text, !text.isEmpty else { return }
                let annotation = PDFAnnotation(bounds: bounds, forType: .freeText, withProperties: nil)
                annotation.contents = text
                annotation.font = UIFont.systemFont(ofSize: 12)
                annotation.fontColor = .label
                annotation.alignment = .left
                annotation.color = UIColor.systemYellow.withAlphaComponent(0.25)
                page.addAnnotation(annotation)
                self.pdfView.setNeedsDisplay()
            })
            present(alert, animated: true)
        case .highlight:
            let annotation = PDFAnnotation(bounds: bounds, forType: .highlight, withProperties: nil)
            annotation.color = UIColor.systemYellow.withAlphaComponent(0.55)
            page.addAnnotation(annotation)
            pdfView.setNeedsDisplay()
        case .underline:
            let annotation = PDFAnnotation(bounds: bounds, forType: .underline, withProperties: nil)
            annotation.color = .systemRed
            page.addAnnotation(annotation)
            pdfView.setNeedsDisplay()
        case .rectangle:
            let annotation = PDFAnnotation(bounds: bounds, forType: .square, withProperties: nil)
            annotation.color = SantanderAppTheme.accentColor
            annotation.interiorColor = .clear
            let border = PDFBorder()
            border.lineWidth = 1.5
            annotation.border = border
            page.addAnnotation(annotation)
            pdfView.setNeedsDisplay()
        case .eraser:
            return
        }
    }
    private func rotate(_ degree: Int) {
        guard canEdit, let page = pdfView.currentPage else { return }
        page.rotation = (page.rotation + degree + 360) % 360
        pdfView.go(to: page)
        pdfView.setNeedsLayout()
        pdfView.layoutIfNeeded()
    }
    private func savePDF() {
        guard canEdit else { return }
        guard let data = document.dataRepresentation() else {
            errorAlert(nil, title: SantanderL10n.t("Unable to save PDF"))
            return
        }
        let target = fileURL
        DispatchQueue.global(qos: .userInitiated).async { [weak self] in
            do {
                try ensureFileContentIsUnlocked(target)
                try FSOperation.perform(.writeData(url: target, data: data), rootHelperConf: RootConf.shared)
                DispatchQueue.main.async { self?.errorAlert(nil, title: SantanderL10n.t("PDF saved")) }
            } catch {
                DispatchQueue.main.async { self?.errorAlert(error, title: SantanderL10n.t("Unable to save PDF")) }
            }
        }
    }

    private func optimizePDF() {
        guard canEdit else { return }
        guard let data = document.dataRepresentation() else {
            errorAlert(nil, title: SantanderL10n.t("Unable to save PDF"))
            return
        }
        let originalSize = (try? fileURL.resourceValues(forKeys: [.fileSizeKey]).fileSize) ?? Int.max
        let target = fileURL
        DispatchQueue.global(qos: .userInitiated).async { [weak self] in
            do {
                try ensureFileContentIsUnlocked(target)
                guard data.count <= originalSize else {
                    throw StringError("优化后的 PDF 不会更小，因此保留原文件。")
                }
                try FSOperation.perform(.writeData(url: target, data: data), rootHelperConf: RootConf.shared)
                DispatchQueue.main.async { self?.errorAlert(nil, title: SantanderL10n.t("PDF optimized")) }
            } catch {
                DispatchQueue.main.async { self?.errorAlert(error, title: SantanderL10n.t("Unable to save PDF")) }
            }
        }
    }
}

private typealias PDFEditorViewController = SantanderPDFEditorViewController

private final class SantanderAudioWaveformView: UIView {
    var amplitudes: [CGFloat] = [] { didSet { setNeedsDisplay() } }

    override func draw(_ rect: CGRect) {
        guard let context = UIGraphicsGetCurrentContext(), !amplitudes.isEmpty else {
            UIColor.tertiarySystemFill.setFill()
            UIBezierPath(roundedRect: bounds, cornerRadius: 8).fill()
            return
        }
        context.clear(bounds)
        let count = amplitudes.count
        let gap: CGFloat = count > 80 ? 1 : 2
        let width = max(1, (bounds.width - CGFloat(count - 1) * gap) / CGFloat(count))
        let centerY = bounds.midY
        SantanderAppTheme.accentColor.setFill()
        for (index, value) in amplitudes.enumerated() {
            let height = max(2, min(bounds.height, value * bounds.height * 0.92))
            let x = CGFloat(index) * (width + gap)
            let bar = CGRect(x: x, y: centerY - height / 2, width: width, height: height)
            UIBezierPath(roundedRect: bar, cornerRadius: width / 2).fill()
        }
    }
}

private final class SantanderAudioQueueListViewController: UITableViewController {
    private let urls: [URL]
    private let selectedIndex: Int
    private let didSelect: (Int) -> Void

    init(urls: [URL], selectedIndex: Int, didSelect: @escaping (Int) -> Void) {
        self.urls = urls
        self.selectedIndex = selectedIndex
        self.didSelect = didSelect
        super.init(style: .insetGrouped)
        title = SantanderL10n.t("Queue")
    }

    required init?(coder: NSCoder) { fatalError("init(coder:) has not been implemented") }

    override func viewDidLoad() {
        super.viewDidLoad()
        applySantanderUI()
        tableView.rowHeight = UITableView.automaticDimension
        tableView.estimatedRowHeight = 54
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int { urls.count }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = UITableViewCell(style: .subtitle, reuseIdentifier: nil)
        SantanderUI.styleCell(cell)
        let url = urls[indexPath.row]
        cell.textLabel?.text = url.deletingPathExtension().lastPathComponent
        cell.detailTextLabel?.text = url.pathExtension.uppercased()
        cell.imageView?.image = UIImage(systemName: indexPath.row == selectedIndex ? "waveform.circle.fill" : "waveform")
        cell.imageView?.tintColor = indexPath.row == selectedIndex ? SantanderAppTheme.accentColor : .secondaryLabel
        cell.accessoryType = indexPath.row == selectedIndex ? .checkmark : .none
        cell.accessibilityLabel = "\(url.lastPathComponent), \(indexPath.row == selectedIndex ? SantanderL10n.t("Now Playing") : "")"
        return cell
    }

    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        didSelect(indexPath.row)
        navigationController?.popViewController(animated: true)
    }
}

private final class AudioQueueViewController: UIViewController {
    private let urls: [URL]
    private var currentIndex: Int = 0
    private var player = AVQueuePlayer()
    private var observer: Any?
    private let titleLabel = UILabel()
    private let slider = UISlider()
    private let waveformView = SantanderAudioWaveformView()
    private var waveformGeneration = UUID()

    static func make(around url: URL) -> AudioQueueViewController? {
        guard let type = url.contentType, type.isSubtype(of: .audio) else { return nil }
        let siblings = (try? FileManager.default.contentsOfDirectory(at: url.deletingLastPathComponent(), includingPropertiesForKeys: [.contentTypeKey], options: [.skipsHiddenFiles]))?.filter { ($0.contentType?.isSubtype(of: .audio) ?? false) }.sorted { $0.lastPathComponent.localizedStandardCompare($1.lastPathComponent) == .orderedAscending } ?? [url]
        return AudioQueueViewController(urls: siblings, currentURL: url)
    }

    init(urls: [URL], currentURL: URL) {
        self.urls = urls
        self.currentIndex = max(0, urls.firstIndex(of: currentURL) ?? 0)
        super.init(nibName: nil, bundle: nil)
        title = currentURL.lastPathComponent
    }

    required init?(coder: NSCoder) { fatalError("init(coder:) has not been implemented") }

    override func viewDidLoad() {
        super.viewDidLoad()
        applySantanderUI()
        view.backgroundColor = .systemBackground

        let stack = UIStackView()
        stack.axis = .vertical
        stack.spacing = 18
        stack.alignment = .fill
        stack.translatesAutoresizingMaskIntoConstraints = false

        titleLabel.textAlignment = .center
        titleLabel.font = .preferredFont(forTextStyle: .headline)
        titleLabel.adjustsFontForContentSizeCategory = true
        titleLabel.numberOfLines = 2
        waveformView.translatesAutoresizingMaskIntoConstraints = false
        waveformView.heightAnchor.constraint(equalToConstant: 56).isActive = true
        waveformView.accessibilityLabel = SantanderL10n.t("Audio waveform")

        let volumeRow = UIStackView()
        volumeRow.axis = .horizontal
        volumeRow.alignment = .center
        volumeRow.spacing = 10
        let volumeIcon = UIImageView(image: UIImage(systemName: "speaker.wave.2"))
        volumeIcon.tintColor = .secondaryLabel
        volumeIcon.setContentHuggingPriority(.required, for: .horizontal)
        slider.minimumValue = 0
        slider.maximumValue = 1
        slider.value = player.volume
        slider.accessibilityLabel = SantanderL10n.t("Volume")
        slider.addAction(UIAction { [weak self] _ in self?.player.volume = self?.slider.value ?? 1 }, for: .valueChanged)
        volumeRow.addArrangedSubview(volumeIcon)
        volumeRow.addArrangedSubview(slider)

        let controls = UIStackView()
        controls.axis = .horizontal
        controls.distribution = .equalCentering
        controls.alignment = .center
        let prev = UIButton(type: .system)
        prev.setImage(SantanderIconLibrary.shared.interfaceIcon(for: "backward.fill"), for: .normal)
        prev.addAction(UIAction { [weak self] _ in self?.previous() }, for: .touchUpInside)
        let play = UIButton(type: .system)
        play.setImage(UIImage(systemName: "play.fill"), for: .normal)
        play.accessibilityLabel = SantanderL10n.t("Play or pause")
        play.addAction(UIAction { [weak self, weak play] _ in
            guard let self, let play else { return }
            if self.player.timeControlStatus == .playing {
                self.player.pause()
                play.setImage(UIImage(systemName: "play.fill"), for: .normal)
            } else {
                self.player.play()
                play.setImage(UIImage(systemName: "pause.fill"), for: .normal)
            }
        }, for: .touchUpInside)
        let next = UIButton(type: .system)
        next.setImage(SantanderIconLibrary.shared.interfaceIcon(for: "forward.fill"), for: .normal)
        next.addAction(UIAction { [weak self] _ in self?.next() }, for: .touchUpInside)
        for button in [prev, play, next] {
            button.widthAnchor.constraint(greaterThanOrEqualToConstant: 44).isActive = true
            button.heightAnchor.constraint(greaterThanOrEqualToConstant: 44).isActive = true
            controls.addArrangedSubview(button)
        }

        stack.addArrangedSubview(titleLabel)
        stack.addArrangedSubview(waveformView)
        stack.addArrangedSubview(volumeRow)
        stack.addArrangedSubview(controls)
        view.addSubview(stack)
        NSLayoutConstraint.activate([
            stack.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor, constant: 24),
            stack.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor, constant: -24),
            stack.centerYAnchor.constraint(equalTo: view.safeAreaLayoutGuide.centerYAnchor)
        ])

        navigationItem.rightBarButtonItem = UIBarButtonItem(title: SantanderL10n.t("Queue"), image: SantanderIconLibrary.shared.interfaceIcon(for: "list.bullet"), primaryAction: UIAction { [weak self] _ in self?.showQueue() })
        setupQueue(autoplay: true)
    }

    private func setupQueue(autoplay: Bool) {
        player.pause()
        player.removeAllItems()
        for index in currentIndex..<urls.count {
            player.insert(AVPlayerItem(url: urls[index]), after: nil)
        }
        if let observer {
            NotificationCenter.default.removeObserver(observer)
            self.observer = nil
        }
        observer = NotificationCenter.default.addObserver(forName: .AVPlayerItemDidPlayToEndTime, object: nil, queue: .main) { [weak self] note in
            guard let self,
                  let finishedItem = note.object as? AVPlayerItem,
                  let finishedURL = (finishedItem.asset as? AVURLAsset)?.url,
                  self.currentIndex < self.urls.count,
                  finishedURL.standardizedFileURL == self.urls[self.currentIndex].standardizedFileURL else { return }
            self.currentIndex = min(self.urls.count - 1, self.currentIndex + 1)
            self.updateNowPlaying(self.player.currentItem)
            if self.currentIndex < self.urls.count { self.loadWaveform(for: self.urls[self.currentIndex]) }
        }
        updateNowPlaying(player.currentItem)
        if currentIndex < urls.count { loadWaveform(for: urls[currentIndex]) }
        if autoplay { player.play() }
    }

    private func play(at index: Int) {
        guard urls.indices.contains(index) else { return }
        currentIndex = index
        setupQueue(autoplay: true)
    }

    private func updateNowPlaying(_ item: AVPlayerItem?) {
        guard let asset = item?.asset as? AVURLAsset else { return }
        titleLabel.text = asset.url.lastPathComponent
        title = asset.url.lastPathComponent
        MPNowPlayingInfoCenter.default().nowPlayingInfo = [
            MPMediaItemPropertyTitle: asset.url.deletingPathExtension().lastPathComponent,
            MPMediaItemPropertyPlaybackDuration: CMTimeGetSeconds(item?.duration ?? .zero)
        ]
    }

    private func previous() {
        guard !urls.isEmpty else { return }
        play(at: max(0, currentIndex - 1))
    }

    private func next() {
        guard !urls.isEmpty else { return }
        play(at: min(urls.count - 1, currentIndex + 1))
    }

    private func showQueue() {
        let queue = SantanderAudioQueueListViewController(urls: urls, selectedIndex: currentIndex) { [weak self] index in
            self?.play(at: index)
        }
        navigationController?.pushViewController(queue, animated: true)
    }

    private func loadWaveform(for url: URL) {
        let generation = UUID()
        waveformGeneration = generation
        DispatchQueue.global(qos: .utility).async { [weak self] in
            let amplitudes = Self.readWaveform(url: url, barCount: 96)
            DispatchQueue.main.async {
                guard let self, self.waveformGeneration == generation else { return }
                self.waveformView.amplitudes = amplitudes
            }
        }
    }

    private static func readWaveform(url: URL, barCount: Int) -> [CGFloat] {
        guard barCount > 0, let file = try? AVAudioFile(forReading: url) else { return [] }
        let totalFrames = file.length
        guard totalFrames > 0 else { return [] }
        let format = file.processingFormat
        guard format.commonFormat == .pcmFormatFloat32 else { return [] }

        var peaks = [Float](repeating: 0, count: barCount)
        var framesProcessed: Int64 = 0
        while framesProcessed < totalFrames {
            let desired = AVAudioFrameCount(min(Int64(4096), totalFrames - framesProcessed))
            guard let buffer = AVAudioPCMBuffer(pcmFormat: format, frameCapacity: desired),
                  (try? file.read(into: buffer, frameCount: desired)) != nil,
                  buffer.frameLength > 0,
                  let channels = buffer.floatChannelData else { break }
            let samples = Int(buffer.frameLength)
            let channel = channels[0]
            for sampleIndex in 0..<samples {
                let frame = framesProcessed + Int64(sampleIndex)
                let bucket = min(barCount - 1, Int((Double(frame) / Double(totalFrames)) * Double(barCount)))
                peaks[bucket] = max(peaks[bucket], abs(channel[sampleIndex]))
            }
            framesProcessed += Int64(samples)
        }
        let maximum = max(peaks.max() ?? 0, 0.0001)
        return peaks.map { CGFloat($0 / maximum) }
    }

    deinit {
        if let observer { NotificationCenter.default.removeObserver(observer) }
        player.pause()
    }
}

private final class SantanderFontCompareViewController: UIViewController {
    private let fonts: [UIFont]
    init(fonts: [UIFont]) { self.fonts = fonts; super.init(nibName: nil, bundle: nil); title = SantanderL10n.t("Compare Fonts") }
    required init?(coder: NSCoder) { fatalError() }
    override func viewDidLoad() { super.viewDidLoad(); applySantanderUI(); let stack = UIStackView(); stack.axis = UIDevice.isiPad ? .horizontal : .vertical; stack.distribution = .fillEqually; stack.spacing = 1; stack.translatesAutoresizingMaskIntoConstraints = false; for (i,font) in fonts.prefix(2).enumerated() { let tv = UITextView(); tv.isEditable = false; tv.font = font; tv.text = "A a B b C c 0123456789\nThe quick brown fox jumps over the lazy dog.\n\\(font.fontName)"; stack.addArrangedSubview(tv); _ = i }; view.addSubview(stack); NSLayoutConstraint.activate([stack.leadingAnchor.constraint(equalTo: view.leadingAnchor), stack.trailingAnchor.constraint(equalTo: view.trailingAnchor), stack.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor), stack.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor)]) }
}

private enum SantanderSyntaxHighlighter {
    static let keywords: [String: Set<String>] = [
        "swift": Set("class struct enum protocol extension func let var if else for while in switch case default guard return import public private internal fileprivate static final async await actor throws try catch defer where as is nil true false self super init deinit override weak unowned mutating nonmutating some any".split(separator: " ").map(String.init)),
        "c": Set("auto break case char const continue default do double else enum extern float for goto if inline int long register restrict return short signed sizeof static struct switch typedef union unsigned void volatile while".split(separator: " ").map(String.init)),
        "m": Set("@interface @implementation @end @property @synthesize @dynamic self super nil YES NO".split(separator: " ").map(String.init)),
        "objc": Set("@interface @implementation @end @property @synthesize @dynamic self super nil YES NO".split(separator: " ").map(String.init)),
        "javascript": Set("const let var function return if else for while switch case break class new this async await throw try catch import export from typeof instanceof true false null undefined".split(separator: " ").map(String.init)),
        "js": Set("const let var function return if else for while switch case break class new this async await throw try catch import export from typeof instanceof true false null undefined".split(separator: " ").map(String.init)),
        "python": Set("def class import from as if elif else for while in return yield try except finally with lambda async await True False None and or not is".split(separator: " ").map(String.init)),
        "sh": Set("if then else fi for while in do done case esac function export local readonly return".split(separator: " ").map(String.init)),
        "shell": Set("if then else fi for while in do done case esac function export local readonly return".split(separator: " ").map(String.init)),
        "zsh": Set("autoload alias bindkey case coproc do done elif else esac export for function if in select then time typeset until while return setopt unsetopt".split(separator: " ").map(String.init)),
        "bash": Set("alias bg bind break case cd continue declare do done echo elif else enable eval exec exit export false fi for function getopts hash help history if in jobs kill local logout mapfile popd printf pushd pwd read readonly return select set shift source suspend test then times trap true type typeset ulimit umask unalias unset until wait while".split(separator: " ").map(String.init)),
        "json": Set(["true", "false", "null"]),
        "plist": Set(["dict", "array", "string", "integer", "real", "true", "false", "data", "date", "key"]),
        "xml": Set(),
        "html": Set("html head body div span a img script style meta link title form input button textarea table tr td th ul ol li".split(separator: " ").map(String.init)),
        "css": Set("color background display position absolute relative fixed margin padding border font width height flex grid overflow".split(separator: " ").map(String.init)),
        "sql": Set("select from where insert into update delete create alter drop table index view join left right inner outer group by order having limit offset union all as distinct and or not null values set pragma begin commit rollback explain vacuum".split(separator: " ").map(String.init)),
        "yaml": Set("true false null yes no on off".split(separator: " ").map(String.init))
    ]
    static func highlight(_ source: String, fileExtension: String, baseFont: UIFont, baseColor: UIColor) -> NSAttributedString {
        let result = NSMutableAttributedString(string: source, attributes: [.font: baseFont, .foregroundColor: baseColor])
        let ext = fileExtension.lowercased(); let keySet = keywords[ext] ?? keywords[ext == "m" ? "objc" : ext]
        let full = NSRange(location: 0, length: (source as NSString).length)
        let patterns: [(String, UIColor)] = [
            (#"//.*$|/\\*[\\s\\S]*?\\*/|#.*$"#, .systemGreen),
            (#"\\"(?:\\\\.|[^\\"])*\\"|'(?:\\\\.|[^'])*'|`(?:\\\\.|[^`])*`"#, .systemRed),
            (#"\\b(?:0x[0-9A-Fa-f]+|\\d+(?:\\.\\d+)?)\\b"#, .systemOrange)
        ]
        for (pattern,color) in patterns { if let regex = try? NSRegularExpression(pattern: pattern, options: [.anchorsMatchLines]) { for match in regex.matches(in: source, range: full) { result.addAttribute(.foregroundColor, value: color, range: match.range) } } }
        if let keySet { let pattern = "\\b(?:" + keySet.map(NSRegularExpression.escapedPattern(for:)).joined(separator: "|") + ")\\b"; if let regex = try? NSRegularExpression(pattern: pattern) { for match in regex.matches(in: source, range: full) { result.addAttribute(.foregroundColor, value: SantanderAppTheme.accentColor, range: match.range) } } }
        return result
    }
}


extension URL {
    fileprivate var mimeType: String? {
        if let type = contentType, let mime = type.preferredMIMEType { return mime }
        return nil
    }
}




extension PathSidebarListViewController {
    func collectionView(_ collectionView: UICollectionView, itemsForBeginning session: UIDragSession, at indexPath: IndexPath) -> [UIDragItem] {
        guard let item = dataSource.itemIdentifier(for: indexPath), case .item(let path) = item else { return [] }
        let provider = NSItemProvider(); provider.registerFileRepresentation(forTypeIdentifier: path.contentType?.identifier ?? UTType.item.identifier, visibility: .all) { completion in completion(path.url, true, nil); return nil }
        return [UIDragItem(itemProvider: provider)]
    }
    func collectionView(_ collectionView: UICollectionView, canHandle session: UIDropSession) -> Bool { true }
    func collectionView(_ collectionView: UICollectionView, dropSessionDidUpdate session: UIDropSession, withDestinationIndexPath destinationIndexPath: IndexPath?) -> UICollectionViewDropProposal { UICollectionViewDropProposal(operation: .copy, intent: .insertIntoDestinationIndexPath) }
    func collectionView(_ collectionView: UICollectionView, performDropWith coordinator: UICollectionViewDropCoordinator) {
        guard let destination = coordinator.destinationIndexPath, let target = dataSource.itemIdentifier(for: destination) else { return }
        switch target {
        case .section(let groupName):
            guard let groupIndex = pathGroups.firstIndex(where: { $0.name == groupName }) else { return }
            for item in coordinator.items {
                item.dragItem.itemProvider.loadFileRepresentation(forTypeIdentifier: UTType.item.identifier) { [weak self] url, _ in
                    guard let url else { return }
                    DispatchQueue.main.async {
                        guard let self else { return }
                        if !self.pathGroups[groupIndex].paths.contains(url) {
                            self.pathGroups[groupIndex].paths.append(url)
                            UserPreferences.pathGroups = self.pathGroups
                        }
                    }
                }
            }
        case .item(let destinationPath):
            guard destinationPath.isDirectory else { return }
            for item in coordinator.items {
                item.dragItem.itemProvider.loadFileRepresentation(forTypeIdentifier: UTType.item.identifier) { url, _ in
                    guard let url else { return }
                    DispatchQueue.global(qos: .userInitiated).async {
                        do {
                            try ensureFileContentIsUnlocked(destinationPath.url)
                            try FSOperation.perform(.copyItem(items: [url], resultPath: destinationPath.url), rootHelperConf: RootConf.shared)
                        } catch {
                            DispatchQueue.main.async {
                                if let vc = collectionView.window?.rootViewController {
                                    vc.errorAlert(error, title: SantanderL10n.t("Unable to copy"))
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

