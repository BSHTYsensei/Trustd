# Santander 文件浏览器重构记录（2026-11-15）

## Filza 逆向资料依据

本次只使用 `逆向.zip` 中的静态逆向材料。关键证据：

- `TIGIBrowserView.h`：浏览器协调列表/网格、工具栏、目录信息视图，并处理排序、搜索、视图模式、选择和长按等交互。
- `ListViewRowCell.h`：Filza 列表行具有独立的图标、名称、详情、大小和权限字段。
- `TGDirectoryInfoView.h`：目录信息栏包含文件系统、项目数量、磁盘空间和锁定状态。
- `TGInfoFooterCollectionReusableView.h`：网格模式使用独立的 collection footer。

这些是类接口和静态线索，不是原始实现，也不是运行时截图。因此本次按结构重建经典 UI，不宣称像素级复刻。

## 已实施的重构

### 1. Filza 经典列表行

- 列表行改为独立的图标、名称、次要详情、文件大小和权限字段。
- 图标固定为适合列表阅读的尺寸；大小和权限使用右侧独立列，权限使用等宽数字字体。
- 使用复用的 UIKit 子视图和 frame 布局，不为每个文件创建 Auto Layout 约束树。
- 保留现有文件图标、缩略图缓存、元数据缓存、搜索高亮、应用名称显示和文件操作入口。
- 目录统计信息继续位于列表内容末尾；网格信息栏继续由 collection reusable footer 承载。

### 2. 目录读取与错误语义

旧的 `URL.contents` 会把所有读取错误折叠成 `[]`。这让“目录确实为空”“普通权限不足”“Helper 失败”在调用端无法区分。新增 throwing 的 `readDirectoryContents()`：

1. 先调用 Foundation 直接枚举。
2. 只有直接枚举抛错，且用户启用了 Helper 时，才尝试 Santander Helper。
3. 两种读取方式都失败时，保留并返回具体错误，不再伪装成空目录。
4. 浏览器首屏、下拉刷新和目录监控改为使用这个明确的读取结果。

旧 `contents` 属性仍保留给其他历史调用点，避免无关功能大范围破坏；主文件浏览器不再依赖这个吞错接口。

### 3. 无限加载和重复启动

发现一个明确的重复启动问题：`viewDidLoad` 已启动初次目录读取后，`viewDidAppear` 仍可能在读取尚未完成时再次启动。原 guard 只在 `isDirectoryContentsReady == true` 时阻止重复启动，因此第二次请求会覆盖 generation，造成多余枚举或 Helper 进程。

现在初次读取一旦启动，在非强制刷新时就不再重复启动。另增加两层终止保障：

- Helper 目录读取最长等待 15 秒，超时会终止 Helper 并返回明确错误。
- UI 读取 watchdog 为 20 秒。若 Foundation 或底层挂载点卡住，界面会退出永久 spinner，显示可重试的错误状态，并使迟到的旧结果失效。

成功读取 0 个项目才显示“文件夹为空”；失败显示错误和重试入口。刷新或监控读取失败时保留已显示的文件，不用空数组覆盖现有内容。

## 验证结果

已完成：

- `Santander.swift` Swift parser 语法解析。
- `SantanderHelper/helper.swift` Swift parser 语法解析。
- `entitlements.plist`、`SantanderHelper/entitlements.plist`、`Resources/Info.plist`、`Resources/entitlements.plist` 均通过 plist 解析。
- 对照确认主浏览器首屏、刷新、目录监控走 throwing 读取接口。
- ZIP 完整性检查将在交付归档后执行。

未能完成：

- 当前环境没有 macOS、Xcode 和 Apple iOS SDK，不能执行完整 UIKit 类型检查、iOS 编译、签名或真机启动。
- 不能在当前环境连接 TrollStore / 越狱设备，不能验证 Helper root persona、实际目录权限和大目录滚动帧率。
- UI watchdog 能释放界面，但 Foundation 内部被内核阻塞的线程无法安全强杀；它会让旧结果失效并提供重试，而不是声称能中断系统文件调用。

## 保留的兼容边界

没有改写文件操作协议、Helper 命令格式、root persona entitlement 或现有预览/编辑器。Helper 仍受设备 iOS 版本、TrollStore 能力和实际 entitlement 限制；UI 重构不会伪造 root 权限。
