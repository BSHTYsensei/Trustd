# Santander：iOS 18 普通侧载与 RootHelper 说明

## 默认构建：iOS 18 UI 预览 / 普通证书侧载

默认 `DISTRIBUTION=sideload`。此模式面向普通开发者证书侧载：

- 主应用使用空 entitlement 字典，不携带 `platform-application`、`no-sandbox`、`persona-mgmt` 等私有权限。
- 不在 app bundle 中打包 RootHelper，也不声明 TrollStore 专用的 `TSRootBinaries`。
- 首次启动打开应用自己的容器目录（`NSHomeDirectory()`），并创建 `Documents` 文件夹，所以即使没有越狱/root，也能看到文件浏览器、右上角菜单、列表/网格、底部锁状态栏等 UI。
- 在应用沙盒允许的范围内，可使用 Foundation 执行创建、复制、移动、删除、重命名、写入和权限位修改。
- 系统目录、其他 App 容器、所有者变更、挂载、不可变标记等特权操作不可用；界面会返回权限提示而不是假装成功。
- 终端界面保留，但普通侧载进程不是 root；PTY 或 `/bin/sh` 受系统策略限制时会显示启动错误，不会把普通 shell 标成 root。

构建命令：

```sh
make DISTRIBUTION=sideload
make ipa DISTRIBUTION=sideload
```

## 可选旧版构建：TrollStore RootHelper

`DISTRIBUTION=trollstore` 只保留给实际兼容 TrollStore 的系统（官方公开支持范围中的 iOS 17.0）使用。此模式会编译并打包 RootHelper，应用使用 `Resources/Info-TrollStore.plist` 与旧版私有 entitlement 文件。

```sh
make clean
make DISTRIBUTION=trollstore
make ipa DISTRIBUTION=trollstore
```

**不要在 iOS 18 上使用 TrollStore 模式。** 普通证书侧载不等于 TrollStore；把私有 entitlement 写进 plist 并不能获得权限。TrollStore 的 root helper 路径也不能通过新增 entitlement 在 iOS 18 上恢复。

## RootHelper 机制说明

TrollStore 模式会尝试通过 persona ID 99、Override 标志和 UID/GID 0 设置来启动 RootHelper，并在使用前检查子进程真实身份。`id -u` 和 `id -g` 均为 `0` 才能称为 root。只要系统拒绝 persona，特权文件操作就不可用。

`entitlements-legacy-private.plist` 仅供上述旧版模式调用，不是普通侧载权限清单。`entitlements.plist` 是普通侧载模式实际使用的空 entitlement plist。

## 验证范围

已执行 Swift 前端语法解析、Makefile 解析、plist 解析及 ZIP 完整性检查。但当前编辑环境为 Linux，没有 macOS、Xcode、iOS SDK 或真实 iPhone，因此没有完成 iOS 二进制编译、重新签名或 iOS 18 真机启动验证。

若 iOS 18 普通侧载版本仍然秒退，请导出 `Santander.ips` 崩溃报告，或提供 `amfid`、`SpringBoard`、`runningboardd` 附近的系统日志。这样才能分辨签名/entitlement 拒绝、dyld 依赖错误和应用内异常。

## 参考

- Santander 上游项目：<https://github.com/NSAntoine/Santander>
- TrollStore 官方 README：<https://github.com/opa334/TrollStore/blob/main/README.md>
- TrollStore `spawnRoot` 实现：<https://github.com/opa334/TrollStore/blob/main/Shared/TSUtil.m>
- TrollStore 兼容范围：<https://theapplewiki.com/wiki/TrollStore>
