# Santander Helper、终端与文件浏览器说明

## 本次改动

- 修正 Makefile 中 SantanderHelper 源文件大小写：仓库文件是 `SantanderHelper/helper.swift`。
- Santander Helper 启动时显式检查 TrollStore persona API 是否存在，并逐项检查设置 persona、UID、GID 的返回值；失败时给出明确错误，不再把“子进程启动成功”误当成“已经是 root”。
- 新增 `identity` 诊断子命令，Santander Helper 会返回真实 UID/EUID/GID/EGID，只有四项均为 0 才会被识别为 root。
- 文件夹枚举在普通 FileManager 枚举失败时会尝试 Santander Helper。
- 终端优先请求 root persona；如果系统在 `posix_spawn` 阶段拒绝该 persona，则重试普通用户 shell，避免终端整个打不开。终端会输出实际 UID 状态提示；普通用户 shell 不代表拥有系统目录写权限。
- 文件浏览器以 UIKit 原生导航栏为主：常用的搜索、排序、网格入口直接显示，选择、新建、粘贴、终端和文件夹信息等其余操作放在右上角 `…` 菜单。“复制”会把单个或多选文件 URL 放入应用剪贴板，检测到可粘贴文件后才显示“粘贴”；原来的“复制到…”目录操作保留在更多操作中。网格视图与列表视图都有终端和文件夹信息入口。
- 列表目录状态行放在最后一个文件之后的 `tableFooterView`，随内容滚动；字号调至 11–12 pt，显示文件系统、项目统计、空间和可写/只读状态。文件行/网格开启元数据副标题。

## TrollStore / Santander Helper 所需条件

主应用侧与 root 启动直接相关的 entitlement：

- `com.apple.private.persona-mgmt = true`：父应用请求 TrollStore root persona 的关键权限。
- `com.apple.private.security.container-required = false`
- `com.apple.private.security.no-container = true`
- `com.apple.private.security.no-sandbox = true`：让应用在无容器/无沙盒路径下访问文件系统。
- `platform-application = true`：工程目前保留；这不是 root 的替代品，并可能带来额外 sandbox 行为。
- `com.apple.private.security.storage.AppDataContainers = true`：与 `platform-application` 和 no-sandbox 组合时，保留应用数据容器访问能力。

SantanderHelper 自身的 entitlements 采用按实际调用收敛的权限集合：no-sandbox、container-manager、MobileContainerManager、AppBundles、AppDataContainers、MobileDocuments、storage-exempt.heritable、VFS owner/authorized/root、mount、disk-device-access 和 rootless install。没有加入 MobileInstallation / LaunchServices / SpringBoard 启动应用等与当前 helper 代码无关的 entitlement，也移除了调试用 `get-task-allow` 和未使用的 `system-task-ports`。`com.apple.private.persona-mgmt` 是调用 `posix_spawn` 请求 root persona 的父应用权限；当前主应用 `entitlements.plist` 已包含该键，因此不重复把它当作 helper 自身的必需权限。`Resources/Info.plist` 的 `TSRootBinaries` 路径必须与 app bundle 内的 `SantanderHelper` 可执行文件名完全一致。entitlement 只能表达请求的能力，不保证每个 iOS 版本都会允许 root persona。

TrollStore 官方的 `spawnRoot` 实现使用 `posix_spawnattr_set_persona_np(attr, 99, 1)`，再设置 UID/GID 为 0，最后才 `posix_spawn` helper。本工程现在对这三个调用的存在与返回值都做了检查。

## 版本限制与诊断

TrollStore 的公开兼容范围并非覆盖所有 iOS 版本。Apple Wiki 当前列出的范围为 iOS 14.0–16.6.1、16.7 RC（20H18）和 iOS 17.0；其说明还指出 iOS 17.6 与 iOS 18 引入了阻止非 root 进程通过 `com.apple.private.persona-mgmt` 将子进程提升为 root 的系统缓解措施。因此，**单靠增加 entitlement 或修改 UI，无法让不受支持的系统重新获得 TrollStore root spawn 能力**。

可在终端执行：

```sh
id -u
id -g
```

两项均为 `0` 才是 root shell。若显示非 0，当前终端仍可用于普通用户范围内的命令，但 SantanderHelper 的特权文件操作仍会失败。若设备另有已启用的越狱 bootstrap/root 服务，需要另行接入对应越狱环境的受支持 root 启动机制；本工程没有伪造或绕过系统权限限制。

## 构建验证

此归档中的修改已做 Swift 语法解析与三个 plist 的格式校验。完整 iOS 构建、签名和真机 root/PTY 验证需要 macOS、Xcode/iOS SDK、项目依赖及实际设备环境；在 Linux 容器中无法完成这些设备级验证。

## 参考

- TrollStore `spawnRoot` 实现：<https://github.com/opa334/TrollStore/blob/main/Shared/TSUtil.m>
- TrollStore 兼容性与系统限制：<https://theapplewiki.com/wiki/TrollStore>
- Santander 上游项目：<https://github.com/NSAntoine/Santander>
- TrollStore 官方 README（Unsandboxing / Santander Helpers）：<https://github.com/opa334/TrollStore/blob/main/README.md>



## 稳定 UIKit 文件浏览器重构（2026-11-14）

本次依据 `逆向.zip` 的 Filza UIKit 类结构重做主浏览器，不读取或合并 `逆向2.zip`：

- 主列表固定使用 `UITableViewController` / `UITableView` 的传统 data source/delegate，继续由单一 `displayedRows` 数组驱动，不引入 diffable snapshot。顶部搜索、排序和网格切换采用原生 `UIBarButtonItem`，其余文件操作保留在 `UIMenu`。
- 文件行改为系统 `UITableViewCell` 的 `subtitle` 样式，由 UIKit 自身负责图标、主标题、副标题和 accessory 的布局；不再为每行创建多层 `UIStackView` 或自定义约束树。日期、大小和权限信息合并在紧凑副标题中。
- 移除额外的自定义顶部横向工具条。搜索由系统 `UISearchController` 提供；排序、选择、新建、粘贴、网格和终端入口统一放入系统导航栏菜单。
- 列表目录信息使用 `UITableView.tableFooterView`，严格排在最后一个文件之后并随滚动内容移动；没有 overlay、zPosition 固定或额外底部 inset。它保留文件系统、项目数、磁盘空间和只读/可写状态，并可点击查看详情。
- 网格仍使用 `UICollectionViewFlowLayout`，其状态区由 `UICollectionReusableView` 实现，与列表 footer 分开挂接。
- 首次目录读取在 `viewDidLoad` 启动到后台队列；读取期间显示 UIKit 原生活动指示器，完成后明确显示文件列表、空目录或权限错误状态。全局搜索界面不再误加载根目录内容或挂目录状态 footer。
- 首次安装默认采用 Filza 经典浅色外观；用户明确保存的系统/深色外观仍会被尊重，避免把设备系统深色模式误当成应用首次默认主题。
- 列表工具栏、导航栏和交互均使用 UIKit 系统控件；iOS 15 的 appearance API 做了可用性保护，Makefile 最低目标维持 iOS 14.0。

性能方面继续使用现有的后台目录枚举、元数据缓存、缩略图缓存和 generation 检查。列表 cell 配置不做递归磁盘操作，也不创建约束堆栈。目录 footer 只在宽度变化时重新挂回 tableFooterView。

### 验证范围

本轮对应用/Helper Swift 源文件执行 Swift parser 语法解析，核对 iOS 14 最低部署目标、Info.plist、场景入口、footer 注册和 ZIP 完整性。当前环境没有 Xcode/iOS SDK，无法执行完整 UIKit 类型检查、设备编译、签名、启动和帧率测试；不能把静态检查描述成真机验证。

### 首屏空白问题修复

初始目录异步读取期间，旧逻辑在 `viewDidLoad` 调用空目录状态检查时提前清除了加载视图；文件尚未读出时，表格因此只剩背景色。现在仅当 `isDirectoryContentsReady == true` 才会移除加载视图，异步读取完成后再显示文件列表、空目录或权限错误状态。
