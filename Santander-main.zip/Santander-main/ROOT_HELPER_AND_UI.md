# Santander Helper、终端与文件浏览器说明

## 本次改动

- 修正 Makefile 中 SantanderHelper 源文件大小写：仓库文件是 `SantanderHelper/helper.swift`。
- Santander Helper 启动时显式检查 TrollStore persona API 是否存在，并逐项检查设置 persona、UID、GID 的返回值；失败时给出明确错误，不再把“子进程启动成功”误当成“已经是 root”。
- 新增 `identity` 诊断子命令，Santander Helper 会返回真实 UID/EUID/GID/EGID，只有四项均为 0 才会被识别为 root。
- 文件夹枚举在普通 FileManager 枚举失败时会尝试 Santander Helper。
- 终端优先请求 root persona；如果系统在 `posix_spawn` 阶段拒绝该 persona，则重试普通用户 shell，避免终端整个打不开。终端会输出实际 UID 状态提示；普通用户 shell 不代表拥有系统目录写权限。
- 文件浏览器统一使用右上角 `…` 菜单；“新建”位于菜单中。“复制”会把单个或多选文件 URL 放入应用剪贴板，检测到可粘贴文件后才显示“粘贴”；原来的“复制到…”目录操作保留在更多操作中。网格视图与列表视图都有终端和文件夹信息入口。
- 底部增加目录状态行：锁图标表示当前目录是否可写；同时显示文件数、文件夹数、隐藏项目数、已用空间和可用空间。文件行/网格开启元数据副标题。

## TrollStore / Santander Helper 所需条件

主应用侧与 root 启动直接相关的 entitlement：

- `com.apple.private.persona-mgmt = true`：父应用请求 TrollStore root persona 的关键权限。
- `com.apple.private.security.container-required = false`
- `com.apple.private.security.no-container = true`
- `com.apple.private.security.no-sandbox = true`：让应用在无容器/无沙盒路径下访问文件系统。
- `platform-application = true`：工程目前保留；这不是 root 的替代品，并可能带来额外 sandbox 行为。
- `com.apple.private.security.storage.AppDataContainers = true`：与 `platform-application` 和 no-sandbox 组合时，保留应用数据容器访问能力。

SantanderHelper 自身的 entitlements 采用按实际调用收敛的权限集合：no-sandbox、container-manager、MobileContainerManager、AppBundles、AppDataContainers、MobileDocuments、storage-exempt.heritable、VFS owner/authorized/root、mount、disk-device-access 和 rootless install。没有加入 MobileInstallation / LaunchServices / SpringBoard 启动应用等与当前 helper 代码无关的 entitlement，也移除了调试用 `get-task-allow` 和未使用的 `system-task-ports`。`com.apple.private.persona-mgmt` 是调用 `posix_spawn` 请求 root persona 的父应用权限；当前主应用 `entitlements.plist` 已包含该键，因此不重复把它当作 helper 自身的必需权限。`Resources/Info.plist` 的 `TSRootBinaries` 路径必须与 app bundle 内的 `SantanderHelper` 可执行文件名完全一致。entitlement 只能表达请求的能力，不保证每个 iOS 版本都会允许 root persona。

TrollStore 官方的 `spawnRoot` 实现使用 `posix_spawnattr_set_persona_np(attr, 99, 1)`，再设置 UID/GID 为 0，最后才 `posix_spawn` helper。本工程现在对这三个调用的存在与返回值都做了检查。

## 版本限制与诊断

TrollStore 的公开兼容范围并非覆盖所有 iOS 版本。Apple Wiki 当前列出的范围为 iOS 14.0–16.6.1、16.7 RC（20H18）和 iOS 17.0；其说明还指出 iOS 17.6 与 iOS 18 引入了阻止非 root 进程通过 `com.apple.private.persona-mgmt` 将子进程提升为 root 的系统缓解措施。因此，**单靠增加 entitlement 或修改 UI，无法让不受支持的系统重新获得 TrollStore root spawn 能力**。

可在终端执行：

```sh
id -u
id -g
```

两项均为 `0` 才是 root shell。若显示非 0，当前终端仍可用于普通用户范围内的命令，但 SantanderHelper 的特权文件操作仍会失败。若设备另有已启用的越狱 bootstrap/root 服务，需要另行接入对应越狱环境的受支持 root 启动机制；本工程没有伪造或绕过系统权限限制。

## 构建验证

此归档中的修改已做 Swift 语法解析与三个 plist 的格式校验。完整 iOS 构建、签名和真机 root/PTY 验证需要 macOS、Xcode/iOS SDK、项目依赖及实际设备环境；在 Linux 容器中无法完成这些设备级验证。

## 参考

- TrollStore `spawnRoot` 实现：<https://github.com/opa334/TrollStore/blob/main/Shared/TSUtil.m>
- TrollStore 兼容性与系统限制：<https://theapplewiki.com/wiki/TrollStore>
- Santander 上游项目：<https://github.com/NSAntoine/Santander>
- TrollStore 官方 README（Unsandboxing / Santander Helpers）：<https://github.com/opa334/TrollStore/blob/main/README.md>


## UI 稳定性复查（2026-11-11）

- 保留原有 TrollStore / root helper 构建路径与默认文件系统行为；本次没有把工程改成普通沙盒预览版。
- 列表页固定底栏不再作为 `UITableView` 的滚动子视图，而是作为当前 `PathListViewController` 独立的导航栏覆盖视图；延后到 `viewDidAppear`（导航转场结束后）再安装，push 时隐藏，pop 时移除，返回时复用当前控制器自己的实例。deinit 时清理遗留覆盖视图，避免切换标签/替换导航栈后留下悬空底栏。
- 底栏高度根据导航容器的安全区域更新；内容 inset 只在值实际变化时修改，避免每次 layout pass 重复写入。底栏恢复也延后到 `viewDidAppear`，不在转场中抢导航容器的视图层级。
- 目录状态刷新只检查当前进程的文件系统写权限，不在绘制锁图标时启动特权进程；真正的文件操作仍使用原有 SantanderHelper 调用链。
- Diffable data source 的 cell provider 使用弱引用；列表、网格、设置、主题、工具和应用信息页面对过期 IndexPath / 不匹配行项目增加了边界保护，避免 UI 更新期间的强制转换或 `fatalError`。
- 空状态改用 `UITableView.backgroundView`，不再把固定空状态面板插入滚动内容视图；网格在首轮布局宽度为 0 时不计算 cell 尺寸，防止出现负宽度；diffable 列表对重复路径标识去重。
- 对近期/文件关联/权限编辑/跳转建议/标签页等表格回调补充过期 IndexPath 边界检查；意外设置行不再走 `fatalError`。
- 右侧操作表单在 iPad popover fallback 中取消强制解包 presenter view；Helper 重命名后修复了 helper 子进程的父路径白名单判断。
- 未拿到设备崩溃日志，也不能在本环境运行 iOS 18 真机；这些是静态源码检查定位到的风险点与修复，不能据此断言已百分之百排除设备闪退。
