# Santander UI refresh — Filza-style PNG assets

## Design reference

This revision uses publicly visible Filza screenshots as visual references, not copied source code. The target layout is the familiar file-manager structure: a compact path/navigation title, a search + Name/Date/Size + list/grid control strip, dense icon-led file rows, a borderless icon grid, a four-item bottom navigation bar (Recents, Favorites, Settings, Tabs), and contextual file-action sheets.

## PNG icon packs

The folder picker uses the PNG packs already present in `Resources/Assets/theme`:

- `theme/folder*.png`: Default folder and symbolic-link variants.
- `theme/folders/{mac,linux,window,yosemite}*.png`: Mac, Linux, Windows, and Yosemite folder PNGs, including `_link` variants.
- `theme/extensions`, `theme/colorful`, `theme/light`: Default, Colorful, and Light file-type PNG themes.
- Root `theme/*.png`: the supplied Filza-style UI icons (search, list, grid, sort, favorites, recents, settings, tabs, copy, move, rename, delete, properties, paste, new file/folder, open-in, etc.).

Folder icons are loaded from PNG files. No programmatically drawn folder artwork or color-overlay folder renderer is used. The selected pack is resolved directly; missing folder variants use an explicit `noicon` placeholder instead of silently reverting to the Default pack. File-type misses use the generic-file PNG from the selected pack. `Path.displayImage` is computed so changing a theme invalidates caches and refreshes visible file lists, grid cells, favorites, and other list-based screens.

## Browser layout and motion

- List and grid share the same top strip: search, Name, Date, Size, and view switch.
- Grid cells are cardless and use the file PNGs with centered filenames.
- Redundant Paste/New footer cards and the duplicate operation shortcut in the bottom bar were removed. File actions remain in the navigation-bar menu/action sheet.
- Bottom navigation and browser controls use the bundled Filza PNG artwork, not substitute SF Symbols when a matching asset exists.
- Browser push/pop uses a slower 0.72s eased spring/parallax transition; theme application crossfades, action sheets have slower eased entrances/exits, and control feedback is low-amplitude. Reduce Motion is respected.

## Build and verification

- The included GitHub Actions workflow selects Xcode 16.4, builds the iOS 16.5 SDK dependency as configured, prepares SwiftTerm 1.2.1 with the current NSLog compatibility patch, then builds the IPA and runs CI smoke tests.
- Local static checks completed: `swiftc -frontend -parse Santander.swift`, `swiftc -frontend -parse RootHelper/helper.swift`, Makefile dry-run, workflow YAML parsing, Bash syntax checks, and validation that every literal toolbar/interface PNG reference exists.
- This environment does not have Xcode or the iOS SDK; a full Apple-platform build and device screenshot comparison have not been performed.

## Public references consulted

- TIGI Software Filza User Guide (theme configuration and PNG theme/folder asset format): https://www.tigisoftware.com/default/?page_id=177
- TIGI Software Filza update page: https://www.tigisoftware.com/default/?p=439
- Public Filza browser, action-sheet, and theme-selection screenshots: https://kubadownload.com/news/filza-file-manager/ and https://cloud.tencent.com/developer/news/1941920

The supplied reverse-analysis ZIP contains static analysis results; it does not include image screenshots. Publicly available screenshots and the bundled PNG resources were therefore used as the visual source of truth.
