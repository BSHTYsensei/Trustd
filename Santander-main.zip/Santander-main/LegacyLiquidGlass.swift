import Foundation
import UIKit
import SwiftUI
import Metal
import MetalKit
import QuartzCore
import CoreVideo
import simd
import ObjectiveC

private let llScrollViewDidScrollNotification = Notification.Name("UIScrollViewDidScrollNotification")
private let llScrollViewDidEndScrollingAnimationNotification = Notification.Name("UIScrollViewDidEndScrollingAnimationNotification")

public enum LegacyLiquidGlass {
    public static let version = "8.0-final-optical-material-engine-ios13-18"
    public static let minimumOS = 13

    public enum Backend: Equatable { case automatic, legacy }

    public enum Quality: Int, CaseIterable, Sendable {
        case low = 0, medium = 1, high = 2, ultra = 3

        fileprivate var captureFPS: Int {
            switch self {
            case .low: return 10
            case .medium: return 15
            case .high: return 24
            case .ultra: return 30
            }
        }

        fileprivate var shaderTaps: Int {
            switch self {
            case .low: return 1
            case .medium: return 2
            case .high: return 3
            case .ultra: return 4
            }
        }

        fileprivate var shaderQuality: CGFloat {
            switch self {
            case .low: return 0.0
            case .medium: return 1.0
            case .high: return 2.0
            case .ultra: return 3.0
            }
        }

        fileprivate var dispersionEnabled: Bool {
            switch self {
            case .low, .medium: return false
            case .high, .ultra: return true
            }
        }

        fileprivate var blurPyramidLevels: Int {
            switch self {
            case .low: return 1
            case .medium: return 2
            case .high: return 3
            case .ultra: return 4
            }
        }
    }

    public enum Style {
        case regular, clear, prominent
        case tinted(UIColor)
        case custom(tint: UIColor, opacity: CGFloat, blur: CGFloat)
    }

    public struct Configuration {
        public var backend: Backend = .automatic
        public var quality: Quality = .high
        public var adaptiveQuality: Bool = true
        public var style: Style = .regular
        public var cornerRadius: CGFloat = 24
        public var opacity: CGFloat = 1
        public var blurRadius: CGFloat = 18
        public var tintStrength: CGFloat = 0.12
        public var specularStrength: CGFloat = 0.34
        public var edgeLightStrength: CGFloat = 0.36
        public var refractionStrength: CGFloat = 0.026
        public var refractionScale: CGFloat = 0.90
        public var highlightWidth: CGFloat = 0.18
        public var rimWidth: CGFloat = 0.075
        public var lensThickness: CGFloat = 0.45
        public var dispersionStrength: CGFloat = 0.0
        public var fresnelPower: CGFloat = 2.5
        public var saturation: CGFloat = 1.04
        public var contrast: CGFloat = 1.02
        public var shadowOpacity: Float = 0.16
        public var shadowRadius: CGFloat = 20
        public var shadowOffset = CGSize(width: 0, height: 10)
        public var interactive = true
        public var morphing = true
        public var animated = true
        public var liveCapture = true
        public var captureScale: CGFloat = 0
        public var maxCapturePixels: Int = 900_000
        public var preferredFrameRate: Int = 60
        public var maxRenderScale: CGFloat = 2.0
        public var sharedSurface = true
        public var reduceEffectsForBattery = true
        public var cacheStaticBackdrops = true
        public var enableDiagnostics = false
        public var pointerInteraction = true
        public var morphSmoothness: CGFloat = 0.35

        public var opticalThickness: CGFloat = 0.42
        public var indexOfRefraction: CGFloat = 1.48
        public var materialRoughness: CGFloat = 0.14
        public var environmentLightStrength: CGFloat = 0.34
        public var absorptionStrength: CGFloat = 0.14
        public var normalStrength: CGFloat = 0.42
        public var reflectionMix: CGFloat = 0.22
        public var refractionChroma: CGFloat = 0.010

        public var bevelWidth: CGFloat = 0.24
        public var curvatureStrength: CGFloat = 0.34
        public var microRoughness: CGFloat = 0.11
        public var environmentOffset: CGFloat = 0.055
        public var dynamicLightStrength: CGFloat = 0.82
        public var interactionStrength: CGFloat = 0.90
        public var depthAttenuation: CGFloat = 0.76
        public var edgeDispersion: CGFloat = 0.65
        public var liveCaptureDuringScroll: Bool = true
        public var useDeepBlur: Bool = true
        public var idleFrameRate: Int = 30
        public var maximumMorphShapes: Int = 32

        public init() {}
    }

    public static var configuration = Configuration() {
        didSet {
            Task { @MainActor in
                LLGlassFrameTicker.shared.refreshRateChanged()
            }
            Task { @MainActor in
                LLGlassBackdropCoordinatorRegistry.shared.invalidateAll()
            }
        }
    }

    public static var effectiveBackend: Backend {
        let environment = LLGlassEnvironment.shared
        let usesLegacy = configuration.backend == .legacy
            || !LLMetalShared.isUsable
            || effectiveQuality(for: configuration) == .low
            || environment.reduceTransparency
        return usesLegacy ? .legacy : .automatic
    }

    public static func effectiveQuality(for configuration: Configuration) -> Quality {
        configuration.adaptiveQuality ? LLGlassPerformanceGovernor.shared.currentQuality : configuration.quality
    }

    @MainActor
    public static func invalidateBackdrop(for window: UIWindow? = nil) {
        guard LLMetalShared.isUsable else { return }
        if let window = window {
            LLGlassBackdropCoordinatorRegistry.shared.coordinator(for: window).markDirty()
        } else {
            LLGlassBackdropCoordinatorRegistry.shared.invalidateAll()
        }
    }

    @MainActor
    public static func sceneDidChange(in window: UIWindow) {
        guard LLMetalShared.isUsable else { return }
        LLGlassBackdropCoordinatorRegistry.shared.coordinator(for: window).markDirty()
    }

    public static func start() { LLGlassBootstrap.start() }
    public static func stop() { LLGlassBootstrap.stop() }
}

public final class LLGlassEnvironment {
    public static let shared = LLGlassEnvironment()

    public private(set) var reduceMotion = UIAccessibility.isReduceMotionEnabled
    public private(set) var reduceTransparency = UIAccessibility.isReduceTransparencyEnabled
    public private(set) var darkerSystemColors = UIAccessibility.isDarkerSystemColorsEnabled
    public private(set) var boldText = UIAccessibility.isBoldTextEnabled
    public private(set) var increaseContrast = UIAccessibility.isDarkerSystemColorsEnabled

    private var observers: [NSObjectProtocol] = []

    private init() {
        let names: [Notification.Name] = [
            UIAccessibility.reduceMotionStatusDidChangeNotification,
            UIAccessibility.reduceTransparencyStatusDidChangeNotification,
            UIAccessibility.darkerSystemColorsStatusDidChangeNotification,
            UIAccessibility.boldTextStatusDidChangeNotification,
            UIAccessibility.invertColorsStatusDidChangeNotification
        ]
        for name in names {
            observers.append(NotificationCenter.default.addObserver(forName: name, object: nil, queue: .main) { [weak self] _ in
                self?.refresh()
            })
        }
        observers.append(NotificationCenter.default.addObserver(forName: .LLGlassThemeDidChange, object: nil, queue: .main) { [weak self] _ in
            self?.refresh()
        })
    }

    deinit { observers.forEach(NotificationCenter.default.removeObserver) }

    public func refresh() {
        reduceMotion = UIAccessibility.isReduceMotionEnabled
        reduceTransparency = UIAccessibility.isReduceTransparencyEnabled
        darkerSystemColors = UIAccessibility.isDarkerSystemColorsEnabled
        boldText = UIAccessibility.isBoldTextEnabled
        increaseContrast = UIAccessibility.isDarkerSystemColorsEnabled
        NotificationCenter.default.post(name: .LLGlassEnvironmentDidChange, object: self)
    }
}

public extension Notification.Name {
    static let LLGlassEnvironmentDidChange = Notification.Name("LegacyLiquidGlass.EnvironmentDidChange")
    static let LLGlassThemeDidChange = Notification.Name("LegacyLiquidGlass.ThemeDidChange")
    static let LLGlassPerformanceDidChange = Notification.Name("LegacyLiquidGlass.PerformanceDidChange")
}

public struct LLGlassMaterial {
    public var tint: UIColor?
    public var opacity: CGFloat
    public var blurRadius: CGFloat
    public var refraction: CGFloat
    public var specular: CGFloat
    public var edgeLight: CGFloat
    public var darkness: CGFloat
    public var saturation: CGFloat
    public var contrast: CGFloat
    public var scale: CGFloat
    public var lensThickness: CGFloat
    public var dispersion: CGFloat
    public var fresnelPower: CGFloat
    public var roughness: CGFloat
    public var absorption: CGFloat
    public var ior: CGFloat
    public var environmentLight: CGFloat
    public var reflectionMix: CGFloat
    public var normalStrength: CGFloat
    public var bevelWidth: CGFloat
    public var curvatureStrength: CGFloat
    public var microRoughness: CGFloat
    public var environmentOffset: CGFloat
    public var dynamicLightStrength: CGFloat
    public var interactionStrength: CGFloat
    public var depthAttenuation: CGFloat
    public var edgeDispersion: CGFloat

    public init(
        tint: UIColor? = nil,
        opacity: CGFloat = 1,
        blurRadius: CGFloat = 18,
        refraction: CGFloat = 0.016,
        specular: CGFloat = 0.28,
        edgeLight: CGFloat = 0.34,
        darkness: CGFloat = 0.03,
        saturation: CGFloat = 1.05,
        contrast: CGFloat = 1.025,
        scale: CGFloat = 0.58,
        lensThickness: CGFloat = 0.45,
        dispersion: CGFloat = 0.15,
        fresnelPower: CGFloat = 2.5,
        roughness: CGFloat = 0.14,
        absorption: CGFloat = 0.14,
        ior: CGFloat = 1.48,
        environmentLight: CGFloat = 0.34,
        reflectionMix: CGFloat = 0.22,
        normalStrength: CGFloat = 0.42,
        bevelWidth: CGFloat = 0.24,
        curvatureStrength: CGFloat = 0.34,
        microRoughness: CGFloat = 0.11,
        environmentOffset: CGFloat = 0.055,
        dynamicLightStrength: CGFloat = 0.82,
        interactionStrength: CGFloat = 0.90,
        depthAttenuation: CGFloat = 0.76,
        edgeDispersion: CGFloat = 0.65
    ) {
        self.tint = tint
        self.opacity = opacity
        self.blurRadius = blurRadius
        self.refraction = refraction
        self.specular = specular
        self.edgeLight = edgeLight
        self.darkness = darkness
        self.saturation = saturation
        self.contrast = contrast
        self.scale = scale
        self.lensThickness = lensThickness
        self.dispersion = dispersion
        self.fresnelPower = fresnelPower
        self.roughness = roughness
        self.absorption = absorption
        self.ior = ior
        self.environmentLight = environmentLight
        self.reflectionMix = reflectionMix
        self.normalStrength = normalStrength
        self.bevelWidth = bevelWidth
        self.curvatureStrength = curvatureStrength
        self.microRoughness = microRoughness
        self.environmentOffset = environmentOffset
        self.dynamicLightStrength = dynamicLightStrength
        self.interactionStrength = interactionStrength
        self.depthAttenuation = depthAttenuation
        self.edgeDispersion = edgeDispersion
    }

    public static var regular: LLGlassMaterial { LLGlassMaterial() }

    public static var liquidGlass: LLGlassMaterial { opticalRegular }

    public static var opticalRegular: LLGlassMaterial {
        LLGlassMaterial(
            opacity: 1.0, blurRadius: 18, refraction: 0.020, specular: 0.31,
            edgeLight: 0.36, darkness: 0.025, saturation: 1.04, contrast: 1.02,
            scale: 0.60, lensThickness: 0.42, dispersion: 0.010, fresnelPower: 2.5,
            roughness: 0.14, absorption: 0.14, ior: 1.48,
            environmentLight: 0.34, reflectionMix: 0.22, normalStrength: 0.42,
            bevelWidth: 0.24, curvatureStrength: 0.34, microRoughness: 0.11,
            environmentOffset: 0.055, dynamicLightStrength: 0.82, interactionStrength: 0.90,
            depthAttenuation: 0.76, edgeDispersion: 0.65
        )
    }

    public static var clear: LLGlassMaterial {
        LLGlassMaterial(opacity: 0.90, blurRadius: 10, refraction: 0.010, specular: 0.20,
                        edgeLight: 0.26, darkness: 0.02, saturation: 1.0, contrast: 1.01,
                        scale: 0.72, lensThickness: 0.30, dispersion: 0.08, fresnelPower: 3.0,
                        roughness: 0.08, absorption: 0.08, ior: 1.46,
                        environmentLight: 0.28, reflectionMix: 0.16, normalStrength: 0.30,
                        bevelWidth: 0.18, curvatureStrength: 0.28, microRoughness: 0.08,
                        environmentOffset: 0.040, dynamicLightStrength: 0.70, interactionStrength: 0.80,
                        depthAttenuation: 0.62, edgeDispersion: 0.50)
    }

    public static var prominent: LLGlassMaterial {
        LLGlassMaterial(opacity: 1.0, blurRadius: 24, refraction: 0.020, specular: 0.34,
                        edgeLight: 0.40, darkness: 0.06, saturation: 1.08, contrast: 1.04,
                        scale: 0.54, lensThickness: 0.55, dispersion: 0.22, fresnelPower: 2.2,
                        roughness: 0.18, absorption: 0.18, ior: 1.50,
                        environmentLight: 0.40, reflectionMix: 0.28, normalStrength: 0.50,
                        bevelWidth: 0.30, curvatureStrength: 0.42, microRoughness: 0.15,
                        environmentOffset: 0.070, dynamicLightStrength: 0.92, interactionStrength: 1.0,
                        depthAttenuation: 0.82, edgeDispersion: 0.78)
    }

    public func tinted(_ color: UIColor) -> LLGlassMaterial {
        var copy = self; copy.tint = color; return copy
    }

    public func adjusted(quality: LegacyLiquidGlass.Quality, reduceTransparency: Bool, reduceMotion: Bool) -> LLGlassMaterial {
        var copy = self
        let multiplier: CGFloat
        switch quality {
        case .low: multiplier = 0.55
        case .medium: multiplier = 0.72
        case .high: multiplier = 1.0
        case .ultra: multiplier = 1.16
        }
        copy.blurRadius *= multiplier
        copy.refraction *= multiplier
        copy.specular *= multiplier
        copy.edgeLight *= multiplier
        copy.environmentLight *= multiplier
        copy.reflectionMix *= multiplier
        copy.normalStrength *= multiplier
        copy.bevelWidth *= multiplier
        copy.curvatureStrength *= multiplier
        copy.microRoughness = (copy.microRoughness * multiplier).clamped(to: 0...1)
        copy.environmentOffset *= multiplier
        copy.dynamicLightStrength *= multiplier
        copy.interactionStrength *= multiplier
        copy.depthAttenuation *= multiplier
        copy.edgeDispersion *= multiplier
        if !quality.dispersionEnabled {
            copy.dispersion = 0
        }
        if reduceTransparency {
            copy.opacity = min(1, copy.opacity + 0.16)
            copy.blurRadius *= 0.60
            copy.refraction = 0
            copy.lensThickness = 0
            copy.dispersion = 0
            copy.reflectionMix *= 0.35
            copy.environmentLight *= 0.55
            copy.normalStrength *= 0.55
        }
        if reduceMotion {
            copy.refraction *= 0.45
            copy.normalStrength *= 0.70
        }
        return copy
    }
}

public enum LLGlassMaterialResolver {
    public static func resolve(_ configuration: LegacyLiquidGlass.Configuration, environment: LLGlassEnvironment = .shared) -> LLGlassMaterial {
        let base: LLGlassMaterial
        switch configuration.style {
        case .regular: base = .regular
        case .clear: base = .clear
        case .prominent: base = .prominent
        case .tinted(let color): base = .regular.tinted(color)
        case let .custom(tint, opacity, blur): base = LLGlassMaterial(tint: tint, opacity: opacity, blurRadius: blur)
        }
        var material = base
        material.opacity *= configuration.opacity
        material.blurRadius = max(0, configuration.blurRadius)
        material.refraction = configuration.refractionStrength
        material.specular = configuration.specularStrength
        material.edgeLight = configuration.edgeLightStrength
        let legacyDispersion = configuration.dispersionStrength * 0.067
        material.dispersion = (legacyDispersion + configuration.refractionChroma)
            .clamped(to: 0...0.05)
        material.fresnelPower = configuration.fresnelPower
        material.roughness = configuration.materialRoughness
        material.absorption = configuration.absorptionStrength
        material.ior = configuration.indexOfRefraction
        material.environmentLight = configuration.environmentLightStrength
        material.reflectionMix = configuration.reflectionMix
        material.normalStrength = configuration.normalStrength
        material.bevelWidth = configuration.bevelWidth
        material.curvatureStrength = configuration.curvatureStrength
        material.microRoughness = configuration.microRoughness
        material.environmentOffset = configuration.environmentOffset
        material.dynamicLightStrength = configuration.dynamicLightStrength
        material.interactionStrength = configuration.interactionStrength
        material.depthAttenuation = configuration.depthAttenuation
        material.edgeDispersion = configuration.edgeDispersion
        material.lensThickness = max(0, configuration.lensThickness)
            * (configuration.opticalThickness / 0.45)
        material.saturation = configuration.saturation
        material.contrast = configuration.contrast
        let quality = LegacyLiquidGlass.effectiveQuality(for: configuration)
        return material.adjusted(quality: quality,
                                 reduceTransparency: environment.reduceTransparency,
                                 reduceMotion: environment.reduceMotion)
    }
}

public final class LLGlassPerformanceGovernor: NSObject {
    public static let shared = LLGlassPerformanceGovernor()

    public private(set) var currentQuality: LegacyLiquidGlass.Quality
    public private(set) var measuredFPS: Double = 60
    public private(set) var measuredGPUTime: Double = 0
    public private(set) var measuredCaptureTime: Double = 0
    public private(set) var thermalState: ProcessInfo.ThermalState = ProcessInfo.processInfo.thermalState
    public private(set) var activeGlassCount: Int = 0
    public var isScrolling: Bool {
        lock.lock()
        let value = scrollActive
        lock.unlock()
        return value
    }

    private var displayLink: CADisplayLink?
    private var lastTimestamp: CFTimeInterval = 0
    private var sampleAccumulator: CFTimeInterval = 0
    private var frameCount = 0
    private let lock = NSLock()
    private var started = false
    private var totalGlassArea: CGFloat = 0
    private var scrollActive = false
    private var gpuTimeSamples: [Double] = []
    private var captureTimeSamples: [Double] = []
    private var qualityChangeTime: CFTimeInterval = 0

    private override init() {
        currentQuality = LegacyLiquidGlass.configuration.quality
        super.init()
        NotificationCenter.default.addObserver(self, selector: #selector(thermalDidChange),
                                               name: ProcessInfo.thermalStateDidChangeNotification, object: nil)
    }

    deinit {
        displayLink?.invalidate()
        NotificationCenter.default.removeObserver(self)
    }

    public func start() {
        lock.lock()
        if started { lock.unlock(); return }
        started = true
        lock.unlock()
        let link = CADisplayLink(target: self, selector: #selector(tick(_:)))
        link.preferredFramesPerSecond = min(max(LegacyLiquidGlass.configuration.preferredFrameRate, 30), 60)
        link.add(to: .main, forMode: .common)
        displayLink = link
    }

    public func stop() {
        lock.lock(); started = false; lock.unlock()
        displayLink?.invalidate(); displayLink = nil
    }

    public func registerGlass(area: CGFloat = 0) {
        lock.lock()
        activeGlassCount += 1
        totalGlassArea += area
        lock.unlock()
    }

    public func unregisterGlass(area: CGFloat = 0) {
        lock.lock()
        activeGlassCount = max(0, activeGlassCount - 1)
        totalGlassArea = max(0, totalGlassArea - area)
        lock.unlock()
    }

    public func recordGPUTime(_ seconds: Double) {
        lock.lock()
        gpuTimeSamples.append(seconds)
        if gpuTimeSamples.count > 30 { gpuTimeSamples.removeFirst() }
        measuredGPUTime = gpuTimeSamples.reduce(0, +) / Double(gpuTimeSamples.count)
        lock.unlock()
    }

    public func recordCaptureTime(_ seconds: Double) {
        lock.lock()
        captureTimeSamples.append(seconds)
        if captureTimeSamples.count > 20 { captureTimeSamples.removeFirst() }
        measuredCaptureTime = captureTimeSamples.reduce(0, +) / Double(captureTimeSamples.count)
        lock.unlock()
    }

    public func chooseQuality() -> LegacyLiquidGlass.Quality {
        guard LegacyLiquidGlass.configuration.reduceEffectsForBattery else {
            return LegacyLiquidGlass.configuration.quality
        }
        let thermal = ProcessInfo.processInfo.thermalState
        lock.lock()
        let fps = measuredFPS
        let count = activeGlassCount
        let area = totalGlassArea
        let scrolling = scrollActive
        let gpuTime = measuredGPUTime
        let captureTime = measuredCaptureTime
        lock.unlock()

        if thermal == .critical || thermal == .serious { return .low }
        if fps < 25 { return .low }
        if captureTime > 0.020 { return .low }
        if gpuTime > 0.014 { return .low }
        if area > 1_500_000 || count > 15 { return .medium }
        if fps < 38 { return .medium }
        if captureTime > 0.014 { return .medium }
        if gpuTime > 0.010 { return .medium }
        if scrolling { return .medium }
        if count > 8 || area > 800_000 { return .high }
        if fps < 50 { return .high }
        return LegacyLiquidGlass.configuration.quality
    }

    @objc private func tick(_ link: CADisplayLink) {
        if lastTimestamp == 0 { lastTimestamp = link.timestamp; return }
        let delta = link.timestamp - lastTimestamp
        lastTimestamp = link.timestamp
        guard delta > 0.0001 else { return }
        frameCount += 1
        sampleAccumulator += delta
        if sampleAccumulator >= 1.0 {
            lock.lock()
            measuredFPS = Double(frameCount) / sampleAccumulator
            lock.unlock()
            frameCount = 0
            sampleAccumulator = 0
            let next = chooseQuality()
            let now = CACurrentMediaTime()
            let downgrade = next.rawValue < currentQuality.rawValue
            let minimumDwell: CFTimeInterval = downgrade ? 0.8 : 2.4
            if next != currentQuality && now - qualityChangeTime >= minimumDwell {
                currentQuality = next
                qualityChangeTime = now
                NotificationCenter.default.post(name: .LLGlassPerformanceDidChange, object: self)
            }
        }
    }

    @objc private func thermalDidChange() {
        thermalState = ProcessInfo.processInfo.thermalState
        NotificationCenter.default.post(name: .LLGlassPerformanceDidChange, object: self)
    }

    public func setScrollActive(_ active: Bool) {
        lock.lock()
        scrollActive = active
        lock.unlock()
    }
}

public enum LLGlassColorMath {
    public static func components(_ color: UIColor) -> SIMD4<Float> {
        var r: CGFloat = 0, g: CGFloat = 0, b: CGFloat = 0, a: CGFloat = 0
        if color.getRed(&r, green: &g, blue: &b, alpha: &a) {
            return SIMD4(Float(r), Float(g), Float(b), Float(a))
        }
        var white: CGFloat = 0
        color.getWhite(&white, alpha: &a)
        return SIMD4(Float(white), Float(white), Float(white), Float(a))
    }

    public static func appearanceTint() -> UIColor {
        UIColor { traits in
            traits.userInterfaceStyle == .dark ? UIColor(white: 1, alpha: 0.10) : UIColor(white: 1, alpha: 0.20)
        }
    }

    public static func blend(_ a: UIColor, _ b: UIColor, amount: CGFloat) -> UIColor {
        let ca = components(a); let cb = components(b)
        let t = max(0, min(1, amount))
        return UIColor(
            red: CGFloat(ca.x + (cb.x - ca.x) * Float(t)),
            green: CGFloat(ca.y + (cb.y - ca.y) * Float(t)),
            blue: CGFloat(ca.z + (cb.z - ca.z) * Float(t)),
            alpha: CGFloat(ca.w + (cb.w - ca.w) * Float(t))
        )
    }
}

public enum LLGlassGeometry {
    public static func roundedPath(bounds: CGRect, radius: CGFloat) -> UIBezierPath {
        UIBezierPath(roundedRect: bounds, cornerRadius: min(max(radius, 0), min(bounds.width, bounds.height) * 0.5))
    }
    public static func insetRadius(_ radius: CGFloat, inset: CGFloat) -> CGFloat { max(0, radius - inset) }
}

@MainActor
public final class LLGlassExclusionRegistry {
    public static let shared = LLGlassExclusionRegistry()
    private var views = NSHashTable<UIView>.weakObjects()

    private init() {}

    public func register(_ view: UIView) {
        views.add(view)
    }

    public func unregister(_ view: UIView) {
        views.remove(view)
    }

    public func hideAll(in window: UIWindow) -> [UIView: Bool] {
        var states: [UIView: Bool] = [:]
        for view in views.allObjects where view.window === window {
            states[view] = view.isHidden
            view.isHidden = true
        }
        return states
    }

    public func restore(_ states: [UIView: Bool]) {
        for (view, wasHidden) in states {
            view.isHidden = wasHidden
        }
    }
}

public final class LLBackdropSnapshot: NSObject {
    public let texture: MTLTexture
    public let rect: CGRect
    public let size: CGSize
    public let timestamp: CFTimeInterval
    private let backingTexture: CVMetalTexture?

    public init(texture: MTLTexture,
                rect: CGRect,
                timestamp: CFTimeInterval = CACurrentMediaTime(),
                backingTexture: CVMetalTexture? = nil) {
        self.texture = texture
        self.rect = rect
        self.size = rect.size
        self.timestamp = timestamp
        self.backingTexture = backingTexture
        super.init()
    }
}

private final class LLWeakUIViewBox {
    weak var view: UIView?
    init(_ view: UIView) { self.view = view }
}

@MainActor
public final class LLGlassBackdropCoordinator {
    @MainActor
    public static let shared = LLGlassBackdropCoordinator()

    private weak var window: UIWindow?
    private var latestSnapshot: LLBackdropSnapshot?
    private var lastCaptureTime: CFTimeInterval = 0
    private var lastCaptureWindowSize: CGSize = .zero
    private var isRendering = false
    private var scrollActive = false
    private var dirty = true
    private var scrollEndWork: DispatchWorkItem?
    private var textureCache: CVMetalTextureCache?
    private var pixelBufferPools: [UInt64: CVPixelBufferPool] = [:]
    private var poolLRU: [UInt64] = []
    private let maxPoolCount = 4
    private var captureRequests: [ObjectIdentifier: (scale: CGFloat, maxPixels: Int, cacheStatic: Bool, liveCapture: Bool, quality: LegacyLiquidGlass.Quality)] = [:]
    private var captureRegionViews: [ObjectIdentifier: LLWeakUIViewBox] = [:]
    private var notificationObservers: [NSObjectProtocol] = []

    fileprivate init(window: UIWindow? = nil) {
        let device = MTLCreateSystemDefaultDevice()
        self.window = window

        var cache: CVMetalTextureCache?
        if let device = device {
            CVMetalTextureCacheCreate(kCFAllocatorDefault, nil, device, nil, &cache)
        }
        textureCache = cache

        notificationObservers.append(
            NotificationCenter.default.addObserver(
                forName: llScrollViewDidScrollNotification,
                object: nil,
                queue: .main
            ) { [weak self] notification in
                guard let scrollView = notification.object as? UIScrollView else { return }
                Task { @MainActor [weak self, weak scrollView] in
                    guard let self = self,
                          let scrollView = scrollView,
                          scrollView.window === self.window else { return }
                    self.scrollActive = true
                    self.markDirty()
                    self.scrollEndWork?.cancel()
                    let work = DispatchWorkItem { [weak self] in
                        Task { @MainActor [weak self] in
                            self?.scrollActive = false
                        }
                    }
                    self.scrollEndWork = work
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.18, execute: work)
                }
            }
        )

        notificationObservers.append(
            NotificationCenter.default.addObserver(
                forName: UIApplication.didEnterBackgroundNotification,
                object: nil,
                queue: .main
            ) { [weak self] _ in
                Task { @MainActor [weak self] in
                    self?.latestSnapshot = nil
                    self?.dirty = true
                }
            }
        )
    }

    deinit {
        scrollEndWork?.cancel()
        notificationObservers.forEach(NotificationCenter.default.removeObserver)
    }

    public func attach(to window: UIWindow) {
        self.window = window
        dirty = true
    }

    public func register(owner: AnyObject,
                         captureScale: CGFloat,
                         maxCapturePixels: Int,
                         cacheStatic: Bool = LegacyLiquidGlass.configuration.cacheStaticBackdrops,
                         liveCapture: Bool = LegacyLiquidGlass.configuration.liveCapture,
                         quality: LegacyLiquidGlass.Quality = LegacyLiquidGlass.configuration.quality) {
        captureRequests[ObjectIdentifier(owner)] = (
            scale: max(0, min(2.0, captureScale)),
            maxPixels: max(1, maxCapturePixels),
            cacheStatic: cacheStatic,
            liveCapture: liveCapture,
            quality: quality
        )
        if let view = owner as? UIView {
            captureRegionViews[ObjectIdentifier(view)] = LLWeakUIViewBox(view)
        }
        dirty = true
    }

    public func unregister(owner: AnyObject) {
        unregister(ownerIdentifier: ObjectIdentifier(owner))
    }

    public func unregister(ownerIdentifier identifier: ObjectIdentifier) {
        captureRegionViews.removeValue(forKey: identifier)
        captureRequests.removeValue(forKey: identifier)
        dirty = true
    }

    public func markDirty() {
        dirty = true
    }

    public var hasDirtyBackdrop: Bool { dirty }

    public func setScrollActive(_ active: Bool) {
        scrollActive = active
        dirty = true
        if active {
            scrollEndWork?.cancel()
        } else {
            scrollEndWork?.cancel()
            let work = DispatchWorkItem { [weak self] in
                Task { @MainActor [weak self] in
                    self?.markDirty()
                }
            }
            scrollEndWork = work
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.15, execute: work)
        }
    }

    public func snapshot() -> LLBackdropSnapshot? {
        latestSnapshot
    }

    public func purge() {
        for pool in pixelBufferPools.values {
            CVPixelBufferPoolFlush(pool, .excessBuffers)
        }
        pixelBufferPools.removeAll(keepingCapacity: true)
        poolLRU.removeAll(keepingCapacity: true)
        dirty = true
        latestSnapshot = nil
        lastCaptureWindowSize = .zero
    }

    @discardableResult
    public func requestCapture(force: Bool = false) -> LLBackdropSnapshot? {
        guard let window = window, !window.bounds.isEmpty else { return nil }

        let now = CACurrentMediaTime()
        let shouldCacheStatic = captureRequests.isEmpty
            ? LegacyLiquidGlass.configuration.cacheStaticBackdrops
            : captureRequests.values.allSatisfy { $0.cacheStatic }
        let hasLiveCapture = captureRequests.values.contains { $0.liveCapture }

        if !force, let latestSnapshot, shouldCacheStatic, !hasLiveCapture, !dirty {
            return latestSnapshot
        }

        let captureFPS = captureRequests.values.map { $0.quality.captureFPS }.min() ?? LegacyLiquidGlass.Quality.high.captureFPS
        let interval: CFTimeInterval = scrollActive
            ? (hasLiveCapture ? 1.0 / 15.0 : 1.0 / 12.0)
            : (1.0 / Double(max(1, captureFPS)))
        let sizeChanged = lastCaptureWindowSize != window.bounds.size
        if !force, now - lastCaptureTime < interval, let latestSnapshot, !sizeChanged {
            return latestSnapshot
        }

        guard !isRendering else { return latestSnapshot }
        isRendering = true
        defer { isRendering = false }

        let region = captureRegion(in: window)
        let capture = captureConfiguration(for: region.size)
        let pixelWidth = max(1, Int((region.width * capture.scale).rounded(.up)))
        let pixelHeight = max(1, Int((region.height * capture.scale).rounded(.up)))

        guard let pool = pixelBufferPool(width: pixelWidth, height: pixelHeight) else {
            return latestSnapshot
        }

        var pixelBuffer: CVPixelBuffer?
        let status = CVPixelBufferPoolCreatePixelBuffer(kCFAllocatorDefault, pool, &pixelBuffer)
        guard status == kCVReturnSuccess, let buffer = pixelBuffer else {
            return latestSnapshot
        }

        CVPixelBufferLockBaseAddress(buffer, [])
        defer { CVPixelBufferUnlockBaseAddress(buffer, []) }

        guard let baseAddress = CVPixelBufferGetBaseAddress(buffer),
              let textureCache else {
            return latestSnapshot
        }

        let bytesPerRow = CVPixelBufferGetBytesPerRow(buffer)
        let colorSpace = CGColorSpaceCreateDeviceRGB()
        let bitmapInfo = CGBitmapInfo(
            rawValue: CGImageAlphaInfo.premultipliedFirst.rawValue |
                      CGBitmapInfo.byteOrder32Little.rawValue
        )

        guard let context = CGContext(
            data: baseAddress,
            width: pixelWidth,
            height: pixelHeight,
            bitsPerComponent: 8,
            bytesPerRow: bytesPerRow,
            space: colorSpace,
            bitmapInfo: bitmapInfo.rawValue
        ) else {
            return latestSnapshot
        }

        context.translateBy(x: 0, y: CGFloat(pixelHeight))
        context.scaleBy(x: capture.scale, y: -capture.scale)
        context.translateBy(x: -region.minX, y: -region.minY)

        let captureStart = CACurrentMediaTime()
        let hiddenStates = LLGlassExclusionRegistry.shared.hideAll(in: window)
        defer { LLGlassExclusionRegistry.shared.restore(hiddenStates) }

        UIGraphicsPushContext(context)
        defer { UIGraphicsPopContext() }
        if !window.drawHierarchy(in: region, afterScreenUpdates: false) {
            window.layer.render(in: context)
        }
        LLGlassPerformanceGovernor.shared.recordCaptureTime(CACurrentMediaTime() - captureStart)

        var cvTexture: CVMetalTexture?
        let textureStatus = CVMetalTextureCacheCreateTextureFromImage(
            kCFAllocatorDefault,
            textureCache,
            buffer,
            nil,
            .bgra8Unorm,
            pixelWidth,
            pixelHeight,
            0,
            &cvTexture
        )

        guard textureStatus == kCVReturnSuccess,
              let cvTexture,
              let mtlTexture = CVMetalTextureGetTexture(cvTexture) else {
            return latestSnapshot
        }

        let snapshot = LLBackdropSnapshot(
            texture: mtlTexture,
            rect: region,
            timestamp: now,
            backingTexture: cvTexture
        )

        latestSnapshot = snapshot
        lastCaptureTime = now
        lastCaptureWindowSize = window.bounds.size
        dirty = false
        return snapshot
    }

    private func captureRegion(in window: UIWindow) -> CGRect {
        var union = CGRect.null
        var staleIdentifiers: [ObjectIdentifier] = []
        for owner in captureRequests.keys {
            guard let box = captureRegionViews[owner], let view = box.view else {
                staleIdentifiers.append(owner)
                continue
            }
            if view.window === window, !view.isHidden, view.alpha > 0.001 {
                let frame = view.convert(view.bounds, to: window).intersection(window.bounds)
                if !frame.isNull, !frame.isEmpty { union = union.union(frame) }
            }
        }
        if !staleIdentifiers.isEmpty {
            for identifier in staleIdentifiers { captureRegionViews.removeValue(forKey: identifier) }
        }
        if union.isNull || union.isEmpty { return window.bounds }
        let margin: CGFloat = max(24, min(96, LegacyLiquidGlass.configuration.blurRadius * 2.5))
        return union.insetBy(dx: -margin, dy: -margin).intersection(window.bounds)
    }

    private func captureConfiguration(for size: CGSize) -> (scale: CGFloat, maxPixels: Int) {
        let requests = captureRequests.values
        let maxPixels = max(
            1,
            requests.map { $0.maxPixels }.max() ?? LegacyLiquidGlass.configuration.maxCapturePixels
        )

        let explicitScales = requests.compactMap { $0.scale > 0 ? $0.scale : nil }
        let requestedScale = explicitScales.max() ?? 0
        let windowPixels = max(1.0, size.width * size.height)

        let scale: CGFloat
        if requestedScale > 0 {
            scale = requestedScale
        } else {
            scale = min(1.6, sqrt(CGFloat(maxPixels) / windowPixels))
        }

        let clampedScale = max(0.25, min(2.0, scale))
        let actualPixels = max(1, Int(windowPixels * clampedScale * clampedScale))
        if actualPixels <= maxPixels {
            return (clampedScale, maxPixels)
        }

        let constrained = sqrt(CGFloat(maxPixels) / windowPixels)
        return (max(0.125, min(clampedScale, constrained)), maxPixels)
    }

    private func pixelBufferPool(width: Int, height: Int) -> CVPixelBufferPool? {
        let key = (UInt64(width) << 32) ^ UInt64(height)
        if let existing = pixelBufferPools[key] {
            touchPool(key)
            return existing
        }

        let poolAttributes: [String: Any] = [
            kCVPixelBufferPoolMinimumBufferCountKey as String: 2,
            kCVPixelBufferPoolMaximumBufferAgeKey as String: 1.0
        ]
        let bufferAttributes: [String: Any] = [
            kCVPixelBufferWidthKey as String: width,
            kCVPixelBufferHeightKey as String: height,
            kCVPixelBufferPixelFormatTypeKey as String: kCVPixelFormatType_32BGRA,
            kCVPixelBufferMetalCompatibilityKey as String: true,
            kCVPixelBufferIOSurfacePropertiesKey as String: [:]
        ]

        var pool: CVPixelBufferPool?
        let status = CVPixelBufferPoolCreate(
            kCFAllocatorDefault,
            poolAttributes as CFDictionary,
            bufferAttributes as CFDictionary,
            &pool
        )
        guard status == kCVReturnSuccess, let pool else { return nil }

        pixelBufferPools[key] = pool
        poolLRU.removeAll { $0 == key }
        poolLRU.append(key)

        while poolLRU.count > maxPoolCount {
            let evicted = poolLRU.removeFirst()
            if let evictedPool = pixelBufferPools.removeValue(forKey: evicted) {
                CVPixelBufferPoolFlush(evictedPool, .excessBuffers)
            }
        }

        return pool
    }

    private func touchPool(_ key: UInt64) {
        poolLRU.removeAll { $0 == key }
        poolLRU.append(key)
    }
}

@MainActor
public final class LLGlassBackdropCoordinatorRegistry {
    public static let shared = LLGlassBackdropCoordinatorRegistry()

    private let coordinators = NSMapTable<UIWindow, LLGlassBackdropCoordinator>(
        keyOptions: .weakMemory,
        valueOptions: .strongMemory
    )

    private init() {}

    public func coordinator(for window: UIWindow) -> LLGlassBackdropCoordinator {
        if let existing = coordinators.object(forKey: window) {
            return existing
        }
        let coordinator = LLGlassBackdropCoordinator(window: window)
        coordinators.setObject(coordinator, forKey: window)
        return coordinator
    }

    public func coordinatorIfPresent(for window: UIWindow) -> LLGlassBackdropCoordinator? {
        coordinators.object(forKey: window)
    }

    public func invalidateAll() {
        let enumerator = coordinators.keyEnumerator()
        while let window = enumerator.nextObject() as? UIWindow {
            coordinators.object(forKey: window)?.markDirty()
        }
    }
}

public struct LLGlassShapeDescriptor: Equatable {
    public var center: SIMD2<Float>
    public var halfSize: SIMD2<Float>
    public var cornerRadius: Float
    public var smoothness: Float

    public init(center: SIMD2<Float> = .zero,
                halfSize: SIMD2<Float> = SIMD2(50, 50),
                cornerRadius: Float = 20,
                smoothness: Float = 0.35) {
        self.center = center
        self.halfSize = halfSize
        self.cornerRadius = cornerRadius
        self.smoothness = smoothness
    }

    public static let zero = LLGlassShapeDescriptor(center: .zero, halfSize: .zero, cornerRadius: 0, smoothness: 0)
}

private let llGlassMetalSource = """
#include <metal_stdlib>
using namespace metal;

struct LLVertex { float2 position; float2 uv; };

struct LLShapeGPU {
    float4 geometry;
    float4 optical;
};

struct LLUniforms {
    float4 sizePointer;
    float4 materialA;
    float4 materialB;
    float4 materialC;
    float4 opticalA;
    float4 opticalB;
    float4 opticalC;
    float4 opticalD;
    float4 visualA;
    float4 tint;
    float4 shapeCountData;
    float4 sourceRect;
};

struct LLBlurUniforms {
    float4 blur;
    float4 directionTaps;
};

struct LLOut { float4 position [[position]]; float2 uv; };

vertex LLOut ll_vertex(const device LLVertex *vertices [[buffer(0)]], uint id [[vertex_id]]) {
    LLOut out;
    out.position = float4(vertices[id].position, 0.0, 1.0);
    out.uv = vertices[id].uv;
    return out;
}

vertex LLOut ll_fullscreen_vertex(uint id [[vertex_id]]) {
    LLOut out;
    float2 positions[4] = { float2(-1, -1), float2(1, -1), float2(-1, 1), float2(1, 1) };
    float2 uvs[4] = { float2(0, 1), float2(1, 1), float2(0, 0), float2(1, 0) };
    out.position = float4(positions[id], 0.0, 1.0);
    out.uv = uvs[id];
    return out;
}

float roundedBoxSDF(float2 p, float2 b, float r) {
    r = min(r, min(b.x, b.y));
    float2 q = abs(p) - b + r;
    return length(max(q, 0.0)) + min(max(q.x, q.y), 0.0) - r;
}

float smoothMin(float a, float b, float k) {
    if (k <= 0.0001) return min(a, b);
    float h = saturate(0.5 + 0.5 * (b - a) / k);
    return mix(b, a, h) - k * h * (1.0 - h);
}

float evalGlassSDF(float2 p,
                   float2 baseHalfSize,
                   float baseRadius,
                   constant LLUniforms &u,
                   const device LLShapeGPU *shapes) {
    float sdf = roundedBoxSDF(p, baseHalfSize, baseRadius);
    if (u.shapeCountData.x <= 0) return sdf;

    float morphSDF = 1e6;
    const int count = min(int(u.shapeCountData.x), 32);
    for (int i = 0; i < count; ++i) {
        float2 c = shapes[i].geometry.xy * u.opticalB.z;
        float2 hs = shapes[i].geometry.zw * u.opticalB.z;
        float r = shapes[i].optical.x * u.opticalB.z;
        float k = max(0.0, shapes[i].optical.y * 24.0 * u.opticalB.z);
        float d = roundedBoxSDF(p - c, hs, r);
        morphSDF = (i == 0) ? d : smoothMin(morphSDF, d, k);
    }

    return (u.visualA.y > 0.5 && u.shapeCountData.x > 0)
        ? morphSDF
        : smoothMin(sdf, morphSDF, max(0.0, shapes[0].optical.y * 24.0 * u.opticalB.z));
}

float3 makeSurfaceNormal(float2 gradient, float strength, float edgeFactor) {
    float2 lateral = gradient * strength * edgeFactor;
    float lateralSq = min(0.92, dot(lateral, lateral));
    float z = sqrt(max(0.08, 1.0 - lateralSq));
    return normalize(float3(lateral, z));
}

float hash21(float2 p) {
    p = fract(p * float2(123.34, 345.45));
    p += dot(p, p + 34.345);
    return fract(p.x * p.y);
}

float3 applySaturation(float3 c, float s) {
    float l = dot(c, float3(0.2126, 0.7152, 0.0722));
    return mix(float3(l), c, s);
}

float3 applyContrast(float3 c, float x) {
    return saturate((c - 0.5) * x + 0.5);
}

float3 softClip(float3 c) {
    return c / (1.0 + max(c, float3(0.0)) * 0.08);
}

fragment float4 ll_fragment(
    LLOut in [[stage_in]],
    texture2d<float, access::sample> sharpSource [[texture(0)]],
    texture2d<float, access::sample> softSource [[texture(1)]],
    texture2d<float, access::sample> deepSource [[texture(2)]],
    constant LLUniforms &u [[buffer(1)]],
    const device LLShapeGPU *shapes [[buffer(2)]]) {

    constexpr sampler linearSampler(filter::linear, address::clamp_to_edge);

    float2 size = max(float2(1.0), u.sizePointer.xy);
    float2 p = (in.uv - 0.5) * size;
    float radius = min(u.materialA.y, min(size.x, size.y) * 0.5);
    float2 halfSize = size * 0.5 - radius;
    float sdf = evalGlassSDF(p, halfSize, radius, u, shapes);

    float aa = max(0.65, 1.15 * fwidth(sdf));
    float mask = 1.0 - smoothstep(-aa, aa, sdf);
    if (mask <= 0.001) return float4(0.0);

    float2 gradient = float2(dfdx(sdf), dfdy(sdf));
    float gradientLength = max(0.0001, length(gradient));
    float edgeFactor = 1.0 - smoothstep(0.0,
                                         max(1.0, u.opticalD.y * 8.0),
                                         max(0.0, -sdf));
    float bevel = smoothstep(0.0,
                             max(0.001, u.opticalD.y),
                             edgeFactor);
    bevel = max(bevel, edgeFactor * 0.22);

    float3 normal = makeSurfaceNormal(gradient / gradientLength,
                                       u.opticalD.x * 0.85,
                                       bevel);

    float curvature = 0.0;
    if (u.visualA.y >= 2.0 && u.shapeCountData.x <= 16 && u.opticalD.z > 0.001) {
        float stepSize = max(0.8, min(2.5, u.opticalD.y * 3.5));
        float sx0 = evalGlassSDF(p - float2(stepSize, 0), halfSize, radius, u, shapes);
        float sx1 = evalGlassSDF(p + float2(stepSize, 0), halfSize, radius, u, shapes);
        float sy0 = evalGlassSDF(p - float2(0, stepSize), halfSize, radius, u, shapes);
        float sy1 = evalGlassSDF(p + float2(0, stepSize), halfSize, radius, u, shapes);
        curvature = saturate(abs((sx0 + sx1 + sy0 + sy1 - 4.0 * sdf) /
                                 max(0.001, stepSize * stepSize)) * 0.35);
    }

    float2 sourceOrigin = u.sourceRect.xy;
    float2 sourceSize = u.sourceRect.zw;
    float2 sourceUV = saturate(sourceOrigin + in.uv * sourceSize);

    float roughness = saturate(max(u.opticalB.w, u.visualA.y < 1.0 ? 0.16 : u.opticalB.w));
    roughness = saturate(roughness + u.opticalB.w * 0.20);
    float micro = saturate(u.opticalD.x * 0.20 + u.visualA.y * 0.02);

    float pressureScale = 1.0 + saturate(u.opticalB.y) * 0.30 * u.visualA.z;
    float thickness = max(0.02, u.materialC.w) * max(0.05, u.opticalB.z);
    float refractionAmount = max(0.0, u.materialA.z)
                           * max(0.05, u.opticalA.z)
                           * thickness
                           * pressureScale
                           * max(0.35, u.visualA.w);

    float eta = 1.0 / max(1.01, u.opticalC.y);
    float3 viewDir = float3(0.0, 0.0, 1.0);
    float3 transmitted = refract(-viewDir, normal, eta);
    float2 bend = transmitted.xy / max(0.32, abs(transmitted.z));

    float chroma = saturate(u.opticalA.x * 0.75);
    float edgeChroma = saturate(u.opticalD.w) * chroma * edgeFactor;
    float bendGain = 1.0 + curvature * u.opticalD.z * 0.55 + edgeFactor * 0.08;
    float2 segment1 = bend * (refractionAmount * 0.52);
    float2 segment2 = bend * (refractionAmount * 0.48) * bendGain;
    float2 bendBase = segment1 + segment2;
    float pathFade = 1.0 - saturate(length(bendBase) * u.visualA.w * 0.30);
    bendBase *= pathFade;
    float2 uvR = saturate(sourceUV + bendBase * (1.0 + edgeChroma));
    float2 uvG = saturate(sourceUV + bendBase);
    float2 uvB = saturate(sourceUV + bendBase * (1.0 - edgeChroma));

    float3 sampleR = sharpSource.sample(linearSampler, uvR).rgb;
    float3 sampleG = sharpSource.sample(linearSampler, uvG).rgb;
    float3 sampleB = sharpSource.sample(linearSampler, uvB).rgb;
    float3 sharpTransmission = float3(sampleR.r, sampleG.g, sampleB.b);

    float3 softTransmission = softSource.sample(linearSampler, uvG).rgb;
    float3 deepTransmission = deepSource.sample(linearSampler, uvG).rgb;
    float roughBody = smoothstep(0.02, 0.42, roughness);
    float deepWeight = smoothstep(0.16, 0.85, roughness);
    float3 transmission = mix(sharpTransmission, softTransmission, roughBody * 0.78);
    transmission = mix(transmission, deepTransmission, deepWeight * 0.22);

    float opticalPath = saturate(length(bend) * 0.90 + edgeFactor * 0.32);
    float absorptionAmount = saturate(u.opticalC.x * (0.62 + opticalPath * u.visualA.w));
    float3 localScene = sharpSource.sample(linearSampler, sourceUV).rgb;
    float localLuma = dot(localScene, float3(0.2126, 0.7152, 0.0722));
    float adaptiveLift = mix(1.08, 0.94, smoothstep(0.18, 0.82, localLuma));
    float3 sceneAbsorption = mix(float3(1.0), localScene, absorptionAmount);
    transmission *= mix(float3(1.0), sceneAbsorption, absorptionAmount * 0.62);
    transmission *= adaptiveLift;

    float3 tint = mix(float3(1.0), max(u.tint.rgb, 0.0), saturate(u.materialB.y));
    transmission *= tint;
    transmission *= 1.0 - saturate(u.materialB.w) * 0.78;
    transmission = applySaturation(transmission, max(0.0, u.materialC.y));
    transmission = applyContrast(transmission, max(0.5, u.materialC.z));

    float f0 = pow((u.opticalC.y - 1.0) / max(0.001, u.opticalC.y + 1.0), 2.0);
    float cosTheta = saturate(dot(viewDir, normal));
    float fresnel = f0 + (1.0 - f0) * pow(1.0 - cosTheta, 5.0);
    fresnel = saturate(fresnel * max(0.0, u.opticalC.w));
    fresnel += curvature * u.opticalD.z * 0.16;

    float3 reflectedDir = reflect(-viewDir, normal);
    float envOffset = max(0.001, u.opticalD.w);
    float2 reflectedUV = saturate(sourceUV + reflectedDir.xy * envOffset * sourceSize);
    float3 envSharp = sharpSource.sample(linearSampler, reflectedUV).rgb;
    float3 envSoft = softSource.sample(linearSampler, reflectedUV).rgb;
    float3 envDeep = deepSource.sample(linearSampler, reflectedUV).rgb;
    float3 environment = mix(envSharp, envSoft, roughness * 0.55);
    environment = mix(environment, envDeep, roughness * roughness * 0.55);

    float phase = u.materialC.x * 0.32;
    float3 lightDir = normalize(float3(
        0.44 * sin(phase) - 0.16,
        0.36 * cos(phase * 0.71) - 0.20,
        0.80));
    float3 halfVector = normalize(lightDir + viewDir);
    float NdotH = saturate(dot(normal, halfVector));
    float specPower = mix(110.0, 24.0, roughness);
    float specularLobe = pow(NdotH, specPower);
    specularLobe *= (0.86 + 0.14 * sin(phase + dot(in.uv, float2(8.0, -6.0))));
    specularLobe *= (0.75 + 0.25 * saturate(u.opticalC.w));
    specularLobe *= (1.0 + saturate(u.opticalB.y) * 0.20);

    float broadSpec = pow(NdotH, mix(22.0, 7.0, roughness)) * 0.20;
    float reflectionWeight = saturate(fresnel * (0.52 + 0.48 * u.opticalC.z));
    float3 reflection = environment * reflectionWeight;
    reflection += specularLobe * u.materialA.w * u.visualA.z;
    reflection += broadSpec * u.opticalC.z;

    float rimWidth = max(0.25, u.opticalB.x * 16.0);
    float rimBand = 1.0 - smoothstep(0.0, rimWidth, abs(sdf));
    float rim = pow(saturate(fresnel + rimBand * (0.22 + 0.10 * curvature)),
                    max(0.65, u.opticalA.y));
    float3 edgeColor = mix(float3(1.0), tint, 0.20);
    reflection += edgeColor * rim * u.materialB.x * (0.66 + 0.34 * u.opticalC.z);

    float n = hash21(in.uv * float2(173.0, 127.0));
    float microSpec = pow(saturate(NdotH + (n - 0.5) * 0.09), mix(72.0, 18.0, roughness));
    reflection += microSpec * u.materialA.w * micro * 0.16;

    float2 edgeOffset = float2(1.0 / max(1.0, float(sharpSource.get_width())),
                               1.0 / max(1.0, float(sharpSource.get_height()))) *
                        max(1.0, 2.0 + 7.0 * u.opticalA.w);
    float3 edgeA = sharpSource.sample(linearSampler, saturate(sourceUV + edgeOffset)).rgb;
    float3 edgeB = sharpSource.sample(linearSampler, saturate(sourceUV - edgeOffset)).rgb;
    float opticalContrast = saturate(length(edgeA - edgeB) * (1.20 + 0.65 * u.opticalD.z));

    float2 pointerDelta = u.sizePointer.zw - in.uv;
    float pointerRadius = max(0.040, u.opticalA.w * 0.76);
    float pointerGlow = exp(-dot(pointerDelta, pointerDelta) /
                            max(0.001, pointerRadius * pointerRadius)) *
                        saturate(u.materialA.x) * u.visualA.x;
    float pointerSpec = pointerGlow * pow(saturate(NdotH + 0.20), 14.0);
    reflection += pointerSpec * (0.10 + u.materialA.w * 0.42) * u.opticalC.z;

    float3 result = transmission;
    result += reflection * (0.54 + 0.46 * opticalContrast);
    result += rim * u.materialB.x * 0.24;
    result += opticalContrast * rim * u.opticalC.z * 0.16;
    result = softClip(result);
    result = saturate(result);

    return float4(result, mask * saturate(u.materialB.z));
}

fragment float4 ll_blur_pass(
    LLOut in [[stage_in]],
    texture2d<float, access::sample> source [[texture(0)]],
    constant LLBlurUniforms &u [[buffer(1)]]) {

    constexpr sampler linearSampler(filter::linear, address::clamp_to_edge);
    float3 sum = float3(0.0);
    float weightSum = 0.0;

    const float offsets[5] = { -2.0, -1.0, 0.0, 1.0, 2.0 };
    const float weights[5] = { 0.0625, 0.25, 0.375, 0.25, 0.0625 };
    int count = min(5, max(1, int(u.directionTaps.z)));
    for (int i = 0; i < count; ++i) {
        float scalar = offsets[i] * u.blur.z * u.blur.y;
        float w = weights[i];
        if (count == 1) { scalar = 0.0; w = 1.0; }
        else if (count == 2 && i == 0) { scalar = -0.75 * u.blur.z * u.blur.y; }
        else if (count == 2 && i == 1) { scalar =  0.75 * u.blur.z * u.blur.y; }
        sum += source.sample(linearSampler, saturate(in.uv + u.directionTaps.xy * scalar)).rgb * w;
        weightSum += w;
    }
    return float4(sum / max(weightSum, 0.0001), 1.0);
}

fragment float4 ll_downsample(
    LLOut in [[stage_in]],
    texture2d<float, access::sample> source [[texture(0)]]) {

    constexpr sampler linearSampler(filter::linear, address::clamp_to_edge);
    float2 texel = float2(1.0 / float(source.get_width()), 1.0 / float(source.get_height()));
    float2 o = texel * 0.5;
    float3 sum = float3(0.0);
    sum += source.sample(linearSampler, in.uv + float2(-o.x, -o.y)).rgb;
    sum += source.sample(linearSampler, in.uv + float2( o.x, -o.y)).rgb;
    sum += source.sample(linearSampler, in.uv + float2(-o.x,  o.y)).rgb;
    sum += source.sample(linearSampler, in.uv + float2( o.x,  o.y)).rgb;
    return float4(sum * 0.25, 1.0);
}

fragment float4 ll_morph_composite(
    LLOut in [[stage_in]],
    texture2d<float, access::sample> glassTex [[texture(0)]],
    texture2d<float, access::sample> baseTex [[texture(1)]],
    constant LLUniforms &u [[buffer(1)]],
    const device LLShapeGPU *shapes [[buffer(2)]]) {

    constexpr sampler linearSampler(filter::linear, address::clamp_to_edge);
    float2 size = max(float2(1.0), u.sizePointer.xy);
    float2 p = (in.uv - 0.5) * size;
    float radius = min(u.materialA.y, min(size.x, size.y) * 0.5);
    float2 halfSize = size * 0.5 - radius;
    float sdf = evalGlassSDF(p, halfSize, radius, u, shapes);
    float aa = max(0.65, 1.15 * fwidth(sdf));
    float mask = 1.0 - smoothstep(-aa, aa, sdf);
    float4 glass = glassTex.sample(linearSampler, in.uv);
    float4 base = baseTex.sample(linearSampler, in.uv);
    float alpha = mask * glass.a;
    return float4(mix(base.rgb, glass.rgb, alpha), max(base.a, alpha));
}
"""

private struct LLShapeGPU {
    var geometry: SIMD4<Float>
    var optical: SIMD4<Float>
}

private struct LLGlassUniforms {
    var sizePointer: SIMD4<Float>
    var materialA: SIMD4<Float>
    var materialB: SIMD4<Float>
    var materialC: SIMD4<Float>
    var opticalA: SIMD4<Float>
    var opticalB: SIMD4<Float>
    var opticalC: SIMD4<Float>
    var opticalD: SIMD4<Float>
    var visualA: SIMD4<Float>
    var tint: SIMD4<Float>
    var shapeCountData: SIMD4<Float>
    var sourceRect: SIMD4<Float>
}

private struct LLBlurUniforms {
    var blur: SIMD4<Float>
    var directionTaps: SIMD4<Float>
}

private final class LLMetalTexturePool {
    private let device: MTLDevice
    private let lock = NSLock()
    private var available: [UInt64: [MTLTexture]] = [:]

    init(device: MTLDevice) { self.device = device }

    func obtain(width: Int, height: Int, pixelFormat: MTLPixelFormat = .bgra8Unorm) -> MTLTexture? {
        let key = poolKey(width: width, height: height, pixelFormat: pixelFormat)
        lock.lock()
        if var pool = available[key], let tex = pool.popLast() {
            available[key] = pool
            lock.unlock()
            return tex
        }
        lock.unlock()
        let desc = MTLTextureDescriptor.texture2DDescriptor(
            pixelFormat: pixelFormat, width: width, height: height, mipmapped: false)
        desc.usage = [.renderTarget, .shaderRead]
        desc.storageMode = .private
        return device.makeTexture(descriptor: desc)
    }

    func recycleAfterCompletion(_ textures: [MTLTexture], commandBuffer: MTLCommandBuffer) {
        guard !textures.isEmpty else { return }
        commandBuffer.addCompletedHandler { [weak self] _ in
            guard let self = self else { return }
            self.lock.lock()
            for tex in textures {
                let key = Self.poolKey(width: tex.width, height: tex.height, pixelFormat: tex.pixelFormat)
                var pool = self.available[key] ?? []
                if pool.count < 8 { pool.append(tex) }
                self.available[key] = pool
            }
            self.lock.unlock()
        }
    }

    func purge() {
        lock.lock()
        available.removeAll(keepingCapacity: true)
        lock.unlock()
    }

    private static func poolKey(width: Int, height: Int, pixelFormat: MTLPixelFormat) -> UInt64 {
        var hasher = Hasher()
        hasher.combine(width); hasher.combine(height); hasher.combine(pixelFormat.rawValue)
        return UInt64(bitPattern: Int64(hasher.finalize()))
    }

    private func poolKey(width: Int, height: Int, pixelFormat: MTLPixelFormat) -> UInt64 {
        Self.poolKey(width: width, height: height, pixelFormat: pixelFormat)
    }
}

private final class LLMetalPipelineBundle {
    let library: MTLLibrary
    let glass: MTLRenderPipelineState
    let blur: MTLRenderPipelineState
    let downsample: MTLRenderPipelineState
    let morphComposite: MTLRenderPipelineState
    let sampler: MTLSamplerState

    init?(device: MTLDevice, intermediatePixelFormat: MTLPixelFormat) {
        let requiredFunctions = [
            "ll_vertex", "ll_fullscreen_vertex", "ll_fragment",
            "ll_blur_pass", "ll_downsample", "ll_morph_composite"
        ]

        var library: MTLLibrary?
        if let bundled = try? device.makeDefaultLibrary(bundle: .main),
           requiredFunctions.allSatisfy({ bundled.makeFunction(name: $0) != nil }) {
            library = bundled
        }

        if library == nil {
            do {
                library = try device.makeLibrary(source: llGlassMetalSource, options: nil)
            } catch {
                NSLog("[LegacyLiquidGlass] Metal library compile failed: %@", error.localizedDescription)
                return nil
            }
        }

        guard let library = library,
              let vertexFn = library.makeFunction(name: "ll_vertex"),
              let fullscreenFn = library.makeFunction(name: "ll_fullscreen_vertex"),
              let fragmentFn = library.makeFunction(name: "ll_fragment"),
              let blurFn = library.makeFunction(name: "ll_blur_pass"),
              let downsampleFn = library.makeFunction(name: "ll_downsample"),
              let morphFn = library.makeFunction(name: "ll_morph_composite") else {
            NSLog("[LegacyLiquidGlass] Metal library missing required shader entry points")
            return nil
        }

        let glassDesc = MTLRenderPipelineDescriptor()
        glassDesc.vertexFunction = vertexFn
        glassDesc.fragmentFunction = fragmentFn
        glassDesc.colorAttachments[0].pixelFormat = .bgra8Unorm
        glassDesc.colorAttachments[0].isBlendingEnabled = true
        glassDesc.colorAttachments[0].sourceRGBBlendFactor = .sourceAlpha
        glassDesc.colorAttachments[0].destinationRGBBlendFactor = .oneMinusSourceAlpha
        glassDesc.colorAttachments[0].sourceAlphaBlendFactor = .sourceAlpha
        glassDesc.colorAttachments[0].destinationAlphaBlendFactor = .oneMinusSourceAlpha

        let blurDesc = MTLRenderPipelineDescriptor()
        blurDesc.vertexFunction = fullscreenFn
        blurDesc.fragmentFunction = blurFn
        blurDesc.colorAttachments[0].pixelFormat = intermediatePixelFormat

        let downDesc = MTLRenderPipelineDescriptor()
        downDesc.vertexFunction = fullscreenFn
        downDesc.fragmentFunction = downsampleFn
        downDesc.colorAttachments[0].pixelFormat = intermediatePixelFormat

        let morphDesc = MTLRenderPipelineDescriptor()
        morphDesc.vertexFunction = fullscreenFn
        morphDesc.fragmentFunction = morphFn
        morphDesc.colorAttachments[0].pixelFormat = .bgra8Unorm
        morphDesc.colorAttachments[0].isBlendingEnabled = true
        morphDesc.colorAttachments[0].sourceRGBBlendFactor = .sourceAlpha
        morphDesc.colorAttachments[0].destinationRGBBlendFactor = .oneMinusSourceAlpha

        let samplerDesc = MTLSamplerDescriptor()
        samplerDesc.minFilter = .linear
        samplerDesc.magFilter = .linear
        samplerDesc.sAddressMode = .clampToEdge
        samplerDesc.tAddressMode = .clampToEdge
        guard let sampler = device.makeSamplerState(descriptor: samplerDesc) else {
            NSLog("[LegacyLiquidGlass] Metal sampler creation failed")
            return nil
        }

        let glass: MTLRenderPipelineState
        let blur: MTLRenderPipelineState
        let downsample: MTLRenderPipelineState
        let morphComposite: MTLRenderPipelineState
        do {
            glass = try device.makeRenderPipelineState(descriptor: glassDesc)
            blur = try device.makeRenderPipelineState(descriptor: blurDesc)
            downsample = try device.makeRenderPipelineState(descriptor: downDesc)
            morphComposite = try device.makeRenderPipelineState(descriptor: morphDesc)
        } catch {
            NSLog("[LegacyLiquidGlass] Metal pipeline creation failed: %@", error.localizedDescription)
            return nil
        }

        self.library = library
        self.glass = glass
        self.blur = blur
        self.downsample = downsample
        self.morphComposite = morphComposite
        self.sampler = sampler
    }
}

private enum LLMetalShared {
    static let device: MTLDevice? = MTLCreateSystemDefaultDevice()
    static let queue: MTLCommandQueue? = device?.makeCommandQueue()

    static let intermediatePixelFormat: MTLPixelFormat = {
        guard let device = device else { return .bgra8Unorm }
        let descriptor = MTLTextureDescriptor.texture2DDescriptor(
            pixelFormat: .rgba16Float, width: 4, height: 4, mipmapped: false
        )
        descriptor.usage = [.renderTarget, .shaderRead]
        descriptor.storageMode = .private
        return device.makeTexture(descriptor: descriptor) != nil ? .rgba16Float : .bgra8Unorm
    }()

    static let texturePool: LLMetalTexturePool? = device.map { LLMetalTexturePool(device: $0) }
    static let pipelines: LLMetalPipelineBundle? = device.flatMap {
        LLMetalPipelineBundle(device: $0, intermediatePixelFormat: intermediatePixelFormat)
    }
    static let isUsable: Bool = device != nil && queue != nil && texturePool != nil && pipelines != nil
}

private final class LLFullscreenVertexBufferCache {
    static let shared = LLFullscreenVertexBufferCache()
    private var buffer: MTLBuffer?
    private let lock = NSLock()

    private init() {}

    func buffer(for device: MTLDevice) -> MTLBuffer? {
        lock.lock()
        if let buffer = buffer { lock.unlock(); return buffer }
        lock.unlock()
        let vertices: [Float] = [
            -1, -1, 0, 1,   1, -1, 1, 1,
            -1,  1, 0, 0,   1,  1, 1, 0
        ]
        let buf = device.makeBuffer(bytes: vertices,
                                     length: vertices.count * MemoryLayout<Float>.stride,
                                     options: .storageModeShared)
        lock.lock()
        if self.buffer == nil { self.buffer = buf }
        let result = self.buffer
        lock.unlock()
        return result
    }
}

public final class LLMetalGlassRenderer: NSObject, MTKViewDelegate {
    public struct Settings {
        public var cornerRadius: CGFloat = 24
        public var refraction: CGFloat = 0.016
        public var specular: CGFloat = 0.28
        public var edgeLight: CGFloat = 0.34
        public var tintStrength: CGFloat = 0.12
        public var opacity: CGFloat = 1
        public var darkness: CGFloat = 0.025
        public var highlightStrength: CGFloat = 0.0
        public var saturation: CGFloat = 1.04
        public var contrast: CGFloat = 1.02
        public var lensThickness: CGFloat = 0.45
        public var dispersion: CGFloat = 0.15
        public var fresnelPower: CGFloat = 2.5
        public var refractionScale: CGFloat = 0.90
        public var highlightWidth: CGFloat = 0.18
        public var rimWidth: CGFloat = 0.075
        public var pressure: CGFloat = 0
        public var isContainerMorph: Bool = false
        public var shapeScale: CGFloat = 1
        public var blurRadius: CGFloat = 18
        public var tint = SIMD4<Float>(repeating: 1)
        public var quality: CGFloat = 2
        public var time: CGFloat = 0
        public var pointer = SIMD2<Float>(0.5, 0.5)
        public var pointerStrength: CGFloat = 0
        public var sourceOriginUV = SIMD2<Float>(0, 0)
        public var sourceSizeUV = SIMD2<Float>(1, 1)
        public var shapes: [LLGlassShapeDescriptor] = []
        public var morphSmoothness: Float = 0.35
        public var pyramidLevels: Int = 4
        public var roughness: CGFloat = 0.14
        public var absorption: CGFloat = 0.14
        public var ior: CGFloat = 1.48
        public var environmentLight: CGFloat = 0.34
        public var reflectionMix: CGFloat = 0.22
        public var normalStrength: CGFloat = 0.42
        public var bevelWidth: CGFloat = 0.24
        public var curvatureStrength: CGFloat = 0.34
        public var microRoughness: CGFloat = 0.11
        public var environmentOffset: CGFloat = 0.055
        public var dynamicLightStrength: CGFloat = 0.82
        public var interactionStrength: CGFloat = 0.90
        public var depthAttenuation: CGFloat = 0.76
        public var edgeDispersion: CGFloat = 0.65
        public var useDeepBlur: Bool = true

        public init() {}
    }

    public let view: MTKView
    private let device: MTLDevice
    private let commandQueue: MTLCommandQueue
    private let pipelines: LLMetalPipelineBundle
    private let texturePool: LLMetalTexturePool
    private let settingsLock = NSLock()
    private var settings = Settings()
    private var sourceTexture: MTLTexture?
    private var pendingDraw = false

    private var cachedBlurSignature: UInt64 = 0
    private var cachedSoftTexture: MTLTexture?
    private var cachedDeepTexture: MTLTexture?
    private var cachedBlurSize: (Int, Int) = (0, 0)
    private var retiredBlurTextures: [(MTLTexture?, MTLTexture?)] = []
    private var memoryWarningObserver: NSObjectProtocol?

    public init?(frame: CGRect = .zero) {
        guard let device = LLMetalShared.device,
              let queue = LLMetalShared.queue,
              let pipelines = LLMetalShared.pipelines,
              let texturePool = LLMetalShared.texturePool else { return nil }
        self.device = device
        self.commandQueue = queue
        self.pipelines = pipelines
        self.texturePool = texturePool
        self.view = MTKView(frame: frame, device: device)
        super.init()
        self.view.delegate = self
        self.view.isPaused = true
        self.view.enableSetNeedsDisplay = false
        self.view.framebufferOnly = true
        self.view.isOpaque = false
        self.view.backgroundColor = .clear
        self.view.clearColor = MTLClearColor(red: 0, green: 0, blue: 0, alpha: 0)
        self.view.colorPixelFormat = .bgra8Unorm
        self.view.contentScaleFactor = min(UIScreen.main.scale, 2.0)
        self.view.preferredFramesPerSecond = 60
        memoryWarningObserver = NotificationCenter.default.addObserver(
            forName: UIApplication.didReceiveMemoryWarningNotification,
            object: nil, queue: .main
        ) { [weak self] _ in
            Task { @MainActor [weak self] in
                self?.purgeBlurCache()
            }
        }
    }

    deinit {
        if let memoryWarningObserver = memoryWarningObserver {
            NotificationCenter.default.removeObserver(memoryWarningObserver)
        }
    }

    private func purgeBlurCache() {
        cachedBlurSignature = 0
        cachedSoftTexture = nil
        cachedDeepTexture = nil
        retiredBlurTextures.removeAll(keepingCapacity: false)
    }

    public func update(source texture: MTLTexture?, settings: Settings) {
        settingsLock.lock()
        let sourceChanged = sourceTexture.map(ObjectIdentifier.init) != texture.map(ObjectIdentifier.init)
        self.settings = settings
        self.sourceTexture = texture
        settingsLock.unlock()
        if sourceChanged { cachedBlurSignature = 0 }
        scheduleDraw()
    }

    public func updateSettings(_ settings: Settings) {
        settingsLock.lock()
        let previous = self.settings
        self.settings = settings
        settingsLock.unlock()
        if blurSignature(for: previous) != blurSignature(for: settings) {
            cachedBlurSignature = 0
        }
        scheduleDraw()
    }

    private func scheduleDraw() {
        guard !pendingDraw else { return }
        pendingDraw = true
        Task { @MainActor [weak self] in
            guard let self = self else { return }
            self.pendingDraw = false
            self.view.draw()
        }
    }

    public func mtkView(_ view: MTKView, drawableSizeWillChange size: CGSize) {
        cachedBlurSignature = 0
    }

    public func draw(in view: MTKView) {
        settingsLock.lock()
        let s = settings
        let source = sourceTexture
        settingsLock.unlock()

        guard let drawable = view.currentDrawable,
              let sourceTex = source,
              sourceTex.width > 0, sourceTex.height > 0,
              let commandBuffer = commandQueue.makeCommandBuffer() else { return }

        commandBuffer.label = "LegacyLiquidGlass 8.0 Render"
        commandBuffer.addCompletedHandler { cb in
            let gpuStart = cb.gpuStartTime
            let gpuEnd = cb.gpuEndTime
            if gpuEnd > gpuStart {
                LLGlassPerformanceGovernor.shared.recordGPUTime(gpuEnd - gpuStart)
            }
        }

        let outputWidth = max(1, drawable.texture.width)
        let outputHeight = max(1, drawable.texture.height)
        let signature = blurSignature(for: s)
        var transient: [MTLTexture] = []
        let blurred = prepareBlurTexturesIfNeeded(
            source: sourceTex,
            settings: s,
            signature: signature,
            commandBuffer: commandBuffer,
            transientTextures: &transient
        )

        finalPass(drawable: drawable,
                  commandBuffer: commandBuffer,
                  s: s,
                  sharpTexture: sourceTex,
                  softTexture: blurred.soft,
                  deepTexture: blurred.deep,
                  outputWidth: outputWidth,
                  outputHeight: outputHeight)

        commandBuffer.present(drawable)
        texturePool.recycleAfterCompletion(transient, commandBuffer: commandBuffer)
        commandBuffer.commit()
    }

    private func prepareBlurTexturesIfNeeded(source: MTLTexture,
                                             settings s: Settings,
                                             signature: UInt64,
                                             commandBuffer: MTLCommandBuffer,
                                             transientTextures: inout [MTLTexture]) -> (soft: MTLTexture, deep: MTLTexture) {
        if cachedBlurSignature == signature,
           let soft = cachedSoftTexture,
           let deep = cachedDeepTexture,
           soft.width == cachedBlurSize.0,
           soft.height == cachedBlurSize.1 {
            return (soft, deep)
        }

        var oldSoft: MTLTexture?
        var oldDeep: MTLTexture?
        oldSoft = cachedSoftTexture
        oldDeep = cachedDeepTexture
        cachedSoftTexture = nil
        cachedDeepTexture = nil
        cachedBlurSignature = 0

        let levels = max(1, min(4, s.pyramidLevels))
        var current = source
        for _ in 0..<levels {
            if current.width == 1 && current.height == 1 { break }
            let width = max(1, current.width / 2)
            let height = max(1, current.height / 2)
            guard let down = texturePool.obtain(width: width, height: height, pixelFormat: LLMetalShared.intermediatePixelFormat) else { break }
            transientTextures.append(down)
            encodeDownsample(source: current, destination: down, commandBuffer: commandBuffer)
            current = down
        }

        guard let soft = device.makeTexture(descriptor: Self.blurDescriptor(device: device, width: current.width, height: current.height)),
              let deep = device.makeTexture(descriptor: Self.blurDescriptor(device: device, width: current.width, height: current.height)) else {
            return (current, current)
        }

        encodeSeparableBlur(source: current, destination: soft,
                            radius: max(0.8, min(18.0, Float(s.blurRadius) / Float(max(1, levels)))),
                            taps: blurTapCount(quality: s.quality), commandBuffer: commandBuffer)

        if s.useDeepBlur && s.pyramidLevels >= 2 {
            encodeSeparableBlur(source: soft, destination: deep,
                                radius: max(0.7, min(12.0, Float(s.blurRadius) * 0.48)),
                                taps: max(1, blurTapCount(quality: s.quality) - 1),
                                commandBuffer: commandBuffer)
        } else {
            encodeCopy(source: soft, destination: deep, commandBuffer: commandBuffer)
        }

        cachedSoftTexture = soft
        cachedDeepTexture = deep
        cachedBlurSize = (soft.width, soft.height)
        cachedBlurSignature = signature

        if oldSoft != nil || oldDeep != nil {
            let retired = (oldSoft, oldDeep)
            retiredBlurTextures.append(retired)
            commandBuffer.addCompletedHandler { [weak self] _ in
                guard let self = self else { return }
                self.retiredBlurTextures.removeAll { item in
                    let softMatches: Bool
                    if let a = item.0, let b = retired.0 { softMatches = a === b } else { softMatches = false }
                    let deepMatches: Bool
                    if let a = item.1, let b = retired.1 { deepMatches = a === b } else { deepMatches = false }
                    return softMatches || deepMatches
                }
            }
        }

        return (soft, deep)
    }

    private func encodeDownsample(source: MTLTexture, destination: MTLTexture, commandBuffer: MTLCommandBuffer) {
        let desc = MTLRenderPassDescriptor()
        desc.colorAttachments[0].texture = destination
        desc.colorAttachments[0].loadAction = .clear
        desc.colorAttachments[0].storeAction = .store
        desc.colorAttachments[0].clearColor = MTLClearColor(red: 0, green: 0, blue: 0, alpha: 0)
        guard let enc = commandBuffer.makeRenderCommandEncoder(descriptor: desc),
              let vb = LLFullscreenVertexBufferCache.shared.buffer(for: device) else { return }
        enc.setRenderPipelineState(pipelines.downsample)
        enc.setVertexBuffer(vb, offset: 0, index: 0)
        enc.setFragmentTexture(source, index: 0)
        enc.setFragmentSamplerState(pipelines.sampler, index: 0)
        enc.drawPrimitives(type: .triangleStrip, vertexStart: 0, vertexCount: 4)
        enc.endEncoding()
    }

    private func encodeCopy(source: MTLTexture, destination: MTLTexture, commandBuffer: MTLCommandBuffer) {
        let desc = MTLRenderPassDescriptor()
        desc.colorAttachments[0].texture = destination
        desc.colorAttachments[0].loadAction = .clear
        desc.colorAttachments[0].storeAction = .store
        desc.colorAttachments[0].clearColor = MTLClearColor(red: 0, green: 0, blue: 0, alpha: 0)
        guard let enc = commandBuffer.makeRenderCommandEncoder(descriptor: desc),
              let vb = LLFullscreenVertexBufferCache.shared.buffer(for: device) else { return }
        enc.setRenderPipelineState(pipelines.blur)
        enc.setVertexBuffer(vb, offset: 0, index: 0)
        enc.setFragmentTexture(source, index: 0)
        enc.setFragmentSamplerState(pipelines.sampler, index: 0)
        var u = LLBlurUniforms(blur: SIMD4(Float(1.0 / Float(source.width)), Float(1.0 / Float(source.height)), 0, 1),
                               directionTaps: SIMD4(0, 0, 1, 0))
        enc.setFragmentBytes(&u, length: MemoryLayout<LLBlurUniforms>.stride, index: 1)
        enc.drawPrimitives(type: .triangleStrip, vertexStart: 0, vertexCount: 4)
        enc.endEncoding()
    }

    private func encodeSeparableBlur(source: MTLTexture,
                                     destination: MTLTexture,
                                     radius: Float,
                                     taps: Int,
                                     commandBuffer: MTLCommandBuffer) {
        guard let horizontal = texturePool.obtain(
            width: source.width,
            height: source.height,
            pixelFormat: destination.pixelFormat
        ) else {
            encodeCopy(source: source, destination: destination, commandBuffer: commandBuffer)
            return
        }
        encodeBlurPass(source: source, destination: horizontal, radius: radius, taps: taps,
                       direction: SIMD2(1, 0), commandBuffer: commandBuffer)
        encodeBlurPass(source: horizontal, destination: destination, radius: radius, taps: taps,
                       direction: SIMD2(0, 1), commandBuffer: commandBuffer)
        texturePool.recycleAfterCompletion([horizontal], commandBuffer: commandBuffer)
    }

    private func encodeBlurPass(source: MTLTexture,
                                destination: MTLTexture,
                                radius: Float,
                                taps: Int,
                                direction: SIMD2<Float>,
                                commandBuffer: MTLCommandBuffer) {
        let desc = MTLRenderPassDescriptor()
        desc.colorAttachments[0].texture = destination
        desc.colorAttachments[0].loadAction = .clear
        desc.colorAttachments[0].storeAction = .store
        desc.colorAttachments[0].clearColor = MTLClearColor(red: 0, green: 0, blue: 0, alpha: 0)
        guard let enc = commandBuffer.makeRenderCommandEncoder(descriptor: desc),
              let vb = LLFullscreenVertexBufferCache.shared.buffer(for: device) else { return }
        enc.setRenderPipelineState(pipelines.blur)
        enc.setVertexBuffer(vb, offset: 0, index: 0)
        enc.setFragmentTexture(source, index: 0)
        enc.setFragmentSamplerState(pipelines.sampler, index: 0)
        let texel = SIMD2(Float(1.0 / Float(source.width)), Float(1.0 / Float(source.height)))
        var u = LLBlurUniforms(blur: SIMD4(texel.x, texel.y, radius, max(0.65, radius * 0.55)),
                               directionTaps: SIMD4(direction.x, direction.y, Float(max(1, min(5, taps))), 0))
        enc.setFragmentBytes(&u, length: MemoryLayout<LLBlurUniforms>.stride, index: 1)
        enc.drawPrimitives(type: .triangleStrip, vertexStart: 0, vertexCount: 4)
        enc.endEncoding()
    }

    private func finalPass(drawable: CAMetalDrawable,
                           commandBuffer: MTLCommandBuffer,
                           s: Settings,
                           sharpTexture: MTLTexture,
                           softTexture: MTLTexture,
                           deepTexture: MTLTexture,
                           outputWidth: Int,
                           outputHeight: Int) {
        let desc = MTLRenderPassDescriptor()
        desc.colorAttachments[0].texture = drawable.texture
        desc.colorAttachments[0].loadAction = .clear
        desc.colorAttachments[0].storeAction = .store
        desc.colorAttachments[0].clearColor = MTLClearColor(red: 0, green: 0, blue: 0, alpha: 0)
        guard let enc = commandBuffer.makeRenderCommandEncoder(descriptor: desc),
              let vb = LLFullscreenVertexBufferCache.shared.buffer(for: device) else { return }

        var u = makeUniforms(s: s, sourceTexture: sharpTexture, outputWidth: outputWidth, outputHeight: outputHeight)
        enc.setRenderPipelineState(pipelines.glass)
        enc.setVertexBuffer(vb, offset: 0, index: 0)
        enc.setFragmentTexture(sharpTexture, index: 0)
        enc.setFragmentTexture(softTexture, index: 1)
        enc.setFragmentTexture(deepTexture, index: 2)
        enc.setFragmentSamplerState(pipelines.sampler, index: 0)
        enc.setFragmentBytes(&u, length: MemoryLayout<LLGlassUniforms>.stride, index: 1)

        let count = min(s.shapes.count, 32)
        if count > 0 {
            let shapes = s.shapes.prefix(count).map { shape in
                LLShapeGPU(
                    geometry: SIMD4(shape.center.x, shape.center.y, shape.halfSize.x, shape.halfSize.y),
                    optical: SIMD4(shape.cornerRadius, shape.smoothness, 0, 0)
                )
            }
            shapes.withUnsafeBufferPointer { buffer in
                guard let baseAddress = buffer.baseAddress else { return }
                enc.setFragmentBytes(UnsafeRawPointer(baseAddress),
                                     length: MemoryLayout<LLShapeGPU>.stride * buffer.count,
                                     index: 2)
            }
        }
        enc.drawPrimitives(type: .triangleStrip, vertexStart: 0, vertexCount: 4)
        enc.endEncoding()
    }

    private func makeUniforms(s: Settings, sourceTexture: MTLTexture, outputWidth: Int, outputHeight: Int) -> LLGlassUniforms {
        let safeQuality = max(0, min(3, Float(s.quality)))
        let limitedShapeScale = max(0.01, Float(s.shapeScale))
        return LLGlassUniforms(
            sizePointer: SIMD4(Float(outputWidth), Float(outputHeight), Float(s.pointer.x), Float(s.pointer.y)),
            materialA: SIMD4(Float(s.pointerStrength), Float(s.cornerRadius * CGFloat(limitedShapeScale)), Float(s.refraction), Float(s.specular)),
            materialB: SIMD4(Float(s.edgeLight), Float(s.tintStrength), Float(s.opacity), Float(s.darkness)),
            materialC: SIMD4(Float(s.time), Float(s.saturation), Float(s.contrast), Float(s.lensThickness)),
            opticalA: SIMD4(Float(s.dispersion), Float(s.fresnelPower), Float(s.refractionScale), Float(s.highlightWidth)),
            opticalB: SIMD4(Float(s.rimWidth), Float(s.pressure), limitedShapeScale,
                            Float(max(0.01, min(1.0, s.roughness + s.microRoughness * 0.5)))),
            opticalC: SIMD4(Float(max(0, min(1, s.absorption))), Float(max(1.01, min(2.20, s.ior))),
                            Float(max(0, min(2, s.environmentLight))), Float(max(0, min(1, s.reflectionMix)))),
            opticalD: SIMD4(Float(max(0.01, min(1.5, s.normalStrength))), Float(max(0.01, min(2, s.bevelWidth))),
                            Float(max(0, min(2, s.curvatureStrength))), Float(max(0, min(0.25, s.environmentOffset)))),
            visualA: SIMD4(Float(max(0, min(1, s.highlightStrength))), safeQuality,
                           Float(max(0, min(1.5, s.dynamicLightStrength))), Float(max(0.10, min(1.5, s.depthAttenuation)))),
            tint: s.tint,
            shapeCountData: SIMD4(Float(min(s.shapes.count, 32)), 0, 0, 0),
            sourceRect: SIMD4(s.sourceOriginUV.x, s.sourceOriginUV.y, s.sourceSizeUV.x, s.sourceSizeUV.y)
        )
    }

    public func renderSharedMorph(surfaceTexture: MTLTexture,
                                   baseTexture: MTLTexture,
                                   shapes: [LLGlassShapeDescriptor],
                                   settings: Settings,
                                   commandBuffer: MTLCommandBuffer,
                                   drawable: CAMetalDrawable) {
        let desc = MTLRenderPassDescriptor()
        desc.colorAttachments[0].texture = drawable.texture
        desc.colorAttachments[0].loadAction = .clear
        desc.colorAttachments[0].storeAction = .store
        desc.colorAttachments[0].clearColor = MTLClearColor(red: 0, green: 0, blue: 0, alpha: 0)
        guard let enc = commandBuffer.makeRenderCommandEncoder(descriptor: desc),
              let vb = LLFullscreenVertexBufferCache.shared.buffer(for: device) else { return }

        var s = settings
        s.isContainerMorph = true
        s.shapes = Array(shapes.prefix(32))
        var u = makeUniforms(s: s, sourceTexture: surfaceTexture,
                             outputWidth: drawable.texture.width,
                             outputHeight: drawable.texture.height)
        enc.setRenderPipelineState(pipelines.morphComposite)
        enc.setVertexBuffer(vb, offset: 0, index: 0)
        enc.setFragmentTexture(surfaceTexture, index: 0)
        enc.setFragmentTexture(baseTexture, index: 1)
        enc.setFragmentSamplerState(pipelines.sampler, index: 0)
        enc.setFragmentBytes(&u, length: MemoryLayout<LLGlassUniforms>.stride, index: 1)
        if !s.shapes.isEmpty {
            let gpuShapes = s.shapes.map { shape in
                LLShapeGPU(geometry: SIMD4(shape.center.x, shape.center.y, shape.halfSize.x, shape.halfSize.y),
                           optical: SIMD4(shape.cornerRadius, shape.smoothness, 0, 0))
            }
            gpuShapes.withUnsafeBufferPointer { buffer in
                guard let baseAddress = buffer.baseAddress else { return }
                enc.setFragmentBytes(UnsafeRawPointer(baseAddress),
                                     length: MemoryLayout<LLShapeGPU>.stride * buffer.count,
                                     index: 2)
            }
        }
        enc.drawPrimitives(type: .triangleStrip, vertexStart: 0, vertexCount: 4)
        enc.endEncoding()
    }

    private func blurSignature(for s: Settings) -> UInt64 {
        var hasher = Hasher()
        if let source = sourceTexture {
            hasher.combine(ObjectIdentifier(source))
            hasher.combine(source.width)
            hasher.combine(source.height)
        }
        hasher.combine(Int(s.pyramidLevels))
        hasher.combine(Int(max(0, min(5, s.quality))))
        hasher.combine(Int((s.blurRadius * 8).rounded()))
        hasher.combine(s.useDeepBlur)
        return UInt64(bitPattern: Int64(hasher.finalize()))
    }

    private func blurTapCount(quality: CGFloat) -> Int {
        if quality < 0.5 { return 1 }
        if quality < 1.5 { return 2 }
        if quality < 2.5 { return 4 }
        return 5
    }

    private static func blurDescriptor(device: MTLDevice, width: Int, height: Int) -> MTLTextureDescriptor {
        let d = MTLTextureDescriptor.texture2DDescriptor(pixelFormat: LLMetalShared.intermediatePixelFormat,
                                                         width: max(1, width),
                                                         height: max(1, height),
                                                         mipmapped: false)
        d.usage = [.renderTarget, .shaderRead]
        d.storageMode = .private
        return d
    }
}

public final class LLGlassSharedMorphRenderer: NSObject, MTKViewDelegate {
    public static let shared = LLGlassSharedMorphRenderer()

    public let view: MTKView
    private let renderer: LLMetalGlassRenderer?
    private let lock = NSLock()
    private var sourceTexture: MTLTexture?
    private var morphShapes: [LLGlassShapeDescriptor] = []
    private var morphSettings: LLMetalGlassRenderer.Settings?
    private var pendingDraw = false

    public override init() {
        let renderer = LLMetalGlassRenderer(frame: .zero)
        self.renderer = renderer
        if let renderer = renderer {
            self.view = renderer.view
        } else {
            self.view = MTKView(frame: .zero, device: LLMetalShared.device)
        }
        super.init()

        self.view.delegate = self
        self.view.isPaused = true
        self.view.enableSetNeedsDisplay = false
        self.view.framebufferOnly = true
        self.view.isOpaque = false
        self.view.isHidden = renderer == nil
        self.view.backgroundColor = .clear
        self.view.clearColor = MTLClearColor(red: 0, green: 0, blue: 0, alpha: 0)
    }

    public func updateMorph(shapes: [LLGlassShapeDescriptor],
                            settings: LLMetalGlassRenderer.Settings) {
        lock.lock()
        morphShapes = shapes
        morphSettings = settings
        let source = sourceTexture
        lock.unlock()

        guard let source = source, let renderer = renderer else { return }

        var renderSettings = settings
        renderSettings.isContainerMorph = true
        renderSettings.shapes = shapes
        renderer.update(source: source, settings: renderSettings)
        scheduleDraw()
    }

    public func updateMorph(sourceTexture: MTLTexture,
                            shapes: [LLGlassShapeDescriptor],
                            settings: LLMetalGlassRenderer.Settings) {
        lock.lock()
        self.sourceTexture = sourceTexture
        morphShapes = shapes
        morphSettings = settings
        lock.unlock()

        guard let renderer = renderer else { return }
        var renderSettings = settings
        renderSettings.isContainerMorph = true
        renderSettings.shapes = shapes
        renderer.update(source: sourceTexture, settings: renderSettings)
        scheduleDraw()
    }

    private func scheduleDraw() {
        guard !pendingDraw else { return }
        pendingDraw = true

        Task { @MainActor [weak self] in
            guard let self = self else { return }
            self.pendingDraw = false
            self.view.draw()
        }
    }

    public func mtkView(_ view: MTKView, drawableSizeWillChange size: CGSize) {}

    public func draw(in view: MTKView) {
        renderer?.draw(in: view)
    }
}

public final class LLLegacyVisualGlass: UIView {
    private let blurView = UIVisualEffectView(effect: UIBlurEffect(style: .systemMaterial))
    private let tintView = UIView()
    private let highlightView = UIView()
    private let rimLayer = CAShapeLayer()
    private let innerRimLayer = CAShapeLayer()
    private var appliedBlurStyleKey: Int?

    public var material: LLGlassMaterial = .regular { didSet { applyMaterial() } }
    public var cornerRadius: CGFloat = 24 { didSet { setNeedsLayout() } }
    public var highlighted = false { didSet { animateInteraction() } }

    public override init(frame: CGRect) { super.init(frame: frame); setup() }
    public required init?(coder: NSCoder) { super.init(coder: coder); setup() }

    private func setup() {
        isUserInteractionEnabled = false
        backgroundColor = .clear
        layer.masksToBounds = false
        blurView.isUserInteractionEnabled = false
        tintView.isUserInteractionEnabled = false
        highlightView.isUserInteractionEnabled = false
        highlightView.backgroundColor = UIColor.white.withAlphaComponent(0.18)
        addSubview(blurView)
        addSubview(tintView)
        addSubview(highlightView)
        layer.addSublayer(rimLayer)
        layer.addSublayer(innerRimLayer)
        applyMaterial()
    }

    private func applyMaterial() {
        let alpha = material.opacity
        tintView.backgroundColor = (material.tint ?? LLGlassColorMath.appearanceTint())
            .withAlphaComponent(0.12 * alpha)
        blurView.alpha = 1.0
        let style: UIBlurEffect.Style
        let styleKey: Int
        if material.blurRadius >= 22 {
            style = .systemThickMaterial
            styleKey = 2
        } else if material.blurRadius <= 11 {
            style = .systemThinMaterial
            styleKey = 0
        } else {
            style = .systemMaterial
            styleKey = 1
        }
        if appliedBlurStyleKey != styleKey {
            blurView.effect = UIBlurEffect(style: style)
            appliedBlurStyleKey = styleKey
        }
        rimLayer.fillColor = UIColor.clear.cgColor
        rimLayer.strokeColor = UIColor.white.withAlphaComponent(material.edgeLight).cgColor
        rimLayer.lineWidth = 1
        innerRimLayer.fillColor = UIColor.clear.cgColor
        innerRimLayer.strokeColor = UIColor.white.withAlphaComponent(material.specular * 0.45).cgColor
        innerRimLayer.lineWidth = 0.6
        setNeedsLayout()
    }

    private func animateInteraction() {
        guard !LLGlassEnvironment.shared.reduceMotion else {
            highlightView.alpha = highlighted ? 1 : 0
            return
        }
        UIView.animate(withDuration: 0.22, delay: 0,
                       options: [.beginFromCurrentState, .allowUserInteraction]) {
            self.highlightView.alpha = self.highlighted ? 1 : 0
            self.highlightView.transform = self.highlighted
                ? CGAffineTransform(scaleX: 0.98, y: 0.98) : .identity
        }
    }

    public override func layoutSubviews() {
        super.layoutSubviews()
        blurView.frame = bounds
        tintView.frame = bounds
        highlightView.frame = bounds.insetBy(dx: 1, dy: 1)
        let path = LLGlassGeometry.roundedPath(bounds: bounds, radius: cornerRadius)
        rimLayer.path = path.cgPath
        innerRimLayer.path = LLGlassGeometry.roundedPath(
            bounds: bounds.insetBy(dx: 1.0, dy: 1.0),
            radius: LLGlassGeometry.insetRadius(cornerRadius, inset: 1.0)
        ).cgPath
        highlightView.layer.cornerRadius = cornerRadius
        highlightView.layer.cornerCurve = .continuous
        highlightView.layer.masksToBounds = true
        highlightView.alpha = highlighted ? 1 : 0
    }
}

private final class LLPressureLongPressGestureRecognizer: UILongPressGestureRecognizer {
    private(set) var normalizedPressure: CGFloat = 0

    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent) {
        updatePressure(from: touches)
        super.touchesBegan(touches, with: event)
    }

    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent) {
        updatePressure(from: touches)
        super.touchesMoved(touches, with: event)
    }

    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent) {
        updatePressure(from: touches)
        super.touchesEnded(touches, with: event)
    }

    override func touchesCancelled(_ touches: Set<UITouch>, with event: UIEvent) {
        normalizedPressure = 0
        super.touchesCancelled(touches, with: event)
    }

    override func reset() {
        normalizedPressure = 0
        super.reset()
    }

    private func updatePressure(from touches: Set<UITouch>) {
        guard let touch = touches.first else { return }
        let maximum = touch.maximumPossibleForce
        normalizedPressure = maximum > 0
            ? min(1, max(0, touch.force / maximum))
            : 0
    }
}

public final class LLGlassInteractionDriver: NSObject {
    public weak var view: UIView?
    public var enabled = true
    public var pressScale: CGFloat = 0.965
    public var highlight = true
    public var onPointerUpdate: ((CGPoint) -> Void)?
    public var onPressureUpdate: ((CGFloat) -> Void)?

    private lazy var tap = UITapGestureRecognizer(target: self, action: #selector(handleTap(_:)))
    private lazy var longPress = LLPressureLongPressGestureRecognizer(target: self, action: #selector(handleLongPress(_:)))
    private var installed = false

    public init(view: UIView) {
        self.view = view
        super.init()
    }

    public func install() {
        guard !installed, let view else { return }
        installed = true
        longPress.minimumPressDuration = 0.01
        longPress.cancelsTouchesInView = false
        view.addGestureRecognizer(longPress)

        if !(view is UIControl) {
            tap.cancelsTouchesInView = false
            view.addGestureRecognizer(tap)
        }
    }

    public func uninstall() {
        guard installed, let view else { return }
        view.removeGestureRecognizer(longPress)
        view.removeGestureRecognizer(tap)
        installed = false
    }

    @objc private func handleTap(_ recognizer: UITapGestureRecognizer) {
        guard enabled, recognizer.state == .ended else { return }
        pulse()
    }

    @objc private func handleLongPress(_ recognizer: UILongPressGestureRecognizer) {
        guard enabled, let view else { return }
        switch recognizer.state {
        case .began, .changed:
            setPressed(true, view: view)
            let location = recognizer.location(in: view)
            let normalized = CGPoint(
                x: view.bounds.width > 0 ? location.x / view.bounds.width : 0.5,
                y: view.bounds.height > 0 ? location.y / view.bounds.height : 0.5
            )
            onPointerUpdate?(normalized)
            let pressure = (recognizer as? LLPressureLongPressGestureRecognizer)?.normalizedPressure ?? 0
            onPressureUpdate?(max(0.6, pressure))
        default:
            setPressed(false, view: view)
            onPointerUpdate?(CGPoint(x: 0.5, y: 0.5))
            onPressureUpdate?(0)
        }
    }

    private func setPressed(_ value: Bool, view: UIView) {
        guard !LLGlassEnvironment.shared.reduceMotion else {
            view.transform = value ? CGAffineTransform(scaleX: pressScale, y: pressScale) : .identity
            (view as? LLGlassView)?.isHighlighted = value
            return
        }
        let targetScale = value ? pressScale : 1.0
        UIView.animate(withDuration: value ? 0.11 : 0.28, delay: 0,
                       usingSpringWithDamping: value ? 1 : 0.72,
                       initialSpringVelocity: 0.6,
                       options: [.beginFromCurrentState, .allowUserInteraction]) {
            view.transform = CGAffineTransform(scaleX: targetScale, y: targetScale)
            (view as? LLGlassView)?.isHighlighted = value
        }
    }

    private func pulse() {
        guard let view else { return }
        guard !LLGlassEnvironment.shared.reduceMotion else { return }
        UIView.animate(withDuration: 0.10, animations: {
            view.transform = CGAffineTransform(scaleX: 0.985, y: 0.985)
        }) { _ in
            UIView.animate(withDuration: 0.30, delay: 0,
                           usingSpringWithDamping: 0.60,
                           initialSpringVelocity: 0.4,
                           options: [.beginFromCurrentState]) {
                view.transform = .identity
            }
        }
    }
}

private final class LLGlassFrameTicker: NSObject {
    static let shared = LLGlassFrameTicker()

    private let views = NSHashTable<LLGlassView>.weakObjects()
    private var registeredViewIdentifiers = Set<ObjectIdentifier>()
    private var displayLink: CADisplayLink?

    private override init() { super.init() }

    func register(_ view: LLGlassView) {
        views.add(view)
        registeredViewIdentifiers.insert(ObjectIdentifier(view))
        startIfNeeded()
    }

    func unregister(_ view: LLGlassView) {
        views.remove(view)
        unregister(identifier: ObjectIdentifier(view))
    }

    func unregister(identifier: ObjectIdentifier) {
        _ = registeredViewIdentifiers.remove(identifier)
        if registeredViewIdentifiers.isEmpty {
            displayLink?.invalidate()
            displayLink = nil
        }
    }

    private func effectiveFrameRate(for screen: UIScreen?) -> Int {
        let hardwareMax = max(30, screen?.maximumFramesPerSecond ?? UIScreen.main.maximumFramesPerSecond)
        let engineMax = min(60, hardwareMax)
        return min(engineMax, max(30, LegacyLiquidGlass.configuration.preferredFrameRate))
    }

    func refreshRateChanged() {
        guard let displayLink = displayLink else { return }
        let screen = views.allObjects.first?.window?.screen ?? UIScreen.main
        displayLink.preferredFramesPerSecond = effectiveFrameRate(for: screen)
    }

    private func startIfNeeded() {
        guard displayLink == nil else { return }
        let link = CADisplayLink(target: self, selector: #selector(tick(_:)))
        let screen = views.allObjects.first?.window?.screen ?? UIScreen.main
        link.preferredFramesPerSecond = effectiveFrameRate(for: screen)
        link.add(to: .main, forMode: .common)
        displayLink = link
    }

    @MainActor
    @objc private func tick(_ link: CADisplayLink) {
        let current = views.allObjects
        for view in current {
            view._llFrameTick(timestamp: link.timestamp)
        }
    }
}

public final class LLGlassView: UIView {
    public var configuration: LegacyLiquidGlass.Configuration {
        didSet {
            rebuild()
            backdropCoordinator?.markDirty()
            updateBackdropRegistration()
            requestCapture(force: true)
        }
    }

    public var isHighlighted = false { didSet { updateHighlight(animated: true) } }
    public var glassContentView: UIView { contentView }

    public var morphDescriptor: LLGlassShapeDescriptor = .zero {
        didSet { updateMetalMorph() }
    }

    public var morphDescriptors: [LLGlassShapeDescriptor] = [] {
        didSet { updateMetalMorph() }
    }

    internal var skipBackdropCapture = false

    private let contentView = UIView()
    private let legacyRenderer = LLLegacyVisualGlass()
    private let metalContainer = UIView()
    private let highlightOverlay = UIView()
    private let shadowView = UIView()
    private var metalRenderer: LLMetalGlassRenderer?
    private var performanceObservers: [NSObjectProtocol] = []
    private var interactionDriver: LLGlassInteractionDriver?
    private var capturePending = false
    private var time: CGFloat = 0
    private var lastFrame = CACurrentMediaTime()
    private var lastMaterialFrame = CACurrentMediaTime()
    private var lastCaptureRequest = 0.0
    private var lastLayoutBounds = CGRect.zero
    private var didRegisterPerformance = false
    private weak var backdropCoordinator: LLGlassBackdropCoordinator?
    private var sharedSurfaceEnabled = false
    private var currentPointer: CGPoint = CGPoint(x: 0.5, y: 0.5)
    private var pointerStrength: CGFloat = 0
    private var pointerTargetStrength: CGFloat = 0
    private var pointerPressure: CGFloat = 0
    private var pointerPressureTarget: CGFloat = 0
    private var registeredArea: CGFloat = 0
    private var isInContentTransition = false

    public override init(frame: CGRect) {
        configuration = LegacyLiquidGlass.configuration
        super.init(frame: frame)
        setup()
    }

    public required init?(coder: NSCoder) {
        configuration = LegacyLiquidGlass.configuration
        super.init(coder: coder)
        setup()
    }

    public convenience init(configuration: LegacyLiquidGlass.Configuration) {
        self.init(frame: .zero)
        self.configuration = configuration
        rebuild()
    }

    deinit {
        let ownerIdentifier = ObjectIdentifier(self)
        let shouldUnregisterPerformance = didRegisterPerformance
        let area = registeredArea
        let coordinator = backdropCoordinator
        Task { @MainActor in
            LLGlassFrameTicker.shared.unregister(identifier: ownerIdentifier)
            if shouldUnregisterPerformance {
                LLGlassPerformanceGovernor.shared.unregisterGlass(area: area)
            }
            coordinator?.unregister(ownerIdentifier: ownerIdentifier)
        }
        performanceObservers.forEach(NotificationCenter.default.removeObserver)
    }

    private func setup() {
        backgroundColor = .clear
        isOpaque = false
        clipsToBounds = false
        layer.masksToBounds = false

        shadowView.backgroundColor = .clear
        shadowView.isUserInteractionEnabled = false
        addSubview(shadowView)

        metalContainer.backgroundColor = .clear
        metalContainer.isUserInteractionEnabled = false
        addSubview(metalContainer)

        legacyRenderer.isUserInteractionEnabled = false
        addSubview(legacyRenderer)

        highlightOverlay.isUserInteractionEnabled = false
        highlightOverlay.backgroundColor = UIColor.white.withAlphaComponent(0.16)
        highlightOverlay.alpha = 0
        highlightOverlay.layer.masksToBounds = true
        addSubview(highlightOverlay)

        contentView.backgroundColor = .clear
        addSubview(contentView)

        installObservers()
        rebuild()
    }

    private func installObservers() {
        performanceObservers.append(NotificationCenter.default.addObserver(
            forName: .LLGlassEnvironmentDidChange, object: nil, queue: .main) { [weak self] _ in
            Task { @MainActor [weak self] in
                self?.rebuild()
            }
        })
        performanceObservers.append(NotificationCenter.default.addObserver(
            forName: .LLGlassPerformanceDidChange, object: nil, queue: .main) { [weak self] _ in
            Task { @MainActor [weak self] in
                self?.applyQualityChange()
            }
        })
        performanceObservers.append(NotificationCenter.default.addObserver(
            forName: UIApplication.didBecomeActiveNotification, object: nil, queue: .main) { [weak self] _ in
            Task { @MainActor [weak self] in
                self?.restartRenderingIfNeeded()
            }
        })
        performanceObservers.append(NotificationCenter.default.addObserver(
            forName: UIApplication.didEnterBackgroundNotification, object: nil, queue: .main) { [weak self] _ in
            Task { @MainActor [weak self] in
                self?.stopRendering()
            }
        })
        performanceObservers.append(NotificationCenter.default.addObserver(
            forName: UIApplication.willResignActiveNotification, object: nil, queue: .main) { [weak self] _ in
            Task { @MainActor [weak self] in
                self?.stopRendering()
            }
        })
        performanceObservers.append(NotificationCenter.default.addObserver(
            forName: UIDevice.orientationDidChangeNotification, object: nil, queue: .main) { [weak self] _ in
            Task { @MainActor [weak self] in
                self?.requestCapture(force: true)
            }
        })
    }

    public override func didMoveToWindow() {
        super.didMoveToWindow()

        backdropCoordinator?.unregister(owner: self)
        backdropCoordinator = nil

        if let win = window {
            LLGlassExclusionRegistry.shared.register(self)

            if !didRegisterPerformance {
                registeredArea = bounds.width * bounds.height
                LLGlassPerformanceGovernor.shared.registerGlass(area: registeredArea)
                didRegisterPerformance = true
            }

            if LLMetalShared.isUsable {
                let coordinator = LLGlassBackdropCoordinatorRegistry.shared.coordinator(for: win)
                backdropCoordinator = coordinator
                updateBackdropRegistration()
            } else {
                backdropCoordinator = nil
            }
            LLGlassFrameTicker.shared.refreshRateChanged()

            restartRenderingIfNeeded()
        } else {
            stopRendering()
            LLGlassExclusionRegistry.shared.unregister(self)

            if didRegisterPerformance {
                LLGlassPerformanceGovernor.shared.unregisterGlass(area: registeredArea)
                didRegisterPerformance = false
            }
        }
    }

    public override func layoutSubviews() {
        super.layoutSubviews()
        applyCornerRadius()
        shadowView.frame = bounds.offsetBy(dx: configuration.shadowOffset.width,
                                            dy: configuration.shadowOffset.height)
        shadowView.layer.shadowPath = LLGlassGeometry.roundedPath(
            bounds: shadowView.bounds, radius: configuration.cornerRadius).cgPath
        shadowView.layer.shadowOpacity = configuration.shadowOpacity
        shadowView.layer.shadowRadius = configuration.shadowRadius
        shadowView.layer.shadowOffset = .zero

        metalContainer.frame = bounds
        legacyRenderer.frame = bounds
        highlightOverlay.frame = bounds.insetBy(dx: 1, dy: 1)
        contentView.frame = bounds

        metalRenderer?.view.frame = metalContainer.bounds
        if let rendererView = metalRenderer?.view {
            rendererView.contentScaleFactor = window?.screen.scale ?? UIScreen.main.scale
        }
        if lastLayoutBounds != bounds {
            lastLayoutBounds = bounds
            let newArea = bounds.width * bounds.height
            if didRegisterPerformance && newArea != registeredArea {
                LLGlassPerformanceGovernor.shared.unregisterGlass(area: registeredArea)
                registeredArea = newArea
                LLGlassPerformanceGovernor.shared.registerGlass(area: registeredArea)
            }
            updateBackdropRegistration()
            requestCapture(force: true)
        }
    }

    private func updateBackdropRegistration() {
        guard let coordinator = backdropCoordinator else { return }
        coordinator.register(
            owner: self,
            captureScale: configuration.captureScale,
            maxCapturePixels: configuration.maxCapturePixels,
            cacheStatic: configuration.cacheStaticBackdrops,
            liveCapture: configuration.liveCapture,
            quality: LegacyLiquidGlass.effectiveQuality(for: configuration)
        )
    }

    internal func invalidateBackdrop() {
        backdropCoordinator?.markDirty()
    }

    /// Temporarily removes the rendered glass surface while UIKit swaps the
    /// underlying view controller. This prevents a cached screenshot of the
    /// previous folder from being shown through transparent glass for a frame.
    public func prepareForContentTransition() {
        guard !isInContentTransition else { return }
        isInContentTransition = true
        backdropCoordinator?.purge()
        hideIndividualGlassSurface()
    }

    /// Restores the material and immediately requests a fresh backdrop.
    public func finishContentTransition() {
        guard isInContentTransition else {
            backdropCoordinator?.markDirty()
            requestCapture(force: true)
            return
        }
        isInContentTransition = false
        rebuild()
        backdropCoordinator?.purge()
        requestCapture(force: true)
    }

    internal func setScrollActive(_ active: Bool) {
        backdropCoordinator?.setScrollActive(active)
        LLGlassPerformanceGovernor.shared.setScrollActive(active)
        backdropCoordinator?.markDirty()
    }

    internal func backdropSnapshot() -> LLBackdropSnapshot? {
        backdropCoordinator?.snapshot()
    }

    internal func requestBackdropCaptureIfNeeded(force: Bool) -> LLBackdropSnapshot? {
        guard !skipBackdropCapture else { return nil }
        return backdropCoordinator?.requestCapture(force: force)
    }

    internal func requestSharedBackdropCapture(force: Bool) -> LLBackdropSnapshot? {
        backdropCoordinator?.requestCapture(force: force)
    }

    private func applyCornerRadius() {
        let radius = configuration.cornerRadius
        layer.cornerRadius = radius
        layer.cornerCurve = .continuous
        contentView.layer.cornerRadius = radius
        contentView.layer.cornerCurve = .continuous
        contentView.layer.masksToBounds = true
        highlightOverlay.layer.cornerRadius = radius
        highlightOverlay.layer.cornerCurve = .continuous
        legacyRenderer.cornerRadius = radius
        metalRenderer?.view.layer.cornerRadius = radius
        metalRenderer?.view.layer.cornerCurve = .continuous
    }

    private func rebuild() {
        updateBackdropRegistration()

        let environment = LLGlassEnvironment.shared
        let material = LLGlassMaterialResolver.resolve(configuration, environment: environment)

        shadowView.isHidden = environment.reduceTransparency
        shadowView.layer.shadowColor = UIColor.black.cgColor

        if sharedSurfaceEnabled {
            hideIndividualGlassSurface()
        } else {
            configureLegacy(material: material)
        }

        updateHighlight(animated: false)
        updateInteraction()
    }

    private func configureLegacy(material: LLGlassMaterial) {
        let environment = LLGlassEnvironment.shared
        guard !sharedSurfaceEnabled else {
            hideIndividualGlassSurface()
            return
        }

        let usesFallback = shouldUseVisualFallback()
        legacyRenderer.isHidden = !usesFallback
        metalContainer.isHidden = usesFallback
        legacyRenderer.material = material
        legacyRenderer.cornerRadius = configuration.cornerRadius

        highlightOverlay.isHidden = !usesFallback
        highlightOverlay.backgroundColor = UIColor.white.withAlphaComponent(
            min(0.22, material.specular * 0.70)
        )

        if !usesFallback {
            if metalRenderer == nil {
                metalRenderer = LLMetalGlassRenderer(frame: bounds)
                if let rendererView = metalRenderer?.view {
                    metalContainer.addSubview(rendererView)
                }
            }

            if metalRenderer == nil {
                legacyRenderer.isHidden = false
                metalContainer.isHidden = true
                highlightOverlay.isHidden = environment.reduceTransparency
                return
            }
            updateMetal(material: material)
        }
    }

    internal func setSharedSurfaceEnabled(_ enabled: Bool) {
        guard sharedSurfaceEnabled != enabled else { return }
        sharedSurfaceEnabled = enabled
        if enabled {
            stopRendering()
            hideIndividualGlassSurface()
        } else {
            rebuild()
            restartRenderingIfNeeded()
        }
    }

    private func hideIndividualGlassSurface() {
        metalContainer.isHidden = true
        legacyRenderer.isHidden = true
        highlightOverlay.isHidden = true
    }

    private static let metalAvailable = LLMetalShared.isUsable

    private func shouldUseVisualFallback() -> Bool {
        let environment = LLGlassEnvironment.shared
        return configuration.backend == .legacy
            || LegacyLiquidGlass.effectiveQuality(for: configuration) == .low
            || !Self.metalAvailable
            || environment.reduceTransparency
    }

    private func updateMetal(material: LLGlassMaterial) {
        guard !sharedSurfaceEnabled, let renderer = metalRenderer else { return }
        let settings = currentMetalSettings(material: material)
        renderer.updateSettings(settings)

        if let snapshot = backdropCoordinator?.snapshot() {
            renderer.update(source: snapshot.texture, settings: settings)
        }
    }

    private func updateMetalMorph() {
        guard !sharedSurfaceEnabled, let renderer = metalRenderer else { return }
        let material = LLGlassMaterialResolver.resolve(configuration)
        var settings = currentMetalSettings(material: material)
        settings.shapes = morphDescriptors.isEmpty ? [morphDescriptor] : morphDescriptors
        renderer.updateSettings(settings)
    }

    private func requestCapture(force: Bool) {
        guard window != nil, !isInContentTransition, !metalContainer.isHidden, !skipBackdropCapture, !sharedSurfaceEnabled else {
            return
        }
        guard !capturePending else { return }

        capturePending = true
        Task { @MainActor [weak self] in
            guard let self = self else { return }
            self.capturePending = false
            guard let coordinator = self.backdropCoordinator,
                  let snapshot = coordinator.requestCapture(force: force) else {
                return
            }

            let material = LLGlassMaterialResolver.resolve(self.configuration)
            let settings = self.currentMetalSettings(material: material)
            self.metalRenderer?.update(source: snapshot.texture, settings: settings)
        }
    }

    internal func currentMetalSettings(material: LLGlassMaterial) -> LLMetalGlassRenderer.Settings {
        let c = LLGlassColorMath.components(material.tint ?? UIColor(white: 1, alpha: 1))
        var settings = LLMetalGlassRenderer.Settings()

        settings.cornerRadius = configuration.cornerRadius

        settings.refraction = material.refraction
        settings.specular = material.specular * (1.0 + pointerPressure * 0.18)
        settings.edgeLight = material.edgeLight
        settings.tintStrength = configuration.tintStrength
        settings.opacity = material.opacity
        settings.darkness = material.darkness
        settings.time = configuration.animated ? time : 0

        let effectiveQuality = LegacyLiquidGlass.effectiveQuality(for: configuration)
        settings.quality = effectiveQuality.shaderQuality
        settings.pyramidLevels = effectiveQuality.blurPyramidLevels

        settings.tint = SIMD4<Float>(c.x, c.y, c.z, 1)
        settings.highlightStrength = configuration.interactive && isHighlighted ? 0.12 : 0.0
        settings.saturation = material.saturation
        settings.contrast = material.contrast
        settings.pointer = SIMD2<Float>(Float(currentPointer.x), Float(currentPointer.y))
        settings.pointerStrength = pointerStrength
        settings.pressure = pointerPressure
        settings.blurRadius = material.blurRadius
        settings.lensThickness = material.lensThickness
        settings.dispersion = material.dispersion * material.edgeDispersion
        settings.fresnelPower = material.fresnelPower
        settings.roughness = material.roughness
        settings.absorption = material.absorption
        settings.ior = material.ior
        settings.environmentLight = material.environmentLight
        settings.reflectionMix = material.reflectionMix
        settings.normalStrength = material.normalStrength
        settings.bevelWidth = material.bevelWidth
        settings.curvatureStrength = material.curvatureStrength
        settings.microRoughness = material.microRoughness
        settings.environmentOffset = material.environmentOffset
        settings.dynamicLightStrength = material.dynamicLightStrength * material.interactionStrength
        settings.interactionStrength = material.interactionStrength
        settings.depthAttenuation = material.depthAttenuation
        settings.edgeDispersion = material.edgeDispersion
        settings.useDeepBlur = configuration.useDeepBlur
        settings.refractionScale = configuration.refractionScale
        settings.highlightWidth = configuration.highlightWidth
        settings.rimWidth = configuration.rimWidth
        settings.shapeScale = min(
            window?.screen.scale ?? UIScreen.main.scale,
            max(1.0, configuration.maxRenderScale)
        )
        settings.sourceOriginUV = sourceOriginUV
        settings.sourceSizeUV = sourceSizeUV

        if configuration.morphing {
            let hasDescriptor = morphDescriptor.halfSize.x > 0.5 && morphDescriptor.halfSize.y > 0.5
            if !morphDescriptors.isEmpty {
                settings.shapes = Array(morphDescriptors.prefix(min(32, max(1, configuration.maximumMorphShapes))))
            } else if hasDescriptor {
                settings.shapes = [morphDescriptor]
            } else {
                settings.shapes = []
            }
            settings.morphSmoothness = Float(configuration.morphSmoothness)
        }

        return settings
    }

    private var sourceOriginUV: SIMD2<Float> {
        guard let win = window, let snapshot = backdropCoordinator?.snapshot(),
              snapshot.rect.width > 0, snapshot.rect.height > 0 else { return .zero }
        let frame = convert(bounds, to: win)
        return SIMD2(
            Float((frame.minX - snapshot.rect.minX) / snapshot.rect.width),
            Float((frame.minY - snapshot.rect.minY) / snapshot.rect.height)
        )
    }

    private var sourceSizeUV: SIMD2<Float> {
        guard let win = window, let snapshot = backdropCoordinator?.snapshot(),
              snapshot.rect.width > 0, snapshot.rect.height > 0 else { return SIMD2(1, 1) }
        let frame = convert(bounds, to: win)
        return SIMD2(
            Float(max(0, frame.width) / snapshot.rect.width),
            Float(max(0, frame.height) / snapshot.rect.height)
        )
    }

    private func applyQualityChange() {
        guard !metalContainer.isHidden || sharedSurfaceEnabled else { return }

        LLGlassFrameTicker.shared.refreshRateChanged()

        let material = LLGlassMaterialResolver.resolve(configuration)
        if !sharedSurfaceEnabled {
            updateMetal(material: material)
        }
        backdropCoordinator?.markDirty()
        requestCapture(force: true)
    }

    private func updateInteraction() {
        guard configuration.interactive else {
            interactionDriver?.uninstall()
            interactionDriver = nil
            return
        }
        if interactionDriver == nil {
            let driver = LLGlassInteractionDriver(view: self)
            driver.onPointerUpdate = { [weak self] normalized in
                guard let self = self else { return }
                self.currentPointer = normalized
                self.pointerTargetStrength = self.configuration.pointerInteraction ? 1.0 : 0.0
            }
            driver.onPressureUpdate = { [weak self] pressure in
                guard let self = self else { return }
                self.pointerPressureTarget = pressure
            }
            driver.install()
            interactionDriver = driver
        }
    }

    private func updateHighlight(animated: Bool) {
        let alpha: CGFloat = (isHighlighted && !LLGlassEnvironment.shared.reduceTransparency) ? 1.0 : 0.0
        let changes = {
            self.highlightOverlay.alpha = alpha
            self.highlightOverlay.transform = self.isHighlighted
                ? CGAffineTransform(scaleX: 0.992, y: 0.992) : .identity
        }
        if animated && configuration.animated && !LLGlassEnvironment.shared.reduceMotion {
            UIView.animate(withDuration: isHighlighted ? 0.12 : 0.26, delay: 0,
                           usingSpringWithDamping: 0.78,
                           initialSpringVelocity: 0.3,
                           options: [.beginFromCurrentState, .allowUserInteraction],
                           animations: changes)
        } else {
            changes()
        }
    }

    private func restartRenderingIfNeeded() {
        guard window != nil else { return }
        guard configuration.animated || configuration.liveCapture || configuration.interactive else {
            LLGlassFrameTicker.shared.unregister(self)
            return
        }

        LLGlassFrameTicker.shared.register(self)
        LLGlassPerformanceGovernor.shared.start()
        if !sharedSurfaceEnabled {
            requestCapture(force: true)
        } else {
            backdropCoordinator?.markDirty()
        }
    }

    private func stopRendering() {
        LLGlassFrameTicker.shared.unregister(self)
    }

    internal func _llFrameTick(timestamp: CFTimeInterval) {
        guard window != nil, !isInContentTransition else { return }
        guard window != nil else {
            LLGlassFrameTicker.shared.unregister(self)
            return
        }
        let now = timestamp
        if lastFrame == 0 { lastFrame = now }

        let delta = CGFloat(max(0, now - lastFrame))
        lastFrame = now

        if configuration.animated {
            time += delta
        }

        pointerStrength += (pointerTargetStrength - pointerStrength) * 0.16
        if pointerTargetStrength == 0 && pointerStrength < 0.01 { pointerStrength = 0 }

        if pointerPressureTarget > 0 {
            pointerPressure += (pointerPressureTarget - pointerPressure) * 0.20
        } else {
            pointerPressure += (0 - pointerPressure) * 0.15
            if pointerPressure < 0.01 { pointerPressure = 0 }
        }

        let activeInteraction = isHighlighted || pointerStrength > 0.025 || pointerPressure > 0.025
        let targetFPS = activeInteraction
            ? min(60, max(30, configuration.preferredFrameRate))
            : min(60, max(15, configuration.idleFrameRate))
        let minMaterialInterval = 1.0 / Double(targetFPS)
        if !sharedSurfaceEnabled, now - lastMaterialFrame >= minMaterialInterval || activeInteraction {
            lastMaterialFrame = now
            let material = LLGlassMaterialResolver.resolve(configuration)
            metalRenderer?.updateSettings(currentMetalSettings(material: material))
        }

        guard configuration.liveCapture, !sharedSurfaceEnabled else { return }
        if backdropCoordinator != nil, !configuration.liveCaptureDuringScroll, LLGlassPerformanceGovernor.shared.isScrolling { return }

        let shouldContinuouslyCapture = configuration.liveCapture
        let coordinatorDirty = backdropCoordinator?.hasDirtyBackdrop ?? false

        if shouldContinuouslyCapture || coordinatorDirty {
            let targetFPS = LegacyLiquidGlass.effectiveQuality(for: configuration).captureFPS
            let captureInterval = 1.0 / Double(max(1, targetFPS))
            if now - lastCaptureRequest >= captureInterval {
                lastCaptureRequest = now
                requestCapture(force: false)
            }
        }
    }
}

public final class LLGlassContainer: UIView {
    public var spacing: CGFloat = 10 {
        didSet {
            updateMorphDescriptors()
            setNeedsLayout()
        }
    }

    public var morphing = true {
        didSet { updateMorphDescriptors() }
    }

    public var axis: NSLayoutConstraint.Axis = .horizontal {
        didSet { setNeedsLayout() }
    }

    public var morphSmoothness: CGFloat = 0.35 {
        didSet { updateMorphDescriptors() }
    }

    private var glassItems: [LLGlassView] = []
    private var lastBounds = CGRect.zero
    private var sharedMorphRenderer: LLMetalGlassRenderer?
    private var sharedDisplayLink: CADisplayLink?

    public override init(frame: CGRect) {
        super.init(frame: frame)
        backgroundColor = .clear
        clipsToBounds = false
    }

    public required init?(coder: NSCoder) {
        super.init(coder: coder)
        backgroundColor = .clear
        clipsToBounds = false
    }

    deinit {
        let displayLink = sharedDisplayLink
        let sharedView = sharedMorphRenderer?.view
        Task { @MainActor in
            displayLink?.invalidate()
            if let sharedView {
                LLGlassExclusionRegistry.shared.unregister(sharedView)
                sharedView.removeFromSuperview()
            }
        }
    }

    public func addGlass(_ glass: LLGlassView) {
        guard !glassItems.contains(where: { $0 === glass }) else { return }
        glassItems.append(glass)
        glass.skipBackdropCapture = false
        addSubview(glass)
        setNeedsLayout()
        updateMorphDescriptors()
        updateRenderingSurface()
    }

    public func removeGlass(_ glass: LLGlassView) {
        glassItems.removeAll { $0 === glass }
        glass.skipBackdropCapture = false
        glass.setSharedSurfaceEnabled(false)
        glass.removeFromSuperview()
        setNeedsLayout()
        updateMorphDescriptors()
        updateRenderingSurface()
    }

    public override func layoutSubviews() {
        super.layoutSubviews()
        sharedMorphRenderer?.view.frame = bounds

        guard !glassItems.isEmpty else {
            updateRenderingSurface()
            return
        }

        let sizes = glassItems.map { preferredSize(for: $0) }
        if axis == .horizontal {
            var x: CGFloat = 0
            for (index, glass) in glassItems.enumerated() {
                let size = sizes[index]
                glass.frame = CGRect(
                    x: x,
                    y: max(0, (bounds.height - size.height) * 0.5),
                    width: size.width,
                    height: size.height
                )
                x += size.width + (index == glassItems.count - 1 ? 0 : spacing)
            }
        } else {
            var y: CGFloat = 0
            for (index, glass) in glassItems.enumerated() {
                let size = sizes[index]
                glass.frame = CGRect(
                    x: max(0, (bounds.width - size.width) * 0.5),
                    y: y,
                    width: size.width,
                    height: size.height
                )
                y += size.height + (index == glassItems.count - 1 ? 0 : spacing)
            }
        }

        if lastBounds != bounds {
            lastBounds = bounds
            updateMorphDescriptors()
        }
        updateRenderingSurface()
    }

    private func preferredSize(for view: UIView) -> CGSize {
        let target = view.intrinsicContentSize
        let width = target.width > 0 ? target.width : max(44, bounds.width / max(1, CGFloat(glassItems.count)))
        let height = target.height > 0 ? target.height : 44
        return CGSize(width: min(width, bounds.width), height: min(height, bounds.height))
    }

    private func updateSharedLegacySurface(forceCapture: Bool = false) {
        let canShare = LegacyLiquidGlass.configuration.sharedSurface
            && glassItems.count > 1
            && LLMetalShared.isUsable
        guard canShare else {
            sharedMorphRenderer?.view.isHidden = true
            for glass in glassItems {
                glass.skipBackdropCapture = false
                glass.setSharedSurfaceEnabled(false)
            }
            return
        }

        guard let first = glassItems.first, let window = first.window else { return }

        if sharedMorphRenderer == nil {
            sharedMorphRenderer = LLMetalGlassRenderer(frame: bounds)
            if let view = sharedMorphRenderer?.view {
                view.frame = bounds
                view.isUserInteractionEnabled = false
                view.contentScaleFactor = min(window.screen.scale, max(1.0, first.configuration.maxRenderScale))
                LLGlassExclusionRegistry.shared.register(view)
                insertSubview(view, at: 0)
            }
        }

        guard let renderer = sharedMorphRenderer else {
            for glass in glassItems {
                glass.skipBackdropCapture = false
                glass.setSharedSurfaceEnabled(false)
            }
            return
        }

        let snapshot: LLBackdropSnapshot?
        if forceCapture {
            snapshot = first.requestSharedBackdropCapture(force: true)
                ?? first.backdropSnapshot()
        } else {
            snapshot = first.requestSharedBackdropCapture(force: false)
                ?? first.backdropSnapshot()
        }
        guard let coordinatorSnapshot = snapshot else { return }

        let activeGlass = glassItems.first(where: { $0.isHighlighted }) ?? first
        let material = LLGlassMaterialResolver.resolve(activeGlass.configuration)
        var settings = activeGlass.currentMetalSettings(material: material)
        if activeGlass.configuration.animated {
            settings.time = CGFloat(CACurrentMediaTime())
        }
        settings.isContainerMorph = morphing
        settings.shapes = sharedShapeDescriptors()
        settings.morphSmoothness = Float(morphSmoothness)
        settings.sourceOriginUV = sourceOriginUV(in: window)
        settings.sourceSizeUV = sourceSizeUV(in: window)

        renderer.view.isHidden = false
        renderer.view.frame = bounds
        renderer.view.contentScaleFactor = min(window.screen.scale, max(1.0, first.configuration.maxRenderScale))
        renderer.update(source: coordinatorSnapshot.texture, settings: settings)

        for glass in glassItems {
            glass.skipBackdropCapture = true
            glass.setSharedSurfaceEnabled(true)
        }
    }

    private func updateRenderingSurface() {
        updateSharedLegacySurface(forceCapture: false)
        updateSharedDisplayLink()
    }

    private func updateSharedDisplayLink() {
        let needsAnimation = glassItems.contains {
            $0.configuration.animated || $0.configuration.liveCapture || $0.configuration.interactive
        }
        guard needsAnimation,
              sharedMorphRenderer?.view.isHidden == false,
              sharedMorphRenderer != nil else {
            sharedDisplayLink?.invalidate()
            sharedDisplayLink = nil
            return
        }

        if sharedDisplayLink == nil {
            let link = CADisplayLink(target: self, selector: #selector(sharedRenderTick(_:)))
            link.preferredFramesPerSecond = min(
                max(LegacyLiquidGlass.configuration.preferredFrameRate, 30),
                60
            )
            link.add(to: .main, forMode: .common)
            sharedDisplayLink = link
        }
    }

    @objc private func sharedRenderTick(_ link: CADisplayLink) {
        guard !glassItems.isEmpty else {
            link.invalidate()
            sharedDisplayLink = nil
            return
        }
        updateSharedLegacySurface(forceCapture: glassItems.contains { $0.configuration.liveCapture })
    }

    private func updateMorphDescriptors() {
        guard !glassItems.isEmpty else { return }
        let allShapes = sharedShapeDescriptors()

        if morphing && glassItems.count > 1 {
            for glass in glassItems {
                let frameInSelf = glass.convert(glass.bounds, to: self)
                let center = SIMD2<Float>(Float(frameInSelf.midX), Float(frameInSelf.midY))
                let halfSize = SIMD2<Float>(Float(frameInSelf.width * 0.5), Float(frameInSelf.height * 0.5))
                glass.morphDescriptors = allShapes.map { shape in
                    var relative = shape
                    relative.center = shape.center - center + halfSize
                    return relative
                }
            }
        } else {
            for glass in glassItems { glass.morphDescriptors = [] }
        }

        updateRenderingSurface()
    }

    private func sharedShapeDescriptors() -> [LLGlassShapeDescriptor] {
        guard !glassItems.isEmpty else { return [] }
        let effectiveSmoothness = morphing
            ? min(1.0, max(morphSmoothness, spacing / 48.0))
            : 0.0
        return glassItems.prefix(32).map { glass in
            let frameInSelf = glass.convert(glass.bounds, to: self)
            return LLGlassShapeDescriptor(
                center: SIMD2<Float>(Float(frameInSelf.midX), Float(frameInSelf.midY)),
                halfSize: SIMD2<Float>(Float(frameInSelf.width * 0.5), Float(frameInSelf.height * 0.5)),
                cornerRadius: Float(glass.configuration.cornerRadius),
                smoothness: Float(effectiveSmoothness)
            )
        }
    }

    private func sourceOriginUV(in window: UIWindow) -> SIMD2<Float> {
        guard let snapshot = glassItems.first?.backdropSnapshot(), snapshot.rect.width > 0, snapshot.rect.height > 0 else { return .zero }
        let frame = convert(bounds, to: window)
        return SIMD2(Float((frame.minX - snapshot.rect.minX) / snapshot.rect.width),
                     Float((frame.minY - snapshot.rect.minY) / snapshot.rect.height))
    }

    private func sourceSizeUV(in window: UIWindow) -> SIMD2<Float> {
        guard let snapshot = glassItems.first?.backdropSnapshot(), snapshot.rect.width > 0, snapshot.rect.height > 0 else { return SIMD2(1, 1) }
        let frame = convert(bounds, to: window)
        return SIMD2(Float(max(0, frame.width) / snapshot.rect.width),
                     Float(max(0, frame.height) / snapshot.rect.height))
    }
}

public final class LLGlassButton: UIButton {
    public var glassConfiguration: LegacyLiquidGlass.Configuration = .init() {
        didSet { rebuildGlass() }
    }

    private let glass = LLGlassView()

    public override var isHighlighted: Bool {
        didSet { glass.isHighlighted = isHighlighted }
    }

    public override var isSelected: Bool {
        didSet { rebuildGlass() }
    }

    public override init(frame: CGRect) { super.init(frame: frame); setup() }
    public required init?(coder: NSCoder) { super.init(coder: coder); setup() }

    private func setup() {
        setTitleColor(.label, for: .normal)
        layer.cornerCurve = .continuous
        contentHorizontalAlignment = .center
        contentVerticalAlignment = .center
        insertSubview(glass, at: 0)
        rebuildGlass()
    }

    private func rebuildGlass() {
        var config = glassConfiguration
        if isSelected, case .regular = config.style { config.style = .prominent }
        glass.configuration = config
        sendSubviewToBack(glass)
        setNeedsLayout()
    }

    public override func layoutSubviews() {
        super.layoutSubviews()
        glass.frame = bounds
    }

    public override func tintColorDidChange() {
        super.tintColorDidChange()
        if tintColor != nil, case .regular = glassConfiguration.style {
            glassConfiguration.style = .tinted(tintColor)
        }
    }
}

public final class LLGlassToolbar: UIView {
    public let contentView = UIView()
    private let glass = LLGlassView()
    public var configuration: LegacyLiquidGlass.Configuration {
        didSet { glass.configuration = configuration }
    }

    public override init(frame: CGRect) {
        configuration = LegacyLiquidGlass.Configuration()
        super.init(frame: frame)
        setup()
    }

    public required init?(coder: NSCoder) {
        configuration = LegacyLiquidGlass.Configuration()
        super.init(coder: coder)
        setup()
    }

    private func setup() {
        backgroundColor = .clear
        addSubview(glass)
        addSubview(contentView)
        contentView.backgroundColor = .clear
    }

    public override func layoutSubviews() {
        super.layoutSubviews()
        glass.frame = bounds.insetBy(dx: 12, dy: 6)
        contentView.frame = glass.frame
    }
}

public final class LLGlassSearchBar: UIView {
    public let textField = UITextField()
    private let glass = LLGlassView()
    private let iconView = UIImageView(image: UIImage(systemName: "magnifyingglass"))
    private let clearButton = UIButton(type: .system)

    public var placeholder: String = LLGlassLocalization.string("search") {
        didSet { textField.placeholder = placeholder }
    }

    public var onClear: (() -> Void)?

    public override init(frame: CGRect) { super.init(frame: frame); setup() }
    public required init?(coder: NSCoder) { super.init(coder: coder); setup() }

    private func setup() {
        addSubview(glass)
        addSubview(iconView)
        addSubview(textField)
        addSubview(clearButton)
        iconView.tintColor = .secondaryLabel
        iconView.contentMode = .scaleAspectFit
        textField.borderStyle = .none
        textField.clearButtonMode = .never
        textField.placeholder = placeholder
        clearButton.setImage(UIImage(systemName: "xmark.circle.fill"), for: .normal)
        clearButton.tintColor = .tertiaryLabel
        clearButton.addTarget(self, action: #selector(clearText), for: .touchUpInside)
        var config = LegacyLiquidGlass.Configuration()
        config.style = .clear
        config.cornerRadius = 18
        glass.configuration = config
    }

    @objc private func clearText() {
        textField.text = nil
        onClear?()
    }

    public override func layoutSubviews() {
        super.layoutSubviews()
        glass.frame = bounds
        let h = bounds.height
        iconView.frame = CGRect(x: 12, y: (h - 20) * 0.5, width: 20, height: 20)
        textField.frame = CGRect(x: 38, y: 0, width: max(0, bounds.width - 78), height: h)
        clearButton.frame = CGRect(x: max(0, bounds.width - 38), y: 0, width: 30, height: h)
    }
}

public final class LLGlassTabBar: UIView {
    public struct Item {
        public var title: String
        public var image: UIImage?
        public var selectedImage: UIImage?
        public init(title: String, image: UIImage? = nil, selectedImage: UIImage? = nil) {
            self.title = title; self.image = image; self.selectedImage = selectedImage
        }
    }

    public var items: [Item] = [] { didSet { rebuildItems() } }
    public var selectedIndex: Int = 0 { didSet { updateSelection(animated: true) } }
    public var onSelectionChanged: ((Int) -> Void)?

    private let glass = LLGlassView()
    private var buttons: [LLGlassButton] = []
    private var actionTargets: [LLClosureControlTarget] = []

    public override init(frame: CGRect) {
        super.init(frame: frame)
        backgroundColor = .clear
        addSubview(glass)
        var config = LegacyLiquidGlass.Configuration()
        config.cornerRadius = 26
        config.style = .regular
        glass.configuration = config
    }

    public required init?(coder: NSCoder) {
        super.init(coder: coder)
        backgroundColor = .clear
        addSubview(glass)
        var config = LegacyLiquidGlass.Configuration()
        config.cornerRadius = 26
        config.style = .regular
        glass.configuration = config
    }

    private func rebuildItems() {
        buttons.forEach { $0.removeFromSuperview() }
        buttons.removeAll()
        actionTargets.removeAll()
        for item in items {
            let button = LLGlassButton(type: .system)
            button.setTitle(item.title, for: .normal)
            button.setImage(item.image, for: .normal)
            button.titleLabel?.font = .preferredFont(forTextStyle: .caption1)
            button.tintColor = .label
            addSubview(button)
            buttons.append(button)
            let target = LLClosureControlTarget { [weak self, weak button] in
                guard let self = self, let button = button,
                      let index = self.buttons.firstIndex(where: { $0 === button }) else { return }
                self.selectedIndex = index
                self.onSelectionChanged?(index)
            }
            actionTargets.append(target)
            button.llStoreActionTarget(target)
        }
        setNeedsLayout()
    }

    public override func layoutSubviews() {
        super.layoutSubviews()
        glass.frame = bounds
        let count = max(1, buttons.count)
        let width = bounds.width / CGFloat(count)
        for (index, button) in buttons.enumerated() {
            button.frame = CGRect(x: CGFloat(index) * width + 4, y: 4,
                                  width: width - 8, height: max(0, bounds.height - 8))
        }
        updateSelection(animated: false)
    }

    private func updateSelection(animated: Bool) {
        let apply = {
            for (index, button) in self.buttons.enumerated() {
                let selected = index == self.selectedIndex
                var config = button.glassConfiguration
                config.style = selected ? .prominent : .clear
                button.glassConfiguration = config
                if index < self.items.count {
                    let item = self.items[index]
                    let image = selected ? (item.selectedImage ?? item.image) : item.image
                    button.setImage(image, for: .normal)
                }
                button.tintColor = selected ? .label : .secondaryLabel
            }
        }

        if animated && !LLGlassEnvironment.shared.reduceMotion {
            UIView.animate(withDuration: 0.26, delay: 0,
                           usingSpringWithDamping: 0.75,
                           initialSpringVelocity: 0.5,
                           options: [.beginFromCurrentState, .allowUserInteraction],
                           animations: apply)
        } else {
            apply()
        }
    }
}

public final class LLGlassNavigationBar: UIView {
    public let contentView = UIView()
    public let titleLabel = UILabel()
    public let subtitleLabel = UILabel()

    private let glass = LLGlassView()

    public override init(frame: CGRect) { super.init(frame: frame); setup() }
    public required init?(coder: NSCoder) { super.init(coder: coder); setup() }

    private func setup() {
        backgroundColor = .clear
        addSubview(glass)
        addSubview(contentView)
        contentView.backgroundColor = .clear
        titleLabel.font = .preferredFont(forTextStyle: .headline)
        titleLabel.adjustsFontForContentSizeCategory = true
        subtitleLabel.font = .preferredFont(forTextStyle: .caption1)
        subtitleLabel.adjustsFontForContentSizeCategory = true
        subtitleLabel.textColor = .secondaryLabel
        contentView.addSubview(titleLabel)
        contentView.addSubview(subtitleLabel)
        var config = LegacyLiquidGlass.Configuration()
        config.cornerRadius = 22
        config.style = .regular
        glass.configuration = config
    }

    public override func layoutSubviews() {
        super.layoutSubviews()
        glass.frame = bounds.insetBy(dx: 10, dy: 6)
        contentView.frame = glass.frame
        let titleHeight = min(24, contentView.bounds.height)
        titleLabel.frame = CGRect(x: 18,
                                  y: max(0, (contentView.bounds.height - titleHeight) * 0.5 - 6),
                                  width: max(0, contentView.bounds.width - 36),
                                  height: titleHeight)
        subtitleLabel.frame = CGRect(x: 18,
                                     y: min(contentView.bounds.height - 18, titleLabel.frame.maxY),
                                     width: max(0, contentView.bounds.width - 36),
                                     height: 16)
    }
}

public final class LLGlassCard: UIView {
    private let glass = LLGlassView()
    public let contentView = UIView()

    public var cornerRadius: CGFloat = 28 {
        didSet {
            glass.configuration.cornerRadius = cornerRadius
            setNeedsLayout()
        }
    }

    public override init(frame: CGRect) { super.init(frame: frame); setup() }
    public required init?(coder: NSCoder) { super.init(coder: coder); setup() }

    private func setup() {
        addSubview(glass)
        addSubview(contentView)
        contentView.backgroundColor = .clear
        var config = LegacyLiquidGlass.Configuration()
        config.cornerRadius = cornerRadius
        config.style = .prominent
        glass.configuration = config
    }

    public override func layoutSubviews() {
        super.layoutSubviews()
        glass.frame = bounds
        contentView.frame = bounds.insetBy(dx: 12, dy: 12)
    }
}

public struct LLGlassModifier: ViewModifier {
    public var configuration: LegacyLiquidGlass.Configuration

    public init(configuration: LegacyLiquidGlass.Configuration = .init()) {
        self.configuration = configuration
    }

    public func body(content: Content) -> some View {
        content.background(
            LLGlassRepresentable(configuration: configuration)
                .allowsHitTesting(false)
                .clipShape(RoundedRectangle(cornerRadius: configuration.cornerRadius, style: .continuous))
        )
    }
}

public extension View {
    func llGlass(_ configuration: LegacyLiquidGlass.Configuration = .init()) -> some View {
        modifier(LLGlassModifier(configuration: configuration))
    }

    func llGlassClear(cornerRadius: CGFloat = 20, interactive: Bool = true) -> some View {
        var config = LegacyLiquidGlass.Configuration()
        config.style = .clear
        config.cornerRadius = cornerRadius
        config.interactive = interactive
        return modifier(LLGlassModifier(configuration: config))
    }

    func llGlassProminent(cornerRadius: CGFloat = 22, interactive: Bool = true) -> some View {
        var config = LegacyLiquidGlass.Configuration()
        config.style = .prominent
        config.cornerRadius = cornerRadius
        config.interactive = interactive
        return modifier(LLGlassModifier(configuration: config))
    }

    func llGlassTinted(_ tint: Color, cornerRadius: CGFloat = 22, interactive: Bool = true) -> some View {
        var config = LegacyLiquidGlass.Configuration()
        config.style = .tinted(LLGlassColorBridge.color(tint))
        config.cornerRadius = cornerRadius
        config.interactive = interactive
        return modifier(LLGlassModifier(configuration: config))
    }
}

public struct LLGlassRepresentable: UIViewRepresentable {
    public var configuration: LegacyLiquidGlass.Configuration

    public init(configuration: LegacyLiquidGlass.Configuration) {
        self.configuration = configuration
    }

    public func makeUIView(context: Context) -> LLGlassView {
        LLGlassView(configuration: configuration)
    }

    public func updateUIView(_ uiView: LLGlassView, context: Context) {
        uiView.configuration = configuration
    }
}

public struct LLGlassContainerView<Content: View>: View {
    public var spacing: CGFloat
    public var configuration: LegacyLiquidGlass.Configuration
    private let content: Content

    public init(
        spacing: CGFloat = 12,
        configuration: LegacyLiquidGlass.Configuration = .init(),
        @ViewBuilder content: () -> Content
    ) {
        self.spacing = spacing
        self.configuration = configuration
        self.content = content()
    }

    public var body: some View {
        HStack(spacing: spacing) { content }
            .modifier(LLGlassModifier(configuration: configuration))
    }
}

public struct LLGlassButtonStyle: ButtonStyle {
    public var prominent: Bool
    public var tint: Color?

    public init(prominent: Bool = false, tint: Color? = nil) {
        self.prominent = prominent
        self.tint = tint
    }

    public func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .frame(minWidth: 44, minHeight: 44)
            .contentShape(Rectangle())
            .modifier(LLGlassModifier(configuration: makeConfiguration(isPressed: configuration.isPressed)))
            .scaleEffect(configuration.isPressed && !LLGlassEnvironment.shared.reduceMotion ? 0.97 : 1)
            .animation(LLGlassEnvironment.shared.reduceMotion ? nil
                       : .interactiveSpring(response: 0.24, dampingFraction: 0.72))
    }

    private func makeConfiguration(isPressed: Bool) -> LegacyLiquidGlass.Configuration {
        var config = LegacyLiquidGlass.Configuration()
        if let tint = tint {
            config.style = .tinted(UIColor(tint))
        } else {
            config.style = prominent ? .prominent : .regular
        }
        config.interactive = true
        config.cornerRadius = 20
        config.specularStrength = isPressed ? 0.34 : 0.28
        config.refractionStrength = isPressed ? 0.022 : 0.016
        config.lensThickness = isPressed ? 0.58 : 0.45
        return config
    }
}

public struct LLGlassActionButton: View {
    private let title: String
    private let systemImage: String?
    private let prominent: Bool
    private let action: () -> Void

    public init(_ title: String, systemImage: String? = nil,
                prominent: Bool = false, action: @escaping () -> Void) {
        self.title = title
        self.systemImage = systemImage
        self.prominent = prominent
        self.action = action
    }

    @ViewBuilder
    public var body: some View {
        Button(action: action) {
            HStack(spacing: 7) {
                if let systemImage = systemImage {
                    Image(systemName: systemImage)
                }
                Text(title)
            }
        }
        .buttonStyle(LLGlassButtonStyle(prominent: prominent))
    }
}

public struct LLGlassToolbarItem<Label: View>: View {
    private let label: () -> Label
    private let prominent: Bool
    private let action: () -> Void

    public init(prominent: Bool = false, action: @escaping () -> Void,
                @ViewBuilder label: @escaping () -> Label) {
        self.prominent = prominent
        self.action = action
        self.label = label
    }

    public var body: some View {
        Button(action: action) {
            label().padding(.horizontal, 14).padding(.vertical, 10)
        }
        .buttonStyle(LLGlassButtonStyle(prominent: prominent))
    }
}

public struct LLLiquidRoundedRectangle: SwiftUI.Shape {
    public var radius: CGFloat
    public var animatableData: CGFloat {
        get { radius }
        set { radius = newValue }
    }
    public init(radius: CGFloat) { self.radius = radius }
    public func path(in rect: CGRect) -> SwiftUI.Path {
        SwiftUI.Path(UIBezierPath(roundedRect: rect,
                                  cornerRadius: min(radius, min(rect.width, rect.height) * 0.5)).cgPath)
    }
}

public struct LLGlassBackgroundStyle: ViewModifier {
    public var style: LegacyLiquidGlass.Style
    public var cornerRadius: CGFloat

    public init(style: LegacyLiquidGlass.Style = .regular, cornerRadius: CGFloat = 24) {
        self.style = style; self.cornerRadius = cornerRadius
    }

    public func body(content: Content) -> some View {
        var config = LegacyLiquidGlass.Configuration()
        config.style = style
        config.cornerRadius = cornerRadius
        return content.modifier(LLGlassModifier(configuration: config))
    }
}

public extension View {
    func llGlassBackground(style: LegacyLiquidGlass.Style = .regular,
                           cornerRadius: CGFloat = 24) -> some View {
        modifier(LLGlassBackgroundStyle(style: style, cornerRadius: cornerRadius))
    }
}

public enum LLGlassLocalization {
    public enum Language: String, CaseIterable {
        case system, english = "en", simplifiedChinese = "zh-Hans"
        case traditionalChinese = "zh-Hant", japanese = "ja"
    }

    public static var language: Language = .system

    private static let table: [String: [Language: String]] = [
        "search": [.english: "Search", .simplifiedChinese: "搜索", .traditionalChinese: "搜尋", .japanese: "検索"],
        "cancel": [.english: "Cancel", .simplifiedChinese: "取消", .traditionalChinese: "取消", .japanese: "キャンセル"],
        "done": [.english: "Done", .simplifiedChinese: "完成", .traditionalChinese: "完成", .japanese: "完了"],
        "close": [.english: "Close", .simplifiedChinese: "关闭", .traditionalChinese: "關閉", .japanese: "閉じる"],
        "settings": [.english: "Settings", .simplifiedChinese: "设置", .traditionalChinese: "設定", .japanese: "設定"],
        "open": [.english: "Open", .simplifiedChinese: "打开", .traditionalChinese: "開啟", .japanese: "開く"],
        "save": [.english: "Save", .simplifiedChinese: "保存", .traditionalChinese: "儲存", .japanese: "保存"],
        "delete": [.english: "Delete", .simplifiedChinese: "删除", .traditionalChinese: "刪除", .japanese: "削除"],
        "confirm": [.english: "Confirm", .simplifiedChinese: "确认", .traditionalChinese: "確認", .japanese: "確認"],
        "share": [.english: "Share", .simplifiedChinese: "共享", .traditionalChinese: "分享", .japanese: "共有"],
        "more": [.english: "More", .simplifiedChinese: "更多", .traditionalChinese: "更多", .japanese: "その他"],
        "loading": [.english: "Loading…", .simplifiedChinese: "正在加载…", .traditionalChinese: "正在載入…", .japanese: "読み込み中…"],
        "error": [.english: "Error", .simplifiedChinese: "错误", .traditionalChinese: "錯誤", .japanese: "エラー"]
    ]

    public static func string(_ key: String, language: Language? = nil) -> String {
        let requested = language ?? self.language
        let selected: Language
        switch requested {
        case .system:
            let code = Locale.preferredLanguages.first ?? "en"
            if code.hasPrefix("zh-Hans") || code.hasPrefix("zh-CN") { selected = .simplifiedChinese }
            else if code.hasPrefix("zh-Hant") || code.hasPrefix("zh-TW") || code.hasPrefix("zh-HK") { selected = .traditionalChinese }
            else if code.hasPrefix("ja") { selected = .japanese }
            else { selected = .english }
        default:
            selected = requested
        }
        return table[key]?[selected] ?? table[key]?[.english] ?? key
    }

    public static func setLanguage(_ language: Language) {
        self.language = language
        NotificationCenter.default.post(name: .LLGlassThemeDidChange, object: nil)
    }
}

public struct LLGlassDiagnosticsReport: Sendable {
    public let version: String
    public let backend: String
    public let quality: String
    public let fps: Double
    public let gpuTime: Double
    public let captureTime: Double
    public let thermalState: String
    public let glassCount: Int
    public let reduceTransparency: Bool
    public let reduceMotion: Bool
    public let metalAvailable: Bool
    public let metalPipelineAvailable: Bool
    public let versionMajor: Int

    public var dictionary: [String: Any] {
        ["version": version, "backend": backend, "quality": quality, "fps": fps,
         "gpuTime": gpuTime, "captureTime": captureTime, "thermalState": thermalState, "glassCount": glassCount,
         "reduceTransparency": reduceTransparency, "reduceMotion": reduceMotion, "metalAvailable": metalAvailable,
         "metalPipelineAvailable": metalPipelineAvailable, "versionMajor": versionMajor]
    }
}

public enum LLGlassDiagnostics {
    public static func report() -> LLGlassDiagnosticsReport {
        let governor = LLGlassPerformanceGovernor.shared
        let environment = LLGlassEnvironment.shared
        return LLGlassDiagnosticsReport(
            version: LegacyLiquidGlass.version,
            backend: String(describing: LegacyLiquidGlass.effectiveBackend),
            quality: String(describing: governor.currentQuality),
            fps: governor.measuredFPS,
            gpuTime: governor.measuredGPUTime,
            captureTime: governor.measuredCaptureTime,
            thermalState: String(describing: governor.thermalState),
            glassCount: governor.activeGlassCount,
            reduceTransparency: environment.reduceTransparency,
            reduceMotion: environment.reduceMotion,
            metalAvailable: LLMetalShared.isUsable,
            metalPipelineAvailable: LLMetalShared.pipelines != nil,
            versionMajor: 8
        )
    }
}

public extension UIView {
    @discardableResult
    func llApplyGlass(_ configuration: LegacyLiquidGlass.Configuration = .init()) -> LLGlassView {
        let glass = LLGlassView(configuration: configuration)
        insertSubview(glass, at: 0)
        glass.frame = bounds
        glass.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        return glass
    }
}

public enum LLGlassBootstrap {
    private static var started = false
    public static func start() {
        guard !started else { return }
        started = true
        _ = LLGlassEnvironment.shared
        LLGlassPerformanceGovernor.shared.start()
    }
    public static func stop() {
        guard started else { return }
        started = false
        LLGlassPerformanceGovernor.shared.stop()
    }
}

public enum LLGlassColorBridge {
    public static func color(_ color: Color) -> UIColor {
        if #available(iOS 14.0, *) { return UIColor(color) }
        return .white
    }
}

public enum LLGlassPresets {
    public static var liquidGlass: LegacyLiquidGlass.Configuration {
        var c = LegacyLiquidGlass.Configuration()
        c.style = .regular
        c.cornerRadius = 24
        c.blurRadius = 18
        c.refractionStrength = 0.020
        c.lensThickness = 0.42
        c.materialRoughness = 0.14
        c.indexOfRefraction = 1.48
        c.absorptionStrength = 0.14
        c.reflectionMix = 0.22
        c.normalStrength = 0.42
        c.bevelWidth = 0.24
        c.curvatureStrength = 0.34
        c.environmentOffset = 0.055
        c.dynamicLightStrength = 0.82
        c.edgeDispersion = 0.65
        c.useDeepBlur = true
        return c
    }

    public static var regular: LegacyLiquidGlass.Configuration {
        var c = LegacyLiquidGlass.Configuration(); c.style = .regular; c.cornerRadius = 24; return c
    }
    public static var clear: LegacyLiquidGlass.Configuration {
        var c = LegacyLiquidGlass.Configuration()
        c.style = .clear; c.cornerRadius = 20; c.blurRadius = 10; c.refractionStrength = 0.010
        c.lensThickness = 0.30; c.dispersionStrength = 0.08; c.fresnelPower = 3.0
        c.bevelWidth = 0.18; c.curvatureStrength = 0.28; c.materialRoughness = 0.08
        c.environmentOffset = 0.040; c.dynamicLightStrength = 0.70; c.useDeepBlur = true
        return c
    }
    public static var prominent: LegacyLiquidGlass.Configuration {
        var c = LegacyLiquidGlass.Configuration()
        c.style = .prominent; c.cornerRadius = 24; c.blurRadius = 24
        c.specularStrength = 0.34; c.edgeLightStrength = 0.40; c.refractionStrength = 0.020
        c.lensThickness = 0.55; c.dispersionStrength = 0.22; c.fresnelPower = 2.2
        c.bevelWidth = 0.30; c.curvatureStrength = 0.42; c.materialRoughness = 0.15
        c.environmentOffset = 0.070; c.dynamicLightStrength = 0.92; c.useDeepBlur = true
        return c
    }
    public static func tinted(_ color: UIColor, cornerRadius: CGFloat = 22) -> LegacyLiquidGlass.Configuration {
        var c = regular; c.style = .tinted(color); c.cornerRadius = cornerRadius; return c
    }
}

public final class LLGlassDebugOverlay: UIView {
    private let label = UILabel()
    private var timer: CADisplayLink?
    private var lastUpdateTime: CFTimeInterval = 0

    public override init(frame: CGRect) { super.init(frame: frame); setup() }
    public required init?(coder: NSCoder) { super.init(coder: coder); setup() }
    deinit { timer?.invalidate() }

    private func setup() {
        backgroundColor = UIColor.black.withAlphaComponent(0.48)
        layer.cornerRadius = 12
        layer.cornerCurve = .continuous
        label.font = .monospacedSystemFont(ofSize: 11, weight: .medium)
        label.textColor = .white
        label.numberOfLines = 0
        label.translatesAutoresizingMaskIntoConstraints = false
        addSubview(label)
        NSLayoutConstraint.activate([
            label.leadingAnchor.constraint(equalTo: leadingAnchor, constant: 10),
            label.trailingAnchor.constraint(equalTo: trailingAnchor, constant: -10),
            label.topAnchor.constraint(equalTo: topAnchor, constant: 8),
            label.bottomAnchor.constraint(equalTo: bottomAnchor, constant: -8)
        ])
        let link = CADisplayLink(target: self, selector: #selector(update(_:)))
        link.add(to: .main, forMode: .common)
        timer = link
    }

    @objc private func update(_ link: CADisplayLink) {
        let now = CACurrentMediaTime()
        guard now - lastUpdateTime >= 0.25 else { return }
        lastUpdateTime = now

        let r = LLGlassDiagnostics.report()
        label.text = [
            "LegacyLiquidGlass \(r.version)",
            "backend: \(r.backend)",
            "quality: \(r.quality)",
            String(format: "fps: %.1f", r.fps),
            String(format: "gpu: %.1fms", r.gpuTime * 1000),
            "thermal: \(r.thermalState)",
            "capture: \(String(format: "%.1fms", r.captureTime * 1000))",
            "glass: \(r.glassCount)"
        ].joined(separator: "\n")
    }
}

public enum LLGlassAnimations {
    public static func materialize(_ view: UIView, animated: Bool = true) {
        guard animated, !LLGlassEnvironment.shared.reduceMotion else {
            view.alpha = 1; view.transform = .identity; return
        }
        view.alpha = 0
        view.transform = CGAffineTransform(scaleX: 0.96, y: 0.96)
        UIView.animate(withDuration: 0.42, delay: 0, usingSpringWithDamping: 0.78,
                       initialSpringVelocity: 0.15,
                       options: [.beginFromCurrentState, .allowUserInteraction]) {
            view.alpha = 1; view.transform = .identity
        }
    }

    public static func dematerialize(_ view: UIView, animated: Bool = true,
                                     completion: (() -> Void)? = nil) {
        guard animated, !LLGlassEnvironment.shared.reduceMotion else {
            view.alpha = 0; completion?(); return
        }
        UIView.animate(withDuration: 0.24, animations: {
            view.alpha = 0
            view.transform = CGAffineTransform(scaleX: 0.98, y: 0.98)
        }) { _ in completion?() }
    }

    public static func merge(_ views: [UIView], into target: CGRect, duration: TimeInterval = 0.42) {
        guard !LLGlassEnvironment.shared.reduceMotion else {
            views.forEach { $0.frame = target }; return
        }
        UIView.animate(withDuration: duration, delay: 0, usingSpringWithDamping: 0.78,
                       initialSpringVelocity: 0.2,
                       options: [.beginFromCurrentState, .allowUserInteraction]) {
            views.forEach { $0.frame = target }
        }
    }
}

public enum LLGlassAccessibility {
    public static func apply(to view: UIView) {
        let environment = LLGlassEnvironment.shared
        if environment.reduceTransparency {
            view.layer.opacity = 0.96
        }
        if environment.increaseContrast {
            view.layer.borderWidth = 1
            view.layer.borderColor = UIColor.label.cgColor
        }
    }
}

public final class LLGlassVirtualizedListCoordinator: NSObject {
    public weak var scrollView: UIScrollView?
    public var pauseCaptureDuringScroll = false
    public var lowPowerQuality: LegacyLiquidGlass.Quality = .medium

    private var glassViews: NSHashTable<LLGlassView> = .weakObjects()
    private var previousQuality: [ObjectIdentifier: LegacyLiquidGlass.Quality] = [:]
    private var previousLiveCapture: [ObjectIdentifier: Bool] = [:]

    public init(scrollView: UIScrollView) {
        self.scrollView = scrollView
        super.init()
        NotificationCenter.default.addObserver(self,
                                               selector: #selector(didScroll(_:)),
                                               name: llScrollViewDidScrollNotification,
                                               object: scrollView)
        NotificationCenter.default.addObserver(self,
                                               selector: #selector(didEndScrolling(_:)),
                                               name: llScrollViewDidEndScrollingAnimationNotification,
                                               object: scrollView)
    }

    deinit { NotificationCenter.default.removeObserver(self) }

    public func register(_ glass: LLGlassView) {
        glassViews.add(glass)
        previousQuality[ObjectIdentifier(glass)] = glass.configuration.quality
        previousLiveCapture[ObjectIdentifier(glass)] = glass.configuration.liveCapture
    }

    public func unregister(_ glass: LLGlassView) {
        glassViews.remove(glass)
        previousQuality.removeValue(forKey: ObjectIdentifier(glass))
        previousLiveCapture.removeValue(forKey: ObjectIdentifier(glass))
    }

    @MainActor
    @objc private func didScroll(_ note: Notification) {
        LLGlassPerformanceGovernor.shared.setScrollActive(true)
        for glass in glassViews.allObjects where glass.window === scrollView?.window {
            glass.setScrollActive(true)
            if pauseCaptureDuringScroll {
                glass.configuration.liveCapture = false
            } else if glass.configuration.adaptiveQuality {
                glass.invalidateBackdrop()
            }
        }
    }

    @MainActor
    @objc private func didEndScrolling(_ note: Notification) {
        LLGlassPerformanceGovernor.shared.setScrollActive(false)
        for glass in glassViews.allObjects where glass.window === scrollView?.window {
            glass.setScrollActive(false)
            if pauseCaptureDuringScroll {
                if let original = previousLiveCapture[ObjectIdentifier(glass)] {
                    glass.configuration.liveCapture = original
                }
            }
            glass.invalidateBackdrop()
        }
    }
}

public final class LLGlassScrollCoordinator: NSObject, UIScrollViewDelegate {
    public weak var scrollView: UIScrollView?
    private weak var originalDelegate: UIScrollViewDelegate?
    private var registeredViews: NSHashTable<LLGlassView> = .weakObjects()

    public init(scrollView: UIScrollView) {
        self.scrollView = scrollView
        self.originalDelegate = scrollView.delegate
        super.init()
        scrollView.delegate = self
    }

    deinit {
        if scrollView?.delegate === self {
            scrollView?.delegate = originalDelegate
        }
    }

    public func register(_ glass: LLGlassView) { registeredViews.add(glass) }
    public func unregister(_ glass: LLGlassView) { registeredViews.remove(glass) }

    public func scrollViewDidScroll(_ scrollView: UIScrollView) {
        for glass in registeredViews.allObjects {
            glass.setScrollActive(true)
            glass.setNeedsLayout()
        }
        originalDelegate?.scrollViewDidScroll?(scrollView)
    }

    public func scrollViewDidEndDragging(_ scrollView: UIScrollView, willDecelerate decelerate: Bool) {
        if !decelerate {
            for glass in registeredViews.allObjects {
                glass.setScrollActive(false)
            }
        }
        originalDelegate?.scrollViewDidEndDragging?(scrollView, willDecelerate: decelerate)
    }

    public func scrollViewDidEndDecelerating(_ scrollView: UIScrollView) {
        for glass in registeredViews.allObjects {
            glass.setScrollActive(false)
        }
        originalDelegate?.scrollViewDidEndDecelerating?(scrollView)
    }

    public override func responds(to aSelector: Selector!) -> Bool {
        if super.responds(to: aSelector) { return true }
        return originalDelegate?.responds(to: aSelector) ?? false
    }

    public override func forwardingTarget(for aSelector: Selector!) -> Any? {
        if originalDelegate?.responds(to: aSelector) == true {
            return originalDelegate
        }
        return super.forwardingTarget(for: aSelector)
    }
}

private extension CGFloat {
    func clamped(to range: ClosedRange<CGFloat>) -> CGFloat {
        Swift.min(Swift.max(self, range.lowerBound), range.upperBound)
    }
}

private final class LLClosureControlTarget: NSObject {
    private let action: () -> Void
    init(action: @escaping () -> Void) {
        self.action = action
        super.init()
    }
    @objc func invoke() { action() }
}

private var llActionTargetKey: UInt8 = 0

private extension UIButton {
    func llStoreActionTarget(_ target: LLClosureControlTarget) {
        objc_setAssociatedObject(self, &llActionTargetKey, target, .OBJC_ASSOCIATION_RETAIN_NONATOMIC)
        addTarget(target, action: #selector(LLClosureControlTarget.invoke), for: .touchUpInside)
    }
}

public extension LegacyLiquidGlass {
    static func makeGlass(configuration: Configuration = Configuration()) -> LLGlassView {
        LLGlassView(configuration: configuration)
    }

    static func makeButton(title: String, configuration: Configuration = Configuration(),
                           action: @escaping () -> Void) -> UIButton {
        let button = LLGlassButton(type: .system)
        button.setTitle(title, for: .normal)
        button.glassConfiguration = configuration
        button.llStoreActionTarget(LLClosureControlTarget(action: action))
        return button
    }
}