# Hoshino 1.5

Hoshino is an iOS file manager implemented with SwiftUI, Swift, Objective-C++ and C++17. The UI and platform authorization stay in Swift; file operations and archive processing use C++ behind a C ABI; `.mm` files provide the required Objective-C++ adapters.

- Chinese project guide: [README_中文.md](README_中文.md)
- Function-by-function capability matrix: [FUNCTION_MATRIX.md](FUNCTION_MATRIX.md)
- Implementation and verification boundary: [IMPLEMENTATION_STATUS_2026-11-20.md](IMPLEMENTATION_STATUS_2026-11-20.md)

## Build on macOS

Requires Xcode, the iOS SDK, Swift Package Manager access and (for TrollStore IPA packaging) `ldid`.

```sh
make resolve
make smoke
make build
make ipa
```

Optional embedded CPython 3.13:

```sh
make python-runtime
make build
make ipa
```

`make smoke` runs host-side Plist, C++ filesystem/archive, script bridge, Swift parsing, Xcode project integrity and RootHelper protocol tests. It does not replace an iOS SDK build or TrollStore device validation. External script runtimes such as Node.js, Lua, Ruby, Perl, PHP, R and Tcl are enabled only when present on the target device.
