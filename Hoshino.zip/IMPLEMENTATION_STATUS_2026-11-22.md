# Hoshino 1.5 修改记录（2026-11-22）

## 本轮完成

### 1. 应用生命周期 RootHelper

- 新增应用私有 socketpair 常驻 RPC 通道；`HoshinoApp.init()` 启动时异步调用 `RootHelperService.startIfNeeded()`。
- `RootHelper` 通过 `posix_spawn` 启动，使用 TrollStore 约定的 persona ID 99、UID/GID 0；启动阶段通过握手确认子进程实际满足 `geteuid()==0`。设置页可主动检测并显示 Helper PID 或启动错误。
- 一个 helper 进程复用所有类型化 RPC：复制、移动、重命名、创建、删除、符号链接、chmod、xattr 和 immutable；所有请求串行化，参数长度、总大小、参数数量和响应长度都有上限。
- 仅当普通文件操作收到 `EPERM/EACCES` 时调用 RootHelper。通信断开时尝试重新启动，启动失败则保留原有单次 RPC fallback。
- 不写入 launchd plist、不注册 launchd job、不安装后台服务。应用进程退出时 socketpair 关闭，Helper 在当前请求结束后读取 EOF 并退出。
- 设置项默认开启，可关闭；关闭时关闭 IPC 并回收 Helper。

### 2. 文件操作和性能

- APFS 环境下普通文件复制优先尝试 `copyfile(COPYFILE_DATA | COPYFILE_CLONE)`，在跨卷或文件系统不支持时回退 `std::filesystem::copy_file`；RootHelper 复制时尽量保留 UID/GID 和安全的用户 flags（不复制会阻塞 rename 的 immutable/append flags）。
- 复制后继续保留现有扩展属性、权限和修改时间处理；目录和符号链接路径未改变。
- 文件列表时间戳直接读取 `lstat` 的 `st_mtimespec/st_birthtimespec`，去掉每个列表项目额外的 `URL.resourceValues` 请求。
- 排序增加稳定的名称次级排序，避免同时间/同大小项目顺序不稳定。
- 同目录剪切粘贴改为 no-op，避免出现意外的“副本 2”。新建名称拒绝 NUL 字符。
- 新增文件夹递归合并：同名目录合并子项，文件/类型冲突保留两份；任何项目失败时保留源文件夹并列出失败项。全部复制成功后先将源目录原子改名为临时 tombstone 再清理，避免直接递归删除唯一源数据。
- 可访问根目录时默认从 `/` 开始；普通受沙盒安装无法列出根目录时回退 Documents。
- 新增高级递归搜索：支持 name/path/ext/type/size/date/regex/content 查询。文本内容只读取 UTF-8 常见文本文件，且单文件限制 2 MiB；不跟随符号链接。
- 新增重复文件扫描：最多检查 30,000 个目录项，按文件大小和首尾数据块预筛，再对候选文件计算完整 SHA-256；跳过符号链接和硬链接别名。重复文件只能移入废纸篓，不提供自动永久清理。
- 新增目录用量分析：最多检查 500,000 个目录项，汇总文件/目录/符号链接数、扩展名占用和最大文件，按设备号与 inode 避免重复计算硬链接的实际数据；达到上限或存在不可读项目时标注统计不完整。
- 批量复制/移动/删除逐项继续执行；部分失败不会阻塞其余项目，结果显示失败路径。队列可在当前项目完成后停止；剪切粘贴只从剪贴板移除已成功移动的项目。

### 3. 文件类型图标

- 目前共 163 个唯一图标资源，153 个具体图标类别，映射 367 种扩展名。
- 图标分为 RAW/相机、矢量/3D/CAD、视频与音频编码、Office/电子书/邮件、配置和标记语言、独立编程语言、压缩算法、系统二进制、数据库、证书、安装包及系统组件。
- 所有文件项直接使用 Assets 图像资源；不调用 SF Symbols 或 UIKit 系统文件图标。未知格式由 Hoshino 自己的 `FileIcon_generic` 图像显示。
- `FileTypeIconAssets` 集中维护扩展名与文件名映射；右上角角标仍显示实际扩展名。

### 4. Entitlements

- 生产 `TrollStore.entitlements` 沿用 TrollStore 文档确认的最小工作组合，不叠加未经验证的私有键。
- 新增单独的实验 Entitlements 文件，分别测试 `system-application` 和 `com.apple.private.security.system-application`，不影响正常 Hoshino IPA。
- `Makefile` 支持通过 `ENTITLEMENTS` 和 `IPA_NAME` 变量生成测试变体。

## 测试

本轮在当前 Linux 主机执行 `make smoke`，全部通过：

- Plist XML/Binary 往返；
- NativeCore 文件操作；
- ArchiveCore 多格式创建/列举/解压及路径安全测试；
- Swift 全部源文件语法解析；
- Xcode 工程文件、桥接、依赖和资源完整性检查；
- RootHelper PTY；
- RootHelper 类型化 RPC；
- RootHelper 常驻 server 连续 mkdir/delete 请求、socket EOF 退出；RootProcessBridge 的 spawn/握手/复用 RPC/关闭回收集成测试。

当前环境没有 macOS、Xcode、iOS SDK 或 TrollStore 真机，因此尚未验证 Apple iOS SDK 对 Objective-C++ bridge 的最终编译链接、APFS clone 路径、设备 persona API、实际 root EUID、私有 Entitlements 解释结果和系统目录读写。Linux 回归通过不代表这些真机能力已确认。

## 权限结论

TrollStore 可在符合其运行条件的设备上通过 `com.apple.private.persona-mgmt`、`TSRootBinaries` 和 `posix_spawn` root persona 运行包内辅助程序；这不是平台化，也不是 launchd daemon。生产包仍采用应用私有常驻子进程方案。`system-application` 状态不应与签名 Entitlements 混淆，实验配置仅用于设备验证。
