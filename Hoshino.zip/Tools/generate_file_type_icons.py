from pathlib import Path
import json, hashlib
import cairosvg

ROOT = Path(__file__).resolve().parents[1] / 'Hoshino/Resources/Assets.xcassets'
# name: (short label, motif, accent)
ICONS = {
    'jxl': ('JXL','image','#2368E8'), 'avif': ('AVIF','image','#7C4DFF'), 'ico': ('ICO','image','#168BCE'),
    'jp2': ('JP2','image','#2196A6'), 'exr': ('EXR','image','#E87532'), 'nef': ('NEF','camera','#2279C8'),
    'cr3': ('CR3','camera','#D94A53'), 'raf': ('RAF','camera','#6A53CC'), 'rw2': ('RW2','camera','#209B81'),
    'blend': ('BLEND','cube','#F27A24'), 'dwg': ('DWG','ruler','#E04D4D'), 'usd': ('USDZ','cube','#3153B9'),
    'skp': ('SKP','cube','#159B82'), 'epub': ('EPUB','book','#2576D2'), 'mobi': ('MOBI','book','#7B58CF'),
    'azw3': ('AZW3','book','#B66A32'), 'cbz': ('CBZ','book','#E24B73'), 'cbr': ('CBR','book','#C04F3B'),
    'eml': ('EML','mail','#2F8DCC'), 'mbox': ('MBOX','mail','#755AC6'), 'ics': ('ICS','calendar','#2C9A75'),
    'vcf': ('VCF','contact','#287FCB'), 'tex': ('TEX','document','#208D96'), 'adoc': ('ADOC','document','#438DCE'),
    'org': ('ORG','document','#D18B26'), 'flac': ('FLAC','wave','#6B5ECF'), 'ogg': ('OGG','wave','#2685C5'),
    'opus': ('OPUS','wave','#169B91'), 'midi': ('MIDI','piano','#B65CCD'), 'aiff': ('AIFF','wave','#C66B32'),
    'alac': ('ALAC','wave','#2A9A67'), 'dsf': ('DSF','wave','#3970D5'), 'typescript': ('TS','code','#2D78C7'),
    'rust': ('RS','gear','#D97731'), 'golang': ('GO','code','#37A7BA'), 'kotlin': ('KT','code','#8253C7'),
    'csharp': ('C#','code','#6B59B8'), 'php': ('PHP','code','#6477BD'), 'ruby': ('RB','gem','#CC4D69'),
    'lua': ('LUA','code','#316FC4'), 'dart': ('DART','code','#168FBA'), 'sql': ('SQL','database','#347BBF'),
    'graphql': ('GQL','network','#D16C43'), 'wasm': ('WASM','chip','#654CC4'), 'asm': ('ASM','chip','#596A80'),
    'dockerfile': ('DOCKER','container','#218CC8'), 'xip': ('XIP','archive','#5967CA'), 'xz': ('XZ','archive','#32907B'),
    'zst': ('ZST','archive','#9A7135'), 'lz4': ('LZ4','archive','#3E85BB'), 'cpio': ('CPIO','archive','#B57B34'),
    'cab': ('CAB','archive','#CC6B33'), 'deb': ('DEB','package','#B87435'), 'rpm': ('RPM','package','#B84E55'),
    'p12': ('P12','shield','#247FC2'), 'pem': ('PEM','shield','#2A9A84'), 'mobileprovision': ('PROV','shield','#525FC7'),
    'p7b': ('P7B','shield','#2F8D8A'), 'csr': ('CSR','shield','#B17B35'), 'sqlite': ('SQLITE','database','#3A83B7'),
    'realm': ('REALM','database','#7A5ABF'),
}

def motif_svg(motif, color):
    # All glyphs are authored vector paths; no platform/SF Symbols dependency.
    stroke = f' stroke="{color}" stroke-width="9" stroke-linecap="round" stroke-linejoin="round" fill="none"'
    if motif == 'image':
        return f'<rect x="73" y="76" width="110" height="82" rx="13" fill="{color}" opacity=".14"/><path d="M81 148 L112 111 L133 131 L151 109 L176 148 Z" fill="{color}"/><circle cx="157" cy="94" r="10" fill="#FFB547"/>'
    if motif == 'camera':
        return f'<path d="M78 102 L96 83 H160 L178 102 V156 Q178 166 168 166 H88 Q78 166 78 156 Z" fill="{color}" opacity=".18" stroke="{color}" stroke-width="7"/><circle cx="128" cy="125" r="26" fill="white" stroke="{color}" stroke-width="9"/><circle cx="128" cy="125" r="12" fill="{color}"/>'
    if motif == 'cube':
        return f'<path d="M128 72 L184 101 L128 132 L72 101 Z" fill="{color}" opacity=".95"/><path d="M72 101 V155 L128 186 V132 Z" fill="{color}" opacity=".64"/><path d="M184 101 V155 L128 186 V132 Z" fill="{color}" opacity=".82"/><path d="M128 72 V132" stroke="white" stroke-width="5" opacity=".8"/>'
    if motif == 'ruler':
        return f'<path d="M78 151 L151 78 L181 108 L108 181 Z" fill="{color}" opacity=".22" stroke="{color}" stroke-width="8"/><path d="M105 124 L116 135 M121 108 L137 124 M137 92 L148 103"{stroke}/>'
    if motif == 'book':
        return f'<path d="M76 83 Q104 72 128 91 Q152 72 180 83 V165 Q152 155 128 174 Q104 155 76 165 Z" fill="{color}" opacity=".16" stroke="{color}" stroke-width="7"/><path d="M128 91 V174 M90 106 Q105 102 113 108 M143 108 Q159 101 169 106 M90 130 Q106 125 114 132 M143 132 Q158 125 169 130"{stroke}/>'
    if motif == 'mail':
        return f'<rect x="75" y="88" width="106" height="78" rx="12" fill="{color}" opacity=".16" stroke="{color}" stroke-width="8"/><path d="M80 98 L128 135 L176 98"{stroke}/>'
    if motif == 'calendar':
        return f'<rect x="77" y="85" width="102" height="88" rx="12" fill="{color}" opacity=".16" stroke="{color}" stroke-width="8"/><path d="M77 111 H179 M103 76 V97 M153 76 V97"{stroke}/><path d="M102 131 H113 M127 131 H138 M152 131 H163 M102 151 H113 M127 151 H138" stroke="{color}" stroke-width="9" stroke-linecap="round"/>'
    if motif == 'contact':
        return f'<circle cx="128" cy="101" r="23" fill="{color}" opacity=".8"/><path d="M79 174 Q82 134 128 134 Q174 134 177 174 Z" fill="{color}" opacity=".35" stroke="{color}" stroke-width="8"/>'
    if motif == 'document':
        return f'<path d="M86 82 H150 L173 105 V171 H86 Z" fill="{color}" opacity=".12" stroke="{color}" stroke-width="8"/><path d="M150 82 V106 H173 M103 125 H155 M103 145 H155 M103 163 H144"{stroke}/>'
    if motif == 'wave':
        bars = [(82,126,12),(100,106,30),(118,89,47),(136,108,28),(154,96,40),(172,120,16)]
        return ''.join(f'<rect x="{x}" y="{128-h/2}" width="10" height="{h}" rx="5" fill="{color}"/>' for x,_,h in bars) + f'<path d="M80 176 Q128 190 176 176"{stroke} opacity=".35"/>'
    if motif == 'piano':
        return f'<rect x="75" y="94" width="106" height="70" rx="8" fill="white" stroke="{color}" stroke-width="8"/><path d="M101 96 V163 M128 96 V163 M155 96 V163" stroke="{color}" stroke-width="6"/><path d="M94 95 H110 V131 H94 Z M121 95 H137 V131 H121 Z M148 95 H164 V131 H148 Z" fill="{color}"/>'
    if motif == 'code':
        return f'<path d="M111 91 L83 127 L111 163 M145 91 L173 127 L145 163 M137 80 L119 174"{stroke}/>'
    if motif == 'gear':
        return f'<circle cx="128" cy="127" r="42" fill="{color}" opacity=".15" stroke="{color}" stroke-width="9"/><circle cx="128" cy="127" r="15" fill="white" stroke="{color}" stroke-width="8"/><path d="M128 70 V85 M128 169 V184 M71 127 H86 M170 127 H185 M88 87 L99 98 M157 156 L168 167 M168 87 L157 98 M99 156 L88 167"{stroke}/>'
    if motif == 'gem':
        return f'<path d="M86 105 L105 82 H151 L170 105 L128 171 Z" fill="{color}" opacity=".28" stroke="{color}" stroke-width="8"/><path d="M86 105 H170 M105 82 L128 171 L151 82"{stroke}/>'
    if motif == 'database':
        return f'<ellipse cx="128" cy="93" rx="49" ry="18" fill="{color}" opacity=".75"/><path d="M79 93 V156 Q128 187 177 156 V93" fill="{color}" opacity=".18" stroke="{color}" stroke-width="8"/><path d="M79 124 Q128 153 177 124 M79 151 Q128 180 177 151"{stroke}/>'
    if motif == 'network':
        return f'<path d="M128 85 L85 112 L100 162 L156 162 L171 112 Z M128 85 L128 142 M85 112 L128 142 L171 112 M100 162 L128 142 L156 162" stroke="{color}" stroke-width="8" stroke-linejoin="round" fill="none"/><g fill="{color}"><circle cx="128" cy="85" r="10"/><circle cx="85" cy="112" r="10"/><circle cx="171" cy="112" r="10"/><circle cx="100" cy="162" r="10"/><circle cx="156" cy="162" r="10"/><circle cx="128" cy="142" r="10"/></g>'
    if motif == 'chip':
        return f'<rect x="91" y="91" width="74" height="74" rx="12" fill="{color}" opacity=".18" stroke="{color}" stroke-width="8"/><path d="M109 109 H147 V147 H109 Z M109 72 V91 M128 72 V91 M147 72 V91 M109 165 V184 M128 165 V184 M147 165 V184 M72 109 H91 M72 128 H91 M72 147 H91 M165 109 H184 M165 128 H184 M165 147 H184"{stroke}/>'
    if motif == 'container':
        return f'<path d="M80 107 L128 82 L176 107 L128 133 Z" fill="{color}" opacity=".3" stroke="{color}" stroke-width="7"/><path d="M80 107 V156 L128 181 V133 Z M176 107 V156 L128 181 V133 Z" fill="{color}" opacity=".18" stroke="{color}" stroke-width="7"/><path d="M108 123 L128 134 L148 123"{stroke}/>'
    if motif == 'archive':
        return f'<rect x="76" y="99" width="104" height="70" rx="10" fill="{color}" opacity=".2" stroke="{color}" stroke-width="8"/><path d="M76 117 H180 M118 98 V160 M138 112 V127 M138 138 V153"{stroke}/><path d="M110 86 H146" stroke="{color}" stroke-width="9" stroke-linecap="round"/>'
    if motif == 'package':
        return f'<path d="M78 105 L128 80 L178 105 V159 L128 184 L78 159 Z" fill="{color}" opacity=".2" stroke="{color}" stroke-width="8"/><path d="M78 105 L128 131 L178 105 M128 131 V184"{stroke}/>'
    if motif == 'shield':
        return f'<path d="M128 75 L177 94 V126 Q174 161 128 184 Q82 161 79 126 V94 Z" fill="{color}" opacity=".18" stroke="{color}" stroke-width="8"/><path d="M104 129 L121 146 L154 109"{stroke}/>'
    return f'<text x="128" y="140" text-anchor="middle" font-family="Arial" font-size="52" font-weight="bold" fill="{color}">?</text>'

def render(name, label, motif, color):
    svg = f'''<svg xmlns="http://www.w3.org/2000/svg" width="256" height="256" viewBox="0 0 256 256">
      <defs>
        <linearGradient id="paper" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#FFFFFF"/><stop offset="1" stop-color="#EEF2FC"/></linearGradient>
        <linearGradient id="pill" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="{color}"/><stop offset="1" stop-color="{color}" stop-opacity=".84"/></linearGradient>
        <filter id="shadow" x="-20%" y="-20%" width="140%" height="150%"><feDropShadow dx="0" dy="7" stdDeviation="7" flood-color="#53658E" flood-opacity=".22"/></filter>
      </defs>
      <g filter="url(#shadow)"><path d="M48 15 H160 L218 73 V226 Q218 241 202 241 H48 Q32 241 32 225 V31 Q32 15 48 15Z" fill="url(#paper)" stroke="#B8C4DD" stroke-width="4"/><path d="M160 15 V59 Q160 73 174 73 H218" fill="#DCE5F7" stroke="#B8C4DD" stroke-width="4" stroke-linejoin="round"/></g>
      <circle cx="128" cy="128" r="66" fill="{color}" opacity=".055"/>
      {motif_svg(motif,color)}
      <rect x="88" y="190" width="124" height="38" rx="17" fill="url(#pill)" stroke="#FFFFFF" stroke-width="3"/>
      <text x="150" y="215" text-anchor="middle" font-family="DejaVu Sans,Arial,sans-serif" font-size="{23 if len(label)<=4 else 18}" font-weight="800" fill="#FFFFFF" letter-spacing=".4">{label}</text>
    </svg>'''
    return cairosvg.svg2png(bytestring=svg.encode(), output_width=256, output_height=256)

for name, (label, motif, color) in ICONS.items():
    folder = ROOT / f'FileIcon_{name}.imageset'
    folder.mkdir(parents=True, exist_ok=True)
    data = render(name, label, motif, color)
    (folder / 'icon.png').write_bytes(data)
    (folder / 'Contents.json').write_text(json.dumps({
        'images': [{'filename':'icon.png','idiom':'universal'}],
        'info': {'author':'xcode','version':1}
    }, indent=2) + '\n')

print(f'Created {len(ICONS)} unique native vector icons.')
