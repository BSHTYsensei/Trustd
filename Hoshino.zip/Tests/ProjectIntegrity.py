#!/usr/bin/env python3
from pathlib import Path
import re
import plistlib
import hashlib

root = Path(__file__).resolve().parents[1]
pbx_path = root / 'Hoshino.xcodeproj/project.pbxproj'
pbx = pbx_path.read_text()
bridging = (root / 'Hoshino/Hoshino-Bridging-Header.h').read_text()

required = [
    'NativeCore.cpp', 'NativeCoreBridge.mm', 'NativeCore.swift',
    'ArchiveCore.cpp', 'ArchiveService.swift', 'ScriptRuntimeBridge.mm',
    'RootProcessBridge.mm', 'FileMetadataService.swift', 'FileTypeBadge.swift',
    'RecycleBinService.swift', 'MountCatalog.swift', 'ScriptLibrary.swift',
    'ArchivePreferences.swift', 'AdvancedSettingsViews.swift'
]
for name in required:
    if pbx.count(name) < 2:
        raise SystemExit(f'missing Xcode project registration: {name}')

for header in ['Core/NativeCoreBridge.h', 'Core/ArchiveCoreBridge.h', 'Core/ScriptRuntimeBridge.h', 'Core/RootProcessBridge.h']:
    if header not in bridging:
        raise SystemExit(f'missing Swift bridging header import: {header}')

if 'libarchive-for-swift.git' not in pbx or 'productName = libarchive' not in pbx:
    raise SystemExit('libarchive SPM dependency/product is not registered')
if 'ZipArchive.git' not in pbx or 'productName = ZipArchive' not in pbx:
    raise SystemExit('SSZipArchive SPM dependency/product is not registered')
if 'ZipArchive in Frameworks' not in pbx or 'libarchive in Frameworks' not in pbx:
    raise SystemExit('archive SPM products are not linked in the target Frameworks phase')
for flag in ['-liconv', '-lxml2', '-lpthread']:
    if pbx.count(flag) < 2:
        raise SystemExit(f'missing libarchive system link dependency: {flag}')
if 'ZIPFoundation' in pbx:
    raise SystemExit('stale ZIPFoundation build dependency remains in the Xcode project')
if 'build_utils.sh' in pbx or 'install_python' in pbx:
    raise SystemExit('Python embed phase references an unavailable helper script')
if 'Python.xcframework' not in pbx or 'ios-arm64_x86_64-simulator' not in pbx:
    raise SystemExit('optional Python runtime embed phase is incomplete')


makefile = (root / 'Makefile').read_text()
if 'unzip -tq' not in makefile:
    raise SystemExit('TrollStore IPA packaging is missing ZIP integrity verification')
if "-name '*.so' -o -name '*.dylib'" not in makefile or 'ldid -S' not in makefile:
    raise SystemExit('optional Python extension modules are not included in the IPA signing step')

for name in ['CSVEditorView.swift', 'HexEditorView.swift', 'TextFileEditorView.swift', 'PlistEditorView.swift', 'ArchiveBrowserView.swift']:
    p = root / 'Hoshino/UI/Editors' / name
    if 'dismiss()' not in p.read_text():
        raise SystemExit(f'missing explicit exit action: {name}')

for path in [
    root / 'Hoshino/Core/ArchiveCore.cpp',
    root / 'Hoshino/Core/ArchiveCoreBridge.h',
    root / 'Hoshino/Core/NativeCore.cpp',
    root / 'RootHelper/main.cpp',
    root / 'Tests/ArchiveCoreSmoke.cpp',
    root / 'Tests/RootHelperServerProtocol.py',
    root / 'Tests/RootProcessBridgeServerSmoke.cpp',
]:
    if not path.is_file():
        raise SystemExit(f'missing required implementation/test file: {path.relative_to(root)}')

# Every extension-to-artwork mapping must resolve to a unique asset catalog entry.
file_types = (root / 'Hoshino/Models/FileTypeBadge.swift').read_text()
asset_root = root / 'Hoshino/Resources/Assets.xcassets'
# Validate every literal FileIcon_* reference, including the generated extension map,
# filename rules, directory bundles, symbolic links and the custom unknown-file image.
asset_keys = set(re.findall(r'FileIcon_([A-Za-z0-9_]+)', file_types))
# Asset names are built by add("extensions", "asset") to keep the mapping compact.
asset_keys.update(re.findall(r'add\(\"[^\"]+\",\s*\"([^\"]+)\"\)', file_types))
filename_section = file_types.split('private static let filenameMap', 1)[1].split('private static let extensionMap', 1)[0]
asset_keys.update(re.findall(r'\"[^\"]+\"\s*:\s*\"([^\"]+)\"', filename_section))
missing_assets = sorted(key for key in asset_keys if not (asset_root / f'FileIcon_{key}.imageset/Contents.json').is_file())
if missing_assets:
    raise SystemExit(f'missing file-type artwork: {missing_assets}')
if len(asset_keys) < 80:
    raise SystemExit('file type artwork mapping is unexpectedly small')
extension_map_block = file_types.split('private static let extensionMap', 1)[1].split('static func assetName', 1)[0]
all_mapped_extensions = set()
all_mapped_categories = set()
for extensions, category in re.findall(r'add\("([^"]+)"\s*,\s*"([^"]+)"\)', extension_map_block):
    all_mapped_extensions.update(extensions.split())
    all_mapped_categories.add(category)
if len(all_mapped_extensions) < 350 or len(all_mapped_categories) < 150:
    raise SystemExit(f'file type coverage too small: {len(all_mapped_extensions)} extensions / {len(all_mapped_categories)} icon categories')

# File-type images must not duplicate existing artwork byte-for-byte.
icon_hashes = {}
for icon in sorted(asset_root.glob('FileIcon_*.imageset/icon.png')):
    digest = hashlib.sha256(icon.read_bytes()).hexdigest()
    if digest in icon_hashes:
        raise SystemExit(f'duplicate file-type icon: {icon_hashes[digest]} and {icon.parent.name}')
    icon_hashes[digest] = icon.parent.name
if len(icon_hashes) < 90:
    raise SystemExit('expected at least 90 unique file-type artwork assets')
asset_names = {p.name.removeprefix('FileIcon_').removesuffix('.imageset') for p in asset_root.glob('FileIcon_*.imageset')}
referenced_assets = set(asset_keys)
orphan_assets = sorted(asset_names - referenced_assets)
if orphan_assets:
    raise SystemExit(f'unmapped file-type artwork assets: {orphan_assets}')
if 'Image(systemName: kind.symbol)' in (root / 'Hoshino/UI/Browser/FileBrowserView.swift').read_text():
    raise SystemExit('file browser still falls back to SF Symbols for unknown file types')
# File rows, search results, details and archive entries must use concrete Hoshino artwork.
for view_name in ['FileBrowserView.swift', 'SearchView.swift', 'FileDetailsView.swift', 'ArchiveBrowserView.swift', 'EditorAssociationSettingsView.swift']:
    view_path = root / 'Hoshino/UI' / ('Browser' if view_name == 'FileBrowserView.swift' else 'Settings' if view_name in ['SearchView.swift', 'EditorAssociationSettingsView.swift'] else 'Details' if view_name == 'FileDetailsView.swift' else 'Editors') / view_name
    view_source = view_path.read_text()
    if 'FileTypeIconAssets.assetName' not in view_source and 'Image("FileIcon_' not in view_source:
        raise SystemExit(f'{view_name} is not using the unified file artwork map')

service_source = (root / 'Hoshino/Services/FileSystemService.swift').read_text()
for token in ['func analyzeDirectory(', 'func findDuplicates(', 'case .content(let value)', 'case .sizeGreater(let threshold)', 'case .regex(let regex)']:
    if token not in service_source:
        raise SystemExit(f'missing advanced file-management feature: {token}')
search_source = (root / 'Hoshino/UI/Settings/SearchView.swift').read_text()
if 'struct DuplicateFinderView' not in search_source or 'FileSystemService.shared.findDuplicates' not in search_source:
    raise SystemExit('duplicate finder UI is not connected to the search service')
browser_source = (root / 'Hoshino/UI/Browser/FileBrowserView.swift').read_text()
if 'cancelOperationRequested' not in browser_source or 'failures.prefix(8)' not in browser_source:
    raise SystemExit('batch file operations must support cancellation and partial-failure reporting')
if 'FileIcon_generic' not in file_types or 'return "FileIcon_generic"' not in file_types:
    raise SystemExit('unknown file formats must resolve to Hoshino-owned artwork, never system drawing')


helper_source = (root / 'RootHelper/main.cpp').read_text()
bridge_source = (root / 'Hoshino/Core/RootProcessBridge.mm').read_text()
for token in ['runPersistentServer', '"--server"', '"--fd"', '"merge-directory"']:
    if token not in helper_source:
        raise SystemExit(f'missing persistent RootHelper server feature: {token}')
for token in ['HoshinoStartRootService', 'HoshinoRunRootServiceCommand', 'HoshinoStopRootService', 'socketpair']:
    if token not in bridge_source:
        raise SystemExit(f'missing app-scoped RootHelper bridge feature: {token}')
if 'RootHelperServerProtocol.py' not in makefile or 'RootProcessBridgeServerSmoke.cpp' not in makefile:
    raise SystemExit('persistent RootHelper server/bridge tests are not part of make smoke')

base_entitlements = plistlib.loads((root / 'Hoshino/Entitlements/TrollStore.entitlements').read_bytes())
for key in ['com.apple.private.security.no-sandbox', 'com.apple.private.security.storage.AppDataContainers', 'com.apple.private.persona-mgmt', 'platform-application']:
    if base_entitlements.get(key) is not True:
        raise SystemExit(f'missing required TrollStore entitlement: {key}')
if 'system-application' in base_entitlements or 'com.apple.private.security.system-application' in base_entitlements:
    raise SystemExit('unverified system-application entitlement must not enter the production profile')
experimental = plistlib.loads((root / 'Hoshino/Entitlements/TrollStore.experimental-system-application.entitlements').read_bytes())
if experimental.get('system-application') is not True or experimental.get('com.apple.private.security.system-application') is not True:
    raise SystemExit('experimental system-application entitlement profile is incomplete')
info = plistlib.loads((root / 'Hoshino/Info.plist').read_bytes())
if 'RootHelper' not in info.get('TSRootBinaries', []):
    raise SystemExit('RootHelper is not listed in TSRootBinaries')

print(f'Project integrity: PASS ({len(list((root / "Hoshino").rglob("*.swift")))} Swift files; C/C++ bridges, SPM packages, linker flags, build phases and editor exit actions checked)')
