#!/usr/bin/env python3
import os
import socket
import struct
import subprocess
import sys
import tempfile
from pathlib import Path


def send_frame(channel: socket.socket, arguments: list[str]) -> tuple[int, str]:
    channel.sendall(struct.pack("!I", len(arguments)))
    for argument in arguments:
        data = argument.encode("utf-8")
        channel.sendall(struct.pack("!I", len(data)))
        channel.sendall(data)

    header = receive_exact(channel, 8)
    status, length = struct.unpack("!II", header)
    message = receive_exact(channel, length).decode("utf-8", errors="replace") if length else ""
    return status, message


def receive_exact(channel: socket.socket, length: int) -> bytes:
    chunks = bytearray()
    while len(chunks) < length:
        part = channel.recv(length - len(chunks))
        if not part:
            raise RuntimeError("RootHelper closed the socket before completing a response")
        chunks.extend(part)
    return bytes(chunks)


def main() -> int:
    if len(sys.argv) != 2:
        print("usage: RootHelperServerProtocol.py <RootHelper>", file=sys.stderr)
        return 2
    if os.geteuid() != 0:
        print("RootHelper persistent server: SKIP (host test requires root euid)")
        return 0

    helper = str(Path(sys.argv[1]).resolve())
    with tempfile.TemporaryDirectory(prefix="hoshino-root-service-") as temporary:
        target = str(Path(temporary) / "created-by-server")
        parent, child = socket.socketpair()
        child_fd = child.fileno()
        process = subprocess.Popen([helper, "--server", "--fd", str(child_fd)], pass_fds=(child_fd,))
        child.close()
        try:
            ready = struct.unpack("!I", receive_exact(parent, 4))[0]
            assert ready == 0, f"service failed startup handshake: {ready}"

            status, message = send_frame(parent, ["--rpc", "--operation", "mkdir", "--path", target])
            assert status == 0, f"mkdir failed: {status}: {message}"
            assert Path(target).is_dir(), "mkdir request did not create its target"

            hard_source = Path(temporary) / "hard-source.txt"
            hard_source.write_text("hard-link-via-server")
            hard_destination = Path(temporary) / "hard-destination.txt"
            status, message = send_frame(parent, ["--rpc", "--operation", "hardlink", "--source", str(hard_source),
                                                  "--destination", str(hard_destination)])
            assert status == 0, f"hardlink failed: {status}: {message}"
            assert hard_source.stat().st_ino == hard_destination.stat().st_ino
            status, message = send_frame(parent, ["--rpc", "--operation", "chown", "--path", str(hard_destination),
                                                  "--uid", str(os.getuid()), "--gid", str(os.getgid())])
            assert status == 0, f"chown failed: {status}: {message}"
            assert hard_source.stat().st_uid == os.getuid() and hard_source.stat().st_gid == os.getgid()

            status, message = send_frame(parent, ["--rpc", "--operation", "delete", "--path", target])
            assert status == 0, f"delete failed: {status}: {message}"
            assert not Path(target).exists(), "delete request did not remove its target"

            source = Path(temporary) / "merge-source"
            destination = Path(temporary) / "merge-destination"
            (source / "nested").mkdir(parents=True)
            (destination / "nested").mkdir(parents=True)
            (source / "nested" / "conflict.txt").write_text("source")
            (destination / "nested" / "conflict.txt").write_text("destination")
            status, message = send_frame(parent, ["--rpc", "--operation", "merge-directory",
                                                  "--source", str(source), "--destination", str(destination)])
            assert status == 0, f"merge-directory failed: {status}: {message}"
            assert source.is_dir(), "copy-merge must retain its source"
            assert (destination / "nested" / "conflict 2.txt").read_text() == "source"
            assert (destination / "nested" / "conflict.txt").read_text() == "destination"

            move_source = Path(temporary) / "move-source"
            move_destination = Path(temporary) / "move-destination"
            (move_source / "child").mkdir(parents=True)
            (move_destination / "child").mkdir(parents=True)
            (move_source / "child" / "payload.txt").write_text("move")
            status, message = send_frame(parent, ["--rpc", "--operation", "merge-directory",
                                                  "--source", str(move_source), "--destination", str(move_destination),
                                                  "--move-source"])
            assert status == 0, f"move-merge failed: {status}: {message}"
            assert not move_source.exists(), "move-merge must remove the source only after successful copy"
            assert (move_destination / "child" / "payload.txt").read_text() == "move"
        finally:
            parent.close()
            process.wait(timeout=5)

    print("RootHelper persistent server protocol: PASS")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
