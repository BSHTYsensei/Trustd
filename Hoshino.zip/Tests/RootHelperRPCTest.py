#!/usr/bin/env python3
"""Host integration tests for the typed, non-shell RootHelper RPC interface."""
from __future__ import annotations
import os
import pathlib
import subprocess
import sys
import tempfile


def run(helper: str, *args: str) -> str:
    result = subprocess.run([helper, "--rpc", *args], text=True, capture_output=True, timeout=10)
    if result.returncode != 0:
        raise RuntimeError(f"RootHelper {args!r} failed ({result.returncode}): {result.stdout}{result.stderr}")
    return result.stdout + result.stderr


def main() -> int:
    if len(sys.argv) != 2:
        print(f"usage: {sys.argv[0]} /path/to/RootHelper", file=sys.stderr)
        return 2
    if os.geteuid() != 0:
        print("RootHelper RPC smoke: SKIP (host test requires euid 0)")
        return 0
    helper = str(pathlib.Path(sys.argv[1]).resolve())
    with tempfile.TemporaryDirectory(prefix="hoshino-root-rpc-") as temporary:
        root = pathlib.Path(temporary)
        folder = root / "created"
        file = folder / "source.txt"
        copy = root / "copy.txt"
        renamed = root / "renamed.txt"
        moved = root / "moved.txt"
        run(helper, "--operation", "mkdir", "--path", str(folder))
        run(helper, "--operation", "create-file", "--path", str(file))
        file.write_text("root-rpc-ok", encoding="utf-8")
        run(helper, "--operation", "copy", "--source", str(file), "--destination", str(copy))
        assert copy.read_text(encoding="utf-8") == "root-rpc-ok"
        run(helper, "--operation", "rename", "--source", str(copy), "--destination", str(renamed))
        assert renamed.exists() and not copy.exists()
        run(helper, "--operation", "move", "--source", str(renamed), "--destination", str(moved))
        assert moved.exists() and not renamed.exists()
        hardlink = root / "hardlink.txt"
        run(helper, "--operation", "hardlink", "--source", str(moved), "--destination", str(hardlink))
        assert hardlink.exists() and os.stat(hardlink).st_ino == os.stat(moved).st_ino
        run(helper, "--operation", "chmod", "--path", str(moved), "--mode", "0600")
        assert (moved.stat().st_mode & 0o777) == 0o600
        run(helper, "--operation", "chown", "--path", str(moved), "--uid", str(os.getuid()), "--gid", str(os.getgid()))
        assert moved.stat().st_uid == os.getuid() and moved.stat().st_gid == os.getgid()
        try:
            run(helper, "--operation", "xattr-set", "--path", str(moved), "--name", "user.hoshino.rpc", "--value-base64", "cm9vdC1ycGMteGF0dHI=")
            assert os.getxattr(moved, "user.hoshino.rpc") == b"root-rpc-xattr"
            run(helper, "--operation", "xattr-remove", "--path", str(moved), "--name", "user.hoshino.rpc")
            try:
                os.getxattr(moved, "user.hoshino.rpc")
                raise AssertionError("RootHelper xattr-remove did not remove the attribute")
            except OSError:
                pass
        except (AttributeError, OSError):
            # Some host filesystems disable user xattrs; iOS/macOS uses its
            # own com.* namespace and is checked by device integration tests.
            pass
        run(helper, "--operation", "symlink", "--target", str(moved), "--link", str(root / "link"))
        assert (root / "link").is_symlink()
        run(helper, "--operation", "delete", "--path", str(folder))
        assert not folder.exists()
        run(helper, "--operation", "delete", "--path", str(root / "link"))
        assert not (root / "link").is_symlink()
        rejected = subprocess.run([helper, "--rpc", "--operation", "run-shell", "--command", "id"],
                                  text=True, capture_output=True, timeout=10)
        assert rejected.returncode != 0, "unknown RPC operation must be rejected"
    print("RootHelper typed RPC smoke: PASS")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
