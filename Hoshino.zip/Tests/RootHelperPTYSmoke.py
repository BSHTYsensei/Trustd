#!/usr/bin/env python3
"""Host-side PTY smoke test for RootHelper (macOS/Linux)."""
from __future__ import annotations

import os
import pty
import select
import subprocess
import sys
import time


def main() -> int:
    if len(sys.argv) != 2:
        print(f"usage: {sys.argv[0]} /path/to/RootHelper", file=sys.stderr)
        return 2

    master, slave = pty.openpty()
    process = subprocess.Popen(
        [sys.argv[1], "--cwd", "/tmp", "--target", "/usr/bin/id"],
        stdin=slave,
        stdout=slave,
        stderr=slave,
        close_fds=True,
        start_new_session=True,
    )
    os.close(slave)
    output = bytearray()

    def collect(duration: float) -> None:
        deadline = time.monotonic() + duration
        while time.monotonic() < deadline:
            readable, _, _ = select.select([master], [], [], 0.1)
            if readable:
                try:
                    chunk = os.read(master, 8192)
                except OSError:
                    return
                if not chunk:
                    return
                output.extend(chunk)

    try:
        collect(0.35)
        os.write(master, b"tty\nstty size\nprintf 'HOSHINO-PTY-OK\\n'\nexit\n")
        collect(1.5)
        process.wait(timeout=2.0)
    except subprocess.TimeoutExpired:
        process.terminate()
        process.wait(timeout=2.0)
        print("RootHelper did not exit after the shell exit command", file=sys.stderr)
        return 1
    finally:
        os.close(master)

    transcript = output.decode("utf-8", errors="replace")
    required = ("uid=", "option hints", "/dev/", "HOSHINO-PTY-OK")
    missing = [marker for marker in required if marker not in transcript]
    if missing:
        print(transcript, file=sys.stderr)
        print(f"Missing PTY smoke markers: {', '.join(missing)}", file=sys.stderr)
        return 1

    print("RootHelper PTY smoke: PASS")
    for line in transcript.splitlines():
        if "uid=" in line or "/dev/" in line or "HOSHINO-PTY-OK" in line:
            print(line)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
