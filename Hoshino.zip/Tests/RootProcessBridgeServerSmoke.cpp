#include "RootProcessBridge.h"

#include <cstdio>
#include <cstdlib>
#include <string>
#include <spawn.h>
#include <cerrno>
#include <fcntl.h>
#include <sys/stat.h>
#include <unistd.h>
#include <vector>

#if !defined(__APPLE__)
// The private TrollStore persona APIs do not exist on Linux; exercise the
// unprivileged host path while running this smoke test as root.
extern "C" int posix_spawnattr_set_persona_np(const posix_spawnattr_t *, uid_t, uint32_t) { return ENOSYS; }
extern "C" int posix_spawnattr_set_persona_uid_np(const posix_spawnattr_t *, uid_t) { return ENOSYS; }
extern "C" int posix_spawnattr_set_persona_gid_np(const posix_spawnattr_t *, uid_t) { return ENOSYS; }
#endif

int main(int argc, char **argv) {
    if (argc != 2) return 2;
    if (geteuid() != 0) {
        std::puts("RootProcessBridge persistent service: SKIP (host test requires root euid)");
        return 0;
    }

    char temporary[] = "/tmp/hoshino-root-bridge-XXXXXX";
    char *directory = mkdtemp(temporary);
    if (!directory) return 3;
    const std::string target = std::string(directory) + "/created-by-bridge";

    int32_t channelFD = -1;
    pid_t childPID = 0;
    const int startup = HoshinoStartRootService(argv[1], &channelFD, &childPID);
    if (startup != 0) {
        std::fprintf(stderr, "RootProcessBridge startup failed: %d\n", startup);
        (void)rmdir(directory);
        return 4;
    }

    auto request = [&](const std::vector<std::string> &arguments) {
        std::vector<const char *> pointers;
        pointers.reserve(arguments.size());
        for (const auto &argument : arguments) pointers.push_back(argument.c_str());
        char output[2048] = {};
        return HoshinoRunRootServiceCommand(channelFD, pointers.data(), pointers.size(), output, sizeof(output));
    };

    int result = request({"--rpc", "--operation", "mkdir", "--path", target});
    struct stat metadata{};
    if (result != 0 || ::stat(target.c_str(), &metadata) != 0 || !S_ISDIR(metadata.st_mode)) {
        HoshinoStopRootService(channelFD, childPID);
        (void)rmdir(directory);
        return 5;
    }

    result = request({"--rpc", "--operation", "delete", "--path", target});
    const bool removed = (::access(target.c_str(), F_OK) != 0);
    if (result != 0 || !removed) {
        HoshinoStopRootService(channelFD, childPID);
        (void)rmdir(directory);
        return 6;
    }

    const std::string mergeSource = std::string(directory) + "/merge-source";
    const std::string mergeDestination = std::string(directory) + "/merge-destination";
    (void)mkdir(mergeSource.c_str(), 0755);
    (void)mkdir(mergeDestination.c_str(), 0755);
    const std::string sourceFile = mergeSource + "/from-root-helper.txt";
    const int fileFD = ::open(sourceFile.c_str(), O_WRONLY | O_CREAT | O_EXCL, 0644);
    if (fileFD < 0) { HoshinoStopRootService(channelFD, childPID); return 7; }
    (void)::write(fileFD, "merge", 5);
    (void)::close(fileFD);
    result = request({"--rpc", "--operation", "merge-directory", "--source", mergeSource,
                      "--destination", mergeDestination, "--move-source"});
    const bool merged = (::access((mergeDestination + "/from-root-helper.txt").c_str(), F_OK) == 0);
    const bool sourceRemoved = (::access(mergeSource.c_str(), F_OK) != 0);
    HoshinoStopRootService(channelFD, childPID);
    (void)rmdir(directory);
    if (result != 0 || !merged || !sourceRemoved) return 8;

    std::puts("RootProcessBridge persistent service: PASS");
    return 0;
}
