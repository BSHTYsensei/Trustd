#include "../Hoshino/Core/ArchiveCoreBridge.h"
#include <archive.h>
#include <archive_entry.h>
#include <cassert>
#include <cerrno>
#include <cstdio>
#include <cstring>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <string>
#include <vector>
#include <sys/stat.h>
#include <unistd.h>

namespace fs = std::filesystem;

static std::string temporaryRoot() {
    std::string pattern = "/tmp/hoshino-archive-smoke-XXXXXX";
    std::vector<char> buffer(pattern.begin(), pattern.end()); buffer.push_back('\0');
    char *created = mkdtemp(buffer.data()); assert(created); return created;
}

static void callCreate(const fs::path &out, const fs::path &source, const char *format, const char *filter) {
    const char *sources[] = {source.c_str()};
    char error[4096]{};
    const int rc = HoshinoArchiveCreate(out.c_str(), sources, 1, format, filter, 1, error, sizeof(error));
    if (rc != 0) { std::cerr << "create " << out << " failed: " << error << " (" << rc << ")\n"; std::abort(); }
    assert(fs::is_regular_file(out));
}

static std::string listJSON(const fs::path &archivePath) {
    std::vector<char> json(8 * 1024 * 1024, '\0'); char error[4096]{};
    const int rc = HoshinoArchiveListJSON(archivePath.c_str(), nullptr, json.data(), json.size(), error, sizeof(error));
    if (rc != 0) { std::cerr << "list failed: " << error << " (" << rc << ")\n"; std::abort(); }
    return json.data();
}

static void callExtract(const fs::path &archivePath, const fs::path &destination) {
    fs::create_directories(destination);
    char error[4096]{};
    const int rc = HoshinoArchiveExtract(archivePath.c_str(), destination.c_str(), nullptr, error, sizeof(error));
    if (rc != 0) { std::cerr << "extract " << archivePath << " failed: " << error << " (" << rc << ")\n"; std::abort(); }
}

int main() {
    const fs::path root = temporaryRoot();
    const fs::path source = root / "source";
    fs::create_directories(source / "empty");
    fs::create_directories(source / "nested");
    { std::ofstream file(source / "nested" / "hello.txt"); file << "Hoshino archive core\n"; }
    fs::create_symlink("nested/hello.txt", source / "hello-link");

    const struct { const char *name; const char *format; const char *filter; } formats[] = {
        {"sample.zip", "zip", "none"},
        {"sample.tar", "pax", "none"},
        {"sample.tar.gz", "pax", "gzip"},
        {"sample.tar.bz2", "pax", "bzip2"},
        {"sample.tar.xz", "pax", "xz"},
        {"sample.7z", "7zip", "none"},
        {"sample.cpio", "cpio", "none"}
    };
    for (const auto &item : formats) {
        const fs::path archivePath = root / item.name;
        callCreate(archivePath, source, item.format, item.filter);
        const std::string json = listJSON(archivePath);
        assert(json.find("hello.txt") != std::string::npos);
        assert(json.find("empty") != std::string::npos);
        assert(json.find("hello-link") != std::string::npos);
        const fs::path destination = root / (std::string("out-") + item.name);
        callExtract(archivePath, destination);
        assert(fs::is_regular_file(destination / "source" / "nested" / "hello.txt"));
        assert(fs::is_directory(destination / "source" / "empty"));
        assert(fs::is_symlink(destination / "source" / "hello-link"));
        std::ifstream file(destination / "source" / "nested" / "hello.txt");
        std::string contents; std::getline(file, contents); assert(contents == "Hoshino archive core");
    }

    // ISO 9660 is a supported writer format; use a regular file because ISO
    // images cannot represent the full POSIX metadata model used by TAR/CPIO.
    const fs::path isoSource = root / "iso-payload.txt";
    { std::ofstream file(isoSource); file << "iso9660-smoke\n"; }
    const fs::path isoArchive = root / "sample.iso";
    callCreate(isoArchive, isoSource, "iso9660", "none");
    assert(listJSON(isoArchive).find("iso-payload.txt") != std::string::npos);
    const fs::path isoDestination = root / "out-iso";
    callExtract(isoArchive, isoDestination);
    bool isoFound = false;
    for (const auto &item : fs::recursive_directory_iterator(isoDestination)) {
        if (item.is_regular_file()) {
            std::ifstream file(item.path());
            std::string line; std::getline(file, line);
            if (line == "iso9660-smoke") isoFound = true;
        }
    }
    assert(isoFound);

    // Raw single-file compression streams (GZIP/BZIP2/XZ) must round-trip.
    const fs::path single = root / "single.bin";
    { std::ofstream file(single, std::ios::binary); file << "raw-stream-payload\n"; }
    const struct { const char *name; const char *filter; } streams[] = {
        {"single.txt.gz", "gzip"}, {"single.txt.bz2", "bzip2"}, {"single.txt.xz", "xz"}
    };
    for (const auto &item : streams) {
        const fs::path archivePath = root / item.name;
        callCreate(archivePath, single, "raw", item.filter);
        assert(listJSON(archivePath).find("single.txt") != std::string::npos);
        const fs::path destination = root / (std::string("out-") + item.name);
        callExtract(archivePath, destination);
        std::ifstream file(destination / "single.txt", std::ios::binary);
        std::string contents; std::getline(file, contents); assert(contents == "raw-stream-payload");
    }

    // Ensure path traversal, parent/child collisions and escaping symlinks are rejected.
    const fs::path malicious = root / "malicious.tar";
    struct archive *writer = archive_write_new(); assert(writer);
    assert(archive_write_set_format_pax(writer) == ARCHIVE_OK);
    assert(archive_write_open_filename(writer, malicious.c_str()) == ARCHIVE_OK);
    struct archive_entry *entry = archive_entry_new(); assert(entry);
    archive_entry_set_pathname(entry, "../escape.txt"); archive_entry_set_filetype(entry, AE_IFREG);
    archive_entry_set_perm(entry, 0644); archive_entry_set_size(entry, 1);
    assert(archive_write_header(writer, entry) == ARCHIVE_OK); assert(archive_write_data(writer, "x", 1) == 1);
    archive_entry_free(entry); assert(archive_write_close(writer) == ARCHIVE_OK); archive_write_free(writer);
    const fs::path badDestination = root / "bad-out"; fs::create_directories(badDestination);
    char error[4096]{};
    const int badRC = HoshinoArchiveExtract(malicious.c_str(), badDestination.c_str(), nullptr, error, sizeof(error));
    assert(badRC != 0); assert(!fs::exists(root / "escape.txt"));

    const fs::path collision = root / "collision.tar";
    writer = archive_write_new(); assert(writer);
    assert(archive_write_set_format_pax(writer) == ARCHIVE_OK);
    assert(archive_write_open_filename(writer, collision.c_str()) == ARCHIVE_OK);
    entry = archive_entry_new(); assert(entry);
    archive_entry_set_pathname(entry, "parent/child.txt"); archive_entry_set_filetype(entry, AE_IFREG);
    archive_entry_set_perm(entry, 0644); archive_entry_set_size(entry, 1);
    assert(archive_write_header(writer, entry) == ARCHIVE_OK); assert(archive_write_data(writer, "x", 1) == 1);
    archive_entry_clear(entry);
    archive_entry_set_pathname(entry, "parent"); archive_entry_set_filetype(entry, AE_IFREG);
    archive_entry_set_perm(entry, 0644); archive_entry_set_size(entry, 1);
    assert(archive_write_header(writer, entry) == ARCHIVE_OK); assert(archive_write_data(writer, "y", 1) == 1);
    archive_entry_free(entry); assert(archive_write_close(writer) == ARCHIVE_OK); archive_write_free(writer);
    const fs::path collisionDestination = root / "collision-out"; fs::create_directories(collisionDestination);
    std::memset(error, 0, sizeof(error));
    const int collisionRC = HoshinoArchiveExtract(collision.c_str(), collisionDestination.c_str(), nullptr, error, sizeof(error));
    assert(collisionRC != 0);

    // Case-insensitive filesystems must reject entries that differ only by case.
    const fs::path caseCollision = root / "case-collision.tar";
    writer = archive_write_new(); assert(writer);
    assert(archive_write_set_format_pax(writer) == ARCHIVE_OK);
    assert(archive_write_open_filename(writer, caseCollision.c_str()) == ARCHIVE_OK);
    for (const char *name : {"Case.txt", "case.txt"}) {
        entry = archive_entry_new(); assert(entry);
        archive_entry_set_pathname(entry, name); archive_entry_set_filetype(entry, AE_IFREG);
        archive_entry_set_perm(entry, 0644); archive_entry_set_size(entry, 1);
        assert(archive_write_header(writer, entry) == ARCHIVE_OK);
        assert(archive_write_data(writer, "x", 1) == 1);
        archive_entry_free(entry);
    }
    assert(archive_write_close(writer) == ARCHIVE_OK); archive_write_free(writer);
    const fs::path caseDestination = root / "case-out"; fs::create_directories(caseDestination);
    std::memset(error, 0, sizeof(error));
    const int caseRC = HoshinoArchiveExtract(caseCollision.c_str(), caseDestination.c_str(), nullptr, error, sizeof(error));
    assert(caseRC != 0);

    // An archive created inside its source directory must not archive its own
    // temporary writer file or the destination it is producing.
    const fs::path selfSource = root / "self-source"; fs::create_directories(selfSource);
    { std::ofstream file(selfSource / "payload.txt"); file << "self-safe"; }
    const fs::path selfArchive = selfSource / "snapshot.zip";
    callCreate(selfArchive, selfSource, "zip", "none");
    const std::string selfJSON = listJSON(selfArchive);
    assert(selfJSON.find("payload.txt") != std::string::npos);
    assert(selfJSON.find("hoshino-tmp") == std::string::npos);
    assert(selfJSON.find("snapshot.zip") == std::string::npos);

    fs::remove_all(root);
    std::cout << "Archive core smoke passed (ZIP/TAR/TGZ/TBZ2/TXZ/7z/CPIO/ISO9660/GZ/BZ2/XZ + symlink + empty dir + traversal/case-collision/self-inclusion protection)\n";
}
