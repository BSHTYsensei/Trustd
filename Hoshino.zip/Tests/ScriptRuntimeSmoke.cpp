#include <cerrno>
#include <cstdint>
#include <cstdlib>
#include <cstdio>
#include <cstring>
#include <string>
#include <unistd.h>
#include <unwind.h>
#include <fcntl.h>

extern "C" int HoshinoRunShellScript(const char *path, char *output, size_t capacity);
extern "C" int HoshinoInterpreterRuntimeAvailable(const char *kind);
extern "C" int HoshinoRunInterpreterScript(const char *kind, const char *path, char *output, size_t capacity);

#if !defined(__APPLE__)
extern "C" int _NSGetExecutablePath(char *, uint32_t *) { return -1; }
// Linux containers do not ship libobjc. This test source contains no Objective-C
// exceptions, so use the C++ unwind personality solely for host-link smoke tests.
extern "C" _Unwind_Reason_Code __gxx_personality_v0(int, _Unwind_Action, uint64_t,
                                                    _Unwind_Exception *, _Unwind_Context *);
extern "C" _Unwind_Reason_Code __gnu_objc_personality_v0(int version, _Unwind_Action actions,
                                                          uint64_t exceptionClass,
                                                          _Unwind_Exception *exceptionObject,
                                                          _Unwind_Context *context) {
    return __gxx_personality_v0(version, actions, exceptionClass, exceptionObject, context);
}
#endif

static std::string makeScript(const char *contents) {
    char path[] = "/tmp/hoshino-script-XXXXXX";
    const int fd = mkstemp(path);
    if (fd < 0) return {};
    const size_t length = std::strlen(contents);
    size_t offset = 0;
    while (offset < length) {
        const ssize_t count = write(fd, contents + offset, length - offset);
        if (count < 0 && errno == EINTR) continue;
        if (count <= 0) { close(fd); unlink(path); return {}; }
        offset += static_cast<size_t>(count);
    }
    close(fd);
    return path;
}

int main() {
    char output[4096] = {};
    const std::string successPath = makeScript("printf 'script-runtime-ok\\n'\n");
    if (successPath.empty()) return 1;
    int code = HoshinoRunShellScript(successPath.c_str(), output, sizeof(output));
    unlink(successPath.c_str());
    if (code != 0 || std::strstr(output, "script-runtime-ok") == nullptr) {
        std::fprintf(stderr, "shell runtime failed (%d): %s\n", code, output);
        return 2;
    }

    const std::string failurePath = makeScript("printf 'script-runtime-error\\n' >&2; exit 7\n");
    if (failurePath.empty()) return 3;
    std::memset(output, 0, sizeof(output));
    code = HoshinoRunShellScript(failurePath.c_str(), output, sizeof(output));
    unlink(failurePath.c_str());
    if (code != 7 || std::strstr(output, "script-runtime-error") == nullptr) {
        std::fprintf(stderr, "shell error propagation failed (%d): %s\n", code, output);
        return 4;
    }

    if (HoshinoInterpreterRuntimeAvailable("unsupported-kind") != 0) return 5;
    if (HoshinoInterpreterRuntimeAvailable("awk") == 1) {
        const std::string awkPath = makeScript("BEGIN { print \"awk-runtime-ok\" }\n");
        if (awkPath.empty()) return 6;
        std::memset(output, 0, sizeof(output));
        code = HoshinoRunInterpreterScript("awk", awkPath.c_str(), output, sizeof(output));
        unlink(awkPath.c_str());
        if (code != 0 || std::strstr(output, "awk-runtime-ok") == nullptr) {
            std::fprintf(stderr, "AWK runtime failed (%d): %s\n", code, output);
            return 7;
        }
    }
    if (HoshinoInterpreterRuntimeAvailable("mjs") == 1) {
        const std::string esmPath = makeScript("import { strict as assert } from 'node:assert';\nassert.equal(2 + 2, 4);\nconsole.log('esm-node-ok');\n");
        if (esmPath.empty()) return 8;
        std::memset(output, 0, sizeof(output));
        code = HoshinoRunInterpreterScript("mjs", esmPath.c_str(), output, sizeof(output));
        unlink(esmPath.c_str());
        if (code != 0 || std::strstr(output, "esm-node-ok") == nullptr) {
            std::fprintf(stderr, "Node.js ESM runtime failed (%d): %s\n", code, output);
            return 9;
        }
    }

    std::puts("Script runtime smoke: PASS");
    return 0;
}
