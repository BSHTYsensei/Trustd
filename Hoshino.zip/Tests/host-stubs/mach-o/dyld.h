#pragma once
#include <stdint.h>
#ifdef __cplusplus
extern "C" {
#endif
int _NSGetExecutablePath(char *buf, uint32_t *bufsize);
#ifdef __cplusplus
}
#endif
