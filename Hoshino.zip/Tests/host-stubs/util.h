// Linux host-test compatibility for Apple's <util.h> openpty declaration.
#include <pty.h>
