import Foundation
import CoreFoundation

// A small standalone error definition lets this model test run on macOS/Linux
// without compiling the iOS/Darwin-specific file manager service.
enum FileSystemError: Error {
    case invalidPlist(String)
}

@main
struct PlistNodeRoundTripTests {
    static func main() throws {
        let fixture: [String: Any] = [
            "name": "Hoshino",
            "count": NSNumber(value: 42),
            "ratio": NSNumber(value: 0.625),
            "enabled": NSNumber(value: true),
            "created": Date(timeIntervalSince1970: 1_700_000_000),
            "payload": Data([0x00, 0x7F, 0xFF]),
            "items": ["one", NSNumber(value: 2), NSNumber(value: false)]
        ]

        for format in [PropertyListSerialization.PropertyListFormat.xml, .binary] {
            let source = try PropertyListSerialization.data(fromPropertyList: fixture, format: format, options: 0)
            var detected = PropertyListSerialization.PropertyListFormat.xml
            let raw = try PropertyListSerialization.propertyList(from: source, options: [.mutableContainersAndLeaves], format: &detected)
            precondition(detected == format, "Plist format detection failed")

            var root = try PlistNode.parse(raw)
            precondition(root.kind == .dictionary, "Root dictionary was not detected")
            precondition(root.children.contains(where: { $0.name == "enabled" && $0.kind == .boolean }), "Boolean node type was not preserved")
            precondition(root.children.contains(where: { $0.name == "payload" && $0.kind == .data }), "Data node type was not preserved")

            let added = PlistNode(name: "newKey", kind: .string, value: "added")
            precondition(root.append(added, to: root.id), "Could not append a dictionary item")
            precondition(root.delete(id: added.id), "Could not delete a dictionary item")

            let edited = PlistNode(name: "name", kind: .string, value: "Hoshino Editor")
            let originalName = root.children.first(where: { $0.name == "name" })!
            precondition(root.update(id: originalName.id, with: PlistNode(id: originalName.id, name: edited.name, kind: edited.kind, value: edited.value)), "Could not update a node")

            let result = try root.toPropertyListObject()
            let output = try PropertyListSerialization.data(fromPropertyList: result, format: format, options: 0)
            var outputFormat = PropertyListSerialization.PropertyListFormat.xml
            let decoded = try PropertyListSerialization.propertyList(from: output, options: [], format: &outputFormat) as! [String: Any]
            precondition(outputFormat == format, "Saving did not preserve XML/Binary format")
            precondition(decoded["name"] as? String == "Hoshino Editor", "Edited value was not saved")
            precondition((decoded["payload"] as? Data) == Data([0x00, 0x7F, 0xFF]), "Data node did not round-trip")
            let enabled = decoded["enabled"] as! NSNumber
            precondition(CFGetTypeID(enabled) == CFBooleanGetTypeID(), "Boolean node became an integer")
        }
        print("PlistNode XML/Binary round-trip tests: PASS")
    }
}
