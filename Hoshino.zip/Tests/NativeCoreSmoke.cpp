#include "../Hoshino/Core/NativeCore.hpp"
#include <filesystem>
#include <fstream>
#include <iostream>
#include <unistd.h>
#include <sys/stat.h>
#include <iterator>
namespace fs = std::filesystem;
int main() {
    auto root = fs::temp_directory_path() / ("hoshino-core-" + std::to_string(getpid()));
    fs::remove_all(root); fs::create_directories(root / "src" / "nested" / "empty");
    { std::ofstream f(root / "src" / "nested" / "data.txt"); f << "mixed-language-core"; }
    auto createdDirectory = hoshino::core::create_directory((root / "created").string());
    if (!createdDirectory.ok || !fs::is_directory(root / "created")) return 10;
    auto createdFile = hoshino::core::create_file((root / "created" / "empty.txt").string());
    if (!createdFile.ok || !fs::is_regular_file(root / "created" / "empty.txt")) return 11;
    if (hoshino::core::create_file((root / "created" / "empty.txt").string()).ok) return 12;
    auto createdLink = hoshino::core::create_symlink("empty.txt", (root / "created" / "link").string());
    if (!createdLink.ok || !fs::is_symlink(root / "created" / "link")) return 13;
    { std::ofstream f(root / "created" / "hard-source.txt"); f << "hard-link-data"; }
    auto createdHardLink = hoshino::core::create_hardlink((root / "created" / "hard-source.txt").string(),
                                                         (root / "created" / "hard-copy.txt").string());
    if (!createdHardLink.ok || !fs::exists(root / "created" / "hard-copy.txt")) return 23;
    struct stat hardSourceStat {}, hardCopyStat {};
    if (::stat((root / "created" / "hard-source.txt").c_str(), &hardSourceStat) != 0 ||
        ::stat((root / "created" / "hard-copy.txt").c_str(), &hardCopyStat) != 0 ||
        hardSourceStat.st_ino != hardCopyStat.st_ino || hardSourceStat.st_nlink < 2) return 24;
    if (hoshino::core::create_hardlink((root / "created").string(), (root / "created" / "directory-link").string()).ok) return 25;
    auto copied = hoshino::core::transfer((root / "src").string(), (root / "copy").string(), hoshino::core::Operation::copy, false);
    if (!copied.ok || !fs::exists(root / "copy" / "nested" / "data.txt") || !fs::is_directory(root / "copy" / "nested" / "empty")) { std::cerr << copied.message << "\n"; return 1; }
    auto conflict = hoshino::core::transfer((root / "src").string(), (root / "copy").string(), hoshino::core::Operation::copy, false);
    if (conflict.ok) return 2;
    auto renamed = hoshino::core::transfer((root / "copy").string(), (root / "renamed").string(), hoshino::core::Operation::rename, false);
    if (!renamed.ok || fs::exists(root / "copy") || !fs::exists(root / "renamed")) return 3;
    auto chmodResult = hoshino::core::set_permissions((root / "renamed").string(), 0700, true);
    if (!chmodResult.ok) return 4;
    auto chownResult = hoshino::core::set_owner((root / "renamed" / "nested" / "data.txt").string(),
                                                static_cast<std::uint32_t>(::getuid()),
                                                static_cast<std::uint32_t>(::getgid()), false);
    if (!chownResult.ok) { std::cerr << chownResult.message << "\n"; return 26; }
    auto moved = hoshino::core::transfer((root / "src").string(), (root / "moved").string(), hoshino::core::Operation::move, false);
    if (!moved.ok || fs::exists(root / "src") || !fs::exists(root / "moved")) return 5;
    { std::ofstream f(root / "replacement-source.txt"); f << "new-value"; }
    { std::ofstream f(root / "replacement-target.txt"); f << "old-value"; }
    auto replaced = hoshino::core::transfer((root / "replacement-source.txt").string(), (root / "replacement-target.txt").string(), hoshino::core::Operation::copy, true);
    if (!replaced.ok) { std::cerr << replaced.message << "\n"; return 6; }
    { std::ifstream f(root / "replacement-target.txt"); std::string value; f >> value; if (value != "new-value") return 7; }
    fs::create_symlink("missing-target.txt", root / "dangling-source-link");
    auto danglingCopy = hoshino::core::transfer((root / "dangling-source-link").string(), (root / "dangling-copy").string(), hoshino::core::Operation::copy, false);
    if (!danglingCopy.ok || !fs::is_symlink(root / "dangling-copy")) return 17;
    fs::create_symlink("replacement-target.txt", root / "source-link");
    auto linkCopy = hoshino::core::transfer((root / "source-link").string(), (root / "link-copy").string(), hoshino::core::Operation::copy, false);
    if (!linkCopy.ok || !fs::is_symlink(root / "link-copy")) return 8;
#if defined(__APPLE__)
    const std::string attrName = "com.hoshino.smoke";
#else
    const std::string attrName = "user.hoshino.smoke";
#endif
    const char attrValue[] = "xattr-ok";
    auto attrSet = hoshino::core::set_xattr((root / "replacement-target.txt").string(), attrName, attrValue, sizeof(attrValue), true);
    if (attrSet.ok) {
        auto attrRemove = hoshino::core::remove_xattr((root / "replacement-target.txt").string(), attrName, true);
        if (!attrRemove.ok) return 9;
    }
    auto removeLink = hoshino::core::remove_item((root / "created" / "link").string());
    if (!removeLink.ok || !fs::exists(root / "created" / "empty.txt")) return 14;
    auto removeDirectory = hoshino::core::remove_item((root / "created").string());
    if (!removeDirectory.ok || fs::exists(root / "created")) return 15;
    auto selfMove = hoshino::core::transfer((root / "renamed").string(), (root / "renamed" / "child").string(), hoshino::core::Operation::copy, false);
    if (selfMove.ok) return 16;

    // Directory merge preserves colliding files, recursively combines folders,
    // and keeps the source untouched until a move-merge fully succeeds.
    fs::create_directories(root / "merge-source" / "nested");
    fs::create_directories(root / "merge-destination" / "nested");
    { std::ofstream f(root / "merge-source" / "root.txt"); f << "root-source"; }
    { std::ofstream f(root / "merge-source" / "nested" / "same.txt"); f << "source-version"; }
    { std::ofstream f(root / "merge-source" / "nested" / "new.txt"); f << "new-entry"; }
    { std::ofstream f(root / "merge-destination" / "nested" / "same.txt"); f << "destination-version"; }
    auto merged = hoshino::core::merge_directory((root / "merge-source").string(),
                                                  (root / "merge-destination").string(), false);
    if (!merged.ok || !fs::exists(root / "merge-source") ||
        !fs::exists(root / "merge-destination" / "root.txt") ||
        !fs::exists(root / "merge-destination" / "nested" / "new.txt") ||
        !fs::exists(root / "merge-destination" / "nested" / "same 2.txt")) {
        std::cerr << "directory merge failed: " << merged.message << "\n";
        return 19;
    }
    { std::ifstream f(root / "merge-destination" / "nested" / "same.txt"); std::string value; f >> value; if (value != "destination-version") return 20; }

    fs::create_directories(root / "move-merge-source" / "sub");
    fs::create_directories(root / "move-merge-destination" / "sub");
    { std::ofstream f(root / "move-merge-source" / "sub" / "moved.txt"); f << "move-merge"; }
    auto moveMerged = hoshino::core::merge_directory((root / "move-merge-source").string(),
                                                      (root / "move-merge-destination").string(), true);
    if (!moveMerged.ok || fs::exists(root / "move-merge-source") ||
        !fs::exists(root / "move-merge-destination" / "sub" / "moved.txt")) {
        std::cerr << "directory move-merge failed: " << moveMerged.message << "\n";
        return 21;
    }

    auto mergeIntoChild = hoshino::core::merge_directory((root / "merge-destination").string(),
                                                         (root / "merge-destination" / "nested").string(), false);
    if (mergeIntoChild.ok) return 22;

    // Exercise the EXDEV copy+atomic-detach move path when /dev/shm is a
    // different filesystem from the temporary test directory (Linux CI).
    const fs::path sharedMemory = "/dev/shm";
    struct stat rootStat = {}, sharedStat = {};
    if (fs::is_directory(sharedMemory) && ::stat(root.c_str(), &rootStat) == 0 &&
        ::stat(sharedMemory.c_str(), &sharedStat) == 0 && rootStat.st_dev != sharedStat.st_dev) {
        const fs::path crossSource = root / "cross-volume-source";
        const fs::path crossDestination = sharedMemory / ("hoshino-cross-volume-" + std::to_string(getpid()));
        fs::remove_all(crossDestination);
        fs::create_directories(crossSource / "empty-subdirectory");
        { std::ofstream f(crossSource / "payload.txt"); f << "cross-volume-atomic-move"; }
        auto crossMove = hoshino::core::transfer(crossSource.string(), crossDestination.string(), hoshino::core::Operation::move, false);
        if (!crossMove.ok || fs::exists(crossSource) ||
            !fs::exists(crossDestination / "payload.txt") ||
            !fs::is_directory(crossDestination / "empty-subdirectory")) {
            std::cerr << "cross-volume move failed: " << crossMove.message << "\n";
            return 18;
        }
        fs::remove_all(crossDestination);
    }

    fs::remove_all(root);
    std::cout << "NativeCore smoke passed\n";
    return 0;
}
