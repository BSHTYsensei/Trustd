# Hoshino 功能矩阵

状态依据当前工程源码和 `make smoke` 主机测试。**主机已测不等于 iOS SDK 编译或 TrollStore 真机验收。**

| 功能 | 实现位置 | 当前状态 | 边界与说明 |
|---|---|---|---|
| 文件浏览、列表/网格、排序、过滤、目录搜索 | `UI/Browser/FileBrowserView.swift`, `Services/FileSystemService.swift` | 已实现 | 搜索范围受当前进程及安全书签授权限制 |
| 高级递归搜索 | `Services/FileSystemService.swift`, `UI/Settings/SearchView.swift` | 已实现，源码语法已测 | 支持 name/path/ext/type/size/date/regex/content；内容搜索限 UTF-8 文本且单文件不超过 2 MiB |
| 重复文件查找 | `FileSystemService.swift`, `SearchView.swift` | 已实现，源码语法已测 | 先按大小分桶，再以 SHA-256 精确校验；硬链接别名排除；清理只允许进入废纸篓 |
| 目录用量分析 | `FileSystemService.swift`, `FileDetailsView.swift` | 已实现，源码语法已测 | 汇总文件、子目录、符号链接、扩展名分布和最大文件；不跟随符号链接，硬链接数据只计一次 |
| 批量传输/删除 | `FileBrowserView.swift`, `ClipboardStore.swift` | 已实现，源码语法已测 | 显示逐项进度；失败项目单独报告并继续；允许在当前项目完成后停止剩余队列 |
| 文件类型专用图标 | `Models/FileTypeBadge.swift`, `Resources/Assets.xcassets` | 163 个唯一图标资源；映射完整性已测 | 367 个扩展名映射到 153 个具体图标类别；未知格式显示自有 generic 图片，不调用系统文件图标绘制 |
| 新建、删除、复制、移动、重命名 | `Core/NativeCore.cpp`, `Core/NativeCoreBridge.mm`, `Core/NativeCore.swift` | 已实现，主机已测 | 使用 C ABI 桥接 C++17；复制/覆盖使用暂存和回滚；跨卷移动走 EXDEV 回退 |
| 批量重命名 | `Services/FileSystemService.swift`, `UI/Browser/FileBrowserView.swift` | 已实现 | 两阶段暂存与提交，回滚不完整时列出残留路径 |
| 符号链接 | `NativeCore.cpp`, `FileSystemService.swift` | 已实现，主机已测 | 操作链接本身；文件复制不跟随目录链接 |
| POSIX 权限与递归 chmod | `NativeCore.cpp`, `FileSystemService.swift` | 已实现，主机已测 | 失败时恢复此前更改；受文件系统与当前 UID 限制 |
| BSD immutable | `FileSystemService.swift`, `RootHelper/main.cpp` | 已实现，未真机验证 | 只改 `UF_IMMUTABLE` 位；不尝试受限的 system immutable |
| 扩展属性 | `NativeCore.cpp`, `FileDetailsView.swift` | 已实现，主机已测 | 查看、Base64 添加/修改/删除；权限与文件系统可能拒绝 |
| 文件元数据、哈希、挂载信息 | `FileMetadataService.swift`, `MountCatalog.swift` | 已实现 | 哈希分块读取；挂载页只读展示系统 mount table |
| 回收站、恢复、永久删除 | `FileSystemService.swift`, `RecycleBinService.swift` | 已实现 | 永久删除/介质错误可能导致部分清理，失败会报告路径 |
| RootHelper PTY | `RootProcessBridge.mm`, `RootHelper/main.cpp` | 已实现，主机已测 | PTY 交互与文件 RPC 分离；root persona 需真机确认 |
| RootHelper 类型化文件 RPC | `NativeCore.swift`, `RootProcessBridge.mm`, `RootHelper/main.cpp` | 已实现，主机已测 | 白名单参数，不接受任意 shell RPC；要求有效 root EUID，失败不伪装提权 |
| 收藏与分组 | `FavoritesStore.swift`, `FavoritesView.swift` | 已实现 | 分组持久化、旧数据迁移、重命名、移动与删除分组 |
| 收藏和最近目录安全书签 | `FavoritesStore.swift`, `FileBrowserView.swift` | 已实现，未真机验证 | 检查书签目标仍存在且为文件夹；外部文件提供器跨重启行为需设备验证 |
| ZIP | `ArchiveCore.cpp`, `ArchiveService.swift`, `ArchiveBrowserView.swift` | 已实现，主机已测 | 列表、普通创建、解压；可选 SSZipArchive 密码创建/解压；加密路径额外校验 |
| 7z | 同上 | 已实现，主机已测 | 列表、创建、解压；具体压缩算法依赖集成 libarchive 编译能力 |
| TAR / TGZ / TBZ2 / TXZ | 同上 | 已实现，主机已测 | PAX TAR，gzip/bzip2/xz 过滤器；保留空目录与安全相对符号链接 |
| 裸 GZ / BZ2 / XZ | 同上 | 已实现，主机已测 | 只接受单个普通文件；解压后文件名由归档名决定 |
| CPIO / ISO 9660 | 同上 | 已实现，主机已测 | 列表、创建、解压；ISO 合成根目录项会安全跳过 |
| RAR / RAR5 / CAB / AR（含 DEB 外层） | 同上 | 读取/解压 | 不创建 RAR/CAB；DEB 作为 ar 外层展开，不自动安装软件包 |
| 归档安全 | `ArchiveCore.cpp`, `ArchiveService.swift` | 已实现，主机已测 | 路径穿越、绝对路径、重复/大小写冲突、父子冲突、越界符号链接、特殊文件、硬链接目标、条目数和实际解压字节上限检查；staging 成功后提交 |
| XML/Binary Plist 编辑 | `PlistNode.swift`, `PlistEditorView.swift` | 已实现，往返测试通过 | 保留原始 plist 编码类型；非法值保存时报错 |
| 文本/JSON、HEX、CSV/TSV 编辑 | 对应 `UI/Editors` 视图 | 基础功能已实现 | 不等同完整 IDE/电子表格；存在文件大小与分页限制 |
| 图片、音视频、Quick Look | `MediaPreviewViews.swift` | 已实现 | 支持范围取决于系统解码器/预览提供器 |
| JavaScript `.js` | `ScriptLibrary.swift`, `ScriptRuntimeBridge.mm` | 已实现 | JavaScriptCore 经典脚本；非 Node.js |
| CommonJS `.cjs` | `ScriptLibrary.swift` | 已实现 | JavaScriptCore 内本地相对模块子集；不支持 npm、Node 内置模块、原生扩展和进程 API |
| ES Module `.mjs` | `ScriptRuntimeBridge.mm`, `ScriptLibrary.swift` | 条件运行 | 使用设备已安装的 Node.js；无 Node.js 时明确显示不可用 |
| Shell `.sh` / `.command` | `ScriptRuntimeBridge.mm` | 已实现 | `/bin/sh`；外部进程执行受目标系统策略限制 |
| Bash `.bash` | 同上 | 条件运行 | 设备必须安装 Bash |
| Python `.py` / `.pyw` | 同上、`Makefile` | 可选嵌入 | macOS/Xcode 执行 `make python-runtime` 构建并暂存 BeeWare CPython 3.13；源码包不内置解释器二进制 |
| Lua / Ruby / Perl / AWK / PHP / R / Tcl | 同上 | 条件运行 | 探测越狱常见路径及 PATH；设备必须安装对应解释器 |
| iOS SDK 构建、IPA 签名与 TrollStore 安装 | `Makefile` | 构建脚本已提供，当前环境未验证 | 本容器无 Xcode/iOS SDK/目标设备，未声称已生成可安装 IPA |

## C++ / Swift 混编架构

```text
SwiftUI
  └─ Swift Services / Models
      ├─ NativeCore.swift
      │   └─ NativeCoreBridge.h / NativeCoreBridge.mm
      │       └─ NativeCore.hpp / NativeCore.cpp
      ├─ ArchiveService.swift
      │   └─ ArchiveCoreBridge.h / ArchiveCore.cpp
      └─ ScriptLibrary.swift
          └─ ScriptRuntimeBridge.h / ScriptRuntimeBridge.mm

RootProcessBridge.mm ── PTY / typed RootHelper RPC
```

Swift 不持有 C++ 类、模板或 STL 对象。公开边界采用 C ABI；Objective-C++ 只负责必要的跨语言适配。C++17 实现文件由 Xcode Sources build phase 编译。

## 回归测试

```sh
make smoke
```

包含 Plist XML/Binary 往返、NativeCore 文件操作、归档格式往返和安全拒绝、脚本桥接、Swift 前端语法解析、工程注册检查、RootHelper PTY 与类型化 RPC。
