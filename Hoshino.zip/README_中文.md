# Hoshino 1.5 — TrollStore 专用本地文件管理器

Hoshino 是 SwiftUI + Objective-C++ + C++17 混合实现的 iOS 文件管理器。Swift 管理 UI、状态和文件提供器授权；Objective-C++ 提供 C/Swift 桥接；C++17 负责文件系统与归档底层。工程不向 Swift 暴露 C++ 类或 STL 类型。

## 功能

### 文件管理

- 列表/网格、名称/日期/大小/类型/扩展名/创建时间排序、隐藏文件显示；支持递归搜索、按扩展名/类型/路径/大小/修改日期筛选、正则文件名和小型文本文件内容搜索。
- 新建、重命名、复制、剪切、粘贴、批量重命名、符号链接；同名文件夹可递归合并，冲突文件自动保留两份。
- 覆盖复制暂存旧目标；跨卷移动使用复制后提交；失败时尝试回滚并报告残留路径。文件夹合并逐项报告失败项，发生失败时保留完整源文件夹；合并成功后先原子重命名源文件夹，再执行清理。
- 回收站、恢复、永久删除、递归权限管理、BSD immutable、扩展属性编辑。
- 文件元数据、容量、MD5/SHA-1/SHA-256、挂载点只读信息；目录用量分析可汇总文件/目录/符号链接、按扩展名统计、列出最大文件，并对硬链接只计一次实际占用。
- 重复文件查找先按大小缩小候选集，再流式计算 SHA-256；不把硬链接别名误判成重复副本。清理操作只能移入 Hoshino 废纸篓，不直接永久删除。
- 多文件复制、移动、删除支持进度和逐项失败报告；单项失败不会阻断后续项目，可在当前文件完成后停止剩余队列。
- 收藏夹分组与安全书签；最近打开目录书签恢复。
- 应用启动时尝试启动应用私有的常驻 RootHelper 子进程；文件操作复用类型化 RPC，进程退出时由 socketpair EOF 自动结束，不创建 launchd 注册。RPC 使用操作白名单并验证 root EUID，不接受任意 shell 命令。
- APFS 同卷复制优先尝试 Copy-on-Write clone，跨卷或不支持的文件系统自动回退普通复制；目录列表直接使用 `lstat` 时间戳，减少逐项资源读取。
- 文件类型图标统一由扩展名映射：目前有 **163 个唯一 Hoshino 图标资源**、**153 个映射图标类型**，覆盖 **367 种扩展名**，包括图像/RAW/矢量/3D、音视频与编码格式、Office/电子书/邮件、配置/标记语言、主流编程语言、压缩格式、系统二进制、数据库、证书和安装包。全部文件类型视图直接加载 Assets 图标，不调用 SF Symbols 或 UIKit 系统文件图标；未知格式也使用项目自带的 `FileIcon_generic` 图像。
- 图标资源可通过 `Tools/generate_file_type_icons.py` 重新生成新增的矢量格式图标（需 Python `cairosvg`）；运行时不依赖该脚本。

### 搜索语法

搜索会递归遍历当前授权根目录，不跟随符号链接。支持以下单条件查询：

| 示例 | 含义 |
|---|---|
| `name:SpringBoard` 或普通关键字 | 文件名包含文本 |
| `path:MobileSubstrate` | 完整路径包含文本 |
| `.dylib` / `ext:plist` | 精确扩展名 |
| `type:image` / `type:font` / `type:certificate` | 按文件类型筛选 |
| `size>10MB` / `size<512KB` | 按文件大小筛选，支持 B/KB/MB/GB/TB |
| `date>2026-01-01` / `modified<2026-11-01` | 按修改日期筛选 |
| `re:^Spring.*\.plist$` | 使用正则匹配文件名 |
| `content:CFBundleIdentifier` | 搜索 UTF-8 小型文本文件内容（单文件上限 2 MiB） |

重复文件分析最多检查 30,000 个目录项，先按大小和首尾数据块筛选，再对候选项计算完整 SHA-256；适合用来找出内容完全相同的文件。目录用量分析最多读取 500,000 个目录项，超过上限会明确标注统计不完整。

### 归档

归档核心由 libarchive 提供，Xcode 工程集成 iOS 静态 XCFramework。当前能力：

| 格式 | 列表 | 创建 | 解压 |
|---|---:|---:|---:|
| ZIP | 是 | 是 | 是 |
| 加密 ZIP | 是 | 是 | 是 |
| 7z | 是 | 是 | 是 |
| TAR / TGZ / TBZ2 / TXZ | 是 | 是 | 是 |
| 单文件 GZ / BZ2 / XZ | 是 | 是 | 是 |
| CPIO | 是 | 是 | 是 |
| ISO 9660 | 是 | 是 | 是 |
| RAR / RAR5 | 是 | 否 | 是（取决于具体变体/加密方式） |
| CAB | 是 | 否 | 是 |
| AR / DEB 外层 | 是 | 否 | 是（展开容器，不安装软件包） |

安全措施包括路径穿越和绝对路径拒绝、重复/大小写冲突检测、文件目录父子冲突检查、越界符号链接与特殊文件拒绝、硬链接目标限制、条目数量和实际解压字节上限、临时目录解压及提交。加密 ZIP 为兼容第三方后端，保守拒绝符号链接、特殊节点、空目录和冲突名称。

### 编辑器与预览

| 编辑器/查看器 | 能力 |
|---|---|
| Plist | XML/Binary 自动识别，树形增删改，保留原始编码格式 |
| 文本/JSON | UTF-8、UTF-16、Latin-1 读取，查找、JSON 格式化、保存和基础着色 |
| HEX | 分页查看/编辑、地址跳转、字节模式搜索 |
| CSV/TSV | 基础表格解析与单元格、行列编辑 |
| 图片/音视频 | 系统解码与 AVFoundation 播放 |
| Quick Look | 使用系统预览提供器 |

文本/HEX/CSV 编辑器不是完整 IDE 或 Excel 替代品，均设有内存或分页限制。

### 脚本运行时

- `.js`：JavaScriptCore 经典脚本。
- `.cjs`：限定在脚本目录内的本地 CommonJS 子集，不支持 npm、Node 内置模块、原生扩展和进程 API。
- `.mjs`：设备安装 Node.js 时运行；未安装时标记不可运行。
- `.sh` / `.command`：`/bin/sh`；`.bash`：需要设备安装 Bash。
- `.py` / `.pyw`：可选内嵌 CPython 3.13，需在 macOS/Xcode 执行 `make python-runtime`。
- Lua、Ruby、Perl、AWK、PHP、R、Tcl：检测设备是否安装对应命令行解释器后运行。

外部解释器使用 `posix_spawn`、收集 stdout/stderr、超时后终止进程组。TrollStore 版本拥有更大的文件访问能力，执行不可信脚本可能破坏系统文件；只运行可信代码。

## 混编结构

```text
SwiftUI
  └─ Swift Services / Models
      ├─ NativeCore.swift
      │   └─ NativeCoreBridge.h / NativeCoreBridge.mm
      │       └─ NativeCore.hpp / NativeCore.cpp
      ├─ ArchiveService.swift
      │   └─ ArchiveCoreBridge.h / ArchiveCore.cpp
      └─ ScriptLibrary.swift
          └─ ScriptRuntimeBridge.h / ScriptRuntimeBridge.mm

RootProcessBridge.mm ── PTY / RootHelper RPC
```

## TrollStore 权限模型

生产 Entitlements 只保留已验证且与目标直接相关的项目：`com.apple.private.security.no-sandbox`、`com.apple.private.security.storage.AppDataContainers`、`com.apple.private.persona-mgmt` 和 `platform-application`。`Info.plist` 的 `TSRootBinaries` 登记包内 `RootHelper`；应用在启动时通过 persona API 请求 root 子进程，普通文件操作仅在收到 `EPERM/EACCES` 后回退到该 Helper。

Helper 是应用子进程，不是 launchd daemon。父应用被系统终止或用户强制退出后，socketpair 自动关闭，Helper 读取到 EOF 后退出；单纯切到后台不等于应用进程关闭。TrollStore 公开文档指出，真正注册 launchd daemon 需要 `CS_PLATFORMIZED`，普通 TrollStore 应用无法获得该能力。

`system-application` 与 `com.apple.private.security.system-application` 未在 TrollStore 文档中列为可用的提权 Entitlement。TrollStore 中显示为 System app 的状态属于应用注册/持久化状态，不应当与签名 Entitlement 混淆。为便于你在测试设备验证，项目单独提供 `TrollStore.experimental-system-application.entitlements`，仅实验配置包含这两个未验证键；生产构建不会使用它们。可用以下命令单独构建测试包：

```sh
make ipa ENTITLEMENTS=Hoshino/Entitlements/TrollStore.experimental-system-application.entitlements IPA_NAME=Hoshino-system-application
```

即使该测试包能够安装，也不代表系统承认这两个键或授予额外文件权限；必须在真机检查实际 entitlement 字典、进程 UID、目录访问结果和启动稳定性。

## 构建与测试

需要 macOS、Xcode、iOS SDK，以及 Swift Package Manager 网络依赖。

```sh
make resolve
make build             # Release arm64 .app，关闭 Xcode 自动签名
make python-runtime    # 可选：构建并暂存 CPython 3.13
make ipa               # 需要 ldid，生成 TrollStore/越狱 IPA
make smoke             # 当前主机可运行的自动化测试
make clean
```

`make smoke` 覆盖 Plist XML/Binary 往返、C++ 文件核心、归档多格式往返/安全拒绝、脚本桥接、Swift 源码语法解析、Xcode 工程注册、RootHelper PTY、类型化 RPC 和常驻 Helper 连续请求/EOF 退出。

## 验证边界

本轮在 Linux 主机执行 `make smoke` 全部通过。但当前环境没有 macOS、Xcode、Apple iOS SDK、模拟器或 TrollStore 设备，因此没有执行 iOS SDK 编译链接、IPA 签名、真机安装、root persona、外部文件提供器授权或完整 UI 验收。主机测试通过不能等同真机通过。详细记录见 `IMPLEMENTATION_STATUS_2026-11-20.md` 和 `FUNCTION_MATRIX.md`。
