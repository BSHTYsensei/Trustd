#include <algorithm>
#include <cerrno>
#include <cctype>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <set>
#include <string>
#include <vector>
#include <cstdint>
#include <filesystem>
#include <limits>
#include <utility>
#include "../Hoshino/Core/NativeCore.hpp"
#include <sys/ioctl.h>
#include <sys/stat.h>
#include <termios.h>
#include <unistd.h>
#include <sys/socket.h>
#include <arpa/inet.h>

extern char **environ;

static std::string argValue(int argc, char **argv, const char *key, const char *fallback = "") {
    for (int i = 1; i + 1 < argc; ++i) {
        if (std::strcmp(argv[i], key) == 0) return argv[i + 1];
    }
    return fallback;
}

static bool hasFlag(int argc, char **argv, const char *flag) {
    for (int i = 1; i < argc; ++i) if (std::strcmp(argv[i], flag) == 0) return true;
    return false;
}

static std::string shellQuote(const std::string &value) {
    std::string out = "'";
    for (char c : value) {
        if (c == '\'') out += "'\\''";
        else out += c;
    }
    out += "'";
    return out;
}

static bool executable(const char *path) {
    return path && access(path, X_OK) == 0;
}

static std::vector<std::string> discoverOptions(const std::string &path) {
    std::vector<std::string> result;
    FILE *file = std::fopen(path.c_str(), "rb");
    if (!file) return result;
    constexpr size_t kMaxRead = 8 * 1024 * 1024;
    std::vector<unsigned char> bytes(kMaxRead);
    const size_t count = std::fread(bytes.data(), 1, bytes.size(), file);
    std::fclose(file);

    std::set<std::string> unique;
    for (size_t i = 0; i + 2 < count; ++i) {
        if (bytes[i] != '-') continue;
        size_t start = i;
        size_t cursor = i;
        if (bytes[cursor + 1] == '-') {
            cursor += 2;
            if (!std::isalpha(bytes[cursor])) continue;
            while (cursor < count && (std::isalnum(bytes[cursor]) || bytes[cursor] == '-' || bytes[cursor] == '_')) ++cursor;
            if (cursor - start >= 3 && cursor - start <= 72) {
                unique.emplace(reinterpret_cast<const char *>(bytes.data() + start), cursor - start);
                i = cursor - 1;
            }
        } else if (std::isalpha(bytes[cursor + 1])) {
            // Collect compact short-option tokens only when they look like -x or -X.
            const bool boundary = (i == 0) || !(std::isalnum(bytes[i - 1]) || bytes[i - 1] == '_');
            const bool end = (i + 2 >= count) || !(std::isalnum(bytes[i + 2]) || bytes[i + 2] == '_');
            if (boundary && end) unique.emplace(reinterpret_cast<const char *>(bytes.data() + start), 2);
        }
        if (unique.size() >= 96) break;
    }
    result.assign(unique.begin(), unique.end());
    return result;
}

static void ensureControllingTerminal() {
    if (!isatty(STDIN_FILENO)) return;

    // openpty() gives us a slave descriptor, not necessarily a controlling TTY.
    // Attach it only when this process has no controlling terminal yet. This is
    // important for the su fallback: su may already own the PTY session, and a
    // second setsid()/TIOCSCTTY attempt would detach or contend with that session.
    const pid_t terminalSession = tcgetsid(STDIN_FILENO);
    if (terminalSession < 0) {
        if (getsid(0) != getpid() && setsid() < 0) {
            dprintf(STDERR_FILENO, "[Hoshino] setsid failed: %s\r\n", std::strerror(errno));
            return;
        }
        if (ioctl(STDIN_FILENO, TIOCSCTTY, 0) != 0 && errno != EBUSY) {
            dprintf(STDERR_FILENO, "[Hoshino] TIOCSCTTY failed: %s\r\n", std::strerror(errno));
        }
    }
    if (tcsetpgrp(STDIN_FILENO, getpgrp()) != 0) {
        dprintf(STDERR_FILENO, "[Hoshino] tcsetpgrp failed: %s\r\n", std::strerror(errno));
    }
}

static void printBanner(const std::string &target) {
    const uid_t uid = getuid();
    const uid_t euid = geteuid();
    const gid_t gid = getgid();
    const gid_t egid = getegid();
    dprintf(STDOUT_FILENO,
            "\r\n[Hoshino] uid=%u euid=%u gid=%u egid=%u\r\n",
            static_cast<unsigned>(uid), static_cast<unsigned>(euid),
            static_cast<unsigned>(gid), static_cast<unsigned>(egid));
    dprintf(STDOUT_FILENO, "[Hoshino] target binary: %s\r\n", target.c_str());
    dprintf(STDOUT_FILENO, "[Hoshino] run it explicitly with: \"$HOSHINO_TARGET\" <option>\r\n");
    dprintf(STDOUT_FILENO, "[Hoshino] option hints below are extracted from printable strings; they are not a complete or verified command reference.\r\n");
    const auto options = discoverOptions(target);
    if (options.empty()) {
        dprintf(STDOUT_FILENO, "[Hoshino] no option strings were detected (the binary may be stripped or use subcommands).\r\n");
    } else {
        dprintf(STDOUT_FILENO, "[Hoshino] detected option hints:\r\n");
        for (const auto &option : options) dprintf(STDOUT_FILENO, "  %s\r\n", option.c_str());
    }
    dprintf(STDOUT_FILENO, "[Hoshino] The selected executable is not run automatically. Type its path and an option when ready.\r\n\r\n");
}

static bool tryJailbreakSUArguments(const std::string &self,
                                    const std::vector<std::string> &arguments) {
    const char *candidates[] = {"/var/jb/usr/bin/su", "/usr/bin/su", "/bin/su", nullptr};
    const char *suPath = nullptr;
    for (int i = 0; candidates[i]; ++i) {
        if (executable(candidates[i])) { suPath = candidates[i]; break; }
    }
    if (!suPath) return false;

    // All arguments are individually shell-quoted. This allows non-interactive,
    // passwordless jailbreak su configurations to service typed RPC requests;
    // interactive authorization remains available through the PTY mode.
    std::string command = shellQuote(self);
    for (const auto &argument : arguments) command += " " + shellQuote(argument);
    char *const args[] = {
        const_cast<char *>(suPath),
        const_cast<char *>("root"),
        const_cast<char *>("-c"),
        const_cast<char *>(command.c_str()),
        nullptr
    };
    execv(suPath, args);
    dprintf(STDERR_FILENO, "[Hoshino] su RPC elevation failed: %s\n", std::strerror(errno));
    return false;
}

static void tryJailbreakSU(const std::string &self,
                           const std::string &cwd,
                           const std::string &target) {
    const char *candidates[] = {"/var/jb/usr/bin/su", "/usr/bin/su", "/bin/su", nullptr};
    const char *suPath = nullptr;
    for (int i = 0; candidates[i]; ++i) {
        if (executable(candidates[i])) { suPath = candidates[i]; break; }
    }
    if (!suPath) return;

    // Use the system/jailbreak su authorization path; never change ownership,
    // file mode, launchd jobs, or kernel state to obtain privileges.
    const std::string command = shellQuote(self) + " --root-session --cwd " + shellQuote(cwd) + " --target " + shellQuote(target);
    char *const args[] = {
        const_cast<char *>(suPath),
        const_cast<char *>("root"),
        const_cast<char *>("-c"),
        const_cast<char *>(command.c_str()),
        nullptr
    };
    execv(suPath, args);
}


static bool decodeBase64(const std::string &encoded, std::vector<unsigned char> &decoded) {
    static const std::string alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    if (encoded.size() % 4 != 0) return false;
    decoded.clear();
    decoded.reserve((encoded.size() / 4) * 3);
    for (size_t i = 0; i < encoded.size(); i += 4) {
        unsigned int value = 0;
        unsigned int padding = 0;
        for (size_t j = 0; j < 4; ++j) {
            const char c = encoded[i + j];
            if (c == '=') {
                ++padding;
                if (j < 2 || (i + 4 != encoded.size())) return false;
                value <<= 6;
            } else {
                if (padding) return false;
                const size_t position = alphabet.find(c);
                if (position == std::string::npos) return false;
                value = (value << 6) | static_cast<unsigned int>(position);
            }
        }
        if (padding > 2) return false;
        decoded.push_back(static_cast<unsigned char>((value >> 16) & 0xff));
        if (padding < 2) decoded.push_back(static_cast<unsigned char>((value >> 8) & 0xff));
        if (padding < 1) decoded.push_back(static_cast<unsigned char>(value & 0xff));
    }
    return true;
}


static int setImmutableFlags(const std::string &rootPath, bool enabled, bool recursive, bool linkItself) {
#ifdef __APPLE__
    namespace fs = std::filesystem;
    struct Previous { fs::path path; unsigned long flags; bool symlink; };
    std::vector<Previous> nodes;
    struct stat rootStat = {};
    const int rootResult = linkItself ? lstat(rootPath.c_str(), &rootStat) : stat(rootPath.c_str(), &rootStat);
    if (rootResult != 0) return errno;
    nodes.push_back({fs::path(rootPath), static_cast<unsigned long>(rootStat.st_flags), (rootStat.st_mode & S_IFMT) == S_IFLNK});
    if (recursive && S_ISDIR(rootStat.st_mode) && !(rootStat.st_mode & S_IFLNK)) {
        std::error_code error;
        fs::recursive_directory_iterator iterator(rootPath, fs::directory_options::none, error), end;
        if (error) return error.value();
        for (; iterator != end; iterator.increment(error)) {
            if (error) return error.value();
            struct stat itemStat = {};
            const int rc = linkItself ? lstat(iterator->path().c_str(), &itemStat) : stat(iterator->path().c_str(), &itemStat);
            if (rc != 0) return errno;
            nodes.push_back({iterator->path(), static_cast<unsigned long>(itemStat.st_flags), (itemStat.st_mode & S_IFMT) == S_IFLNK});
        }
    }
    std::stable_sort(nodes.begin(), nodes.end(), [enabled](const Previous &a, const Previous &b) {
        return enabled ? a.path.native().size() > b.path.native().size() : a.path.native().size() < b.path.native().size();
    });
    std::vector<Previous> changed;
    for (const auto &node : nodes) {
        const unsigned long flags = enabled ? (node.flags | UF_IMMUTABLE) : (node.flags & ~static_cast<unsigned long>(UF_IMMUTABLE));
        const int rc = linkItself && node.symlink ? lchflags(node.path.c_str(), flags) : chflags(node.path.c_str(), flags);
        if (rc != 0) {
            const int failure = errno;
            for (auto it = changed.rbegin(); it != changed.rend(); ++it) {
                if (linkItself && it->symlink) (void)lchflags(it->path.c_str(), it->flags);
                else (void)chflags(it->path.c_str(), it->flags);
            }
            return failure;
        }
        changed.push_back(node);
    }
    return 0;
#else
    (void)rootPath; (void)enabled; (void)recursive; (void)linkItself;
    return ENOTSUP;
#endif
}

static int runRPC(int argc, char **argv, std::string *response = nullptr) {
    auto emit = [&](int fd, const std::string &message) {
        if (response) *response = message;
        else dprintf(fd, "%s\n", message.c_str());
    };
    if (geteuid() != 0) {
        emit(STDERR_FILENO, "[Hoshino] RootHelper RPC refused: euid=" + std::to_string(static_cast<unsigned>(geteuid())) + ", root persona is required.");
        return 77;
    }
    const std::string operation = argValue(argc, argv, "--operation");
    hoshino::core::Result result{false, EINVAL, "未知或不完整的 RPC 操作"};
    if (operation == "copy" || operation == "move" || operation == "rename") {
        const std::string source = argValue(argc, argv, "--source");
        const std::string destination = argValue(argc, argv, "--destination");
        const auto kind = operation == "copy" ? hoshino::core::Operation::copy :
                          operation == "move" ? hoshino::core::Operation::move : hoshino::core::Operation::rename;
        result = hoshino::core::transfer(source, destination, kind, hasFlag(argc, argv, "--replace"));
    } else if (operation == "merge-directory") {
        const std::string source = argValue(argc, argv, "--source");
        const std::string destination = argValue(argc, argv, "--destination");
        if (source.empty() || destination.empty()) result = {false, EINVAL, "merge-directory 参数无效"};
        else result = hoshino::core::merge_directory(source, destination, hasFlag(argc, argv, "--move-source"));
    } else if (operation == "chown") {
        const std::string path = argValue(argc, argv, "--path");
        const std::string uidText = argValue(argc, argv, "--uid");
        const std::string gidText = argValue(argc, argv, "--gid");
        char *uidEnd = nullptr;
        char *gidEnd = nullptr;
        errno = 0;
        const unsigned long uid = std::strtoul(uidText.c_str(), &uidEnd, 10);
        const bool uidOK = !uidText.empty() && errno == 0 && uidEnd && *uidEnd == '\0' && uid <= UINT32_MAX;
        errno = 0;
        const unsigned long gid = std::strtoul(gidText.c_str(), &gidEnd, 10);
        const bool gidOK = !gidText.empty() && errno == 0 && gidEnd && *gidEnd == '\0' && gid <= UINT32_MAX;
        if (path.empty() || !uidOK || !gidOK) result = {false, EINVAL, "chown 参数无效；UID/GID 必须是 0–4294967295"};
        else result = hoshino::core::set_owner(path, static_cast<std::uint32_t>(uid), static_cast<std::uint32_t>(gid),
                                               hasFlag(argc, argv, "--recursive"), hasFlag(argc, argv, "--follow"));
    } else if (operation == "chmod") {
        const std::string path = argValue(argc, argv, "--path");
        const std::string modeText = argValue(argc, argv, "--mode");
        char *end = nullptr;
        errno = 0;
        const unsigned long mode = std::strtoul(modeText.c_str(), &end, 8);
        if (path.empty() || modeText.empty() || errno != 0 || !end || *end != '\0' || mode > 07777) {
            result = {false, EINVAL, "chmod 参数无效：mode 必须是 0000–7777 的八进制值"};
        } else {
            result = hoshino::core::set_permissions(path, static_cast<std::uint32_t>(mode),
                                                    hasFlag(argc, argv, "--recursive"),
                                                    hasFlag(argc, argv, "--follow"));
        }
    } else if (operation == "xattr-set") {
        const std::string path = argValue(argc, argv, "--path");
        const std::string name = argValue(argc, argv, "--name");
        const std::string encoded = argValue(argc, argv, "--value-base64");
        std::vector<unsigned char> bytes;
        if (path.empty() || name.empty() || !decodeBase64(encoded, bytes)) {
            result = {false, EINVAL, "xattr-set 参数无效或 Base64 数据损坏"};
        } else {
            result = hoshino::core::set_xattr(path, name, bytes.empty() ? nullptr : bytes.data(), bytes.size(), hasFlag(argc, argv, "--follow"));
        }
    } else if (operation == "xattr-remove") {
        const std::string path = argValue(argc, argv, "--path");
        const std::string name = argValue(argc, argv, "--name");
        if (path.empty() || name.empty()) result = {false, EINVAL, "xattr-remove 参数无效"};
        else result = hoshino::core::remove_xattr(path, name, hasFlag(argc, argv, "--follow"));
    } else if (operation == "mkdir") {
        const std::string path = argValue(argc, argv, "--path");
        result = path.empty() ? hoshino::core::Result{false, EINVAL, "mkdir 操作缺少路径"} : hoshino::core::create_directory(path);
    } else if (operation == "create-file") {
        const std::string path = argValue(argc, argv, "--path");
        result = path.empty() ? hoshino::core::Result{false, EINVAL, "create-file 操作缺少路径"} : hoshino::core::create_file(path);
    } else if (operation == "symlink") {
        const std::string target = argValue(argc, argv, "--target");
        const std::string link = argValue(argc, argv, "--link");
        result = (target.empty() || link.empty()) ? hoshino::core::Result{false, EINVAL, "symlink 参数无效"} : hoshino::core::create_symlink(target, link);
    } else if (operation == "hardlink") {
        const std::string source = argValue(argc, argv, "--source");
        const std::string destination = argValue(argc, argv, "--destination");
        result = (source.empty() || destination.empty()) ? hoshino::core::Result{false, EINVAL, "hardlink 参数无效"} : hoshino::core::create_hardlink(source, destination);
    } else if (operation == "delete") {
        const std::string path = argValue(argc, argv, "--path");
        result = path.empty() ? hoshino::core::Result{false, EINVAL, "delete 操作缺少路径"} : hoshino::core::remove_item(path);
    } else if (operation == "immutable") {
        const std::string path = argValue(argc, argv, "--path");
        if (path.empty()) result = {false, EINVAL, "immutable 操作缺少路径"};
        else {
            const int code = setImmutableFlags(path, hasFlag(argc, argv, "--enabled"),
                                               hasFlag(argc, argv, "--recursive"),
                                               !hasFlag(argc, argv, "--follow"));
            result = code == 0 ? hoshino::core::Result{true, 0, {}} : hoshino::core::Result{false, code, "设置 BSD immutable flags 失败"};
        }
    }

    if (!result.ok) {
        emit(STDERR_FILENO, "[Hoshino] " + result.message + " (errno=" + std::to_string(result.code) + ")");
        return result.code > 0 && result.code < 126 ? result.code : 1;
    }
    emit(STDOUT_FILENO, "[Hoshino] RPC " + operation + " completed successfully.");
    return 0;
}

static bool readExact(int fd, void *buffer, size_t length) {
    auto *bytes = static_cast<unsigned char *>(buffer);
    size_t offset = 0;
    while (offset < length) {
        const ssize_t count = read(fd, bytes + offset, length - offset);
        if (count > 0) { offset += static_cast<size_t>(count); continue; }
        if (count < 0 && errno == EINTR) continue;
        return false;
    }
    return true;
}

static bool writeExact(int fd, const void *buffer, size_t length) {
    const auto *bytes = static_cast<const unsigned char *>(buffer);
    size_t offset = 0;
    while (offset < length) {
        const ssize_t count = write(fd, bytes + offset, length - offset);
        if (count > 0) { offset += static_cast<size_t>(count); continue; }
        if (count < 0 && errno == EINTR) continue;
        return false;
    }
    return true;
}

static int runPersistentServer(int fd) {
    constexpr uint32_t kMaxArguments = 64;
    constexpr uint32_t kMaxArgumentBytes = 1024 * 1024;
    constexpr uint32_t kMaxRequestBytes = 4 * 1024 * 1024;
    constexpr uint32_t kMaxResponseBytes = 16 * 1024;

    uint32_t ready = htonl(geteuid() == 0 ? 0u : 77u);
    if (!writeExact(fd, &ready, sizeof(ready))) return 74;
    if (geteuid() != 0) return 77;

    for (;;) {
        uint32_t networkCount = 0;
        if (!readExact(fd, &networkCount, sizeof(networkCount))) return 0; // EOF means the parent app exited.
        const uint32_t count = ntohl(networkCount);
        if (count < 3 || count > kMaxArguments) return 65;

        std::vector<std::string> arguments;
        arguments.reserve(count);
        uint64_t totalBytes = 0;
        bool valid = true;
        for (uint32_t index = 0; index < count; ++index) {
            uint32_t networkLength = 0;
            if (!readExact(fd, &networkLength, sizeof(networkLength))) return 0;
            const uint32_t length = ntohl(networkLength);
            totalBytes += length;
            if (length == 0 || length > kMaxArgumentBytes || totalBytes > kMaxRequestBytes) { valid = false; break; }
            std::string argument(length, '\0');
            if (!readExact(fd, argument.data(), length)) return 0;
            if (argument.find('\0') != std::string::npos) { valid = false; break; }
            arguments.emplace_back(std::move(argument));
        }
        if (!valid || arguments.size() != count || arguments.front() != "--rpc") return 65;

        std::vector<char *> argv;
        argv.reserve(arguments.size() + 1);
        for (auto &argument : arguments) argv.push_back(argument.data());
        argv.push_back(nullptr);

        std::string response;
        const int status = runRPC(static_cast<int>(arguments.size()), argv.data(), &response);
        if (response.size() > kMaxResponseBytes) response.resize(kMaxResponseBytes);
        uint32_t networkStatus = htonl(static_cast<uint32_t>(status));
        uint32_t networkResponseLength = htonl(static_cast<uint32_t>(response.size()));
        if (!writeExact(fd, &networkStatus, sizeof(networkStatus)) ||
            !writeExact(fd, &networkResponseLength, sizeof(networkResponseLength)) ||
            (!response.empty() && !writeExact(fd, response.data(), response.size()))) return 0;
    }
}

int main(int argc, char **argv) {
    if (hasFlag(argc, argv, "--server")) {
        const std::string fdText = argValue(argc, argv, "--fd");
        char *end = nullptr;
        errno = 0;
        const long descriptor = std::strtol(fdText.c_str(), &end, 10);
        if (fdText.empty() || errno != 0 || !end || *end != '\0' || descriptor < 3 || descriptor > 1024) return 64;
        return runPersistentServer(static_cast<int>(descriptor));
    }
    if (hasFlag(argc, argv, "--rpc")) {
        if (geteuid() != 0 && !hasFlag(argc, argv, "--root-session")) {
            const std::string self = (argc > 0 && argv[0]) ? argv[0] : "RootHelper";
            std::vector<std::string> arguments;
            arguments.emplace_back("--root-session");
            for (int index = 1; index < argc; ++index) arguments.emplace_back(argv[index]);
            if (!tryJailbreakSUArguments(self, arguments)) {
                dprintf(STDERR_FILENO, "[Hoshino] RootHelper RPC could not obtain root persona; operation was not run.\n");
                return 77;
            }
            return 127; // execv only returns on failure; defensive fallback.
        }
        return runRPC(argc, argv);
    }

    const std::string cwd = argValue(argc, argv, "--cwd", "/");
    const std::string target = argValue(argc, argv, "--target", "");
    const bool rootSession = hasFlag(argc, argv, "--root-session");

    if (chdir(cwd.c_str()) != 0) chdir("/");

    // Attach the PTY before invoking su so any password/authorization prompt is
    // interactive. The root-session re-entry detects and keeps this same TTY.
    ensureControllingTerminal();

    if (geteuid() != 0 && !rootSession) {
        const std::string self = (argc > 0 && argv[0]) ? argv[0] : "RootHelper";
        tryJailbreakSU(self, cwd, target);
    }

    const bool root = (geteuid() == 0);
    setenv("TERM", "xterm-256color", 1);
    setenv("COLORTERM", "truecolor", 1);
    setenv("PATH", "/var/jb/usr/local/bin:/var/jb/usr/bin:/var/jb/bin:/usr/local/bin:/usr/bin:/bin:/usr/sbin:/sbin", 1);
    setenv("HOSHINO_TARGET", target.c_str(), 1);
    if (root) {
        setenv("HOME", "/var/root", 1);
        setenv("USER", "root", 1);
        setenv("LOGNAME", "root", 1);
    } else {
        setenv("HOME", "/var/mobile", 1);
        setenv("USER", "mobile", 1);
        setenv("LOGNAME", "mobile", 1);
        dprintf(STDOUT_FILENO, "[Hoshino] RootHelper did not receive root persona and no authorized su session was completed; continuing with current UID.\r\n");
    }

    const char *shellCandidates[] = {"/var/jb/bin/zsh", "/var/jb/usr/bin/zsh", "/bin/zsh", "/bin/sh", nullptr};
    const char *shell = "/bin/sh";
    for (int i = 0; shellCandidates[i]; ++i) {
        if (executable(shellCandidates[i])) { shell = shellCandidates[i]; break; }
    }
    setenv("SHELL", shell, 1);
    ensureControllingTerminal();
    printBanner(target);

    char *const shellArgs[] = {const_cast<char *>(shell), const_cast<char *>("-i"), nullptr};
    execve(shell, shellArgs, environ);
    dprintf(STDERR_FILENO, "[Hoshino] execve(%s) failed: %s\r\n", shell, std::strerror(errno));
    return 127;
}
