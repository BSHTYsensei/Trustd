# Hoshino 完整性修订记录（2026-11-20）

本文件记录本轮对 Hoshino 的真实源码修改、测试及验证边界。不存在“为了让表格全绿而把外部依赖标成内置”的处理。

## 本轮完成的修改

### 1. 归档核心接入与格式覆盖

- Xcode 工程包含 `ArchiveCore.cpp` 源文件、`ArchiveCoreBridge.h` 桥接头及 `libarchive` SPM 静态 XCFramework 产品依赖；补齐 `iconv`、`xml2`、`pthread` 系统链接项。归档依赖面向 iOS 15+；依赖包说明其为 iOS 静态 XCFramework，并要求这三个系统库。参考：libarchive-for-swift 项目文档及 Package.swift。 
- C++ 归档核心通过 libarchive 完成 ZIP、7z、PAX TAR、gzip/bzip2/xz TAR、裸 GZ/BZ2/XZ、CPIO、ISO 9660 的列表、创建与解压。
- 读取/解压覆盖 RAR/RAR5、CAB、AR/DEB 外层。RAR/CAB 是只读能力；DEB 展开为 ar 内容，不是软件安装器。
- 对 ISO 9660 合成根目录 `.` 项做专门跳过，不能把它写入 staging 根目录，也不放宽普通路径校验。
- 归档创建采用 `mkstemp` 唯一临时文件，并用同卷 `link(2)` 做 no-clobber 提交；目标已被并发创建时不会被覆盖。生成目录归档时排除正在生成的目标和临时文件，防止自包含。
- 解压限制路径穿越、绝对路径、控制字符、大小写冲突、文件/目录父子冲突、越界符号链接、特殊文件、非法硬链接目标、条目数量和真实解压字节数。目标先解压到 staging，成功后再提交。
- 加密 ZIP 通过 SSZipArchive 创建/解压，创建端拒绝符号链接、特殊节点、空目录以及重复或大小写冲突路径；解压端先验证归档路径与条目类型，完成后再次检查实际文件类型、条目数和真实文件字节数。
- 加密创建能力只对 ZIP 开放。7z/RAR 密码是读取/解压输入，不再错误显示为支持密码创建。

### 2. 脚本执行

- `.js` 使用 JavaScriptCore 经典脚本；`.cjs` 使用限定在脚本目录内的本地 CommonJS 子集；禁止 Node 内置模块、npm 包、原生扩展和进程 API。
- `.mjs` 改为通过设备上实际探测到的 Node.js 运行；无 Node 时显示不可用。没有把经典 JSCore 求值器冒充为 ES Module 运行时。
- `.sh`/`.command` 使用 `/bin/sh`；Bash 以及 Lua、Ruby、Perl、AWK、PHP、R、Tcl、Node 通过越狱环境路径与 `PATH` 探测。没有安装对应解释器就只保留导入与保存，不宣称运行。
- 外部解释器由 `posix_spawn` 启动，stdout/stderr 合并收集、执行超时 120 秒并清理进程组。JavaScriptCore 的控制台输出限制为 1 MiB。
- Python 是可选的内嵌 CPython 3.13：`make python-runtime` 在 macOS/Xcode 环境构建 BeeWare Python-Apple-support，并检查 device/simulator slices，再将 `Python.xcframework` 暂存给工程的 Embed Python Runtime build phase。源码包不包含体积很大的 Python 二进制。

### 3. 收藏与最近目录

- 收藏只允许保存当前可访问的目录，书签解析后检查目标存在且仍为目录。
- 外部安全范围 URL 在读取/校验期间启动 security-scoped access，并在函数返回或错误路径释放临时访问。
- 最近目录书签恢复时先请求文件提供器授权，再验证目录仍然存在；过期或撤销授权显示明确提示，不静默把失效路径当作正常目录。

### 4. C++ / Swift 混编与 RootHelper

- 文件操作链：SwiftUI → Swift Facade → C ABI → Objective-C++ bridge → C++17 NativeCore。
- 归档链：Swift ArchiveService → C ABI → C++ libarchive 核心。
- RootHelper 继续保持类型化白名单 RPC，不接受任意 shell 文本；仅当用户打开权限重试选项且普通操作返回权限错误时尝试 RootHelper。RootHelper 对 RPC 强制检查 `geteuid()==0`。
- PTY 交互与文件 RPC 是不同协议。没有 root persona 时不会把普通 UID 的成功启动说成获得 root 权限。

### 打包完善

- `make ipa` 对主程序、RootHelper、可选 Python.framework 及 `.so`/`.dylib` 扩展模块签名；归档生成后执行 `unzip -tq` 完整性检查。该打包流程已加入工程完整性自动检查，尚未在本环境执行，因为缺少 Xcode 与 ldid。

## 验证结果

本轮实际执行 `make smoke`，全部通过：

- Plist XML/Binary 往返；
- NativeCore C++ 文件操作；
- ArchiveCore ZIP/TAR/TGZ/TBZ2/TXZ/7z/CPIO/ISO 9660/GZ/BZ2/XZ 创建、列举、解压往返；
- 归档符号链接、空目录、恶意路径穿越、父子冲突、大小写碰撞、自归档问题检查；
- Shell/脚本桥接与 AWK（运行环境存在时）；Node `.mjs` 测试在 Node 可用时执行；
- 全部 Swift 源文件前端语法解析；
- Xcode 工程注册检查；
- RootHelper PTY；
- RootHelper 类型化 RPC。

归档测试实际发现并修复了 ISO 9660 根目录 `.` 元数据项导致的拒绝问题，之后重新运行通过。

## 当前不能在该环境完成的验证

1. 当前执行容器不是 macOS，缺少 Xcode、Apple iOS SDK 和 iOS 模拟器，因此不能实际执行 `xcodebuild` 的 iOS 编译/链接，不能验证 Swift/Objective-C++ 在真实 iOS SDK 下的完整类型检查与链接。
2. 没有 TrollStore/iPhone 设备，不能验证私有 persona API、RootHelper 实际 root EUID、文件提供器跨重启授权、`UF_IMMUTABLE`、加密 ZIP 与不同解压器的互操作、UI 工作流和安装持久化。
3. `make python-runtime` 需要 macOS + Xcode + 网络；本轮没有下载或内置 CPython framework。
4. Lua/Ruby/Perl/AWK/PHP/R/Tcl/Node 作为外部解释器由设备安装状态决定。不能在不引入相应运行时二进制的前提下声称这些语言在每台设备都可用。
5. iOS 上 libarchive 的外部程序过滤器受平台进程限制；本实现使用库内置格式/过滤器，不依赖外部 gzip/bzip2/xz 进程。参考 libarchive-for-swift 对 iOS 外部进程过滤限制的说明。

因此，本轮已完成当前源码可实现的剩余功能并修复测试发现的问题；**iOS 目标构建和 TrollStore 真机验收仍是外部环境步骤，不应伪称已经通过。**

## 重复执行

```sh
make smoke
```

macOS/Xcode 环境下：

```sh
make resolve
make build
# 可选：构建并嵌入 CPython 3.13
make python-runtime
make build
# 需要 ldid 才能生成 TrollStore IPA
make ipa
```
