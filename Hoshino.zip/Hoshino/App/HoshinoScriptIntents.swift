import AppIntents
import Foundation

@available(iOS 16.0, *)
struct RunSelectedHoshinoScriptsIntent: AppIntent {
    static var title: LocalizedStringResource = "运行 Hoshino 已选脚本"
    static var description = IntentDescription("按顺序执行 Hoshino 脚本管理器中已勾选且具备运行器的脚本。")
    static var openAppWhenRun = true
    func perform() async throws -> some IntentResult & ReturnsValue<String> {
        let results = await ScriptLibrary.shared.runSelected()
        let summary = results.map { "[\($0.0)]\n\($0.1)" }.joined(separator: "\n\n")
        return .result(value: summary.isEmpty ? "没有勾选可执行脚本。" : summary)
    }
}

@available(iOS 16.0, *)
struct HoshinoShortcuts: AppShortcutsProvider {
    static var appShortcuts: [AppShortcut] {
        AppShortcut(intent: RunSelectedHoshinoScriptsIntent(), phrases: ["运行 Hoshino 已选脚本", "执行 Hoshino 脚本"], shortTitle: "运行脚本", systemImageName: "play.fill")
    }
}
