import SwiftUI

@main
struct HoshinoApp: App {
    init() {
        // Keep one app-scoped helper process alive while Hoshino is alive.
        // The socketpair closes automatically on process termination, so the helper exits.
        DispatchQueue.global(qos: .utility).async {
            RootHelperService.startIfNeeded()
        }
    }

    var body: some Scene {
        WindowGroup { ContentView() }
    }
}
