import SwiftUI

struct ContentView: View {
    @AppStorage("Hoshino.UseDarkAppearance") private var useDarkAppearance = false
    @AppStorage("Hoshino.ThemePalette") private var themePalette = "ocean"
    private var accent: Color { switch themePalette { case "mint": return Color(red: 0.22, green: 0.68, blue: 0.57); case "lavender": return Color(red: 0.52, green: 0.46, blue: 0.82); case "coral": return Color(red: 0.91, green: 0.42, blue: 0.38); default: return Color(red: 0.30, green: 0.62, blue: 0.92) } }

    var body: some View {
        TabView {
            FileBrowserView()
                .tabItem { Label("文件", systemImage: "folder.fill") }
            FavoritesView()
                .tabItem { Label("收藏", systemImage: "star.fill") }
            SearchView()
                .tabItem { Label("搜索", systemImage: "magnifyingglass") }
            HoshinoSettingsView()
                .tabItem { Label("设置", systemImage: "gearshape.fill") }
        }
        .tint(accent)
        .preferredColorScheme(useDarkAppearance ? .dark : .light)
    }
}
