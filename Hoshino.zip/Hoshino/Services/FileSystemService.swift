import Foundation
import Darwin
import CommonCrypto

final class FileSystemService {
    static let shared = FileSystemService()
    private let fm = FileManager.default
    private init() {}

    var appSupport: URL {
        let base = fm.urls(for: .applicationSupportDirectory, in: .userDomainMask).first!
        try? fm.createDirectory(at: base, withIntermediateDirectories: true)
        return base
    }
    var trashURL: URL {
        let url = appSupport.appendingPathComponent("HoshinoTrash", isDirectory: true)
        try? fm.createDirectory(at: url, withIntermediateDirectories: true)
        return url
    }

    func defaultDirectory() -> URL {
        let root = URL(fileURLWithPath: "/", isDirectory: true)
        // TrollStore builds are unsandboxed and should open at the filesystem root.
        // A normal sandboxed install falls back to Documents without surfacing an error.
        if (try? fm.contentsOfDirectory(atPath: root.path)) != nil { return root }
        return fm.urls(for: .documentDirectory, in: .userDomainMask).first
            ?? URL(fileURLWithPath: NSTemporaryDirectory(), isDirectory: true)
    }

    func list(_ directory: URL, showHidden: Bool, sort: HoshinoSort) throws -> [HoshinoFile] {
        let urls = try fm.contentsOfDirectory(at: directory, includingPropertiesForKeys: nil, options: [])
        var items = urls.compactMap(HoshinoFile.read).filter { showHidden || !$0.name.hasPrefix(".") }
        items.sort { lhs, rhs in
            if lhs.isDirectory != rhs.isDirectory { return lhs.isDirectory }
            switch sort {
            case .name:
                let order = lhs.name.localizedStandardCompare(rhs.name)
                return order == .orderedSame ? lhs.url.path < rhs.url.path : order == .orderedAscending
            case .date:
                let left = lhs.modified ?? .distantPast
                let right = rhs.modified ?? .distantPast
                return left == right ? lhs.name.localizedStandardCompare(rhs.name) == .orderedAscending : left > right
            case .size:
                return lhs.size == rhs.size
                    ? lhs.name.localizedStandardCompare(rhs.name) == .orderedAscending
                    : lhs.size > rhs.size
            case .kind, .extensionName:
                let order = lhs.fileExtension.localizedCompare(rhs.fileExtension)
                return order == .orderedSame ? lhs.name.localizedStandardCompare(rhs.name) == .orderedAscending : order == .orderedAscending
            case .created:
                let left = lhs.created ?? .distantPast
                let right = rhs.created ?? .distantPast
                return left == right ? lhs.name.localizedStandardCompare(rhs.name) == .orderedAscending : left > right
            }
        }
        return items
    }

    func validateName(_ name: String) throws {
        let trimmed = name.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty, !trimmed.contains("/"), !trimmed.contains("\0"), trimmed != ".", trimmed != ".." else { throw FileSystemError.invalidName }
    }

    func uniqueDestination(for source: URL, in folder: URL) -> URL {
        let ext = source.pathExtension
        let stem = source.deletingPathExtension().lastPathComponent
        var candidate = folder.appendingPathComponent(source.lastPathComponent)
        var index = 2
        while pathExistsNoFollow(candidate) {
            let name = ext.isEmpty ? "\(stem) \(index)" : "\(stem) \(index).\(ext)"
            candidate = folder.appendingPathComponent(name)
            index += 1
        }
        return candidate
    }

    func createFolder(named name: String, in folder: URL) throws -> URL {
        try validateName(name)
        let target = folder.appendingPathComponent(name, isDirectory: true)
        try NativeCore.createDirectory(target)
        return target
    }

    func createFile(named name: String, in folder: URL) throws -> URL {
        try validateName(name)
        let target = folder.appendingPathComponent(name)
        try NativeCore.createFile(target)
        return target
    }

    func rename(_ source: URL, to newName: String) throws -> URL {
        try validateName(newName)
        try ensureMutable(source)
        let destination = source.deletingLastPathComponent().appendingPathComponent(newName)
        guard source.standardizedFileURL != destination.standardizedFileURL else { throw FileSystemError.sameLocation }
        try NativeCore.transfer(source, to: destination, operation: .rename)
        return destination
    }

    /// Two-phase batch rename: stage every source before committing any destination.
    /// On failure, committed destinations are moved back to staging, then every
    /// staged item is restored. Any failed rollback paths are reported explicitly.
    func batchRename(_ sources: [URL], baseName: String, startAt: Int = 1, preserveExtensions: Bool = true) throws -> [URL] {
        guard !sources.isEmpty else { throw FileSystemError.invalidData("请先选择要重命名的项目。") }
        try validateName(baseName)
        guard startAt >= 0 else { throw FileSystemError.invalidData("起始序号不能小于 0。") }
        let normalized = sources.map { $0.standardizedFileURL }
        guard Set(normalized.map(\.path)).count == normalized.count else { throw FileSystemError.invalidData("选择列表包含重复项目。") }
        let sourcePaths = Set(normalized.map(\.path))
        var destinations: [URL] = []
        for (offset, source) in normalized.enumerated() {
            try ensureMutable(source)
            let suffix = preserveExtensions && !source.pathExtension.isEmpty ? ".\(source.pathExtension)" : ""
            let destination = source.deletingLastPathComponent().appendingPathComponent("\(baseName)\(startAt + offset)\(suffix)")
            guard !destinations.contains(where: { $0.path == destination.path }) else { throw FileSystemError.invalidData("生成了重复目标名称。") }
            if pathExistsNoFollow(destination) && !sourcePaths.contains(destination.path) { throw CocoaError(.fileWriteFileExists) }
            destinations.append(destination)
        }
        let staging = normalized.map { $0.deletingLastPathComponent().appendingPathComponent(".hoshino-rename-\(UUID().uuidString)") }
        var stagedCount = 0
        var committedCount = 0
        do {
            for index in normalized.indices {
                try NativeCore.transfer(normalized[index], to: staging[index], operation: .rename)
                stagedCount += 1
            }
            for index in normalized.indices {
                try NativeCore.transfer(staging[index], to: destinations[index], operation: .rename)
                committedCount += 1
            }
            return destinations
        } catch {
            let originalError = error.localizedDescription
            var recoveryFailures: [String] = []
            if committedCount > 0 {
                for index in (0..<committedCount).reversed() {
                    do { try NativeCore.transfer(destinations[index], to: staging[index], operation: .rename) }
                    catch { recoveryFailures.append("\(destinations[index].path) → 暂存失败：\(error.localizedDescription)") }
                }
            }
            if stagedCount > 0 {
                for index in (0..<stagedCount).reversed() where pathExistsNoFollow(staging[index]) {
                    do { try NativeCore.transfer(staging[index], to: normalized[index], operation: .rename) }
                    catch { recoveryFailures.append("\(staging[index].path) → 原路径恢复失败：\(error.localizedDescription)") }
                }
            }
            if recoveryFailures.isEmpty { throw FileSystemError.invalidData("批量重命名失败，已恢复原文件名。原因：\(originalError)") }
            throw FileSystemError.invalidData("批量重命名失败：\(originalError)。部分回滚未完成，请检查以下暂存文件并手动恢复：\(recoveryFailures.joined(separator: "；"))")
        }
    }

    func copy(_ source: URL, to folder: URL, policy: HoshinoConflictPolicy = .keepBoth) throws -> URL? {
        try ensureMutable(source, allowImmutableSource: true)
        var destination = folder.appendingPathComponent(source.lastPathComponent)
        if pathExistsNoFollow(destination) {
            switch policy {
            case .cancel: return nil
            case .keepBoth: destination = uniqueDestination(for: source, in: folder)
            case .replace:
                try ensureMutable(destination)
            case .merge:
                if source.standardizedFileURL == destination.standardizedFileURL { return source }
                do {
                    try NativeCore.mergeDirectory(source, into: destination, moveSource: false)
                    return destination
                } catch {
                    guard (error as NSError).code == Int(ENOTDIR) else { throw error }
                    destination = uniqueDestination(for: source, in: folder)
                }
            }
        }
        try NativeCore.transfer(source, to: destination, operation: .copy, replace: policy == .replace)
        return destination
    }

    func move(_ source: URL, to folder: URL, policy: HoshinoConflictPolicy = .keepBoth) throws -> URL? {
        try ensureMutable(source)
        if source.deletingLastPathComponent().standardizedFileURL == folder.standardizedFileURL { return source }
        var destination = folder.appendingPathComponent(source.lastPathComponent)
        if pathExistsNoFollow(destination) {
            switch policy {
            case .cancel: return nil
            case .keepBoth: destination = uniqueDestination(for: source, in: folder)
            case .replace:
                try ensureMutable(destination)
            case .merge:
                do {
                    try NativeCore.mergeDirectory(source, into: destination, moveSource: true)
                    return destination
                } catch {
                    guard (error as NSError).code == Int(ENOTDIR) else { throw error }
                    destination = uniqueDestination(for: source, in: folder)
                }
            }
        }
        if source.standardizedFileURL == destination.standardizedFileURL { return source }
        try NativeCore.transfer(source, to: destination, operation: .move, replace: policy == .replace)
        return destination
    }

    func trash(_ source: URL) throws -> URL {
        guard (UserDefaults.standard.object(forKey: "recycleBinEnabled") as? Bool) ?? true else {
            throw FileSystemError.invalidData("回收站已关闭。请在确认后使用永久删除。")
        }
        try ensureMutable(source)
        let id = UUID().uuidString + "_" + source.lastPathComponent
        let target = trashURL.appendingPathComponent(id)
        try NativeCore.transfer(source, to: target, operation: .move)
        var manifest = loadTrashManifest()
        manifest[id] = source.path
        do {
            try saveTrashManifest(manifest)
        } catch {
            do { try NativeCore.transfer(target, to: source, operation: .move) }
            catch {
                throw NSError(domain: "Hoshino.Trash", code: 1, userInfo: [NSLocalizedDescriptionKey: "项目已移入废纸篓，但记录保存失败，且自动回滚失败。项目仍位于：\(target.path)"])
            }
            throw error
        }
        return target
    }

    func restoreFromTrash(_ trashed: URL) throws -> URL {
        let key = trashed.lastPathComponent
        guard let originalPath = loadTrashManifest()[key] else { throw FileSystemError.cannotRestore }
        let original = URL(fileURLWithPath: originalPath)
        guard !pathExistsNoFollow(original) else { throw FileSystemError.cannotRestore }
        try fm.createDirectory(at: original.deletingLastPathComponent(), withIntermediateDirectories: true)
        try NativeCore.transfer(trashed, to: original, operation: .move)
        var manifest = loadTrashManifest()
        manifest.removeValue(forKey: key)
        do {
            try saveTrashManifest(manifest)
        } catch {
            do { try NativeCore.transfer(original, to: trashed, operation: .move) }
            catch {
                throw NSError(domain: "Hoshino.Trash", code: 2, userInfo: [NSLocalizedDescriptionKey: "项目已恢复，但回收站记录更新失败，且无法自动移回。原路径：\(original.path)"])
            }
            throw error
        }
        return original
    }

    func trashItems() -> [HoshinoFile] {
        (try? fm.contentsOfDirectory(at: trashURL, includingPropertiesForKeys: nil))?.compactMap(HoshinoFile.read) ?? []
    }

    func permanentlyDelete(_ url: URL) throws {
        try ensureMutable(url)
        let key = url.lastPathComponent
        var manifest = loadTrashManifest()
        let wasInTrash = manifest[key] != nil
        if wasInTrash {
            let tombstone = trashURL.appendingPathComponent(".deleting-\(UUID().uuidString)")
            try NativeCore.transfer(url, to: tombstone, operation: .move)
            let originalValue = manifest.removeValue(forKey: key)
            do {
                try saveTrashManifest(manifest)
            } catch {
                do { try NativeCore.transfer(tombstone, to: url, operation: .move) }
                catch {
                    throw NSError(domain: "Hoshino.Trash", code: 3,
                                  userInfo: [NSLocalizedDescriptionKey: "废纸篓记录保存失败：\(error.localizedDescription)。项目未删除，暂存位置为：\(tombstone.path)；请手动恢复。"])
                }
                throw error
            }
            do {
                try NativeCore.removeItem(tombstone)
            } catch {
                let deletionError = error.localizedDescription
                if let originalValue { manifest[key] = originalValue }
                var manifestError: String?
                do { try saveTrashManifest(manifest) }
                catch { manifestError = error.localizedDescription }
                var restoreError: String?
                do { try NativeCore.transfer(tombstone, to: url, operation: .move) }
                catch { restoreError = error.localizedDescription }
                let residualPath = pathExistsNoFollow(tombstone) ? tombstone.path : url.path
                let details = [manifestError.map { "废纸篓索引恢复失败：\($0)" },
                               restoreError.map { "项目恢复失败：\($0)" }].compactMap { $0 }
                throw NSError(domain: "Hoshino.Trash", code: 4,
                              userInfo: [NSLocalizedDescriptionKey: "永久删除失败：\(deletionError)。未能完成的清理项目保留在：\(residualPath)\(details.isEmpty ? "" : "；" + details.joined(separator: "；"))"])
            }
        } else {
            try NativeCore.removeItem(url)
        }
    }

    func createSymbolicLink(target: URL, linkURL: URL) throws {
        guard !pathExistsNoFollow(linkURL) else { throw CocoaError(.fileWriteFileExists) }
        try NativeCore.createSymbolicLink(target: target, at: linkURL)
    }

    func createHardLink(from source: URL, at linkURL: URL) throws {
        try ensureMutable(source, allowImmutableSource: true)
        let sourceMeta = try metadata(for: source)
        guard !sourceMeta.isSymbolicLink, (sourceMeta.mode & S_IFMT) == S_IFREG else {
            throw FileSystemError.invalidData("硬链接只允许普通文件，不允许目录、设备节点或符号链接。")
        }
        guard !pathExistsNoFollow(linkURL) else { throw CocoaError(.fileWriteFileExists) }
        try NativeCore.createHardLink(from: source, at: linkURL)
    }

    func metadata(for url: URL, followLinks: Bool = false) throws -> HoshinoFileMetadata {
        var st = stat()
        let result = url.path.withCString { path in followLinks ? stat(path, &st) : lstat(path, &st) }
        guard result == 0 else { throw posixError() }
        return HoshinoFileMetadata(mode: st.st_mode, owner: st.st_uid, group: st.st_gid,
                                   flags: UInt32(st.st_flags), inode: UInt64(st.st_ino),
                                   device: UInt64(st.st_dev), linkCount: UInt32(st.st_nlink),
                                   isSymbolicLink: (st.st_mode & S_IFMT) == S_IFLNK)
    }

    func setPermissions(_ url: URL, octal: String, recursive: Bool) throws {
        guard let value = UInt32(octal, radix: 8), value <= 0o7777 else { throw FileSystemError.invalidData("权限必须是 0000–7777 的八进制值") }
        try NativeCore.setPermissions(url, mode: value, recursive: recursive)
    }

    func setOwnership(_ url: URL, uid: String, gid: String, recursive: Bool) throws {
        let trimmedUID = uid.trimmingCharacters(in: .whitespacesAndNewlines)
        let trimmedGID = gid.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmedUID.isEmpty || !trimmedGID.isEmpty else {
            throw FileSystemError.invalidData("至少输入 UID 或 GID；留空的字段保持原值。")
        }
        let targetUID = trimmedUID.isEmpty ? UInt32.max : UInt32(trimmedUID)
        let targetGID = trimmedGID.isEmpty ? UInt32.max : UInt32(trimmedGID)
        guard let targetUID, let targetGID else { throw FileSystemError.invalidData("UID/GID 必须是 0–4294967295 的十进制整数。") }
        try NativeCore.setOwner(url, uid: targetUID, gid: targetGID, recursive: recursive)
    }

    func setImmutable(_ url: URL, enabled: Bool, recursive: Bool, linkItself: Bool = true) throws {
        let collected = recursive ? descendants(of: url, includingRoot: true) : [url]
        // Lock descendants before the directory; unlock the directory first so traversal remains possible.
        let urls: [URL]
        if recursive, enabled, collected.count > 1 {
            urls = Array(collected.dropFirst().reversed()) + [url]
        } else {
            urls = collected
        }
        struct FlagSnapshot { let url: URL; let flags: UInt32; let isSymlink: Bool }
        var snapshots: [FlagSnapshot] = []
        var changedCount = 0
        do {
            for item in urls {
                var st = stat()
                let statResult = item.path.withCString { linkItself ? lstat($0, &st) : stat($0, &st) }
                guard statResult == 0 else { throw posixError() }
                snapshots.append(FlagSnapshot(url: item, flags: UInt32(st.st_flags), isSymlink: (st.st_mode & S_IFMT) == S_IFLNK))
            }
            for snapshot in snapshots {
                var flags = snapshot.flags
                if enabled { flags |= 0x00000002 } else { flags &= ~UInt32(0x00000002) }
                let result = snapshot.url.path.withCString { path in
                    if linkItself && snapshot.isSymlink { return lchflags(path, flags) }
                    return chflags(path, flags)
                }
                if result != 0 { throw posixError() }
                changedCount += 1
            }
        } catch {
            let originalError = error.localizedDescription
            var rootHelperError: String?
            if RootHelperService.shouldRetry(error) {
                do {
                    try RootHelperService.setImmutable(url, enabled: enabled, recursive: recursive, followSymlinks: !linkItself)
                    return
                } catch { rootHelperError = error.localizedDescription }
            }

            var rollbackFailures: [String] = []
            for snapshot in snapshots.prefix(changedCount).reversed() {
                let result = snapshot.url.path.withCString { path in
                    if linkItself && snapshot.isSymlink { return lchflags(path, snapshot.flags) }
                    return chflags(path, snapshot.flags)
                }
                if result != 0 { rollbackFailures.append(snapshot.url.path) }
            }
            if !rollbackFailures.isEmpty {
                let helperDetail = rootHelperError.map { "；RootHelper 也未能完成：\($0)" } ?? ""
                throw NSError(domain: "Hoshino.Immutable", code: 3,
                              userInfo: [NSLocalizedDescriptionKey: "设置 immutable 失败：\(originalError)\(helperDetail)。部分原始标记无法回滚：\(rollbackFailures.joined(separator: "、"))"])
            }
            if let rootHelperError {
                throw NSError(domain: "Hoshino.Immutable", code: 4,
                              userInfo: [NSLocalizedDescriptionKey: "设置 immutable 失败：\(originalError)。RootHelper 无法完成操作：\(rootHelperError)；已恢复此前更改。"])
            }
            throw NSError(domain: "Hoshino.Immutable", code: 5,
                          userInfo: [NSLocalizedDescriptionKey: "设置 immutable 失败：\(originalError)；已恢复此前更改。"])

        }
    }

    func ensureMutable(_ url: URL, allowImmutableSource: Bool = false) throws {
        let meta = try metadata(for: url)
        if meta.immutable && !allowImmutableSource { throw FileSystemError.immutable }
    }

    /// Counts package contents as normal directories and never follows symlinks.
    /// lstat is used for every node so a symlink to / or another large tree cannot
    /// make the statistics walk escape the selected directory.
    func directoryStats(_ url: URL, maxEntries: Int = 100_000) -> (count: Int, bytes: Int64, truncated: Bool) {
        var count = 0
        var bytes: Int64 = 0
        var scannedEntries = 0
        var truncated = false
        var pending: [URL] = [url]
        var visitedDirectories = Set<String>()
        var seenInodes = Set<String>()
        while let directory = pending.popLast() {
            let identity = directory.standardizedFileURL.path
            guard visitedDirectories.insert(identity).inserted,
                  let children = try? fm.contentsOfDirectory(at: directory, includingPropertiesForKeys: nil, options: []) else { continue }
            for child in children {
                if scannedEntries >= max(1, maxEntries) { truncated = true; break }
                scannedEntries += 1
                var st = stat()
                let status = child.path.withCString { Darwin.lstat($0, &st) }
                guard status == 0 else { continue }
                count += 1
                let type = st.st_mode & S_IFMT
                if type == S_IFREG {
                    let identity = "\(st.st_dev):\(st.st_ino)"
                    if seenInodes.insert(identity).inserted {
                        let (sum, overflow) = bytes.addingReportingOverflow(Int64(max(0, st.st_size)))
                        bytes = overflow ? Int64.max : sum
                    }
                } else if type == S_IFDIR {
                    pending.append(child)
                }
                // Symbolic links and special nodes are counted but not traversed or sized.
            }
            if truncated { break }
        }
        return (count, bytes, truncated)
    }

    /// Calculates actual directory usage using lstat. Symlinks are counted but never followed;
    /// hard-linked files contribute their data blocks only once to the byte total.
    func analyzeDirectory(_ root: URL, largestLimit: Int = 15, includeHidden: Bool = true,
                          maxEntries: Int = 500_000) -> HoshinoDirectoryAnalysis {
        var pending = [root]
        var scannedEntries = 0
        var isTruncated = false
        var fileCount = 0
        var directoryCount = 0
        var symlinkCount = 0
        var unreadableCount = 0
        var totalBytes: UInt64 = 0
        var seenInodes = Set<String>()
        var largest: [HoshinoFile] = []
        var byExtension: [String: HoshinoDirectoryExtensionUsage] = [:]

        while let directory = pending.popLast() {
            let children: [URL]
            do {
                children = try fm.contentsOfDirectory(at: directory, includingPropertiesForKeys: nil, options: [])
            } catch {
                unreadableCount += 1
                continue
            }
            for child in children {
                if scannedEntries >= max(1, maxEntries) { isTruncated = true; break }
                scannedEntries += 1
                if !includeHidden && child.lastPathComponent.hasPrefix(".") { continue }
                var st = stat()
                guard child.path.withCString({ Darwin.lstat($0, &st) }) == 0 else {
                    unreadableCount += 1
                    continue
                }
                let kind = st.st_mode & S_IFMT
                if kind == S_IFDIR {
                    directoryCount += 1
                    pending.append(child)
                    continue
                }
                if kind == S_IFLNK { symlinkCount += 1; continue }
                guard kind == S_IFREG else { continue }
                fileCount += 1
                let size = UInt64(max(0, st.st_size))
                let identity = "\(st.st_dev):\(st.st_ino)"
                let firstLink = seenInodes.insert(identity).inserted
                if firstLink {
                    totalBytes &+= size
                    let ext = child.pathExtension.isEmpty ? "[无扩展名]" : child.pathExtension.lowercased()
                    var usage = byExtension[ext] ?? HoshinoDirectoryExtensionUsage(ext: ext, count: 0, bytes: 0)
                    usage.count += 1
                    usage.bytes &+= size
                    byExtension[ext] = usage
                }
                if let item = HoshinoFile.read(child) {
                    largest.append(item)
                    if largest.count > max(1, largestLimit * 2) {
                        largest.sort { $0.size > $1.size }
                        largest = Array(largest.prefix(max(1, largestLimit)))
                    }
                }
            }
            if isTruncated { break }
        }
        largest.sort { lhs, rhs in lhs.size == rhs.size ? lhs.url.path < rhs.url.path : lhs.size > rhs.size }
        return HoshinoDirectoryAnalysis(
            fileCount: fileCount,
            directoryCount: directoryCount,
            symlinkCount: symlinkCount,
            unreadableCount: unreadableCount,
            totalBytes: totalBytes,
            isTruncated: isTruncated,
            largestFiles: Array(largest.prefix(max(1, largestLimit))),
            extensionUsage: byExtension.values.sorted { lhs, rhs in
                lhs.bytes == rhs.bytes ? lhs.ext.localizedStandardCompare(rhs.ext) == .orderedAscending : lhs.bytes > rhs.bytes
            }
        )
    }

    /// Finds byte-identical regular files. A cheap size pass avoids hashing unrelated files;
    /// SHA-256 is then computed in streaming chunks. Hard-link aliases are not reported as duplicates.
    func findDuplicates(in root: URL, showHidden: Bool = false, maxCandidates: Int = 30_000) -> [HoshinoDuplicateGroup] {
        var buckets: [UInt64: [URL]] = [:]
        var pending = [root]
        var scannedEntries = 0
        var seenInodes = Set<String>()
        let entryLimit = max(1, maxCandidates)

        while let directory = pending.popLast(), scannedEntries < entryLimit {
            guard let children = try? fm.contentsOfDirectory(at: directory, includingPropertiesForKeys: nil, options: []) else { continue }
            for child in children {
                if scannedEntries >= entryLimit { break }
                scannedEntries += 1
                if !showHidden && child.lastPathComponent.hasPrefix(".") { continue }
                var st = stat()
                guard child.path.withCString({ Darwin.lstat($0, &st) }) == 0 else { continue }
                let kind = st.st_mode & S_IFMT
                if kind == S_IFDIR { pending.append(child); continue }
                guard kind == S_IFREG, st.st_size >= 0 else { continue }
                let identity = "\(st.st_dev):\(st.st_ino)"
                guard seenInodes.insert(identity).inserted else { continue }
                buckets[UInt64(st.st_size), default: []].append(child)
            }
        }

        // A small first/last-block fingerprint filters same-size files before expensive full hashes.
        func sampleFingerprint(_ url: URL, size: UInt64) -> String? {
            guard let handle = try? FileHandle(forReadingFrom: url) else { return nil }
            defer { try? handle.close() }
            let first = (try? handle.read(upToCount: 64 * 1024)) ?? Data()
            var last = Data()
            if size > UInt64(first.count) {
                do {
                    try handle.seek(toOffset: size > 64 * 1024 ? size - 64 * 1024 : 0)
                    last = try handle.read(upToCount: 64 * 1024) ?? Data()
                } catch { return nil }
            }
            var context = CC_SHA256_CTX()
            CC_SHA256_Init(&context)
            var bigSize = size.bigEndian
            withUnsafeBytes(of: &bigSize) { raw in
                if let base = raw.bindMemory(to: UInt8.self).baseAddress { CC_SHA256_Update(&context, base, CC_LONG(raw.count)) }
            }
            for chunk in [first, last] {
                chunk.withUnsafeBytes { raw in
                    if let base = raw.bindMemory(to: UInt8.self).baseAddress, !chunk.isEmpty {
                        CC_SHA256_Update(&context, base, CC_LONG(chunk.count))
                    }
                }
            }
            var digest = [UInt8](repeating: 0, count: Int(CC_SHA256_DIGEST_LENGTH))
            CC_SHA256_Final(&digest, &context)
            return digest.map { String(format: "%02x", $0) }.joined()
        }

        var digestGroups: [String: [HoshinoFile]] = [:]
        var digestSizes: [String: UInt64] = [:]
        for (size, urls) in buckets where urls.count > 1 {
            var sampleBuckets: [String: [URL]] = [:]
            for url in urls {
                guard let fingerprint = sampleFingerprint(url, size: size) else { continue }
                sampleBuckets[fingerprint, default: []].append(url)
            }
            for (_, sampleURLs) in sampleBuckets where sampleURLs.count > 1 {
                for url in sampleURLs {
                    guard let digest = try? FileMetadataService.sha256(url), let item = HoshinoFile.read(url) else { continue }
                    digestGroups[digest, default: []].append(item)
                    digestSizes[digest] = size
                }
            }
        }
        return digestGroups.compactMap { digest, files in
            guard files.count > 1, let size = digestSizes[digest] else { return nil }
            return HoshinoDuplicateGroup(sha256: digest, size: size,
                                         files: files.sorted { $0.url.path.localizedStandardCompare($1.url.path) == .orderedAscending })
        }.sorted { lhs, rhs in
            lhs.reclaimableBytes == rhs.reclaimableBytes ? lhs.size > rhs.size : lhs.reclaimableBytes > rhs.reclaimableBytes
        }
    }

    func storageInfo(for url: URL) -> (capacity: Int64, available: Int64) {
        let values = try? url.resourceValues(forKeys: [.volumeTotalCapacityKey, .volumeAvailableCapacityKey])
        return (Int64(values?.volumeTotalCapacity ?? 0), Int64(values?.volumeAvailableCapacity ?? 0))
    }

    func hashes(for url: URL) throws -> (md5: String, sha1: String, sha256: String) {
        let handle = try FileHandle(forReadingFrom: url)
        defer { try? handle.close() }
        var md5 = CC_MD5_CTX(); CC_MD5_Init(&md5)
        var sha1 = CC_SHA1_CTX(); CC_SHA1_Init(&sha1)
        var sha256 = CC_SHA256_CTX(); CC_SHA256_Init(&sha256)
        while true {
            let chunk = try handle.read(upToCount: 1024 * 1024) ?? Data()
            if chunk.isEmpty { break }
            chunk.withUnsafeBytes { raw in
                guard let base = raw.bindMemory(to: UInt8.self).baseAddress else { return }
                CC_MD5_Update(&md5, base, CC_LONG(chunk.count))
                CC_SHA1_Update(&sha1, base, CC_LONG(chunk.count))
                CC_SHA256_Update(&sha256, base, CC_LONG(chunk.count))
            }
        }
        var md5Bytes = [UInt8](repeating: 0, count: Int(CC_MD5_DIGEST_LENGTH))
        var sha1Bytes = [UInt8](repeating: 0, count: Int(CC_SHA1_DIGEST_LENGTH))
        var sha256Bytes = [UInt8](repeating: 0, count: Int(CC_SHA256_DIGEST_LENGTH))
        CC_MD5_Final(&md5Bytes, &md5); CC_SHA1_Final(&sha1Bytes, &sha1); CC_SHA256_Final(&sha256Bytes, &sha256)
        let hex: ([UInt8]) -> String = { $0.map { String(format: "%02x", $0) }.joined() }
        return (hex(md5Bytes), hex(sha1Bytes), hex(sha256Bytes))
    }

    func extendedAttributeNames(_ url: URL) -> [String] {
        let length = url.path.withCString { listxattr($0, nil, 0, XATTR_NOFOLLOW) }
        guard length > 0 else { return [] }
        var buffer = [CChar](repeating: 0, count: length)
        let bufferSize = buffer.count
        let read = url.path.withCString { listxattr($0, &buffer, bufferSize, XATTR_NOFOLLOW) }
        guard read > 0 else { return [] }
        return String(decoding: buffer.prefix(read).map { UInt8(bitPattern: $0) }, as: UTF8.self)
            .split(separator: "\0").map(String.init)
    }

    func setExtendedAttribute(_ name: String, data: Data, url: URL, followLinks: Bool = false) throws {
        guard !name.isEmpty, !name.contains("\0") else { throw FileSystemError.invalidData("扩展属性名称不能为空或包含 NUL。") }
        try NativeCore.setExtendedAttribute(name, data: data, on: url, followSymlinks: followLinks)
    }

    func removeExtendedAttribute(_ name: String, url: URL, followLinks: Bool = false) throws {
        guard !name.isEmpty, !name.contains("\0") else { throw FileSystemError.invalidData("扩展属性名称不能为空或包含 NUL。") }
        try NativeCore.removeExtendedAttribute(name, from: url, followSymlinks: followLinks)
    }

    func extendedAttribute(_ name: String, url: URL) -> Data? {
        let length = url.path.withCString { path in name.withCString { getxattr(path, $0, nil, 0, 0, XATTR_NOFOLLOW) } }
        guard length >= 0 else { return nil }
        var data = Data(count: length)
        let result = data.withUnsafeMutableBytes { raw in
            url.path.withCString { path in name.withCString { getxattr(path, $0, raw.baseAddress, raw.count, 0, XATTR_NOFOLLOW) } }
        }
        return result >= 0 ? data : nil
    }

    func search(_ root: URL, query: String, showHidden: Bool, limit: Int = 1_000) -> [HoshinoFile] {
        let normalized = query.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !normalized.isEmpty, limit > 0 else { return [] }

        enum Rule {
            case name(String), path(String), ext(String), type(String), regex(NSRegularExpression)
            case sizeGreater(UInt64), sizeLess(UInt64), dateAfter(Date), dateBefore(Date), content(String)
        }
        func parseSize(_ raw: String) -> UInt64? {
            let value = raw.trimmingCharacters(in: .whitespaces).uppercased()
            let units: [(String, Double)] = [
                ("TB", 1_099_511_627_776), ("TIB", 1_099_511_627_776),
                ("GB", 1_073_741_824), ("GIB", 1_073_741_824),
                ("MB", 1_048_576), ("MIB", 1_048_576),
                ("KB", 1_024), ("KIB", 1_024), ("B", 1)
            ]
            let unit = units.first { value.hasSuffix($0.0) }
            let number = unit.map { String(value.dropLast($0.0.count)) } ?? value
            guard let amount = Double(number.trimmingCharacters(in: .whitespaces)), amount >= 0, amount.isFinite else { return nil }
            let bytes = amount * (unit?.1 ?? 1)
            guard bytes <= Double(UInt64.max) else { return nil }
            return UInt64(bytes)
        }
        func parseDate(_ raw: String) -> Date? {
            let formatter = DateFormatter()
            formatter.locale = Locale(identifier: "en_US_POSIX")
            formatter.timeZone = TimeZone(secondsFromGMT: 0)
            formatter.dateFormat = "yyyy-MM-dd"
            return formatter.date(from: raw.trimmingCharacters(in: .whitespaces))
        }

        let lowered = normalized.lowercased()
        let rule: Rule
        if lowered.hasPrefix("name:") {
            rule = .name(String(normalized.dropFirst(5)).trimmingCharacters(in: .whitespaces))
        } else if lowered.hasPrefix("path:") {
            rule = .path(String(normalized.dropFirst(5)).trimmingCharacters(in: .whitespaces))
        } else if lowered.hasPrefix("ext:") {
            rule = .ext(String(lowered.dropFirst(4)).trimmingCharacters(in: CharacterSet(charactersIn: ". ")))
        } else if lowered.hasPrefix("type:") {
            rule = .type(String(lowered.dropFirst(5)).trimmingCharacters(in: .whitespaces))
        } else if lowered.hasPrefix("size>") {
            guard let size = parseSize(String(normalized.dropFirst(5))) else { return [] }
            rule = .sizeGreater(size)
        } else if lowered.hasPrefix("size<") {
            guard let size = parseSize(String(normalized.dropFirst(5))) else { return [] }
            rule = .sizeLess(size)
        } else if lowered.hasPrefix("date>") || lowered.hasPrefix("modified>") {
            let count = lowered.hasPrefix("date>") ? 5 : 9
            guard let date = parseDate(String(normalized.dropFirst(count))) else { return [] }
            rule = .dateAfter(date)
        } else if lowered.hasPrefix("date<") || lowered.hasPrefix("modified<") {
            let count = lowered.hasPrefix("date<") ? 5 : 9
            guard let date = parseDate(String(normalized.dropFirst(count))) else { return [] }
            rule = .dateBefore(date)
        } else if lowered.hasPrefix("content:") {
            rule = .content(String(normalized.dropFirst(8)).trimmingCharacters(in: .whitespaces))
        } else if lowered.hasPrefix("re:") {
            let pattern = String(normalized.dropFirst(3))
            guard let regex = try? NSRegularExpression(pattern: pattern, options: [.caseInsensitive]) else { return [] }
            rule = .regex(regex)
        } else if lowered.hasPrefix(".") && !lowered.contains("/") {
            rule = .ext(String(lowered.dropFirst()))
        } else {
            rule = .name(normalized)
        }

        func matchesType(_ item: HoshinoFile, _ value: String) -> Bool {
            let kind = HoshinoFileKind.classify(item.url, isDirectory: item.isDirectory,
                                                executable: item.isExecutableMachO)
            switch value.lowercased() {
            case "folder", "dir", "directory", "文件夹": return item.isDirectory
            case "image", "图片": return kind == .image
            case "video", "视频": return kind == .video
            case "audio", "音频": return kind == .audio
            case "archive", "压缩包": return kind == .archive
            case "package", "安装包": return kind == .package
            case "code", "源码": return kind == .code
            case "document", "文档": return kind == .document
            case "executable", "binary", "可执行": return kind == .executable
            case "text", "文本": return kind == .text
            case "plist": return kind == .plist
            case "font", "字体": return kind == .font
            case "certificate", "cert", "证书": return kind == .certificate
            case "database", "db", "数据库": return kind == .database
            default: return false
            }
        }
        let textExtensions: Set<String> = Set("txt text log md markdown rst json jsonc json5 xml plist strings stringsdict entitlements xcprivacy yaml yml toml ini conf cfg env properties csv tsv swift c cc cpp h hpp m mm js mjs ts tsx jsx py sh bash zsh rs go java kt cs php rb lua dart sql graphql html htm css scss less diff patch tex adoc org".split(separator: " ").map(String.init))
        func contentMatches(_ url: URL, _ query: String) -> Bool {
            guard !query.isEmpty else { return false }
            var st = stat()
            guard url.path.withCString({ Darwin.lstat($0, &st) }) == 0,
                  (st.st_mode & S_IFMT) == S_IFREG,
                  st.st_size >= 0, st.st_size <= 2 * 1024 * 1024,
                  textExtensions.contains(url.pathExtension.lowercased()) else { return false }
            guard let data = try? Data(contentsOf: url, options: [.mappedIfSafe]),
                  let text = String(data: data, encoding: .utf8) else { return false }
            return text.localizedCaseInsensitiveContains(query)
        }

        var results: [HoshinoFile] = []
        guard let enumerator = fm.enumerator(at: root, includingPropertiesForKeys: nil, options: []) else { return [] }
        while let url = enumerator.nextObject() as? URL {
            var st = stat()
            guard url.path.withCString({ Darwin.lstat($0, &st) }) == 0 else { continue }
            let kind = st.st_mode & S_IFMT
            let isDirectory = kind == S_IFDIR
            let isSymlink = kind == S_IFLNK
            if !showHidden && url.lastPathComponent.hasPrefix(".") {
                if isDirectory && !isSymlink { enumerator.skipDescendants() }
                continue
            }
            if isSymlink { enumerator.skipDescendants() }
            guard let item = HoshinoFile.read(url) else { continue }
            let size = UInt64(max(0, st.st_size))
            let date = item.modified ?? .distantPast
            let matched: Bool
            switch rule {
            case .name(let value): matched = !value.isEmpty && item.name.localizedCaseInsensitiveContains(value)
            case .path(let value): matched = !value.isEmpty && item.url.path.localizedCaseInsensitiveContains(value)
            case .ext(let value): matched = !value.isEmpty && item.fileExtension.caseInsensitiveCompare(value) == .orderedSame
            case .type(let value): matched = matchesType(item, value)
            case .regex(let regex):
                let range = NSRange(item.name.startIndex..<item.name.endIndex, in: item.name)
                matched = regex.firstMatch(in: item.name, options: [], range: range) != nil
            case .sizeGreater(let threshold): matched = !isDirectory && size > threshold
            case .sizeLess(let threshold): matched = !isDirectory && size < threshold
            case .dateAfter(let threshold): matched = date >= threshold
            case .dateBefore(let threshold): matched = date < threshold
            case .content(let value): matched = !isDirectory && contentMatches(url, value)
            }
            if matched {
                results.append(item)
                if results.count >= limit { break }
            }
        }
        return results.sorted { lhs, rhs in
            let order = lhs.url.path.localizedStandardCompare(rhs.url.path)
            return order == .orderedSame ? lhs.name < rhs.name : order == .orderedAscending
        }
    }

    private func descendants(of root: URL, includingRoot: Bool) -> [URL] {
        var urls: [URL] = includingRoot ? [root] : []
        if let enumerator = fm.enumerator(at: root, includingPropertiesForKeys: nil, options: []) {
            for case let url as URL in enumerator { urls.append(url) }
        }
        return urls
    }

    private func pathExistsNoFollow(_ url: URL) -> Bool {
        var st = stat()
        return url.path.withCString { lstat($0, &st) == 0 }
    }

    private func saveTrashManifest(_ manifest: [String: String]) throws {
        let data = try PropertyListSerialization.data(fromPropertyList: manifest, format: .binary, options: 0)
        try data.write(to: appSupport.appendingPathComponent("trash-manifest.plist"), options: .atomic)
    }

    private func loadTrashManifest() -> [String: String] {
        let url = appSupport.appendingPathComponent("trash-manifest.plist")
        return (try? Data(contentsOf: url)).flatMap { try? PropertyListSerialization.propertyList(from: $0, options: [], format: nil) as? [String: String] } ?? [:]
    }

    private func posixError() -> NSError { NSError(domain: NSPOSIXErrorDomain, code: Int(errno), userInfo: [NSLocalizedDescriptionKey: String(cString: strerror(errno))]) }
}
