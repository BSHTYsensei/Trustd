import Foundation
import Darwin

struct MountRecord: Identifiable { let id=UUID(); let device:String; let mountPoint:String; let fileSystem:String; let isReadOnly:Bool; let blockSize:UInt64; let blocks:UInt64; let freeBlocks:UInt64 }
enum MountCatalog {
    static func all() -> [MountRecord] {
        var count=getfsstat(nil,0,MNT_NOWAIT); guard count>0 else{return []}; var list=[statfs](repeating:statfs(),count:Int(count)); count=list.withUnsafeMutableBufferPointer { getfsstat($0.baseAddress,Int32($0.count*MemoryLayout<statfs>.stride),MNT_NOWAIT) }; return list.prefix(Int(max(0,count))).map { s in MountRecord(device:withUnsafePointer(to:s.f_mntfromname){$0.withMemoryRebound(to:CChar.self,capacity:Int(MNAMELEN)) {String(cString:$0)}},mountPoint:withUnsafePointer(to:s.f_mntonname){$0.withMemoryRebound(to:CChar.self,capacity:Int(MNAMELEN)) {String(cString:$0)}},fileSystem:withUnsafePointer(to:s.f_fstypename){$0.withMemoryRebound(to:CChar.self,capacity:Int(MFSNAMELEN)) {String(cString:$0)}},isReadOnly:(s.f_flags & MNT_RDONLY) != 0,blockSize:UInt64(s.f_bsize),blocks:UInt64(s.f_blocks),freeBlocks:UInt64(s.f_bfree)) }
    }
}
