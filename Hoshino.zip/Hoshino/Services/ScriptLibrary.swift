import Foundation
import Combine
import JavaScriptCore

struct HoshinoScript: Identifiable, Codable, Hashable {
    var id = UUID(); var name: String; var fileName: String; var kind: String; var enabled = true
    @MainActor var runtimeAvailable: Bool {
        switch kind {
        case "js", "cjs", "sh", "command": return true
        case "bash": return HoshinoBashRuntimeAvailable() == 1
        case "py", "pyw": return HoshinoPythonRuntimeAvailable() == 1
        case "lua", "rb", "pl", "awk", "php", "r", "tcl", "mjs":
            return kind.withCString { HoshinoInterpreterRuntimeAvailable($0) == 1 }
        default: return false // ES Modules require a module resolver; JavaScriptCore exposes classic scripts only.
        }
    }
}
@_silgen_name("HoshinoBashRuntimeAvailable") private func HoshinoBashRuntimeAvailable() -> Int32
@_silgen_name("HoshinoRunBashScript") private func HoshinoRunBashScript(_ path: UnsafePointer<CChar>, _ output: UnsafeMutablePointer<CChar>, _ capacity: Int) -> Int32
@_silgen_name("HoshinoRunShellScript") private func HoshinoRunShellScript(_ path: UnsafePointer<CChar>, _ output: UnsafeMutablePointer<CChar>, _ capacity: Int) -> Int32
@_silgen_name("HoshinoPythonRuntimeAvailable") private func HoshinoPythonRuntimeAvailable() -> Int32
@_silgen_name("HoshinoInterpreterRuntimeAvailable") private func HoshinoInterpreterRuntimeAvailable(_ kind: UnsafePointer<CChar>) -> Int32
@_silgen_name("HoshinoRunInterpreterScript") private func HoshinoRunInterpreterScript(_ kind: UnsafePointer<CChar>, _ path: UnsafePointer<CChar>, _ output: UnsafeMutablePointer<CChar>, _ capacity: Int) -> Int32
@_silgen_name("HoshinoRunPythonScript") private func HoshinoRunPythonScript(_ path: UnsafePointer<CChar>, _ output: UnsafeMutablePointer<CChar>, _ capacity: Int) -> Int32

@MainActor final class ScriptLibrary: ObservableObject {
    static let shared = ScriptLibrary()
    /// Runtime inventory is evaluated on the current device; it is not a hard-coded capability promise.
    static var availableRuntimes: Set<String> {
        Set(["js", "cjs", "sh", "command", "bash", "py", "lua", "rb", "pl", "awk", "php", "r", "tcl", "mjs"].filter { kind in
            HoshinoScript(name: "", fileName: "", kind: kind).runtimeAvailable
        })
    }
    static let supportedExtensions: Set<String> = ["js","mjs","cjs","sh","bash","command","py","pyw","lua","rb","pl","awk","php","r","tcl"]
    @Published private(set) var scripts: [HoshinoScript] = []
    private let selectedKey = "Hoshino.SelectedScripts.v1"
    private let folder: URL
    private init() { folder = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0].appendingPathComponent("Scripts", isDirectory: true); try? FileManager.default.createDirectory(at: folder, withIntermediateDirectories: true); reload() }
    func reload() {
        let urls = ((try? FileManager.default.contentsOfDirectory(at: folder, includingPropertiesForKeys: [.isRegularFileKey], options: [.skipsHiddenFiles])) ?? []).filter { Self.supportedExtensions.contains($0.pathExtension.lowercased()) }.sorted { $0.lastPathComponent.localizedStandardCompare($1.lastPathComponent) == .orderedAscending }
        let stored = UserDefaults.standard.stringArray(forKey: selectedKey)
        let selected = Set(stored ?? urls.map(\.lastPathComponent))
        scripts = urls.map { HoshinoScript(name: $0.deletingPathExtension().lastPathComponent, fileName: $0.lastPathComponent, kind: $0.pathExtension.lowercased(), enabled: selected.contains($0.lastPathComponent)) }
        if stored == nil { persistSelection() }
    }
    func importScript(_ source: URL) throws {
        let ext = source.pathExtension.lowercased(); guard Self.supportedExtensions.contains(ext) else { throw NSError(domain: "Hoshino.Script", code: 2, userInfo: [NSLocalizedDescriptionKey: "不支持此脚本扩展名。可导入 JS、Shell、Python、Lua、Ruby、Perl、AWK、PHP、R、Tcl 文件。Node.js、Lua、Ruby、Perl、AWK、PHP、R、Tcl 等外部解释器只有在设备上已安装时才可运行；.mjs 依赖 Node.js。"] ) }
        let access = source.startAccessingSecurityScopedResource(); defer { if access { source.stopAccessingSecurityScopedResource() } }
        let dest = folder.appendingPathComponent(source.lastPathComponent); guard !FileManager.default.fileExists(atPath: dest.path) else { throw CocoaError(.fileWriteFileExists) }; try FileManager.default.copyItem(at: source, to: dest); var selected = Set(UserDefaults.standard.stringArray(forKey: selectedKey) ?? []); selected.insert(dest.lastPathComponent); UserDefaults.standard.set(Array(selected), forKey: selectedKey); reload()
    }
    func toggle(_ script: HoshinoScript) { guard let i = scripts.firstIndex(where: { $0.id == script.id }) else { return }; scripts[i].enabled.toggle(); persistSelection() }
    private func persistSelection() { UserDefaults.standard.set(scripts.filter(\.enabled).map(\.fileName), forKey: selectedKey) }
    func delete(_ script: HoshinoScript) throws { try FileManager.default.removeItem(at: folder.appendingPathComponent(script.fileName)); var selected = Set(UserDefaults.standard.stringArray(forKey: selectedKey) ?? []); selected.remove(script.fileName); UserDefaults.standard.set(Array(selected), forKey: selectedKey); reload() }
    nonisolated private static func runOne(_ script: HoshinoScript, at url: URL) throws -> String {
        switch script.kind {
        case "js":
            return try JavaScriptRuntime(rootDirectory: url.deletingLastPathComponent()).runClassic(url)
        case "cjs":
            return try JavaScriptRuntime(rootDirectory: url.deletingLastPathComponent()).runCommonJS(url)
        case "sh", "command":
            var output = [CChar](repeating: 0, count: 1_048_576); let rc = url.path.withCString { path in output.withUnsafeMutableBufferPointer { HoshinoRunShellScript(path, $0.baseAddress!, $0.count) } }
            guard rc == 0 else { throw NSError(domain: "Hoshino.Script", code: Int(rc), userInfo: [NSLocalizedDescriptionKey: String(cString: output).isEmpty ? "Shell 执行失败，退出码 \(rc)" : String(cString: output)]) }; return String(cString: output)
        case "bash":
            var output = [CChar](repeating: 0, count: 1_048_576); let rc = url.path.withCString { path in output.withUnsafeMutableBufferPointer { HoshinoRunBashScript(path, $0.baseAddress!, $0.count) } }
            guard rc == 0 else { throw NSError(domain: "Hoshino.Script", code: Int(rc), userInfo: [NSLocalizedDescriptionKey: String(cString: output).isEmpty ? "Bash 执行失败，退出码 \(rc)" : String(cString: output)]) }; return String(cString: output)
        case "py", "pyw":
            var output = [CChar](repeating: 0, count: 1_048_576); let rc = url.path.withCString { path in output.withUnsafeMutableBufferPointer { HoshinoRunPythonScript(path, $0.baseAddress!, $0.count) } }
            guard rc == 0 else { throw NSError(domain: "Hoshino.Script", code: Int(rc), userInfo: [NSLocalizedDescriptionKey: String(cString: output).isEmpty ? "Python 执行失败或未集成 Python.xcframework（退出码 \(rc)）" : String(cString: output)]) }; return String(cString: output)
        case "lua", "rb", "pl", "awk", "php", "r", "tcl", "mjs":
            var output = [CChar](repeating: 0, count: 1_048_576)
            let rc = script.kind.withCString { kind in url.path.withCString { path in output.withUnsafeMutableBufferPointer { HoshinoRunInterpreterScript(kind, path, $0.baseAddress!, $0.count) } } }
            guard rc == 0 else { throw NSError(domain: "Hoshino.Script", code: Int(rc), userInfo: [NSLocalizedDescriptionKey: String(cString: output).isEmpty ? "脚本执行失败或缺少解释器（退出码 \(rc)）" : String(cString: output)]) }
            return String(cString: output)
        default: throw NSError(domain: "Hoshino.Script", code: 5, userInfo: [NSLocalizedDescriptionKey: "当前版本不支持运行此脚本类型：\(script.kind)"])
        }
    }
    func runSelected() async -> [(String, String)] {
        let selected = scripts.filter(\.enabled)
        var results: [(String, String)] = []
        for script in selected {
            guard script.runtimeAvailable else { results.append((script.name, "未运行：缺少 \(script.kind.uppercased()) 解释器")); continue }
            let scriptURL = folder.appendingPathComponent(script.fileName)
            do { results.append((script.name, try await Task.detached(priority: .userInitiated) { try Self.runOne(script, at: scriptURL) }.value)) }
            catch { results.append((script.name, "ERROR: \(error.localizedDescription)")) }
        }
        return results
    }
}


/// A deliberately bounded JavaScript runtime for application-managed scripts.
/// It supports classic .js and local CommonJS .cjs modules. It is not Node.js:
/// package resolution, native addons, process spawning, and built-in modules are
/// intentionally unavailable.
private final class JavaScriptRuntime {
    private let context: JSContext
    private let rootDirectory: URL
    private var output = ""
    private var moduleCache: [String: JSValue] = [:]
    private let outputLimit = 1_048_576

    private func appendOutput(_ value: String) {
        guard output.utf8.count < outputLimit else { return }
        let remaining = outputLimit - output.utf8.count
        let bytes = Array(value.utf8.prefix(remaining))
        output += String(decoding: bytes, as: UTF8.self)
        if value.utf8.count > remaining { output += "\n[输出已截断：超过 1 MiB]" }
    }

    init(rootDirectory: URL) {
        self.rootDirectory = rootDirectory.standardizedFileURL.resolvingSymlinksInPath()
        self.context = JSContext()!
        installConsole()
    }

    func runClassic(_ url: URL) throws -> String {
        let source = try readSource(url)
        _ = context.evaluateScript(source, withSourceURL: url)
        try throwIfException()
        return output
    }

    func runCommonJS(_ url: URL) throws -> String {
        _ = try loadCommonJS(url)
        try throwIfException()
        return output
    }

    private func installConsole() {
        let log: @convention(block) (String) -> Void = { [weak self] value in self?.appendOutput(value + "\n") }
        context.setObject(log, forKeyedSubscript: "print" as NSString)
        let console = JSValue(newObjectIn: context)!
        console.setObject(log, forKeyedSubscript: "log" as NSString)
        console.setObject(log, forKeyedSubscript: "info" as NSString)
        console.setObject(log, forKeyedSubscript: "warn" as NSString)
        console.setObject(log, forKeyedSubscript: "error" as NSString)
        context.setObject(console, forKeyedSubscript: "console" as NSString)
        context.exceptionHandler = { [weak self] _, exception in
            guard let exception else { return }
            self?.appendOutput("ERROR: \(exception.toString() ?? "JavaScript exception")\n")
        }
    }

    private func throwIfException() throws {
        guard let exception = context.exception else { return }
        context.exception = nil
        throw NSError(domain: "Hoshino.Script.JavaScript", code: 1,
                      userInfo: [NSLocalizedDescriptionKey: exception.toString() ?? "JavaScript 执行失败。"])
    }

    private func readSource(_ url: URL) throws -> String {
        let safeURL = try validatedURL(url)
        return try String(contentsOf: safeURL, encoding: .utf8)
    }

    private func validatedURL(_ url: URL) throws -> URL {
        let resolved = url.standardizedFileURL.resolvingSymlinksInPath()
        let rootPath = rootDirectory.path.hasSuffix("/") ? rootDirectory.path : rootDirectory.path + "/"
        guard resolved.path.hasPrefix(rootPath), resolved.path != rootDirectory.path else {
            throw runtimeError("模块路径越过脚本库目录，已拒绝加载：\(url.path)")
        }
        var isDirectory: ObjCBool = false
        guard FileManager.default.fileExists(atPath: resolved.path, isDirectory: &isDirectory), !isDirectory.boolValue else {
            throw runtimeError("脚本模块不存在或不是普通文件：\(resolved.lastPathComponent)")
        }
        let ext = resolved.pathExtension.lowercased()
        guard ["js", "cjs", "json"].contains(ext) else {
            throw runtimeError("CommonJS 只允许加载 .js、.cjs、.json 本地模块：\(resolved.lastPathComponent)")
        }
        return resolved
    }

    private func loadCommonJS(_ requestedURL: URL) throws -> JSValue {
        let url = try validatedURL(requestedURL)
        let key = url.path
        if let cachedModule = moduleCache[key] {
            return cachedModule.forProperty("exports") ?? JSValue(undefinedIn: context)
        }
        if url.pathExtension.lowercased() == "json" {
            let data = try Data(contentsOf: url)
            let value = try JSONSerialization.jsonObject(with: data, options: [.fragmentsAllowed])
            let jsonData = try JSONSerialization.data(withJSONObject: value, options: [.fragmentsAllowed, .sortedKeys])
            guard let json = String(data: jsonData, encoding: .utf8),
                  let parsed = context.evaluateScript("JSON.parse(\(Self.javascriptStringLiteral(json)))") else {
                throw runtimeError("JSON 模块解析失败：\(url.lastPathComponent)")
            }
            return parsed
        }

        let module = JSValue(newObjectIn: context)!
        let exports = JSValue(newObjectIn: context)!
        module.setValue(exports, forProperty: "exports")
        // Cache before evaluating to support the CommonJS circular-dependency rule.
        moduleCache[key] = module

        let requireBlock: @convention(block) (String) -> JSValue? = { [weak self] specifier in
            guard let self else { return nil }
            do {
                return try self.resolveAndLoad(specifier, parent: url)
            } catch {
                let message = Self.javascriptStringLiteral(error.localizedDescription)
                _ = self.context.evaluateScript("throw new Error(\(message))")
                return nil
            }
        }

        let source = try readSource(url)
        let wrapper = "(function(exports, require, module, __filename, __dirname) {\n\(source)\n})"
        guard let function = context.evaluateScript(wrapper, withSourceURL: url) else {
            try throwIfException()
            throw runtimeError("无法创建 CommonJS 模块函数：\(url.lastPathComponent)")
        }
        _ = function.call(withArguments: [exports, requireBlock, module, url.path, url.deletingLastPathComponent().path])
        try throwIfException()
        return module.forProperty("exports") ?? JSValue(undefinedIn: context)
    }

    private func resolveAndLoad(_ specifier: String, parent: URL) throws -> JSValue {
        guard specifier.hasPrefix("./") || specifier.hasPrefix("../") else {
            throw runtimeError("不支持 Node 内置模块或 npm 包：\(specifier)。当前只允许脚本库目录内的相对模块。")
        }
        let base = parent.deletingLastPathComponent().appendingPathComponent(specifier)
        var candidates = [base]
        if base.pathExtension.isEmpty {
            candidates += [base.appendingPathExtension("js"), base.appendingPathExtension("cjs"), base.appendingPathExtension("json"),
                           base.appendingPathComponent("index.js"), base.appendingPathComponent("index.cjs"), base.appendingPathComponent("index.json")]
        }
        for candidate in candidates {
            let resolved = candidate.standardizedFileURL.resolvingSymlinksInPath()
            let rootPath = rootDirectory.path.hasSuffix("/") ? rootDirectory.path : rootDirectory.path + "/"
            guard resolved.path.hasPrefix(rootPath) else { throw runtimeError("模块路径越过脚本库目录：\(specifier)") }
            if FileManager.default.fileExists(atPath: resolved.path) { return try loadCommonJS(resolved) }
        }
        throw runtimeError("找不到本地 CommonJS 模块：\(specifier)")
    }

    private func runtimeError(_ message: String) -> NSError {
        NSError(domain: "Hoshino.Script.CommonJS", code: 2, userInfo: [NSLocalizedDescriptionKey: message])
    }

    private static func javascriptStringLiteral(_ string: String) -> String {
        let data = try! JSONSerialization.data(withJSONObject: [string], options: [.fragmentsAllowed])
        let encoded = String(data: data, encoding: .utf8) ?? "[\"\"]"
        return String(encoded.dropFirst().dropLast())
    }
}
