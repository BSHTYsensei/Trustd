import Foundation
import CryptoKit
import Darwin

struct HoshinoStatMetadata: Sendable {
    let path: String; let size: UInt64; let mode: mode_t; let uid: uid_t; let gid: gid_t
    let inode: UInt64; let device: UInt64; let links: UInt64; let flags: UInt32
    let created: Date?; let modified: Date; let accessed: Date; let fileSystem: String
    let isDirectory: Bool; let isSymlink: Bool
}

enum FileMetadataService {
    static func read(_ url: URL) throws -> HoshinoStatMetadata {
        var st = stat()
        let rc = url.withUnsafeFileSystemRepresentation { p in Darwin.lstat(p, &st) }
        guard rc == 0 else { throw POSIXError(POSIXErrorCode(rawValue: errno) ?? .EIO) }
        var fs = statfs()
        let fsOK = url.withUnsafeFileSystemRepresentation { p in Darwin.statfs(p, &fs) == 0 }
        let name = fsOK ? withUnsafePointer(to: &fs.f_fstypename) { $0.withMemoryRebound(to: CChar.self, capacity: Int(MFSNAMELEN)) { String(cString: $0) } } : "unknown"
        return .init(path:url.path,size:UInt64(max(0,st.st_size)),mode:st.st_mode,uid:st.st_uid,gid:st.st_gid,inode:UInt64(st.st_ino),device:UInt64(st.st_dev),links:UInt64(st.st_nlink),flags:st.st_flags,created:st.st_birthtimespec.tv_sec > 0 ? Date(timeIntervalSince1970:Double(st.st_birthtimespec.tv_sec)) : nil,modified:Date(timeIntervalSince1970:Double(st.st_mtimespec.tv_sec)),accessed:Date(timeIntervalSince1970:Double(st.st_atimespec.tv_sec)),fileSystem:name,isDirectory:(st.st_mode & S_IFMT) == S_IFDIR,isSymlink:(st.st_mode & S_IFMT) == S_IFLNK)
    }
    static func sha256(_ url: URL, chunkSize: Int = 1 << 20) throws -> String {
        let handle = try FileHandle(forReadingFrom:url); defer { try? handle.close() }
        var hasher = SHA256()
        while true { let data = try handle.read(upToCount:chunkSize) ?? Data(); if data.isEmpty { break }; hasher.update(data:data) }
        return hasher.finalize().map { String(format:"%02x",$0) }.joined()
    }
    static func readWindow(_ url: URL, offset: UInt64, length: Int) throws -> Data {
        let h = try FileHandle(forReadingFrom:url); defer { try? h.close() }; try h.seek(toOffset:offset); return try h.read(upToCount:max(0,length)) ?? Data()
    }
    static func writeWindow(_ url: URL, offset: UInt64, bytes: Data) throws {
        let h = try FileHandle(forUpdating:url); defer { try? h.close() }; try h.seek(toOffset:offset); try h.write(contentsOf:bytes)
    }
    static func setImmutable(_ url: URL, enabled: Bool) throws {
        var st=stat(); let rc=url.withUnsafeFileSystemRepresentation { Darwin.lstat($0,&st) }; guard rc == 0 else { throw POSIXError(.init(rawValue:errno) ?? .EIO) }
        let flags = enabled ? (st.st_flags | UInt32(UF_IMMUTABLE)) : (st.st_flags & ~UInt32(UF_IMMUTABLE))
        let result=url.withUnsafeFileSystemRepresentation { Darwin.chflags($0,flags) }; guard result == 0 else { throw POSIXError(.init(rawValue:errno) ?? .EPERM) }
    }
    static func recursiveURLs(_ root: URL) throws -> [URL] {
        var result=[root]; guard (try? root.resourceValues(forKeys:[.isDirectoryKey]).isDirectory) == true else { return result }
        let e=FileManager.default.enumerator(at:root,includingPropertiesForKeys:[.isDirectoryKey],options:[.skipsPackageDescendants])
        while let u=e?.nextObject() as? URL { result.append(u) }; return result
    }
}
