import Foundation
import Darwin
import ZipArchive

struct ArchiveEntryInfo: Identifiable, Decodable {
    let index: Int
    let path: String
    let kind: String
    let size: UInt64
    let mode: UInt32
    let linkTarget: String?

    var isDirectory: Bool { kind == "directory" }
    var isSymbolicLink: Bool { kind == "symlink" }
    var id: String { "\(index):\(path)" }
}

enum ArchiveOutputFormat: String, CaseIterable, Identifiable, Hashable {
    case zip, sevenZip, tar, tarGzip, tarBzip2, tarXZ, gzip, bzip2, xz, cpio, iso9660

    var id: String { rawValue }
    var title: String {
        switch self {
        case .zip: return "ZIP"
        case .sevenZip: return "7-Zip"
        case .tar: return "TAR"
        case .tarGzip: return "TAR.GZ"
        case .tarBzip2: return "TAR.BZ2"
        case .tarXZ: return "TAR.XZ"
        case .gzip: return "GZIP（单文件）"
        case .bzip2: return "BZIP2（单文件）"
        case .xz: return "XZ（单文件）"
        case .cpio: return "CPIO"
        case .iso9660: return "ISO 9660"
        }
    }
    var fileExtension: String {
        switch self {
        case .zip: return "zip"
        case .sevenZip: return "7z"
        case .tar: return "tar"
        case .tarGzip: return "tar.gz"
        case .tarBzip2: return "tar.bz2"
        case .tarXZ: return "tar.xz"
        case .gzip: return "gz"
        case .bzip2: return "bz2"
        case .xz: return "xz"
        case .cpio: return "cpio"
        case .iso9660: return "iso"
        }
    }
    var libarchiveFormat: String {
        switch self {
        case .zip: return "zip"
        case .sevenZip: return "7zip"
        case .tar, .tarGzip, .tarBzip2, .tarXZ: return "pax"
        case .gzip, .bzip2, .xz: return "raw"
        case .cpio: return "cpio"
        case .iso9660: return "iso9660"
        }
    }
    var libarchiveFilter: String {
        switch self {
        case .tarGzip, .gzip: return "gzip"
        case .tarBzip2, .bzip2: return "bzip2"
        case .tarXZ, .xz: return "xz"
        default: return "none"
        }
    }
    var isSingleFileStream: Bool { self == .gzip || self == .bzip2 || self == .xz }
    var supportsPassword: Bool { self == .zip }
}

private struct ArchiveEntryPayload: Decodable {
    let path: String
    let kind: String
    let size: UInt64
    let mode: UInt32
    let linkTarget: String?
}

final class ArchiveService {
    static let shared = ArchiveService()
    private init() {}

    func entries(at archiveURL: URL, password: String? = nil) throws -> [ArchiveEntryInfo] {
        var capacity = 1 * 1024 * 1024
        var json = [CChar]()
        var error = [CChar](repeating: 0, count: 4096)
        var result: Int32 = 0
        while capacity <= 64 * 1024 * 1024 {
            json = [CChar](repeating: 0, count: capacity)
            let invoke: (UnsafePointer<CChar>?) -> Int32 = { passphrase in
                archiveURL.path.withCString { path in
                    json.withUnsafeMutableBufferPointer { output in
                        error.withUnsafeMutableBufferPointer { message in
                            HoshinoArchiveListJSON(path, passphrase, output.baseAddress!, output.count,
                                                   message.baseAddress!, message.count)
                        }
                    }
                }
            }
            result = password.map { value in value.withCString { invoke($0) } } ?? invoke(nil)
            if result != Int32(Darwin.ENOBUFS) { break } // ENOBUFS
            capacity *= 2
        }
        guard result == 0 else { throw makeError(result, error) }
        let data = Data(String(cString: json).utf8)
        let decoded = try JSONDecoder().decode([ArchiveEntryPayload].self, from: data)
        return decoded.enumerated().map { index, item in
            ArchiveEntryInfo(index: index, path: item.path, kind: item.kind, size: item.size,
                             mode: item.mode, linkTarget: item.linkTarget)
        }.sorted { lhs, rhs in
            if lhs.isDirectory != rhs.isDirectory { return lhs.isDirectory }
            if lhs.isSymbolicLink != rhs.isSymbolicLink { return lhs.isSymbolicLink }
            return lhs.path.localizedStandardCompare(rhs.path) == .orderedAscending
        }
    }

    func createArchive(from sources: [URL], to destination: URL, format: ArchiveOutputFormat,
                       password: String? = nil, preservePermissions: Bool = true) throws {
        guard !sources.isEmpty else { throw archiveError("没有选择要压缩的项目。") }
        guard !pathExistsNoFollow(destination) else { throw CocoaError(.fileWriteFileExists) }
        if format.isSingleFileStream {
            guard sources.count == 1 else { throw archiveError("GZ、BZ2、XZ 是单文件压缩格式，请只选择一个普通文件。") }
            var st = stat()
            guard sources[0].withUnsafeFileSystemRepresentation({ lstat($0, &st) }) == 0, (st.st_mode & S_IFMT) == S_IFREG else {
                throw archiveError("GZ、BZ2、XZ 单文件压缩不接受目录、符号链接或特殊文件。")
            }
        }
        if let password, !password.isEmpty {
            guard format.supportsPassword else { throw archiveError("只有 ZIP 格式支持密码加密。") }
            try createEncryptedZip(from: sources, to: destination, password: password)
            return
        }

        let paths = sources.map(\.path)
        var duplicated: [UnsafeMutablePointer<CChar>] = []
        for path in paths {
            guard let pointer = strdup(path) else {
                duplicated.forEach { free($0) }
                throw archiveError("无法分配归档路径参数。")
            }
            duplicated.append(pointer)
        }
        defer { duplicated.forEach { free($0) } }
        let sourcePointers: [UnsafePointer<CChar>?] = duplicated.map { UnsafePointer($0) }
        var error = [CChar](repeating: 0, count: 4096)
        let result = destination.path.withCString { destinationPath in
            format.libarchiveFormat.withCString { archiveFormat in
                format.libarchiveFilter.withCString { filter in
                    sourcePointers.withUnsafeBufferPointer { sourceBuffer in
                        error.withUnsafeMutableBufferPointer { errorBuffer in
                            HoshinoArchiveCreate(destinationPath, sourceBuffer.baseAddress!, sourceBuffer.count,
                                                 archiveFormat, filter, preservePermissions ? 1 : 0,
                                                 errorBuffer.baseAddress!, errorBuffer.count)
                        }
                    }
                }
            }
        }
        guard result == 0 else { throw makeError(result, error) }
    }

    func createZip(from sources: [URL], to destination: URL) throws {
        try createArchive(from: sources, to: destination, format: .zip)
    }

    func extractArchive(_ source: URL, to destination: URL, password: String? = nil) throws {
        guard !pathExistsNoFollow(destination) else { throw CocoaError(.fileWriteFileExists) }
        let parent = destination.deletingLastPathComponent()
        try FileManager.default.createDirectory(at: parent, withIntermediateDirectories: true)
        let metadata = try entries(at: source, password: password)
        guard !metadata.isEmpty else { throw archiveError("归档为空。") }
        try validateExpandedSize(metadata, parent: parent)
        let staging = parent.appendingPathComponent(".hoshino-extract-\(UUID().uuidString)", isDirectory: true)
        try FileManager.default.createDirectory(at: staging, withIntermediateDirectories: false)
        do {
            if let password, !password.isEmpty, source.pathExtension.lowercased() == "zip" {
                try validateThirdPartyZipEntries(metadata)
                var nsError: NSError?
                let ok = SSZipArchive.unzipFile(atPath: source.path, toDestination: staging.path,
                                                overwrite: false, password: password, error: &nsError)
                guard ok else { throw nsError ?? archiveError("ZIP 密码错误或归档损坏。") }
                try validateExtractedTree(staging)
            } else {
                var error = [CChar](repeating: 0, count: 4096)
                let invoke: (UnsafePointer<CChar>?) -> Int32 = { passphrase in
                    source.path.withCString { sourcePath in
                        staging.path.withCString { stagingPath in
                            error.withUnsafeMutableBufferPointer { message in
                                HoshinoArchiveExtract(sourcePath, stagingPath, passphrase,
                                                      message.baseAddress!, message.count)
                            }
                        }
                    }
                }
                let result = password.map { value in value.withCString { invoke($0) } } ?? invoke(nil)
                guard result == 0 else { throw makeError(result, error) }
            }
            guard !pathExistsNoFollow(destination) else { throw CocoaError(.fileWriteFileExists) }
            try FileManager.default.moveItem(at: staging, to: destination)
        } catch {
            try? FileManager.default.removeItem(at: staging)
            throw error
        }
    }

    func extractZip(_ source: URL, to destination: URL, password: String?) throws {
        try extractArchive(source, to: destination, password: password)
    }

    func createEncryptedZip(from sources: [URL], to destination: URL, password: String) throws {
        guard !password.isEmpty else { throw archiveError("密码不能为空。") }
        guard !sources.isEmpty else { throw archiveError("没有选择要压缩的项目。") }
        guard !pathExistsNoFollow(destination) else { throw CocoaError(.fileWriteFileExists) }
        try validateEncryptedSources(sources)
        let paths = sources.map(\.path)
        let temporary = destination.deletingLastPathComponent()
            .appendingPathComponent(".hoshino-encrypted-\(UUID().uuidString).zip")
        defer { try? FileManager.default.removeItem(at: temporary) }
        let ok = SSZipArchive.createZipFile(atPath: temporary.path, withFilesAtPaths: paths, withPassword: password)
        guard ok else { throw archiveError("加密 ZIP 创建失败。请确认选择的项目受当前 ZipArchive 后端支持。") }
        guard link(temporary.path, destination.path) == 0 else {
            throw POSIXError(POSIXErrorCode(rawValue: errno) ?? .EIO)
        }
    }

    private func validateExpandedSize(_ entries: [ArchiveEntryInfo], parent: URL) throws {
        let total = try entries.reduce(UInt64(0)) { partial, item in
            let (value, overflow) = partial.addingReportingOverflow(item.size)
            guard !overflow else { throw archiveError("归档声明的解压大小溢出。") }
            return value
        }
        let hardLimit: UInt64 = 4 * 1024 * 1024 * 1024
        let reserve: UInt64 = 64 * 1024 * 1024
        let available = try? parent.resourceValues(forKeys: [.volumeAvailableCapacityKey]).volumeAvailableCapacity
        let availableBytes = UInt64(max(Int64(0), available ?? Int64(2 * 1024 * 1024 * 1024)))
        let availableBudget = availableBytes > reserve ? availableBytes - reserve : 0
        let budget = min(hardLimit, availableBudget)
        guard total <= hardLimit, total <= budget else { throw archiveError("解压数据超过安全空间预算。") }
    }

    private func validateThirdPartyZipEntries(_ entries: [ArchiveEntryInfo]) throws {
        var paths: [String: Bool] = [:]
        for entry in entries {
            let raw = entry.path.replacingOccurrences(of: "\\", with: "/")
            let components = raw.split(separator: "/", omittingEmptySubsequences: false)
            let drive = raw.range(of: "^[A-Za-z]:", options: .regularExpression) != nil
            guard !raw.isEmpty, !raw.hasPrefix("/"), !drive, !raw.contains("\0"),
                  !raw.unicodeScalars.contains(where: { CharacterSet.controlCharacters.contains($0) }),
                  !components.isEmpty, !components.contains(""), !components.contains("."), !components.contains("..") else {
                throw archiveError("ZIP 包含不安全路径：\(entry.path)")
            }
            guard entry.kind == "file" || entry.kind == "directory" else {
                throw archiveError("加密 ZIP 包含不支持的条目类型：\(raw)")
            }
            let folded = raw.lowercased()
            guard paths[folded] == nil else { throw archiveError("ZIP 包含重复或大小写冲突路径：\(raw)") }
            paths[folded] = entry.isDirectory
        }
        // Validate parents after collecting all entries so archive order cannot
        // bypass a file-vs-directory collision check.
        for path in paths.keys {
            var parent = (path as NSString).deletingLastPathComponent
            while !parent.isEmpty && parent != "." && parent != "/" {
                if let isDirectory = paths[parent], !isDirectory {
                    throw archiveError("ZIP 路径穿过普通文件：\(parent)")
                }
                parent = (parent as NSString).deletingLastPathComponent
            }
        }
    }

    private func validateExtractedTree(_ root: URL) throws {
        var pending = [root]
        var count = 0
        var total: UInt64 = 0
        let limit: UInt64 = 4 * 1024 * 1024 * 1024
        while let url = pending.popLast() {
            count += 1
            guard count <= 100_000 else { throw archiveError("解压结果包含过多文件，已回滚。") }
            var info = stat()
            guard url.withUnsafeFileSystemRepresentation({ Darwin.lstat($0, &info) }) == 0 else {
                throw POSIXError(POSIXErrorCode(rawValue: errno) ?? .EIO)
            }
            switch info.st_mode & S_IFMT {
            case S_IFDIR:
                let children = try FileManager.default.contentsOfDirectory(at: url, includingPropertiesForKeys: nil)
                pending.append(contentsOf: children)
            case S_IFREG:
                guard info.st_size >= 0 else { throw archiveError("解压文件大小无效：\(url.lastPathComponent)") }
                let (next, overflow) = total.addingReportingOverflow(UInt64(info.st_size))
                guard !overflow, next <= limit else { throw archiveError("解压后的实际文件数据超过 4 GiB 安全上限。") }
                total = next
            default:
                throw archiveError("加密 ZIP 解压产生了符号链接或特殊文件，已回滚：\(url.lastPathComponent)")
            }
        }
    }

    private func validateEncryptedSources(_ sources: [URL]) throws {
        var names: [String: Bool] = [:]
        for source in sources {
            try validateEncryptedNode(source, relativePath: source.lastPathComponent, paths: &names)
        }
        // Check all ancestor components only after every entry has been indexed;
        // this catches parent/child conflicts independent of traversal order.
        for path in names.keys {
            var parent = (path as NSString).deletingLastPathComponent
            while !parent.isEmpty && parent != "." && parent != "/" {
                if let isDirectory = names[parent], !isDirectory {
                    throw archiveError("加密 ZIP 源路径将普通文件用作目录：\(parent)")
                }
                parent = (parent as NSString).deletingLastPathComponent
            }
        }
    }

    private func validateEncryptedNode(_ item: URL, relativePath: String,
                                       paths: inout [String: Bool]) throws {
        let components = relativePath.split(separator: "/", omittingEmptySubsequences: false)
        guard !relativePath.isEmpty, !relativePath.hasPrefix("/"), !relativePath.contains("\\"),
              !components.isEmpty, !components.contains(""), !components.contains("."), !components.contains(".."),
              !relativePath.unicodeScalars.contains(where: { CharacterSet.controlCharacters.contains($0) }) else {
            throw archiveError("加密 ZIP 源项目名称包含不安全路径：\(relativePath)")
        }
        var info = stat()
        guard item.withUnsafeFileSystemRepresentation({ Darwin.lstat($0, &info) }) == 0 else {
            throw POSIXError(POSIXErrorCode(rawValue: errno) ?? .EIO)
        }
        let kind = info.st_mode & S_IFMT
        if kind == S_IFLNK { throw archiveError("当前加密 ZIP 后端不保证保留符号链接，请关闭加密。") }
        guard kind == S_IFREG || kind == S_IFDIR else { throw archiveError("加密 ZIP 不支持 socket、FIFO 或设备节点：\(item.path)") }
        let folded = relativePath.lowercased()
        guard paths[folded] == nil else { throw archiveError("加密 ZIP 源项目存在重复或大小写冲突路径：\(relativePath)") }
        paths[folded] = kind == S_IFDIR
        guard kind == S_IFDIR else { return }
        let children = try FileManager.default.contentsOfDirectory(at: item, includingPropertiesForKeys: nil)
        if children.isEmpty { throw archiveError("当前加密 ZIP 后端不保证保留空目录，请关闭加密。") }
        for child in children {
            try validateEncryptedNode(child, relativePath: relativePath + "/" + child.lastPathComponent,
                                      paths: &paths)
        }
    }

    private func pathExistsNoFollow(_ url: URL) -> Bool {
        var info = stat()
        return url.withUnsafeFileSystemRepresentation { Darwin.lstat($0, &info) == 0 }
    }

    private func makeError(_ code: Int32, _ buffer: [CChar]) -> NSError {
        let detail = String(cString: buffer)
        return NSError(domain: "Hoshino.Archive", code: Int(code),
                       userInfo: [NSLocalizedDescriptionKey: detail.isEmpty ? "归档操作失败（错误码：\(code)）。" : detail])
    }

    private func archiveError(_ message: String) -> NSError {
        NSError(domain: "Hoshino.Archive", code: 1, userInfo: [NSLocalizedDescriptionKey: message])
    }
}
