import Foundation
import Combine

/// Shared preference for the single trash implementation in FileSystemService.
@MainActor final class RecycleBinService: ObservableObject {
    static let shared = RecycleBinService()
    @Published var isEnabled: Bool {
        didSet { UserDefaults.standard.set(isEnabled, forKey: "recycleBinEnabled") }
    }
    private init() { isEnabled = UserDefaults.standard.object(forKey: "recycleBinEnabled") as? Bool ?? true }
}
