import Foundation
import Combine
import SwiftUI

@MainActor
final class ClipboardStore: ObservableObject {
    static let shared = ClipboardStore()
    @Published private(set) var urls: [URL] = []
    @Published private(set) var isCut = false
    private init() {}
    func set(_ urls: [URL], cut: Bool) { self.urls = urls; isCut = cut }
    func clear() { urls = []; isCut = false }
    func remove(_ completed: [URL]) {
        let completedPaths = Set(completed.map { $0.standardizedFileURL.path })
        urls.removeAll { completedPaths.contains($0.standardizedFileURL.path) }
        if urls.isEmpty { isCut = false }
    }
}
