# Hoshino attribution and notices

Hoshino is a modified version of Fila by OwnGoal Studio. Fila's copyright and
MIT license notice are retained in `LICENSE`; third-party notices are shown in
the in-app Open Source Licenses screen.

The file-type icon catalogue and application icon in this build were sourced
from the Hoshino archive supplied for this modification. That archive did not
contain a license file or an explicit redistribution grant. The assets are
used here as requested by the project owner; verify the original author's
permission and applicable terms before redistributing this modified project.

The app's About screen names Fila and OwnGoal Studio as the upstream project.
No upstream endorsement is implied.
