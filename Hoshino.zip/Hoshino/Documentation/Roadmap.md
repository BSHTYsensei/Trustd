# Roadmap

What exists, what comes next, and what was deliberately left out. Nothing here
is a promise — it is a record of decisions so they don't get re-argued.

## Now

Hoshino is a local-first derivative of Fila. `filad` serves the privileged
local operations; the app browses, edits, copies, moves, deletes to the trash,
compresses, previews files, hosts a local terminal, browses installed-app
containers in the full jailbreak build, and accesses the music library where
that composition supports it. SMB, WebDAV, URL downloads and the WebDAV browser
UI are removed. The IPA/TIPA app-install action is removed. Debian package installation
remains available only through the local terminal; this is separate from app installation.

The part worth stating plainly, because it is what the package split bought:
the code that can destroy the user's filesystem is reachable from `swift test`
on a Mac, and that is where the two worst bugs so far were caught — a guard
that would have let `/var` be unlinked because the leaf symlink was never put
through it a second time, and a `copyfile` callback that answered
`COPYFILE_CONTINUE` on an error stage, so a partly-failed cross-volume move
deleted originals that had never copied.

Shipped with that slice, and no longer future work:

- `LocalFileAccess` with two implementations, chosen at handshake: XPC to
  `filad`, or `FilaFileOps` in-process for the `.tipa`, the `.ipa`, and the
  simulator. (`FileService` is now the backend-neutral protocol above both.)
- libarchive, statically linked, for the formats Fila reads and writes. 7z
  and RAR stay read-only.
- Runestone for the text editor.
- Tabs with a retained navigation stack each, and one `OperationCenter` for
  jobs, transfers and toasts.
- Script execution for supported local runtimes, launched as the app user.
- A *Save to Hoshino* share-sheet extension.
- The terminal: libghostty, a pty the daemon opens, and credentials dropped
  before the shell is spawned.
- Extensible local/domain modules. `Frameworks/` holds Local, Privileged,
  Applications and Music modules. Network transport modules are not shipped.
- Two compositions from one shell: `Fila` links every module, `HoshinoSandboxed`
  links only what a sandboxed process can use, and
  `Scripts/verify-composition.sh` reads the difference back out of the
  packaged binary.
- App Intents in `Hoshino/Shortcuts/`, read and write, over the same guarded
  operations the browser uses.
- Thirteen languages, one catalogue per target that shows a sentence.

Every push runs `.github/workflows/ci.yml`, which compiles, packages and
verifies both compositions; a version tag runs `.github/workflows/release.yml`,
which compiles nothing and publishes the four packages that run built. Local
`make check`, `make harness` and `make packages` remain the gate a change has
to pass before it is called done.

## Next

1. Content search: matching inside files, not only names. The walk already
   exists; what it needs is a bounded reader and a decision about binary files.
2. Re-query the daemon after the in-process fallback and rebind when it
   answers. Running jobs must move with it. See the note on
   `DaemonLink.graceBeforeFallback`.
3. Verify single-process mode on a real LiveContainer host: icon getter,
   `LSApplicationWorkspace` timing, and that no listed path hangs in
   `opendir`. A sandboxed Applications page could show this app's own
   container instead of hiding, if that is ever worth a row.

## Boundaries and intentionally omitted features

These are explicit product boundaries, not incomplete UI entries.

Script execution is implemented as an app-user feature, not a daemon operation.
JavaScript (`.js`) and restricted local CommonJS (`.cjs`) use JavaScriptCore;
`.mjs` uses Node when installed. Shell, Python, Lua, Ruby, Perl, AWK, PHP, R,
Tcl, Swift and Raku/Perl 6 are available only when the corresponding on-device
interpreter is detected. External interpreters run in a separate process group
with a 120-second default timeout (900-second maximum) and a 4 MiB output cap.
CommonJS modules are limited to local `.js`, `.cjs` and `.json` files under the
script's folder; Node built-ins and npm modules are not emulated. JavaScriptCore
execution has no public per-script hard timeout in this implementation.

The app uses `hoshino://` for its read-only navigation links and still accepts the legacy `fila://` scheme. The managed library lives in `Documents/Scripts`. Scripts can be imported,
enabled, disabled, deleted and run sequentially. The file menu and App Intents
also expose single-script execution and batch execution. Every run requires
confirmation and uses the app process identity; scripts never become a root
shell. Scripts that require root must be run manually in the terminal after
review.

| Feature | Note |
| --- | --- |
| Network transports | Removed. No SMB, WebDAV, FTP, SFTP, URL download or WebDAV server is included. |
| App Store distribution | The sandboxed `.ipa` composition ships, and it contains no private API by construction. That is not the same as an App Store audit, which nobody has done and no approval is claimed for. |
| Markdown preview | Asked for and declined. |
| SQLite browser | A viewer, but much larger than the others, and the only one that wants a real database engine rather than a parser. |
| Passcode / Face ID lock | Reasonable for an app that can read the whole filesystem. It is a feature rather than a setting. |
| A rootful `.deb` | Only roothide and rootless are built. The daemon resolves its own prefix, so rootful is close to free if wanted. |
| A Mac product | Not shipped. Hoshino is iOS only; the Mac is a test host for `FilaKit`. |
| A full audio/video editor | Playback and Now Playing are shipped. Trimming and waveform editing were evaluated and declined — see `Audio-Playback.md`. |

## Application installation

Installing `.ipa` or `.tipa` applications from the file manager is deliberately removed. The installed-app catalogue and container navigation remain in the full jailbreak composition; they only inspect existing apps and do not install or uninstall them. Debian package installation through the local terminal remains a separate system-package operation.

## Done, and where the decision is written down

| Was deferred | Now | Where |
| --- | --- | --- |
| Whole-device search | A daemon job that walks with an explicit `opendir` stack and never `stat`s an entry it is not going to return. The earlier note here said a daemon-side walk would allocate inside the 6 MB budget; that was true of `fts(3)` and not of the walk that was written. | `Architecture.md` |
| Archives | libarchive over descriptors. ZIP, TAR and the compressed TAR filters are writable; 7z and RAR are read-only. | `FilaFormats` |
| Mach-O and entitlement viewer | Built, including the entitlements plist out of the code-signature superblob. | `Hoshino/Interface/Viewer/` |
| App container jump | App-side through `LSApplicationWorkspace`. The documented limit is that nothing on disk links a bundle UUID to its data UUID, so the fallback scan finds bundles only. | `Packages/FilaKit/Sources/FilaApplications/ApplicationCatalog.swift` |
| Bookmarks, tabs, recents | App-side state. Each tab retains its navigation stack. | `Hoshino/Application/State/` |
| TrollStore / sideloaded packages | `make tipa` and `make ipa`, app only, no daemon — the in-process backend after the grace period. | `Scripts/package-ipa.sh` |
| Local file access | Two implementations, one handshake. Never a build flag. | `Architecture.md` |
| Text editor | Runestone, same atomic-save path. | `Hoshino/Interface/Viewer/` |
| Script execution | Local JavaScriptCore, restricted local CommonJS and detected external interpreters; app-user only. | `Hoshino/Services/Scripts/`, `Hoshino/Shortcuts/` |
| Files.app integration | Removed. The replicated File Provider could export only what `mobile` already reached, so the folder picker promised access it did not have. | `Architecture.md` |
