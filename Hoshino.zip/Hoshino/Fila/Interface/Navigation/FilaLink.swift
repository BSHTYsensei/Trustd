import Foundation

/// A `hoshino://` link, resolved into the one destination it means.
///
/// # Read-only by construction
///
/// **Every case below navigates, reveals or inspects. None of them changes the
/// filesystem, and none of them ever will.**
///
/// A URL scheme is an unauthenticated entry point. Any app on the device, and
/// any web page the user taps a link in, can open `hoshino://…`: there is no audit
/// token, no entitlement and no caller identity behind it, unlike every request
/// that reaches `filad`. The app is simply told to do something by a stranger —
/// and this app drives a root daemon.
///
/// So `hoshino://delete?path=/System` arriving from a web page has to be
/// impossible, and the way it is made impossible is *not* a confirmation
/// dialog: it is that there is no `delete` case here for the parser to produce.
/// A reviewer checks that boundary by reading this one enum. Write verbs would
/// need a design where the app shows exactly what is about to happen and the
/// user confirms it against the real path — a different piece of work, not an
/// extension of this one.
///
/// Read-only is not a reason to trust the bytes. Every path is bounded and
/// canonicalised by `canonical(_:)` before it leaves this file, and `filad`
/// calls `realpath(3)` and runs `FilaGuard` again on whatever finally reaches
/// it. That is defence in depth, not an excuse for the first layer.
enum FilaLink: Equatable {
    case activate
    /// Show a directory, or a file selected in its folder:
    /// `hoshino:///var/mobile/Documents`, `hoshino://open?path=…`, and Filza's
    /// `hoshino://view/var/mobile/Documents`. A link cannot know which of the two
    /// it names, so the router asks before it navigates.
    case locate(String)
    /// A path the caller already knows is a directory. No URL produces it:
    /// it is *Show Original* on a link to a folder.
    case directory(String)
    /// `hoshino://open?path=…&tab=new`, with the same file rule as `locate`.
    case newTab(String)
    /// `hoshino://reveal?path=…` — the parent directory of the item.
    case reveal(String)
    /// `hoshino://view?path=…`.
    case view(String)
    /// `hoshino://info?path=…`.
    case info(String)
    /// `hoshino://search?query=…[&path=/where]`.
    case search(query: String, root: String)
    /// `hoshino://app?bundle=com.example.thing[&container=bundle|data]`.
    case app(bundle: String, container: AppContainer)
    /// `hoshino://apps`.
    case installedApps
    /// `hoshino://settings`.
    case settings

    enum AppContainer: String {
        case bundle
        case data
    }
}

extension FilaLink {
    static let scheme = "hoshino"
    static let legacyScheme = "fila"

    /// `PATH_MAX`. A longer string cannot name a file, so it is not a path — it
    /// is somebody finding out how much the parser will swallow.
    static let pathByteLimit = 1024
    /// A search needle is typed by a person; anything longer is not one.
    static let queryByteLimit = 256
    /// Longer than any reverse-DNS identifier the system will install.
    static let bundleByteLimit = 256

    /// The single place that decides what a `hoshino://` URL means. Everything it
    /// does not recognise returns nil, and the caller says so out loud.
    init?(_ url: URL) {
        guard let incomingScheme = url.scheme?.lowercased(),
              incomingScheme == Self.scheme || incomingScheme == Self.legacyScheme,
              let components = URLComponents(url: url, resolvingAgainstBaseURL: false)
        else { return nil }

        // First value wins. A duplicated key is either a mistake or an attempt
        // to make the link read one way and act another; either way, the
        // leftmost spelling is the one a person reading the URL sees.
        var values: [String: String] = [:]
        for item in components.queryItems ?? [] {
            guard let value = item.value else { continue }
            let name = item.name.lowercased()
            if values[name] == nil {
                values[name] = value
            }
        }
        let wantsNewTab = values["tab"]?.lowercased() == "new"

        // No host means the path is the destination: `hoshino:///var/mobile` is
        // the natural spelling and the one people guess. `hoshino://var/mobile`
        // is not it — that names the verb "var" — and failing visibly there
        // teaches the third slash.
        let verb = components.host?.lowercased() ?? ""
        guard !verb.isEmpty else {
            if components.path.isEmpty, components.query == nil, components.fragment == nil {
                self = .activate
                return
            }
            guard let path = Self.canonical(components.path) else { return nil }
            self = wantsNewTab ? .newTab(path) : .locate(path)
            return
        }

        switch verb {
        case "open":
            guard let path = Self.path(values) else { return nil }
            self = wantsNewTab ? .newTab(path) : .locate(path)
        case "reveal":
            guard let path = Self.path(values) else { return nil }
            self = .reveal(path)
        case "view":
            if components.queryItems?.contains(where: { $0.name.lowercased() == "path" }) == true {
                guard let path = Self.path(values) else { return nil }
                self = .view(path)
            } else {
                guard let path = Self.canonical(components.path) else { return nil }
                self = .locate(path)
            }
        case "info":
            guard let path = Self.path(values) else { return nil }
            self = .info(path)
        case "search":
            guard let query = values["query"], Self.isPlausibleQuery(query) else { return nil }
            // Searching from `/` is the useful default: a link that names a
            // needle and no root wants the whole device.
            self = .search(query: query, root: Self.path(values) ?? "/")
        case "app":
            guard let bundle = values["bundle"], Self.isBundleIdentifier(bundle) else { return nil }
            let container = values["container"]?.lowercased()
            self = .app(bundle: bundle, container: container.flatMap(AppContainer.init(rawValue:)) ?? .bundle)
        case "apps":
            self = .installedApps
        case "settings":
            self = .settings
        default:
            return nil
        }
    }

    private static func path(_ values: [String: String]) -> String? {
        values["path"].flatMap(canonical)
    }

    /// Bounds and canonicalises a path handed over by a stranger.
    ///
    /// Absolute, no NUL, no longer than a path can be, empty and repeated
    /// separators dropped, and `.` / `..` collapsed so a link cannot spell one
    /// place and mean another.
    ///
    /// The collapse is lexical, so `a/b/..` resolves differently here than on
    /// disk when `b` is a symlink. That costs nothing: every verb in this file
    /// is read-only, and the daemon canonicalises with `realpath(3)` and runs
    /// `FilaGuard` on whatever it is finally asked for.
    static func canonical(_ path: String) -> String? {
        guard path.hasPrefix("/"), path.utf8.count <= pathByteLimit, !path.contains("\0") else { return nil }
        var stack: [Substring] = []
        for component in path.split(separator: "/") {
            switch component {
            case ".": continue
            case "..": _ = stack.popLast()
            default: stack.append(component)
            }
        }
        return "/" + stack.joined(separator: "/")
    }

    static func isPlausibleQuery(_ query: String) -> Bool {
        !query.isEmpty && query.utf8.count <= queryByteLimit && !query.contains("\0")
    }

    /// Reverse-DNS, near enough. The point is not to validate an identifier the
    /// installation database will validate anyway — it is that this string gets
    /// compared against every installed app's identifier, so it must be a short
    /// run of the characters an identifier can contain and nothing else. ASCII
    /// only: a Cyrillic `а` that looks like an `a` has no business matching one.
    static func isBundleIdentifier(_ identifier: String) -> Bool {
        guard !identifier.isEmpty, identifier.utf8.count <= bundleByteLimit else { return false }
        return identifier.unicodeScalars.allSatisfy {
            ("a" ... "z").contains($0) || ("A" ... "Z").contains($0) || ("0" ... "9").contains($0)
                || $0 == "." || $0 == "-" || $0 == "_"
        }
    }
}
