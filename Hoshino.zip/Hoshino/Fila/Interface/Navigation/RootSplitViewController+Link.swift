import FilaBackendKit
import FilaBackendUI
import FilaLog
import FilaProtocol
import UIKit

/// Where a `fila://` link ends up.
///
/// The parser (`FilaLink`) decides what a URL means and this decides what to
/// show for it — one exhaustive switch, so a verb added to the enum cannot be
/// quietly forgotten here. Every branch navigates, reveals or inspects; there
/// is nothing to confirm because there is nothing destructive to confirm.
extension RootSplitViewController {
    /// Every URL a scene hands us — a cold launch through
    /// `connectionOptions.urlContexts`, a warm one through
    /// `scene(_:openURLContexts:)`.
    func follow(_ contexts: Set<UIOpenURLContext>) {
        // A `file:` URL is not a link: it is a file the system already copied
        // into this app's Inbox for *Copy to Fila*. One panel for the whole
        // batch, and never through `FilaLink` — see `importFiles`.
        let files = contexts.map(\.url).filter(\.isFileURL)
        if !files.isEmpty {
            importFiles(files)
        }
        for context in contexts where !context.url.isFileURL {
            follow(context.url)
        }
    }

    func follow(_ url: URL) {
        // Deferred a turn rather than acted on inline: on a cold launch this is
        // called while the scene is still connecting, and the split view has
        // not finished laying itself out — a push or a present from inside that
        // window either animates from nowhere or is dropped.
        Task { @MainActor in
            guard let link = FilaLink(url) else {
                // An unauthenticated entry point — anything on the device can
                // hand this app a URL — so both outcomes are written down.
                FilaLog.warning("link not recognised: \(url)")
                self.reportUnrecognized(url)
                return
            }
            FilaLog.info("following link \(url)")
            if link == .activate {
                return
            }
            await FileSession.shared.ready()
            self.follow(link)
        }
    }

    /// Not private: *Show Original* on a symlink, a search hit and a module's
    /// reveal want exactly what `fila://reveal` and `fila://open` already do —
    /// a directory is opened, a file is revealed with its row selected — and a
    /// second copy of that would be a second place for them to drift apart.
    /// Everything else still arrives as a URL.
    func follow(_ link: FilaLink) {
        switch link {
        case .activate:
            return
        case let .locate(path):
            let navigation = content.navigation
            locate(path) { folder, name in
                // Another tab chosen meanwhile is the person's choice, and
                // the link does not pull them back. A cold launch still
                // connecting had no tab to choose from: the first one
                // arriving during the lookup is not a choice.
                guard navigation == nil || self.content.navigation === navigation else { return }
                self.open(folder, select: name)
            }
        case let .directory(path):
            open(path)
        case let .newTab(path):
            // A `tab` flag on `open` rather than a `tab` verb: a tab is one
            // place the app can be, so `open` with `tab=new` is `open` plus one
            // bit — a separate verb would spell the same destination twice.
            //
            // Capped, and the cap drops the *new* tab rather than an old one:
            // this list is on the other side of an unauthenticated entry point,
            // so a page that keeps sending links must not be able to grow a
            // preference without bound — nor to push a person's own tabs out of
            // the switcher. `BrowserTabStore.limit` is the number, and
            // `BrowserTabStore.openFromLink` is where it is enforced.
            locate(path) { folder, name in
                self.openFromLink(folder, select: name)
            }
        case let .reveal(path):
            // The folder the item is in, and the row itself once the page
            // carrying it arrives — the listing streams, so the row does not
            // exist yet at this point and may never exist at all.
            open(parent(of: path), select: (path as NSString).lastPathComponent)
        case let .view(path):
            // These three wait on the daemon rather than failing while it is
            // still coming up. `filad` is on-demand and a link can easily
            // arrive during the second the app spends saying *Connecting…*;
            // dropping the destination there would look like the scheme not
            // working. `FileSession.perform` awaits the handshake itself, so
            // this is simply a request that takes a moment.
            Task { await self.openFile(at: path, session: FileSession.shared) }
        case let .info(path):
            showProperties(of: path)
        case let .search(query, root):
            search(query, in: root)
        case let .app(bundle, container):
            openApp(bundle: bundle, container: container)
        case .installedApps:
            guard let screen = SidebarLocation.screen(for: .root(of: .applications)) else {
                presentMessage(String(localized: "Applications Unavailable"), message: applicationsUnavailableMessage)
                return
            }
            push(screen)
        case .settings:
            presentSettings()
        }
    }

    /// Why a link into Applications went nowhere. A copy without the backend
    /// — the sandboxed composition, a module that failed to bootstrap, or one
    /// that found no local backend to read through — is a different sentence
    /// from a copy that has the module and cannot see past its own sandbox.
    private var applicationsUnavailableMessage: String {
        BackendComposition.registry.backend(.applications) == nil
            ? String(localized: "Applications are not included in this copy of Hoshino.")
            : String(localized: "Hoshino cannot see other apps on this device.")
    }

    /// Where a linked path is shown: a directory is the folder itself, and
    /// anything else is its parent with the item's name to select. A link only
    /// spells a path, so this asks what is there first. A path that cannot be
    /// read is reported, rather than opened as a folder that fails to list.
    private func locate(_ path: String, then show: @escaping @MainActor (_ folder: String, _ name: String?) -> Void) {
        Task {
            do {
                let details = try await FileSession.shared.perform(retryOnDisconnect: true) { try await $0.details(of: path) }
                guard self.viewIfLoaded?.window != nil else { return }
                if details.node.isNavigable {
                    show(path, nil)
                } else {
                    show(self.parent(of: path), (path as NSString).lastPathComponent)
                }
            } catch let failure as FilaFailure {
                TopPresenter.whenReady(from: self) { $0.report(failure) }
            } catch {}
        }
    }

    /// A path's directory. `deletingLastPathComponent` on `/etc` gives `/`,
    /// which is right, and on `/` gives `/`, which is also right — revealing
    /// the volume root shows the volume root.
    private func parent(of path: String) -> String {
        let parent = (path as NSString).deletingLastPathComponent
        return parent.isEmpty ? "/" : parent
    }

    private func showProperties(of path: String) {
        Task {
            let session = FileSession.shared
            do {
                let details = try await session.perform(retryOnDisconnect: true) { try await $0.details(of: path) }
                // Over whatever is up — another sheet, a card — rather than
                // from the root, which UIKit refuses while it presents one.
                TopPresenter.whenReady(from: self) { top in
                    top.presentAsSheet(
                        UINavigationController(rootViewController: PropertiesViewController(
                            details: details,
                            link: session.link,
                        )),
                    )
                }
            } catch let failure as FilaFailure {
                TopPresenter.whenReady(from: self) { $0.report(failure) }
            } catch {}
        }
    }

    private func search(_ query: String, in root: String) {
        push(SearchViewController(root: root, query: query))
    }

    private func openApp(bundle: String, container: FilaLink.AppContainer) {
        Task {
            // Waits on the daemon for the same reason the file verbs do: the
            // fallback source lists containers through it, so asking before the
            // handshake lands would answer "not installed" for an app that is.
            await FileSession.shared.ready()
            guard let applications = SystemCapabilities.applications, applications.isEnabled else {
                self.presentMessage(String(localized: "Applications Unavailable"), message: self.applicationsUnavailableMessage)
                return
            }
            guard let app = await applications.locate(bundleIdentifier: bundle) else {
                self.presentMessage(
                    String(localized: "App Not Found"),
                    message: String(localized: "“\(bundle)” is not installed on this device."),
                )
                return
            }
            switch container {
            case .bundle:
                self.open(app.bundlePath)
            case .data:
                // Absent whenever the installation database could not be read —
                // see `ApplicationCatalog`. Saying so beats silently showing the
                // bundle instead and letting the user work out why.
                guard let data = app.dataPath else {
                    self.presentMessage(
                        String(localized: "No App Data"),
                        message: String(localized: "Hoshino could not find App Data for \(app.name)."),
                    )
                    return
                }
                self.open(data)
            }
        }
    }

    /// A scheme that silently does nothing is indistinguishable from a broken
    /// app, so an unrecognised link says so — and says so as a sentence, never
    /// as a crash. The URL is echoed back truncated: it came from a stranger
    /// and an alert is not a place to render an arbitrary kilobyte.
    private func reportUnrecognized(_ url: URL) {
        presentMessage(
            String(localized: "Unsupported Link"),
            message: String(localized: "Hoshino cannot open this link. Check the address and try again.")
                + "\n\n" + String(url.absoluteString.prefix(200)),
        )
    }
}
