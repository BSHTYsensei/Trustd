import AlertController
import FilaBackendKit
import FilaBackendUI
import FilaClient
import FilaProtocol
import UIKit

/// Browser navigation, selection, and transfer UI. File actions are shared
/// with previews and editors through `FileActions`.
///
/// None of this decides whether an operation is allowed — `FilaGuard` runs in
/// the daemon and is the only thing that does. A greyed item here is a courtesy
/// to save a round trip, nothing more.
extension FileBrowserViewController {
    var deleteTitle: String {
        FileActions.deleteTitle
    }

    private var fileActions: FileActions {
        FileActions(presenter: self, directory: directory, removals: self)
    }

    // MARK: - Menus

    func contextMenu(for node: FileNode) -> UIMenu {
        let path = path(of: node)
        var file: [UIMenuElement] = []
        // Only folders: a tab is somewhere to be, and "open this PNG in a new
        // tab" has no answer that is not a viewer with no way back. Not in the
        // trash, where `FileActions` hands back Put Back and little else.
        if node.isNavigable, !isTrash {
            // Alone in its group: a folder's menu leads with where else the
            // folder can go, then everything that acts on it here.
            file.append(UIMenu(options: .displayInline, children: [
                UIAction(
                    title: String(localized: "Open in New Tab"),
                    image: UIImage(systemName: "plus.square.on.square"),
                ) { [weak self] _ in
                    self?.shell?.openInNewTab(path)
                },
            ]))
        }
        // A link's row now draws its target's icon, so "where does this
        // actually go" is the question the row raises and this is the answer to
        // it. Disabled rather than absent when the link dangles: the item
        // missing would read as the menu not having it, and an alert after the
        // tap makes a person ask a question they could have been spared.
        if node.kind == .symbolicLink, !isTrash, let link = node.link {
            let broken = link.isBroken
            file.append(UIAction(
                title: String(localized: "Show Original"),
                subtitle: broken ? String(localized: "The original item no longer exists.") : nil,
                image: UIImage(systemName: "arrowshape.turn.up.right.circle"),
                attributes: broken ? .disabled : [],
            ) { [weak self] _ in
                guard let self, let original = originalPath(of: node) else { return }
                // A directory is somewhere to be, a file is something to be
                // shown in its folder — the router's `.directory` and
                // `.reveal`, where `fila://` links land, so it goes through
                // them rather than past them. The kind is already known, so
                // there is no lookup. Both re-root the tab: see
                // `open(directory:)` for why going anywhere that is not a
                // child of this folder is a jump.
                shell?.follow(link.resolvedKind == .directory ? .directory(original) : .reveal(original))
            })
        }

        // No title: the menu was opened on the row, and its name is the row.
        return UIMenu(
            children: fileActions.menuElements(
                for: path,
                node: node,
                additional: file,
                select: isEditing ? nil : { [weak self] in self?.select(node) },
                preview: { [weak self] in self?.preview(node) },
            ),
        )
    }

    /// Takes the trash's place in the folder menu, where New would be. Not
    /// while the listing still streams: emptying what has arrived so far
    /// would leave the rest with a confirmation that named the wrong count.
    func emptyTrashAction() -> UIAction {
        UIAction(
            title: String(localized: "Empty Trash"),
            image: UIImage(systemName: "trash"),
            attributes: items.isEmpty || isLoading ? [.destructive, .disabled] : .destructive,
        ) { [weak self] _ in
            guard let self else { return }
            // Every entry, hidden ones included: the trash is emptied, not the
            // view of it. The permanent-delete confirmation names the count.
            delete(items.map(path(of:)), permanently: true)
        }
    }

    /// Put Back is not a job, so nothing tells this list to reload but the
    /// action itself — which `removalDidEnd` does.
    func putBack(_ paths: [String]) {
        fileActions.putBack(paths)
    }

    /// Where a symlink actually points, as a path something can be asked for.
    ///
    /// A target is whatever string `readlink(2)` gave back: absolute, or
    /// relative to the directory the link is in — `/etc -> private/etc` is the
    /// second kind and is the common one. The `..` in a relative target is
    /// folded away by `standardizedFileURL`, which is lexical and touches no
    /// file; resolving it for real is `realpath(3)` in the daemon, which runs
    /// on whatever finally arrives there anyway.
    func originalPath(of node: FileNode) -> String? {
        guard let target = node.link?.target, !target.isEmpty else { return nil }
        let joined = target.hasPrefix("/") ? target : (directory as NSString).appendingPathComponent(target)
        return URL(fileURLWithPath: joined).standardizedFileURL.path
    }

    /// The ellipsis menu, top to bottom: what acts on this folder, then its
    /// display as two switches, then creating something, then where to go.
    ///
    /// "More" used to hold the row actions one level down, and View and Hidden
    /// Files were two-option submenus of a two-option kind: a menu that is
    /// opened for a folder should say what can be done with it in its first
    /// group, and a choice of two belongs in one switch, not a submenu.
    func browserMenuElements(folderAction: UIMenuElement, selectAction: UIAction) -> [UIMenuElement] {
        let actions: [UIMenuElement] = [
            selectAction,
            favoriteToggleAction(keepsMenuOpen: true),
            UIAction(
                title: String(localized: "Open in New Tab"),
                image: UIImage(systemName: "plus.square.on.square"),
            ) { [weak self] _ in
                guard let self else { return }
                shell?.openInNewTab(directory)
            },
        ]
        let display: [UIMenuElement] = [
            layoutToggleAction(),
            hiddenFilesToggleAction(),
            UIMenu(
                title: String(localized: "Sort By"),
                image: UIImage(systemName: "arrow.up.arrow.down"),
                children: sortMenuElements(),
            ),
        ]
        // Collapsed, the leading bookmark opens the Places page, so this menu
        // need not offer the same destinations a second time. A wide layout
        // keeps Go: there the bookmark only brings the column back.
        let narrow = traitCollection.horizontalSizeClass == .compact
        let navigation: [UIMenuElement] = [
            narrow ? nil : UIMenu(
                title: String(localized: "Go"),
                image: UIImage(systemName: "arrow.right.circle"),
                children: goMenuElements(),
            ),
            settingsMenuElement,
        ].compactMap { $0 }
        return FilaMenu.groups(actions, display, [folderAction], navigation)
    }

    /// The layout the list is in now, named and pictured: "Show as List" while
    /// it is a list, "Show as Grid" once it is a grid. Tapping flips to the
    /// other one and the row turns with it, so what it says is always the
    /// state rather than a promise about the next tap.
    private func layoutToggleAction() -> UIAction {
        let isList = session.layout(for: directory) == .list
        return UIAction(
            title: isList ? String(localized: "Show as List") : String(localized: "Show as Grid"),
            image: UIImage(systemName: isList ? "list.bullet" : "square.grid.2x2"),
            attributes: Self.staysOpenWhileToggling,
        ) { [weak self] _ in
            guard let self else { return }
            session.setLayout(isList ? .grid : .list, for: directory)
            viewPreferenceChanged(relayout: true)
            refreshMoreMenu()
        }
    }

    /// The same shape for hidden files: one switch, wording first, mark on the
    /// state — it used to be Show/Hide inside a submenu called Hidden Files.
    private func hiddenFilesToggleAction() -> UIAction {
        let shows = session.showsHidden
        return UIAction(
            title: String(localized: "Show Hidden Files"),
            image: UIImage(systemName: "eye"),
            attributes: Self.staysOpenWhileToggling,
            state: shows ? .on : .off,
        ) { [weak self] _ in
            guard let self else { return }
            session.setShowsHidden(!shows)
            viewPreferenceChanged(relayout: false)
            refreshMoreMenu()
        }
    }

    /// A switch that closed the menu would make a person open it again to see
    /// what it did. iOS 16 knows the attribute; before it, a tap still closes
    /// the menu and the marks are read on the next opening.
    private static var staysOpenWhileToggling: UIMenuElement.Attributes {
        if #available(iOS 16.0, *) {
            return [.keepsMenuPresented]
        }
        return []
    }

    /// This folder into or out of the favourites, worded for its state when
    /// the menu is built.
    ///
    /// `keepsMenuOpen` is for the ellipsis, a bar button item: handing its item
    /// a rebuilt menu repaints the presented menu where it stands, so the row
    /// flips under the finger. The breadcrumb's current crumb is a `UIButton`,
    /// and its menu is presented again when it is handed a new one — there the
    /// row would blink closed and open, so that menu closes as it always has.
    private func favoriteToggleAction(keepsMenuOpen: Bool = false) -> UIAction {
        let favorite = session.isFavorite(directory)
        return UIAction(
            title: favorite
                ? String(localized: "Remove from Favorites")
                : String(localized: "Add to Favorites"),
            image: UIImage(systemName: favorite ? "star.slash" : "star"),
            attributes: keepsMenuOpen ? Self.staysOpenWhileToggling : [],
        ) { [weak self] _ in
            guard let self else { return }
            session.toggleFavorite(directory)
            if keepsMenuOpen {
                refreshMoreMenu()
            }
        }
    }

    /// A tap on the current breadcrumb: this folder in or out of the
    /// favourites, then the favourites to jump to. The toggle means the menu
    /// is never empty, and it is what the star beside the crumb promises.
    func makeCurrentCrumbMenu() -> UIMenu {
        UIMenu(children: [
            UIMenu(options: .displayInline, children: [
                UIAction(title: String(localized: "Go to Path…")) { [weak self] _ in
                    self?.promptGoToPath()
                },
                UIDeferredMenuElement.uncached { [weak self] completion in
                    completion(self.map { [$0.favoriteToggleAction()] } ?? [])
                },
            ]),
            UIMenu(options: .displayInline, children: [
                FilaMenu.favoriteItems { [weak self] path in self?.open(directory: path) },
            ]),
        ])
    }

    /// A long press on the current breadcrumb: the rows of Go › Places,
    /// built when the menu opens so the capabilities are current.
    /// No title: the menu is the places, and a heading over them says nothing
    /// the rows do not.
    func makeCurrentCrumbPlacesMenu() -> UIMenu {
        UIMenu(children: [
            UIDeferredMenuElement.uncached { [weak self] completion in
                completion(FilaMenu.placeActions(
                    open: { [weak self] path in self?.open(directory: path) },
                    openLocation: { [weak self] location in self?.openLocation(location) },
                ))
            },
        ])
    }

    private func goMenuElements() -> [UIMenuElement] {
        FilaMenu.destinations { [weak self] in
            self?.promptGoToPath()
        } open: { [weak self] path in
            self?.open(directory: path)
        } openLocation: { [weak self] location in
            self?.openLocation(location)
        }
    }

    /// A catalogue or a share replaces the tab's page, as its sidebar row does.
    private func openLocation(_ location: BackendLocation) {
        guard let screen = SidebarLocation.screen(for: location) else { return }
        shell?.replace(screen)
    }

    func sortMenuElements() -> [UIMenuElement] {
        let titles: [FileSortKey: String] = [
            .name: String(localized: "Name"),
            .date: String(localized: "Date"),
            .size: String(localized: "Size"),
            .kind: String(localized: "Kind"),
        ]
        let keys = FileSortKey.allCases.map { key in
            UIAction(
                title: titles[key] ?? key.rawValue,
                state: session.sortKey == key ? .on : .off,
            ) { [weak self] _ in
                guard let self else { return }
                session.setSort(key: key, ascending: session.sortAscending)
                viewPreferenceChanged(relayout: false)
            }
        }
        let directions = [true, false].map { ascending in
            UIAction(
                title: ascending ? String(localized: "Ascending") : String(localized: "Descending"),
                state: session.sortAscending == ascending ? .on : .off,
            ) { [weak self] _ in
                guard let self else { return }
                session.setSort(key: session.sortKey, ascending: ascending)
                viewPreferenceChanged(relayout: false)
            }
        }
        return [
            UIMenu(options: [.displayInline, .singleSelection], children: keys),
            UIMenu(options: [.displayInline, .singleSelection], children: directions),
        ]
    }

    func newMenu() -> UIMenu {
        UIMenu(title: String(localized: "New"), image: UIImage(systemName: "plus"), children: FilaMenu.groups([
            UIAction(
                title: String(localized: "Folder"),
                image: UIImage(systemName: "folder.badge.plus"),
            ) { [weak self] _ in
                self?.promptCreate(.directory)
            },
            UIAction(
                title: String(localized: "Text File"),
                image: UIImage(systemName: "doc.badge.plus"),
            ) { [weak self] _ in
                self?.promptCreate(.emptyFile)
            },
            UIAction(
                title: String(localized: "Symbolic Link"),
                image: UIImage(systemName: "arrowshape.turn.up.right"),
            ) { [weak self] _ in
                self?.promptCreateLink()
            },
        ], [
            UIAction(
                title: String(localized: "Import Photos…"),
                image: UIImage(systemName: "photo.on.rectangle"),
            ) { [weak self] _ in
                self?.importPhotos()
            },
            UIAction(
                title: String(localized: "Import Files…"),
                image: UIImage(systemName: "square.and.arrow.down"),
            ) { [weak self] _ in
                self?.importDocuments()
            },
        ]))
    }

    // MARK: - Operations

    func takeSelection(cut: Bool) {
        let paths = selectedPaths()
        guard !paths.isEmpty else { return }
        FileClipboard.shared.take(paths, cut: cut)
        setEditing(false, animated: true)
    }

    func paste(mode: TransferMode) {
        // Nothing is created in the trash, by any route: a pasted item would
        // sit there with no origin to put it back to.
        guard !isTrash, !FileClipboard.shared.isEmpty else { return }
        recordDirectoryUse()
        ClipboardPaste.paste(into: .local(directory), mode: mode, from: self)
    }

    func delete(_ paths: [String], permanently: Bool = false) {
        fileActions.delete(paths, permanently: permanently)
    }

    func presentSearch() {
        recordDirectoryUse()
        navigationController?.pushViewController(SearchViewController(root: directory, scope: .folder), animated: true)
    }

    // MARK: - Prompts

    func promptCreate(_ template: NodeTemplate) {
        guard !isTrash else { return }
        recordDirectoryUse()
        let title = template == .directory
            ? String.LocalizationValue("New Folder")
            : String.LocalizationValue("New Text File")
        let initial = template == .directory ? "" : String(localized: "Untitled.txt")
        prompt(
            title: title,
            message: String.LocalizationValue("Enter a name for the new item in this folder."),
            placeholder: template == .directory
                ? String.LocalizationValue("Folder name")
                : String.LocalizationValue("File name"),
            initial: initial,
            confirm: String.LocalizationValue("Create"),
        ) { [weak self] name in
            guard let self, !name.isEmpty else { return }
            guard FileActions.isItemName(name) else { return refuseName(name) }
            let path = path(ofName: name)
            run { try await $0.create(template, at: path) }
        }
    }

    /// The same refusal Rename gives: a typed slash or `..` would create the
    /// item outside the folder the prompt promised.
    private func refuseName(_ name: String) {
        FileActions.refuseName(name)
    }

    /// The target is picked, not typed: the folder panel in its file-picking
    /// mode, then one name prompt already filled with the target's own name.
    func promptCreateLink() {
        let picker = SaveDestinationViewController(
            picksFiles: true,
            link: session.link,
        ) { [weak self] target in
            guard let self else { return }
            prompt(
                title: String.LocalizationValue("New Symbolic Link"),
                message: String.LocalizationValue("Enter a name for the link to the item you chose."),
                placeholder: String.LocalizationValue("Link name"),
                initial: target.lastPathComponent,
                confirm: String.LocalizationValue("Create"),
            ) { [weak self] name in
                guard let self, !name.isEmpty else { return }
                guard FileActions.isItemName(name) else { return refuseName(name) }
                let path = path(ofName: name)
                run { try await $0.create(.symbolicLink(target: target.path), at: path) }
            }
        }
        presentAsSheet(UINavigationController(rootViewController: picker))
    }

    /// A long press on the navigation bar's title. The title is the app's own —
    /// `navigationItem.title`, not a view of ours — so the gesture goes on the
    /// bar and only answers between the leading and trailing controls, which is
    /// where the title is. Nothing else on the bar is touched by it.
    @objc private func handleTitleLongPress(_ gesture: UILongPressGestureRecognizer) {
        guard gesture.state == .began, navigationController?.topViewController === self,
              let bar = gesture.view else { return }
        let point = gesture.location(in: bar)
        let titleZone = (bar.bounds.width / 4) ..< (bar.bounds.width * 3 / 4)
        guard titleZone.contains(point.x), !(bar.hitTest(point, with: nil) is UIControl) else { return }
        promptGoToPath()
    }

    /// Called once a page has a bar to hang it on.
    func installTitleLongPress() {
        guard titleLongPress == nil, let bar = navigationController?.navigationBar else { return }
        let press = UILongPressGestureRecognizer(target: self, action: #selector(handleTitleLongPress(_:)))
        bar.addGestureRecognizer(press)
        titleLongPress = press
    }

    func promptGoToPath() {
        promptForPath(initial: directory) { [weak self] path in
            self?.open(directory: path)
        }
    }

    private func prompt(
        title: String.LocalizationValue,
        message: String.LocalizationValue,
        placeholder: String.LocalizationValue,
        initial: String,
        confirm: String.LocalizationValue,
        handler: @escaping (String) -> Void,
    ) {
        let alert = AlertInputViewController(
            title: title,
            message: message,
            placeholder: placeholder,
            text: initial,
            doneButtonText: confirm,
            onConfirm: handler,
        ).typingLiterally()
        present(alert, animated: true)
    }

    // MARK: - Plumbing

    private func run(_ body: @escaping (any LocalFileAccess) async throws -> Void) {
        Task { [weak self] in
            guard let self else { return }
            do {
                try await session.perform(body)
            } catch let failure as FilaFailure {
                self.report(failure)
            } catch {}
            reload()
        }
    }
}
