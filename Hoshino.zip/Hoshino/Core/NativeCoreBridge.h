#ifndef HOSHINO_NATIVE_CORE_BRIDGE_H
#define HOSHINO_NATIVE_CORE_BRIDGE_H
#include <stddef.h>
#include <stdint.h>
#ifdef __cplusplus
extern "C" {
#endif
int HoshinoCoreTransfer(const char *source, const char *destination, int operation, int replace, char *error, size_t errorCapacity);
int HoshinoCoreMergeDirectory(const char *source, const char *destination, int moveSource, char *error, size_t errorCapacity);
int HoshinoCoreCreateDirectory(const char *path, char *error, size_t errorCapacity);
int HoshinoCoreCreateFile(const char *path, char *error, size_t errorCapacity);
int HoshinoCoreCreateSymlink(const char *target, const char *linkPath, char *error, size_t errorCapacity);
int HoshinoCoreCreateHardlink(const char *source, const char *linkPath, char *error, size_t errorCapacity);
int HoshinoCoreRemoveItem(const char *path, char *error, size_t errorCapacity);
int HoshinoCoreSetPermissions(const char *path, uint32_t mode, int recursive, int followSymlinks, char *error, size_t errorCapacity);
int HoshinoCoreSetOwner(const char *path, uint32_t uid, uint32_t gid, int recursive, int followSymlinks, char *error, size_t errorCapacity);
int HoshinoCoreSetXAttr(const char *path, const char *name, const void *bytes, size_t length, int followSymlinks, char *error, size_t errorCapacity);
int HoshinoCoreRemoveXAttr(const char *path, const char *name, int followSymlinks, char *error, size_t errorCapacity);
#ifdef __cplusplus
}
#endif
#endif
