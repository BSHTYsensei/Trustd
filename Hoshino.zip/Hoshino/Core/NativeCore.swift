import Foundation
import Darwin

/// Typed Swift facade over the C++17 filesystem engine. SwiftUI never handles C++ objects.
enum NativeCore {
    enum Transfer { case copy, move, rename }

    static func transfer(_ source: URL, to destination: URL, operation: Transfer, replace: Bool = false) throws {
        let op: Int32 = operation == .copy ? 0 : (operation == .move ? 1 : 2)
        do {
            try withErrorBuffer { buffer in
                source.path.withCString { s in destination.path.withCString { d in
                    HoshinoCoreTransfer(s, d, op, replace ? 1 : 0, buffer, 1024)
                }}
            }
        } catch {
            guard RootHelperService.shouldRetry(error) else { throw error }
            try RootHelperService.transfer(source, to: destination, operation: operation, replace: replace)
        }
    }

    static func mergeDirectory(_ source: URL, into destination: URL, moveSource: Bool) throws {
        RootHelperService.startIfNeeded()
        if RootHelperService.isRunning {
            try RootHelperService.mergeDirectory(source, into: destination, moveSource: moveSource)
            return
        }
        try withErrorBuffer { buffer in
            source.path.withCString { sourcePath in
                destination.path.withCString { destinationPath in
                    HoshinoCoreMergeDirectory(sourcePath, destinationPath, moveSource ? 1 : 0, buffer, 1024)
                }
            }
        }
    }

    static func createDirectory(_ url: URL) throws {
        do { try withErrorBuffer { buffer in url.path.withCString { path in HoshinoCoreCreateDirectory(path, buffer, 1024) } } }
        catch { guard RootHelperService.shouldRetry(error) else { throw error }; try RootHelperService.createDirectory(url) }
    }

    static func createFile(_ url: URL) throws {
        do { try withErrorBuffer { buffer in url.path.withCString { path in HoshinoCoreCreateFile(path, buffer, 1024) } } }
        catch { guard RootHelperService.shouldRetry(error) else { throw error }; try RootHelperService.createFile(url) }
    }

    static func createSymbolicLink(target: URL, at linkURL: URL) throws {
        do {
            try withErrorBuffer { buffer in
                target.path.withCString { targetPath in linkURL.path.withCString { linkPath in
                    HoshinoCoreCreateSymlink(targetPath, linkPath, buffer, 1024)
                }}
            }
        } catch { guard RootHelperService.shouldRetry(error) else { throw error }; try RootHelperService.createSymbolicLink(target: target, at: linkURL) }
    }

    static func createHardLink(from source: URL, at linkURL: URL) throws {
        do {
            try withErrorBuffer { buffer in
                source.path.withCString { sourcePath in linkURL.path.withCString { linkPath in
                    HoshinoCoreCreateHardlink(sourcePath, linkPath, buffer, 1024)
                }}
            }
        } catch {
            guard RootHelperService.shouldRetry(error) else { throw error }
            try RootHelperService.createHardLink(from: source, at: linkURL)
        }
    }

    static func removeItem(_ url: URL) throws {
        do { try withErrorBuffer { buffer in url.path.withCString { path in HoshinoCoreRemoveItem(path, buffer, 1024) } } }
        catch { guard RootHelperService.shouldRetry(error) else { throw error }; try RootHelperService.removeItem(url) }
    }

    static func setPermissions(_ url: URL, mode: UInt32, recursive: Bool, followSymlinks: Bool = false) throws {
        do {
            try withErrorBuffer { buffer in
                url.path.withCString { HoshinoCoreSetPermissions($0, mode, recursive ? 1 : 0, followSymlinks ? 1 : 0, buffer, 1024) }
            }
        } catch {
            guard RootHelperService.shouldRetry(error) else { throw error }
            try RootHelperService.setPermissions(url, mode: mode, recursive: recursive, followSymlinks: followSymlinks)
        }
    }

    static func setOwner(_ url: URL, uid: UInt32, gid: UInt32, recursive: Bool, followSymlinks: Bool = false) throws {
        do {
            try withErrorBuffer { buffer in
                url.path.withCString { HoshinoCoreSetOwner($0, uid, gid, recursive ? 1 : 0, followSymlinks ? 1 : 0, buffer, 1024) }
            }
        } catch {
            guard RootHelperService.shouldRetry(error) else { throw error }
            try RootHelperService.setOwner(url, uid: uid, gid: gid, recursive: recursive, followSymlinks: followSymlinks)
        }
    }

    static func setExtendedAttribute(_ name: String, data: Data, on url: URL, followSymlinks: Bool = false) throws {
        do {
            try withErrorBuffer { buffer in
                url.path.withCString { path in name.withCString { key in
                    data.withUnsafeBytes { bytes in HoshinoCoreSetXAttr(path, key, bytes.baseAddress, bytes.count, followSymlinks ? 1 : 0, buffer, 1024) }
                }}
            }
        } catch {
            guard RootHelperService.shouldRetry(error) else { throw error }
            try RootHelperService.setExtendedAttribute(name, data: data, on: url, followSymlinks: followSymlinks)
        }
    }

    static func removeExtendedAttribute(_ name: String, from url: URL, followSymlinks: Bool = false) throws {
        do {
            try withErrorBuffer { buffer in
                url.path.withCString { path in name.withCString { key in HoshinoCoreRemoveXAttr(path, key, followSymlinks ? 1 : 0, buffer, 1024) } }
            }
        } catch {
            guard RootHelperService.shouldRetry(error) else { throw error }
            try RootHelperService.removeExtendedAttribute(name, from: url, followSymlinks: followSymlinks)
        }
    }

    private static func withErrorBuffer(_ body: (UnsafeMutablePointer<CChar>) -> Int32) throws {
        var message = [CChar](repeating: 0, count: 1024)
        let code = message.withUnsafeMutableBufferPointer { body($0.baseAddress!) }
        guard code == 0 else {
            let detail = String(cString: message)
            throw NSError(domain: NSPOSIXErrorDomain, code: Int(code), userInfo: [NSLocalizedDescriptionKey: detail.isEmpty ? String(cString: strerror(code)) : detail])
        }
    }
}

/// App-scoped persistent privilege broker. RootHelper accepts typed operations only;
/// it never receives a shell command or evaluates caller-provided command text.
enum RootHelperService {
    private static let enabledKey = "Hoshino.UseRootHelperForFileOperations"
    private static let lock = NSRecursiveLock()
    private static let lifecycleQueue = DispatchQueue(label: "Hoshino.RootHelper.lifecycle", qos: .utility)
    private static var channelFD: Int32 = -1
    private static var childPID: pid_t = 0
    private static var lastStartupError: String?

    static var statusDescription: String {
        lock.lock()
        defer { lock.unlock() }
        if channelFD >= 0 { return "RootHelper 正在运行（PID：\(childPID)）" }
        if let error = lastStartupError { return "RootHelper 未运行：\(error)" }
        return "RootHelper 尚未启动"
    }

    static var isRunning: Bool {
        guard isEnabled else { return false }
        lock.lock()
        defer { lock.unlock() }
        return channelFD >= 0 && childPID > 0
    }

    /// The resident helper is opt-out: TrollStore builds start it with the app.
    static var isEnabled: Bool {
        (UserDefaults.standard.object(forKey: enabledKey) as? Bool) ?? true
    }

    static func shouldRetry(_ error: Error) -> Bool {
        guard isEnabled else { return false }
        let code = (error as NSError).code
        return code == Int(EPERM) || code == Int(EACCES)
    }

    /// Called once during app startup. The child is attached to a private socketpair;
    /// no launchd job, global socket, or persistent registration is created.
    static func startIfNeeded() {
        guard isEnabled else { return }
        lock.lock()
        defer { lock.unlock() }
        guard channelFD < 0 else { return }
        do {
            try startLocked()
            lastStartupError = nil
        } catch {
            lastStartupError = error.localizedDescription
            // File operations retain the one-shot fallback.
        }
    }

    static func configure(enabled: Bool, completion: ((String) -> Void)? = nil) {
        UserDefaults.standard.set(enabled, forKey: enabledKey)
        lifecycleQueue.async {
            lock.lock()
            if enabled {
                if channelFD < 0 {
                    do { try startLocked(); lastStartupError = nil }
                    catch { lastStartupError = error.localizedDescription }
                }
            } else {
                stopLocked()
                lastStartupError = nil
            }
            lock.unlock()
            completion?(statusDescription)
        }
    }

    private static func startLocked() throws {
        guard channelFD < 0 else { return }
        let helper = Bundle.main.bundleURL.appendingPathComponent("RootHelper")
        guard FileManager.default.isExecutableFile(atPath: helper.path) else {
            throw NSError(domain: "Hoshino.RootHelper", code: ENOENT,
                          userInfo: [NSLocalizedDescriptionKey: "RootHelper 未嵌入应用包。请重新构建 Hoshino。"])
        }
        var newChannel: Int32 = -1
        var newPID: pid_t = 0
        let status = helper.path.withCString { path in
            HoshinoStartRootService(path, &newChannel, &newPID)
        }
        guard status == 0, newChannel >= 0, newPID > 0 else {
            throw NSError(domain: "Hoshino.RootHelper", code: Int(status),
                          userInfo: [NSLocalizedDescriptionKey: "常驻 RootHelper 启动失败，设备未提供可用的 root persona（状态码：\(status)）。"])
        }
        channelFD = newChannel
        childPID = newPID
    }

    private static func stopLocked() {
        guard channelFD >= 0 || childPID > 0 else { return }
        HoshinoStopRootService(channelFD, childPID)
        channelFD = -1
        childPID = 0
    }

    static func mergeDirectory(_ source: URL, into destination: URL, moveSource: Bool) throws {
        var args = ["--rpc", "--operation", "merge-directory", "--source", source.path, "--destination", destination.path]
        if moveSource { args.append("--move-source") }
        try run(args)
    }

    static func transfer(_ source: URL, to destination: URL, operation: NativeCore.Transfer, replace: Bool) throws {
        let kind: String = operation == .copy ? "copy" : (operation == .move ? "move" : "rename")
        var args = ["--rpc", "--operation", kind, "--source", source.path, "--destination", destination.path]
        if replace { args.append("--replace") }
        try run(args)
    }

    static func setPermissions(_ url: URL, mode: UInt32, recursive: Bool, followSymlinks: Bool) throws {
        var args = ["--rpc", "--operation", "chmod", "--path", url.path, "--mode", String(format: "%04o", mode)]
        if recursive { args.append("--recursive") }
        if followSymlinks { args.append("--follow") }
        try run(args)
    }

    static func setOwner(_ url: URL, uid: UInt32, gid: UInt32, recursive: Bool, followSymlinks: Bool) throws {
        var args = ["--rpc", "--operation", "chown", "--path", url.path, "--uid", String(uid), "--gid", String(gid)]
        if recursive { args.append("--recursive") }
        if followSymlinks { args.append("--follow") }
        try run(args)
    }

    static func setExtendedAttribute(_ name: String, data: Data, on url: URL, followSymlinks: Bool) throws {
        var args = ["--rpc", "--operation", "xattr-set", "--path", url.path, "--name", name, "--value-base64", data.base64EncodedString()]
        if followSymlinks { args.append("--follow") }
        try run(args)
    }

    static func removeExtendedAttribute(_ name: String, from url: URL, followSymlinks: Bool) throws {
        var args = ["--rpc", "--operation", "xattr-remove", "--path", url.path, "--name", name]
        if followSymlinks { args.append("--follow") }
        try run(args)
    }

    static func createDirectory(_ url: URL) throws { try run(["--rpc", "--operation", "mkdir", "--path", url.path]) }
    static func createFile(_ url: URL) throws { try run(["--rpc", "--operation", "create-file", "--path", url.path]) }
    static func createSymbolicLink(target: URL, at linkURL: URL) throws {
        try run(["--rpc", "--operation", "symlink", "--target", target.path, "--link", linkURL.path])
    }

    static func createHardLink(from source: URL, at linkURL: URL) throws {
        try run(["--rpc", "--operation", "hardlink", "--source", source.path, "--destination", linkURL.path])
    }
    static func removeItem(_ url: URL) throws { try run(["--rpc", "--operation", "delete", "--path", url.path]) }

    static func setImmutable(_ url: URL, enabled: Bool, recursive: Bool, followSymlinks: Bool) throws {
        var args = ["--rpc", "--operation", "immutable", "--path", url.path]
        if enabled { args.append("--enabled") }
        if recursive { args.append("--recursive") }
        if followSymlinks { args.append("--follow") }
        try run(args)
    }

    private static func run(_ arguments: [String]) throws {
        let helper = Bundle.main.bundleURL.appendingPathComponent("RootHelper")
        guard FileManager.default.isExecutableFile(atPath: helper.path) else {
            throw NSError(domain: "Hoshino.RootHelper", code: ENOENT,
                          userInfo: [NSLocalizedDescriptionKey: "RootHelper 未嵌入应用包。请重新构建 Hoshino。"])
        }
        lock.lock()
        defer { lock.unlock() }

        if channelFD < 0 {
            do { try startLocked(); lastStartupError = nil }
            catch { lastStartupError = error.localizedDescription }
        }
        var output = [CChar](repeating: 0, count: 16 * 1024)
        var code: Int32 = -1
        if channelFD >= 0 {
            code = invokePersistent(arguments, output: &output)
            let detail = String(cString: output)
            if code != 0 && detail.isEmpty && [EPIPE, ECONNRESET, EBADF, ETIMEDOUT, EPROTO].contains(code) {
                stopLocked()
                try? startLocked()
                if channelFD >= 0 {
                    output = [CChar](repeating: 0, count: 16 * 1024)
                    code = invokePersistent(arguments, output: &output)
                }
            }
        }

        if channelFD < 0 || (code != 0 && String(cString: output).isEmpty && [EPIPE, ECONNRESET, EBADF, ETIMEDOUT, EPROTO, EPERM].contains(code)) {
            output = [CChar](repeating: 0, count: 16 * 1024)
            code = invokeOneShot(helper: helper, arguments: arguments, output: &output)
        }

        guard code == 0 else {
            let detail = String(cString: output)
            throw NSError(domain: "Hoshino.RootHelper", code: Int(code),
                          userInfo: [NSLocalizedDescriptionKey: detail.isEmpty ? "RootHelper 执行失败（状态码：\(code)）。" : detail])
        }
    }

    private static func invokePersistent(_ arguments: [String], output: inout [CChar]) -> Int32 {
        var duplicated: [UnsafeMutablePointer<CChar>] = []
        for argument in arguments {
            guard let value = strdup(argument) else {
                duplicated.forEach { free($0) }
                return ENOMEM
            }
            duplicated.append(value)
        }
        defer { duplicated.forEach { free($0) } }
        let pointers = duplicated.map { UnsafePointer<CChar>($0) }
        return pointers.withUnsafeBufferPointer { buffer in
            output.withUnsafeMutableBufferPointer { out in
                HoshinoRunRootServiceCommand(channelFD, buffer.baseAddress, buffer.count, out.baseAddress, out.count)
            }
        }
    }

    private static func invokeOneShot(helper: URL, arguments: [String], output: inout [CChar]) -> Int32 {
        var duplicated: [UnsafeMutablePointer<CChar>] = []
        for argument in arguments {
            guard let value = strdup(argument) else {
                duplicated.forEach { free($0) }
                return ENOMEM
            }
            duplicated.append(value)
        }
        defer { duplicated.forEach { free($0) } }
        let pointers = duplicated.map { UnsafePointer<CChar>($0) }
        return helper.path.withCString { helperPath in
            pointers.withUnsafeBufferPointer { buffer in
                output.withUnsafeMutableBufferPointer { out in
                    HoshinoRunRootCommand(helperPath, buffer.baseAddress, buffer.count, out.baseAddress, out.count)
                }
            }
        }
    }
}
