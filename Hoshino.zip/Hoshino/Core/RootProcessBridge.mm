#include "RootProcessBridge.h"
#include <errno.h>
#include <fcntl.h>
#include <spawn.h>
#include <sys/ioctl.h>
#include <sys/wait.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <sys/time.h>
#include <util.h>
#include <unistd.h>
#include <signal.h>
#include <poll.h>
#include <chrono>
#include <vector>
#include <algorithm>
#include <cstdio>
#include <ctime>
#include <string.h>

extern char **environ;

#ifndef POSIX_SPAWN_PERSONA_FLAGS_OVERRIDE
#define POSIX_SPAWN_PERSONA_FLAGS_OVERRIDE 1
#endif

// These private persona APIs are weak-linked: ordinary signed installs can
// still launch an unprivileged shell and the RootHelper may use an installed su.
extern "C" int posix_spawnattr_set_persona_np(const posix_spawnattr_t *, uid_t, uint32_t) __attribute__((weak_import));
extern "C" int posix_spawnattr_set_persona_uid_np(const posix_spawnattr_t *, uid_t) __attribute__((weak_import));
extern "C" int posix_spawnattr_set_persona_gid_np(const posix_spawnattr_t *, uid_t) __attribute__((weak_import));

static int configureActions(posix_spawn_file_actions_t *actions, int slaveFD, int masterFD) {
    int error = posix_spawn_file_actions_init(actions);
    if (error != 0) return error;
    error = posix_spawn_file_actions_adddup2(actions, slaveFD, STDIN_FILENO);
    if (!error) error = posix_spawn_file_actions_adddup2(actions, slaveFD, STDOUT_FILENO);
    if (!error) error = posix_spawn_file_actions_adddup2(actions, slaveFD, STDERR_FILENO);
    if (!error) error = posix_spawn_file_actions_addclose(actions, masterFD);
    if (!error) error = posix_spawn_file_actions_addclose(actions, slaveFD);
    if (error != 0) posix_spawn_file_actions_destroy(actions);
    return error;
}

static int spawnHelper(const char *helperPath,
                       const char *workingDirectory,
                       const char *targetBinary,
                       int slaveFD,
                       int masterFD,
                       pid_t *childPID,
                       bool requestRootPersona) {
    posix_spawn_file_actions_t actions;
    int error = configureActions(&actions, slaveFD, masterFD);
    if (error != 0) return error;

    char *argv[] = {
        const_cast<char *>(helperPath),
        const_cast<char *>("--cwd"), const_cast<char *>(workingDirectory),
        const_cast<char *>("--target"), const_cast<char *>(targetBinary),
        nullptr
    };

    posix_spawnattr_t attr;
    error = posix_spawnattr_init(&attr);
    if (error != 0) {
        posix_spawn_file_actions_destroy(&actions);
        return error;
    }

    bool personaConfigured = false;
    if (requestRootPersona && posix_spawnattr_set_persona_np &&
        posix_spawnattr_set_persona_uid_np && posix_spawnattr_set_persona_gid_np) {
        const int p1 = posix_spawnattr_set_persona_np(&attr, 99, POSIX_SPAWN_PERSONA_FLAGS_OVERRIDE);
        const int p2 = posix_spawnattr_set_persona_uid_np(&attr, 0);
        const int p3 = posix_spawnattr_set_persona_gid_np(&attr, 0);
        personaConfigured = (p1 == 0 && p2 == 0 && p3 == 0);
        if (!personaConfigured) {
            // Discard any partially configured persona state before a normal spawn.
            posix_spawnattr_destroy(&attr);
            error = posix_spawnattr_init(&attr);
            if (error != 0) {
                posix_spawn_file_actions_destroy(&actions);
                return error;
            }
        }
    }

    error = posix_spawn(childPID, helperPath, &actions, &attr, argv, environ);
    posix_spawnattr_destroy(&attr);
    posix_spawn_file_actions_destroy(&actions);

    if (error != 0 && personaConfigured) {
        // A plain launch is a deliberate fallback, not a privilege bypass.
        posix_spawn_file_actions_t fallbackActions;
        error = configureActions(&fallbackActions, slaveFD, masterFD);
        if (error != 0) return error;
        error = posix_spawn(childPID, helperPath, &fallbackActions, nullptr, argv, environ);
        posix_spawn_file_actions_destroy(&fallbackActions);
    }
    return error;
}

extern "C" int HoshinoStartRootPTY(const char *helperPath,
                                     const char *workingDirectory,
                                     const char *targetBinary,
                                     int32_t columns,
                                     int32_t rows,
                                     int32_t *masterFD,
                                     pid_t *childPID) {
    if (!helperPath || !workingDirectory || !targetBinary || !masterFD || !childPID) return EINVAL;
    *masterFD = -1;
    *childPID = 0;

    struct winsize size = {};
    size.ws_col = static_cast<unsigned short>(columns > 0 ? columns : 100);
    size.ws_row = static_cast<unsigned short>(rows > 0 ? rows : 32);
    int master = -1;
    int slave = -1;
    if (openpty(&master, &slave, nullptr, nullptr, &size) != 0) return errno;

    int flags = fcntl(master, F_GETFL, 0);
    if (flags >= 0) fcntl(master, F_SETFL, flags | O_NONBLOCK);

    int error = spawnHelper(helperPath, workingDirectory, targetBinary, slave, master, childPID, true);
    if (error != 0) {
        close(master);
        close(slave);
        return error;
    }
    close(slave);
    *masterFD = master;
    return 0;
}

extern "C" void HoshinoResizePTY(int32_t masterFD, int32_t columns, int32_t rows, pid_t childPID) {
    if (masterFD < 0) return;
    struct winsize size = {};
    size.ws_col = static_cast<unsigned short>(columns > 0 ? columns : 1);
    size.ws_row = static_cast<unsigned short>(rows > 0 ? rows : 1);
    ioctl(masterFD, TIOCSWINSZ, &size);
    if (childPID > 0) kill(-childPID, SIGWINCH);
}

extern "C" void HoshinoStopPTY(pid_t childPID) {
    if (childPID > 0) {
        // RootHelper makes itself a session leader; signal its process group so
        // foreground jobs receive HUP along with the interactive shell.
        if (kill(-childPID, SIGHUP) != 0) kill(childPID, SIGHUP);
        // Do not block the main thread waiting for a shell that may be running a command.
    }
}




static bool socketReadExact(int fd, void *buffer, size_t length) {
    auto *bytes = static_cast<unsigned char *>(buffer);
    size_t offset = 0;
    while (offset < length) {
        const ssize_t count = recv(fd, bytes + offset, length - offset, 0);
        if (count > 0) { offset += static_cast<size_t>(count); continue; }
        if (count < 0 && errno == EINTR) continue;
        return false;
    }
    return true;
}

static bool socketWriteExact(int fd, const void *buffer, size_t length) {
    const auto *bytes = static_cast<const unsigned char *>(buffer);
    size_t offset = 0;
    while (offset < length) {
#ifdef MSG_NOSIGNAL
        const ssize_t count = send(fd, bytes + offset, length - offset, MSG_NOSIGNAL);
#else
        const ssize_t count = send(fd, bytes + offset, length - offset, 0);
#endif
        if (count > 0) { offset += static_cast<size_t>(count); continue; }
        if (count < 0 && errno == EINTR) continue;
        return false;
    }
    return true;
}

extern "C" int HoshinoStartRootService(const char *helperPath, int32_t *channelFD, pid_t *childPID) {
    if (!helperPath || !channelFD || !childPID) return EINVAL;
    *channelFD = -1;
    *childPID = 0;

    int sockets[2] = {-1, -1};
    if (socketpair(AF_UNIX, SOCK_STREAM, 0, sockets) != 0) return errno;
    (void)fcntl(sockets[0], F_SETFD, FD_CLOEXEC);
    (void)fcntl(sockets[1], F_SETFD, FD_CLOEXEC);
#ifdef SO_NOSIGPIPE
    int noSigPipe = 1;
    (void)setsockopt(sockets[0], SOL_SOCKET, SO_NOSIGPIPE, &noSigPipe, sizeof(noSigPipe));
#endif
    const int helperFD = 198;

    posix_spawn_file_actions_t actions;
    int error = posix_spawn_file_actions_init(&actions);
    const bool actionsInitialized = (error == 0);
    if (error == 0) error = posix_spawn_file_actions_adddup2(&actions, sockets[1], helperFD);
    if (error == 0) error = posix_spawn_file_actions_addclose(&actions, sockets[0]);
    if (error == 0 && sockets[1] != helperFD) error = posix_spawn_file_actions_addclose(&actions, sockets[1]);
    if (error != 0) {
        if (actionsInitialized) posix_spawn_file_actions_destroy(&actions);
        close(sockets[0]); close(sockets[1]);
        return error;
    }

    char fdString[16];
    snprintf(fdString, sizeof(fdString), "%d", helperFD);
    char *argv[] = {
        const_cast<char *>(helperPath),
        const_cast<char *>("--server"),
        const_cast<char *>("--fd"),
        fdString,
        nullptr
    };

    posix_spawnattr_t attr;
    error = posix_spawnattr_init(&attr);
    if (error != 0) {
        posix_spawn_file_actions_destroy(&actions);
        close(sockets[0]); close(sockets[1]);
        return error;
    }
    (void)posix_spawnattr_setpgroup(&attr, 0);
    (void)posix_spawnattr_setflags(&attr, POSIX_SPAWN_SETPGROUP);

    if (posix_spawnattr_set_persona_np && posix_spawnattr_set_persona_uid_np && posix_spawnattr_set_persona_gid_np) {
        const int p1 = posix_spawnattr_set_persona_np(&attr, 99, POSIX_SPAWN_PERSONA_FLAGS_OVERRIDE);
        const int p2 = posix_spawnattr_set_persona_uid_np(&attr, 0);
        const int p3 = posix_spawnattr_set_persona_gid_np(&attr, 0);
        if (p1 != 0 || p2 != 0 || p3 != 0) {
            posix_spawnattr_destroy(&attr);
            error = posix_spawnattr_init(&attr);
            if (error != 0) {
                posix_spawn_file_actions_destroy(&actions);
                close(sockets[0]); close(sockets[1]);
                return error;
            }
            (void)posix_spawnattr_setpgroup(&attr, 0);
            (void)posix_spawnattr_setflags(&attr, POSIX_SPAWN_SETPGROUP);
        }
    }

    pid_t child = 0;
    error = posix_spawn(&child, helperPath, &actions, &attr, argv, environ);
    posix_spawnattr_destroy(&attr);
    posix_spawn_file_actions_destroy(&actions);
    close(sockets[1]);
    if (error != 0) {
        close(sockets[0]);
        return error;
    }

    struct timeval timeout = {5, 0};
    (void)setsockopt(sockets[0], SOL_SOCKET, SO_RCVTIMEO, &timeout, sizeof(timeout));
    (void)setsockopt(sockets[0], SOL_SOCKET, SO_SNDTIMEO, &timeout, sizeof(timeout));
    uint32_t networkReady = 0;
    if (!socketReadExact(sockets[0], &networkReady, sizeof(networkReady))) {
        close(sockets[0]);
        (void)kill(child, SIGTERM);
        (void)waitpid(child, nullptr, 0);
        return ETIMEDOUT;
    }
    const uint32_t ready = ntohl(networkReady);
    if (ready != 0) {
        close(sockets[0]);
        int status = 0;
        (void)waitpid(child, &status, 0);
        return ready == 77 ? EPERM : EPROTO;
    }

    timeout.tv_sec = 300;
    timeout.tv_usec = 0;
    (void)setsockopt(sockets[0], SOL_SOCKET, SO_RCVTIMEO, &timeout, sizeof(timeout));
    (void)setsockopt(sockets[0], SOL_SOCKET, SO_SNDTIMEO, &timeout, sizeof(timeout));
    *channelFD = sockets[0];
    *childPID = child;
    return 0;
}

extern "C" int HoshinoRunRootServiceCommand(int32_t channelFD,
                                              const char *const arguments[],
                                              size_t argumentCount,
                                              char *output,
                                              size_t outputCapacity) {
    if (channelFD < 0 || !arguments || argumentCount < 3 || argumentCount > 64 || !output || outputCapacity == 0) return EINVAL;
    output[0] = '\0';
    uint32_t networkCount = htonl(static_cast<uint32_t>(argumentCount));
    if (!socketWriteExact(channelFD, &networkCount, sizeof(networkCount))) return errno ? errno : EPIPE;
    size_t totalBytes = 0;
    for (size_t index = 0; index < argumentCount; ++index) {
        if (!arguments[index]) return EINVAL;
        const size_t length = strlen(arguments[index]);
        if (length == 0 || length > 1024 * 1024 || totalBytes + length > 4 * 1024 * 1024) return E2BIG;
        totalBytes += length;
        uint32_t networkLength = htonl(static_cast<uint32_t>(length));
        if (!socketWriteExact(channelFD, &networkLength, sizeof(networkLength)) ||
            !socketWriteExact(channelFD, arguments[index], length)) return errno ? errno : EPIPE;
    }

    uint32_t networkStatus = 0;
    uint32_t networkLength = 0;
    if (!socketReadExact(channelFD, &networkStatus, sizeof(networkStatus)) ||
        !socketReadExact(channelFD, &networkLength, sizeof(networkLength))) return errno ? errno : EPIPE;
    const uint32_t status = ntohl(networkStatus);
    const uint32_t length = ntohl(networkLength);
    if (length > 16 * 1024) return EPROTO;
    std::vector<char> message(length + 1, '\0');
    if (length && !socketReadExact(channelFD, message.data(), length)) return errno ? errno : EPIPE;
    const size_t copy = std::min(static_cast<size_t>(length), outputCapacity - 1);
    if (copy) memcpy(output, message.data(), copy);
    output[copy] = '\0';
    return static_cast<int>(status);
}

extern "C" void HoshinoStopRootService(int32_t channelFD, pid_t childPID) {
    if (channelFD >= 0) {
        (void)shutdown(channelFD, SHUT_RDWR);
        close(channelFD);
    }
    if (childPID <= 0) return;
    const auto deadline = std::chrono::steady_clock::now() + std::chrono::milliseconds(700);
    int status = 0;
    while (std::chrono::steady_clock::now() < deadline) {
        const pid_t waited = waitpid(childPID, &status, WNOHANG);
        if (waited == childPID || (waited < 0 && errno != EINTR)) return;
        usleep(20000);
    }
    if (kill(childPID, SIGTERM) != 0 && errno != ESRCH) return;
    const auto termDeadline = std::chrono::steady_clock::now() + std::chrono::milliseconds(300);
    while (std::chrono::steady_clock::now() < termDeadline) {
        const pid_t waited = waitpid(childPID, &status, WNOHANG);
        if (waited == childPID || (waited < 0 && errno != EINTR)) return;
        usleep(20000);
    }
    (void)kill(childPID, SIGKILL);
    while (waitpid(childPID, &status, 0) < 0 && errno == EINTR) {}
}

static int spawnRootRPC(const char *helperPath,
                        const char *const arguments[],
                        size_t argumentCount,
                        char *output,
                        size_t outputCapacity) {
    if (!helperPath || !arguments || argumentCount == 0 || !output || outputCapacity == 0) return EINVAL;
    output[0] = '\0';
    int pipeFD[2];
    if (pipe(pipeFD) != 0) return errno;
    (void)fcntl(pipeFD[0], F_SETFD, FD_CLOEXEC);
    (void)fcntl(pipeFD[1], F_SETFD, FD_CLOEXEC);

    posix_spawn_file_actions_t actions;
    int error = posix_spawn_file_actions_init(&actions);
    const bool actionsInitialized = (error == 0);
    if (error == 0) error = posix_spawn_file_actions_adddup2(&actions, pipeFD[1], STDOUT_FILENO);
    if (error == 0) error = posix_spawn_file_actions_adddup2(&actions, pipeFD[1], STDERR_FILENO);
    if (error == 0) error = posix_spawn_file_actions_addclose(&actions, pipeFD[0]);
    if (error == 0) error = posix_spawn_file_actions_addclose(&actions, pipeFD[1]);
    if (error != 0) {
        if (actionsInitialized) posix_spawn_file_actions_destroy(&actions);
        close(pipeFD[0]); close(pipeFD[1]); return error;
    }

    std::vector<char *> argv;
    argv.reserve(argumentCount + 2);
    argv.push_back(const_cast<char *>(helperPath));
    for (size_t index = 0; index < argumentCount; ++index) {
        if (!arguments[index]) {
            posix_spawn_file_actions_destroy(&actions); close(pipeFD[0]); close(pipeFD[1]); return EINVAL;
        }
        argv.push_back(const_cast<char *>(arguments[index]));
    }
    argv.push_back(nullptr);

    posix_spawnattr_t attr;
    error = posix_spawnattr_init(&attr);
    if (error != 0) {
        posix_spawn_file_actions_destroy(&actions); close(pipeFD[0]); close(pipeFD[1]); return error;
    }
    bool attrInitialized = true;
    error = posix_spawnattr_setpgroup(&attr, 0);
    if (error == 0) error = posix_spawnattr_setflags(&attr, POSIX_SPAWN_SETPGROUP);
    bool personaConfigured = false;
    if (error == 0 && posix_spawnattr_set_persona_np &&
        posix_spawnattr_set_persona_uid_np && posix_spawnattr_set_persona_gid_np) {
        const int p1 = posix_spawnattr_set_persona_np(&attr, 99, POSIX_SPAWN_PERSONA_FLAGS_OVERRIDE);
        const int p2 = posix_spawnattr_set_persona_uid_np(&attr, 0);
        const int p3 = posix_spawnattr_set_persona_gid_np(&attr, 0);
        personaConfigured = (p1 == 0 && p2 == 0 && p3 == 0);
        if (!personaConfigured) {
            // Reinitialize attributes to ensure a partially configured persona is never used.
            posix_spawnattr_destroy(&attr);
            attrInitialized = false;
            error = posix_spawnattr_init(&attr);
            attrInitialized = (error == 0);
            if (error == 0) error = posix_spawnattr_setpgroup(&attr, 0);
            if (error == 0) error = posix_spawnattr_setflags(&attr, POSIX_SPAWN_SETPGROUP);
        }
    }

    pid_t child = 0;
    if (error == 0) error = posix_spawn(&child, helperPath, &actions, &attr, argv.data(), environ);
    if (attrInitialized) posix_spawnattr_destroy(&attr);
    if (error != 0 && personaConfigured) {
        // A normal launch is not privileged; RootHelper refuses the RPC unless euid is zero.
        posix_spawnattr_t fallbackAttr;
        int fallbackError = posix_spawnattr_init(&fallbackAttr);
        const bool fallbackInitialized = (fallbackError == 0);
        if (fallbackError == 0) fallbackError = posix_spawnattr_setpgroup(&fallbackAttr, 0);
        if (fallbackError == 0) fallbackError = posix_spawnattr_setflags(&fallbackAttr, POSIX_SPAWN_SETPGROUP);
        if (fallbackError == 0) error = posix_spawn(&child, helperPath, &actions, &fallbackAttr, argv.data(), environ);
        else error = fallbackError;
        if (fallbackInitialized) posix_spawnattr_destroy(&fallbackAttr);
    }
    posix_spawn_file_actions_destroy(&actions);
    close(pipeFD[1]);
    if (error != 0) { close(pipeFD[0]); return error; }

    const int oldFlags = fcntl(pipeFD[0], F_GETFL, 0);
    if (oldFlags >= 0) (void)fcntl(pipeFD[0], F_SETFL, oldFlags | O_NONBLOCK);
    size_t used = 0;
    char buffer[2048];
    bool eof = false;
    bool exited = false;
    bool validStatus = false;
    bool timedOut = false;
    int status = 0;
    const auto deadline = std::chrono::steady_clock::now() + std::chrono::seconds(30);
    auto drain = [&]() {
        while (!eof) {
            const ssize_t count = read(pipeFD[0], buffer, sizeof(buffer));
            if (count > 0) {
                const size_t available = outputCapacity - 1 - used;
                const size_t copy = std::min(static_cast<size_t>(count), available);
                if (copy) { memcpy(output + used, buffer, copy); used += copy; }
                continue;
            }
            if (count == 0) { eof = true; break; }
            if (errno == EINTR) continue;
            if (errno == EAGAIN || errno == EWOULDBLOCK) break;
            eof = true; break;
        }
    };

    while (!exited) {
        drain();
        const pid_t waited = waitpid(child, &status, WNOHANG);
        if (waited == child) { exited = true; validStatus = true; break; }
        if (waited < 0 && errno != EINTR) { exited = true; break; }
        if (std::chrono::steady_clock::now() >= deadline) { timedOut = true; break; }
        if (!eof) {
            struct pollfd descriptor = {pipeFD[0], POLLIN | POLLHUP, 0};
            (void)poll(&descriptor, 1, 100);
        } else {
            usleep(100000);
        }
    }

    if (timedOut) {
        if (kill(-child, SIGTERM) != 0) (void)kill(child, SIGTERM);
        const auto graceDeadline = std::chrono::steady_clock::now() + std::chrono::seconds(2);
        while (std::chrono::steady_clock::now() < graceDeadline) {
            const pid_t waited = waitpid(child, &status, WNOHANG);
            if (waited == child) { exited = true; validStatus = true; break; }
            if (waited < 0 && errno != EINTR) { exited = true; break; }
            usleep(50000);
        }
        if (!exited) {
            if (kill(-child, SIGKILL) != 0) (void)kill(child, SIGKILL);
            pid_t waited;
            do { waited = waitpid(child, &status, 0); } while (waited < 0 && errno == EINTR);
            validStatus = waited == child;
        }
    } else {
        // RootHelper RPC is synchronous; do not leave any child process behind.
        (void)kill(-child, SIGTERM);
    }
    drain();
    close(pipeFD[0]);

    if (timedOut) {
        const char *message = "\n[Hoshino] Root helper timed out after 30 seconds.\n";
        const size_t length = strlen(message);
        const size_t copy = std::min(length, outputCapacity - 1 - used);
        memcpy(output + used, message, copy); used += copy;
    }
    if (!personaConfigured && validStatus && WIFEXITED(status) && WEXITSTATUS(status) == 77) {
        const char *message = "\n[Hoshino] Root persona API is unavailable; operation was not elevated.\n";
        const size_t length = strlen(message);
        const size_t copy = std::min(length, outputCapacity - 1 - used);
        memcpy(output + used, message, copy); used += copy;
    }
    output[used] = '\0';
    if (timedOut) return ETIMEDOUT;
    if (!validStatus) return ECHILD;
    if (WIFEXITED(status)) return WEXITSTATUS(status);
    if (WIFSIGNALED(status)) return 128 + WTERMSIG(status);
    return ECHILD;
}

extern "C" int HoshinoRunRootCommand(const char *helperPath,
                                      const char *const arguments[],
                                      size_t argumentCount,
                                      char *output,
                                      size_t outputCapacity) {
    return spawnRootRPC(helperPath, arguments, argumentCount, output, outputCapacity);
}
