#include "NativeCore.hpp"

#include <algorithm>
#include <atomic>
#include <cerrno>
#include <cstring>
#include <filesystem>
#include <string>
#include <system_error>
#include <vector>
#include <sys/stat.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/xattr.h>
#if defined(__APPLE__)
#include <copyfile.h>
#endif

namespace fs = std::filesystem;
namespace hoshino::core {
namespace {
std::atomic<unsigned long long> sequence{0};

Result failure(int code, const std::string& message) {
    const int value = code ? code : EIO;
    return {false, value, message + ": " + std::strerror(value)};
}

bool status_no_follow(const fs::path& path, fs::file_status& status, std::error_code& ec) {
    status = fs::symlink_status(path, ec);
    if (ec == std::errc::no_such_file_or_directory || status.type() == fs::file_type::not_found) {
        ec.clear();
        return false;
    }
    return !ec;
}

bool path_exists_no_follow(const fs::path& path, std::error_code& ec) {
    fs::file_status status;
    return status_no_follow(path, status, ec);
}

fs::path unique_sibling(const fs::path& base, const char* suffix) {
    for (unsigned attempt = 0; attempt < 128; ++attempt) {
        const auto serial = ++sequence;
        fs::path candidate(base.string() + ".hoshino-" + std::to_string(::getpid()) + "-" +
                           std::to_string(serial) + "-" + suffix);
        std::error_code ec;
        if (!path_exists_no_follow(candidate, ec) && !ec) return candidate;
    }
    return {};
}

void copy_xattrs_best_effort(const fs::path& source, const fs::path& destination, bool noFollow = false) {
#if defined(__APPLE__)
    const int options = noFollow ? XATTR_NOFOLLOW : 0;
    const ssize_t length = ::listxattr(source.c_str(), nullptr, 0, options);
#else
    (void)noFollow;
    const ssize_t length = ::llistxattr(source.c_str(), nullptr, 0);
#endif
    if (length <= 0 || length > 1024 * 1024) return;
    std::vector<char> names(static_cast<size_t>(length));
#if defined(__APPLE__)
    const ssize_t got = ::listxattr(source.c_str(), names.data(), names.size(), options);
#else
    const ssize_t got = ::llistxattr(source.c_str(), names.data(), names.size());
#endif
    if (got <= 0) return;
    for (size_t offset = 0; offset < static_cast<size_t>(got);) {
        const char* name = names.data() + offset;
        const size_t n = std::strlen(name);
        if (n == 0 || offset + n >= static_cast<size_t>(got)) break;
#if defined(__APPLE__)
        const ssize_t valueSize = ::getxattr(source.c_str(), name, nullptr, 0, 0, options);
#else
        const ssize_t valueSize = ::lgetxattr(source.c_str(), name, nullptr, 0);
#endif
        if (valueSize >= 0 && valueSize <= 16 * 1024 * 1024) {
            std::vector<unsigned char> value(static_cast<size_t>(valueSize));
#if defined(__APPLE__)
            const ssize_t readSize = ::getxattr(source.c_str(), name, value.data(), value.size(), 0, options);
            if (readSize >= 0) (void)::setxattr(destination.c_str(), name, value.data(), static_cast<size_t>(readSize), 0, options);
#else
            const ssize_t readSize = ::lgetxattr(source.c_str(), name, value.data(), value.size());
            if (readSize >= 0) (void)::setxattr(destination.c_str(), name, value.data(), static_cast<size_t>(readSize), 0);
#endif
        }
        offset += n + 1;
    }
}

Result preserve_owner(const fs::path& source, const fs::path& destination, bool symlink) {
#if defined(__APPLE__)
    if (geteuid() != 0) return {true, 0, {}};
    struct stat sourceStat{};
    if (::lstat(source.c_str(), &sourceStat) != 0) return failure(errno, "读取源文件所有者失败");
    const int result = symlink
        ? ::lchown(destination.c_str(), sourceStat.st_uid, sourceStat.st_gid)
        : ::chown(destination.c_str(), sourceStat.st_uid, sourceStat.st_gid);
    if (result != 0) return failure(errno, "保留文件所有者/用户组失败");
#else
    (void)source; (void)destination; (void)symlink;
#endif
    return {true, 0, {}};
}

Result preserve_user_flags(const fs::path& source, const fs::path& destination, bool symlink) {
#if defined(__APPLE__)
    if (geteuid() != 0) return {true, 0, {}};
    struct stat sourceStat{};
    if (::lstat(source.c_str(), &sourceStat) != 0) return failure(errno, "读取源文件 flags 失败");
    // Preserve harmless display/backup flags only. UF_IMMUTABLE and UF_APPEND
    // are intentionally omitted because the transfer engine commits staged
    // entries with rename(), which those protection flags can block.
    constexpr unsigned long kCopyableFlags = 0x00008001UL; // UF_HIDDEN | UF_NODUMP
    const auto userFlags = static_cast<unsigned long>(sourceStat.st_flags) & kCopyableFlags;
    if (userFlags == 0) return {true, 0, {}};
    const int result = symlink ? ::lchflags(destination.c_str(), userFlags)
                               : ::chflags(destination.c_str(), userFlags);
    if (result != 0) return failure(errno, "保留 BSD 文件 flags 失败");
#else
    (void)source; (void)destination; (void)symlink;
#endif
    return {true, 0, {}};
}

Result copy_node(const fs::path& source, const fs::path& destination) {
    std::error_code ec;
    fs::file_status status;
    if (!status_no_follow(source, status, ec)) return failure(ec ? ec.value() : ENOENT, "读取源项目失败");

    if (fs::is_symlink(status)) {
        const auto target = fs::read_symlink(source, ec);
        if (ec) return failure(ec.value(), "读取符号链接目标失败");
        fs::create_symlink(target, destination, ec);
        if (ec) return failure(ec.value(), "复制符号链接失败");
        copy_xattrs_best_effort(source, destination, true);
        const auto ownerResult = preserve_owner(source, destination, true);
        if (!ownerResult.ok) return ownerResult;
        return preserve_user_flags(source, destination, true);
    }

    if (fs::is_directory(status)) {
        if (!fs::create_directory(destination, ec) || ec) return failure(ec ? ec.value() : EEXIST, "创建目标目录失败");
        fs::directory_iterator iterator(source, fs::directory_options::none, ec), end;
        if (ec) return failure(ec.value(), "读取源目录失败");
        for (; iterator != end; iterator.increment(ec)) {
            if (ec) return failure(ec.value(), "遍历源目录失败");
            const auto childResult = copy_node(iterator->path(), destination / iterator->path().filename());
            if (!childResult.ok) return childResult;
        }
        // Apply ownership and permissions only after children have been created,
        // so read-only source directories do not block population of the copy.
        copy_xattrs_best_effort(source, destination);
        const auto ownerResult = preserve_owner(source, destination, false);
        if (!ownerResult.ok) return ownerResult;
        fs::permissions(destination, status.permissions(), fs::perm_options::replace, ec);
        if (ec) return failure(ec.value(), "保留目录权限失败");
        const auto stamp = fs::last_write_time(source, ec);
        if (!ec) fs::last_write_time(destination, stamp, ec);
        return preserve_user_flags(source, destination, false);
    }

    if (fs::is_regular_file(status)) {
        bool copiedWithClone = false;
#if defined(__APPLE__) && defined(COPYFILE_CLONE)
        // APFS can create a copy-on-write clone instead of copying every byte.
        // Fall back for unsupported volumes or cross-volume copies.
        if (::copyfile(source.c_str(), destination.c_str(), nullptr, COPYFILE_DATA | COPYFILE_CLONE) == 0) {
            copiedWithClone = true;
        } else {
            const int cloneError = errno;
            if (cloneError != EXDEV && cloneError != EOPNOTSUPP && cloneError != ENOTSUP &&
                cloneError != EINVAL && cloneError != ENOSYS) {
                return failure(cloneError, "创建 APFS 文件克隆失败");
            }
            // A failed clone attempt may have left a partial destination entry.
            (void)::unlink(destination.c_str());
        }
#endif
        if (!copiedWithClone) {
            ec.clear();
            fs::copy_file(source, destination, fs::copy_options::none, ec);
            if (ec) return failure(ec.value(), "复制普通文件失败");
        }
        copy_xattrs_best_effort(source, destination);
        const auto ownerResult = preserve_owner(source, destination, false);
        if (!ownerResult.ok) return ownerResult;
        fs::permissions(destination, status.permissions(), fs::perm_options::replace, ec);
        if (ec) return failure(ec.value(), "保留文件权限失败");
        const auto stamp = fs::last_write_time(source, ec);
        if (!ec) fs::last_write_time(destination, stamp, ec);
        return preserve_user_flags(source, destination, false);
    }

    return failure(ENOTSUP, "不支持复制 socket、FIFO 或设备节点");
}

bool is_inside(const fs::path& parent, const fs::path& candidate) {
    auto rel = candidate.lexically_relative(parent);
    if (rel.empty() || rel == ".") return false;
    return *rel.begin() != "..";
}

Result cleanup_and_restore(const fs::path& staging, const fs::path& destination,
                           const fs::path& backup, bool hasBackup, int code,
                           const std::string& message) {
    std::error_code ignored;
    if (!staging.empty()) fs::remove_all(staging, ignored);
    if (hasBackup) {
        ignored.clear();
        fs::rename(backup, destination, ignored);
        if (ignored) return failure(ignored.value(), message + "；恢复原目标也失败，备份保留在 " + backup.string());
    }
    return failure(code, message);
}

Result rollback_move_copy(const fs::path& destination, const fs::path& backup,
                          bool hasBackup, int code, const std::string& message) {
    const fs::path failedCopy = unique_sibling(destination, "failed-move-copy");
    if (failedCopy.empty()) {
        return failure(code, message + "；新副本仍在目标路径：" + destination.string() +
                       (hasBackup ? "；旧目标备份：" + backup.string() : ""));
    }
    std::error_code moveError;
    fs::rename(destination, failedCopy, moveError);
    if (moveError) {
        return failure(code, message + "；新副本仍在目标路径：" + destination.string() +
                       (hasBackup ? "；旧目标备份：" + backup.string() : ""));
    }
    if (hasBackup) {
        std::error_code restoreError;
        fs::rename(backup, destination, restoreError);
        if (restoreError) {
            std::error_code putBackError;
            fs::rename(failedCopy, destination, putBackError);
            if (!putBackError) {
                return failure(code, message + "；新副本已保留在目标路径，旧目标备份仍在：" + backup.string());
            }
            return failure(code, message + "；新副本保留在：" + failedCopy.string() +
                           "；旧目标备份保留在：" + backup.string());
        }
    }
    std::error_code cleanupError;
    fs::remove_all(failedCopy, cleanupError);
    if (cleanupError) return failure(code, message + "；回滚已完成，但临时副本清理失败：" + failedCopy.string());
    return failure(code, message + "；目标状态已恢复");
}
} // namespace

Result transfer(const std::string& source, const std::string& destination,
                Operation operation, bool replace) {
    if (source.empty() || destination.empty()) return failure(EINVAL, "源路径和目标路径不能为空");
    const fs::path src(source), dst(destination);
    std::error_code ec;
    const auto srcAbs = fs::absolute(src, ec).lexically_normal();
    if (ec) return failure(ec.value(), "解析源路径失败");
    const auto dstAbs = fs::absolute(dst, ec).lexically_normal();
    if (ec) return failure(ec.value(), "解析目标路径失败");
    if (srcAbs == dstAbs) return failure(EINVAL, "源路径与目标路径相同");

    fs::file_status sourceStatus;
    if (!status_no_follow(src, sourceStatus, ec)) return failure(ec ? ec.value() : ENOENT, "源项目不存在");
    if (operation == Operation::rename && srcAbs.parent_path() != dstAbs.parent_path())
        return failure(EINVAL, "重命名不能更改父目录");
    if (fs::is_directory(sourceStatus) && !fs::is_symlink(sourceStatus) && is_inside(srcAbs, dstAbs))
        return failure(EINVAL, "不能将目录复制或移动到自身内部");

    fs::file_status parentStatus;
    if (!status_no_follow(dstAbs.parent_path(), parentStatus, ec) || !fs::is_directory(parentStatus) || ec)
        return failure(ec ? ec.value() : ENOTDIR, "目标父目录不存在或不是目录");

    fs::file_status destinationStatus;
    const bool destinationExists = status_no_follow(dst, destinationStatus, ec);
    if (ec) return failure(ec.value(), "检查目标路径失败");
    if (destinationExists && !replace) return failure(EEXIST, "目标已存在");

    fs::path backup;
    bool hasBackup = false;
    if (destinationExists) {
        backup = unique_sibling(dst, "backup");
        if (backup.empty()) return failure(EEXIST, "无法分配唯一备份路径");
        fs::rename(dst, backup, ec);
        if (ec) return failure(ec.value(), "暂存旧目标失败");
        hasBackup = true;
    }

    const fs::path staging = unique_sibling(dst, "staging");
    if (staging.empty()) return cleanup_and_restore({}, dst, backup, hasBackup, EEXIST, "无法分配唯一暂存路径");

    if (operation == Operation::move) {
        fs::rename(src, dst, ec);
        if (!ec) {
            if (hasBackup) { std::error_code ignored; fs::remove_all(backup, ignored); }
            return {true, 0, {}};
        }
        if (ec.value() != EXDEV) return cleanup_and_restore({}, dst, backup, hasBackup, ec.value(), "移动失败");
        ec.clear();
    }

    if (operation == Operation::copy || operation == Operation::move) {
        const auto copied = copy_node(src, staging);
        if (!copied.ok) return cleanup_and_restore(staging, dst, backup, hasBackup, copied.code, copied.message);
        fs::rename(staging, dst, ec);
        if (ec) return cleanup_and_restore(staging, dst, backup, hasBackup, ec.value(), "提交复制结果失败");
        if (operation == Operation::move) {
            // Never recursively delete the source in place: remove_all() can fail
            // halfway through a tree and destroy the only intact copy. Detach the
            // original with an atomic same-volume rename, then clean it up later.
            const fs::path sourceTombstone = unique_sibling(src, "move-source");
            if (sourceTombstone.empty()) {
                return rollback_move_copy(dst, backup, hasBackup, EEXIST,
                                          "无法为源项目分配移动暂存路径，源项目保持不变");
            }

            fs::rename(src, sourceTombstone, ec);
            if (ec) {
                const int code = ec.value();
                return rollback_move_copy(dst, backup, hasBackup, code,
                                          "无法原子移出源项目；原源项目保持不变");
            }
            std::error_code cleanupSourceError;
            fs::remove_all(sourceTombstone, cleanupSourceError);
            // Once the source has been atomically detached, the move is committed.
            // If cleanup is blocked, keep the hidden tombstone rather than risk loss.

        }
    } else {
        fs::rename(src, staging, ec);
        if (ec) return cleanup_and_restore(staging, dst, backup, hasBackup, ec.value(), "重命名暂存失败");
        fs::rename(staging, dst, ec);
        if (ec) {
            std::error_code rollbackError;
            fs::rename(staging, src, rollbackError);
            return cleanup_and_restore({}, dst, backup, hasBackup, ec.value(), "提交重命名失败");
        }
    }

    if (hasBackup) {
        fs::remove_all(backup, ec);
        // New destination is already committed. Keep the backup rather than
        // falsely reporting failure and attempting to roll back a committed op.
    }
    return {true, 0, {}};
}

namespace {
struct MergeContext {
    fs::path root;
    size_t failureCount = 0;
    int firstError = EIO;
    std::vector<std::string> failures;
};

void record_merge_failure(MergeContext& context, const fs::path& path, int code, const std::string& message) {
    ++context.failureCount;
    if (context.failureCount == 1 && code > 0) context.firstError = code;
    if (context.failures.size() < 100) {
        const fs::path relative = path.lexically_relative(context.root);
        context.failures.push_back((relative.empty() ? path : relative).string() + ": " + message);
    }
}

fs::path unique_merge_destination(const fs::path& source, const fs::path& destinationDirectory) {
    const std::string filename = source.filename().string();
    const std::string extension = source.extension().string();
    const std::string stem = source.stem().string();
    for (unsigned index = 2; index < 100000; ++index) {
        const fs::path candidate = destinationDirectory / (stem + " " + std::to_string(index) + extension);
        std::error_code ec;
        if (!path_exists_no_follow(candidate, ec) && !ec) return candidate;
        if (ec) return {};
    }
    (void)filename;
    return {};
}

void merge_directory_contents(const fs::path& source, const fs::path& destination, MergeContext& context) {
    std::error_code iteratorError;
    fs::directory_iterator iterator(source, fs::directory_options::none, iteratorError), end;
    if (iteratorError) {
        record_merge_failure(context, source, iteratorError.value(), "读取源目录失败: " + iteratorError.message());
        return;
    }

    while (iterator != end) {
        const fs::path sourceChild = iterator->path();
        const fs::path destinationChild = destination / sourceChild.filename();
        std::error_code ec;
        fs::file_status sourceStatus;
        if (!status_no_follow(sourceChild, sourceStatus, ec)) {
            record_merge_failure(context, sourceChild, ec ? ec.value() : ENOENT, "读取源项目状态失败");
        } else {
            fs::file_status destinationStatus;
            const bool destinationExists = status_no_follow(destinationChild, destinationStatus, ec);
            if (ec) {
                record_merge_failure(context, sourceChild, ec.value(), "检查目标项目失败: " + ec.message());
            } else if (destinationExists && fs::is_directory(sourceStatus) && !fs::is_symlink(sourceStatus) &&
                       fs::is_directory(destinationStatus) && !fs::is_symlink(destinationStatus)) {
                merge_directory_contents(sourceChild, destinationChild, context);
            } else {
                fs::path finalDestination = destinationChild;
                if (destinationExists) {
                    finalDestination = unique_merge_destination(sourceChild, destination);
                    if (finalDestination.empty()) {
                        record_merge_failure(context, sourceChild, EEXIST, "无法生成不冲突的目标名称");
                    }
                }
                if (!finalDestination.empty()) {
                    const Result copied = transfer(sourceChild.string(), finalDestination.string(), Operation::copy, false);
                    if (!copied.ok) record_merge_failure(context, sourceChild, copied.code, copied.message);
                }
            }
        }

        iterator.increment(iteratorError);
        if (iteratorError) {
            record_merge_failure(context, source, iteratorError.value(), "继续读取源目录失败: " + iteratorError.message());
            break;
        }
    }
}
} // namespace

Result merge_directory(const std::string& source, const std::string& destination, bool moveSource) {
    if (source.empty() || destination.empty()) return failure(EINVAL, "源目录和目标目录不能为空");
    std::error_code ec;
    const fs::path sourcePath = fs::absolute(fs::path(source), ec).lexically_normal();
    if (ec) return failure(ec.value(), "解析源目录失败");
    const fs::path destinationPath = fs::absolute(fs::path(destination), ec).lexically_normal();
    if (ec) return failure(ec.value(), "解析目标目录失败");
    if (sourcePath == destinationPath || is_inside(sourcePath, destinationPath) || is_inside(destinationPath, sourcePath))
        return failure(EINVAL, "不能把文件夹合并到自身、父目录或子目录中");

    fs::file_status sourceStatus, destinationStatus;
    if (!status_no_follow(sourcePath, sourceStatus, ec)) return failure(ec ? ec.value() : ENOENT, "源目录不存在");
    if (!status_no_follow(destinationPath, destinationStatus, ec)) return failure(ec ? ec.value() : ENOENT, "目标目录不存在");
    if (!fs::is_directory(sourceStatus) || fs::is_symlink(sourceStatus) ||
        !fs::is_directory(destinationStatus) || fs::is_symlink(destinationStatus))
        return failure(ENOTDIR, "文件夹合并要求源路径和目标路径都是实际目录，不能是符号链接");

    MergeContext context;
    context.root = sourcePath;
    merge_directory_contents(sourcePath, destinationPath, context);
    if (context.failureCount != 0) {
        std::string details;
        for (const auto& item : context.failures) details += (details.empty() ? "" : "；") + item;
        if (context.failureCount > context.failures.size()) details += "；其余失败项目已省略";
        return failure(context.firstError, "文件夹合并有 " + std::to_string(context.failureCount) +
                       " 项失败；源目录保持不变，已复制项目不会回滚。" + details);
    }

    if (moveSource) {
        const fs::path tombstone = unique_sibling(sourcePath, "merged-source");
        if (tombstone.empty()) return failure(EEXIST, "合并完成，但无法为源目录分配安全清理路径");
        const Result detached = transfer(sourcePath.string(), tombstone.string(), Operation::rename, false);
        if (!detached.ok) return failure(detached.code, "目标已合并，但源目录仍保留在原位置。" + detached.message);
        const Result cleaned = remove_item(tombstone.string());
        if (!cleaned.ok) return failure(cleaned.code, "目标已合并，源目录清理失败；完整源数据保留在 " + tombstone.string() + "。" + cleaned.message);
    }
    return {true, 0, {}};
}

Result create_directory(const std::string& path) {
    if (path.empty()) return failure(EINVAL, "目录路径不能为空");
    if (::mkdir(path.c_str(), 0777) != 0) return failure(errno, "创建目录失败");
    return {true, 0, {}};
}

Result create_file(const std::string& path) {
    if (path.empty()) return failure(EINVAL, "文件路径不能为空");
    const int descriptor = ::open(path.c_str(), O_WRONLY | O_CREAT | O_EXCL | O_CLOEXEC, 0666);
    if (descriptor < 0) return failure(errno, "创建文件失败");
    if (::close(descriptor) != 0) {
        const int code = errno;
        (void)::unlink(path.c_str());
        return failure(code, "关闭新文件失败");
    }
    return {true, 0, {}};
}

Result create_symlink(const std::string& target, const std::string& linkPath) {
    if (target.empty() || linkPath.empty()) return failure(EINVAL, "符号链接参数不能为空");
    if (::symlink(target.c_str(), linkPath.c_str()) != 0) return failure(errno, "创建符号链接失败");
    return {true, 0, {}};
}

Result create_hardlink(const std::string& source, const std::string& linkPath) {
    if (source.empty() || linkPath.empty()) return failure(EINVAL, "硬链接源路径和目标路径不能为空");
    struct stat sourceStatus {};
    if (::lstat(source.c_str(), &sourceStatus) != 0) return failure(errno, "读取硬链接源文件失败");
    if (!S_ISREG(sourceStatus.st_mode)) return failure(EINVAL, "硬链接只允许指向普通文件，不接受目录或符号链接");
    struct stat destinationStatus {};
    if (::lstat(linkPath.c_str(), &destinationStatus) == 0) return failure(EEXIST, "硬链接目标已存在");
    if (errno != ENOENT) return failure(errno, "检查硬链接目标失败");
    if (::link(source.c_str(), linkPath.c_str()) != 0) return failure(errno, "创建硬链接失败（源和目标必须位于同一文件系统）");
    return {true, 0, {}};
}

Result remove_item(const std::string& path) {
    if (path.empty()) return failure(EINVAL, "删除路径不能为空");
    std::error_code ec;
    fs::file_status status;
    if (!status_no_follow(fs::path(path), status, ec)) return failure(ec ? ec.value() : ENOENT, "待删除项目不存在");
    const auto removed = fs::remove_all(fs::path(path), ec);
    if (ec) return failure(ec.value(), "删除项目失败");
    if (removed == 0) return failure(ENOENT, "待删除项目不存在");
    return {true, 0, {}};
}

Result set_owner(const std::string& path, std::uint32_t uid, std::uint32_t gid, bool recursive, bool followSymlinks) {
    if (path.empty()) return failure(EINVAL, "chown 路径不能为空");
    const fs::path root(path);
    std::error_code ec;
    fs::file_status rootStatus;
    if (!status_no_follow(root, rootStatus, ec)) return failure(ec ? ec.value() : ENOENT, "chown 目标不存在");

    std::vector<fs::path> items{root};
    if (recursive && fs::is_directory(rootStatus) && !fs::is_symlink(rootStatus)) {
        fs::recursive_directory_iterator it(root, fs::directory_options::none, ec), end;
        if (ec) return failure(ec.value(), "枚举 chown 目录失败");
        while (it != end) {
            items.push_back(it->path());
            it.increment(ec);
            if (ec) return failure(ec.value(), "枚举 chown 子项目失败");
        }
    }

    struct OwnerSnapshot { fs::path path; uid_t uid; gid_t gid; bool symlink; };
    std::vector<OwnerSnapshot> changed;
    changed.reserve(items.size());
    const uid_t targetUID = uid == UINT32_MAX ? static_cast<uid_t>(-1) : static_cast<uid_t>(uid);
    const gid_t targetGID = gid == UINT32_MAX ? static_cast<gid_t>(-1) : static_cast<gid_t>(gid);

    auto restore = [&]() {
        bool failed = false;
        for (auto it = changed.rbegin(); it != changed.rend(); ++it) {
            const int result = it->symlink && !followSymlinks
                ? ::lchown(it->path.c_str(), it->uid, it->gid)
                : ::chown(it->path.c_str(), it->uid, it->gid);
            if (result != 0) failed = true;
        }
        return !failed;
    };

    for (const auto& item : items) {
        struct stat st {};
        const int statResult = followSymlinks ? ::stat(item.c_str(), &st) : ::lstat(item.c_str(), &st);
        if (statResult != 0) {
            const int code = errno;
            const bool rolledBack = restore();
            return failure(code, rolledBack ? "读取 chown 项目属性失败，已回滚此前修改" : "读取 chown 项目属性失败，且部分所有者回滚失败");
        }
        const bool symlink = S_ISLNK(st.st_mode);
        const int result = symlink && !followSymlinks
            ? ::lchown(item.c_str(), targetUID, targetGID)
            : ::chown(item.c_str(), targetUID, targetGID);
        if (result != 0) {
            const int code = errno;
            const bool rolledBack = restore();
            return failure(code, rolledBack ? "更改文件所有者失败，已回滚此前修改" : "更改文件所有者失败，且部分项目回滚失败；请检查目录内所有者状态");
        }
        changed.push_back({item, st.st_uid, st.st_gid, symlink});
    }
    return {true, 0, {}};
}

Result set_permissions(const std::string& path, std::uint32_t mode, bool recursive, bool followSymlinks) {
    if (path.empty() || mode > 07777) return failure(EINVAL, "路径或权限值无效（允许 0000–7777）");
    const fs::path root(path);
    std::error_code ec;
    fs::file_status rootStatus;
    if (!status_no_follow(root, rootStatus, ec)) return failure(ec ? ec.value() : ENOENT, "项目不存在");

    struct ModeSnapshot { fs::path path; mode_t mode; };
    std::vector<ModeSnapshot> snapshots;
    auto snapshot = [&](const fs::path& item) -> Result {
        fs::file_status st;
        std::error_code statusError;
        if (!status_no_follow(item, st, statusError)) return failure(statusError ? statusError.value() : ENOENT, "读取权限目标失败");
        if (fs::is_symlink(st) && !followSymlinks) return {true, 0, {}};
        struct stat nativeStatus{};
        const int statResult = followSymlinks ? ::stat(item.c_str(), &nativeStatus) : ::lstat(item.c_str(), &nativeStatus);
        if (statResult != 0) return failure(errno, "读取原始权限失败");
        snapshots.push_back({item, static_cast<mode_t>(nativeStatus.st_mode & 07777)});
        return {true, 0, {}};
    };

    std::vector<fs::path> paths{root};
    if (recursive && fs::is_directory(rootStatus) && !fs::is_symlink(rootStatus)) {
        fs::recursive_directory_iterator it(root, fs::directory_options::none, ec), end;
        if (ec) return failure(ec.value(), "打开目录失败");
        for (; it != end; it.increment(ec)) {
            if (ec) return failure(ec.value(), "遍历目录失败");
            paths.push_back(it->path());
        }
    }

    // Snapshot before mutation; set permissions on child files before directories.
    for (const auto& item : paths) {
        const auto result = snapshot(item);
        if (!result.ok) return result;
    }
    std::stable_sort(paths.begin(), paths.end(), [](const fs::path& a, const fs::path& b) {
        std::error_code ea, eb;
        const auto ta = fs::symlink_status(a, ea).type();
        const auto tb = fs::symlink_status(b, eb).type();
        return (ta == fs::file_type::directory) < (tb == fs::file_type::directory);
    });

    std::vector<fs::path> changed;
    for (const auto& item : paths) {
        fs::file_status status;
        std::error_code statusError;
        if (!status_no_follow(item, status, statusError)) {
            const int code = statusError ? statusError.value() : ENOENT;
            for (auto it = changed.rbegin(); it != changed.rend(); ++it) {
                auto found = std::find_if(snapshots.begin(), snapshots.end(), [&](const ModeSnapshot& value) { return value.path == *it; });
                if (found != snapshots.end()) (void)::chmod(found->path.c_str(), found->mode);
            }
            return failure(code, "设置权限前项目状态发生变化，已尝试回滚");
        }
        if (fs::is_symlink(status) && !followSymlinks) continue;
        if (::chmod(item.c_str(), static_cast<mode_t>(mode)) != 0) {
            const int code = errno;
            bool rollbackFailed = false;
            for (auto it = changed.rbegin(); it != changed.rend(); ++it) {
                auto found = std::find_if(snapshots.begin(), snapshots.end(), [&](const ModeSnapshot& value) { return value.path == *it; });
                if (found != snapshots.end() && ::chmod(found->path.c_str(), found->mode) != 0) rollbackFailed = true;
            }
            return failure(code, rollbackFailed ? "设置权限失败，且部分权限回滚失败" : "设置权限失败，已回滚此前更改");
        }
        changed.push_back(item);
    }
    return {true, 0, {}};
}

Result set_xattr(const std::string& path, const std::string& name,
                 const void* bytes, std::size_t length, bool follow) {
    if (path.empty() || name.empty() || name.find('\0') != std::string::npos || (!bytes && length))
        return failure(EINVAL, "路径、扩展属性名或数据无效");
#if defined(__APPLE__)
    const int options = follow ? 0 : XATTR_NOFOLLOW;
    if (::setxattr(path.c_str(), name.c_str(), bytes, length, 0, options) != 0) return failure(errno, "写入扩展属性失败");
#else
    const int rc = follow ? ::setxattr(path.c_str(), name.c_str(), bytes, length, 0)
                          : ::lsetxattr(path.c_str(), name.c_str(), bytes, length, 0);
    if (rc != 0) return failure(errno, "写入扩展属性失败");
#endif
    return {true, 0, {}};
}

Result remove_xattr(const std::string& path, const std::string& name, bool follow) {
    if (path.empty() || name.empty() || name.find('\0') != std::string::npos)
        return failure(EINVAL, "路径或扩展属性名无效");
#if defined(__APPLE__)
    if (::removexattr(path.c_str(), name.c_str(), follow ? 0 : XATTR_NOFOLLOW) != 0) return failure(errno, "删除扩展属性失败");
#else
    const int rc = follow ? ::removexattr(path.c_str(), name.c_str()) : ::lremovexattr(path.c_str(), name.c_str());
    if (rc != 0) return failure(errno, "删除扩展属性失败");
#endif
    return {true, 0, {}};
}
} // namespace hoshino::core
