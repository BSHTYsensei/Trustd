#import "NativeCoreBridge.h"
#include "NativeCore.hpp"
#include <cstring>
#include <cerrno>
using hoshino::core::Result;
static int finish(const Result& r, char *error, size_t capacity) {
    if (error && capacity) { std::strncpy(error, r.ok ? "" : r.message.c_str(), capacity - 1); error[capacity - 1] = 0; }
    return r.ok ? 0 : r.code;
}
extern "C" int HoshinoCoreTransfer(const char *s, const char *d, int op, int replace, char *e, size_t n) {
    if (!s || !d || op < 0 || op > 2) return finish({false, EINVAL, "参数无效"}, e, n);
    auto operation = op == 0 ? hoshino::core::Operation::copy : (op == 1 ? hoshino::core::Operation::move : hoshino::core::Operation::rename);
    return finish(hoshino::core::transfer(s, d, operation, replace != 0), e, n);
}
extern "C" int HoshinoCoreMergeDirectory(const char *s, const char *d, int moveSource, char *e, size_t n) {
    if (!s || !d) return finish({false, EINVAL, "文件夹合并参数无效"}, e, n);
    return finish(hoshino::core::merge_directory(s, d, moveSource != 0), e, n);
}
extern "C" int HoshinoCoreSetPermissions(const char *p, uint32_t m, int r, int f, char *e, size_t n) {
    if (!p) return finish({false, EINVAL, "路径为空"}, e, n);
    return finish(hoshino::core::set_permissions(p, m, r != 0, f != 0), e, n);
}
extern "C" int HoshinoCoreSetOwner(const char *p, uint32_t uid, uint32_t gid, int r, int f, char *e, size_t n) {
    if (!p) return finish({false, EINVAL, "chown 路径为空"}, e, n);
    return finish(hoshino::core::set_owner(p, uid, gid, r != 0, f != 0), e, n);
}
extern "C" int HoshinoCoreSetXAttr(const char *p, const char *name, const void *b, size_t l, int f, char *e, size_t n) {
    if (!p || !name || (!b && l)) return finish({false, EINVAL, "参数无效"}, e, n);
    return finish(hoshino::core::set_xattr(p, name, b, l, f != 0), e, n);
}
extern "C" int HoshinoCoreRemoveXAttr(const char *p, const char *name, int f, char *e, size_t n) {
    if (!p || !name) return finish({false, EINVAL, "参数无效"}, e, n);
    return finish(hoshino::core::remove_xattr(p, name, f != 0), e, n);
}

extern "C" int HoshinoCoreCreateDirectory(const char *p, char *e, size_t n) {
    if (!p) return finish({false, EINVAL, "目录路径为空"}, e, n);
    return finish(hoshino::core::create_directory(p), e, n);
}
extern "C" int HoshinoCoreCreateFile(const char *p, char *e, size_t n) {
    if (!p) return finish({false, EINVAL, "文件路径为空"}, e, n);
    return finish(hoshino::core::create_file(p), e, n);
}
extern "C" int HoshinoCoreCreateSymlink(const char *t, const char *l, char *e, size_t n) {
    if (!t || !l) return finish({false, EINVAL, "符号链接参数为空"}, e, n);
    return finish(hoshino::core::create_symlink(t, l), e, n);
}
extern "C" int HoshinoCoreCreateHardlink(const char *s, const char *l, char *e, size_t n) {
    if (!s || !l) return finish({false, EINVAL, "硬链接参数为空"}, e, n);
    return finish(hoshino::core::create_hardlink(s, l), e, n);
}
extern "C" int HoshinoCoreRemoveItem(const char *p, char *e, size_t n) {
    if (!p) return finish({false, EINVAL, "删除路径为空"}, e, n);
    return finish(hoshino::core::remove_item(p), e, n);
}
