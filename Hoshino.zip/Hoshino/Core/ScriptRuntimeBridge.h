#ifndef HOSHINO_SCRIPT_RUNTIME_BRIDGE_H
#define HOSHINO_SCRIPT_RUNTIME_BRIDGE_H
#include <stddef.h>
#ifdef __cplusplus
extern "C" {
#endif
int HoshinoRunShellScript(const char *path, char *output, size_t capacity);
int HoshinoBashRuntimeAvailable(void);
int HoshinoRunBashScript(const char *path, char *output, size_t capacity);
int HoshinoRunPythonScript(const char *path, char *output, size_t capacity);
int HoshinoPythonRuntimeAvailable(void);
int HoshinoInterpreterRuntimeAvailable(const char *kind);
int HoshinoRunInterpreterScript(const char *kind, const char *path, char *output, size_t capacity);
#ifdef __cplusplus
}
#endif
#endif
