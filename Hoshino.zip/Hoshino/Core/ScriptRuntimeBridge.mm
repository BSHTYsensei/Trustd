#include "ScriptRuntimeBridge.h"
#include <spawn.h>
#include <algorithm>
#include <sys/wait.h>
#include <unistd.h>
#include <dlfcn.h>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cerrno>
#include <pthread.h>
#include <mach-o/dyld.h>
#include <limits.h>
#include <poll.h>
#include <fcntl.h>
#include <chrono>
#include <signal.h>
#include <ctime>
#include <string>
#include <vector>
extern char **environ;
static pthread_mutex_t gPythonLock = PTHREAD_MUTEX_INITIALIZER;
static bool gPythonInitialized = false;
static void *gPythonHandle = nullptr;

static void loadPythonFramework() {
    if (gPythonHandle) return;
    char executablePath[PATH_MAX] = {0}; uint32_t size = sizeof(executablePath);
    if (_NSGetExecutablePath(executablePath, &size) != 0) return;
    std::string exe(executablePath); size_t slash = exe.find_last_of('/'); if (slash == std::string::npos) return;
    std::string framework = exe.substr(0, slash) + "/Frameworks/Python.framework/Python";
    gPythonHandle = dlopen(framework.c_str(), RTLD_NOW | RTLD_GLOBAL);
    if (gPythonHandle) {
        const std::string appBundle = exe.substr(0, slash);
        const std::string pythonHome = appBundle + "/python";
#if defined(__x86_64__)
        const std::string pythonArchitecture = "x86_64";
#else
        const std::string pythonArchitecture = "arm64";
#endif
        const std::string pythonPath = pythonHome + "/lib/python3.13:" +
            pythonHome + "/lib/python3.13/lib-dynload:" +
            pythonHome + "/platform-config/" + pythonArchitecture + ":" + appBundle + "/app";
        setenv("PYTHONHOME", pythonHome.c_str(), 1);
        setenv("PYTHONPATH", pythonPath.c_str(), 1);
        setenv("PYTHONUTF8", "1", 1);
        setenv("PYTHONDONTWRITEBYTECODE", "1", 1);
    }
}

static int collectOutput(int fd, char *out, size_t cap, pid_t pid, int timeoutSeconds = 120) {
    if (!out || cap == 0 || fd < 0 || pid <= 0) {
        if (fd >= 0) close(fd);
        if (pid > 0) { (void)kill(-pid, SIGKILL); (void)kill(pid, SIGKILL); while (waitpid(pid, nullptr, 0) < 0 && errno == EINTR) {} }
        return -1;
    }
    const int oldFlags = fcntl(fd, F_GETFL, 0);
    if (oldFlags >= 0) (void)fcntl(fd, F_SETFL, oldFlags | O_NONBLOCK);

    size_t used = 0;
    char buffer[4096];
    bool eof = false;
    bool exited = false;
    bool validStatus = false;
    int status = 0;
    bool timedOut = false;
    const auto deadline = std::chrono::steady_clock::now() + std::chrono::seconds(timeoutSeconds);

    auto drain = [&]() {
        while (!eof) {
            const ssize_t count = read(fd, buffer, sizeof(buffer));
            if (count > 0) {
                const size_t available = cap - 1 - used;
                const size_t take = std::min(static_cast<size_t>(count), available);
                if (take) { memcpy(out + used, buffer, take); used += take; }
                continue; // Continue draining even when output is truncated, to avoid blocking the child.
            }
            if (count == 0) { eof = true; break; }
            if (errno == EINTR) continue;
            if (errno == EAGAIN || errno == EWOULDBLOCK) break;
            eof = true;
            break;
        }
    };

    while (!exited) {
        drain();
        const pid_t waited = waitpid(pid, &status, WNOHANG);
        if (waited == pid) { exited = true; validStatus = true; break; }
        if (waited < 0 && errno != EINTR) { exited = true; break; }
        if (std::chrono::steady_clock::now() >= deadline) { timedOut = true; break; }

        if (!eof) {
            struct pollfd descriptor = {fd, POLLIN | POLLHUP, 0};
            (void)poll(&descriptor, 1, 100);
        } else {
            // The process may close stdout/stderr and continue running. Keep enforcing
            // the timeout even though the pipe no longer has pollable events.
            usleep(100000);
        }
    }

    if (timedOut) {
        if (kill(-pid, SIGTERM) != 0) (void)kill(pid, SIGTERM);
        const auto graceDeadline = std::chrono::steady_clock::now() + std::chrono::seconds(2);
        while (std::chrono::steady_clock::now() < graceDeadline) {
            const pid_t waited = waitpid(pid, &status, WNOHANG);
            if (waited == pid) { exited = true; validStatus = true; break; }
            if (waited < 0 && errno != EINTR) { exited = true; break; }
            usleep(50000);
        }
        if (!exited) {
            if (kill(-pid, SIGKILL) != 0) (void)kill(pid, SIGKILL);
            pid_t waited;
            do { waited = waitpid(pid, &status, 0); } while (waited < 0 && errno == EINTR);
            validStatus = waited == pid;
        }
    } else {
        // Reap background descendants left behind by a script after its main process exits.
        (void)kill(-pid, SIGTERM);
    }

    drain();
    close(fd);
    if (timedOut) {
        const char suffix[] = "\n[Hoshino] Script execution timed out after 120 seconds.\n";
        const size_t length = sizeof(suffix) - 1;
        const size_t take = std::min(length, cap - 1 - used);
        memcpy(out + used, suffix, take); used += take;
    }
    out[used] = 0;
    if (timedOut) return 124;
    if (!validStatus) return -1;
    if (WIFEXITED(status)) return WEXITSTATUS(status);
    if (WIFSIGNALED(status)) return 128 + WTERMSIG(status);
    return -1;
}

static int spawnScript(const char *binary, char *const argv[], char *output, size_t capacity) {
    if (!binary || !argv || !argv[0] || !output || capacity == 0) return -1;
    int descriptors[2];
    if (pipe(descriptors) != 0) return -3;
    (void)fcntl(descriptors[0], F_SETFD, FD_CLOEXEC);
    (void)fcntl(descriptors[1], F_SETFD, FD_CLOEXEC);

    posix_spawn_file_actions_t actions;
    int rc = posix_spawn_file_actions_init(&actions);
    const bool actionsInitialized = (rc == 0);
    if (rc == 0) rc = posix_spawn_file_actions_adddup2(&actions, descriptors[1], STDOUT_FILENO);
    if (rc == 0) rc = posix_spawn_file_actions_adddup2(&actions, descriptors[1], STDERR_FILENO);
    if (rc == 0) rc = posix_spawn_file_actions_addclose(&actions, descriptors[0]);
    if (rc == 0) rc = posix_spawn_file_actions_addclose(&actions, descriptors[1]);
    if (rc != 0) {
        if (actionsInitialized) posix_spawn_file_actions_destroy(&actions);
        close(descriptors[0]); close(descriptors[1]);
        return -rc;
    }

    posix_spawnattr_t attr;
    bool attrInitialized = false;
    rc = posix_spawnattr_init(&attr);
    if (rc == 0) {
        attrInitialized = true;
        rc = posix_spawnattr_setpgroup(&attr, 0);
        if (rc == 0) rc = posix_spawnattr_setflags(&attr, POSIX_SPAWN_SETPGROUP);
    }
    pid_t pid = 0;
    if (rc == 0) rc = posix_spawn(&pid, binary, &actions, &attr, argv, environ);
    if (attrInitialized) posix_spawnattr_destroy(&attr);
    posix_spawn_file_actions_destroy(&actions);
    close(descriptors[1]);
    if (rc != 0) { close(descriptors[0]); return -rc; }
    return collectOutput(descriptors[0], output, capacity, pid);
}

int HoshinoRunShellScript(const char *path, char *output, size_t capacity) {
    if (!path || access(path, R_OK) != 0) return -2;
    char *const argv[] = {(char *)"sh", (char *)path, nullptr};
    return spawnScript("/bin/sh", argv, output, capacity);
}

static std::string findExecutable(const std::string &name) {
    std::vector<std::string> directories = {
        "/var/jb/usr/bin", "/var/jb/bin", "/opt/procursus/bin", "/usr/local/bin",
        "/usr/bin", "/bin", "/usr/sbin", "/sbin", "/opt/bin"
    };
    if (const char *environmentPath = getenv("PATH")) {
        std::string pathValue(environmentPath);
        size_t begin = 0;
        while (begin <= pathValue.size()) {
            const size_t end = pathValue.find(':', begin);
            const std::string directory = pathValue.substr(begin, end == std::string::npos ? std::string::npos : end - begin);
            if (!directory.empty()) directories.push_back(directory);
            if (end == std::string::npos) break;
            begin = end + 1;
        }
    }
    std::vector<std::string> checked;
    for (const auto &directory : directories) {
        if (directory.empty() || std::find(checked.begin(), checked.end(), directory) != checked.end()) continue;
        checked.push_back(directory);
        const std::string candidate = directory + "/" + name;
        if (access(candidate.c_str(), X_OK) == 0) return candidate;
    }
    return {};
}

int HoshinoBashRuntimeAvailable(void) { return findExecutable("bash").empty() ? 0 : 1; }
int HoshinoRunBashScript(const char *path, char *output, size_t capacity) {
    if (!path || access(path, R_OK) != 0) return -2;
    const std::string bash = findExecutable("bash");
    if (bash.empty()) { if (output && capacity) snprintf(output, capacity, "Bash runtime unavailable on this device."); return -100; }
    char *const argv[] = {(char *)"bash", (char *)path, nullptr};
    return spawnScript(bash.c_str(), argv, output, capacity);
}

int HoshinoPythonRuntimeAvailable(void) {
    pthread_mutex_lock(&gPythonLock);
    loadPythonFramework();
    const bool available = dlsym(RTLD_DEFAULT, "Py_Initialize") &&
                           dlsym(RTLD_DEFAULT, "PyRun_SimpleStringFlags") &&
                           dlsym(RTLD_DEFAULT, "PyEval_SaveThread") &&
                           dlsym(RTLD_DEFAULT, "PyGILState_Ensure") &&
                           dlsym(RTLD_DEFAULT, "PyGILState_Release");
    pthread_mutex_unlock(&gPythonLock);
    return available ? 1 : 0;
}

static std::string pythonStringLiteral(const char *value) {
    std::string out = "'";
    for (const unsigned char *p = (const unsigned char *)value; *p; ++p) {
        switch (*p) {
            case '\\': out += "\\\\"; break;
            case '\'': out += "\\'"; break;
            case '\n': out += "\\n"; break;
            case '\r': out += "\\r"; break;
            case '\t': out += "\\t"; break;
            default: out += (char)*p; break;
        }
    }
    out += "'";
    return out;
}

int HoshinoRunPythonScript(const char *path, char *output, size_t capacity) {
    if (!path || access(path, R_OK) != 0) return -2;
    if (!output || capacity == 0) return -1;
    output[0] = '\0';

    pthread_mutex_lock(&gPythonLock);
    loadPythonFramework();
    typedef void (*InitFn)(void);
    typedef int (*RunFn)(const char *, void *);
    typedef void *(*SaveThreadFn)(void);
    typedef int (*GILEnsureFn)(void);
    typedef void (*GILReleaseFn)(int);
    InitFn init = (InitFn)dlsym(RTLD_DEFAULT, "Py_Initialize");
    RunFn run = (RunFn)dlsym(RTLD_DEFAULT, "PyRun_SimpleStringFlags");
    SaveThreadFn saveThread = (SaveThreadFn)dlsym(RTLD_DEFAULT, "PyEval_SaveThread");
    GILEnsureFn gilEnsure = (GILEnsureFn)dlsym(RTLD_DEFAULT, "PyGILState_Ensure");
    GILReleaseFn gilRelease = (GILReleaseFn)dlsym(RTLD_DEFAULT, "PyGILState_Release");
    if (!init || !run || !saveThread || !gilEnsure || !gilRelease) {
        snprintf(output, capacity, "Python runtime missing or incomplete. Add a compatible BeeWare Python.framework to Hoshino.app/Frameworks.");
        pthread_mutex_unlock(&gPythonLock);
        return -100;
    }

    if (!gPythonInitialized) {
        init();
        // Release the initialization thread's GIL. Each subsequent script execution
        // acquires/releases the interpreter lock on its own worker thread.
        (void)saveThread();
        gPythonInitialized = true;
    }
    const int gilState = gilEnsure();
    FILE *capture = tmpfile();
    if (!capture) {
        gilRelease(gilState);
        pthread_mutex_unlock(&gPythonLock);
        snprintf(output, capacity, "无法创建 Python 输出缓冲区：%s", strerror(errno));
        return -3;
    }
    fflush(stdout); fflush(stderr);
    const int oldOut = dup(STDOUT_FILENO);
    const int oldErr = dup(STDERR_FILENO);
    if (oldOut < 0 || oldErr < 0 || dup2(fileno(capture), STDOUT_FILENO) < 0 || dup2(fileno(capture), STDERR_FILENO) < 0) {
        if (oldOut >= 0) { (void)dup2(oldOut, STDOUT_FILENO); close(oldOut); }
        if (oldErr >= 0) { (void)dup2(oldErr, STDERR_FILENO); close(oldErr); }
        fclose(capture);
        gilRelease(gilState);
        pthread_mutex_unlock(&gPythonLock);
        snprintf(output, capacity, "无法重定向 Python 输出：%s", strerror(errno));
        return -3;
    }

    const std::string quotedPath = pythonStringLiteral(path);
    const std::string code = "import os,runpy,sys; sys.path.insert(0, os.path.dirname(" + quotedPath + ")); sys.argv=[" + quotedPath + "]; runpy.run_path(" + quotedPath + ", run_name='__main__')";
    const int result = run(code.c_str(), nullptr);
    fflush(stdout); fflush(stderr);
    (void)dup2(oldOut, STDOUT_FILENO);
    (void)dup2(oldErr, STDERR_FILENO);
    close(oldOut); close(oldErr);
    gilRelease(gilState);

    size_t used = 0;
    char buffer[2048];
    rewind(capture);
    size_t count;
    while ((count = fread(buffer, 1, sizeof(buffer), capture)) > 0) {
        const size_t take = std::min(count, capacity - 1 - used);
        if (take) { memcpy(output + used, buffer, take); used += take; }
    }
    output[used] = '\0';
    fclose(capture);
    pthread_mutex_unlock(&gPythonLock);
    return result;
}


static std::string findInterpreter(const char *kind) {
    if (!kind) return {};
    struct Runtime { const char *kind; const char *binary; };
    static const Runtime runtimes[] = {
        {"lua", "lua"}, {"rb", "ruby"}, {"pl", "perl"}, {"awk", "awk"},
        {"php", "php"}, {"r", "Rscript"}, {"tcl", "tclsh"}, {"mjs", "node"}
    };
    for (const auto &runtime : runtimes) {
        if (strcmp(kind, runtime.kind) == 0) return findExecutable(runtime.binary);
    }
    return {};
}

int HoshinoInterpreterRuntimeAvailable(const char *kind) {
    return findInterpreter(kind).empty() ? 0 : 1;
}

int HoshinoRunInterpreterScript(const char *kind, const char *path, char *output, size_t capacity) {
    if (!path || access(path, R_OK) != 0) return -2;
    const std::string interpreter = findInterpreter(kind);
    if (interpreter.empty()) {
        if (output && capacity) snprintf(output, capacity, "未找到 %s 解释器。请在越狱环境中安装对应命令行运行时。", kind ? kind : "unknown");
        return -100;
    }
    if (kind && strcmp(kind, "awk") == 0) {
        char *const argv[] = {const_cast<char *>(interpreter.c_str()), const_cast<char *>("-f"), const_cast<char *>(path), nullptr};
        return spawnScript(interpreter.c_str(), argv, output, capacity);
    }
    char *const argv[] = {const_cast<char *>(interpreter.c_str()), const_cast<char *>(path), nullptr};
    return spawnScript(interpreter.c_str(), argv, output, capacity);
}
