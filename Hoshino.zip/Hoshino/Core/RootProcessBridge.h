#ifndef HOSHINO_ROOT_PROCESS_BRIDGE_H
#define HOSHINO_ROOT_PROCESS_BRIDGE_H
#include <stdint.h>
#include <stddef.h>
#include <sys/types.h>
#ifdef __cplusplus
extern "C" {
#endif
int HoshinoStartRootPTY(const char *helperPath,
                        const char *workingDirectory,
                        const char *targetBinary,
                        int32_t columns,
                        int32_t rows,
                        int32_t *masterFD,
                        pid_t *childPID);
void HoshinoResizePTY(int32_t masterFD, int32_t columns, int32_t rows, pid_t childPID);
void HoshinoStopPTY(pid_t childPID);
int HoshinoStartRootService(const char *helperPath, int32_t *channelFD, pid_t *childPID);
int HoshinoRunRootServiceCommand(int32_t channelFD,
                                 const char *const arguments[],
                                 size_t argumentCount,
                                 char *output,
                                 size_t outputCapacity);
void HoshinoStopRootService(int32_t channelFD, pid_t childPID);
int HoshinoRunRootCommand(const char *helperPath,
                          const char *const arguments[],
                          size_t argumentCount,
                          char *output,
                          size_t outputCapacity);
#ifdef __cplusplus
}
#endif
#endif
