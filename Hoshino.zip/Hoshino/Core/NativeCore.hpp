#pragma once
#include <string>
#include <cstdint>

namespace hoshino::core {
enum class Operation { copy, move, rename };
struct Result { bool ok; int code; std::string message; };
Result transfer(const std::string& source, const std::string& destination, Operation operation, bool replace);
Result merge_directory(const std::string& source, const std::string& destination, bool move_source);
Result create_directory(const std::string& path);
Result create_file(const std::string& path);
Result create_symlink(const std::string& target, const std::string& link_path);
Result create_hardlink(const std::string& source, const std::string& link_path);
Result remove_item(const std::string& path);
Result set_permissions(const std::string& path, std::uint32_t mode, bool recursive, bool follow_symlinks = false);
Result set_owner(const std::string& path, std::uint32_t uid, std::uint32_t gid, bool recursive, bool follow_symlinks = false);
Result set_xattr(const std::string& path, const std::string& name, const void* bytes, std::size_t length, bool follow_symlinks);
Result remove_xattr(const std::string& path, const std::string& name, bool follow_symlinks);
}
