#ifndef HOSHINO_ARCHIVE_CORE_BRIDGE_H
#define HOSHINO_ARCHIVE_CORE_BRIDGE_H
#include <stddef.h>
#ifdef __cplusplus
extern "C" {
#endif

/* JSON array of archive entries. Returns 0 on success or an errno/libarchive error. */
int HoshinoArchiveListJSON(const char *archivePath,
                           const char *password,
                           char *jsonOutput,
                           size_t jsonCapacity,
                           char *errorOutput,
                           size_t errorCapacity);

/* Creates an archive atomically. format/filter are libarchive names; "none" disables a filter. */
int HoshinoArchiveCreate(const char *destinationPath,
                         const char *const sourcePaths[],
                         size_t sourceCount,
                         const char *format,
                         const char *filter,
                         int preservePermissions,
                         char *errorOutput,
                         size_t errorCapacity);

/* Extracts into an existing empty staging directory. The caller commits/removes that directory. */
int HoshinoArchiveExtract(const char *archivePath,
                          const char *stagingDirectory,
                          const char *password,
                          char *errorOutput,
                          size_t errorCapacity);

#ifdef __cplusplus
}
#endif
#endif
