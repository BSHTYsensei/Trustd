#include "ArchiveCoreBridge.h"

// The iOS SPM dependency is distributed as a libarchive.framework inside
// an XCFramework; host builds generally expose the traditional flat headers.
#if __has_include(<libarchive/archive.h>)
#include <libarchive/archive.h>
#include <libarchive/archive_entry.h>
#else
#include <archive.h>
#include <archive_entry.h>
#endif

#include <algorithm>
#include <cerrno>
#include <cctype>
#include <map>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <dirent.h>
#include <fcntl.h>
#include <limits>
#include <set>
#include <sstream>
#include <string>
#include <sys/stat.h>
#include <unistd.h>
#include <vector>

namespace {
constexpr size_t kIOBlock = 64 * 1024;
constexpr size_t kMaxEntries = 100000;
constexpr uint64_t kMaxExpandedBytes = 4ULL * 1024 * 1024 * 1024;

void setError(char *out, size_t cap, const std::string &message) {
    if (!out || cap == 0) return;
    std::snprintf(out, cap, "%s", message.c_str());
}

int fail(char *out, size_t cap, int code, const std::string &message) {
    setError(out, cap, message);
    return code > 0 ? code : EIO;
}

std::string archiveError(struct archive *a, const char *prefix) {
    const char *detail = a ? archive_error_string(a) : nullptr;
    std::string result(prefix ? prefix : "归档操作失败");
    if (detail && *detail) result += std::string("：") + detail;
    return result;
}

std::string jsonEscape(const char *value) {
    std::string out = "\"";
    if (value) {
        for (const unsigned char *p = reinterpret_cast<const unsigned char *>(value); *p; ++p) {
            switch (*p) {
                case '"': out += "\\\""; break;
                case '\\': out += "\\\\"; break;
                case '\b': out += "\\b"; break;
                case '\f': out += "\\f"; break;
                case '\n': out += "\\n"; break;
                case '\r': out += "\\r"; break;
                case '\t': out += "\\t"; break;
                default:
                    if (*p < 0x20) {
                        char escaped[7]; std::snprintf(escaped, sizeof(escaped), "\\u%04x", *p); out += escaped;
                    } else out += static_cast<char>(*p);
            }
        }
    }
    out += '"';
    return out;
}

bool hasPrefixPath(const std::string &path, const std::string &prefix) {
    return path == prefix || (path.size() > prefix.size() && path.compare(0, prefix.size(), prefix) == 0 && path[prefix.size()] == '/');
}

std::string asciiCaseFold(std::string value) {
    std::transform(value.begin(), value.end(), value.begin(), [](unsigned char c) {
        return static_cast<char>(std::tolower(c));
    });
    return value;
}

bool normalizeArchivePath(const char *rawValue, std::string &normalized) {
    if (!rawValue || !*rawValue) return false;
    std::string raw(rawValue);
    std::replace(raw.begin(), raw.end(), '\\', '/');
    if (raw.empty() || raw[0] == '/' || raw.find('\0') != std::string::npos) return false;
    for (const unsigned char ch : raw) if (ch < 0x20 || ch == 0x7f) return false;
    if (raw.size() >= 2 && std::isalpha(static_cast<unsigned char>(raw[0])) && raw[1] == ':') return false;
    std::vector<std::string> components;
    std::stringstream stream(raw);
    std::string part;
    while (std::getline(stream, part, '/')) {
        if (part.empty() || part == ".") continue;
        if (part == "..") return false;
        components.push_back(part);
    }
    if (components.empty()) return false;
    normalized.clear();
    for (const auto &component : components) {
        if (!normalized.empty()) normalized += '/';
        normalized += component;
    }
    return true;
}

bool safeSymlinkTarget(const std::string &relativePath, const char *targetValue) {
    if (!targetValue || !*targetValue) return false;
    std::string target(targetValue);
    std::replace(target.begin(), target.end(), '\\', '/');
    if (target[0] == '/' || (target.size() >= 2 && std::isalpha(static_cast<unsigned char>(target[0])) && target[1] == ':')) return false;
    std::vector<std::string> stack;
    const size_t slash = relativePath.find_last_of('/');
    if (slash != std::string::npos) {
        std::stringstream parent(relativePath.substr(0, slash));
        std::string part;
        while (std::getline(parent, part, '/')) if (!part.empty()) stack.push_back(part);
    }
    std::stringstream stream(target);
    std::string part;
    while (std::getline(stream, part, '/')) {
        if (part.empty() || part == ".") continue;
        if (part == "..") {
            if (stack.empty()) return false;
            stack.pop_back();
        } else {
            stack.push_back(part);
        }
    }
    return !stack.empty();
}

bool pathExistsNoFollow(const std::string &path) {
    struct stat st{};
    return lstat(path.c_str(), &st) == 0;
}

std::string pathLeaf(const std::string &path) {
    const auto slash = path.find_last_of('/');
    return slash == std::string::npos ? path : path.substr(slash + 1);
}

std::string rawOutputLeaf(const std::string &archivePath) {
    std::string leaf = pathLeaf(archivePath);
    const auto dot = leaf.find_last_of('.');
    if (dot != std::string::npos && dot > 0) leaf.erase(dot);
    if (leaf.empty()) leaf = "decompressed";
    return leaf;
}

bool isRawStreamPath(const std::string &path) {
    std::string lower = path;
    std::transform(lower.begin(), lower.end(), lower.begin(), [](unsigned char c) { return static_cast<char>(std::tolower(c)); });
    auto ends = [&](const char *suffix) {
        const size_t length = std::strlen(suffix);
        return lower.size() >= length && lower.compare(lower.size() - length, length, suffix) == 0;
    };
    // TAR-compressed containers must use format autodetection, not the raw reader.
    if (ends(".tar.gz") || ends(".tgz") || ends(".tar.bz2") || ends(".tbz2") ||
        ends(".tar.xz") || ends(".txz")) return false;
    return ends(".gz") || ends(".bz2") || ends(".xz");
}

int addFilter(struct archive *writer, const std::string &filter) {
    if (filter.empty() || filter == "none") return ARCHIVE_OK;
    if (filter == "gzip" || filter == "gz") return archive_write_add_filter_gzip(writer);
    if (filter == "bzip2" || filter == "bz2") return archive_write_add_filter_bzip2(writer);
    if (filter == "xz" || filter == "lzma") return archive_write_add_filter_xz(writer);
    if (filter == "zstd") return archive_write_add_filter_zstd(writer);
    if (filter == "lz4") return archive_write_add_filter_lz4(writer);
    return ARCHIVE_FATAL;
}

struct WriterContext {
    struct archive *writer = nullptr;
    std::string destination;
    std::string temporaryPath;
    bool preservePermissions = true;
    std::string error;
    size_t entries = 0;
};

int writeEntryHeader(WriterContext &context, struct archive_entry *entry) {
    const int rc = archive_write_header(context.writer, entry);
    if (rc != ARCHIVE_OK) context.error = archiveError(context.writer, "写入归档条目失败");
    return rc;
}

int addSourceNode(WriterContext &context, const std::string &sourcePath, const std::string &entryPath) {
    if (++context.entries > kMaxEntries) { context.error = "归档包含过多条目，已中止。"; return ARCHIVE_FATAL; }
    if (sourcePath == context.destination || sourcePath == context.temporaryPath) return ARCHIVE_OK;

    std::string normalizedEntry;
    if (!normalizeArchivePath(entryPath.c_str(), normalizedEntry) || normalizedEntry != entryPath) {
        context.error = "源项目名称包含不适合归档的路径分隔符或控制字符：" + entryPath;
        return ARCHIVE_FATAL;
    }

    struct stat st{};
    if (lstat(sourcePath.c_str(), &st) != 0) { context.error = std::string("无法读取源项目：") + std::strerror(errno); return ARCHIVE_FATAL; }
    const mode_t kind = st.st_mode & S_IFMT;
    if (kind != S_IFREG && kind != S_IFDIR && kind != S_IFLNK) {
        context.error = "不支持打包 socket、FIFO 或设备节点：" + sourcePath;
        return ARCHIVE_FATAL;
    }

    struct archive_entry *entry = archive_entry_new();
    if (!entry) { context.error = "无法分配归档条目。"; return ARCHIVE_FATAL; }
    archive_entry_set_pathname(entry, entryPath.c_str());
    archive_entry_set_perm(entry, context.preservePermissions ? (st.st_mode & 07777) : (kind == S_IFDIR ? 0755 : 0644));
    archive_entry_set_uid(entry, st.st_uid);
    archive_entry_set_gid(entry, st.st_gid);
    archive_entry_set_mtime(entry, st.st_mtime, 0);
    archive_entry_set_size(entry, kind == S_IFREG ? st.st_size : 0);

    if (kind == S_IFDIR) archive_entry_set_filetype(entry, AE_IFDIR);
    else if (kind == S_IFLNK) {
        archive_entry_set_filetype(entry, AE_IFLNK);
        std::vector<char> target(256, '\0');
        ssize_t length = -1;
        while (target.size() <= 1024 * 1024) {
            length = readlink(sourcePath.c_str(), target.data(), target.size());
            if (length < 0) {
                archive_entry_free(entry);
                context.error = std::string("读取符号链接失败：") + std::strerror(errno);
                return ARCHIVE_FATAL;
            }
            if (static_cast<size_t>(length) < target.size()) break;
            target.resize(target.size() * 2);
        }
        if (length < 0 || static_cast<size_t>(length) >= target.size()) {
            archive_entry_free(entry);
            context.error = "符号链接目标过长，拒绝归档。";
            return ARCHIVE_FATAL;
        }
        const std::string targetValue(target.data(), static_cast<size_t>(length));
        if (!safeSymlinkTarget(entryPath, targetValue.c_str())) {
            archive_entry_free(entry);
            context.error = "符号链接指向归档根目录之外，拒绝创建可能无法安全解压的归档：" + entryPath;
            return ARCHIVE_FATAL;
        }
        archive_entry_set_symlink(entry, targetValue.c_str());
    } else archive_entry_set_filetype(entry, AE_IFREG);

    int rc = writeEntryHeader(context, entry);
    archive_entry_free(entry);
    if (rc != ARCHIVE_OK) return rc;

    if (kind == S_IFREG) {
        const int fd = open(sourcePath.c_str(), O_RDONLY | O_CLOEXEC | O_NOFOLLOW);
        if (fd < 0) { context.error = std::string("打开源文件失败：") + std::strerror(errno); return ARCHIVE_FATAL; }
        char buffer[kIOBlock];
        while (true) {
            const ssize_t count = read(fd, buffer, sizeof(buffer));
            if (count == 0) break;
            if (count < 0) {
                if (errno == EINTR) continue;
                context.error = std::string("读取源文件失败：") + std::strerror(errno); close(fd); return ARCHIVE_FATAL;
            }
            la_ssize_t offset = 0;
            while (offset < count) {
                const la_ssize_t written = archive_write_data(context.writer, buffer + offset, static_cast<size_t>(count - offset));
                if (written <= 0) { context.error = archiveError(context.writer, "写入文件数据失败"); close(fd); return ARCHIVE_FATAL; }
                offset += written;
            }
        }
        close(fd);
        return ARCHIVE_OK;
    }

    if (kind == S_IFDIR) {
        DIR *directory = opendir(sourcePath.c_str());
        if (!directory) { context.error = std::string("无法遍历目录：") + std::strerror(errno); return ARCHIVE_FATAL; }
        std::vector<std::string> children;
        while (dirent *item = readdir(directory)) {
            const std::string name(item->d_name);
            if (name == "." || name == "..") continue;
            children.push_back(name);
        }
        closedir(directory);
        std::sort(children.begin(), children.end());
        for (const auto &child : children) {
            const std::string childSource = sourcePath + "/" + child;
            const std::string childEntry = entryPath + "/" + child;
            if (addSourceNode(context, childSource, childEntry) != ARCHIVE_OK) return ARCHIVE_FATAL;
        }
    }
    return ARCHIVE_OK;
}

int readArchive(const std::string &path, const char *password, struct archive **out, char *error, size_t errorCapacity) {
    struct archive *reader = archive_read_new();
    if (!reader) return fail(error, errorCapacity, ENOMEM, "无法创建归档读取器。");
    archive_read_support_filter_all(reader);
    if (isRawStreamPath(path)) {
        // The raw bidder intentionally has a low score. Register it exclusively
        // for plain compression streams so mtree never misclassifies arbitrary
        // compressed data and archive formats remain auto-detected elsewhere.
        archive_read_support_format_raw(reader);
    } else {
        archive_read_support_format_all(reader);
        archive_read_support_format_empty(reader);
    }
    if (password && *password) archive_read_add_passphrase(reader, password);
    const int rc = archive_read_open_filename(reader, path.c_str(), kIOBlock);
    if (rc != ARCHIVE_OK) {
        const std::string detail = archiveError(reader, "无法打开归档");
        archive_read_free(reader);
        return fail(error, errorCapacity, EINVAL, detail);
    }
    *out = reader;
    return 0;
}

} // namespace

extern "C" int HoshinoArchiveListJSON(const char *archivePath, const char *password,
                                        char *jsonOutput, size_t jsonCapacity,
                                        char *errorOutput, size_t errorCapacity) {
    if (!archivePath || !*archivePath || !jsonOutput || jsonCapacity == 0)
        return fail(errorOutput, errorCapacity, EINVAL, "归档路径或输出缓冲区无效。");
    jsonOutput[0] = '\0';
    struct archive *reader = nullptr;
    int code = readArchive(archivePath, password, &reader, errorOutput, errorCapacity);
    if (code != 0) return code;

    const bool raw = isRawStreamPath(archivePath);
    const std::string rawName = raw ? rawOutputLeaf(archivePath) : std::string();
    std::string json = "[";
    size_t count = 0;
    struct archive_entry *entry = nullptr;
    int rc;
    while ((rc = archive_read_next_header(reader, &entry)) == ARCHIVE_OK) {
        if (++count > kMaxEntries) { code = fail(errorOutput, errorCapacity, EFBIG, "归档条目数量超过安全上限。"); break; }
        const char *path = raw ? rawName.c_str() : archive_entry_pathname(entry);
        const mode_t type = archive_entry_filetype(entry);
        // ISO 9660 may expose its synthetic root directory as ".". It is a
        // container marker, not a filesystem entry, so omit it from listings.
        if (!raw && type == AE_IFDIR && path && (std::strcmp(path, ".") == 0 || std::strcmp(path, "./") == 0)) {
            archive_read_data_skip(reader);
            continue;
        }
        const char *kind = type == AE_IFDIR ? "directory" : type == AE_IFLNK ? "symlink" : type == AE_IFREG ? "file" : "other";
        if (count > 1) json += ',';
        json += "{\"path\":" + jsonEscape(path) + ",\"kind\":" + jsonEscape(kind);
        const la_int64_t size = archive_entry_size_is_set(entry) ? archive_entry_size(entry) : 0;
        json += ",\"size\":" + std::to_string(static_cast<uint64_t>(std::max<la_int64_t>(0, size)));
        json += ",\"mode\":" + std::to_string(static_cast<uint32_t>(archive_entry_perm(entry)));
        const char *link = archive_entry_symlink(entry);
        json += ",\"linkTarget\":" + (link ? jsonEscape(link) : "null") + "}";
        archive_read_data_skip(reader);
    }
    if (code == 0 && rc != ARCHIVE_EOF) code = fail(errorOutput, errorCapacity, EIO, archiveError(reader, "读取归档目录失败"));
    archive_read_free(reader);
    json += ']';
    if (code != 0) return code;
    if (json.size() + 1 > jsonCapacity) return fail(errorOutput, errorCapacity, ENOBUFS, "归档目录过大，JSON 输出缓冲区不足。");
    std::memcpy(jsonOutput, json.c_str(), json.size() + 1);
    if (errorOutput && errorCapacity) errorOutput[0] = '\0';
    return 0;
}

extern "C" int HoshinoArchiveCreate(const char *destinationPath, const char *const sourcePaths[], size_t sourceCount,
                                      const char *format, const char *filter, int preservePermissions,
                                      char *errorOutput, size_t errorCapacity) {
    if (!destinationPath || !*destinationPath || !sourcePaths || sourceCount == 0 || !format || !*format)
        return fail(errorOutput, errorCapacity, EINVAL, "创建归档的参数无效。");
    if (pathExistsNoFollow(destinationPath)) return fail(errorOutput, errorCapacity, EEXIST, "目标归档已存在。");
    struct stat parent{};
    const auto slash = std::string(destinationPath).find_last_of('/');
    const std::string parentPath = slash == std::string::npos ? "." : (slash == 0 ? "/" : std::string(destinationPath).substr(0, slash));
    if (stat(parentPath.c_str(), &parent) != 0 || !S_ISDIR(parent.st_mode)) return fail(errorOutput, errorCapacity, ENOENT, "归档目标父目录不存在。");

    std::string tempTemplate = std::string(destinationPath) + ".hoshino-tmp-XXXXXX";
    std::vector<char> tempBuffer(tempTemplate.begin(), tempTemplate.end());
    tempBuffer.push_back('\0');
    const int tempFD = mkstemp(tempBuffer.data());
    if (tempFD < 0) return fail(errorOutput, errorCapacity, errno, std::string("无法创建归档临时文件：") + std::strerror(errno));
    close(tempFD);
    const std::string tempPath(tempBuffer.data());
    struct archive *writer = archive_write_new();
    if (!writer) { unlink(tempPath.c_str()); return fail(errorOutput, errorCapacity, ENOMEM, "无法创建归档写入器。"); }

    int rc = archive_write_set_format_by_name(writer, format);
    if (rc == ARCHIVE_OK) rc = addFilter(writer, filter ? filter : "none");
    if (rc != ARCHIVE_OK) {
        const std::string detail = archiveError(writer, "当前构建不支持请求的归档格式或压缩器");
        archive_write_free(writer);
        unlink(tempPath.c_str());
        return fail(errorOutput, errorCapacity, ENOTSUP, detail);
    }
    rc = archive_write_open_filename(writer, tempPath.c_str());
    if (rc != ARCHIVE_OK) {
        const std::string detail = archiveError(writer, "无法创建临时归档");
        archive_write_free(writer); unlink(tempPath.c_str());
        return fail(errorOutput, errorCapacity, EIO, detail);
    }

    WriterContext context{writer, destinationPath, tempPath, preservePermissions != 0, {}, 0};
    std::set<std::string> rootNames;
    for (size_t i = 0; i < sourceCount; ++i) {
        if (!sourcePaths[i] || !*sourcePaths[i]) { rc = ARCHIVE_FATAL; context.error = "源路径为空。"; break; }
        const std::string source(sourcePaths[i]);
        const auto slashAt = source.find_last_of('/');
        std::string rootName = slashAt == std::string::npos ? source : source.substr(slashAt + 1);
        if (rootName.empty()) rootName = "root";
        const std::string original = rootName;
        unsigned int suffix = 2;
        while (!rootNames.insert(asciiCaseFold(rootName)).second) rootName = original + " " + std::to_string(suffix++);
        if (addSourceNode(context, source, rootName) != ARCHIVE_OK) { rc = ARCHIVE_FATAL; break; }
    }

    if (archive_write_close(writer) != ARCHIVE_OK && rc == ARCHIVE_OK) { rc = ARCHIVE_FATAL; context.error = archiveError(writer, "关闭归档失败"); }
    archive_write_free(writer);
    if (rc != ARCHIVE_OK) {
        unlink(tempPath.c_str());
        return fail(errorOutput, errorCapacity, EIO, context.error.empty() ? "创建归档失败。" : context.error);
    }
    // link(2) is an atomic no-clobber commit for a regular file on the same volume.
    // Unlike rename(2), it cannot silently replace a destination created after our
    // initial existence check.
    if (link(tempPath.c_str(), destinationPath) != 0) {
        const int saved = errno; unlink(tempPath.c_str());
        return fail(errorOutput, errorCapacity, saved, std::string("提交归档文件失败：") + std::strerror(saved));
    }
    if (unlink(tempPath.c_str()) != 0) {
        const int saved = errno;
        unlink(destinationPath);
        return fail(errorOutput, errorCapacity, saved, std::string("清理归档临时文件失败：") + std::strerror(saved));
    }
    if (errorOutput && errorCapacity) errorOutput[0] = '\0';
    return 0;
}

extern "C" int HoshinoArchiveExtract(const char *archivePath, const char *stagingDirectory, const char *password,
                                       char *errorOutput, size_t errorCapacity) {
    if (!archivePath || !*archivePath || !stagingDirectory || !*stagingDirectory)
        return fail(errorOutput, errorCapacity, EINVAL, "解压参数无效。");
    struct stat stagingStat{};
    if (lstat(stagingDirectory, &stagingStat) != 0 || !S_ISDIR(stagingStat.st_mode))
        return fail(errorOutput, errorCapacity, ENOTDIR, "解压暂存路径必须是已存在的目录。");

    struct archive *reader = nullptr;
    int code = readArchive(archivePath, password, &reader, errorOutput, errorCapacity);
    if (code != 0) return code;
    struct archive *disk = archive_write_disk_new();
    if (!disk) { archive_read_free(reader); return fail(errorOutput, errorCapacity, ENOMEM, "无法创建安全解压器。"); }
    const int options = ARCHIVE_EXTRACT_TIME | ARCHIVE_EXTRACT_PERM |
                        ARCHIVE_EXTRACT_SECURE_NODOTDOT |
                        ARCHIVE_EXTRACT_SECURE_SYMLINKS | ARCHIVE_EXTRACT_NO_OVERWRITE;
    archive_write_disk_set_options(disk, options);

    const bool raw = isRawStreamPath(archivePath);
    const std::string rawName = raw ? rawOutputLeaf(archivePath) : std::string();
    const std::string root = stagingDirectory;
    std::set<std::string> seen;
    std::set<std::string> seenCaseFolded;
    // Store archive entry types, not just directory flags: hard links may only
    // point at an already materialized regular file.
    std::map<std::string, mode_t> entryKinds;
    uint64_t declaredSize = 0;
    uint64_t actualExpandedSize = 0;
    size_t count = 0;
    struct archive_entry *entry = nullptr;
    int rc;
    while ((rc = archive_read_next_header(reader, &entry)) == ARCHIVE_OK) {
        if (++count > kMaxEntries) { code = fail(errorOutput, errorCapacity, EFBIG, "归档条目数量超过安全上限。"); break; }
        const char *rawPath = raw ? rawName.c_str() : archive_entry_pathname(entry);
        const mode_t type = archive_entry_filetype(entry);
        // ISO 9660's synthetic root directory is represented as "."; skip it
        // rather than ever mapping it to the extraction staging directory.
        if (!raw && type == AE_IFDIR && rawPath && (std::strcmp(rawPath, ".") == 0 || std::strcmp(rawPath, "./") == 0)) {
            archive_read_data_skip(reader);
            continue;
        }
        std::string relative;
        if (!normalizeArchivePath(rawPath, relative)) { code = fail(errorOutput, errorCapacity, EINVAL, std::string("归档包含不安全路径：") + (rawPath ? rawPath : "(null)")); break; }
        if (!seen.insert(relative).second || !seenCaseFolded.insert(asciiCaseFold(relative)).second) {
            code = fail(errorOutput, errorCapacity, EEXIST, "归档包含重复或大小写冲突路径：" + relative); break;
        }
        // FIFO entries can block consumers indefinitely and are not useful in a
        // user-facing file-manager extraction flow. Device nodes and sockets are
        // always rejected as well.
        if (type != AE_IFDIR && type != AE_IFREG && type != AE_IFLNK) {
            code = fail(errorOutput, errorCapacity, ENOTSUP, "归档包含不支持的特殊文件：" + relative); break;
        }
        if (type == AE_IFLNK) {
            const char *target = archive_entry_symlink(entry);
            if (!safeSymlinkTarget(relative, target)) { code = fail(errorOutput, errorCapacity, EINVAL, "归档符号链接可能逃逸解压目录：" + relative); break; }
        }
        const la_int64_t entrySize = archive_entry_size_is_set(entry) ? archive_entry_size(entry) : 0;
        if (entrySize > 0) {
            if (static_cast<uint64_t>(entrySize) > kMaxExpandedBytes - declaredSize) { code = fail(errorOutput, errorCapacity, EFBIG, "归档声明解压大小超过 4 GiB 安全上限。"); break; }
            declaredSize += static_cast<uint64_t>(entrySize);
        }
        // Reject both a child beneath a non-directory entry and a non-directory
        // entry that would replace an already-seen parent of other entries.
        const std::string foldedRelative = asciiCaseFold(relative);
        for (const auto &known : entryKinds) {
            if (hasPrefixPath(foldedRelative, known.first) && foldedRelative != known.first && known.second != AE_IFDIR) {
                code = fail(errorOutput, errorCapacity, EINVAL, "归档路径穿过非目录条目（忽略大小写）：" + known.first); break;
            }
            if (hasPrefixPath(known.first, foldedRelative) && known.first != foldedRelative && type != AE_IFDIR) {
                code = fail(errorOutput, errorCapacity, EINVAL, "归档文件与已有子路径冲突（忽略大小写）：" + relative); break;
            }
        }
        if (code != 0) break;

        const char *hardlink = archive_entry_hardlink(entry);
        std::string hardlinkRelative;
        if (hardlink) {
            if (!normalizeArchivePath(hardlink, hardlinkRelative)) {
                code = fail(errorOutput, errorCapacity, EINVAL, "归档硬链接目标路径不安全。"); break;
            }
            const auto targetType = entryKinds.find(asciiCaseFold(hardlinkRelative));
            if (targetType == entryKinds.end() || targetType->second != AE_IFREG) {
                code = fail(errorOutput, errorCapacity, EINVAL, "归档硬链接必须指向此前出现的普通文件：" + hardlinkRelative); break;
            }
        }
        entryKinds[foldedRelative] = type;

        const std::string targetPath = root + "/" + relative;
        archive_entry_set_pathname(entry, targetPath.c_str());
        if (hardlink) {
            const std::string hardlinkPath = root + "/" + hardlinkRelative;
            archive_entry_set_hardlink(entry, hardlinkPath.c_str());
        }

        int writeStatus = archive_write_header(disk, entry);
        if (writeStatus != ARCHIVE_OK) { code = fail(errorOutput, errorCapacity, EIO, archiveError(disk, "创建解压条目失败")); break; }
        while (true) {
            const void *block = nullptr;
            size_t blockSize = 0;
            la_int64_t offset = 0;
            const int readStatus = archive_read_data_block(reader, &block, &blockSize, &offset);
            if (readStatus == ARCHIVE_EOF) break;
            if (readStatus != ARCHIVE_OK) { code = fail(errorOutput, errorCapacity, EIO, archiveError(reader, "读取归档数据失败")); break; }
            // Enforce the expansion limit against actual bytes, not only untrusted
            // declared sizes (which malicious archives can understate).
            if (blockSize > kMaxExpandedBytes - actualExpandedSize) {
                code = fail(errorOutput, errorCapacity, EFBIG, "归档实际解压数据超过 4 GiB 安全上限。"); break;
            }
            actualExpandedSize += static_cast<uint64_t>(blockSize);
            if (archive_write_data_block(disk, block, blockSize, offset) != ARCHIVE_OK) { code = fail(errorOutput, errorCapacity, EIO, archiveError(disk, "写入解压数据失败")); break; }
        }
        if (code != 0) break;
        if (archive_write_finish_entry(disk) != ARCHIVE_OK) { code = fail(errorOutput, errorCapacity, EIO, archiveError(disk, "完成解压条目失败")); break; }
    }
    if (code == 0 && rc != ARCHIVE_EOF) code = fail(errorOutput, errorCapacity, EIO, archiveError(reader, "读取归档失败"));
    if (count == 0 && code == 0) code = fail(errorOutput, errorCapacity, EINVAL, "归档为空或格式不受支持。");
    archive_write_close(disk);
    archive_write_free(disk);
    archive_read_free(reader);
    if (code == 0 && errorOutput && errorCapacity) errorOutput[0] = '\0';
    return code;
}
