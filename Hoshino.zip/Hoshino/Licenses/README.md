# Bundled notices

Settings → About Hoshino → Licenses follows iGhostVT's component list and selectable
full-text reader, adapted to UIKit. Fila's own code stays MIT; third-party code
and fonts retain their respective licenses.

`Scripts/collect-licenses.py` runs offline on every app build. It collects
the root MIT license, vendored notices, and notices in SwiftPM checkouts that
Xcode materialized for the current app build destination (including nested
notices). The Xcode workspace `Package.resolved` is the authority for this
build. `Packages/FilaKit/Package.resolved` is used by the standalone macOS
`swift test` workflow and is intentionally not merged into the iOS app graph.

A pin can remain in `Package.resolved` without a checkout when it is inactive
for the current platform/target graph. Such pins are logged and omitted from
that build's license UI; their reviewed records remain in `review.json` so a
composition that materializes them will include them. Every checkout that is
present must match its exact pinned Git revision. When a reviewed notice is
absent from that checkout's working tree, the collector restores it from the
pinned Git object; an unreviewed new notice, changed text, or mismatched
checkout still fails the build. No WebUI or npm dependency is shipped.
The generated `Hoshino.app/Licenses.json` travels in the packaged app. It is
not linked into filad.

Each subdirectory has the full notice and `notice.json` with its source URL,
content hash and, where available, version. Ghostty's version comes from the
resolved wrapper's `Ghostty.version`. Archive URLs identify the exact dependency
sources from Ghostty's pinned `build.zig.zon`; Runestone's editor notice comes
from its pinned `Upstream.versions`. Grammar source URLs follow the vendored
TreeSitterLanguages attribution list. Those grammar imports do not record
individual upstream revisions; their recovered notices are snapshots, not a
claim that current upstream HEAD is the parser revision. Lua's missing license
file and contradictory metadata are documented explicitly in its notice and
in the review below.

`review.json` records the reviewed text hash and display label of every notice,
and the three reviewed XCFramework wrapper revisions. A changed or missing
notice, a newly discovered component, or a binary upgrade fails collection.
Recheck the component inventory and conditions before updating this file. The
labels are reviewed descriptions, not a keyword-based compatibility verdict.

See [Compatibility review](Compatibility.md) for the findings and their limits.
