import Foundation
import Combine

enum EditorKind: String, CaseIterable, Identifiable, Codable {
    case text = "文本编辑器"
    case plist = "Plist 树形编辑器"
    case hex = "十六进制编辑器"
    case json = "JSON 编辑器"
    case csv = "CSV 表格编辑器"
    case archive = "ZIP 压缩包管理器"
    case image = "图片查看器"
    case media = "音视频播放器"
    case quickLook = "Quick Look 预览"

    var id: String { rawValue }
    var symbol: String {
        switch self {
        case .text: return "doc.text"
        case .plist: return "list.tree"
        case .hex: return "number"
        case .json: return "curlybraces"
        case .csv: return "tablecells"
        case .archive: return "archivebox"
        case .image: return "photo"
        case .media: return "play.rectangle"
        case .quickLook: return "eye"
        }
    }
}

@MainActor
final class EditorAssociationStore: ObservableObject {
    static let shared = EditorAssociationStore()
    @Published private(set) var associations: [String: EditorKind] = [:]
    private let key = "Hoshino.EditorAssociations.v2"

    private let defaults: [String: EditorKind] = [
        "txt": .text, "log": .text, "ini": .text, "cfg": .text, "conf": .text,
        "md": .text, "markdown": .text, "swift": .text, "h": .text, "m": .text,
        "mm": .text, "c": .text, "cc": .text, "cpp": .text, "sh": .text,
        "bash": .text, "zsh": .text, "command": .text, "py": .text, "pyw": .text, "rb": .text, "pl": .text, "lua": .text, "awk": .text, "php": .text, "r": .text, "js": .text, "mjs": .text, "cjs": .text,
        "ts": .text, "tsx": .text, "jsx": .text, "css": .text, "scss": .text, "sass": .text, "html": .text, "htm": .text, "xml": .text, "xhtml": .text, "yaml": .text,
        "yml": .text, "toml": .text, "env": .text, "properties": .text, "strings": .text, "sql": .text, "diff": .text, "patch": .text, "rst": .text,
        "plist": .plist, "stringsdict": .plist, "entitlements": .plist, "xcprivacy": .plist,
        "json": .json, "jsonc": .json, "hex": .hex, "bin": .hex,
        "dat": .hex, "csv": .csv, "tsv": .csv, "zip": .archive, "7z": .archive, "rar": .archive, "tar": .archive, "gz": .archive, "tgz": .archive, "bz2": .archive, "xz": .archive, "txz": .archive, "cab": .archive, "iso": .archive, "deb": .archive, "cpio": .archive, "ar": .archive, "ipa": .archive, "apk": .archive,
        "png": .image, "jpg": .image, "jpeg": .image, "heic": .image,
        "gif": .image, "webp": .image, "bmp": .image, "tif": .image, "tiff": .image, "svg": .image, "avif": .image,
        "mp4": .media, "mov": .media, "m4v": .media, "mp3": .media,
        "m4a": .media, "wav": .media, "aac": .media, "aiff": .media, "flac": .media, "ogg": .media, "opus": .media, "mkv": .media, "avi": .media, "webm": .media,
        "pdf": .quickLook, "pages": .quickLook, "numbers": .quickLook,
        "key": .quickLook, "doc": .quickLook, "docx": .quickLook,
        "ppt": .quickLook, "pptx": .quickLook, "rtf": .quickLook
    ]

    private init() {
        if let data = UserDefaults.standard.data(forKey: key),
           let saved = try? JSONDecoder().decode([String: EditorKind].self, from: data) {
            associations = defaults.merging(saved) { _, custom in custom }
        } else {
            associations = defaults
        }
    }

    func kind(for url: URL) -> EditorKind {
        associations[url.pathExtension.lowercased()] ?? .quickLook
    }

    func set(_ kind: EditorKind, for extensionName: String) {
        let ext = extensionName.trimmingCharacters(in: .whitespacesAndNewlines).lowercased().trimmingCharacters(in: CharacterSet(charactersIn: "."))
        guard !ext.isEmpty else { return }
        associations[ext] = kind
        persist()
    }

    func remove(_ extensionName: String) {
        associations.removeValue(forKey: extensionName.lowercased())
        persist()
    }

    func reset() {
        associations = defaults
        persist()
    }

    private func persist() {
        if let data = try? JSONEncoder().encode(associations) {
            UserDefaults.standard.set(data, forKey: key)
        }
    }
}
