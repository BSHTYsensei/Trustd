import Foundation
import Combine
import SwiftUI

struct FavoriteLocation: Identifiable, Codable, Hashable {
    var id: UUID
    var title: String
    var path: String
    var group: String
    var bookmark: Data?

    init(id: UUID = UUID(), title: String, path: String, group: String = "未分组", bookmark: Data? = nil) {
        self.id = id
        self.title = title
        self.path = path
        self.group = group
        self.bookmark = bookmark
    }

    private enum CodingKeys: String, CodingKey { case id, title, path, group, bookmark }
    init(from decoder: Decoder) throws {
        let c = try decoder.container(keyedBy: CodingKeys.self)
        id = try c.decodeIfPresent(UUID.self, forKey: .id) ?? UUID()
        title = try c.decodeIfPresent(String.self, forKey: .title) ?? "未命名收藏"
        path = try c.decode(String.self, forKey: .path)
        group = try c.decodeIfPresent(String.self, forKey: .group) ?? "未分组"
        bookmark = try c.decodeIfPresent(Data.self, forKey: .bookmark)
    }
}

@MainActor
final class FavoritesStore: ObservableObject {
    static let shared = FavoritesStore()
    @Published private(set) var items: [FavoriteLocation] = []
    @Published private(set) var groups: [String] = ["未分组"]

    private let itemsKey = "Hoshino.Favorites.v2"
    private let legacyItemsKey = "Hoshino.Favorites.v1"
    private let groupsKey = "Hoshino.FavoriteGroups.v1"

    private init() {
        let defaults = UserDefaults.standard
        if let data = defaults.data(forKey: itemsKey), let decoded = try? JSONDecoder().decode([FavoriteLocation].self, from: data) {
            items = decoded
        } else if let data = defaults.data(forKey: legacyItemsKey), let decoded = try? JSONDecoder().decode([FavoriteLocation].self, from: data) {
            items = decoded
            saveItems()
        } else {
            let docs = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
            items = [FavoriteLocation(title: "文稿", path: docs.path), FavoriteLocation(title: "临时文件", path: FileManager.default.temporaryDirectory.path)]
        }
        if let saved = defaults.stringArray(forKey: groupsKey) {
            groups = Self.normalizedGroups(saved)
        }
        for item in items where !groups.contains(item.group) { groups.append(item.group) }
        if groups.isEmpty { groups = ["未分组"] }
        saveItems()
        saveGroups()
    }

    func add(_ url: URL, title: String? = nil, group: String = "未分组") throws {
        let standardized = url.standardizedFileURL
        let started = standardized.startAccessingSecurityScopedResource()
        defer { if started { standardized.stopAccessingSecurityScopedResource() } }
        var isDirectory: ObjCBool = false
        guard FileManager.default.fileExists(atPath: standardized.path, isDirectory: &isDirectory), isDirectory.boolValue else {
            throw NSError(domain: "Hoshino.Favorites", code: 7,
                          userInfo: [NSLocalizedDescriptionKey: "只能收藏当前可访问的文件夹。"])
        }
        guard !items.contains(where: { $0.path == standardized.path }) else { return }
        let bookmark = try standardized.bookmarkData(options: .minimalBookmark,
                                                      includingResourceValuesForKeys: nil,
                                                      relativeTo: nil)
        let safeGroup = groups.contains(group) ? group : "未分组"
        items.append(FavoriteLocation(title: title ?? (standardized.lastPathComponent.isEmpty ? standardized.path : standardized.lastPathComponent),
                                      path: standardized.path,
                                      group: safeGroup,
                                      bookmark: bookmark))
        saveItems()
    }

    func remove(_ item: FavoriteLocation) {
        items.removeAll { $0.id == item.id }
        saveItems()
    }

    func addGroup(_ rawName: String) throws {
        let name = rawName.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !name.isEmpty, name.count <= 80, name != ".", name != "..", !name.contains("/"),
              !name.unicodeScalars.contains(where: { CharacterSet.controlCharacters.contains($0) }) else {
            throw NSError(domain: "Hoshino.Favorites", code: 1, userInfo: [NSLocalizedDescriptionKey: "分组名称无效。"])
        }
        guard !groups.contains(name) else {
            throw NSError(domain: "Hoshino.Favorites", code: 2, userInfo: [NSLocalizedDescriptionKey: "该分组已经存在。"])
        }
        groups.append(name)
        saveGroups()
    }

    func renameGroup(_ oldName: String, to rawName: String) throws {
        let newName = rawName.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !newName.isEmpty, newName.count <= 80, newName != ".", newName != "..", !newName.contains("/"),
              !newName.unicodeScalars.contains(where: { CharacterSet.controlCharacters.contains($0) }) else {
            throw NSError(domain: "Hoshino.Favorites", code: 1, userInfo: [NSLocalizedDescriptionKey: "分组名称无效。"])
        }
        guard oldName != "未分组", groups.contains(oldName), !groups.contains(newName) else {
            throw NSError(domain: "Hoshino.Favorites", code: 3, userInfo: [NSLocalizedDescriptionKey: "不能重命名该分组，或目标名称已经存在。"])
        }
        groups = groups.map { $0 == oldName ? newName : $0 }
        for index in items.indices where items[index].group == oldName { items[index].group = newName }
        saveGroups(); saveItems()
    }

    func removeGroup(_ group: String) {
        guard group != "未分组" else { return }
        groups.removeAll { $0 == group }
        if !groups.contains("未分组") { groups.insert("未分组", at: 0) }
        for index in items.indices where items[index].group == group { items[index].group = "未分组" }
        saveGroups(); saveItems()
    }

    func move(_ item: FavoriteLocation, to group: String) {
        guard groups.contains(group), let index = items.firstIndex(where: { $0.id == item.id }) else { return }
        items[index].group = group
        saveItems()
    }

    func move(from source: IndexSet, to destination: Int, in group: String) {
        var values = items.filter { $0.group == group }
        values.move(fromOffsets: source, toOffset: destination)
        let others = items.filter { $0.group != group }
        // Keep each group's order stable while applying the reordered subset.
        var iterator = values.makeIterator()
        items = items.map { $0.group == group ? (iterator.next() ?? $0) : $0 }
        if items.count != values.count + others.count { items = others + values }
        saveItems()
    }

    func resolveURL(for favorite: FavoriteLocation) throws -> URL {
        guard let data = favorite.bookmark else {
            let localURL = URL(fileURLWithPath: favorite.path)
            var isDirectory: ObjCBool = false
            guard FileManager.default.fileExists(atPath: localURL.path, isDirectory: &isDirectory), isDirectory.boolValue else {
                throw NSError(domain: "Hoshino.Favorites", code: 4,
                              userInfo: [NSLocalizedDescriptionKey: "收藏目录不存在或不再是文件夹：\(favorite.path)"])
            }
            return localURL
        }
        var stale = false
        let resolved: URL
        do {
            resolved = try URL(resolvingBookmarkData: data,
                               options: [],
                               relativeTo: nil,
                               bookmarkDataIsStale: &stale)
        } catch {
            throw NSError(domain: "Hoshino.Favorites", code: 5,
                          userInfo: [NSLocalizedDescriptionKey: "收藏的安全书签已失效，系统无法恢复文件提供器授权。请重新添加该目录。\(error.localizedDescription)"])
        }
        let accessStarted = resolved.startAccessingSecurityScopedResource()
        defer { if accessStarted { resolved.stopAccessingSecurityScopedResource() } }
        var isDirectory: ObjCBool = false
        guard FileManager.default.fileExists(atPath: resolved.path, isDirectory: &isDirectory), isDirectory.boolValue else {
            throw NSError(domain: "Hoshino.Favorites", code: 8,
                          userInfo: [NSLocalizedDescriptionKey: "收藏的书签目标不存在或不再是文件夹：\(resolved.path)"])
        }
        if stale {
            let refreshed: Data
            do {
                refreshed = try resolved.bookmarkData(options: .minimalBookmark,
                                                       includingResourceValuesForKeys: nil,
                                                       relativeTo: nil)
            } catch {
                throw NSError(domain: "Hoshino.Favorites", code: 6,
                              userInfo: [NSLocalizedDescriptionKey: "收藏目录已恢复，但无法续期安全书签：\(error.localizedDescription)"])
            }
            if let index = items.firstIndex(where: { $0.id == favorite.id }) {
                items[index].bookmark = refreshed
                items[index].path = resolved.path
                saveItems()
            }
        }
        return resolved
    }

    private func saveItems() {
        if let data = try? JSONEncoder().encode(items) { UserDefaults.standard.set(data, forKey: itemsKey) }
    }
    private func saveGroups() { UserDefaults.standard.set(groups, forKey: groupsKey) }
    private static func normalizedGroups(_ values: [String]) -> [String] {
        var result = ["未分组"]
        for value in values where !value.isEmpty && !result.contains(value) { result.append(value) }
        return result
    }
}
