import Foundation
import Darwin

struct HoshinoFile: Identifiable, Hashable {
    let url: URL
    let isDirectory: Bool
    let isSymbolicLink: Bool
    let isExecutableMachO: Bool
    let size: Int64
    let modified: Date?
    let created: Date?

    var id: String { url.standardizedFileURL.path }
    var name: String { url.lastPathComponent.isEmpty ? url.path : url.lastPathComponent }
    var fileExtension: String { url.pathExtension.lowercased() }

    static func read(_ url: URL) -> HoshinoFile? {
        var st = stat()
        let result = url.path.withCString { lstat($0, &st) }
        guard result == 0 else { return nil }
        let isLink = (st.st_mode & S_IFMT) == S_IFLNK
        let isDir = (st.st_mode & S_IFMT) == S_IFDIR
        // lstat already supplies timestamps; avoid an extra URL resource-values query
        // for every row when opening directories containing thousands of entries.
        let modified = Date(timeIntervalSince1970: Double(st.st_mtimespec.tv_sec) + Double(st.st_mtimespec.tv_nsec) / 1_000_000_000)
        let created = st.st_birthtimespec.tv_sec > 0
            ? Date(timeIntervalSince1970: Double(st.st_birthtimespec.tv_sec) + Double(st.st_birthtimespec.tv_nsec) / 1_000_000_000)
            : nil
        return HoshinoFile(
            url: url,
            isDirectory: isDir,
            isSymbolicLink: isLink,
            isExecutableMachO: !isDir && !isLink && isExecutable(st.st_mode) && BinaryInspector.isMachO(at: url),
            size: Int64(max(0, st.st_size)),
            modified: modified,
            created: created
        )
    }

    static func isExecutable(_ mode: mode_t) -> Bool {
        (mode & (S_IXUSR | S_IXGRP | S_IXOTH)) != 0
    }
}



struct HoshinoDirectoryExtensionUsage: Identifiable, Hashable {
    let ext: String
    var count: Int
    var bytes: UInt64
    var id: String { ext }
}

struct HoshinoDirectoryAnalysis {
    let fileCount: Int
    let directoryCount: Int
    let symlinkCount: Int
    let unreadableCount: Int
    let totalBytes: UInt64
    let isTruncated: Bool
    let largestFiles: [HoshinoFile]
    let extensionUsage: [HoshinoDirectoryExtensionUsage]
}

struct HoshinoDuplicateGroup: Identifiable {
    let sha256: String
    let size: UInt64
    let files: [HoshinoFile]
    var id: String { sha256 }
    var reclaimableBytes: UInt64 { size * UInt64(max(0, files.count - 1)) }
}

enum HoshinoSort: String, CaseIterable, Identifiable {
    case name = "名称"
    case date = "修改日期"
    case size = "大小"
    case kind = "类型"
    case created = "创建时间"
    case extensionName = "扩展名"
    var id: String { rawValue }
}

enum HoshinoConflictPolicy: String, CaseIterable, Identifiable {
    case keepBoth = "保留两份"
    case replace = "覆盖"
    case merge = "合并文件夹"
    case cancel = "取消"
    var id: String { rawValue }
}

struct HoshinoFileMetadata {
    let mode: mode_t
    let owner: uid_t
    let group: gid_t
    let flags: UInt32
    let inode: UInt64
    let device: UInt64
    let linkCount: UInt32
    let isSymbolicLink: Bool

    var permissions: String {
        let bits: [(mode_t, String)] = [
            (S_IRUSR, "r"), (S_IWUSR, "w"), (S_IXUSR, "x"),
            (S_IRGRP, "r"), (S_IWGRP, "w"), (S_IXGRP, "x"),
            (S_IROTH, "r"), (S_IWOTH, "w"), (S_IXOTH, "x")
        ]
        return bits.map { mode & $0.0 == 0 ? "-" : $0.1 }.joined()
    }
    var octal: String { String(mode & 0o7777, radix: 8) }
    var immutable: Bool { (flags & 0x00000002) != 0 }
}

enum FileSystemError: LocalizedError {
    case invalidName
    case sameLocation
    case unsupported
    case immutable
    case noPermission
    case cannotRestore
    case invalidPlist(String)
    case invalidData(String)

    var errorDescription: String? {
        switch self {
        case .invalidName: return "名称不能为空，不能包含路径分隔符或 NUL 字符。"
        case .sameLocation: return "源文件和目标位置相同。"
        case .unsupported: return "当前文件系统或运行环境不支持此操作。"
        case .immutable: return "文件带有 BSD UF_IMMUTABLE 只读标记，请先解除锁定。"
        case .noPermission: return "当前进程没有足够的文件系统权限。"
        case .cannotRestore: return "无法恢复该项目，原位置可能已被占用或不可访问。"
        case .invalidPlist(let reason): return "Plist 数据无效：\(reason)"
        case .invalidData(let reason): return "数据无效：\(reason)"
        }
    }
}
