import Foundation

struct ArchivePreferences: Codable {
    var enabledFormats: Set<String> = supportedFormats
    var zipEncryption = true
    // Legacy compatibility fields retained so existing UserDefaults still decode.
    var zipAES = true
    var compressionLevel = 6
    var preservePermissions = true
    var createFormat = "zip"

    static let key = "archivePreferences.v1"
    static let supportedFormats: Set<String> = ["zip", "7z", "tar", "tar.gz", "tar.bz2", "tar.xz", "gz", "bz2", "xz", "cpio", "iso"]

    static func load() -> Self {
        guard let data = UserDefaults.standard.data(forKey: key),
              var value = try? JSONDecoder().decode(Self.self, from: data) else { return .init() }
        value.enabledFormats.formIntersection(supportedFormats)
        value.enabledFormats.insert("zip")
        if !supportedFormats.contains(value.createFormat) { value.createFormat = "zip" }
        value.compressionLevel = min(9, max(0, value.compressionLevel))
        return value
    }

    func save() {
        if let data = try? JSONEncoder().encode(self) { UserDefaults.standard.set(data, forKey: Self.key) }
    }

    struct FormatCapability: Identifiable {
        let name: String
        let supported: Bool
        let detail: String
        var id: String { name }
    }

    static let capabilities: [FormatCapability] = [
        .init(name: "ZIP", supported: true, detail: "支持列表、普通创建、解压；密码创建/解压走 SSZipArchive，密码模式拒绝无法可靠保留的特殊条目。"),
        .init(name: "7-Zip", supported: true, detail: "支持 7z 列表、创建和解压；具体压缩方法受集成 libarchive 版本限制。"),
        .init(name: "TAR / TGZ / TBZ2 / TXZ", supported: true, detail: "支持 PAX TAR 及 gzip、bzip2、xz 压缩组合，保留空目录和符号链接。"),
        .init(name: "GZ / BZ2 / XZ", supported: true, detail: "支持单个普通文件的压缩流创建与解压；不支持把多个文件直接放入裸压缩流。"),
        .init(name: "CPIO / ISO 9660", supported: true, detail: "支持列表、创建、解压；ISO 9660 的合成根目录标记会在解压时跳过。"),
        .init(name: "RAR / RAR5", supported: true, detail: "仅支持读取和解压；RAR 解码能力受 libarchive 对具体 RAR 版本及加密方式的支持范围约束。"),
        .init(name: "CAB", supported: true, detail: "仅支持读取和解压；不提供 CAB 创建。"),
        .init(name: "DEB", supported: true, detail: "按 ar 容器读取/解包，可再打开其中的 control.tar.*、data.tar.*；不是自动安装 Debian 软件包。")
    ]
}
