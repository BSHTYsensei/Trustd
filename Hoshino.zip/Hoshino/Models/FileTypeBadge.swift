import Foundation
import SwiftUI

enum HoshinoFileKind: String, CaseIterable {
    case folder, image, video, audio, plist, code, text, archive, package
    case document, font, certificate, database, executable, unknown

    var color: Color {
        switch self {
        case .folder: return .blue
        case .image: return .purple
        case .video: return .pink
        case .audio: return .orange
        case .plist: return .teal
        case .code: return .indigo
        case .text: return .gray
        case .archive: return .brown
        case .package: return .purple
        case .document: return .cyan
        case .font: return .mint
        case .certificate: return .teal
        case .database: return .brown
        case .executable: return .red
        case .unknown: return .secondary
        }
    }

    static func classify(_ url: URL, isDirectory: Bool = false, executable: Bool = false) -> Self {
        if isDirectory { return .folder }
        if executable { return .executable }
        let name = url.lastPathComponent.lowercased()
        if ["plist", "stringsdict", "entitlements", "xcprivacy"].contains(url.pathExtension.lowercased()) { return .plist }
        if ["ipa", "tipa", "apk", "deb", "pkg", "rpm", "appx", "msi", "appstore", "appclip"].contains(url.pathExtension.lowercased()) { return .package }
        if FileTypeIconAssets.archiveExtensions.contains(url.pathExtension.lowercased()) { return .archive }
        if FileTypeIconAssets.imageExtensions.contains(url.pathExtension.lowercased()) { return .image }
        if FileTypeIconAssets.videoExtensions.contains(url.pathExtension.lowercased()) { return .video }
        if FileTypeIconAssets.audioExtensions.contains(url.pathExtension.lowercased()) { return .audio }
        if ["ttf", "otf", "woff", "woff2", "eot", "fon", "fnt"].contains(url.pathExtension.lowercased()) { return .font }
        if ["cer", "crt", "csr", "pem", "p12", "pfx", "p7b", "p7c", "der", "mobileprovision", "key"].contains(url.pathExtension.lowercased()) { return .certificate }
        if ["db", "sqlite", "sqlite3", "sqlite-wal", "sqlite-shm", "realm", "sql", "dump"].contains(url.pathExtension.lowercased()) { return .database }
        if ["dylib", "so", "a", "framework", "xcframework", "bin", "exe", "dll", "sys", "elf", "wasm"].contains(url.pathExtension.lowercased()) { return .executable }
        if ["pdf", "doc", "docx", "odt", "rtf", "pages", "xls", "xlsx", "ods", "ppt", "pptx", "odp", "key", "epub", "mobi", "azw", "azw3", "djvu", "fb2", "cbz", "cbr"].contains(url.pathExtension.lowercased()) { return .document }
        if ["swift", "h", "hpp", "c", "cc", "cpp", "m", "mm", "js", "mjs", "cjs", "ts", "tsx", "jsx", "py", "pyw", "sh", "bash", "zsh", "command", "lua", "rb", "go", "rs", "java", "kt", "cs", "php", "pl", "pm", "r", "awk", "gradle", "cmake", "dart", "scala", "groovy", "vue", "svelte", "proto", "sql", "graphql", "wasm", "asm", "s"].contains(url.pathExtension.lowercased()) { return .code }
        if ["txt", "text", "log", "md", "markdown", "rst", "json", "jsonc", "json5", "xml", "html", "htm", "xhtml", "yaml", "yml", "ini", "conf", "cfg", "toml", "env", "csv", "tsv", "properties", "strings", "diff", "patch", "gitignore", "gitattributes", "gitmodules", "css", "scss", "less", "tex", "adoc", "org", "eml", "ics", "vcf"].contains(url.pathExtension.lowercased()) { return .text }
        if ["makefile", "gnumakefile", "dockerfile", "containerfile", "cmakelists.txt", "gemfile", "podfile", "rakefile", "fastfile", "procfile", "vagrantfile", "brewfile", ".bashrc", ".zshrc", ".profile"].contains(name) { return .code }
        if ["readme", "license", "copying", "authors", "notice", "changelog", ".editorconfig", ".gitignore", ".gitattributes", ".gitmodules"].contains(name) { return .text }
        return .unknown
    }
}

/// Every item rendered by the browser resolves to an artwork asset. There is no SF Symbols
/// or UIKit file-icon fallback: unmapped types intentionally use Hoshino's own generic artwork.
enum FileTypeIconAssets {
    static let imageExtensions: Set<String> = Set("jpg jpeg jpe jfif png apng gif heic heif svg svgz webp bmp dib tif tiff psd psb raw dng nef nrw cr2 cr3 arw raf rw2 orf pef srw avif jxl icns ico eps ai jp2 exr procreate afdesign afphoto xcf blend stl obj fbx gltf glb usd usdz dwg dxf step stp iges ifc skp icc icm cube 3dl".split(separator: " ").map(String.init))
    static let videoExtensions: Set<String> = Set("mp4 m4v mov qt mkv avi wmv asf flv webm mpg mpeg mpe vob m2v m2ts mts ts 3gp 3g2 ogv mxf rm rmvb divx f4v braw r3d cine ari".split(separator: " ").map(String.init))
    static let audioExtensions: Set<String> = Set("mp3 wav aiff aif flac aac m4a ogg oga opus mid midi wma amr caf ape alac dsf dff ac3 eac3 mka au snd aup".split(separator: " ").map(String.init))
    static let archiveExtensions: Set<String> = Set("zip xip rar 7z tar gz tgz bz2 tbz tbz2 xz txz zst tzst lz lz4 lzma lzo cab cpio ar xar deb rpm iso dmg".split(separator: " ").map(String.init))

    private static let filenameMap: [String: String] = [
        "makefile": "config", "gnumakefile": "config", "dockerfile": "config", "containerfile": "config",
        "cmakelists.txt": "config", "gemfile": "config", "podfile": "config", "rakefile": "c_cpp",
        "fastfile": "c_cpp", "procfile": "config", "vagrantfile": "config", "brewfile": "config",
        ".bashrc": "sh", ".zshrc": "sh", ".profile": "sh", ".gitignore": "config",
        ".gitattributes": "config", ".gitmodules": "config", ".editorconfig": "config",
        ".ds_store": "ds_store", "readme": "readme", "readme.md": "md",
        "license": "license", "license.md": "md", "copying": "license", "authors": "txt",
        "notice": "notice", "changelog": "md", "thumbs.db": "db",
        "dockerfile": "dockerfile", "containerfile": "dockerfile", "brewfile": "config",
        "gemfile": "config", "podfile": "config", "procfile": "config", "vagrantfile": "config",
        "justfile": "config", "taskfile": "config", "license.txt": "license", "authors.txt": "txt",
        "readme.txt": "readme", ".zprofile": "sh", ".zshenv": "sh", ".bash_profile": "sh",
        ".npmrc": "config", ".yarnrc": "config", ".pypirc": "config", ".gitconfig": "config",
        "aperturelibrary": "aperture", "aplibrary": "aperture", "login.keychain-db": "keychain",
        "system.keychain": "keychain", "user.keychain": "keychain", "photoslibrary": "panorama"
    ]

    private static let extensionMap: [String: String] = {
        var map: [String: String] = [:]
        func add(_ extensions: String, _ asset: String) {
            for ext in extensions.split(separator: " ") { map[String(ext)] = asset }
        }
        // Image families, with distinct artwork for the formats users encounter most often.
        add("jpg jpeg jpe jfif", "jpg"); add("png apng", "png"); add("gif", "gif")
        add("heic heif", "heic"); add("svg", "svg"); add("svgz ai eps", "vector")
        add("webp", "webp"); add("bmp dib", "bmp"); add("tif tiff", "tiff")
        add("psd psb xcf", "psd"); add("raw dng nef nrw cr2 cr3 arw raf rw2 orf pef srw", "raw")
        add("avif jxl icns ico jp2 exr", "image"); add("procreate afdesign afphoto", "palette")
        add("blend stl obj fbx gltf glb usd usdz", "cube3d"); add("dwg dxf step stp iges ifc skp", "cad")
        add("icc icm cube 3dl", "lut")
        // Video and audio codecs/formats.
        add("mp4", "mp4"); add("m4v", "m4v"); add("mov qt", "mov"); add("mkv", "mkv")
        add("avi", "avi"); add("wmv asf", "wmv"); add("flv f4v", "flv"); add("webm", "webm")
        add("mpg mpeg mpe vob m2v m2ts mts ts 3gp 3g2 ogv mxf rm rmvb divx", "video")
        add("mp3", "mp3"); add("wav aiff aif", "wav"); add("aac ac3 eac3", "aac"); add("m4a", "m4a")
        add("caf", "caf"); add("midi mid wma ogg oga opus flac ape alac dsf dff mka au snd", "audio")
        // Documents, e-books, mail and office data.
        add("pdf", "pdf"); add("doc docx dot dotx odt ott pages", "doc")
        add("xls xlsx xlsm xlsb ods numbers", "xls"); add("ppt pptx pptm odp key", "ppt")
        add("rtf", "rtf"); add("epub mobi azw azw3 fb2 djvu cbz cbr", "doc")
        add("eml msg mbox", "notice"); add("ics vcf vcard", "config")
        // Text, markup and configuration.
        add("txt text log", "txt"); add("md markdown rst adoc org", "md")
        add("csv tsv", "csv"); add("json jsonc json5", "json"); add("xml xsd xsl xslt", "xml")
        add("plist entitlements stringsdict xcprivacy", "plist"); add("yaml yml toml ini conf cfg env properties", "config")
        add("html htm xhtml", "html"); add("css scss sass less", "css")
        add("diff patch", "c_cpp"); add("tex latex bib", "txt")
        // Programming languages and project formats.
        add("swift", "swift"); add("py pyw pyc pyo ipynb", "py"); add("js mjs cjs jsx ts tsx", "js")
        add("c cc cxx cpp", "cpp"); add("h hh hpp hxx", "header"); add("m mm", "objc")
        add("sh bash zsh fish command", "sh"); add("rs go", "rust_go"); add("java kt kts scala groovy", "java_kotlin")
        add("cs fs fsx vb php phtml pl pm r awk lua rb dart ex exs erl hs lhs ml", "c_cpp")
        add("gradle cmake makefile proto graphql wasm asm s vue svelte", "c_cpp")
        add("sql", "db")
        // Archives, disk images and installable packages.
        add("zip xip", "zip"); add("rar", "rar"); add("7z", "7z"); add("tar", "tar")
        add("gz tgz", "gz"); add("bz2 tbz tbz2", "bz2"); add("xz txz zst tzst lz lz4 lzma lzo cab cpio ar xar", "7z")
        add("dmg", "dmg"); add("iso", "iso"); add("ipa tipa apk deb rpm pkg appx msi", "package")
        // System artifacts, executable formats and development bundles.
        add("dylib", "dylib"); add("so", "so"); add("dll sys", "dll"); add("exe", "exe")
        add("bin elf mach-o wasm", "bin"); add("a lib", "lib"); add("framework xcframework", "framework")
        add("db sqlite sqlite3 sqlite-wal sqlite-shm realm storedata dump", "db")
        add("ttf fon fnt", "font"); add("otf woff woff2 eot", "font")
        add("cer crt csr pem p12 pfx p7b p7c p7m p7s der mobileprovision provprofile", "cert")
        add("key", "key"); add("m4a", "m4a"); add("m4v", "m4v"); add("caf", "caf")
        add("lock pid", "temp"); add("log", "log")

        // More granular artwork: high-frequency extensions no longer collapse into one generic family.
        add("jxl", "jxl"); add("avif", "avif"); add("ico icns", "ico"); add("jp2 j2k", "jp2"); add("exr hdr", "exr")
        add("nef nrw", "nef"); add("cr3", "cr3"); add("raf", "raf"); add("rw2", "rw2"); add("blend", "blend")
        add("dwg dxf step stp iges ifc", "dwg"); add("usd usdz", "usd"); add("skp", "skp")
        add("epub fb2", "epub"); add("mobi", "mobi"); add("azw azw3", "azw3"); add("cbz", "cbz"); add("cbr", "cbr")
        add("eml msg", "eml"); add("mbox", "mbox"); add("ics", "ics"); add("vcf vcard", "vcf")
        add("tex latex bib", "tex"); add("adoc asciidoc", "adoc"); add("org", "org")
        add("flac", "flac"); add("ogg oga", "ogg"); add("opus", "opus"); add("mid midi", "midi")
        add("aiff aif", "aiff"); add("alac", "alac"); add("dsf dff", "dsf")
        add("ts tsx", "typescript"); add("rs", "rust"); add("go", "golang"); add("kt kts", "kotlin")
        add("cs fs fsx", "csharp"); add("php phtml", "php"); add("rb", "ruby"); add("lua", "lua"); add("dart", "dart")
        add("sql", "sql"); add("graphql gql", "graphql"); add("wasm", "wasm"); add("asm s", "asm")
        add("xip", "xip"); add("xz txz", "xz"); add("zst tzst", "zst"); add("lz4", "lz4")
        add("cpio", "cpio"); add("cab", "cab"); add("deb", "deb"); add("rpm", "rpm")
        add("p12 pfx", "p12"); add("pem", "pem"); add("mobileprovision provprofile", "mobileprovision")
        add("p7b p7c p7m p7s", "p7b"); add("csr", "csr"); add("sqlite sqlite3 sqlite-wal sqlite-shm", "sqlite"); add("realm", "realm")
        add("docker", "dockerfile")
        // Remaining specialist assets: photo libraries, raw-camera sidecars, network captures,
        // OCR output, panorama projects, theme bundles and web shortcut documents.
        add("appstore appclip", "app_store")
        add("cache cachedata assetcache", "cache")
        add("dng cr2 arw", "camera_raw"); add("dcr kdc x3f cap bay eip", "dslr")
        add("mxf braw r3d cine ari", "filmstrip")
        add("ipa tipa", "ipa")
        add("keychain keychain-db", "keychain")
        add("kra ora", "layers")
        add("pcap pcapng har netlog", "network")
        add("alto hocr ocr", "ocr")
        add("pano pnt 360 vr", "panorama")
        add("cube look 3dl", "prism")
        add("theme skthem theos", "theme")
        add("url webloc website webarchive mht mhtml", "web")
        return map
    }()

    /// All paths resolve to a Hoshino artwork asset. Directory bundles are classified before
    /// generic folders so .app, .framework and .plugin keep their own visual identity.
    static func assetName(for url: URL, isDirectory: Bool, isSymbolicLink: Bool = false,
                          isExecutable: Bool = false) -> String {
        if isSymbolicLink { return "FileIcon_symlink" }
        let filename = url.lastPathComponent.lowercased()
        if let special = filenameMap[filename] { return "FileIcon_\(special)" }
        let ext = url.pathExtension.lowercased()
        if isDirectory {
            switch ext {
            case "app", "appex", "prefpane": return "FileIcon_app"
            case "framework", "xcframework", "bundle": return "FileIcon_framework"
            case "plugin", "qlgenerator": return "FileIcon_plugin"
            case "photoslibrary", "photolibrary": return "FileIcon_sync"
            default: return "FileIcon_folder"
            }
        }
        if isExecutable { return "FileIcon_exe" }
        if let key = extensionMap[ext] { return "FileIcon_\(key)" }
        return "FileIcon_generic"
    }
}

struct FileTypeCornerBadge: View {
    let url: URL
    let isDirectory: Bool
    private var ext: String { isDirectory ? "DIR" : (url.pathExtension.isEmpty ? "FILE" : String(url.pathExtension.uppercased().prefix(5))) }
    private var kind: HoshinoFileKind { HoshinoFileKind.classify(url, isDirectory: isDirectory) }
    var body: some View {
        Text(ext).font(.system(size: ext.count > 4 ? 6 : 7, weight: .heavy, design: .rounded))
            .lineLimit(1).minimumScaleFactor(0.65).fixedSize(horizontal: false, vertical: true)
            .foregroundStyle(.white).padding(.horizontal, 3).padding(.vertical, 2)
            .background(kind.color, in: RoundedRectangle(cornerRadius: 4, style: .continuous))
            .overlay(RoundedRectangle(cornerRadius: 4, style: .continuous).stroke(Color(uiColor: .systemBackground), lineWidth: 1))
            .accessibilityLabel(isDirectory ? "文件夹" : "文件类型 \(ext)")
    }
}
