import Foundation
import CoreFoundation

struct PlistNode: Identifiable, Equatable {
    enum Kind: String, CaseIterable, Identifiable {
        case dictionary = "Dictionary"
        case array = "Array"
        case string = "String"
        case integer = "Integer"
        case real = "Real"
        case boolean = "Boolean"
        case date = "Date"
        case data = "Data"
        var id: String { rawValue }
        var isContainer: Bool { self == .dictionary || self == .array }
    }

    var id: UUID
    var name: String
    var kind: Kind
    var value: String
    var children: [PlistNode]

    init(id: UUID = UUID(), name: String, kind: Kind, value: String = "", children: [PlistNode] = []) {
        self.id = id; self.name = name; self.kind = kind; self.value = value; self.children = children
    }

    var summary: String {
        switch kind {
        case .dictionary: return "\(children.count) 个键值对"
        case .array: return "\(children.count) 个项目"
        case .string: return value.isEmpty ? "空字符串" : value
        case .integer, .real, .boolean, .date: return value
        case .data: return "\(Data(base64Encoded: value)?.count ?? 0) bytes"
        }
    }

    static func parse(_ raw: Any, name: String = "Root") throws -> PlistNode {
        if let dict = raw as? [String: Any] {
            let children = try dict.keys.sorted().map { try parse(dict[$0]!, name: $0) }
            return PlistNode(name: name, kind: .dictionary, children: children)
        }
        if let dict = raw as? NSDictionary {
            var children: [PlistNode] = []
            for (key, value) in dict {
                guard let stringKey = key as? String else { continue }
                children.append(try parse(value, name: stringKey))
            }
            children.sort { $0.name.localizedStandardCompare($1.name) == .orderedAscending }
            return PlistNode(name: name, kind: .dictionary, children: children)
        }
        if let array = raw as? [Any] {
            return PlistNode(name: name, kind: .array,
                             children: try array.enumerated().map { try parse($0.element, name: "[\($0.offset)]") })
        }
        if let string = raw as? String { return PlistNode(name: name, kind: .string, value: string) }
        if let date = raw as? Date { return PlistNode(name: name, kind: .date, value: ISO8601DateFormatter().string(from: date)) }
        if let data = raw as? Data { return PlistNode(name: name, kind: .data, value: data.base64EncodedString()) }
        if let number = raw as? NSNumber {
            if CFGetTypeID(number) == CFBooleanGetTypeID() {
                return PlistNode(name: name, kind: .boolean, value: number.boolValue ? "true" : "false")
            }
            let type = String(cString: number.objCType)
            if type == "f" || type == "d" {
                return PlistNode(name: name, kind: .real, value: number.stringValue)
            }
            return PlistNode(name: name, kind: .integer, value: number.stringValue)
        }
        throw FileSystemError.invalidPlist("不支持的数据类型 \(type(of: raw))")
    }

    func toPropertyListObject() throws -> Any {
        switch kind {
        case .dictionary:
            var result: [String: Any] = [:]
            for child in children {
                guard !child.name.isEmpty else { throw FileSystemError.invalidPlist("字典键名不能为空") }
                guard result[child.name] == nil else { throw FileSystemError.invalidPlist("重复键：\(child.name)") }
                result[child.name] = try child.toPropertyListObject()
            }
            return result
        case .array:
            return try children.map { try $0.toPropertyListObject() }
        case .string:
            return value
        case .integer:
            guard let number = Int64(value) else { throw FileSystemError.invalidPlist("\(name) 不是有效整数") }
            return NSNumber(value: number)
        case .real:
            guard let number = Double(value), number.isFinite else { throw FileSystemError.invalidPlist("\(name) 不是有效实数") }
            return NSNumber(value: number)
        case .boolean:
            return NSNumber(value: value == "true")
        case .date:
            let formatter = ISO8601DateFormatter()
            guard let date = formatter.date(from: value) else { throw FileSystemError.invalidPlist("日期请使用 ISO-8601 格式") }
            return date
        case .data:
            guard let data = Data(base64Encoded: value) else { throw FileSystemError.invalidPlist("Data 必须是有效 Base64") }
            return data
        }
    }

    mutating func update(id target: UUID, with replacement: PlistNode) -> Bool {
        if id == target { self = replacement; return true }
        for index in children.indices {
            if children[index].update(id: target, with: replacement) { return true }
        }
        return false
    }

    mutating func append(_ child: PlistNode, to target: UUID) -> Bool {
        if id == target, kind.isContainer {
            var newChild = child
            if kind == .array { newChild.name = "[\(children.count)]" }
            children.append(newChild); return true
        }
        for index in children.indices { if children[index].append(child, to: target) { return true } }
        return false
    }

    mutating func delete(id target: UUID) -> Bool {
        if let index = children.firstIndex(where: { $0.id == target }) { children.remove(at: index); reindexArrayChildren(); return true }
        for index in children.indices { if children[index].delete(id: target) { return true } }
        return false
    }

    private mutating func reindexArrayChildren() {
        guard kind == .array else { return }
        for index in children.indices { children[index].name = "[\(index)]" }
    }
}
