import SwiftUI
import Foundation

struct HexEditorView: View {
    let fileURL: URL
    let readOnly: Bool
    @Environment(\.dismiss) private var dismiss
    @State private var hexText = ""
    @State private var originalHex = ""
    @State private var address = "0"
    @State private var searchPattern = ""
    @State private var searchResult: String?
    @State private var alertText: String?
    @State private var showSearch = false
    @State private var isLoading = false
    @State private var pageStart: UInt64 = 0
    @State private var pageLength = 0
    @State private var fileSize: UInt64 = 0
    private let pageSize = 64 * 1024

    var body: some View {
        VStack(spacing: 0) {
            HStack(spacing: 8) {
                Text("偏移").font(.caption).foregroundStyle(.secondary)
                TextField("0x0000", text: $address).font(.system(.caption, design: .monospaced)).textFieldStyle(.roundedBorder)
                Button("跳转") { gotoAddress() }.buttonStyle(.bordered)
                Button { loadPage(at: pageStart > UInt64(pageSize) ? pageStart - UInt64(pageSize) : 0) } label: { Image(systemName: "chevron.left") }
                    .disabled(isLoading || pageStart == 0)
                Button { loadPage(at: pageStart + UInt64(pageSize)) } label: { Image(systemName: "chevron.right") }
                    .disabled(isLoading || pageStart + UInt64(pageLength) >= fileSize)
            }.padding(9)
            Divider()
            if isLoading { ProgressView("正在读取当前 64 KB 页面…").frame(maxWidth: .infinity, maxHeight: .infinity) }
            else {
                TextEditor(text: $hexText)
                    .font(.system(size: 12, weight: .regular, design: .monospaced))
                    .autocorrectionDisabled().textInputAutocapitalization(.never)
                    .disabled(readOnly).padding(.horizontal, 6)
            }
            if showSearch {
                HStack {
                    TextField("字节模式，例如 DE AD BE EF", text: $searchPattern)
                        .font(.system(.caption, design: .monospaced)).textFieldStyle(.roundedBorder)
                    Button("全文件搜索") { searchBytes() }.buttonStyle(.borderedProminent)
                }.padding(9)
            }
            HStack {
                Text("偏移 0x\(String(pageStart, radix: 16, uppercase: true))")
                Spacer()
                Text("本页 \(pageLength) / 文件 \(ByteCountFormatter.string(fromByteCount: Int64(fileSize), countStyle: .file))")
                if let searchResult { Text(searchResult).foregroundStyle(.blue) }
            }.font(.system(size: 10, design: .monospaced)).foregroundStyle(.secondary).padding(9).background(.bar)
        }
        .navigationTitle(fileURL.lastPathComponent)
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .navigationBarLeading) { Button("退出") { dismiss() } }
            ToolbarItemGroup(placement: .navigationBarTrailing) {
                Button { showSearch.toggle() } label: { Image(systemName: "magnifyingglass") }
                Button { save() } label: { Image(systemName: "square.and.arrow.down") }.disabled(readOnly || hexText == originalHex || isLoading)
            }
        }
        .onAppear { loadPage(at: 0) }
        .alert("十六进制编辑器", isPresented: Binding(get: { alertText != nil }, set: { if !$0 { alertText = nil } })) {
            Button("好", role: .cancel) { alertText = nil }
        } message: { Text(alertText ?? "") }
    }

    private func loadPage(at requestedOffset: UInt64) {
        isLoading = true; searchResult = nil
        let url = fileURL; let length = pageSize
        DispatchQueue.global(qos: .userInitiated).async {
            let result: Result<(UInt64, UInt64, Int, String), Error> = Result {
                let attrs = try FileManager.default.attributesOfItem(atPath: url.path)
                let size = (attrs[.size] as? NSNumber)?.uint64Value ?? 0
                guard requestedOffset <= size else { throw FileSystemError.invalidData("偏移超出文件范围。") }
                let handle = try FileHandle(forReadingFrom: url); defer { try? handle.close() }
                try handle.seek(toOffset: requestedOffset)
                let data = try handle.read(upToCount: min(length, Int(min(size - requestedOffset, UInt64(length))))) ?? Data()
                let lines = stride(from: 0, to: data.count, by: 16).map { offset -> String in
                    let chunk = data[offset..<min(offset + 16, data.count)]
                    return String(format: "%016llX", requestedOffset + UInt64(offset)) + "  " + chunk.map { String(format: "%02X", $0) }.joined(separator: " ")
                }.joined(separator: "\n")
                return (requestedOffset, size, data.count, lines)
            }
            DispatchQueue.main.async {
                isLoading = false
                switch result {
                case .success(let value): pageStart = value.0; fileSize = value.1; pageLength = value.2; hexText = value.3; originalHex = value.3; address = String(value.0, radix: 16, uppercase: true)
                case .failure(let error): alertText = error.localizedDescription
                }
            }
        }
    }

    private func parsedData() throws -> Data {
        var data = Data()
        for line in hexText.split(separator: "\n") {
            let components = line.split(separator: " ", omittingEmptySubsequences: true)
            guard components.count > 1, components[0].count == 16, UInt64(components[0], radix: 16) != nil else {
                throw FileSystemError.invalidData("每行必须以十六位十六进制偏移开头。")
            }
            for token in components.dropFirst() {
                guard token.count == 2, let byte = UInt8(token, radix: 16) else { throw FileSystemError.invalidData("无效十六进制字节：\(token)") }
                data.append(byte)
            }
        }
        return data
    }

    private func save() {
        do {
            let data = try parsedData()
            guard data.count == pageLength else { throw FileSystemError.invalidData("当前分页必须保持 \(pageLength) bytes；不能通过 HEX 页面改变文件长度。") }
            let handle = try FileHandle(forWritingTo: fileURL); defer { try? handle.close() }
            try handle.seek(toOffset: pageStart); try handle.write(contentsOf: data); try handle.synchronize()
            originalHex = hexText; alertText = "已原位保存当前页面 \(data.count) bytes；文件其他页面未改动。"
        } catch { alertText = error.localizedDescription }
    }

    private func gotoAddress() {
        let cleaned = address.lowercased().replacingOccurrences(of: "0x", with: "")
        guard let offset = UInt64(cleaned, radix: 16), offset < fileSize || (offset == 0 && fileSize == 0) else { alertText = "地址格式无效或超出文件范围。"; return }
        loadPage(at: (offset / UInt64(pageSize)) * UInt64(pageSize))
    }

    private func searchBytes() {
        let pattern = searchPattern.split { !$0.isHexDigit }.compactMap { UInt8($0, radix: 16) }
        guard !pattern.isEmpty else { searchResult = "无搜索内容"; return }
        let url = fileURL
        DispatchQueue.global(qos: .userInitiated).async {
            let found = Self.find(pattern: pattern, in: url)
            DispatchQueue.main.async {
                if let found { searchResult = "命中 0x" + String(found, radix: 16).uppercased(); address = String(found, radix: 16, uppercase: true); loadPage(at: (found / UInt64(pageSize)) * UInt64(pageSize)) }
                else { searchResult = "未找到" }
            }
        }
    }

    private static func find(pattern: [UInt8], in url: URL) -> UInt64? {
        guard let handle = try? FileHandle(forReadingFrom: url) else { return nil }; defer { try? handle.close() }
        let chunkSize = 64 * 1024; var carry = Data(); var base: UInt64 = 0
        while true {
            let chunk = (try? handle.read(upToCount: chunkSize)) ?? nil
            guard let chunk, !chunk.isEmpty else { return nil }
            var data = carry; data.append(chunk)
            if data.count >= pattern.count, let range = data.range(of: Data(pattern)) { return base - UInt64(carry.count) + UInt64(range.lowerBound) }
            let keep = min(pattern.count > 1 ? pattern.count - 1 : 0, data.count)
            carry = keep > 0 ? data.suffix(keep) : Data(); base += UInt64(chunk.count)
        }
    }
}
