import SwiftUI

struct CSVEditorView: View {
    let fileURL: URL
    let readOnly: Bool
    @Environment(\.dismiss) private var dismiss
    @State private var rows: [[String]] = []
    @State private var delimiter = ","
    @State private var alertText: String?

    var body: some View {
        VStack(spacing: 0) {
            HStack {
                Text("\(rows.count) 行 · \(rows.map(\.count).max() ?? 0) 列")
                Spacer()
                Menu("表格") {
                    Button("添加行") { rows.append(Array(repeating: "", count: max(1, columnCount))) }
                    Button("添加列") { for index in rows.indices { rows[index].append("") } }
                    Button("使用逗号分隔") { delimiter = "," }
                    Button("使用制表符分隔") { delimiter = "\t" }
                }.disabled(readOnly)
            }.font(.caption).padding(10).background(.bar)
            Divider()
            if rows.isEmpty {
                ContentUnavailableViewCompat(title: "空表格", message: "可以添加行或打开已有 CSV/TSV 文件。", systemImage: "tablecells")
            } else {
                ScrollView([.horizontal, .vertical]) {
                    LazyVStack(alignment: .leading, spacing: 0) {
                        ForEach(rows.indices, id: \.self) { row in
                            HStack(spacing: 0) {
                                Text("\(row + 1)").font(.system(.caption2, design: .monospaced)).foregroundStyle(.secondary)
                                    .frame(width: 36, height: 42).background(.quaternary)
                                ForEach(rows[row].indices, id: \.self) { column in
                                    TextField("", text: Binding(
                                        get: { rows[row][column] },
                                        set: { rows[row][column] = $0 }
                                    ))
                                    .font(.system(size: 12, design: .monospaced))
                                    .textFieldStyle(.plain).padding(.horizontal, 8)
                                    .frame(width: 160, height: 42, alignment: .leading)
                                    .disabled(readOnly)
                                    .overlay(Rectangle().stroke(Color.secondary.opacity(0.18), lineWidth: 0.5))
                                }
                            }
                        }
                    }
                }
            }
        }
        .navigationTitle(fileURL.lastPathComponent)
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .navigationBarLeading) { Button("退出") { dismiss() } }
            ToolbarItem(placement: .navigationBarTrailing) {
                Button { save() } label: { Image(systemName: "square.and.arrow.down") }.disabled(readOnly)
            }
        }
        .onAppear(perform: load)
        .alert("CSV 编辑器", isPresented: Binding(get: { alertText != nil }, set: { if !$0 { alertText = nil } })) {
            Button("好", role: .cancel) { alertText = nil }
        } message: { Text(alertText ?? "") }
    }

    private var columnCount: Int { rows.map(\.count).max() ?? 1 }

    private func load() {
        let url = fileURL
        DispatchQueue.global(qos: .userInitiated).async {
            let result: Result<([[String]], String), Error> = Result {
                let values = try url.resourceValues(forKeys: [.fileSizeKey])
                guard (values.fileSize ?? 0) <= 8 * 1024 * 1024 else { throw FileSystemError.invalidData("CSV/TSV 编辑限制 8 MB，避免大型表格造成内存占用。请拆分文件或使用文本查看器。") }
                let text = try String(contentsOf: url, encoding: .utf8)
                let separator = url.pathExtension.lowercased() == "tsv" ? "\t" : ","
                let parsed = Self.parse(text, delimiter: separator)
                guard parsed.count <= 20_000 else { throw FileSystemError.invalidData("CSV 行数超过 20,000 行，暂不允许在表格编辑器中整体编辑。请使用文本查看器或拆分文件。") }
                return (parsed, separator)
            }
            DispatchQueue.main.async {
                switch result {
                case .success(let value): delimiter = value.1; rows = value.0.isEmpty ? [[""]] : value.0
                case .failure(let error): alertText = error.localizedDescription
                }
            }
        }
    }

    private func save() {
        let output = rows.map { row in row.map(escape).joined(separator: delimiter) }.joined(separator: "\n")
        do { try Data(output.utf8).write(to: fileURL, options: .atomic); alertText = "保存成功。" }
        catch { alertText = error.localizedDescription }
    }

    private func escape(_ field: String) -> String {
        guard field.contains(delimiter) || field.contains("\"") || field.contains("\n") else { return field }
        return "\"" + field.replacingOccurrences(of: "\"", with: "\"\"") + "\""
    }

    private static func parse(_ text: String, delimiter: String) -> [[String]] {
        var result: [[String]] = [[]]
        var field = ""
        var quoted = false
        let chars = Array(text)
        var index = 0
        while index < chars.count {
            let char = chars[index]
            if char == "\"" {
                if quoted && index + 1 < chars.count && chars[index + 1] == "\"" { field.append("\""); index += 1 }
                else { quoted.toggle() }
            } else if !quoted && String(char) == delimiter {
                result[result.count - 1].append(field); field = ""
            } else if !quoted && (char == "\n" || char == "\r") {
                result[result.count - 1].append(field); field = ""
                if char == "\r", index + 1 < chars.count, chars[index + 1] == "\n" { index += 1 }
                if index < chars.count - 1 { result.append([]) }
            } else { field.append(char) }
            index += 1
        }
        result[result.count - 1].append(field)
        return result.filter { !($0.count == 1 && $0[0].isEmpty) }
    }
}
