import SwiftUI
import Foundation

struct PlistEditorView: View {
    let fileURL: URL
    let readOnly: Bool
    @Environment(\.dismiss) private var dismiss
    @State private var root: PlistNode?
    @State private var plistFormat: PropertyListSerialization.PropertyListFormat = .xml
    @State private var editingNode: PlistNode?
    @State private var addingTo: PlistNode?
    @State private var alertText: String?
    @State private var isDirty = false
    @State private var showRaw = false
    @State private var isLoading = false

    var body: some View {
        Group {
            if isLoading {
                ProgressView("正在解析 Plist…").frame(maxWidth: .infinity, maxHeight: .infinity)
            } else if let root {
                List {
                    Section {
                        HStack {
                            Label("\(plistFormat == .binary ? "Binary" : "XML") Plist", systemImage: "list.tree")
                            Spacer()
                            Text(isDirty ? "未保存" : "已加载")
                                .font(.caption).foregroundStyle(isDirty ? .orange : .secondary)
                        }
                    }
                    Section("对象树") {
                        PlistTreeRow(node: root, depth: 0,
                                     canEdit: !readOnly,
                                     onEdit: { editingNode = $0 },
                                     onAdd: { addingTo = $0 },
                                     onDelete: { deleteNode($0) })
                    }
                }
                .listStyle(.insetGrouped)
            } else {
                ContentUnavailableViewCompat(title: "无法读取 Plist", message: "文件可能损坏，或不是有效的 Apple Property List。", systemImage: "exclamationmark.triangle")
            }
        }
        .navigationTitle(fileURL.lastPathComponent)
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .navigationBarLeading) { Button("退出") { dismiss() } }
            ToolbarItemGroup(placement: .navigationBarTrailing) {
                if let root, root.kind.isContainer && !readOnly {
                    Menu {
                        Button { addingTo = root } label: { Label("添加根节点", systemImage: "plus") }
                        Button { showRaw = true } label: { Label("查看原始 XML", systemImage: "chevron.left.forwardslash.chevron.right") }
                    } label: { Image(systemName: "plus.circle") }
                } else if !readOnly {
                    Button { showRaw = true } label: { Image(systemName: "chevron.left.forwardslash.chevron.right") }
                }
                Button { save() } label: { Image(systemName: "square.and.arrow.down") }
                    .disabled(readOnly || !isDirty || root == nil)
            }
        }
        .onAppear(perform: load)
        .sheet(item: $editingNode) { node in
            NavigationView {
                PlistNodeEditSheet(node: node, isNew: false) { updated in
                    guard var current = root else { return }
                    _ = current.update(id: node.id, with: updated)
                    root = current; isDirty = true
                }
            }
        }
        .sheet(item: $addingTo) { parent in
            NavigationView {
                PlistNodeEditSheet(node: PlistNode(name: "NewKey", kind: .string), isNew: true) { newNode in
                    guard var current = root else { return }
                    _ = current.append(newNode, to: parent.id)
                    root = current; isDirty = true
                }
            }
        }
        .sheet(isPresented: $showRaw) {
            NavigationView {
                PlistRawView(fileURL: fileURL)
                    .navigationTitle("原始 Plist")
                    .navigationBarTitleDisplayMode(.inline)
                    .toolbar { ToolbarItem(placement: .navigationBarTrailing) { Button("关闭") { showRaw = false } } }
            }
        }
        .alert("Plist 编辑器", isPresented: Binding(get: { alertText != nil }, set: { if !$0 { alertText = nil } })) {
            Button("好", role: .cancel) { alertText = nil }
        } message: { Text(alertText ?? "") }
    }

    private func load() {
        isLoading = true
        let url = fileURL
        DispatchQueue.global(qos: .userInitiated).async {
            let result: Result<(PlistNode, PropertyListSerialization.PropertyListFormat), Error> = Result {
                let values = try url.resourceValues(forKeys: [.fileSizeKey])
                guard (values.fileSize ?? 0) <= 8 * 1024 * 1024 else { throw FileSystemError.invalidData("Plist 树形编辑限制 8 MB；更大的文件请使用原始查看器，避免对象树占用过多内存。") }
                let data = try Data(contentsOf: url, options: [.mappedIfSafe])
                var format = PropertyListSerialization.PropertyListFormat.xml
                let object = try PropertyListSerialization.propertyList(from: data, options: [.mutableContainersAndLeaves], format: &format)
                return (try PlistNode.parse(object), format)
            }
            DispatchQueue.main.async {
                isLoading = false
                switch result {
                case .success(let value): root = value.0; plistFormat = value.1
                case .failure(let error): alertText = error.localizedDescription
                }
            }
        }
    }

    private func save() {
        guard let root else { return }
        do {
            let object = try root.toPropertyListObject()
            let data = try PropertyListSerialization.data(fromPropertyList: object, format: plistFormat, options: 0)
            try data.write(to: fileURL, options: .atomic)
            isDirty = false
            alertText = "保存成功。"
        } catch { alertText = error.localizedDescription }
    }

    private func deleteNode(_ id: UUID) {
        guard var current = root else { return }
        _ = current.delete(id: id); root = current; isDirty = true
    }
}

private struct PlistTreeRow: View {
    let node: PlistNode
    let depth: Int
    let canEdit: Bool
    let onEdit: (PlistNode) -> Void
    let onAdd: (PlistNode) -> Void
    let onDelete: (UUID) -> Void

    var body: some View {
        if node.kind.isContainer {
            DisclosureGroup {
                if node.children.isEmpty {
                    Text("空容器").font(.caption).foregroundStyle(.secondary).padding(.vertical, 5)
                }
                ForEach(node.children) { child in
                    PlistTreeRow(node: child, depth: depth + 1, canEdit: canEdit,
                                 onEdit: onEdit, onAdd: onAdd, onDelete: onDelete)
                }
            } label: {
                rowLabel
            }
            .contextMenu {
                if canEdit {
                    Button { onEdit(node) } label: { Label("编辑键名", systemImage: "pencil") }
                    Button { onAdd(node) } label: { Label("添加子节点", systemImage: "plus") }
                    if depth > 0 { Button(role: .destructive) { onDelete(node.id) } label: { Label("删除", systemImage: "trash") } }
                }
            }
        } else {
            rowLabel
                .contentShape(Rectangle())
                .onTapGesture { if canEdit { onEdit(node) } }
                .contextMenu {
                    if canEdit {
                        Button { onEdit(node) } label: { Label("编辑", systemImage: "pencil") }
                        Button(role: .destructive) { onDelete(node.id) } label: { Label("删除", systemImage: "trash") }
                    }
                }
        }
    }

    private var rowLabel: some View {
        HStack(spacing: 9) {
            Image(systemName: icon)
                .foregroundStyle(node.kind.isContainer ? .blue : .secondary)
                .frame(width: 20)
            VStack(alignment: .leading, spacing: 2) {
                Text(node.name).font(.system(size: 13, weight: .semibold)).lineLimit(1)
                Text(node.kind.isContainer ? node.summary : node.summary)
                    .font(.system(size: 11, design: .monospaced)).foregroundStyle(.secondary).lineLimit(2)
            }
            Spacer(minLength: 0)
            Text(node.kind.rawValue).font(.system(size: 9, weight: .medium)).foregroundStyle(.tertiary)
        }
        .padding(.vertical, 3)
    }

    private var icon: String {
        switch node.kind {
        case .dictionary: return "character.book.closed"
        case .array: return "list.number"
        case .string: return "textformat"
        case .integer, .real: return "number"
        case .boolean: return "switch.2"
        case .date: return "calendar"
        case .data: return "doc.zipper"
        }
    }
}

private struct PlistNodeEditSheet: View {
    @Environment(\.dismiss) private var dismiss
    @State var node: PlistNode
    let isNew: Bool
    let onCommit: (PlistNode) -> Void

    var body: some View {
        Form {
            if node.kind != .array || isNew {
                Section("键名") {
                    TextField("Key", text: $node.name)
                        .textInputAutocapitalization(.never).autocorrectionDisabled()
                }
            }
            Section("类型") {
                Picker("值类型", selection: $node.kind) {
                    ForEach(PlistNode.Kind.allCases) { kind in Text(kind.rawValue).tag(kind) }
                }
            }
            if node.kind == .boolean {
                Toggle("布尔值", isOn: Binding(get: { node.value == "true" }, set: { node.value = $0 ? "true" : "false" }))
            } else if node.kind.isContainer {
                Text("保存后可在对象树中继续添加子节点。")
                    .font(.caption).foregroundStyle(.secondary)
            } else {
                Section("值") {
                    TextEditor(text: $node.value).frame(minHeight: node.kind == .data ? 130 : 90)
                        .font(.system(.body, design: .monospaced))
                    if node.kind == .date { Text("使用 ISO-8601，例如 2025-01-01T10:00:00Z").font(.caption).foregroundStyle(.secondary) }
                    if node.kind == .data { Text("输入 Base64 编码数据").font(.caption).foregroundStyle(.secondary) }
                }
            }
        }
        .navigationTitle(isNew ? "添加节点" : "编辑节点")
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .cancellationAction) { Button("取消") { dismiss() } }
            ToolbarItem(placement: .confirmationAction) {
                Button("完成") { onCommit(node); dismiss() }
                    .disabled(node.kind != .array && node.name.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
            }
        }
    }
}

private struct PlistRawView: View {
    let fileURL: URL
    @State private var raw = ""
    var body: some View {
        ScrollView { Text(raw).font(.system(.caption, design: .monospaced)).frame(maxWidth: .infinity, alignment: .leading).padding() }
            .onAppear { raw = (try? String(contentsOf: fileURL, encoding: .utf8)) ?? "二进制 Plist 无法以文本显示。" }
    }
}

struct ContentUnavailableViewCompat: View {
    let title: String
    let message: String
    let systemImage: String
    var body: some View {
        VStack(spacing: 12) {
            Image(systemName: systemImage).font(.system(size: 38)).foregroundStyle(.secondary)
            Text(title).font(.headline)
            Text(message).font(.caption).foregroundStyle(.secondary).multilineTextAlignment(.center)
        }.padding(30).frame(maxWidth: .infinity, maxHeight: .infinity)
    }
}
