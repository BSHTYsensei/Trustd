import SwiftUI
import UIKit

struct TextFileEditorView: View {
    let fileURL: URL
    let readOnly: Bool
    let syntaxHint: String
    @Environment(\.dismiss) private var dismiss
    @State private var text = ""
    @State private var originalText = ""
    @State private var showSearch = false
    @State private var searchText = ""
    @State private var replaceText = ""
    @State private var showReplace = false
    @State private var showDiscardConfirmation = false
    @State private var matchCount = 0
    @State private var alertText: String?
    @State private var isLoading = true
    @State private var wrapLines = true
    @State private var textEncoding: String.Encoding = .utf8

    private var dirty: Bool { text != originalText }

    var body: some View {
        VStack(spacing: 0) {
            if showSearch {
                HStack(spacing: 8) {
                    Image(systemName: "magnifyingglass").foregroundStyle(.secondary)
                    TextField("查找文本", text: $searchText)
                        .textInputAutocapitalization(.never).autocorrectionDisabled()
                        .onChange(of: searchText) { updateMatchCount() }
                    Text("\(matchCount) 处").font(.caption).foregroundStyle(.secondary)
                    Button { showReplace.toggle() } label: { Image(systemName: "arrow.left.arrow.right") }
                    Button { showSearch = false; showReplace = false } label: { Image(systemName: "xmark.circle.fill") }
                }.padding(10).background(.thinMaterial)
                if showReplace {
                    HStack {
                        TextField("替换为", text: $replaceText).textInputAutocapitalization(.never).autocorrectionDisabled()
                        Button("替换全部") { replaceAll() }.disabled(readOnly || searchText.isEmpty)
                    }.padding(.horizontal, 10).padding(.bottom, 8).background(.thinMaterial)
                }
            }
            if isLoading {
                ProgressView("正在读取文件…").frame(maxWidth: .infinity, maxHeight: .infinity)
            } else {
                SyntaxTextView(text: $text, isEditable: !readOnly, language: syntaxHint, wrapLines: wrapLines)
                    .background(Color(uiColor: .systemBackground))
            }
            HStack {
                Text("\(text.count) 字符 · \(text.utf8.count) bytes")
                Spacer()
                if dirty { Text("未保存").foregroundStyle(.orange) }
                Text(readOnly ? "只读" : "可编辑")
                    .foregroundStyle(readOnly ? .orange : .secondary)
            }
            .font(.system(size: 10, design: .monospaced)).padding(.horizontal, 12).padding(.vertical, 7)
            .background(.bar)
        }
        .navigationTitle(fileURL.lastPathComponent)
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .navigationBarLeading) { Button("退出") { if dirty { showDiscardConfirmation = true } else { dismiss() } } }
            ToolbarItemGroup(placement: .navigationBarTrailing) {
                Button { showSearch.toggle() } label: { Image(systemName: "magnifyingglass") }
                Menu {
                    Button { wrapLines.toggle() } label: { Label(wrapLines ? "关闭自动换行" : "开启自动换行", systemImage: "text.alignleft") }
                    if syntaxHint == "json" || fileURL.pathExtension.lowercased() == "json" {
                        Button { formatJSON() } label: { Label("格式化 JSON", systemImage: "curlybraces") }
                    }
                    Button { UIPasteboard.general.string = text } label: { Label("复制全部文本", systemImage: "doc.on.doc") }
                } label: { Image(systemName: "ellipsis.circle") }
                Button { save() } label: { Image(systemName: "square.and.arrow.down") }
                    .disabled(readOnly || !dirty)
            }
        }
        .onAppear(perform: load)
        .alert("文本编辑器", isPresented: Binding(get: { alertText != nil }, set: { if !$0 { alertText = nil } })) {
            Button("好", role: .cancel) { alertText = nil }
        } message: { Text(alertText ?? "") }
        .confirmationDialog("存在未保存的修改", isPresented: $showDiscardConfirmation, titleVisibility: .visible) {
            Button("保存并退出") { if save() { dismiss() } }
            Button("放弃修改", role: .destructive) { dismiss() }
            Button("继续编辑", role: .cancel) { }
        } message: { Text("退出前是否保存当前内容？") }
    }

    private func load() {
        isLoading = true
        DispatchQueue.global(qos: .userInitiated).async {
            let result: Result<(String, String.Encoding), Error> = Result {
                let values = try fileURL.resourceValues(forKeys: [.fileSizeKey])
                if (values.fileSize ?? 0) > 16 * 1024 * 1024 {
                    throw FileSystemError.invalidData("文本编辑器单次限制 16 MB；更大的文本请使用 Quick Look 或分段查看，避免整份载入内存。")
                }
                let data = try Data(contentsOf: fileURL, options: [.mappedIfSafe])
                if let value = String(data: data, encoding: .utf8) { return (value, .utf8) }
                if let value = String(data: data, encoding: .utf16) { return (value, .utf16) }
                if let value = String(data: data, encoding: .isoLatin1) { return (value, .isoLatin1) }
                throw FileSystemError.invalidData("无法识别文本编码。")
            }
            DispatchQueue.main.async {
                switch result {
                case .success(let value): text = value.0; originalText = value.0; textEncoding = value.1
                case .failure(let error): alertText = error.localizedDescription
                }
                isLoading = false
            }
        }
    }

    @discardableResult private func save() -> Bool {
        do {
            let encoded = text.data(using: textEncoding) ?? text.data(using: .utf8)!
            try encoded.write(to: fileURL, options: .atomic)
            if text.data(using: textEncoding) == nil { textEncoding = .utf8 }
            originalText = text
            alertText = "保存成功。"
            return true
        } catch { alertText = error.localizedDescription; return false }
    }

    private func formatJSON() {
        guard let data = text.data(using: .utf8) else { return }
        do {
            let object = try JSONSerialization.jsonObject(with: data, options: [.fragmentsAllowed])
            let formatted = try JSONSerialization.data(withJSONObject: object, options: [.prettyPrinted, .sortedKeys, .fragmentsAllowed])
            text = String(data: formatted, encoding: .utf8) ?? text
        } catch { alertText = "JSON 格式错误：\(error.localizedDescription)" }
    }

    private func updateMatchCount() {
        guard !searchText.isEmpty else { matchCount = 0; return }
        let source = text as NSString; let needle = searchText as NSString
        var cursor = 0; var count = 0
        while cursor < source.length {
            let range = source.range(of: searchText, options: [], range: NSRange(location: cursor, length: source.length - cursor))
            if range.location == NSNotFound { break }
            count += 1; cursor = range.location + max(1, needle.length)
        }
        matchCount = count
    }

    private func replaceAll() {
        guard !searchText.isEmpty else { return }
        let count = matchCount
        text = text.replacingOccurrences(of: searchText, with: replaceText)
        updateMatchCount()
        alertText = "已替换 \(count) 处。"
    }
}

struct SyntaxTextView: UIViewRepresentable {
    @Binding var text: String
    let isEditable: Bool
    let language: String
    let wrapLines: Bool

    func makeUIView(context: Context) -> UITextView {
        let view = UITextView()
        view.delegate = context.coordinator
        view.font = UIFont.monospacedSystemFont(ofSize: 13, weight: .regular)
        view.backgroundColor = .systemBackground
        view.textColor = .label
        view.autocorrectionType = .no
        view.autocapitalizationType = .none
        view.smartQuotesType = .no
        view.smartDashesType = .no
        view.isEditable = isEditable
        view.alwaysBounceVertical = true
        view.textContainer.widthTracksTextView = wrapLines
        view.textContainer.lineBreakMode = wrapLines ? .byWordWrapping : .byClipping
        view.alwaysBounceHorizontal = !wrapLines
        view.textContainerInset = UIEdgeInsets(top: 13, left: 12, bottom: 24, right: 12)
        view.text = text
        applyHighlight(to: view)
        return view
    }

    func updateUIView(_ view: UITextView, context: Context) {
        context.coordinator.parent = self
        view.isEditable = isEditable
        view.textContainer.widthTracksTextView = wrapLines
        view.textContainer.lineBreakMode = wrapLines ? .byWordWrapping : .byClipping
        view.alwaysBounceHorizontal = !wrapLines
        if view.text != text {
            let selected = view.selectedRange
            view.text = text
            applyHighlight(to: view)
            view.selectedRange = NSRange(location: min(selected.location, (text as NSString).length), length: 0)
        }
    }

    func makeCoordinator() -> Coordinator { Coordinator(self) }

    private func applyHighlight(to view: UITextView) {
        let source = text as NSString
        let result = NSMutableAttributedString(string: text, attributes: [
            .font: UIFont.monospacedSystemFont(ofSize: 13, weight: .regular),
            .foregroundColor: UIColor.label
        ])
        // Avoid full-document regex passes on large buffers; editing remains responsive.
        guard source.length <= 300_000 else { view.attributedText = result; return }
        let rules: [(String, UIColor)] = [
            ("//[^\\n]*|#[^\\n]*", .secondaryLabel),
            ("\"(?:\\\\.|[^\"\\\\])*\"", .systemRed),
            ("\\b(true|false|null|nil|YES|NO)\\b", .systemPurple),
            ("\\b(0x[0-9A-Fa-f]+|[0-9]+(?:\\.[0-9]+)?)\\b", .systemOrange),
            ("</?[A-Za-z][^>]*>", .systemBlue),
            ("\\b(import|func|class|struct|enum|let|var|return|if|else|for|while|switch|case|try|throw|guard|public|private|static|async|await)\\b", .systemIndigo)
        ]
        for (pattern, color) in rules {
            guard let regex = try? NSRegularExpression(pattern: pattern, options: []) else { continue }
            for match in regex.matches(in: text, range: NSRange(location: 0, length: source.length)) {
                result.addAttribute(.foregroundColor, value: color, range: match.range)
            }
        }
        view.attributedText = result
        view.typingAttributes = [.font: UIFont.monospacedSystemFont(ofSize: 13, weight: .regular), .foregroundColor: UIColor.label]
    }

    final class Coordinator: NSObject, UITextViewDelegate {
        var parent: SyntaxTextView
        init(_ parent: SyntaxTextView) { self.parent = parent }
        func textViewDidChange(_ textView: UITextView) { parent.text = textView.text }
    }
}
