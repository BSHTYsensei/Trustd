import SwiftUI
import AVKit
import QuickLook
import UIKit
import Darwin
import ImageIO

struct ImagePreviewView: View {
    @Environment(\.dismiss) private var dismiss
    let fileURL: URL
    @State private var image: UIImage?
    @State private var scale: CGFloat = 1
    @State private var lastScale: CGFloat = 1

    var body: some View {
        Group {
            if let image {
                ScrollView([.horizontal, .vertical]) {
                    Image(uiImage: image).resizable().aspectRatio(contentMode: .fit)
                        .scaleEffect(scale).frame(maxWidth: .infinity, maxHeight: .infinity)
                        .gesture(MagnificationGesture().onChanged { value in scale = min(max(1, lastScale * value), 6) }
                            .onEnded { _ in lastScale = scale })
                }.background(Color.black)
            } else {
                ContentUnavailableViewCompat(title: "无法预览图片", message: "图片格式可能不受支持或文件已损坏。", systemImage: "photo")
            }
        }
        .navigationTitle(fileURL.lastPathComponent)
        .navigationBarTitleDisplayMode(.inline)
        .toolbar { ToolbarItem(placement: .navigationBarTrailing) { Button("退出") { dismiss() } } }
        .onAppear {
            let url = fileURL
            DispatchQueue.global(qos: .userInitiated).async {
                let options: [CFString: Any] = [kCGImageSourceShouldCache: false]
                let thumbnailOptions: [CFString: Any] = [kCGImageSourceCreateThumbnailFromImageAlways: true, kCGImageSourceThumbnailMaxPixelSize: 2048, kCGImageSourceShouldCacheImmediately: true]
                let result = CGImageSourceCreateWithURL(url as CFURL, options as CFDictionary).flatMap { CGImageSourceCreateThumbnailAtIndex($0, 0, thumbnailOptions as CFDictionary) }.map(UIImage.init(cgImage:))
                DispatchQueue.main.async { image = result }
            }
        }
    }
}

struct MediaPlayerView: View {
    @Environment(\.dismiss) private var dismiss
    let fileURL: URL
    @State private var player: AVPlayer?
    @State private var isVideo = false

    var body: some View {
        Group {
            if let player {
                if isVideo {
                    VideoPlayer(player: player).background(Color.black)
                } else {
                    VStack(spacing: 18) {
                        Image(systemName: "waveform").font(.system(size: 66, weight: .light)).foregroundStyle(.secondary)
                        Text(fileURL.lastPathComponent).font(.headline).multilineTextAlignment(.center)
                        VideoPlayer(player: player).frame(height: 70)
                    }.padding()
                }
            } else {
                ProgressView("正在载入媒体…")
            }
        }
        .navigationTitle(fileURL.lastPathComponent)
        .navigationBarTitleDisplayMode(.inline)
        .toolbar { ToolbarItem(placement: .navigationBarTrailing) { Button("退出") { dismiss() } } }
        .onAppear {
            let ext = fileURL.pathExtension.lowercased()
            isVideo = ["mp4", "mov", "m4v", "mkv", "avi"].contains(ext)
            player = AVPlayer(url: fileURL)
        }
        .onDisappear { player?.pause(); player = nil }
    }
}

struct QuickLookPreviewView: UIViewControllerRepresentable {
    let fileURL: URL

    func makeUIViewController(context: Context) -> QLPreviewController {
        let controller = QLPreviewController()
        controller.dataSource = context.coordinator
        return controller
    }
    func updateUIViewController(_ controller: QLPreviewController, context: Context) {}
    func makeCoordinator() -> Coordinator { Coordinator(fileURL: fileURL) }

    final class Coordinator: NSObject, QLPreviewControllerDataSource {
        let fileURL: URL
        init(fileURL: URL) { self.fileURL = fileURL }
        func numberOfPreviewItems(in controller: QLPreviewController) -> Int { 1 }
        func previewController(_ controller: QLPreviewController, previewItemAt index: Int) -> QLPreviewItem {
            fileURL as NSURL
        }
    }
}

struct FileEditorRouter: View {
    let fileURL: URL
    @ObservedObject private var associations = EditorAssociationStore.shared
    @State private var resolvedReadOnly = false

    var body: some View {
        Group {
            switch associations.kind(for: fileURL) {
            case .text:
                TextFileEditorView(fileURL: fileURL, readOnly: resolvedReadOnly, syntaxHint: fileURL.pathExtension.lowercased())
            case .plist:
                PlistEditorView(fileURL: fileURL, readOnly: resolvedReadOnly)
            case .hex:
                HexEditorView(fileURL: fileURL, readOnly: resolvedReadOnly)
            case .json:
                TextFileEditorView(fileURL: fileURL, readOnly: resolvedReadOnly, syntaxHint: "json")
            case .csv:
                CSVEditorView(fileURL: fileURL, readOnly: resolvedReadOnly)
            case .archive:
                ArchiveBrowserView(fileURL: fileURL)
            case .image:
                ImagePreviewView(fileURL: fileURL)
            case .media:
                MediaPlayerView(fileURL: fileURL)
            case .quickLook:
                QuickLookPreviewView(fileURL: fileURL)
            }
        }
        .onAppear { resolvedReadOnly = Self.isReadOnly(fileURL) }
    }

    private static func isReadOnly(_ url: URL) -> Bool {
        guard let meta = try? FileSystemService.shared.metadata(for: url) else { return true }
        if meta.immutable { return true }
        let mode = meta.mode
        let euid = geteuid()
        if euid == 0 { return false }
        if euid == meta.owner { return (mode & S_IWUSR) == 0 }
        if getegid() == meta.group { return (mode & S_IWGRP) == 0 }
        return (mode & S_IWOTH) == 0
    }
}
