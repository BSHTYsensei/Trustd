import SwiftUI

struct ArchiveBrowserView: View {
    let fileURL: URL
    @State private var entries: [ArchiveEntryInfo] = []
    @State private var isExtracting = false
    @State private var isLoadingEntries = false
    @State private var requiresPassword = false
    @State private var message: String?
    @State private var password = ""
    @Environment(\.dismiss) private var dismiss

    private var acceptsPassword: Bool { ["zip", "7z", "rar"].contains(fileURL.pathExtension.lowercased()) }
    private var archiveLabel: String { fileURL.pathExtension.uppercased().isEmpty ? "归档" : fileURL.pathExtension.uppercased() }

    var body: some View {
        List {
            Section {
                HStack {
                    Label("\(archiveLabel) 归档", systemImage: "archivebox.fill")
                    Spacer()
                    Text("\(entries.count) 项").font(.caption).foregroundStyle(.secondary)
                }
                if acceptsPassword {
                    SecureField("归档密码（无密码可留空）", text: $password)
                        .textInputAutocapitalization(.never).autocorrectionDisabled()
                    Button {
                        load(usingPassword: true)
                    } label: {
                        if isLoadingEntries { ProgressView("正在读取目录…") }
                        else { Label("读取加密归档目录", systemImage: "arrow.clockwise") }
                    }.disabled(isLoadingEntries || password.isEmpty)
                    if requiresPassword {
                        Text("该归档可能使用了密码。输入密码后点按“读取加密归档目录”，即可查看内容。")
                            .font(.caption).foregroundStyle(.secondary)
                    }
                }
                Button { extractHere() } label: {
                    if isExtracting { ProgressView("正在解压…") }
                    else { Label("解压到当前文件所在目录", systemImage: "arrow.down.doc") }
                }.disabled(isExtracting || entries.isEmpty)
            }
            Section("内容") {
                ForEach(entries) { entry in
                    HStack(spacing: 10) {
                        Image(FileTypeIconAssets.assetName(for: URL(fileURLWithPath: entry.path),
                                                            isDirectory: entry.isDirectory,
                                                            isSymbolicLink: entry.isSymbolicLink))
                            .resizable().scaledToFit().frame(width: 32, height: 32)
                        VStack(alignment: .leading, spacing: 2) {
                            Text(entry.path).font(.system(size: 12, weight: .medium)).lineLimit(2)
                            Text(entry.isDirectory ? "文件夹" : (entry.isSymbolicLink ? "符号链接 · \(entry.linkTarget ?? "")" : ByteCountFormatter.string(fromByteCount: Int64(entry.size), countStyle: .file)))
                                .font(.caption2).foregroundStyle(.secondary).lineLimit(2)
                        }
                        Spacer()
                    }
                }
            }
            Section {
                Text("归档核心由 libarchive 提供。RAR/CAB 为只读格式；DEB 先解包外层 ar 容器，内部 data/control 归档可继续单独打开。裸 GZ/BZ2/XZ 仅包含单个文件。")
                    .font(.caption).foregroundStyle(.secondary)
            }
        }
        .navigationTitle(fileURL.lastPathComponent).navigationBarTitleDisplayMode(.inline)
        .toolbar { ToolbarItem(placement: .navigationBarTrailing) { Button("退出") { dismiss() } } }
        .onAppear { load(usingPassword: false) }
        .alert("归档", isPresented: Binding(get: { message != nil }, set: { if !$0 { message = nil } })) {
            Button("好", role: .cancel) { message = nil }
        } message: { Text(message ?? "") }
    }

    private func load(usingPassword: Bool) {
        guard !isLoadingEntries else { return }
        isLoadingEntries = true
        let selectedPassword = usingPassword && !password.isEmpty ? password : nil
        DispatchQueue.global(qos: .userInitiated).async {
            let result: Result<[ArchiveEntryInfo], Error> = Result {
                try ArchiveService.shared.entries(at: fileURL, password: selectedPassword)
            }
            DispatchQueue.main.async {
                isLoadingEntries = false
                switch result {
                case .success(let values):
                    entries = values
                    requiresPassword = false
                    message = nil
                case .failure(let error):
                    entries = []
                    if acceptsPassword && !usingPassword {
                        requiresPassword = true
                    } else {
                        message = error.localizedDescription
                    }
                }
            }
        }
    }

    private func extractHere() {
        isExtracting = true
        let parent = fileURL.deletingLastPathComponent()
        let stem = fileURL.lastPathComponent.replacingOccurrences(of: ".tar.gz", with: "", options: [.caseInsensitive, .backwards])
            .replacingOccurrences(of: ".tar.bz2", with: "", options: [.caseInsensitive, .backwards])
            .replacingOccurrences(of: ".tar.xz", with: "", options: [.caseInsensitive, .backwards])
            .replacingOccurrences(of: ".\(fileURL.pathExtension)", with: "", options: [.caseInsensitive, .backwards])
        var destination = parent.appendingPathComponent(stem, isDirectory: true)
        var suffix = 2
        while FileManager.default.fileExists(atPath: destination.path) {
            destination = parent.appendingPathComponent("\(stem) \(suffix)", isDirectory: true)
            suffix += 1
        }
        let selectedPassword = password.isEmpty ? nil : password
        DispatchQueue.global(qos: .userInitiated).async {
            let result: Result<Void, Error> = Result {
                try ArchiveService.shared.extractArchive(fileURL, to: destination, password: selectedPassword)
            }
            DispatchQueue.main.async {
                isExtracting = false
                switch result {
                case .success: message = "解压完成：\(destination.path)"
                case .failure(let error): message = error.localizedDescription
                }
            }
        }
    }
}
