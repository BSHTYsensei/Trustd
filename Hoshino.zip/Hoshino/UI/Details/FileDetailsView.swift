import SwiftUI
import Darwin
import UIKit

struct FileDetailsView: View {
    let file: HoshinoFile
    @Environment(\.dismiss) private var dismiss
    @State private var metadata: HoshinoFileMetadata?
    @State private var permissions = ""
    @State private var ownerUID = ""
    @State private var ownerGID = ""
    @State private var recursive = false
    @State private var immutable = false
    @State private var pendingImmutable = false
    @State private var confirmProtection = false
    @State private var hashValues: (String, String, String)?
    @State private var xattrs: [String] = []
    @State private var showXattrEditor = false
    @State private var xattrEditingName = ""
    @State private var xattrEditingValue = ""
    @State private var message: String?
    @State private var isCalculating = false
    @State private var folderStats: (count: Int, bytes: Int64, truncated: Bool)?
    @State private var directoryAnalysis: HoshinoDirectoryAnalysis?
    @State private var isAnalyzingDirectory = false
    @State private var linkDestination: String?

    var body: some View {
        List {
            Section {
                HStack(spacing: 14) {
                    Image(FileTypeIconAssets.assetName(for: file.url, isDirectory: file.isDirectory,
                                                        isSymbolicLink: file.isSymbolicLink,
                                                        isExecutable: file.isExecutableMachO))
                        .resizable().scaledToFit().frame(width: 58, height: 58)
                    VStack(alignment: .leading, spacing: 4) {
                        Text(file.name).font(.headline).lineLimit(2)
                        Text(file.url.path).font(.system(size: 10, design: .monospaced)).foregroundStyle(.secondary).textSelection(.enabled)
                    }
                }.padding(.vertical, 4)
            }
            Section("基本信息") {
                infoRow("类型", file.isDirectory ? "文件夹" : (file.isSymbolicLink ? "符号链接" : file.fileExtension.uppercased().isEmpty ? "文件" : file.fileExtension.uppercased()))
                infoRow("大小", ByteCountFormatter.string(fromByteCount: file.size, countStyle: .file))
                infoRow("创建时间", file.created?.formatted() ?? "未知")
                infoRow("修改时间", file.modified?.formatted() ?? "未知")
                if let metadata {
                    infoRow("所有者 UID", "\(metadata.owner)")
                    infoRow("所属组 GID", "\(metadata.group)")
                    infoRow("inode", "\(metadata.inode)")
                    infoRow("设备号", "\(metadata.device)")
                    infoRow("硬链接数", "\(metadata.linkCount)")
                    infoRow("BSD flags", String(format: "0x%08X", metadata.flags))
                }
                if let linkDestination { infoRow("链接目标", linkDestination) }
            }
            if file.isDirectory, let folderStats {
                Section("目录统计") {
                    infoRow("项目数", folderStats.truncated ? ">= \(folderStats.count)（达到扫描上限）" : "\(folderStats.count)")
                    infoRow("总大小", ByteCountFormatter.string(fromByteCount: folderStats.bytes, countStyle: .file))
                }
            }
            if file.isDirectory {
                Section("磁盘用量分析") {
                    if let report = directoryAnalysis {
                        infoRow("普通文件", "\(report.fileCount)")
                        infoRow("子目录", "\(report.directoryCount)")
                        infoRow("符号链接", "\(report.symlinkCount)")
                        infoRow("占用空间", ByteCountFormatter.string(fromByteCount: Int64(clamping: report.totalBytes), countStyle: .file))
                        if report.unreadableCount > 0 || report.isTruncated {
                            Label("统计可能不完整：无法读取 \(report.unreadableCount) 项；达到 500,000 项扫描上限：\(report.isTruncated ? "是" : "否")。", systemImage: "exclamationmark.triangle.fill")
                                .font(.caption).foregroundStyle(.orange)
                        }
                        if !report.extensionUsage.isEmpty {
                            Text("按扩展名统计").font(.caption).foregroundStyle(.secondary)
                            ForEach(report.extensionUsage.prefix(8)) { item in
                                HStack {
                                    Text(item.ext).font(.system(.caption, design: .monospaced))
                                    Spacer()
                                    Text("\(item.count) 个 · \(ByteCountFormatter.string(fromByteCount: Int64(clamping: item.bytes), countStyle: .file))")
                                        .font(.caption).foregroundStyle(.secondary)
                                }
                            }
                        }
                        if !report.largestFiles.isEmpty {
                            Text("最大文件").font(.caption).foregroundStyle(.secondary)
                            ForEach(report.largestFiles) { item in
                                HStack(spacing: 8) {
                                    Image(FileTypeIconAssets.assetName(for: item.url, isDirectory: false,
                                                                        isSymbolicLink: item.isSymbolicLink,
                                                                        isExecutable: item.isExecutableMachO))
                                        .resizable().scaledToFit().frame(width: 24, height: 24)
                                    VStack(alignment: .leading, spacing: 2) {
                                        Text(item.name).font(.caption).lineLimit(1)
                                        Text(item.url.path).font(.system(size: 8, design: .monospaced)).foregroundStyle(.secondary).lineLimit(1)
                                    }
                                    Spacer()
                                    Text(ByteCountFormatter.string(fromByteCount: item.size, countStyle: .file))
                                        .font(.system(size: 9, design: .monospaced)).foregroundStyle(.secondary)
                                }
                            }
                        }
                    }
                    Button {
                        analyzeDirectoryUsage()
                    } label: {
                        if isAnalyzingDirectory { ProgressView("正在分析目录…") }
                        else { Label(directoryAnalysis == nil ? "分析目录占用" : "重新分析", systemImage: "chart.bar.xaxis") }
                    }
                    .disabled(isAnalyzingDirectory)
                    Text("按 lstat 统计，不跟随符号链接；硬链接的实际数据只计入一次。大型目录分析会在后台运行。")
                        .font(.caption2).foregroundStyle(.secondary)
                }
            }
            Section("所有者 / 用户组") {
                TextField("UID（留空保持不变）", text: $ownerUID).keyboardType(.numberPad)
                TextField("GID（留空保持不变）", text: $ownerGID).keyboardType(.numberPad)
                Button("应用 chown") { applyOwnership() }
                Text("支持普通文件、目录和符号链接；默认不跟随符号链接。递归模式会修改所选目录下的子项目，失败时会尝试回滚已修改节点。")
                    .font(.caption).foregroundStyle(.secondary)
            }
            Section("POSIX 权限") {
                if let metadata {
                    infoRow("符号权限", metadata.permissions)
                    HStack {
                        Text("八进制")
                        Spacer()
                        TextField("0755", text: $permissions).multilineTextAlignment(.trailing)
                            .font(.system(.body, design: .monospaced)).frame(width: 90)
                            .keyboardType(.numberPad)
                    }
                    Toggle("递归应用到子项目", isOn: $recursive).disabled(!file.isDirectory)
                    Button("应用 chmod 权限") { applyPermissions() }
                }
            }
            Section("文件保护 / 限制删除") {
                if let metadata {
                    Toggle("只读锁定（UF_IMMUTABLE / uchg）", isOn: Binding(
                        get: { immutable },
                        set: { pendingImmutable = $0; confirmProtection = true }
                    ))
                    .tint(.orange)
                    .disabled(file.isDirectory && recursive && folderStats == nil)
                    if metadata.isSymbolicLink {
                        Label("该项目是符号链接；默认只对链接本身设置标记，不跟随目标。", systemImage: "link")
                            .font(.caption).foregroundStyle(.secondary)
                    }
                    if file.isDirectory {
                        Text(folderStats.map { "对目录递归设置/解除锁定会作用于 \($0.count + 1) 个项目，并需确认。" } ?? "正在统计目录项目数…")
                            .font(.caption).foregroundStyle(.secondary)
                    }
                    Text(immutable ? "此文件当前带有 uchg 标记，系统将阻止写入、重命名、移动和删除。" : "未设置 uchg。文件仍可能受到普通 POSIX 权限限制。")
                        .font(.caption).foregroundStyle(.secondary)
                }
            }
            Section("校验值") {
                if let hashValues {
                    hashRow("MD5", hashValues.0)
                    hashRow("SHA-1", hashValues.1)
                    hashRow("SHA-256", hashValues.2)
                } else {
                    Button { calculateHashes() } label: {
                        if isCalculating { ProgressView() } else { Label("计算 MD5 / SHA-1 / SHA-256", systemImage: "number") }
                    }.disabled(isCalculating || file.isDirectory)
                }
            }
            Section {
                if xattrs.isEmpty {
                    Text("没有可见扩展属性，或当前进程无法读取。")
                        .font(.caption).foregroundStyle(.secondary)
                } else {
                    ForEach(xattrs, id: \.self) { name in
                        VStack(alignment: .leading, spacing: 4) {
                            Text(name).font(.system(.caption, design: .monospaced))
                            if let data = FileSystemService.shared.extendedAttribute(name, url: file.url) {
                                Text(data.base64EncodedString()).font(.system(size: 9, design: .monospaced)).foregroundStyle(.secondary).lineLimit(3)
                            }
                        }
                        .contextMenu {
                            Button { beginXattrEdit(name) } label: { Label("编辑", systemImage: "pencil") }
                            Button { UIPasteboard.general.string = name } label: { Label("复制属性名", systemImage: "doc.on.doc") }
                            Button(role: .destructive) { deleteXattr(name) } label: { Label("删除属性", systemImage: "trash") }
                        }
                    }
                }
                Button { xattrEditingName = ""; xattrEditingValue = ""; showXattrEditor = true } label: { Label("添加扩展属性", systemImage: "plus") }
            } header: { Text("扩展属性（xattr）") } footer: {
                Text("值使用 Base64 编辑，避免二进制扩展属性被文本编码破坏。符号链接默认不跟随目标。")
            }
        }
        .navigationTitle("文件信息").navigationBarTitleDisplayMode(.inline)
        .onAppear(perform: load)
        .sheet(isPresented: $showXattrEditor) {
            NavigationView {
                Form {
                    Section("属性名称") { TextField("com.example.attribute", text: $xattrEditingName).textInputAutocapitalization(.never).autocorrectionDisabled() }
                    Section("Base64 值") { TextEditor(text: $xattrEditingValue).font(.system(.footnote, design: .monospaced)).frame(minHeight: 150) }
                }
                .navigationTitle(xattrs.contains(xattrEditingName) ? "编辑扩展属性" : "添加扩展属性")
                .toolbar {
                    ToolbarItem(placement: .cancellationAction) { Button("取消") { showXattrEditor = false } }
                    ToolbarItem(placement: .confirmationAction) { Button("保存") { saveXattr() }.disabled(xattrEditingName.isEmpty || Data(base64Encoded: xattrEditingValue) == nil) }
                }
            }
        }
        .confirmationDialog(pendingImmutable ? "设置只读锁定？" : "解除只读锁定？", isPresented: $confirmProtection, titleVisibility: .visible) {
            Button(pendingImmutable ? "锁定" : "解除锁定", role: pendingImmutable ? .destructive : .none) { applyImmutable() }
            Button("取消", role: .cancel) { pendingImmutable = immutable }
        } message: {
            Text(protectionConfirmationText)
        }
        .alert("文件属性", isPresented: Binding(get: { message != nil }, set: { if !$0 { message = nil } })) {
            Button("好", role: .cancel) { message = nil; load() }
        } message: { Text(message ?? "") }
    }

    private func beginXattrEdit(_ name: String) {
        xattrEditingName = name
        xattrEditingValue = FileSystemService.shared.extendedAttribute(name, url: file.url)?.base64EncodedString() ?? ""
        showXattrEditor = true
    }

    private func saveXattr() {
        guard let data = Data(base64Encoded: xattrEditingValue) else { message = "Base64 格式无效。"; return }
        do {
            try FileSystemService.shared.setExtendedAttribute(xattrEditingName, data: data, url: file.url)
            showXattrEditor = false; load()
        } catch { message = error.localizedDescription }
    }

    private func deleteXattr(_ name: String) {
        do { try FileSystemService.shared.removeExtendedAttribute(name, url: file.url); load() }
        catch { message = error.localizedDescription }
    }

    private var protectionConfirmationText: String {
        if file.isDirectory && recursive {
            let count = (folderStats?.count ?? 0) + 1
            let suffix = folderStats?.truncated == true ? "（至少此数量，统计达到上限）" : ""
            return "将对当前目录及全部子项目递归执行。预计项目数：\(count)\(suffix)。\n符号链接默认作用于链接本身；大型目录可能需要较长时间。"
        }
        return "将对 \(file.name) 执行 BSD flags 修改，只修改 UF_IMMUTABLE 位并保留其他 flags。"
    }

    private func infoRow(_ label: String, _ value: String) -> some View {
        HStack(alignment: .top) { Text(label); Spacer(minLength: 12); Text(value).font(.system(size: 12, design: .monospaced)).foregroundStyle(.secondary).multilineTextAlignment(.trailing).textSelection(.enabled) }
    }

    private func hashRow(_ label: String, _ value: String) -> some View {
        VStack(alignment: .leading, spacing: 4) {
            Text(label).font(.caption).foregroundStyle(.secondary)
            Text(value).font(.system(size: 10, design: .monospaced)).textSelection(.enabled)
        }.contextMenu { Button { UIPasteboard.general.string = value } label: { Label("复制", systemImage: "doc.on.doc") } }
    }

    private func load() {
        metadata = try? FileSystemService.shared.metadata(for: file.url)
        if let metadata {
            permissions = metadata.octal
            ownerUID = String(metadata.owner)
            ownerGID = String(metadata.group)
            immutable = metadata.immutable
        }
        xattrs = FileSystemService.shared.extendedAttributeNames(file.url)
        if file.isDirectory {
            let url = file.url
            DispatchQueue.global(qos: .utility).async {
                let stats = FileSystemService.shared.directoryStats(url, maxEntries: 100_000)
                DispatchQueue.main.async { folderStats = stats }
            }
        }
        if file.isSymbolicLink { linkDestination = (try? FileManager.default.destinationOfSymbolicLink(atPath: file.url.path)) ?? "目标不存在或无法读取" }
    }

    private func applyPermissions() {
        do { try FileSystemService.shared.setPermissions(file.url, octal: permissions, recursive: recursive); message = "权限已更新。" }
        catch { message = error.localizedDescription }
    }

    private func applyOwnership() {
        do {
            try FileSystemService.shared.setOwnership(file.url, uid: ownerUID, gid: ownerGID, recursive: recursive)
            message = "所有者 / 用户组已更新。"
        } catch { message = error.localizedDescription }
    }

    private func applyImmutable() {
        do {
            try FileSystemService.shared.setImmutable(file.url, enabled: pendingImmutable, recursive: recursive, linkItself: true)
            immutable = pendingImmutable
            message = immutable ? "已设置 UF_IMMUTABLE。" : "已清除 UF_IMMUTABLE，其他 BSD flags 已保留。"
        } catch { message = error.localizedDescription; immutable = (try? FileSystemService.shared.metadata(for: file.url).immutable) ?? immutable }
    }

    private func analyzeDirectoryUsage() {
        guard file.isDirectory, !isAnalyzingDirectory else { return }
        isAnalyzingDirectory = true
        let url = file.url
        DispatchQueue.global(qos: .utility).async {
            let report = FileSystemService.shared.analyzeDirectory(url, largestLimit: 15, includeHidden: true)
            DispatchQueue.main.async {
                directoryAnalysis = report
                folderStats = (report.fileCount + report.directoryCount + report.symlinkCount,
                               Int64(clamping: report.totalBytes), report.isTruncated)
                isAnalyzingDirectory = false
            }
        }
    }

    private func calculateHashes() {
        isCalculating = true
        DispatchQueue.global(qos: .userInitiated).async {
            let result = try? FileSystemService.shared.hashes(for: file.url)
            DispatchQueue.main.async { hashValues = result; isCalculating = false }
        }
    }
}

struct StorageInfoView: View {
    @State private var capacity: Int64 = 0
    @State private var available: Int64 = 0
    @State private var path = FileSystemService.shared.defaultDirectory()
    @State private var showPicker = false
    var body: some View {
        List {
            Section("文件系统") {
                storageRow("检查路径", path.path)
                storageRow("总容量", ByteCountFormatter.string(fromByteCount: capacity, countStyle: .file))
                storageRow("可用空间", ByteCountFormatter.string(fromByteCount: available, countStyle: .file))
                storageRow("已用空间", ByteCountFormatter.string(fromByteCount: max(0, capacity - available), countStyle: .file))
            }
            Button("选择其他目录") { showPicker = true }
        }
        .navigationTitle("存储空间").navigationBarTitleDisplayMode(.inline)
        .onAppear(perform: refresh)
        .fileImporter(isPresented: $showPicker, allowedContentTypes: [.folder], allowsMultipleSelection: false) { result in
            if let url = try? result.get().first { path = url; refresh() }
        }
    }
    private func storageRow(_ title: String, _ value: String) -> some View { HStack { Text(title); Spacer(); Text(value).foregroundStyle(.secondary).font(.caption) } }
    private func refresh() {
        let values = FileSystemService.shared.storageInfo(for: path)
        capacity = values.capacity; available = values.available
    }
}
