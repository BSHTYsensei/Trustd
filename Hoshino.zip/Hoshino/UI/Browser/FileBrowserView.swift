import SwiftUI
import UniformTypeIdentifiers
import UIKit
import Darwin

struct FileBrowserView: View {
    let initialURL: URL?
    @State private var currentDirectory: URL
    @State private var items: [HoshinoFile] = []
    @State private var searchText = ""
    @AppStorage("Hoshino.ShowHidden") private var showHidden = false
    @AppStorage("Hoshino.DefaultGrid") private var gridMode = false
    @State private var sortMode: HoshinoSort = .name
    @State private var selecting = false
    @State private var selectedIDs: Set<String> = []
    @State private var showFolderPicker = false
    @State private var showCreateSheet = false
    @State private var renameTarget: HoshinoFile?
    @State private var detailsTarget: HoshinoFile?
    @State private var editorTarget: URLItem?
    @State private var linkTarget: HoshinoFile?
    @State private var hardLinkTarget: HoshinoFile?
    @State private var trashTarget: HoshinoFile?
    @State private var confirmBatchTrash = false
    @State private var showBatchRename = false
    @State private var infoMessage: String?
    @State private var isLoading = false
    @State private var isArchiving = false
    @State private var isOperating = false
    @State private var operationLabel = ""
    @State private var operationCompleted = 0
    @State private var operationTotal = 0
    @State private var cancelOperationRequested = false
    @State private var archiveRequest: ArchiveCreationRequest?
    @State private var loadRequestID = UUID()
    @State private var showTrashManager = false
    @AppStorage("Hoshino.ConflictPolicy") private var conflictPolicyRaw = HoshinoConflictPolicy.keepBoth.rawValue
    @State private var scopeURL: URL?
    @State private var didAttemptRestore = false
    @StateObject private var clipboard = ClipboardStore.shared
    @StateObject private var favorites = FavoritesStore.shared

    init(initialURL: URL? = nil) {
        self.initialURL = initialURL
        _currentDirectory = State(initialValue: initialURL ?? FileSystemService.shared.defaultDirectory())
    }

    private var visibleItems: [HoshinoFile] {
        items.filter { searchText.isEmpty || $0.name.localizedCaseInsensitiveContains(searchText) }
    }

    var body: some View {
        NavigationView {
            VStack(spacing: 0) {
                pathBar
                Divider().opacity(0.7)
                if isLoading && items.isEmpty {
                    ProgressView("正在读取文件夹…").frame(maxWidth: .infinity, maxHeight: .infinity)
                } else if visibleItems.isEmpty {
                    ContentUnavailableViewCompat(title: searchText.isEmpty ? "此文件夹为空" : "没有匹配的文件", message: searchText.isEmpty ? "点按右上角菜单新建项目，或导入一个文件夹。" : "尝试其他名称或关键词。", systemImage: searchText.isEmpty ? "folder" : "magnifyingglass")
                } else if gridMode {
                    ScrollView {
                        LazyVGrid(columns: [GridItem(.adaptive(minimum: 104), spacing: 14)], spacing: 16) {
                            ForEach(visibleItems) { item in gridCell(item) }
                        }.padding(14)
                    }
                } else {
                    List {
                        ForEach(visibleItems) { item in listRow(item) }
                    }
                    .listStyle(.plain)
                }
                if selecting { selectionBar }
            }
            .background(Color(uiColor: .secondarySystemBackground).opacity(0.24))
            .navigationTitle("Hoshino")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar { toolbarContent }
            .searchable(text: $searchText, prompt: "搜索当前文件夹")
            .onAppear { restoreLastDirectoryBookmark(); reload() }
            .onChange(of: currentDirectory) { _ in reload() }
            .onChange(of: showHidden) { _ in reload() }
            .fileImporter(isPresented: $showFolderPicker, allowedContentTypes: [.folder], allowsMultipleSelection: false) { result in
                do {
                    guard let picked = try result.get().first else { return }
                    let started = picked.startAccessingSecurityScopedResource()
                    do {
                        try DirectoryBookmarkStore.save(picked)
                        scopeURL?.stopAccessingSecurityScopedResource()
                        scopeURL = started ? picked : nil
                        currentDirectory = picked
                    } catch {
                        if started { picked.stopAccessingSecurityScopedResource() }
                        throw error
                    }
                } catch { infoMessage = error.localizedDescription }
            }
            .sheet(isPresented: $showCreateSheet) {
                NavigationView { CreateEntrySheet { name, isFolder in
                    do {
                        if isFolder { _ = try FileSystemService.shared.createFolder(named: name, in: currentDirectory) }
                        else { _ = try FileSystemService.shared.createFile(named: name, in: currentDirectory) }
                        reload()
                    } catch { infoMessage = error.localizedDescription }
                } }
            }
            .sheet(item: $renameTarget) { item in
                NavigationView { RenameEntrySheet(currentName: item.name) { name in
                    do { _ = try FileSystemService.shared.rename(item.url, to: name); reload() }
                    catch { infoMessage = error.localizedDescription }
                } }
            }
            .sheet(isPresented: $showBatchRename) {
                NavigationView {
                    BatchRenameSheet(count: selectedFiles.count) { baseName, startAt, preserveExtension in
                        do {
                            _ = try FileSystemService.shared.batchRename(selectedFiles.map(\.url), baseName: baseName, startAt: startAt, preserveExtensions: preserveExtension)
                            selectedIDs.removeAll(); selecting = false; reload()
                        } catch { infoMessage = error.localizedDescription }
                    }
                }
            }
            .sheet(item: $detailsTarget) { item in NavigationView { FileDetailsView(file: item) } }
            .sheet(item: $editorTarget) { target in NavigationView { FileEditorRouter(fileURL: target.url) } }
            .sheet(item: $archiveRequest) { request in
                NavigationView {
                    ArchiveCreationSheet(request: request, passwordAllowed: ArchivePreferences.load().zipEncryption) { name, format, password in
                        performArchiveCreation(request.sources, archiveName: name, format: format, password: password)
                    }
                }
            }
            .sheet(item: $linkTarget) { item in
                NavigationView { SymbolicLinkSheet(target: item.url, destinationFolder: currentDirectory) { name in
                    do {
                        try FileSystemService.shared.validateName(name)
                        try FileSystemService.shared.createSymbolicLink(target: item.url, linkURL: currentDirectory.appendingPathComponent(name))
                        reload()
                    } catch { infoMessage = error.localizedDescription }
                } }
            }
            .sheet(item: $hardLinkTarget) { item in
                NavigationView { HardLinkSheet(source: item.url, destinationFolder: currentDirectory) { name in
                    do {
                        try FileSystemService.shared.validateName(name)
                        try FileSystemService.shared.createHardLink(from: item.url, at: currentDirectory.appendingPathComponent(name))
                        reload()
                    } catch { infoMessage = error.localizedDescription }
                } }
            }
            .sheet(isPresented: $showTrashManager) {
                NavigationView {
                    TrashManagerView()
                        .toolbar { ToolbarItem(placement: .navigationBarTrailing) { Button("完成") { showTrashManager = false } } }
                }
            }
            .confirmationDialog(RecycleBinService.shared.isEnabled ? "移入废纸篓？" : "永久删除？", isPresented: Binding(get: { trashTarget != nil }, set: { if !$0 { trashTarget = nil } }), titleVisibility: .visible) {
                Button(RecycleBinService.shared.isEnabled ? "移入废纸篓" : "永久删除", role: .destructive) {
                    if let item = trashTarget { do { if RecycleBinService.shared.isEnabled { _ = try FileSystemService.shared.trash(item.url) } else { try FileSystemService.shared.permanentlyDelete(item.url) }; reload() } catch { infoMessage = error.localizedDescription } }
                    trashTarget = nil
                }
                Button("取消", role: .cancel) { trashTarget = nil }
            } message: { Text(RecycleBinService.shared.isEnabled ? (trashTarget?.name ?? "") : "该操作不可恢复：\(trashTarget?.name ?? "")") }
            .confirmationDialog("确认处理所选项目？", isPresented: $confirmBatchTrash, titleVisibility: .visible) {
                Button(RecycleBinService.shared.isEnabled ? "移入废纸篓" : "永久删除", role: .destructive) {
                    performBatchDelete(selectedFiles)
                    selectedIDs.removeAll(); selecting = false
                }
                Button("取消", role: .cancel) {}
            } message: { Text("项目数量：\(selectedFiles.count)" + (RecycleBinService.shared.isEnabled ? "" : "。永久删除后无法恢复。")) }
            .alert("Hoshino", isPresented: Binding(get: { infoMessage != nil }, set: { if !$0 { infoMessage = nil } })) {
                Button("好", role: .cancel) { infoMessage = nil }
            } message: { Text(infoMessage ?? "") }
        }
        .navigationViewStyle(.stack)
        .onDisappear { scopeURL?.stopAccessingSecurityScopedResource() }
    }

    private var pathBar: some View {
        HStack(spacing: 9) {
            Button { goParent() } label: {
                Image(systemName: "arrow.up")
                    .font(.system(size: 13, weight: .semibold))
                    .frame(width: 31, height: 31)
                    .background(Color(uiColor: .tertiarySystemBackground), in: Circle())
            }
            .disabled(currentDirectory.path == "/")
            VStack(alignment: .leading, spacing: 2) {
                Text(currentDirectory.lastPathComponent.isEmpty ? "/" : currentDirectory.lastPathComponent)
                    .font(.system(size: 14, weight: .semibold)).lineLimit(1)
                Text(currentDirectory.path)
                    .font(.system(size: 10, design: .monospaced)).foregroundStyle(.secondary).lineLimit(1)
            }
            Spacer(minLength: 0)
            if isOperating || isArchiving {
                VStack(alignment: .trailing, spacing: 2) {
                    if isArchiving { ProgressView().scaleEffect(0.72) }
                    else { ProgressView(value: Double(operationCompleted), total: Double(max(1, operationTotal))).frame(width: 72) }
                    Text(isArchiving ? "正在压缩" : "\(operationLabel) \(operationCompleted)/\(operationTotal)")
                        .font(.system(size: 8, weight: .medium)).foregroundStyle(.secondary).lineLimit(1)
                }
            }
            if isOperating {
                Button("停止") { cancelOperationRequested = true }
                    .font(.system(size: 10, weight: .semibold)).foregroundStyle(.red)
                    .accessibilityHint("当前文件完成后停止后续批量处理")
            }
            Text("\(visibleItems.count) 项").font(.system(size: 10, weight: .medium, design: .rounded)).foregroundStyle(.secondary)
        }
        .padding(.horizontal, 14).padding(.vertical, 9)
        .background(.ultraThinMaterial)
    }

    @ToolbarContentBuilder
    private var toolbarContent: some ToolbarContent {
        ToolbarItemGroup(placement: .navigationBarLeading) {
            Button(selecting ? "完成" : "选择") {
                selecting.toggle(); selectedIDs.removeAll()
            }.font(.system(size: 13, weight: .semibold)).disabled(isOperating || isArchiving)
        }
        ToolbarItemGroup(placement: .navigationBarTrailing) {
            Menu {
                Button { showFolderPicker = true } label: { Label("导入/选择文件夹", systemImage: "folder.badge.plus") }
                Button { showCreateSheet = true } label: { Label("新建文件或文件夹", systemImage: "plus") }
                Button { showHidden.toggle() } label: { Label(showHidden ? "隐藏隐藏项目" : "显示隐藏项目", systemImage: "eye") }
                Button { gridMode.toggle() } label: { Label(gridMode ? "列表视图" : "网格视图", systemImage: gridMode ? "list.bullet" : "square.grid.2x2") }
                Menu("排序方式") {
                    ForEach(HoshinoSort.allCases) { mode in
                        Button { sortMode = mode; reload() } label: {
                            if sortMode == mode { Label(mode.rawValue, systemImage: "checkmark") }
                            else { Text(mode.rawValue) }
                        }
                    }
                }
                Button { showTrashManager = true } label: { Label("废纸篓", systemImage: "trash") }
            } label: { Image(systemName: "ellipsis.circle") }
        }
    }

    @ViewBuilder
    private func listRow(_ item: HoshinoFile) -> some View {
        HStack(spacing: 10) {
            if selecting {
                Image(systemName: selectedIDs.contains(item.id) ? "checkmark.circle.fill" : "circle")
                    .foregroundStyle(selectedIDs.contains(item.id) ? .blue : .secondary)
                    .font(.system(size: 19))
            }
            ZStack(alignment: .topTrailing) { icon(for: item).frame(width: 33, height: 35); FileTypeCornerBadge(url: item.url, isDirectory: item.isDirectory).padding(1) }.frame(width: 36, height: 36).clipped()
            VStack(alignment: .leading, spacing: 3) {
                Text(item.name).font(.system(size: 13, weight: .medium)).lineLimit(1)
                HStack(spacing: 6) {
                    Text(typeLabel(item)).lineLimit(1)
                    if let date = item.modified { Text("· \(date.formatted(date: .numeric, time: .shortened))").lineLimit(1) }
                }.font(.system(size: 10)).foregroundStyle(.secondary)
            }
            Spacer(minLength: 3)
            if item.isSymbolicLink { Image(systemName: "arrow.turn.up.right").font(.caption2).foregroundStyle(.secondary) }
            if item.isDirectory { Image(systemName: "chevron.right").font(.system(size: 10, weight: .semibold)).foregroundStyle(.tertiary) }
        }
        .contentShape(Rectangle())
        .padding(.vertical, 2)
        .onTapGesture { handleTap(item) }
        .contextMenu { itemContextMenu(item) }
    }

    @ViewBuilder
    private func gridCell(_ item: HoshinoFile) -> some View {
        Button { handleTap(item) } label: {
            VStack(spacing: 8) {
                ZStack(alignment: .topTrailing) {
                    icon(for: item).font(.system(size: 34)).frame(height: 48)
                    FileTypeCornerBadge(url: item.url, isDirectory: item.isDirectory).padding(1)
                    if selecting && selectedIDs.contains(item.id) { Image(systemName: "checkmark.circle.fill").foregroundStyle(.blue).offset(x: 8, y: -6) }
                }
                Text(item.name).font(.system(size: 11, weight: .medium)).lineLimit(2).multilineTextAlignment(.center).frame(height: 28)
                Text(item.isDirectory ? "文件夹" : ByteCountFormatter.string(fromByteCount: item.size, countStyle: .file))
                    .font(.system(size: 9)).foregroundStyle(.secondary)
            }
            .frame(maxWidth: .infinity).padding(.vertical, 11).padding(.horizontal, 5)
            .background(Color(uiColor: .secondarySystemGroupedBackground), in: RoundedRectangle(cornerRadius: 14, style: .continuous))
        }
        .buttonStyle(.plain)
        .contextMenu { itemContextMenu(item) }
    }

    @ViewBuilder
    private func itemContextMenu(_ item: HoshinoFile) -> some View {
        if item.isExecutableMachO {
        } else if !item.isDirectory {
            Button { editorTarget = URLItem(item.url) } label: { Label("打开/编辑", systemImage: "pencil.and.outline") }
        }
        Button { detailsTarget = item } label: { Label("文件信息", systemImage: "info.circle") }
        Button {
            do { try favorites.add(item.url) }
            catch { infoMessage = "无法保存目录授权：\(error.localizedDescription)" }
        } label: { Label("添加到收藏", systemImage: "star") }
        Button { clipboard.set([item.url], cut: false) } label: { Label("复制", systemImage: "doc.on.doc") }
        Button { duplicateItem(item) } label: { Label("在此创建副本", systemImage: "plus.square.on.square") }
        Button { clipboard.set([item.url], cut: true) } label: { Label("剪切", systemImage: "scissors") }
        Button { renameTarget = item } label: { Label("重命名", systemImage: "pencil") }
        Button { linkTarget = item } label: { Label("创建符号链接", systemImage: "link") }
        if !item.isDirectory && !item.isSymbolicLink {
            Button { hardLinkTarget = item } label: { Label("创建硬链接", systemImage: "link.badge.plus") }
        }
        Button { createArchive([item]) } label: { Label("创建归档…", systemImage: "archivebox") }
        let kind = HoshinoFileKind.classify(item.url)
        if kind == .archive || kind == .package {
            Button { editorTarget = URLItem(item.url) } label: { Label("浏览归档内容", systemImage: "archivebox.fill") }
        }
        Button(role: .destructive) { trashTarget = item } label: { Label("移入废纸篓", systemImage: "trash") }
        Button { UIPasteboard.general.string = item.url.path } label: { Label("复制路径", systemImage: "doc.on.clipboard") }
    }

    private var selectionBar: some View {
        HStack(spacing: 0) {
            selectionAction("复制", icon: "doc.on.doc") { clipboard.set(selectedFiles.map(\.url), cut: false); selecting = false }
            selectionAction("剪切", icon: "scissors") { clipboard.set(selectedFiles.map(\.url), cut: true); selecting = false }
            selectionAction("收藏", icon: "star") {
                do { for file in selectedFiles { try favorites.add(file.url) } }
                catch { infoMessage = "部分项目可能已收藏，但无法保存授权：\(error.localizedDescription)" }
                selecting = false
            }
            selectionAction(RecycleBinService.shared.isEnabled ? "废纸篓" : "删除", icon: "trash", tint: .red) { confirmBatchTrash = true }
            selectionAction("批量改名", icon: "textformat") { showBatchRename = true }
            selectionAction("全选", icon: "checkmark.circle") { selectedIDs = Set(visibleItems.map(\.id)) }
            selectionAction("压缩", icon: "archivebox") { createArchive(selectedFiles); selecting = false }
            if !clipboard.urls.isEmpty {
                selectionAction("粘贴", icon: "doc.on.clipboard", tint: .blue) { pasteClipboard() }
            }
        }
        .padding(.vertical, 7).background(.bar)
    }

    private func selectionAction(_ title: String, icon: String, tint: Color = .primary, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            VStack(spacing: 3) { Image(systemName: icon).font(.system(size: 15)); Text(title).font(.system(size: 9)) }
                .foregroundStyle(tint).frame(maxWidth: .infinity)
        }
    }

    private var selectedFiles: [HoshinoFile] { items.filter { selectedIDs.contains($0.id) } }

    private func icon(for item: HoshinoFile) -> some View {
        let asset = FileTypeIconAssets.assetName(
            for: item.url,
            isDirectory: item.isDirectory,
            isSymbolicLink: item.isSymbolicLink,
            isExecutable: item.isExecutableMachO
        )
        return Image(asset).resizable().scaledToFit()
    }

    private func duplicateItem(_ item: HoshinoFile) {
        guard !isArchiving, !isOperating else { return }
        let directory = item.url.deletingLastPathComponent()
        DispatchQueue.global(qos: .userInitiated).async {
            let result: Result<URL?, Error> = Result {
                try FileSystemService.shared.copy(item.url, to: directory, policy: .keepBoth)
            }
            DispatchQueue.main.async {
                switch result {
                case .success(let destination):
                    reload()
                    if let destination { infoMessage = "副本已创建：\(destination.lastPathComponent)" }
                case .failure(let error): infoMessage = error.localizedDescription
                }
            }
        }
    }

    private func typeLabel(_ item: HoshinoFile) -> String {
        if item.isDirectory { return "文件夹" }
        if item.isSymbolicLink { return "符号链接" }
        if item.isExecutableMachO { return "可执行 Mach-O 文件" }
        return item.fileExtension.isEmpty ? ByteCountFormatter.string(fromByteCount: item.size, countStyle: .file) : "\(item.fileExtension.uppercased()) · \(ByteCountFormatter.string(fromByteCount: item.size, countStyle: .file))"
    }

    private func handleTap(_ item: HoshinoFile) {
        if selecting {
            if selectedIDs.contains(item.id) { selectedIDs.remove(item.id) } else { selectedIDs.insert(item.id) }
        } else if item.isDirectory {
            currentDirectory = item.url
        } else {
            editorTarget = URLItem(item.url)
        }
    }

    private func reload() {
        let requestID = UUID()
        loadRequestID = requestID
        let directory = currentDirectory
        let includeHidden = showHidden
        let order = sortMode
        isLoading = true
        DispatchQueue.global(qos: .userInitiated).async {
            let result: Result<[HoshinoFile], Error>
            do { result = .success(try FileSystemService.shared.list(directory, showHidden: includeHidden, sort: order)) }
            catch { result = .failure(error) }
            DispatchQueue.main.async {
                guard loadRequestID == requestID else { return }
                isLoading = false
                switch result {
                case .success(let newItems):
                    items = newItems
                    selectedIDs = selectedIDs.intersection(Set(newItems.map(\.id)))
                case .failure(let error):
                    items = []
                    selectedIDs.removeAll()
                    infoMessage = error.localizedDescription
                }
            }
        }
    }

    private func goParent() {
        let parent = currentDirectory.deletingLastPathComponent()
        if parent.path != currentDirectory.path { currentDirectory = parent }
    }

    private func pasteClipboard() {
        guard !isOperating, !isArchiving else { return }
        let sources = clipboard.urls
        guard !sources.isEmpty else { return }
        let isCut = clipboard.isCut
        let destination = currentDirectory
        let policy = HoshinoConflictPolicy(rawValue: conflictPolicyRaw) ?? .keepBoth
        isOperating = true
        cancelOperationRequested = false
        operationLabel = isCut ? "正在移动" : "正在复制"
        operationCompleted = 0
        operationTotal = sources.count
        DispatchQueue.global(qos: .userInitiated).async {
            var failures: [String] = []
            var completed: [URL] = []
            var processed = 0
            var cancelled = false
            for source in sources {
                if DispatchQueue.main.sync(execute: { cancelOperationRequested }) {
                    cancelled = true
                    break
                }
                do {
                    let result = isCut
                        ? try FileSystemService.shared.move(source, to: destination, policy: policy)
                        : try FileSystemService.shared.copy(source, to: destination, policy: policy)
                    if let result {
                        completed.append(source)
                    } else {
                        cancelled = true // The user selected the global conflict policy "Cancel".
                        break
                    }
                } catch {
                    failures.append("\(source.path)：\(error.localizedDescription)")
                }
                processed += 1
                let currentProgress = processed
                DispatchQueue.main.async { operationCompleted = currentProgress }
            }
            DispatchQueue.main.async {
                isOperating = false
                operationLabel = ""
                operationCompleted = 0
                operationTotal = 0
                if isCut && !completed.isEmpty { clipboard.remove(completed) }
                if !completed.isEmpty || isCut { reload() }
                if !failures.isEmpty {
                    let details = failures.prefix(8).joined(separator: "\n")
                    let suffix = failures.count > 8 ? "\n另有 \(failures.count - 8) 项失败。" : ""
                    infoMessage = "已完成 \(completed.count) 项，失败 \(failures.count) 项。\(cancelled ? "已按要求停止后续项目。" : "")\n\(details)\(suffix)"
                } else if cancelled {
                    infoMessage = "已完成 \(completed.count) 项；已停止后续项目。"
                } else if completed.isEmpty {
                    infoMessage = "没有项目需要复制或移动。"
                }
            }
        }
    }

    private func performBatchDelete(_ files: [HoshinoFile]) {
        guard !files.isEmpty, !isOperating, !isArchiving else { return }
        let useTrash = RecycleBinService.shared.isEnabled
        isOperating = true
        cancelOperationRequested = false
        operationLabel = useTrash ? "正在移入废纸篓" : "正在删除"
        operationCompleted = 0
        operationTotal = files.count
        DispatchQueue.global(qos: .userInitiated).async {
            var failures: [String] = []
            var completed = 0
            var processed = 0
            var cancelled = false
            for item in files {
                if DispatchQueue.main.sync(execute: { cancelOperationRequested }) {
                    cancelled = true
                    break
                }
                do {
                    if useTrash { _ = try FileSystemService.shared.trash(item.url) }
                    else { try FileSystemService.shared.permanentlyDelete(item.url) }
                    completed += 1
                } catch {
                    failures.append("\(item.url.path)：\(error.localizedDescription)")
                }
                processed += 1
                let currentProgress = processed
                DispatchQueue.main.async { operationCompleted = currentProgress }
            }
            DispatchQueue.main.async {
                isOperating = false
                operationLabel = ""
                operationCompleted = 0
                operationTotal = 0
                reload()
                if !failures.isEmpty {
                    let details = failures.prefix(8).joined(separator: "\n")
                    let suffix = failures.count > 8 ? "\n另有 \(failures.count - 8) 项失败。" : ""
                    infoMessage = "已处理 \(processed) 项，成功 \(completed) 项，失败 \(failures.count) 项。\(cancelled ? "已停止后续项目。" : "")\n\(details)\(suffix)"
                } else if cancelled {
                    infoMessage = "已删除/移入废纸篓 \(completed) 项；已停止后续项目。"
                }
            }
        }
    }

    private func restoreLastDirectoryBookmark() {
        guard !didAttemptRestore else { return }
        didAttemptRestore = true
        guard initialURL == nil, let data = DirectoryBookmarkStore.data() else { return }
        var stale = false
        let restored: URL
        do {
            restored = try URL(resolvingBookmarkData: data, options: [], relativeTo: nil, bookmarkDataIsStale: &stale)
        } catch {
            infoMessage = "上次打开的目录授权已失效，请重新选择文件夹：\(error.localizedDescription)"
            return
        }
        let started = restored.startAccessingSecurityScopedResource()
        var isDirectory: ObjCBool = false
        guard FileManager.default.fileExists(atPath: restored.path, isDirectory: &isDirectory), isDirectory.boolValue else {
            if started { restored.stopAccessingSecurityScopedResource() }
            infoMessage = "上次打开的路径已不存在或不再是文件夹，请重新选择文件夹。"
            return
        }
        scopeURL?.stopAccessingSecurityScopedResource()
        scopeURL = started ? restored : nil
        if stale {
            do { try DirectoryBookmarkStore.save(restored) }
            catch { infoMessage = "目录授权已恢复，但无法更新书签：\(error.localizedDescription)" }
        }
        currentDirectory = restored
    }

    private func createArchive(_ files: [HoshinoFile]) {
        guard !files.isEmpty, !isArchiving, !isOperating else { return }
        let stem = files.count == 1 ? files[0].name : "Hoshino_Archive"
        let saved = ArchivePreferences.load()
        let initial = ArchiveOutputFormat.allCases.first(where: { $0.fileExtension == saved.createFormat }) ?? .zip
        archiveRequest = ArchiveCreationRequest(sources: files.map(\.url), suggestedName: stem, initialFormat: initial)
    }

    private func performArchiveCreation(_ sources: [URL], archiveName rawName: String,
                                        format: ArchiveOutputFormat, password: String?) {
        let name = rawName.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !name.isEmpty, !name.contains("/"), !name.contains("\\"), name != ".", name != ".." else {
            infoMessage = "归档文件名无效。"
            return
        }
        let suffix = "." + format.fileExtension
        let stem = name.lowercased().hasSuffix(suffix.lowercased()) ? String(name.dropLast(suffix.count)) : name
        guard !stem.isEmpty else { infoMessage = "归档文件名不能为空。"; return }
        let destination = currentDirectory.appendingPathComponent(stem + suffix)
        guard !pathExistsNoFollow(destination) else {
            infoMessage = "目标文件已存在：\(destination.lastPathComponent)"
            return
        }
        archiveRequest = nil
        var preferences = ArchivePreferences.load()
        preferences.createFormat = format.fileExtension
        preferences.save()
        isArchiving = true
        operationLabel = "正在压缩"
        operationCompleted = 0
        operationTotal = 1
        DispatchQueue.global(qos: .userInitiated).async {
            let result: Result<Void, Error> = Result {
                try ArchiveService.shared.createArchive(
                    from: sources,
                    to: destination,
                    format: format,
                    password: password,
                    preservePermissions: ArchivePreferences.load().preservePermissions
                )
            }
            DispatchQueue.main.async {
                isArchiving = false
                operationLabel = ""
                operationCompleted = 0
                operationTotal = 0
                switch result {
                case .success:
                    reload()
                    infoMessage = password == nil ? "归档创建完成：\(destination.lastPathComponent)" : "加密 ZIP 创建完成：\(destination.lastPathComponent)"
                case .failure(let error): infoMessage = error.localizedDescription
                }
            }
        }
    }

    private func pathExistsNoFollow(_ url: URL) -> Bool {
        var st = stat()
        return url.withUnsafeFileSystemRepresentation { path in Darwin.lstat(path, &st) == 0 }
    }

}

private enum DirectoryBookmarkStore {
    private static let key = "Hoshino.LastDirectoryBookmark.v1"
    static func data() -> Data? { UserDefaults.standard.data(forKey: key) }
    static func save(_ url: URL) throws {
        var isDirectory: ObjCBool = false
        guard FileManager.default.fileExists(atPath: url.path, isDirectory: &isDirectory), isDirectory.boolValue else {
            throw NSError(domain: "Hoshino.Bookmark", code: 1,
                          userInfo: [NSLocalizedDescriptionKey: "只能保存现存文件夹的安全书签。"])
        }
        let bookmark = try url.bookmarkData(options: .minimalBookmark, includingResourceValuesForKeys: nil, relativeTo: nil)
        UserDefaults.standard.set(bookmark, forKey: key)
    }
}


private struct ArchiveCreationRequest: Identifiable {
    let id = UUID()
    let sources: [URL]
    let suggestedName: String
    let initialFormat: ArchiveOutputFormat
}

private struct ArchiveCreationSheet: View {
    @Environment(\.dismiss) private var dismiss
    let request: ArchiveCreationRequest
    let passwordAllowed: Bool
    let onCreate: (String, ArchiveOutputFormat, String?) -> Void
    @State private var name: String
    @State private var format: ArchiveOutputFormat
    @State private var password = ""
    @State private var confirmPassword = ""
    @State private var includePassword = false

    init(request: ArchiveCreationRequest, passwordAllowed: Bool,
         onCreate: @escaping (String, ArchiveOutputFormat, String?) -> Void) {
        self.request = request
        self.passwordAllowed = passwordAllowed
        self.onCreate = onCreate
        _name = State(initialValue: request.suggestedName)
        _format = State(initialValue: request.initialFormat)
    }

    private var passwordsMatch: Bool { !includePassword || (!password.isEmpty && password == confirmPassword) }
    private var allowsPassword: Bool { passwordAllowed && format == .zip }

    var body: some View {
        Form {
            Section("归档信息") {
                TextField("归档文件名", text: $name).textInputAutocapitalization(.never).autocorrectionDisabled()
                Picker("格式", selection: $format) {
                    ForEach(ArchiveOutputFormat.allCases) { option in
                        Text(option.title).tag(option)
                    }
                }
                LabeledContent("项目数量", value: "\(request.sources.count)")
                Text(format.isSingleFileStream ? "该格式是单文件压缩流，只能选择一个普通文件。" : "保留空目录和符号链接；特殊文件节点会被安全拒绝。")
                    .font(.caption).foregroundStyle(.secondary)
            }
            Section("加密") {
                if allowsPassword {
                    Toggle("设置 ZIP 打开密码", isOn: $includePassword)
                    if includePassword {
                        SecureField("密码", text: $password)
                        SecureField("确认密码", text: $confirmPassword)
                        if !passwordsMatch { Text("密码不能为空且两次输入必须一致。") .font(.caption).foregroundStyle(.red) }
                    }
                } else {
                    Text("当前格式不支持密码加密；只有 ZIP 可使用密码模式。")
                        .font(.caption).foregroundStyle(.secondary)
                }
            }
        }
        .navigationTitle("创建归档")
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .cancellationAction) { Button("取消") { dismiss() } }
            ToolbarItem(placement: .confirmationAction) {
                Button("开始创建") { onCreate(name, format, includePassword ? password : nil); dismiss() }
                    .disabled(name.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty || !passwordsMatch || (includePassword && !allowsPassword))
            }
        }
        .onChange(of: format) { selected in
            if selected != .zip { includePassword = false; password = ""; confirmPassword = "" }
        }
        .onChange(of: includePassword) { enabled in
            if !enabled { password = ""; confirmPassword = "" }
        }
    }
}

struct URLItem: Identifiable {
    let url: URL
    var id: String { url.path }
    init(_ url: URL) { self.url = url }
}

private struct BatchRenameSheet: View {
    @Environment(\.dismiss) private var dismiss
    let count: Int
    let onRename: (String, Int, Bool) -> Void
    @State private var baseName = "Item-"
    @State private var startAt = "1"
    @State private var preserveExtension = true
    var body: some View {
        Form {
            Section("命名规则") {
                TextField("名称前缀", text: $baseName).textInputAutocapitalization(.never).autocorrectionDisabled()
                TextField("起始序号", text: $startAt).keyboardType(.numberPad)
                Toggle("保留原扩展名", isOn: $preserveExtension)
            }
            Section("预览") {
                Text("\(baseName)\(Int(startAt) ?? 1) … \(baseName)\((Int(startAt) ?? 1) + max(0, count - 1))")
                    .font(.system(.footnote, design: .monospaced))
                Text("将按当前列表顺序重命名 \(count) 个项目。")
                    .font(.caption).foregroundStyle(.secondary)
            }
        }
        .navigationTitle("批量重命名").navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .cancellationAction) { Button("取消") { dismiss() } }
            ToolbarItem(placement: .confirmationAction) {
                Button("开始") { onRename(baseName, Int(startAt) ?? 1, preserveExtension); dismiss() }
                    .disabled(baseName.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty || Int(startAt) == nil || (Int(startAt) ?? -1) < 0 || count == 0)
            }
        }
    }
}

private struct CreateEntrySheet: View {
    @Environment(\.dismiss) private var dismiss
    @State private var name = ""
    @State private var isFolder = true
    let onCreate: (String, Bool) -> Void
    var body: some View {
        Form {
            Section("项目类型") { Picker("类型", selection: $isFolder) { Text("文件夹").tag(true); Text("空文件").tag(false) }.pickerStyle(.segmented) }
            Section("名称") { TextField(isFolder ? "新建文件夹" : "新建文件.txt", text: $name).textInputAutocapitalization(.never).autocorrectionDisabled() }
        }
        .navigationTitle("新建项目").navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .cancellationAction) { Button("取消") { dismiss() } }
            ToolbarItem(placement: .confirmationAction) { Button("创建") { onCreate(name, isFolder); dismiss() }.disabled(name.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty) }
        }
    }
}

private struct RenameEntrySheet: View {
    @Environment(\.dismiss) private var dismiss
    @State private var name: String
    let onRename: (String) -> Void
    init(currentName: String, onRename: @escaping (String) -> Void) { _name = State(initialValue: currentName); self.onRename = onRename }
    var body: some View {
        Form { Section("新名称") { TextField("名称", text: $name).textInputAutocapitalization(.never).autocorrectionDisabled() } }
            .navigationTitle("重命名").navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("取消") { dismiss() } }
                ToolbarItem(placement: .confirmationAction) { Button("保存") { onRename(name); dismiss() }.disabled(name.isEmpty) }
            }
    }
}

private struct HardLinkSheet: View {
    @Environment(\.dismiss) private var dismiss
    let source: URL
    let destinationFolder: URL
    @State private var name = ""
    let onCreate: (String) -> Void

    var body: some View {
        Form {
            Section("硬链接源文件") {
                Text(source.path).font(.system(.caption, design: .monospaced)).textSelection(.enabled)
            }
            Section("新链接名称") {
                TextField("例如 MyFile.link", text: $name).textInputAutocapitalization(.never).autocorrectionDisabled()
            }
            Section("创建位置") { Text(destinationFolder.path).font(.system(.caption, design: .monospaced)) }
            Section {
                Text("硬链接与源文件共享同一 inode，只支持普通文件；必须位于同一文件系统，修改任一链接的内容会影响另一处。")
                    .font(.caption).foregroundStyle(.secondary)
            }
        }
        .navigationTitle("创建硬链接").navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .cancellationAction) { Button("取消") { dismiss() } }
            ToolbarItem(placement: .confirmationAction) {
                Button("创建") { onCreate(name); dismiss() }
                    .disabled(name.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
            }
        }
        .onAppear { name = source.lastPathComponent + ".link" }
    }
}

private struct SymbolicLinkSheet: View {
    @Environment(\.dismiss) private var dismiss
    let target: URL
    let destinationFolder: URL
    @State private var name = ""
    let onCreate: (String) -> Void
    var body: some View {
        Form {
            Section("链接目标") { Text(target.path).font(.system(.caption, design: .monospaced)).textSelection(.enabled) }
            Section("链接名称") { TextField("例如 MyLink", text: $name).textInputAutocapitalization(.never).autocorrectionDisabled() }
            Section("创建位置") { Text(destinationFolder.path).font(.system(.caption, design: .monospaced)) }
        }
        .navigationTitle("创建符号链接").navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .cancellationAction) { Button("取消") { dismiss() } }
            ToolbarItem(placement: .confirmationAction) { Button("创建") { onCreate(name); dismiss() }.disabled(name.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty) }
        }
        .onAppear { name = target.lastPathComponent + "_link" }
    }
}
