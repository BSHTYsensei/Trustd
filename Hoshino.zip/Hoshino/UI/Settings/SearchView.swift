import SwiftUI
import UIKit

struct SearchView: View {
    @State private var query = ""
    @State private var rootURL = FileSystemService.shared.defaultDirectory()
    @State private var results: [HoshinoFile] = []
    @State private var showHidden = false
    @State private var showRootPicker = false
    @State private var editorTarget: URLItem?
    @State private var folderTarget: URLItem?
    @State private var rootScopeURL: URL?
    @State private var searchRequestID = UUID()
    @State private var infoText: String?
    @State private var showDuplicateScanner = false

    var body: some View {
        NavigationView {
            VStack(spacing: 0) {
                HStack(spacing: 8) {
                    Image("FileIcon_folder").resizable().scaledToFit().frame(width: 28, height: 28)
                    VStack(alignment: .leading, spacing: 2) {
                        Text("搜索范围").font(.caption).foregroundStyle(.secondary)
                        Text(rootURL.path).font(.system(size: 10, design: .monospaced)).lineLimit(1)
                    }
                    Spacer()
                    Button("更改") { showRootPicker = true }.font(.caption)
                }.padding(12).background(.bar)
                if query.isEmpty {
                    ContentUnavailableViewCompat(title: "搜索本地文件", message: "支持名称、path:路径片段、ext:plist、type:image、size>10MB、date>2026-01-01、re:正则、content:文本。递归搜索子目录，不跟随符号链接。", systemImage: "magnifyingglass")
                } else if results.isEmpty {
                    ContentUnavailableViewCompat(title: "没有结果", message: "尝试更短的名称，或更改搜索范围。", systemImage: "doc.questionmark")
                } else {
                    List(results) { item in
                        Button { open(item) } label: {
                            HStack(spacing: 10) {
                                Image(FileTypeIconAssets.assetName(for: item.url, isDirectory: item.isDirectory,
                                                                    isSymbolicLink: item.isSymbolicLink,
                                                                    isExecutable: item.isExecutableMachO))
                                    .resizable().scaledToFit().frame(width: 36, height: 36)
                                VStack(alignment: .leading, spacing: 2) {
                                    Text(item.name).font(.system(size: 13, weight: .medium)).foregroundStyle(.primary)
                                    Text(item.url.deletingLastPathComponent().path).font(.system(size: 9, design: .monospaced)).foregroundStyle(.secondary).lineLimit(1)
                                }
                                Spacer()
                            }
                        }
                    }.listStyle(.plain)
                }
            }
            .navigationTitle("搜索")
            .searchable(text: $query, prompt: "名称、ext:plist、type:image、size>10MB、re:正则、content:文本")
            .toolbar {
                ToolbarItemGroup(placement: .navigationBarTrailing) {
                    Toggle("隐藏", isOn: $showHidden).labelsHidden()
                    Button { showDuplicateScanner = true } label: { Image(systemName: "doc.on.doc.fill") }
                        .accessibilityLabel("查找重复文件")
                }
            }
            .onChange(of: query) { value in performSearch(value) }
            .onChange(of: showHidden) { _ in performSearch(query) }
            .fileImporter(isPresented: $showRootPicker, allowedContentTypes: [.folder], allowsMultipleSelection: false) { result in
                do {
                    if let url = try result.get().first {
                        _ = url.startAccessingSecurityScopedResource()
                        rootScopeURL?.stopAccessingSecurityScopedResource()
                        rootScopeURL = url
                        rootURL = url
                        performSearch(query)
                    }
                } catch { infoText = error.localizedDescription }
            }
            .sheet(isPresented: $showDuplicateScanner) { DuplicateFinderView(rootURL: rootURL) }
            .sheet(item: $editorTarget) { target in NavigationView { FileEditorRouter(fileURL: target.url) } }
            .sheet(item: $folderTarget) { target in
                NavigationView {
                    FileBrowserView(initialURL: target.url)
                        .toolbar { ToolbarItem(placement: .navigationBarTrailing) { Button("完成") { folderTarget = nil } } }
                }
            }
            .onDisappear {
                searchRequestID = UUID()
                rootScopeURL?.stopAccessingSecurityScopedResource()
                rootScopeURL = nil
            }
            .alert("搜索", isPresented: Binding(get: { infoText != nil }, set: { if !$0 { infoText = nil } })) {
                Button("好", role: .cancel) { infoText = nil }
            } message: { Text(infoText ?? "") }
        }
        .navigationViewStyle(.stack)
    }

    private func performSearch(_ value: String) {
        guard !value.isEmpty else { results = []; searchRequestID = UUID(); return }
        let requestID = UUID()
        searchRequestID = requestID
        let root = rootURL
        let includeHidden = showHidden
        DispatchQueue.global(qos: .userInitiated).async {
            let found = FileSystemService.shared.search(root, query: value, showHidden: includeHidden)
            DispatchQueue.main.async {
                guard searchRequestID == requestID else { return }
                results = found
            }
        }
    }

    private func open(_ item: HoshinoFile) {
        if item.isDirectory { folderTarget = URLItem(item.url) }
        else { editorTarget = URLItem(item.url) }
    }
}


struct DuplicateFinderView: View {
    let initialRootURL: URL?
    @Environment(\.dismiss) private var dismiss
    @State private var rootURL: URL
    @State private var groups: [HoshinoDuplicateGroup] = []
    @State private var showHidden = false
    @State private var showRootPicker = false
    @State private var rootScopeURL: URL?
    @State private var isScanning = false
    @State private var removeTarget: HoshinoFile?
    @State private var message: String?

    init(rootURL: URL? = nil) {
        self.initialRootURL = rootURL
        _rootURL = State(initialValue: rootURL ?? FileSystemService.shared.defaultDirectory())
    }

    var body: some View {
        NavigationView {
            List {
                Section {
                    VStack(alignment: .leading, spacing: 6) {
                        Text("扫描范围").font(.caption).foregroundStyle(.secondary)
                        Text(rootURL.path).font(.system(size: 11, design: .monospaced)).textSelection(.enabled)
                        Button("更改扫描目录") { showRootPicker = true }
                    }
                    Toggle("包含隐藏文件", isOn: $showHidden)
                    Text("最多检查 30,000 个目录项；先比较文件大小和首尾数据块，再对候选项计算完整 SHA-256。大型目录建议缩小扫描范围。")
                        .font(.caption2).foregroundStyle(.secondary)
                }
                if isScanning {
                    Section { HStack { ProgressView(); Text("正在比较文件大小并计算 SHA-256…").font(.caption) } }
                } else if groups.isEmpty {
                    ContentUnavailableViewCompat(title: "尚未发现重复文件", message: "点击右上角扫描。系统先按文件大小筛选，再使用 SHA-256 比较内容；硬链接不会被误报为重复副本。", systemImage: "doc.on.doc")
                } else {
                    Section {
                        HStack {
                            Label("重复组", systemImage: "square.stack.3d.up")
                            Spacer()
                            Text("\(groups.count) 组").foregroundStyle(.secondary)
                        }
                        HStack {
                            Label("可回收空间（估算）", systemImage: "externaldrive")
                            Spacer()
                            Text(ByteCountFormatter.string(fromByteCount: Int64(groups.reduce(UInt64(0)) { $0 &+ $1.reclaimableBytes }), countStyle: .file))
                                .foregroundStyle(.secondary)
                        }
                    }
                    ForEach(groups) { group in
                        Section {
                            ForEach(group.files) { file in
                                HStack(spacing: 10) {
                                    Image(FileTypeIconAssets.assetName(for: file.url, isDirectory: false,
                                                                        isSymbolicLink: file.isSymbolicLink,
                                                                        isExecutable: file.isExecutableMachO))
                                        .resizable().scaledToFit().frame(width: 34, height: 34)
                                    VStack(alignment: .leading, spacing: 3) {
                                        Text(file.name).font(.system(size: 13, weight: .medium)).lineLimit(1)
                                        Text(file.url.path).font(.system(size: 9, design: .monospaced)).foregroundStyle(.secondary).lineLimit(2)
                                    }
                                    Spacer(minLength: 4)
                                    Button(role: .destructive) { removeTarget = file } label: {
                                        Image(systemName: "trash").font(.system(size: 14))
                                    }
                                    .buttonStyle(.borderless)
                                    .accessibilityLabel("将此重复文件移入废纸篓")
                                }
                            }
                        } header: {
                            HStack {
                                Text("\(group.files.count) 个相同文件")
                                Spacer()
                                Text(ByteCountFormatter.string(fromByteCount: Int64(group.size), countStyle: .file))
                            }
                        } footer: {
                            Text("SHA-256：\(group.sha256)").font(.system(size: 9, design: .monospaced))
                        }
                    }
                }
            }
            .navigationTitle("重复文件")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) { Button("完成") { dismiss() } }
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button { scan() } label: { isScanning ? AnyView(ProgressView()) : AnyView(Text("扫描")) }
                        .disabled(isScanning)
                }
            }
            .fileImporter(isPresented: $showRootPicker, allowedContentTypes: [.folder], allowsMultipleSelection: false) { result in
                do {
                    guard let url = try result.get().first else { return }
                    let started = url.startAccessingSecurityScopedResource()
                    rootScopeURL?.stopAccessingSecurityScopedResource()
                    rootScopeURL = started ? url : nil
                    rootURL = url
                    groups = []
                } catch { message = error.localizedDescription }
            }
            .confirmationDialog("将重复文件移入废纸篓？", isPresented: Binding(get: { removeTarget != nil }, set: { if !$0 { removeTarget = nil } }), titleVisibility: .visible) {
                Button("移入废纸篓", role: .destructive) { removeDuplicate() }
                Button("取消", role: .cancel) { removeTarget = nil }
            } message: {
                Text(removeTarget?.url.path ?? "")
            }
            .alert("重复文件", isPresented: Binding(get: { message != nil }, set: { if !$0 { message = nil } })) {
                Button("好", role: .cancel) { message = nil }
            } message: { Text(message ?? "") }
        }
        .navigationViewStyle(.stack)
        .onDisappear { rootScopeURL?.stopAccessingSecurityScopedResource() }
    }

    private func scan() {
        guard !isScanning else { return }
        isScanning = true
        let root = rootURL
        let hidden = showHidden
        DispatchQueue.global(qos: .userInitiated).async {
            let found = FileSystemService.shared.findDuplicates(in: root, showHidden: hidden)
            DispatchQueue.main.async {
                groups = found
                isScanning = false
                if found.isEmpty { message = "没有发现内容完全相同的重复文件。" }
            }
        }
    }

    private func removeDuplicate() {
        guard let target = removeTarget else { return }
        guard RecycleBinService.shared.isEnabled else {
            message = "重复项清理只允许先移入废纸篓。请先在设置中启用废纸篓，避免误删不可恢复的数据。"
            removeTarget = nil
            return
        }
        do {
            _ = try FileSystemService.shared.trash(target.url)
            groups = groups.compactMap { group in
                let remaining = group.files.filter { $0.id != target.id }
                guard remaining.count > 1 else { return nil }
                return HoshinoDuplicateGroup(sha256: group.sha256, size: group.size, files: remaining)
            }
            message = "已将 \(target.name) 移入废纸篓。"
        } catch { message = error.localizedDescription }
        removeTarget = nil
    }
}
