import SwiftUI
import UniformTypeIdentifiers

struct ArchiveSettingsView: View {
    @State private var preferences = ArchivePreferences.load()

    var body: some View {
        Form {
            Section("ZIP 设置") {
                Toggle("允许设置 ZIP 打开密码", isOn: $preferences.zipEncryption)
                    .onChange(of: preferences.zipEncryption) { _ in preferences.save() }
                Text("加密仅在创建归档时按需启用，不会自动生成或保存密码。归档格式由静态链接的 libarchive 处理；ZIP 密码模式由 ZipArchive 处理。")
                    .font(.footnote).foregroundStyle(.secondary)
            }
            Section("归档格式能力") {
                ForEach(ArchivePreferences.capabilities) { capability in
                    HStack(alignment: .top, spacing: 10) {
                        Image(systemName: capability.supported ? "checkmark.circle.fill" : "minus.circle")
                            .foregroundStyle(capability.supported ? .green : .secondary)
                        VStack(alignment: .leading, spacing: 3) {
                            HStack {
                                Text(capability.name).font(.body.weight(.medium))
                                Spacer()
                                Text(capability.supported ? "已集成" : "未集成")
                                    .font(.caption2).foregroundStyle(.secondary)
                            }
                            Text(capability.detail).font(.caption).foregroundStyle(.secondary)
                        }
                    }
                    .padding(.vertical, 3)
                }
            }
            Section {
                Text("创建格式为 ZIP、7z、TAR、压缩 TAR、GZ、BZ2、XZ、CPIO 和 ISO；RAR/CAB 为只读。解码能力还受 libarchive 构建选项和具体压缩方法影响。")
                    .font(.footnote).foregroundStyle(.secondary)
            }
        }
        .navigationTitle("压缩能力")
    }
}

struct RecycleBinSettingsView:View { @ObservedObject private var bin=RecycleBinService.shared; var body:some View { Form { Toggle("启用回收站",isOn:$bin.isEnabled); Text(bin.isEnabled ? "删除操作优先移动到 Hoshino 回收站，可恢复。" : "关闭后删除操作将提示永久删除，并要求二次确认。已有回收站内容不会自动清除。").font(.footnote).foregroundStyle(.secondary); NavigationLink("管理回收站",destination:TrashManagerView()) } .navigationTitle("回收站") } }
struct MountBrowserView:View { @State private var mounts:[MountRecord]=[]; var body:some View { List(mounts,id:\.id){m in VStack(alignment:.leading,spacing:4){Text(m.mountPoint).font(.headline);Text("\(m.device) · \(m.fileSystem) · \(m.isReadOnly ? "只读" : "可写")").font(.caption).foregroundStyle(.secondary);Text("容量 \(ByteCountFormatter.string(fromByteCount:Int64(m.blocks*m.blockSize),countStyle:.file)) · 可用 \(ByteCountFormatter.string(fromByteCount:Int64(m.freeBlocks*m.blockSize),countStyle:.file))").font(.caption2)}}.navigationTitle("挂载点").toolbar{Button("刷新"){mounts=MountCatalog.all()}}.onAppear{mounts=MountCatalog.all()} } }

struct ScriptManagerView: View {
    @ObservedObject private var library = ScriptLibrary.shared
    @State private var importer = false
    @State private var output = ""
    @State private var showOutput = false
    @State private var isRunning = false
    @State private var importError: String?
    var body: some View {
        List {
            Section {
                Button { importer = true } label: { Label("导入脚本", systemImage: "square.and.arrow.down") }
                Text("支持导入 JavaScript、Shell、Python、Lua、Ruby、Perl、AWK、PHP、R、Tcl。运行能力按当前设备实际可用的运行时显示，不会把仅能导入的格式标成可运行。")
                    .font(.footnote).foregroundStyle(.secondary)
            }
            Section("脚本库 · 勾选后批量执行") {
                if library.scripts.isEmpty { ContentUnavailableViewCompat(title: "尚无脚本", message: "导入 .sh、.py 或其他脚本文件开始使用。", systemImage: "curlybraces") }
                ForEach(library.scripts) { script in
                    HStack(spacing: 10) {
                        Image(systemName: script.runtimeAvailable ? "play.circle.fill" : "doc.text")
                            .foregroundStyle(script.runtimeAvailable ? .green : .secondary)
                        VStack(alignment: .leading, spacing: 3) {
                            Text(script.name).lineLimit(1)
                            Text(".\(script.kind.uppercased()) · \(script.runtimeAvailable ? "运行器可用" : "已导入，缺少运行器")")
                                .font(.caption).foregroundStyle(script.runtimeAvailable ? .secondary : .orange)
                        }
                        Spacer()
                        Toggle("选择", isOn: Binding(get: { library.scripts.first(where: { $0.id == script.id })?.enabled ?? false }, set: { _ in library.toggle(script) })).labelsHidden()
                    }
                    .swipeActions { Button(role: .destructive) { try? library.delete(script) } label: { Label("删除", systemImage: "trash") } }
                }
            }
            Section("批量执行") {
                Button { Task { await executeSelected() } } label: {
                    HStack { if isRunning { ProgressView() }; Label("执行所有已勾选脚本", systemImage: "play.fill") }
                }.disabled(isRunning || library.scripts.filter(\.enabled).isEmpty)
                if #available(iOS 16.0, *) {
                    Label("快捷指令支持", systemImage: "command")
                    Text("在系统「快捷指令」中添加“运行 Hoshino 已选脚本”动作。动作会按脚本列表顺序执行全部已勾选且运行器可用的脚本，并返回输出摘要。")
                        .font(.footnote).foregroundStyle(.secondary)
                } else {
                    Text("系统快捷指令动作需要 iOS 16 或更新版本；应用内批量执行仍可使用。")
                        .font(.footnote).foregroundStyle(.secondary)
                }
            }
            if let importError { Section { Text(importError).foregroundStyle(.red) } }
        }
        .navigationTitle("脚本管理器")
        .fileImporter(isPresented: $importer, allowedContentTypes: [.item], allowsMultipleSelection: true) { result in
            do { for url in try result.get() { try library.importScript(url) }; importError = nil }
            catch { importError = error.localizedDescription }
        }
        .sheet(isPresented: $showOutput) {
            NavigationView {
                ScrollView { Text(output).font(.system(.footnote, design: .monospaced)).textSelection(.enabled).frame(maxWidth: .infinity, alignment: .leading).padding() }
                    .navigationTitle("脚本执行结果")
                    .toolbar { ToolbarItem(placement: .navigationBarTrailing) { Button("退出") { showOutput = false } } }
            }
        }
    }
    @MainActor private func executeSelected() async {
        isRunning = true; defer { isRunning = false }
        let results = await library.runSelected()
        output = results.map { "===== \($0.0) =====\n\($0.1)" }.joined(separator: "\n\n")
        showOutput = true
    }
}

struct HoshinoSpringButtonStyle:ButtonStyle { func makeBody(configuration:Configuration)->some View { configuration.label.scaleEffect(configuration.isPressed ? 0.94:1).animation(.spring(response:0.28,dampingFraction:0.56,blendDuration:0.08),value:configuration.isPressed) } }
