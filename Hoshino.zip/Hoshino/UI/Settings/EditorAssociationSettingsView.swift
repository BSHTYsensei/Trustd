import SwiftUI

struct EditorAssociationSettingsView: View {
    @ObservedObject private var store = EditorAssociationStore.shared
    @State private var newExtension = ""
    @State private var newKind: EditorKind = .text
    @State private var showAdd = false

    private var extensions: [String] { store.associations.keys.sorted() }

    var body: some View {
        List {
            Section {
                Text("按文件扩展名指定默认编辑器。Plist 默认使用树形编辑器；可随时将任意扩展名改为文本、十六进制或 Quick Look。无扩展名/未配置文件默认 Quick Look。")
                    .font(.caption).foregroundStyle(.secondary)
            }
            Section("文件类型关联") {
                ForEach(extensions, id: \.self) { ext in
                    HStack(spacing: 12) {
                        Text(".\(ext)").font(.system(.body, design: .monospaced)).frame(width: 100, alignment: .leading)
                        Spacer(minLength: 2)
                        Picker("编辑器", selection: Binding(
                            get: { store.associations[ext] ?? .quickLook },
                            set: { store.set($0, for: ext) }
                        )) {
                            ForEach(EditorKind.allCases) { kind in Text(kind.rawValue).tag(kind) }
                        }
                        .labelsHidden().pickerStyle(.menu)
                    }
                    .swipeActions {
                        Button(role: .destructive) { store.remove(ext) } label: { Label("删除", systemImage: "trash") }
                    }
                }
            }
            Section {
                Button { showAdd = true } label: { Label("添加文件类型关联", systemImage: "plus.circle.fill") }
                Button("恢复默认关联") { store.reset() }.foregroundStyle(.orange)
            }
        }
        .navigationTitle("编辑器关联").navigationBarTitleDisplayMode(.inline)
        .sheet(isPresented: $showAdd) {
            NavigationView {
                Form {
                    Section("扩展名") { TextField("例如 plist、yaml、dat", text: $newExtension).textInputAutocapitalization(.never).autocorrectionDisabled() }
                    Section("编辑器") {
                        Picker("编辑器", selection: $newKind) {
                            ForEach(EditorKind.allCases) { kind in Label(kind.rawValue, systemImage: kind.symbol).tag(kind) }
                        }
                    }
                }
                .navigationTitle("添加关联").navigationBarTitleDisplayMode(.inline)
                .toolbar {
                    ToolbarItem(placement: .cancellationAction) { Button("取消") { showAdd = false } }
                    ToolbarItem(placement: .confirmationAction) {
                        Button("添加") { store.set(newKind, for: newExtension); newExtension = ""; showAdd = false }
                            .disabled(newExtension.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
                    }
                }
            }
        }
    }
}

struct HoshinoSettingsView: View {
    @AppStorage("Hoshino.ShowHidden") private var showHidden = false
    @AppStorage("Hoshino.UseDarkAppearance") private var useDarkAppearance = false
    @AppStorage("Hoshino.ThemePalette") private var themePalette = "ocean"
    @AppStorage("Hoshino.DefaultGrid") private var defaultGrid = false
    @AppStorage("Hoshino.ConflictPolicy") private var conflictPolicyRaw = HoshinoConflictPolicy.keepBoth.rawValue
    @AppStorage("Hoshino.UseRootHelperForFileOperations") private var useRootHelper = true
    @State private var rootHelperStatus = RootHelperService.statusDescription

    var body: some View {
        NavigationView {
            List {
                Section {
                    HStack(spacing: 12) {
                        Image("HoshinoMark")
                            .resizable().aspectRatio(contentMode: .fit).frame(width: 48, height: 48).clipShape(RoundedRectangle(cornerRadius: 11))
                        VStack(alignment: .leading, spacing: 3) {
                            Text("Hoshino").font(.headline)
                            Text("本地文件管理器 · 编辑器套件").font(.caption).foregroundStyle(.secondary)
                        }
                    }.padding(.vertical, 5)
                }
                Section("文件管理") {
                    Toggle("默认显示隐藏项目", isOn: $showHidden)
                    Toggle("默认使用网格视图", isOn: $defaultGrid)
                    Picker("同名项目处理", selection: $conflictPolicyRaw) {
                        ForEach(HoshinoConflictPolicy.allCases) { policy in Text(policy.rawValue).tag(policy.rawValue) }
                    }
                    Toggle("启用常驻 RootHelper", isOn: $useRootHelper)
                        .onChange(of: useRootHelper) { enabled in
                            rootHelperStatus = enabled ? "正在启动 RootHelper…" : "正在关闭 RootHelper…"
                            RootHelperService.configure(enabled: enabled) { status in
                                DispatchQueue.main.async { rootHelperStatus = status }
                            }
                        }
                    Text("Hoshino 启动时尝试启动一个应用私有的 RootHelper 子进程；所有文件操作在普通权限不足时复用该进程执行类型化 RPC。关闭 Hoshino 后，父进程的私有通信通道断开，Helper 随之退出。不会注册 launchd 服务或后台常驻任务。是否获得 root 取决于 TrollStore 的 persona 接口和设备环境。")
                        .font(.caption).foregroundStyle(.secondary)
                    HStack {
                        Text(rootHelperStatus).font(.caption).foregroundStyle(.secondary)
                        Spacer()
                        Button("检测") {
                            DispatchQueue.global(qos: .utility).async {
                                RootHelperService.startIfNeeded()
                                let status = RootHelperService.statusDescription
                                DispatchQueue.main.async { rootHelperStatus = status }
                            }
                        }
                        .font(.caption.weight(.semibold))
                    }
                    .onAppear { rootHelperStatus = RootHelperService.statusDescription }
                    NavigationLink { TrashManagerView() } label: { Label("废纸篓", systemImage: "trash") }
                    NavigationLink { RecycleBinSettingsView() } label: { Label("回收站设置", systemImage: "trash.slash") }
                    NavigationLink { ArchiveSettingsView() } label: { Label("压缩能力", systemImage: "archivebox") }
                    NavigationLink { ScriptManagerView() } label: { Label("脚本管理器", systemImage: "curlybraces") }
                    NavigationLink { MountBrowserView() } label: { Label("挂载点信息", systemImage: "externaldrive.badge.timemachine") }
                    NavigationLink { StorageInfoView() } label: { Label("存储空间", systemImage: "externaldrive") }
                }
                Section("查看器与编辑器") {
                    NavigationLink { EditorAssociationSettingsView() } label: {
                        Label("编辑器关联", systemImage: "slider.horizontal.3")
                    }
                    NavigationLink { EditorCatalogView() } label: { Label("编辑器列表", systemImage: "square.grid.2x2") }
                }
                Section("外观") {
                    Toggle("深色外观", isOn: $useDarkAppearance)
                    Picker("主题配色", selection: $themePalette) {
                        Text("海盐蓝").tag("ocean")
                        Text("薄荷绿").tag("mint")
                        Text("薰衣草紫").tag("lavender")
                        Text("珊瑚橙").tag("coral")
                    }
                    Text("文件夹图标固定使用浅蓝色；主题配色仅调整交互强调色，不会改变文件类型的识别颜色。")
                        .font(.caption).foregroundStyle(.secondary)
                }
                Section("关于") {
                    HStack { Text("版本"); Spacer(); Text("1.1.0").foregroundStyle(.secondary) }
                    HStack { Text("应用"); Spacer(); Text("Hoshino").foregroundStyle(.secondary) }
                    Text("只处理当前运行环境有权访问的本地文件。系统沙盒、文件系统标记与权限仍由 iOS 和实际设备环境决定。")
                        .font(.caption).foregroundStyle(.secondary)
                }
            }
            .listStyle(.insetGrouped)
            .navigationTitle("设置")
        }
        .navigationViewStyle(.stack)
    }
}

private struct EditorCatalogView: View {
    var body: some View {
        List {
            Section("内置编辑器") {
                catalogRow("Plist 树形编辑器", detail: "XML / Binary Plist；Dictionary、Array、String、Number、Boolean、Date、Data", icon: "list.tree")
                catalogRow("文本/代码编辑器", detail: "UTF-8/UTF-16/Latin-1；查找、JSON 格式化、基础语法着色", icon: "doc.text")
                catalogRow("十六进制编辑器", detail: "字节编辑、地址跳转、十六进制字节搜索", icon: "number")
                catalogRow("CSV/TSV 表格", detail: "表格单元格编辑、增删行列、引号字段解析", icon: "tablecells")
                catalogRow("ZIP 压缩包管理器", detail: "列出归档内容、显示压缩比例、解压到当前目录", icon: "archivebox")
                catalogRow("图片查看器", detail: "常见图片格式与手势缩放", icon: "photo")
                catalogRow("音视频播放器", detail: "系统 AVFoundation 解码支持的媒体格式", icon: "play.rectangle")
                catalogRow("Quick Look", detail: "PDF、Office、系统可预览的文档类型", icon: "eye")
            }
            Section("配置") {
                Text("在“设置 → 编辑器关联”中为每个扩展名选择默认编辑器。不同扩展名可以映射到相同编辑器。未知类型默认使用 Quick Look。")
                    .font(.caption).foregroundStyle(.secondary)
            }
        }
        .navigationTitle("编辑器列表").navigationBarTitleDisplayMode(.inline)
    }

    private func catalogRow(_ title: String, detail: String, icon: String) -> some View {
        HStack(spacing: 10) {
            Image(systemName: icon).font(.system(size: 20)).foregroundStyle(.blue).frame(width: 28)
            VStack(alignment: .leading, spacing: 2) {
                Text(title).font(.system(size: 13, weight: .semibold))
                Text(detail).font(.caption).foregroundStyle(.secondary)
            }
        }.padding(.vertical, 3)
    }
}

struct TrashManagerView: View {
    @State private var items: [HoshinoFile] = []
    @State private var confirmDelete: HoshinoFile?
    @State private var message: String?

    var body: some View {
        List {
            if items.isEmpty {
                ContentUnavailableViewCompat(title: "废纸篓为空", message: "从文件夹移入废纸篓的项目会显示在这里。", systemImage: "trash")
            }
            ForEach(items) { item in
                HStack(spacing: 10) {
                    Image(FileTypeIconAssets.assetName(for: item.url, isDirectory: item.isDirectory,
                                                        isSymbolicLink: item.isSymbolicLink,
                                                        isExecutable: item.isExecutableMachO))
                        .resizable().scaledToFit().frame(width: 27, height: 27)
                    VStack(alignment: .leading, spacing: 2) {
                        Text(cleanName(item.name)).font(.system(size: 13, weight: .medium)).lineLimit(1)
                        Text(ByteCountFormatter.string(fromByteCount: item.size, countStyle: .file)).font(.caption2).foregroundStyle(.secondary)
                    }
                    Spacer()
                    Button { restore(item) } label: { Image(systemName: "arrow.uturn.backward") }.buttonStyle(.borderless)
                    Button(role: .destructive) { confirmDelete = item } label: { Image(systemName: "trash.slash") }.buttonStyle(.borderless)
                }
            }
        }
        .navigationTitle("废纸篓").navigationBarTitleDisplayMode(.inline)
        .onAppear(perform: reload)
        .confirmationDialog("永久删除项目？", isPresented: Binding(get: { confirmDelete != nil }, set: { if !$0 { confirmDelete = nil } })) {
            Button("永久删除", role: .destructive) {
                if let item = confirmDelete { do { try FileSystemService.shared.permanentlyDelete(item.url); reload() } catch { message = error.localizedDescription } }
                confirmDelete = nil
            }
            Button("取消", role: .cancel) { confirmDelete = nil }
        }
        .alert("废纸篓", isPresented: Binding(get: { message != nil }, set: { if !$0 { message = nil } })) {
            Button("好", role: .cancel) { message = nil }
        } message: { Text(message ?? "") }
    }

    private func cleanName(_ value: String) -> String {
        guard let range = value.range(of: "_"), UUID(uuidString: String(value[..<range.lowerBound])) != nil else { return value }
        return String(value[range.upperBound...])
    }
    private func reload() { items = FileSystemService.shared.trashItems() }
    private func restore(_ item: HoshinoFile) {
        do { _ = try FileSystemService.shared.restoreFromTrash(item.url); reload() }
        catch { message = error.localizedDescription }
    }
}
