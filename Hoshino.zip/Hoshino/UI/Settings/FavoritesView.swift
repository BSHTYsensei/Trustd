import SwiftUI

struct FavoritesView: View {
    @ObservedObject private var store = FavoritesStore.shared
    @State private var showPicker = false
    @State private var showAddGroup = false
    @State private var showManageGroups = false
    @State private var errorText: String?

    var body: some View {
        NavigationView {
            List {
                if store.items.isEmpty {
                    ContentUnavailableViewCompat(title: "暂无收藏", message: "在文件项目菜单中选择“添加到收藏”。", systemImage: "star")
                }
                ForEach(store.groups, id: \.self) { group in
                    let members = store.items.filter { $0.group == group }
                    if !members.isEmpty || group == "未分组" {
                        Section(group) {
                            if members.isEmpty {
                                Text("此分组为空").font(.caption).foregroundStyle(.tertiary)
                            }
                            ForEach(members) { favorite in
                                NavigationLink(destination: FavoriteLocationDestination(favorite: favorite)) {
                                    HStack(spacing: 11) {
                                        Image("FileIcon_folder").resizable().scaledToFit().frame(width: 30, height: 30)
                                            .font(.system(size: 20))
                                            .foregroundStyle(Color(red: 0.42, green: 0.72, blue: 0.98))
                                        VStack(alignment: .leading, spacing: 2) {
                                            Text(favorite.title).font(.system(size: 13, weight: .medium))
                                            Text(favorite.path).font(.system(size: 10, design: .monospaced)).foregroundStyle(.secondary).lineLimit(1)
                                        }
                                    }.padding(.vertical, 3)
                                }
                                .contextMenu {
                                    Menu("移动到分组") {
                                        ForEach(store.groups, id: \.self) { target in
                                            Button {
                                                store.move(favorite, to: target)
                                            } label: {
                                                if target == favorite.group { Label(target, systemImage: "checkmark") }
                                                else { Text(target) }
                                            }.disabled(target == favorite.group)
                                        }
                                    }
                                    Button(role: .destructive) { store.remove(favorite) } label: { Label("移除收藏", systemImage: "trash") }
                                }
                                .swipeActions {
                                    Button(role: .destructive) { store.remove(favorite) } label: { Label("移除", systemImage: "trash") }
                                }
                            }
                        }
                    }
                }
            }
            .navigationTitle("收藏")
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Menu {
                        Button { showAddGroup = true } label: { Label("新建分组", systemImage: "folder.badge.plus") }
                        Button { showManageGroups = true } label: { Label("管理分组", systemImage: "folder.badge.gearshape") }
                    } label: { Image(systemName: "ellipsis.circle") }
                }
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button { showPicker = true } label: { Image(systemName: "plus") }
                }
            }
            .fileImporter(isPresented: $showPicker, allowedContentTypes: [.folder], allowsMultipleSelection: false) { result in
                do {
                    if let url = try result.get().first { try store.add(url) }
                } catch { errorText = error.localizedDescription }
            }
            .sheet(isPresented: $showAddGroup) {
                NavigationView { FavoriteGroupAddSheet { name in
                    do { try store.addGroup(name) } catch { errorText = error.localizedDescription }
                } }
            }
            .sheet(isPresented: $showManageGroups) {
                NavigationView { FavoriteGroupManagementView(store: store) }
            }
            .alert("收藏", isPresented: Binding(get: { errorText != nil }, set: { if !$0 { errorText = nil } })) {
                Button("好", role: .cancel) { errorText = nil }
            } message: { Text(errorText ?? "") }
        }
        .navigationViewStyle(.stack)
    }
}

private struct FavoriteLocationDestination: View {
    let favorite: FavoriteLocation
    @State private var resolvedURL: URL?
    @State private var securityScopedURL: URL?
    @State private var resolutionError: String?

    var body: some View {
        Group {
            if let resolvedURL {
                FileBrowserView(initialURL: resolvedURL)
            } else if let resolutionError {
                ContentUnavailableViewCompat(title: "无法打开收藏", message: resolutionError, systemImage: "exclamationmark.triangle")
            } else {
                ProgressView("正在恢复目录授权…")
            }
        }
        .onAppear {
            do {
                let url = try FavoritesStore.shared.resolveURL(for: favorite)
                resolvedURL = url
                if url.startAccessingSecurityScopedResource() { securityScopedURL = url }
            } catch {
                resolutionError = error.localizedDescription
            }
        }
        .onDisappear { securityScopedURL?.stopAccessingSecurityScopedResource(); securityScopedURL = nil }
    }
}

private struct FavoriteGroupAddSheet: View {
    @Environment(\.dismiss) private var dismiss
    @State private var name = ""
    let onAdd: (String) -> Void
    var body: some View {
        Form { Section("分组名称") { TextField("例如：系统目录、项目文件", text: $name).textInputAutocapitalization(.never).autocorrectionDisabled() } }
            .navigationTitle("新建收藏分组").navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("取消") { dismiss() } }
                ToolbarItem(placement: .confirmationAction) { Button("创建") { onAdd(name); dismiss() }.disabled(name.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty) }
            }
    }
}

private struct FavoriteGroupManagementView: View {
    @Environment(\.dismiss) private var dismiss
    @ObservedObject var store: FavoritesStore
    @State private var renameTarget: String?
    @State private var newName = ""
    @State private var errorText: String?

    var body: some View {
        List {
            ForEach(store.groups, id: \.self) { group in
                HStack {
                    Label(group, systemImage: "folder")
                    Spacer()
                    if group != "未分组" {
                        Button("重命名") { renameTarget = group; newName = group }
                            .font(.caption)
                        Button(role: .destructive) { store.removeGroup(group) } label: { Image(systemName: "trash") }
                            .buttonStyle(.borderless)
                    }
                }
            }
        }
        .navigationTitle("管理分组").navigationBarTitleDisplayMode(.inline)
        .toolbar { ToolbarItem(placement: .confirmationAction) { Button("完成") { dismiss() } } }
        .alert(errorText == nil ? "重命名分组" : "收藏分组", isPresented: Binding(
            get: { renameTarget != nil || errorText != nil },
            set: { if !$0 { renameTarget = nil; errorText = nil } }
        )) {
            if let errorText {
                Button("好", role: .cancel) { self.errorText = nil }
            } else {
                TextField("分组名称", text: $newName)
                Button("取消", role: .cancel) { renameTarget = nil }
                Button("保存") {
                    if let target = renameTarget {
                        do { try store.renameGroup(target, to: newName) }
                        catch { errorText = error.localizedDescription }
                    }
                    renameTarget = nil
                }
            }
        } message: {
            if let errorText { Text(errorText) }
        }
    }
}
