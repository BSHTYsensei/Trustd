# Hoshino 逆向复核与增强能力矩阵

## 复核到的 Filza 静态接口线索

- `FileAttributes`: 文件/目录属性、目录大小计算、MD5/SHA1/SHA256、权限字符串、属性列表。
- `PermissionSetting`: 八进制权限编辑、目录递归应用开关。
- `FileItem`: executable、hidden、tag、permissions、UTType、mimeType、link、icon 等文件项字段。
- `TGFileSystemListViewController`: 排序、属性页、废纸篓、永久擦除、复制/移动/重命名、批量操作。
- `TGRootFileManager`: 扩展属性、BSD/POSIX 属性、符号/硬链接、标签、stat/statfs、目录列表、PTY、RootHelper/XPC。
- `MountPointItem` / `MountPointsBrowserView`: 挂载点、文件系统类型、只读状态、statfs/statvfs。
- `Zipper`: 归档相关类；静态头文件不足以证明每个格式/密码算法在目标版本均可用。
- `ViewersSelectionTableViewController` / `ViewerPrefsTableViewController`: 扩展名到查看器关联。
- `TGPlistViewController`, `TGHexEditorViewController`, `TGFastTextEditViewController`: Plist/Hex/Text 编辑器入口。

## 平台边界

普通 iOS 第三方 App 受沙盒约束。可列出系统暴露的 mount table，但不能任意 mount/remount 系统卷；越狱 helper 能力取决于 jailbreak、签名、权限和文件系统。不要把“查看挂载点”描述成“可挂载系统分区”。

`UF_IMMUTABLE` (`uchg`) 是 BSD immutable flag，不等同于 chmod 0444。能否设置/清除由文件系统、owner、root、SIP/平台限制和当前运行环境决定。普通用户不应宣称能防 root 清除；root 或有权限的 helper 仍可移除该 flag。递归操作需确认项目数量，遇错逐项报告。

## 归档后端选择

- ZIP: SSZipArchive/Minizip 支持 ZipCrypto 与 AES ZIP 加解密、创建和压缩等级；必须锁定安全修复版本。
- 7z/RAR/TAR/GZip/BZip2/XZ: 使用模块化后端（7-Zip SDK / Unrar.swift / libarchive / SWCompression）。RAR 编码涉及许可边界，默认只读提取；启用某格式前要验证对应 filter/codec 确实编入 iOS XCFramework。
- UI 的 enabledFormats 是能力偏好，不等于后端实现。每种格式有 supportsCreate/supportsExtract/supportsEncryption/runtimeAvailable 能力位。

## 大文件策略

- 列表元数据只 stat，不读取文件正文；目录统计后台任务并支持取消。
- Hash 使用 1 MiB streaming chunks。
- Hex 编辑按窗口读取/写入，不把整个文件载入内存。
- 文本编辑器建议 2 MiB 以下可编辑全量文本；更大文件采用分页只读和显式范围编辑。
- 图片缩略图使用 ImageIO thumbnail；视频用 AVPlayer/AVAsset，不预载媒体字节。
- 保存采用临时文件 + 原子替换；覆盖前检查文件保护标记和权限。

## 本轮源代码新增

FileMetadataService、FileTypeBadge、RecycleBinService、MountCatalog、ScriptLibrary、ArchivePreferences、AdvancedSettingsViews。
