@testable import FilaLog
import Foundation
import Testing

// The buffer is shareable in one tap. These are the shapes a credential
// can arrive in — a header-like field, a URL with userinfo,
// a spawned command's argument vector — and each one is a line somebody will
// eventually write without thinking about it.

@Suite("Redaction")
struct RedactionTests {
    private let placeholder = FilaLog.redactedPlaceholder

    @Test
    func `Leaves an ordinary line exactly as it was`() {
        // Also the fast path: none of these carries `@`, `=` or `:`.
        for line in [
            "stat /private/var/db/dslocal refused errno 13 Permission denied",
            "→ list /private/var/mobile/Library/Preferences",
            "job 4 copy 2 source(s) → /private/var/mobile/Documents",
            "guard refused /private/var/mobile",
            "peer accepted pid 4213",
        ] {
            #expect(FilaLog.redacting(line) == line)
        }
    }

    @Test
    func `An Authorization header loses its whole value`() {
        #expect(
            FilaLog.redacting("PROPFIND / Authorization: Basic Ym9iOmh1bnRlcjI=")
                == "PROPFIND / Authorization: \(placeholder)",
        )
        // Case is the client's choice, not ours.
        #expect(FilaLog.redacting("authorization: Bearer eyJhbGciOi").hasSuffix(placeholder))
        #expect(!FilaLog.redacting("Authorization: Basic Ym9iOmh1bnRlcjI=").contains("Ym9i"))
    }

    @Test
    func `A bare auth scheme takes the token after it`() {
        #expect(FilaLog.redacting("sent Basic Ym9iOnB3") == "sent Basic \(placeholder)")
        #expect(FilaLog.redacting("sent Bearer eyJhbGciOi") == "sent Bearer \(placeholder)")
    }

    @Test
    func `A URL keeps its user and loses its password`() {
        #expect(
            FilaLog.redacting("mount https://bob:hunter2@dav.example.com/share")
                == "mount https://bob:\(placeholder)@dav.example.com/share",
        )
        // Without a scheme too — that is how a credential reaches an argv.
        #expect(FilaLog.redacting("bob:hunter2@host") == "bob:\(placeholder)@host")
        // A port is not a password, and neither is a plain address.
        #expect(FilaLog.redacting("listening on 0.0.0.0:8080") == "listening on 0.0.0.0:8080")
        #expect(FilaLog.redacting("peer bob@host") == "peer bob@host")
    }

    @Test
    func `An assignment whose key names a secret loses its value`() {
        #expect(FilaLog.redacting("GET /dav?password=hunter2") == "GET /dav?password=\(placeholder)")
        #expect(FilaLog.redacting("db_password=hunter2") == "db_password=\(placeholder)")
        #expect(FilaLog.redacting("token:hunter2") == "token:\(placeholder)")
        #expect(FilaLog.redacting("X-Auth-Token:abc123") == "X-Auth-Token:\(placeholder)")
        // Keys that name nothing secret are left alone, or the log stops being
        // readable at all.
        #expect(FilaLog.redacting("errno=13") == "errno=13")
        #expect(FilaLog.redacting("mode=0644 uid=501") == "mode=0644 uid=501")
    }

    @Test
    func `A header written with a space after its colon loses the value after it`() {
        #expect(FilaLog.redacting("X-Auth-Token: abc123") == "X-Auth-Token: \(placeholder)")
        #expect(FilaLog.redacting("password: hunter2 then") == "password: \(placeholder) then")
        // A header that is the credential in full, whichever way it is spaced.
        #expect(FilaLog.redacting("authorization:Basic dXNlcjpwdw==") == "authorization:\(placeholder)")
        #expect(!FilaLog.redacting("Cookie: sid=abc").contains("abc"))
        #expect(!FilaLog.redacting("Set-Cookie: sid=abc; HttpOnly").contains("abc"))
        // A colon that ends a word naming nothing secret takes nothing.
        #expect(FilaLog.redacting("errno: 13") == "errno: 13")
    }

    @Test
    func `A credential later in a query loses its value`() {
        #expect(FilaLog.redacting("GET /f?x=1&token=SECRET") == "GET /f?x=1&token=\(placeholder)")
        #expect(!FilaLog.redacting("GET /a?x=1&password=pw&y=2").contains("pw"))
        // A value with an `&` in it does not leave its tail behind.
        #expect(!FilaLog.redacting("GET /a?password=a&b").contains("&b"))
        // Parameters that name nothing secret are left as they were.
        #expect(FilaLog.redacting("GET /f?x=1&y=2") == "GET /f?x=1&y=2")
    }

    @Test
    func `A spawned command's password flag takes the argument after it`() {
        // Execution is no longer forbidden in this project, and an argv is the
        // most reliable place in any program for a password to end up.
        #expect(
            FilaLog.redacting("spawn /usr/bin/tool --password hunter2 /data")
                == "spawn /usr/bin/tool --password \(placeholder) /data",
        )
        #expect(FilaLog.redacting("run tool -p hunter2") == "run tool -p \(placeholder)")
        // Runs of spaces must not let the value slip past as an empty token.
        #expect(FilaLog.redacting("run tool -p   hunter2").contains(placeholder))
        #expect(!FilaLog.redacting("run tool -p   hunter2").contains("hunter2"))
    }

    @Test
    func `Truncation cannot resurrect a secret by cutting the scrubber short`() {
        // The scrubber runs before the ring truncates, so a very long line is
        // scrubbed whole and only then cut.
        let padding = String(repeating: "a", count: FilaLogRing.maximumMessageByteCount)
        let scrubbed = FilaLog.redacting("\(padding) password=hunter2")
        #expect(!scrubbed.contains("hunter2"))
    }
}
