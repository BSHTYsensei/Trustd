import Darwin
@testable import FilaFileOps
@testable import FilaProtocol
import Foundation
import Testing

/// `removeNode`: one node, never a tree, and only the kind the caller
/// verified.
@Suite("Removing one node")
struct RemoveNodeTests {
    let scratch = Scratch()
    let operations = FileOperations(bootstrapRoot: "")

    @Test
    func `A file is unlinked and an empty directory is removed`() throws {
        let file = scratch.file("one.txt")
        try operations.removeNode(at: file, directory: false)
        #expect(!exists(file))

        let directory = scratch.directory("empty")
        try operations.removeNode(at: directory, directory: true)
        #expect(!exists(directory))
    }

    @Test
    func `A directory with entries is refused and keeps every entry`() {
        scratch.directory("full")
        scratch.file("full/keep.txt")
        let failure = #expect(throws: FilaFailure.self) {
            try operations.removeNode(at: scratch.path("full"), directory: true)
        }
        #expect(failure?.systemError == ENOTEMPTY)
        #expect(exists(scratch.path("full/keep.txt")))
    }

    @Test
    func `A name whose kind is not the one verified is left alone`() {
        scratch.directory("folder")
        scratch.file("plain.txt")
        // Verified as a file, found a directory: refused here, before
        // unlink — which root may be allowed to do to a directory.
        let asFile = #expect(throws: FilaFailure.self) {
            try operations.removeNode(at: scratch.path("folder"), directory: false)
        }
        #expect(asFile?.systemError == EISDIR)
        #expect(exists(scratch.path("folder")))
        // A link to a directory is a link: verified as a directory, it is
        // refused, and verified as a file it goes while the target stays.
        #expect(symlink(scratch.path("folder"), scratch.path("folder-link")) == 0)
        let linkAsDirectory = #expect(throws: FilaFailure.self) {
            try operations.removeNode(at: scratch.path("folder-link"), directory: true)
        }
        #expect(linkAsDirectory?.systemError == ENOTDIR)
        #expect(exists(scratch.path("folder-link")))
        // Verified as a directory, found a file: rmdir refuses.
        let asDirectory = #expect(throws: FilaFailure.self) {
            try operations.removeNode(at: scratch.path("plain.txt"), directory: true)
        }
        #expect(asDirectory?.systemError == ENOTDIR)
        #expect(exists(scratch.path("plain.txt")))
    }

    @Test
    func `Removing a link removes the link and keeps its target`() throws {
        let target = scratch.file("target.txt", contents: "kept")
        let link = scratch.path("pointer")
        #expect(symlink(target, link) == 0)
        try operations.removeNode(at: link, directory: false)
        #expect(metadata(of: link) == nil)
        #expect(metadata(of: target)?.st_size == 4)

        scratch.directory("realdir")
        let directoryLink = scratch.path("dirpointer")
        #expect(symlink(scratch.path("realdir"), directoryLink) == 0)
        // A link to a directory is still a link: it goes as a non-directory.
        try operations.removeNode(at: directoryLink, directory: false)
        #expect(metadata(of: directoryLink) == nil)
        #expect(exists(scratch.path("realdir")))
    }

    /// Write and search without read: enough for `unlink`, `rename` and
    /// `chmod` inside it, and so enough for the in-process backend, which runs
    /// as the user rather than as root. Root reads every directory anyway.
    @Test(.enabled(if: getuid() != 0, "root reads every directory"))
    func `A folder that may be searched but not listed still takes changes inside it`() throws {
        scratch.directory("dropbox")
        let file = scratch.file("dropbox/one.txt")
        scratch.file("dropbox/two.txt")
        #expect(chmod(scratch.path("dropbox"), 0o300) == 0)
        defer { chmod(scratch.path("dropbox"), 0o755) }

        try operations.setAttributes(AttributeChange(mode: 0o600), at: scratch.path("dropbox/two.txt"))
        try operations.rename(scratch.path("dropbox/two.txt"), to: scratch.path("dropbox/three.txt"))
        try operations.removeNode(at: file, directory: false)
        #expect(!exists(file))
        #expect(permissions(of: scratch.path("dropbox/three.txt")) == 0o600)
    }

    @Test
    func `The guard refuses a protected node`() {
        let failure = #expect(throws: FilaFailure.self) {
            try operations.removeNode(at: "/", directory: true)
        }
        #expect(failure?.code == .protectedPath)
    }
}
