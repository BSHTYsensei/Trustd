@testable import FilaApplications
import FilaBackendKit
@testable import FilaClient
import FilaProtocol
import Foundation
import Testing

@Suite("Applications backend")
@MainActor
struct ApplicationBackendTests {
    private func local() -> LocalFileBackend {
        LocalFileBackend(access: LocalFileService(), storage: MemoryStorage())
    }

    @Test
    func `The legacy switches keep their keys, and only changed keys are written`() throws {
        let name = "com.hoshino.filemanager.tests.\(UUID().uuidString)"
        let defaults = try #require(UserDefaults(suiteName: name))
        defer { defaults.removePersistentDomain(forName: name) }
        defaults.set("identifier", forKey: "appSort")
        let storage = ApplicationPreferencesDefaults(defaults: defaults)
        var value = try #require(try storage.load())
        #expect(value.sort == .identifier && value.scope == .all)
        value.scope = .user
        try storage.save(value)
        #expect(defaults.string(forKey: "appScope") == "user")
        #expect(defaults.string(forKey: "appSort") == "identifier")
    }

    @Test
    func `The feature is off until the handshake and off in a container`() {
        let files = local()
        let backend = ApplicationBackend(local: files, storage: MemoryStorage())
        #expect(!backend.isEnabled)
        #expect(backend.sidebar().places.isEmpty)
        files.handshakeLanded(LocalHello(protocolVersion: 1, backend: .local(reach: .container)))
        #expect(!backend.isEnabled)
        files.handshakeLanded(LocalHello(protocolVersion: 1, backend: .local(reach: .user)))
        #expect(backend.isEnabled)
        #expect(backend.sidebar().places.map(\.kind) == [.root])
        #expect(backend.sidebar().places.first?.location == .root(of: .applications))
    }

    @Test
    func `Scopes tell user apps from system apps by their bundle container`() {
        let user = InstalledApp(name: "A", bundleIdentifier: "a", bundlePath: "/var/containers/Bundle/Application/X/A.app", dataPath: nil)
        let system = InstalledApp(name: "B", bundleIdentifier: "b", bundlePath: "/Applications/B.app", dataPath: nil)
        #expect(AppScope.user.includes(user) && !AppScope.user.includes(system))
        #expect(AppScope.system.includes(system) && !AppScope.system.includes(user))
        #expect(AppScope.all.includes(user) && AppScope.all.includes(system))
        #expect(InstalledApp.name(" ", "\u{200E}", identifier: "com.apple.MediaRemoteUI") == "MediaRemoteUI")
        #expect(InstalledApp.name("Files", identifier: "x") == "Files")
    }

    @Test
    func `Folder decorations name containers by their owner and the lookup walks every installed app`() async throws {
        let app = InstalledApp(
            name: "Hoshino",
            bundleIdentifier: "com.hoshino.filemanager",
            bundlePath: "/private/var/containers/Bundle/Application/AAAA/Hoshino.app",
            dataPath: "/var/mobile/Containers/Data/Application/DDDD",
            groupPaths: ["group.com.hoshino.filemanager": "/var/mobile/Containers/Shared/AppGroup/GGGG"],
        )
        let lookup = ApplicationFolderDecorations.lookup(for: [app])
        #expect(lookup("/var/containers/Bundle/Application/AAAA")?.name == "Hoshino")
        #expect(lookup("/private/var/mobile/Containers/Data/Application/DDDD")?.applicationIdentifier == "com.hoshino.filemanager")
        #expect(lookup("/var/mobile/Containers/Shared/AppGroup/GGGG")?.name == "group.com.hoshino.filemanager")
        #expect(lookup("/var/mobile/Containers/Shared/AppGroup/GGGG")?.detail == "Hoshino")
        #expect(lookup("/etc") == nil)

        // An unknown data container is named from its own metadata plist.
        let plist = try PropertyListSerialization.data(
            fromPropertyList: ["MCMMetadataIdentifier": "com.example.other"], format: .xml, options: 0,
        )
        let named = await ApplicationFolderDecorations.load(
            in: "/var/mobile/Containers/Data/Application",
            entries: [("DDDD", true), ("EEEE", true), ("file", false)],
            apps: [app],
        ) { path in
            guard path.hasPrefix("/var/mobile/Containers/Data/Application/EEEE/") else {
                throw FilaFailure(code: .notFound, systemError: ENOENT, path: path)
            }
            return plist
        }
        #expect(named["DDDD"]?.name == "Hoshino")
        #expect(named["EEEE"]?.name == "other")
        #expect(named["EEEE"]?.detail == "com.example.other")
        #expect(named["file"] == nil)
        // Not a container root and no .app inside: nothing to decorate.
        let plain = await ApplicationFolderDecorations.load(in: "/etc", entries: [("x", true)], apps: [app]) { path in
            throw FilaFailure(code: .notFound, systemError: ENOENT, path: path)
        }
        #expect(plain.isEmpty)
    }

    /// What the link throws when the daemon goes away mid-request.
    private struct LinkDropped: Error {}

    /// Counts the metadata reads a listing makes.
    private final class ReadCounter: @unchecked Sendable {
        private let lock = NSLock()
        private var reads = 0

        func read() {
            lock.lock(); defer { lock.unlock() }
            reads += 1
        }

        var count: Int {
            lock.lock(); defer { lock.unlock() }
            return reads
        }
    }

    @Test
    func `A container whose metadata could not be read is asked again`() async throws {
        // The cache is process-wide: a name no other test lists.
        let container = UUID().uuidString
        let plist = try PropertyListSerialization.data(
            fromPropertyList: ["MCMMetadataIdentifier": "com.example.later"], format: .xml, options: 0,
        )
        // The daemon restarting: the open fails.
        let failed = await ApplicationFolderDecorations.load(
            in: ApplicationFolderDecorations.dataRoot, entries: [(container, true)], apps: [],
        ) { _ in throw LinkDropped() }
        #expect(failed[container] == nil)
        // Back again: the same container is named on the next listing.
        let named = await ApplicationFolderDecorations.load(
            in: ApplicationFolderDecorations.dataRoot, entries: [(container, true)], apps: [],
        ) { _ in plist }
        #expect(named[container]?.applicationIdentifier == "com.example.later")
    }

    @Test(arguments: [ENOENT, ENOTDIR, EACCES, EPERM])
    func `A container whose metadata cannot exist or be opened is read once`(code: Int32) async {
        // The cache is process-wide: a name no other test lists.
        let container = UUID().uuidString
        let reads = ReadCounter()
        for _ in 0 ..< 3 {
            let decorations = await ApplicationFolderDecorations.load(
                in: ApplicationFolderDecorations.groupRoot, entries: [(container, true)], apps: [],
            ) { path in
                reads.read()
                throw FilaFailure(code: .notFound, systemError: code, path: path)
            }
            #expect(decorations[container] == nil)
        }
        #expect(reads.count == 1, "every listing of the folder opened the file again")
    }

    @Test
    func `The catalogue is read once and dropped on a change hint or a new handshake`() async {
        let files = local()
        let backend = ApplicationBackend(local: files, storage: MemoryStorage())
        // Off: nothing is read and nothing is kept.
        #expect(await backend.applications().isEmpty)
        #expect(backend.catalog == nil)
        // The handshake's republish arrives through a stream and drops the
        // cache as it lands; the root row is published only once it has,
        // so wait for that before counting reads.
        let sidebar = backend.sidebarUpdates()
        files.handshakeLanded(LocalHello(protocolVersion: 1, backend: .local(reach: .user)))
        // Bounded: a lost publish fails the test rather than hanging the suite.
        // The bound is a hang guard, not a latency budget: on a loaded CI
        // runner the main actor was starved past five seconds while the
        // publish was still on its way.
        let landed = await withTaskGroup(of: Bool.self) { group in
            group.addTask {
                for await snapshot in sidebar where !snapshot.places.isEmpty {
                    return true
                }
                return false
            }
            group.addTask {
                try? await Task.sleep(nanoseconds: 60_000_000_000)
                return false
            }
            let first = await group.next() ?? false
            group.cancelAll()
            return first
        }
        #expect(landed)
        _ = await backend.applications()
        // `Task` is a handle: equal only when it is the same task.
        let first = backend.catalog
        #expect(first != nil)
        _ = await backend.applications()
        #expect(backend.catalog == first)
        // A visit publishes too — every folder the user uses does — and
        // must not cost the breadcrumb a second enumeration.
        if let path = try? ServicePath("/tmp") {
            try? files.recordVisit(path)
        }
        try? await Task.sleep(nanoseconds: 100_000_000)
        #expect(backend.catalog == first)
        _ = await backend.applications(refresh: true)
        #expect(backend.catalog != nil && backend.catalog != first)
        backend.catalogChanged()
        #expect(backend.catalog == nil)
    }

    @Test
    func `Only a container root or a folder holding an app bundle can carry decorations`() {
        #expect(ApplicationFolderDecorations.decorates("/private/var/containers/Bundle/Application", entries: []))
        #expect(ApplicationFolderDecorations.decorates("/var/mobile/Containers/Shared/AppGroup", entries: []))
        #expect(ApplicationFolderDecorations.decorates("/Applications", entries: [("Files.app", true)]))
        #expect(!ApplicationFolderDecorations.decorates("/Applications", entries: [("Files.app", false)]))
        #expect(!ApplicationFolderDecorations.decorates("/etc", entries: [("hosts", false), ("ssh", true)]))
    }

    @Test
    func `The change stream hints at once and on every catalogue change`() async {
        let backend = ApplicationBackend(local: local(), storage: MemoryStorage())
        var iterator = backend.changes().makeAsyncIterator()
        #expect(await iterator.next() != nil)
        backend.catalogChanged()
        #expect(await iterator.next() != nil)
    }
}
