import FilaBackendKit
@testable import FilaClient
import Foundation
import Testing

@Suite("Directory observation")
@MainActor
struct DirectoryObservationTests {
    private final class Clock: @unchecked Sendable {
        private let lock = NSLock()
        private var value: Double = 1
        private var calls = 0
        func tick() {
            lock.lock(); value += 1; lock.unlock()
        }

        func read() -> Double {
            lock.lock(); defer { lock.unlock() }; calls += 1; return value
        }

        var reads: Int {
            lock.lock(); defer { lock.unlock() }; return calls
        }

        /// True once the poller has read this many times. A fixed sleep
        /// followed by a count asserts the scheduler's speed as well as the
        /// polling; this waits for the polling alone, on the same slack
        /// `Hints.hinted` takes and for the same reason.
        func reached(_ count: Int, within seconds: Double) async -> Bool {
            let deadline = Date().addingTimeInterval(seconds)
            while Date() < deadline {
                if reads >= count {
                    return true
                }
                try? await Task.sleep(nanoseconds: 5_000_000)
            }
            return reads >= count
        }
    }

    /// Counts a stream's hints from a task that is never cancelled —
    /// cancelling a consumer ends an `AsyncThrowingStream`, so a timed wait
    /// polls this instead of racing `next()`.
    private final class Hints: @unchecked Sendable {
        private let lock = NSLock()
        private var value = 0
        private var task: Task<Void, Never>?
        var count: Int {
            lock.lock(); defer { lock.unlock() }; return value
        }

        init(_ stream: AsyncThrowingStream<Void, Error>) {
            task = Task { [weak self] in
                do {
                    for try await _ in stream {
                        guard let self else { return }
                        lock.withLock { self.value += 1 }
                    }
                } catch {}
            }
        }

        /// True once the count exceeds `after` within `seconds`.
        ///
        /// The bound is slack against a starved scheduler, not a latency
        /// assertion: six `@MainActor` suites in this target run in parallel
        /// on the one main actor, and a second of wall clock buys no actor
        /// hops while another suite is copying files on it. A passing wait
        /// returns as soon as the hint lands and never spends the bound.
        func hinted(after: Int, within seconds: Double) async -> Bool {
            let deadline = Date().addingTimeInterval(seconds)
            while Date() < deadline {
                if count > after {
                    return true
                }
                try? await Task.sleep(nanoseconds: 5_000_000)
            }
            return count > after
        }

        /// True when no hint arrives for `seconds`.
        func quiet(for seconds: Double) async -> Bool {
            let before = count
            try? await Task.sleep(nanoseconds: UInt64(seconds * 1_000_000_000))
            return count == before
        }

        deinit { task?.cancel() }
    }

    /// True once `condition` holds, with the slack `hinted(after:within:)`
    /// explains: a passing wait returns as soon as it does.
    private func eventually(within seconds: Double = 10, _ condition: () -> Bool) async -> Bool {
        let deadline = Date().addingTimeInterval(seconds)
        while Date() < deadline {
            if condition() {
                return true
            }
            try? await Task.sleep(nanoseconds: 5_000_000)
        }
        return condition()
    }

    @Test
    func `A subscription yields once at start, then only when hinted`() async {
        let observation = DirectoryObservation(interval: 3600)
        let clock = Clock()
        let hints = Hints(observation.subscribe("/tmp/a") { clock.read() })
        #expect(await hints.hinted(after: 0, within: 10))
        #expect(observation.subscriberCount == 1)

        // Neither a sibling nor a child hints the parent's screen...
        observation.invalidate(["/tmp/b"])
        observation.invalidate(["/tmp/a/child"])
        #expect(await hints.quiet(for: 0.1))
        // ...but the directory itself, or an ancestor, does — and three
        // hints in a row coalesce, never exceeding one per consumed turn.
        let before = hints.count
        observation.invalidate(["/tmp/a"])
        observation.invalidate(["/tmp"])
        observation.invalidate(["/"])
        #expect(await hints.hinted(after: before, within: 10))
        #expect(await hints.quiet(for: 0.1))
        #expect(hints.count <= before + 3)
    }

    @Test
    func `Cancelling removes the subscriber; the last one releases the watch`() async throws {
        let observation = DirectoryObservation(interval: 3600)
        let clock = Clock()
        let one = Task {
            for try await _ in observation.subscribe("/tmp/a", stat: { clock.read() }) {}
        }
        let two = Task {
            for try await _ in observation.subscribe("/tmp/a", stat: { clock.read() }) {}
        }
        #expect(await eventually { observation.subscriberCount == 2 })
        #expect(observation.watchedDirectories == ["/tmp/a"])
        one.cancel()
        #expect(await eventually { observation.subscriberCount == 1 })
        #expect(observation.watchedDirectories == ["/tmp/a"])
        two.cancel()
        #expect(await eventually { observation.subscriberCount == 0 })
        #expect(observation.watchedDirectories.isEmpty)
    }

    @Test
    func `Polling baselines at once, hints only when the modification time moves, and not while paused`() async throws {
        let observation = DirectoryObservation(interval: 0.02)
        let clock = Clock()
        let hints = Hints(observation.subscribe("/tmp/a") { clock.read() })
        #expect(await hints.hinted(after: 0, within: 10))
        // Unchanged time: polls happen, hints do not.
        #expect(await clock.reached(2, within: 10))
        #expect(await hints.quiet(for: 0.1))
        var count = hints.count
        clock.tick()
        #expect(await hints.hinted(after: count, within: 10))
        // The change was reported once; the new time is the baseline now.
        #expect(await hints.quiet(for: 0.1))

        // An operation the app ran hints at once and re-baselines: the
        // tick after it must not report the same change again.
        count = hints.count
        clock.tick()
        observation.invalidate(["/tmp/a"])
        #expect(await hints.hinted(after: count, within: 10))
        #expect(await hints.quiet(for: 0.15))

        observation.setPaused(true)
        // A stat already in flight when the pause landed still completes —
        // the read happens off the main actor and cancellation cannot recall
        // it — so the count starts once the reads have stopped moving. A
        // poll that never stops keeps them moving, and fails below.
        var reads = clock.reads
        for _ in 0 ..< 200 {
            try await Task.sleep(nanoseconds: 50_000_000)
            guard clock.reads != reads else { break }
            reads = clock.reads
        }
        try await Task.sleep(nanoseconds: 100_000_000)
        #expect(clock.reads == reads, "no polling in the background")
        // Resuming hints once regardless, and polling restarts.
        count = hints.count
        observation.setPaused(false)
        #expect(await hints.hinted(after: count, within: 10))
        #expect(await clock.reached(reads + 1, within: 10))
    }

    @Test
    func `The adapter's changes(in:) resolves the directory and reports a real modification`() async throws {
        let scratch = LocalScratch()
        scratch.directory("watched")
        let observation = DirectoryObservation(interval: 0.02)
        let adapter = LocalFileServiceAdapter(access: LocalFileService(), rootPath: scratch.root, observation: observation)
        let hints = try await Hints(adapter.changes(in: ServicePath("watched")))
        #expect(await hints.hinted(after: 0, within: 10))
        // The baseline is taken at subscription, so a change during the first
        // interval is seen. mtime resolution is a second on some filesystems:
        // set one that cannot equal the current time.
        var times = timeval(tv_sec: 1_600_000_000, tv_usec: 0)
        utimes(scratch.path("watched"), &times)
        #expect(await hints.hinted(after: 1, within: 12))
    }

    @Test
    func `A folder opened through a link is polled at its target, not at the link`() async throws {
        let scratch = LocalScratch()
        scratch.directory("target")
        #expect(symlink("target", scratch.path("link")) == 0)
        let observation = DirectoryObservation(interval: 0.02)
        let adapter = LocalFileServiceAdapter(access: LocalFileService(), rootPath: scratch.root, observation: observation)
        let hints = try await Hints(adapter.changes(in: ServicePath("link")))
        #expect(await hints.hinted(after: 0, within: 10))
        // Another process changes the folder; the link itself never moves.
        scratch.file("target/new.txt")
        var times = timeval(tv_sec: 1_600_000_000, tv_usec: 0)
        utimes(scratch.path("target"), &times)
        #expect(await hints.hinted(after: 1, within: 12))
    }
}
