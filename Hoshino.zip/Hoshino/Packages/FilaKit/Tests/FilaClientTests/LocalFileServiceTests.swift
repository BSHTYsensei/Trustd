import CRemoveFile
import Darwin
@testable import FilaClient
@testable import FilaProtocol
import Foundation
import Testing

/// The in-process backend, driven through `LocalFileAccess` exactly as the
/// app drives it.
///
/// Everything below runs against a real directory on a real filesystem, for the
/// same reason `FilaFileOpsTests` does: an operation that is only correct
/// against a mock is not correct. What is under test here is the wiring —
/// that every call reaches `FilaFileOps`, that a job reports on the stream, and
/// that the guard is still in the way — not the file layer itself, which has
/// its own suite.
@Suite("In-process backend")
struct LocalFileServiceTests {
    let scratch = LocalScratch()

    /// The in-process service on its own, as a build without the privileged
    /// module runs it. The privileged link's fallback onto this same class is
    /// covered in `FilaPrivilegedTests`.
    private func link() async throws -> any LocalFileAccess {
        LocalFileService()
    }

    /// The sentence the user is shown turns on this probe, and the sandboxed
    /// half of it is the half no simulator run ever exercises — a simulator
    /// app can read its container's parent, so it always answers `.user`.
    @Test
    func `A container it cannot read out of reads as sandboxed`() {
        guard geteuid() != 0 else { return } // root can open anything; the probe means nothing then.
        let container = scratch.directory("Application/UUID")
        #expect(LocalFileService.probeReach(container: container) == .user)

        chmod(scratch.path("Application"), 0)
        defer { chmod(scratch.path("Application"), 0o755) }
        #expect(LocalFileService.probeReach(container: container) == .container)
    }

    @Test
    func `Lists a directory`() async throws {
        scratch.file("one")
        scratch.file("two")
        let page = try await link().list(directory: scratch.root)
        #expect(Set(page.entries.map(\.name)) == ["one", "two"])
        #expect(page.isFinal)
    }

    @Test
    func `The client releases an abandoned listing through its selected backend`() async throws {
        for index in 0 ... FilaProtocol.directoryPageEntryCount {
            scratch.file("entry-\(index)")
        }
        let link = try await link()
        let page = try await link.list(directory: scratch.root)
        #expect(!page.isFinal)
        try await link.closeDirectory(cursor: page.cursor)
        let failure = await #expect(throws: FilaFailure.self) {
            _ = try await link.list(directory: scratch.root, cursor: page.cursor)
        }
        #expect(failure?.systemError == ESTALE)
        let replacement = try await link.list(directory: scratch.root)
        #expect(replacement.entries.count == FilaProtocol.directoryPageEntryCount)
        try await link.closeDirectory(cursor: replacement.cursor)
    }

    @Test
    func `Creates, stats and opens a file`() async throws {
        let link = try await link()
        try await link.create(.emptyFile, at: scratch.path("new.txt"))

        let details = try await link.details(of: scratch.path("new.txt"))
        #expect(details.path == scratch.path("new.txt"))
        #expect(!details.isDestructionProtected)

        let descriptor = try await link.open(scratch.path("new.txt"), flags: O_WRONLY)
        #expect(descriptor >= 0)
        #expect(write(descriptor, "fila", 4) == 4)
        close(descriptor)

        let refreshed = try await link.details(of: scratch.path("new.txt"))
        #expect(refreshed.node.size == 4)
    }

    @Test
    func `Renames, and reports the volume it renamed on`() async throws {
        let link = try await link()
        scratch.file("before")
        try await link.rename(scratch.path("before"), to: scratch.path("after"), exclusive: true)
        #expect(!exists(scratch.path("before")))
        #expect(exists(scratch.path("after")))

        let volume = try await link.volumeInfo(for: scratch.root)
        #expect(!volume.mountPoint.isEmpty)
    }

    @Test
    func `A copy job runs and reports its completion on the stream`() async throws {
        let link = try await link()
        scratch.directory("tree/inner")
        scratch.file("tree/inner/leaf", contents: "bytes")
        let destination = scratch.directory("landing")

        let identifier = try await link.startJob(
            JobRequest(kind: .copy, sources: [scratch.path("tree")], destination: destination),
        )
        var outcome: FilaFailure?
        for await update in link.jobEvents where update.identifier == identifier {
            if case let .completed(failure, _) = update.event {
                outcome = failure
                break
            }
        }
        #expect(outcome?.code == .success)
        #expect(exists(scratch.path("landing/tree/inner/leaf")))
    }

    /// The one that matters. There is no privilege boundary in this process,
    /// and the guard is enforced all the same — it is the same
    /// `FileOperations` the daemon runs, and refusing to move `/usr` away is
    /// not about privilege, it is about the device still booting.
    @Test
    func `FilaGuard refuses a protected node here exactly as in the daemon`() async throws {
        let link = try await link()
        await #expect(throws: FilaFailure(code: .protectedPath, path: "/usr")) {
            try await link.rename("/usr", to: scratch.path("usr"))
        }
    }

    @Test
    func `A protected node is reported as protected so the app can grey it out`() async throws {
        let details = try await link().details(of: "/usr")
        #expect(details.isDestructionProtected)
    }
}

/// A real directory, gone when the test is. The `FilaFileOps` suite has its own
/// copy of this; duplicating twenty lines is cheaper than a shared test module
/// between two independent test targets.
final class LocalScratch {
    let root: String

    init() {
        let created = "/private/tmp/fila-client-tests-\(getpid())-\(UInt32.random(in: 0 ..< .max))"
        precondition(mkdir(created, 0o755) == 0, "scratch: \(String(cString: strerror(errno)))")
        root = created
    }

    deinit { removefile(root, nil, removefile_flags_t(REMOVEFILE_RECURSIVE)) }

    func path(_ relative: String) -> String {
        root + "/" + relative
    }

    @discardableResult
    func directory(_ relative: String) -> String {
        var built = root
        for component in relative.split(separator: "/") {
            built += "/" + component
            precondition(mkdir(built, 0o755) == 0 || errno == EEXIST, "mkdir \(built)")
        }
        return built
    }

    @discardableResult
    func file(_ relative: String, contents: String = "fila") -> String {
        let path = path(relative)
        let descriptor = open(path, O_CREAT | O_TRUNC | O_WRONLY, 0o644)
        precondition(descriptor >= 0, "open \(path)")
        contents.withCString { _ = write(descriptor, $0, strlen($0)) }
        close(descriptor)
        return path
    }
}

func exists(_ path: String) -> Bool {
    var found = stat()
    return lstat(path, &found) == 0
}
