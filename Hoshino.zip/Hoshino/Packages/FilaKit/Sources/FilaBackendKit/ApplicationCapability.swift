import Foundation

/// What a directory shows about the app that owns it: a name in place of a
/// container UUID, a detail line, and the identifier whose artwork to draw.
/// Display metadata only; the directory's real name stays the identity
/// every operation uses.
public struct FolderDecoration: Sendable, Hashable {
    public let name: String
    public let detail: String?
    public let applicationIdentifier: String?

    public init(name: String, detail: String?, applicationIdentifier: String?) {
        self.name = name
        self.detail = detail
        self.applicationIdentifier = applicationIdentifier
    }
}

/// Where an installed application keeps its bytes.
public struct ApplicationLocation: Sendable, Hashable {
    public let name: String
    public let bundleIdentifier: String
    public let bundlePath: String
    /// Nil when the app has no data container, or when only a bundle scan
    /// could answer — the mapping lives in the installation database.
    public let dataPath: String?

    public init(name: String, bundleIdentifier: String, bundlePath: String, dataPath: String?) {
        self.name = name
        self.bundleIdentifier = bundleIdentifier
        self.bundlePath = bundlePath
        self.dataPath = dataPath
    }
}

/// Optional installed-app-folder decorations. The full jailbreak composition
/// bundles FilaApplications; the sandboxed composition intentionally omits it.
@MainActor
public protocol ApplicationCapability: AnyObject {
    /// Whether the feature is offered: whether the environment can see other
    /// apps at all.
    var isEnabled: Bool { get }

    /// The installed app registered under `bundleIdentifier`, or nil.
    func locate(bundleIdentifier: String) async -> ApplicationLocation?

    /// Decorations for the directories in `directory`, keyed by entry name.
    /// Empty when the feature is off or the directory is not one apps own.
    func decorations(in directory: String, entries: [(name: String, isDirectory: Bool)]) async -> [String: FolderDecoration]
    /// One lookup table for many paths — a breadcrumb asks once per crumb.
    func decorationLookup() async -> (String) -> FolderDecoration?

}
