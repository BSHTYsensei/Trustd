# Hoshino build and test audit — 2026-11-23

## Corrected test failures

`Packages/FilaKit/Tests/FilaFormatsTests/ArchiveTests.swift` contained two external, pre-branding fixtures whose payload still uses the original `wiki.qaq.fila` identifier:

- `sevenZip` is a checked-in 7z archive with `Package: wiki.qaq.fila\n` in its `control` member.
- `lonelyGzip` decompresses to `Package: wiki.qaq.fila\nVersion: 1.0\n`.

The tests had been changed to expect `com.hoshino.filemanager` without changing those immutable fixture bytes. Their expectations now match the actual external fixture data. Tests that generate a new Hoshino package archive continue to expect `com.hoshino.filemanager`.

A Python regression test decodes both fixtures and asserts that each expected payload matches its bytes. It also guards the generated Hoshino package fixture separately.

## Build diagnostics

The `harness` target now runs the SwiftPM tests serially with verbose output and emits an xUnit report. It stores:

- `swift-test.log`
- `swift-test.xml`
- `music-import.log`

The GitHub Actions workflow uploads these files even when a test or build step fails, so the exact failing test and assertion are retained rather than only the failing target name.

## Checks performed in this environment

- 14 Python regression tests passed.
- 349 Swift files passed Swift parser checks.
- Swift package manifest parsed; 29 targets and all explicit target paths were present.
- `Package.resolved` parsed with 15 pinned dependencies.
- All shell scripts passed `bash -n`.
- All Python files passed bytecode compilation.
- Xcode project, Info.plists, launchd plist, and entitlements passed `plutil -lint`.
- Localization, stale-string, GPU entitlement, launchd path, UI-library, accessibility and Makefile dry-run checks passed.

## Not run here

This container is Linux and cannot run `xcodebuild`, `xcrun`, or the macOS-only music-import harness. SwiftPM dependency checkout also cannot complete here because GitHub host resolution is unavailable. Therefore this audit does not claim that the full Swift test suite or iOS device build passed. The updated GitHub Actions job runs the real macOS SwiftPM harness before the iOS compile and TIPA packaging, and preserves the full failure report as an artifact.
