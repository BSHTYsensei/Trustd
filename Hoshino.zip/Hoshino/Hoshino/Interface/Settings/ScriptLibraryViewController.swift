import AlertController
import FilaBackendUI
import Then
import UIKit
import UniformTypeIdentifiers

@MainActor
final class ScriptLibraryViewController: UITableViewController, UIDocumentPickerDelegate {
    private var scripts: [ScriptLibraryEntry] = []
    private var isRunning = false

    init() {
        super.init(style: .insetGrouped)
    }

    @available(*, unavailable)
    required init?(coder _: NSCoder) { fatalError("init(coder:) is not used") }

    override func viewDidLoad() {
        super.viewDidLoad()
        title = String(localized: "Scripts")
        navigationItem.backButtonDisplayMode = .minimal
        tableView.do {
            $0.rowHeight = UITableView.automaticDimension
            $0.estimatedRowHeight = 60
            $0.contentInset.bottom = FilaUI.Spacing.settingsTail
        }
        navigationItem.leftBarButtonItem = UIBarButtonItem(
            systemItem: .add,
            primaryAction: UIAction { [weak self] _ in self?.importScript() },
        )
        navigationItem.leftBarButtonItem?.accessibilityLabel = String(localized: "Import Script")
        navigationItem.rightBarButtonItem = UIBarButtonItem(
            image: UIImage(systemName: "play.fill"),
            primaryAction: UIAction { [weak self] _ in self?.confirmRunSelected() },
        )
        navigationItem.rightBarButtonItem?.accessibilityLabel = String(localized: "Run Enabled Scripts")
        reloadScripts()
    }

    override func numberOfSections(in _: UITableView) -> Int { 1 }
    override func tableView(_: UITableView, numberOfRowsInSection _: Int) -> Int { scripts.count }

    override func tableView(_: UITableView, titleForHeaderInSection _: Int) -> String? {
        String(localized: "Documents/Scripts")
    }

    override func tableView(_: UITableView, titleForFooterInSection _: Int) -> String? {
        String(localized: "Imported scripts are stored in Documents/Scripts. Enable only scripts you trust. They run as the app user, not as root. Missing interpreters are shown on each row.")
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let entry = scripts[indexPath.row]
        let cell = UITableViewCell(style: .subtitle, reuseIdentifier: nil)
        cell.selectionStyle = .none
        cell.textLabel?.text = entry.fileName
        cell.textLabel?.numberOfLines = 0
        cell.detailTextLabel?.text = entry.runtimeAvailable
            ? ".\(entry.fileExtension.uppercased()) · \(String(localized: "Interpreter available"))"
            : ".\(entry.fileExtension.uppercased()) · \(String(localized: "Interpreter unavailable"))"
        cell.detailTextLabel?.textColor = entry.runtimeAvailable ? .secondaryLabel : .systemOrange
        let toggle = UISwitch()
        toggle.isOn = entry.isEnabled
        toggle.accessibilityLabel = String(localized: "Enable \(entry.fileName)")
        toggle.addAction(UIAction { [weak self, weak toggle] _ in
            guard let self, let toggle else { return }
            do {
                try ScriptLibrary.setEnabled(toggle.isOn, for: entry.fileName)
                reloadScripts()
            } catch {
                toggle.setOn(!toggle.isOn, animated: true)
                presentMessage(String(localized: "Unable to Update Script"), message: error.localizedDescription)
            }
        }, for: .valueChanged)
        cell.accessoryView = toggle
        return cell
    }

    override func tableView(_ tableView: UITableView, trailingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration? {
        let entry = scripts[indexPath.row]
        let delete = UIContextualAction(style: .destructive, title: String(localized: "Delete")) { [weak self] _, _, completion in
            guard let self else { completion(false); return }
            do {
                try ScriptLibrary.delete(entry.fileName)
                reloadScripts()
                completion(true)
            } catch {
                presentMessage(String(localized: "Unable to Delete Script"), message: error.localizedDescription)
                completion(false)
            }
        }
        return UISwipeActionsConfiguration(actions: [delete])
    }

    func documentPicker(_ controller: UIDocumentPickerViewController, didPickDocumentsAt urls: [URL]) {
        controller.dismiss(animated: true) { [weak self] in
            guard let self else { return }
            var failures: [String] = []
            for url in urls {
                do { _ = try ScriptLibrary.importScript(from: url) }
                catch { failures.append("\(url.lastPathComponent): \(error.localizedDescription)") }
            }
            reloadScripts()
            if !failures.isEmpty {
                presentMessage(String(localized: "Some Scripts Could Not Be Imported"), message: failures.joined(separator: "\n\n"))
            }
        }
    }

    private func reloadScripts() {
        do {
            scripts = try ScriptLibrary.entries()
            tableView.reloadData()
            if scripts.isEmpty {
                let empty = UILabel()
                empty.numberOfLines = 0
                empty.textAlignment = .center
                empty.textColor = .secondaryLabel
                empty.text = String(localized: "No scripts yet. Import scripts to Documents/Scripts.")
                tableView.backgroundView = empty
            } else {
                tableView.backgroundView = nil
            }
        } catch {
            presentMessage(String(localized: "Unable to Load Scripts"), message: error.localizedDescription)
        }
    }

    private func importScript() {
        let picker = UIDocumentPickerViewController(forOpeningContentTypes: [.data], asCopy: true)
        picker.delegate = self
        picker.allowsMultipleSelection = true
        present(picker, animated: true)
    }

    private func confirmRunSelected() {
        let selectedCount = scripts.filter(\.isEnabled).count
        guard selectedCount > 0, !isRunning else {
            if selectedCount == 0 { presentMessage(String(localized: "No Scripts Enabled"), message: String(localized: "Enable one or more scripts before running the library.")) }
            return
        }
        let alert = AlertViewController(
            title: String.LocalizationValue("Run Enabled Scripts?"),
            message: String.LocalizationValue("\(selectedCount) enabled script(s) will run sequentially as the app user. They can read and modify files available to Hoshino. They will not run as root. Continue only if you trust every enabled script."),
        ) { [weak self] context in
            context.addAction(title: String.LocalizationValue("Cancel")) { context.dispose() }
            context.addAction(title: String.LocalizationValue("Run"), attribute: .accent) {
                context.dispose { self?.runSelected() }
            }
        }
        present(alert, animated: true)
    }

    private func runSelected() {
        isRunning = true
        navigationItem.rightBarButtonItem?.isEnabled = false
        Task { [weak self] in
            guard let self else { return }
            let executions = await ScriptLibrary.runSelected()
            isRunning = false
            navigationItem.rightBarButtonItem?.isEnabled = true
            let lines = executions.map { execution -> String in
                if let result = execution.result {
                    let status = result.timedOut ? "Timed out" : "Exit \(result.exitCode)"
                    return "===== \(execution.name) · \(status) =====\n\(result.output)"
                }
                return "===== \(execution.name) · Failed =====\n\(execution.error ?? "Unknown error")"
            }
            let output = lines.joined(separator: "\n\n")
            let boundedOutput = String(output.prefix(1_000_000))
            let failed = executions.contains { $0.result?.succeeded != true }
            let result = ScriptRunResult(
                output: boundedOutput + (output.count > 1_000_000 ? "\n\n[Output truncated at 1,000,000 characters]" : ""),
                exitCode: failed ? 1 : 0,
                timedOut: executions.contains { $0.result?.timedOut == true },
                runtime: "Hoshino Script Library · \(executions.count) script(s)",
            )
            let outputController = ScriptOutputViewController(scriptName: String(localized: "Selected Scripts"), result: result)
            presentAsFormSheet(UINavigationController(rootViewController: outputController))
        }
    }
}
