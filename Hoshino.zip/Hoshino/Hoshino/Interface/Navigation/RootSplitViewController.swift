import FilaBackendKit
import FilaBackendUI
import Then
import UIKit

/// The shell: a tab, and — wherever the width is regular — a sidebar beside it.
///
/// Regular is a width, not a device: an iPad, and an iPhone Duo's inner display
/// in either orientation, both get the column; a phone, the Duo's outer display
/// and a narrow window get the sheet. Nothing here asks which device it is on —
/// `isCollapsed` is the whole of the decision, and UIKit makes it.
///
/// The home screen is the tab's content. There is no third column any more:
/// a viewer, an editor or a terminal fills the tab it was opened from rather
/// than living in a panel beside it, which is what makes "a tab" mean the same
/// thing on a phone and on an iPad.
///
/// Two columns, and a third view controller for the collapsed shape. Setting
/// one for `.compact` is what stops UIKit merging the sidebar into the phone's
/// navigation stack: on a phone the sidebar is not a column that happens to be
/// off screen, it is a sheet, and the browser is the root of the app rather
/// than something you reach past a list of places.
final class RootSplitViewController: UISplitViewController {
    /// The primary column, and only ever that. A phone reaches the same
    /// destinations through every page's Go menu and the tab overview's plus.
    let sidebar = SidebarViewController()

    /// This window's tabs. One list per window scene, keyed by the scene
    /// session that made this shell, so two windows on an iPad each keep
    /// their own — see `BrowserTabStore`.
    let tabs: BrowserTabStore

    /// One runtime owner moves intact between the split view's column hosts.
    /// A size-class change never dismantles a tab's navigation subtree.
    let content: TabContainerViewController
    private let wideContent = UIViewController()
    private let compactContent = UIViewController()

    /// `sessionIdentifier` is the scene session's `persistentIdentifier`:
    /// what the window's tabs are stored under.
    init(sessionIdentifier: String) {
        tabs = BrowserTabStore(sessionIdentifier: sessionIdentifier)
        content = TabContainerViewController(store: tabs)
        super.init(style: .doubleColumn)
        content.owner = self
    }

    @available(*, unavailable)
    required init?(coder _: NSCoder) {
        fatalError("not supported")
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        // Now, not on first use: the menus read it synchronously, and on a
        // phone the sidebar column never loads — a Go menu that built the
        // model itself showed it before any backend had reported, without Places.
        _ = BackendComposition.sidebar
        delegate = self
        displayModeButtonVisibility = .never
        preferredDisplayMode = .oneBesideSecondary
        preferredSplitBehavior = .tile
        setViewController(UINavigationController(rootViewController: sidebar), for: .primary)
        // Split view wraps a plain secondary controller in a navigation
        // controller. Supply both column wrappers with their bars hidden;
        // the live tab is the only owner of visible navigation chrome.
        let wideNavigation = UINavigationController(rootViewController: wideContent)
        wideNavigation.setNavigationBarHidden(true, animated: false)
        setViewController(wideNavigation, for: .secondary)
        let compactNavigation = UINavigationController(rootViewController: compactContent)
        compactNavigation.setNavigationBarHidden(true, animated: false)
        setViewController(compactNavigation, for: .compact)

        // The handshake is started here rather than lazily by the first
        // request: `filad` is on-demand, and asking early means the daemon is
        // usually up by the time the first directory is asked for.
        Task { await FileSession.shared.ready() }
    }

    /// `isCollapsed` is only true once UIKit has laid the split view out, so
    /// the tab is installed here rather than in `viewDidLoad` — where it would
    /// go into the wrong column on a phone and have to be moved a moment later,
    /// listing the same directory twice.
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        syncContentColumn()
    }

    // MARK: - The tab

    /// Moves the content owner, including an open overview and every retained
    /// tab, into the visible column. The navigation controllers stay parented.
    private func syncContentColumn() {
        content.move(to: isCollapsed ? compactContent : wideContent)
        if content.navigation == nil {
            content.showCurrentTab()
        }
        content.refreshSidebarButton()
    }

    /// Our own items rather than `displayModeButtonItem`: UIKit already shows
    /// that one in the primary column. One item per bar, because a bar button
    /// item has one view and UIKit's animated item swap fades that view — an
    /// item shared between two bars would have nothing left to fade out of the
    /// first while it fades into the second.
    ///
    /// The same rule applies along the navigation stack: a push or pop renders
    /// the departing and arriving bars together, so an item taken off the
    /// departing screen in `willShow` left a blank capsule behind and faded
    /// in late on the arriving one. Every screen keeps its own pair, ready
    /// before the transition starts.
    private let sidebarToggles = NSMapTable<UIViewController, UIBarButtonItem>.weakToStrongObjects()
    private let navigationBacks = NSMapTable<UIViewController, UIBarButtonItem>.weakToStrongObjects()
    private lazy var columnToggle = makeSidebarToggle()

    private func item(
        in table: NSMapTable<UIViewController, UIBarButtonItem>,
        for controller: UIViewController,
        make: () -> UIBarButtonItem,
    ) -> UIBarButtonItem {
        if let item = table.object(forKey: controller) {
            return item
        }
        let item = make()
        table.setObject(item, forKey: controller)
        return item
    }

    private func makeSidebarToggle() -> UIBarButtonItem {
        UIBarButtonItem(
            image: UIImage(systemName: "sidebar.leading"),
            primaryAction: UIAction { [weak self] _ in
                guard let self else { return }
                if isCollapsed {
                    presentSidebar()
                } else if displayMode == .secondaryOnly {
                    show(.primary)
                } else {
                    hide(.primary)
                }
            },
        ).then {
            $0.accessibilityLabel = String(localized: "Places")
            $0.title = String(localized: "Places")
            if #available(iOS 26.0, *) {
                $0.identifier = "sidebar"
                $0.sharesBackground = false
            }
        }
    }

    /// A standard Back item preserves the guarded history menu while allowing
    /// the sidebar toggle to move between columns independently.
    private func makeNavigationBack() -> UIBarButtonItem {
        UIBarButtonItem(
            image: UIImage(systemName: "chevron.backward"),
            primaryAction: UIAction { [weak self] _ in
                self?.navigateBack()
            },
        ).then {
            $0.accessibilityLabel = String(localized: "Back")
            $0.title = String(localized: "Back")
            if #available(iOS 26.0, *) {
                $0.identifier = "back"
                $0.sharesBackground = false
            }
        }
    }

    private var announcedDisplayMode: UISplitViewController.DisplayMode?
    private var animateToggleTransfer = false

    func configureSidebarButton(for controller: UIViewController, leadingItems: [UIBarButtonItem]? = nil) {
        guard controller === content.visibleTop, let navigation = controller.navigationController,
              let index = navigation.viewControllers.firstIndex(of: controller) else { return }
        prepareNavigationItems(
            for: controller,
            in: navigation,
            ancestors: Array(navigation.viewControllers.prefix(index)),
            leadingItems: leadingItems,
        )
    }

    /// The destination need not be in the stack yet. The tab supplies its future
    /// ancestors before UIKit starts rendering the push or pop transition.
    func prepareNavigationItems(
        for controller: UIViewController,
        in navigation: UINavigationController,
        ancestors: [UIViewController],
        leadingItems: [UIBarButtonItem]? = nil,
    ) {
        let item = controller.navigationItem
        let toggle = self.item(in: sidebarToggles, for: controller, make: makeSidebarToggle)
        let back = self.item(in: navigationBacks, for: controller, make: makeNavigationBack)
        let inSidebar = !isCollapsed && (announcedDisplayMode ?? displayMode) != .secondaryOnly
        // Collapsed, the toggle opens Places as a sheet, not a column: say so
        // with the shape of an index rather than of a sidebar.
        toggle.image = UIImage(systemName: isCollapsed ? "bookmark" : "sidebar.leading")
        var buttons = (leadingItems ?? item.leftBarButtonItems ?? [])
            .filter { $0 !== toggle && $0 !== back }
        // An editor or selection mode owns its Cancel/guarded Back. Keep that
        // exit intact, rather than creating another route around its save guard.
        if !controller.isEditing, !item.hidesBackButton {
            if !ancestors.isEmpty, buttons.isEmpty {
                back.menu = UIMenu(children: ancestors.reversed().map { destination in
                    UIAction(
                        title: destination.navigationItem.title ?? destination.title ?? String(localized: "Back"),
                    ) { [weak self, weak destination] _ in
                        guard let destination else { return }
                        self?.navigateBack(to: destination)
                    }
                })
                buttons.insert(back, at: 0)
            } else if ancestors.isEmpty, buttons.isEmpty,
                      let browser = controller as? FileBrowserViewController, hasParent(browser.directory)
            {
                back.menu = nil
                buttons.insert(back, at: 0)
            }
            // Custom leading items suppress UIKit's default Back control.
            // Keep its native edge transition, subject to editor guards.
            navigation.interactivePopGestureRecognizer?.delegate = self
            // The Places page is the folder browser's own control, and on a
            // phone it is the only way into it: the Go menu and the
            // breadcrumb's long press are its destinations flattened into a
            // menu, not the page. A viewer, an editor, a settings page or the
            // tab overview is not a folder and has no places to jump to; they
            // keep Back alone.
            if !inSidebar, controller is FileBrowserViewController {
                buttons.append(toggle)
            }
        }
        item.leftItemsSupplementBackButton = false
        // UIKit's animated item swap fades the arriving and departing buttons
        // alongside the column slide it was announced with.
        let animated = animateToggleTransfer && !UIAccessibility.isReduceMotionEnabled
        if (item.leftBarButtonItems ?? []) != buttons {
            item.setLeftBarButtonItems(buttons.isEmpty ? nil : buttons, animated: animated)
        }
        sidebar.setColumnToggle(inSidebar ? columnToggle : nil, animated: animated)
    }

    /// Whether Back at the root of a tab's stack has a folder to open. Not at
    /// `/`, and not at the local backend's own root: inside a container that
    /// is Documents, and nothing above it is offered — the breadcrumb and the
    /// restored tab chain stop there too.
    private func hasParent(_ directory: String) -> Bool {
        guard directory != "/" else { return false }
        let root = FileSession.shared.local.rootPath
        guard root != "/" else { return true }
        return ![root, URL(fileURLWithPath: root).resolvingSymlinksInPath().path].contains(directory)
    }

    private func navigateBack(to requested: UIViewController? = nil) {
        guard let source = content.visibleTop,
              !source.isEditing, !source.navigationItem.hidesBackButton,
              let navigation = source.navigationController,
              navigation.transitionCoordinator == nil else { return }
        if navigation.viewControllers.count == 1 {
            guard requested == nil, let browser = source as? FileBrowserViewController,
                  hasParent(browser.directory) else { return }
            let parent = FileBrowserViewController(directory: (browser.directory as NSString).deletingLastPathComponent)
            navigation.setViewControllers([parent, source], animated: false)
            navigation.popViewController(animated: true)
            return
        }
        let destination = requested ?? navigation.viewControllers[navigation.viewControllers.count - 2]
        let perform = { [weak self, weak source, weak navigation, weak destination] in
            guard let self, let source, let navigation, let destination,
                  content.visibleTop === source,
                  navigation.topViewController === source,
                  navigation.viewControllers.contains(where: { $0 === destination }),
                  destination !== source else { return }
            navigation.popToViewController(destination, animated: true)
        }
        if let confirm = (source as? ViewerContainerViewController)?.confirmReplacement {
            confirm({}, perform)
        } else {
            perform()
        }
    }

    /// Re-roots the current tab at `path`, without retaining the old location.
    ///
    /// A jump and not a descent: this is what the sidebar's places, favorites
    /// and recents do, and going to `/etc` from `/var/mobile/Documents` is not
    /// something Back should walk out of through somebody's Documents. Back out
    /// of the jump climbs `/etc`'s own chain instead. Each parent is created
    /// only when Back opens it, so an unseen ancestor is never a recent visit.
    /// The compact column already hosts content. show(.secondary) while
    /// collapsed asks UIKit to push its navigation wrapper and crashes on iOS 18.
    func open(_ path: String, select: String? = nil) {
        confirmLeavingContent { [weak self] in
            guard let self else { return }
            dismissSidebarSheet()
            content.showRoot(path, select: select)
            if !isCollapsed {
                show(.secondary)
            }
        }
    }

    /// A folder named by a crumb on a screen that is not a browser — a
    /// viewer, a search, a terminal. Back to that folder's browser when it is
    /// on the stack, which it is after a descent; otherwise a jump to it,
    /// the way the sidebar's rows arrive.
    func showDirectory(_ path: String, from screen: UIViewController) {
        if let navigation = screen.navigationController,
           let browser = navigation.viewControllers.last(where: { ($0 as? FileBrowserViewController)?.directory == path })
        {
            navigation.popToViewController(browser, animated: true)
            return
        }
        open(path)
    }

    /// Pushes a screen into the current tab — a viewer, an editor, a search, a
    /// terminal. This is the only way anything gets in front of a tab, which is
    /// what makes "a tab can be covered by a preview" true without a second
    /// mechanism for each kind of cover.
    func push(_ viewController: UIViewController, animated: Bool = true) {
        confirmLeavingContent(replacing: false) { [weak self] in
            self?.dismissSidebarSheet()
            self?.content.navigation?.pushViewController(viewController, animated: animated)
        }
    }

    /// A catalogue or a server replaces the tab's page, with no transition —
    /// the sidebar's row and the Go menu both land here.
    ///
    /// In a regular layout that is the whole story: the sidebar column stays on
    /// screen, so another row is one tap away and the page needs no history of
    /// its own. In a collapsed one the sidebar is a sheet that leaves with the
    /// tap, and a catalogue root has no folder and no parent — a stack holding
    /// nothing but itself had no way back. There the page lands *on top of* the
    /// one it was made from instead.
    func replace(_ viewController: UIViewController) {
        confirmLeavingContent { [weak self] in
            guard let self else { return }
            dismissSidebarSheet()
            if isCollapsed {
                var stack = content.navigation?.viewControllers ?? []
                // The same catalogue twice is the same place: a second tap on
                // its row replaces the page rather than stacking another copy.
                if let top = stack.last, type(of: top) == type(of: viewController) {
                    stack.removeLast()
                }
                stack.append(viewController)
                content.navigation?.setViewControllers(stack, animated: false)
            } else {
                content.navigation?.setViewControllers([viewController], animated: false)
                show(.secondary)
            }
        }
    }

    /// Opens `path` in a new tab and shows it.
    ///
    /// At the cap it opens in *this* tab instead — the request was to see the
    /// folder, and refusing to navigate at all would read as the menu item
    /// being broken. Saying so is the toast's job. It goes through the browser
    /// that is on screen rather than pushing directly, so the folder arrives by
    /// the same rule as every other way of naming one: a child descends,
    /// anything else jumps. See `FileBrowserViewController.open(directory:)`.
    func openInNewTab(_ path: String) {
        content.captureCurrentTab()
        guard let tab = tabs.open(path) else {
            openInCurrentTabAtCap(path)
            return
        }
        // A tour rather than a cut, so that opening in a new tab feels like
        // something happened: the page shrinks to its card, the new card
        // arrives beside it, and the new tab zooms out of that card. Reduce
        // Motion, or the overview already open, goes straight to the tab.
        guard !UIAccessibility.isReduceMotionEnabled, !content.isShowingOverview, view.window != nil else {
            content.showCurrentTab()
            return
        }
        content.showTabSwitcher(deferring: tab.id)
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.45) { [weak self] in
            self?.content.revealDeferredTab()
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) { self?.content.showCurrentTab() }
        }
    }

    /// A catalogue or a server in a tab of its own, as the switcher's plus
    /// says. In a collapsed layout the default folder — where a new tab opens
    /// anyway — sits beneath it, so Back and the edge swipe have a page to
    /// return to, and the tab records that folder, which is what it restores
    /// to. In a regular one the page stands alone, as it always has: the
    /// sidebar column is the way out.
    func openInNewTab(location: BackendLocation) {
        guard let screen = SidebarLocation.screen(for: location), !tabs.isFull else { return }
        content.captureCurrentTab()
        let directory = AppPreferences.shared.launchDirectory
        guard tabs.open(directory) != nil else { return }
        content.showCurrentTab(
            root: screen,
            beneath: isCollapsed ? FileBrowserViewController(directory: directory) : nil,
        )
    }

    /// A new tab asked for at the cap: the folder opens in the current tab
    /// instead, and the card says so.
    private func openInCurrentTabAtCap(_ path: String, select: String? = nil) {
        FeedbackAlert.show(
            String(localized: "Too Many Tabs"),
            message: String(localized: "This folder opened in the current tab. Close a tab to open a new one."),
        )
        confirmLeavingContent { [weak self] in
            guard let self else { return }
            // A file to select is a jump to its folder, as `fila://reveal` is:
            // the browser's own descent has nothing to select with.
            if select == nil, let browser = content.navigation?.topViewController as? FileBrowserViewController {
                browser.open(directory: path)
            } else {
                content.showRoot(path, select: select)
            }
        }
    }

    /// The `fila://open?path=…&tab=new` destination. `BrowserTabStore.openFromLink`
    /// decides *whether* a tab is made — it is capped and it deduplicates,
    /// because a link is an unauthenticated entry point. At the cap the link
    /// opens in the current tab, as Open in New Tab does, so it navigates
    /// either way. `select` names the file the link pointed at, in `path`.
    func openFromLink(_ path: String, select: String? = nil) {
        content.captureCurrentTab()
        guard tabs.openFromLink(path, selection: select) else {
            openInCurrentTabAtCap(path, select: select)
            if !isCollapsed {
                show(.secondary)
            }
            return
        }
        content.showCurrentTab()
        // A tab already open at `path` keeps its built page, made before this
        // link; a new one has the name already, and asking twice is harmless.
        // A viewer or editor over the folder stays where it is: a link does
        // not close the person's document to show a row under it.
        if let select, let browser = content.navigation?.topViewController as? FileBrowserViewController,
           browser.directory == path
        {
            browser.reveal(select)
        }
        if !isCollapsed {
            show(.secondary)
        }
    }

    /// The overview covers the content, without dismissing any document.
    func presentTabSwitcher() {
        content.showTabSwitcher()
    }

    func selectTab(_ id: UUID) {
        content.captureCurrentTab()
        tabs.select(id)
        content.showCurrentTab()
    }

    func closeTab(_ id: UUID) {
        closeTabs([id][...])
    }

    func closeAllTabs() {
        closeTabs(tabs.tabs.map(\.id)[...]) { [weak self] in
            guard let self else { return }
            tabs.closeAll()
            content.removeClosedTabs()
            content.showCurrentTab()
        }
    }

    /// Keep the overview and surviving previews installed while removing cards.
    /// Only an editor that actually needs a save/discard prompt becomes visible.
    private func closeTabs(_ ids: ArraySlice<UUID>, completion: (() -> Void)? = nil) {
        guard let id = ids.first else {
            if let completion {
                completion()
            } else {
                content.showTabSwitcher()
            }
            return
        }
        guard tabs.tabs.contains(where: { $0.id == id }) else {
            closeTabs(ids.dropFirst(), completion: completion)
            return
        }
        content.confirmClosingTab(id) { [weak self] in
            guard let self else { return }
            tabs.close(id)
            content.removeClosedTabs()
            closeTabs(ids.dropFirst(), completion: completion)
        }
    }

    /// Closing or replacing content consults the editor that owns its work.
    /// Merely switching to another retained tab does not discard anything.
    ///
    /// `replacing` is false for a push, which covers the page and leaves it in
    /// the stack, so a running install under it carries on.
    private func confirmLeavingContent(replacing: Bool = true, _ leave: @escaping () -> Void) {
        // The page on this screen, not a tab still arriving from a menu: a
        // push or replace acts on what the person is looking at.
        content.showInstalledTab()
        if replacing, refusesLeavingInstall() {
            return
        }
        let navigation = content.navigation
        let source = navigation?.topViewController
        let viewer = navigation?.viewControllers.compactMap { $0 as? ViewerContainerViewController }.last
        let finish = { [weak self, weak navigation, weak source] in
            // Saving may finish after a tab switch. Its permission applies
            // only to the page that asked, never to a newly selected editor.
            guard let self, content.navigation === navigation,
                  navigation?.topViewController === source else { return }
            leave()
        }
        if let confirm = viewer?.confirmReplacement {
            confirm({}, finish)
        } else {
            leave()
        }
    }

    /// A package install running in this tab, said so before a replacement
    /// starts rather than when it lands: the navigation would refuse it too,
    /// but after the sidebar closed and the tab store had recorded the jump.
    private func refusesLeavingInstall() -> Bool {
        guard let navigation = content.navigation as? TabNavigationController else { return false }
        return navigation.refusesRemoving(navigation.viewControllers)
    }

    /// Called when the app goes away. The stack is already written down on
    /// every push and pop; this catches the scroll position, which moves
    /// continuously and is not worth a notification per pixel.
    func rememberState() {
        content.captureCurrentTab()
    }

    // MARK: - The sidebar

    /// A column where the width is regular, a sheet where it is compact.
    ///
    /// The phone gets a *second* `SidebarViewController` rather than the one in
    /// the primary column, because that one is inside the split view's own
    /// navigation controller and moving a view controller out of a container to
    /// present it and back again is a great deal of ceremony for a list that
    /// rebuilds itself from `UserDefaults` in a millisecond.
    func presentSidebar() {
        guard isCollapsed else {
            show(.primary)
            return
        }
        presentAsSheet(UINavigationController(rootViewController: SidebarViewController()))
    }

    /// The shell's own sheets — Places on a phone, Settings anywhere —
    /// give way when content is replaced beneath them: a server saved in
    /// Settings › Servers opens, and the sheet that added it is not left
    /// covering it. Any other presentation stays.
    private func dismissSidebarSheet() {
        let root = (presentedViewController as? UINavigationController)?.viewControllers.first
        guard root is SidebarViewController || root is SettingsViewController else { return }
        dismiss(animated: true)
    }
}

extension RootSplitViewController: UISplitViewControllerDelegate {
    func splitViewController(
        _: UISplitViewController,
        willChangeTo displayMode: UISplitViewController.DisplayMode,
    ) {
        announcedDisplayMode = displayMode
        animateToggleTransfer = true
        content.refreshSidebarButton()
        animateToggleTransfer = false
    }

    func splitViewControllerDidCollapse(_: UISplitViewController) {
        syncContentColumn()
    }

    func splitViewControllerDidExpand(_: UISplitViewController) {
        syncContentColumn()
    }
}

extension RootSplitViewController: UIGestureRecognizerDelegate {
    func gestureRecognizerShouldBegin(_ gestureRecognizer: UIGestureRecognizer) -> Bool {
        guard let top = content.visibleTop, let navigation = top.navigationController,
              gestureRecognizer === navigation.interactivePopGestureRecognizer,
              navigation.viewControllers.count > 1, navigation.transitionCoordinator == nil,
              (navigation as? TabNavigationController)?.isTransitionPending != true,
              !top.isEditing, !top.navigationItem.hidesBackButton,
              !top.isModalInPresentation else { return false }
        return true
    }
}
