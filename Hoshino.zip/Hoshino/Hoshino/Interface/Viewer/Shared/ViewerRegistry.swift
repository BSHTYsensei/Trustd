import AlertController
import FilaBackendUI
import FilaClient
import FilaFormats
import FilaLog
import FilaProtocol
import SnapKit
import UIKit

/// The seam between the browser and everything that opens a file.
///
/// The browser knows this one function and nothing else about viewers, so
/// adding a format is adding a file here — never a change to the list. That is
/// the whole reason the registry exists rather than a `switch` in the browser.
enum ViewerRegistry {
    /// The viewer for a file, or nil when there is nothing to open — a
    /// directory, a socket, a device node. Nil is meant to be rare: `FileFormat`
    /// has no "unknown" case because the hex viewer is the floor and every file
    /// has one.
    ///
    /// Prepare the selected viewer and its navigation items before the caller
    /// pushes it. Format detection must not add editor buttons mid-transition.
    ///
    /// A gallery is the folder's other images; only the image viewer reads it.
    @MainActor
    static func makeViewer(
        for details: FileDetails,
        link: any LocalFileAccess,
        gallery: ImageGallery? = nil,
    ) async -> UIViewController? {
        let kind = details.node.kind == .symbolicLink ? details.node.link?.resolvedKind : details.node.kind
        guard kind == .regular else { return nil }
        let viewer = ViewerContainerViewController(details: details, link: link, gallery: gallery)
        await viewer.prepare()
        return viewer
    }

    /// The format-to-viewer table. The only place the mapping is written down.
    static func viewer(
        for format: FileFormat,
        details: FileDetails,
        file: DescriptorFile,
        link: any LocalFileAccess,
        gallery: ImageGallery?,
    ) -> UIViewController {
        switch format {
        case .propertyList:
            PropertyListEditorViewController(details: details, file: file, link: link)
        case .machO:
            MachOInspectorViewController(details: details, file: file, link: link)
        case .archive:
            ArchiveBrowserViewController(details: details, file: file, link: link)
        case .image:
            ImageViewerViewController(details: details, file: file, gallery: gallery)
        case .audio:
            MediaPlayerViewController(details: details, file: file, isAudio: true)
        case .video:
            MediaPlayerViewController(details: details, file: file, isAudio: false)
        case .pdf:
            PDFViewerViewController(details: details, file: file)
        case .document:
            DocumentViewerViewController(details: details, file: file)
        case .text:
            TextViewerViewController(details: details, file: file, link: link)
        // A SQLite browser is a viewer several times the size of the others and
        // is deliberately deferred; until it exists the file is bytes, and bytes
        // have a viewer.
        case .sqlite, .binary:
            HexViewerViewController(details: details, file: file)
        }
    }
}

/// Opens the file once, detects what it is, and hosts the viewer that resulted.
///
/// One descriptor for the whole screen: the container opens it, reads the
/// detection window, and hands ownership to the child. Detecting in one place
/// and opening in another would mean two `open(2)`s per tap, and on a device
/// each one is a round trip to a daemon that may still be launching.
final class ViewerContainerViewController: TabContentViewController {
    /// Menu entries a child folds into the screen's one menu, above "Open As".
    /// A child sets this rather than adding a second menu button beside this
    /// one: two ellipses in one navigation bar is how a screen ends up with the
    /// same action in two places.
    var childMenuElements: [UIMenuElement] = []
    /// Editors request a visible presenter only when a save/discard prompt is
    /// needed. Closing a clean background tab never needs to display its page.
    var confirmReplacement: ((_ prepareToPresent: () -> Void, _ replace: @escaping () -> Void) -> Void)?

    /// The file on screen. A gallery moves it when the user swipes to another
    /// image (`follow`), and everything the screen does to "this file" reads it.
    private var details: FileDetails
    private let link: any LocalFileAccess
    private var gallery: ImageGallery?
    /// Shown until the child is embedded or the open fails, which are the only
    /// two ways `load()` ends.
    private lazy var status = StatusView(content: .loading(
        String(localized: "Opening…"),
        detail: fileName + " · " + FilePresentation.byteLabel(details.node.size),
    ))
    private var child: UIViewController?
    private var detectedFormat: FileFormat?
    /// What the bytes alone say, without the name — the archive browser for a
    /// ZIP, hex for an OLE compound file, text for RTF. A document opens in
    /// it when it is empty or too large; one WebKit declines does not.
    private var contentFormat: FileFormat = .binary
    private lazy var menuItem: UIBarButtonItem = {
        let item = UIBarButtonItem(image: UIImage(systemName: "ellipsis"), menu: UIMenu())
        item.accessibilityLabel = String(localized: "More")
        return item
    }()

    private var fileName: String {
        (details.path as NSString).lastPathComponent
    }

    init(details: FileDetails, link: any LocalFileAccess, gallery: ImageGallery? = nil) {
        self.details = details
        self.link = link
        self.gallery = gallery
        super.init(nibName: nil, bundle: nil)
        title = fileName
        trailingNavigationItems = [menuItem]
        menuItem.isEnabled = false
        // The file's folder, then the file: a crumb on the folder goes back
        // to its browser. A snapshot of a remote file is given its share's
        // decoration by the shell instead, once it is on screen.
        decorationSource = LocalPathDecoration(path: details.path, icon: FilePresentation.image(for: details.node))
    }

    @available(*, unavailable)
    required init?(coder _: NSCoder) {
        fatalError("init(coder:) is not used")
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .systemBackground

        view.addSubview(status)
        status.snp.makeConstraints { make in
            make.edges.equalToSuperview()
        }
    }

    fileprivate func prepare() async {
        loadViewIfNeeded()
        do {
            let file = try await DescriptorFile.open(details.path, link: link)
            let head = try file.read(at: 0, count: FileFormat.detectionByteCount)
            var format = FileFormat.detect(head: head, name: fileName)
            contentFormat = FileFormat.detect(head: head, name: "")
            // A document with nothing in it, or too much to draw, opens as its
            // bytes: an empty `.rtf` is a text file to write in, and a 300 MB
            // `.docx` browses as the archive it is.
            if format == .document, file.byteCount == 0
                || (try? PreviewLimits.validate(byteCount: file.byteCount, format: format)) == nil
            {
                format = contentFormat
            }
            // Detection is a guess from the first bytes and it will eventually
            // be wrong on a jailbroken filesystem. The line says which guess it
            // made, which is the difference between "the editor is broken" and
            // "that plist is not a plist".
            FilaLog.info("open \(details.path) as \(format) (\(details.node.size) bytes)")
            try present(format: format, file: file)
        } catch {
            FilaLog.warning("open \(details.path) failed: \(Self.describe(error))")
            present(failure: error)
        }
    }

    /// A `FilaFailure` in the log's own words, anything else as itself.
    private static func describe(_ error: Error) -> String {
        (error as? FilaFailure).map { FilaLog.describe($0) } ?? "\(error)"
    }

    private func present(format: FileFormat, file: DescriptorFile) throws {
        try PreviewLimits.validate(byteCount: file.byteCount, format: format)
        detectedFormat = format
        // Cleared before the child loads, because the child sets it while its
        // view is being made and clearing afterwards would wipe it.
        childMenuElements = []
        confirmReplacement = nil
        embed(ViewerRegistry.viewer(for: format, details: details, file: file, link: link, gallery: gallery))
        refreshBarItems()
        menuItem.isEnabled = true
    }

    private func present(failure: Error) {
        // Never `localizedDescription`: this is usually a `FilaFailure` from the
        // open, and that type has no `LocalizedError`, so the raw description is
        // "(FilaProtocol.FilaFailure error 1.)" — filling the screen with the
        // one message a user can neither read nor act on.
        let message = FailureMessage.text(for: failure)
        if canChangePermissions(after: failure) {
            present(failurePage: ViewerFailureViewController(
                message: message + "\n\n"
                    + String(localized: "Change the file's permissions in Properties, then open it again."),
                button: String(localized: "Change Permissions…"),
            ) { [weak self] in
                self?.showProperties()
            })
        } else {
            present(failurePage: ViewerFailureViewController(message: message))
        }
    }

    private func present(failurePage: ViewerFailureViewController) {
        childMenuElements = []
        confirmReplacement = nil
        embed(failurePage)
        refreshBarItems()
        menuItem.isEnabled = true
    }

    private func embed(_ controller: UIViewController) {
        status.removeFromSuperview()

        if let child {
            child.willMove(toParent: nil)
            child.view.removeFromSuperview()
            child.removeFromParent()
        }

        child = controller
        addChild(controller)
        view.addSubview(controller.view)
        controller.view.snp.makeConstraints { make in
            make.edges.equalToSuperview()
        }
        controller.didMove(toParent: self)
    }

    /// The child owns the screen's title, its buttons and its refusal to be
    /// left; the container is a frame. A child's own navigation item is never
    /// the one the bar reads, so what it puts there is copied here — and a
    /// child whose buttons change calls this again.
    ///
    /// "Open as" is the container's own, and the escape hatch for when
    /// detection guessed wrong, which on a jailbroken filesystem it eventually
    /// will: an extensionless file whose first bytes happen to be printable is
    /// text until someone says otherwise.
    func refreshBarItems() {
        let item = child?.navigationItem
        navigationItem.title = item?.title ?? fileName
        navigationItem.prompt = nil
        trailingNavigationItems = ((child as? TabContentViewController)?.trailingNavigationItems ?? []) + [menuItem]
        navigationItem.hidesBackButton = item?.hidesBackButton ?? false
        let leadingItems = item?.leftBarButtonItems ?? []
        if let shell, shell.content.visibleTop === self {
            // Compose the child's exit and shell controls in one assignment.
            // Clearing first would remove the prepared Back during viewWillAppear.
            shell.configureSidebarButton(for: self, leadingItems: leadingItems)
        } else if (navigationItem.leftBarButtonItems ?? []) != leadingItems {
            navigationItem.leftBarButtonItems = leadingItems.isEmpty ? nil : leadingItems
        }
        navigationItem.scrollEdgeAppearance = item?.scrollEdgeAppearance
        isModalInPresentation = child?.isModalInPresentation ?? false
        navigationController?.isModalInPresentation = isModalInPresentation

        var choices: [FileFormat] = [.text, .binary, .propertyList, .machO, .archive, .image]
        // Only a name WebKit has a type for: the way back to the page after
        // opening a `.docx` as an archive, or after it fell back to one.
        if FileFormat.documentMIMEType(name: fileName) != nil {
            choices.append(.document)
        }
        let openAs = UIMenu(
            title: String(localized: "Open As"),
            image: UIImage(systemName: "doc.text.magnifyingglass"),
            options: .singleSelection,
            children: choices.map { format in
                UIAction(
                    title: Self.name(of: format),
                    state: format == detectedFormat ? .on : .off,
                ) { [weak self] _ in self?.reopen(as: format) }
            },
        )
        menuItem.menu = UIMenu(
            children: fileMenuElements(presenting: self, additional: childMenuElements + [openAs]) + [settingsMenuElement],
        )
    }

    /// The image viewer swiped to another image in its gallery. The title, the
    /// breadcrumb and the file menu move with it. Until that file's details
    /// arrive — or if they never do — the menu stays off: everything in it
    /// acts on `details`, and that is still the image just left.
    func follow(_ details: FileDetails?, galleryIndex: Int) {
        guard var gallery, gallery.names.indices.contains(galleryIndex) else { return }
        gallery.index = galleryIndex
        self.gallery = gallery
        if let details {
            self.details = details
            decorationSource = LocalPathDecoration(path: details.path, icon: FilePresentation.image(for: details.node))
        } else {
            decorationSource = LocalPathDecoration(path: gallery.path(at: galleryIndex), icon: nil)
        }
        title = child?.title ?? fileName
        refreshBarItems()
        menuItem.isEnabled = details != nil
    }

    /// Nested editors and virtual archive directories use their real file's
    /// container; a staged archive member must never borrow another file.
    func fileMenuElements(presenting presenter: UIViewController, additional: [UIMenuElement] = []) -> [UIMenuElement] {
        let directory = URL(fileURLWithPath: details.path).deletingLastPathComponent().path
        let actions = FileActions(presenter: presenter, directory: directory) { [weak self, weak presenter] in
            guard let self, let presenter, let navigation = navigationController,
                  navigation.topViewController === presenter,
                  let index = navigation.viewControllers.firstIndex(where: { $0 === self }), index > 0 else { return }
            navigation.popToViewController(navigation.viewControllers[index - 1], animated: true)
        }
        let confirmBlock: (@escaping () -> Void) -> Void = { [weak self, weak presenter] action in
            guard let self, menuItem.isEnabled else { return }
            let perform = { [weak self, weak presenter] in
                guard let self, let presenter, let navigation = navigationController,
                      navigation.topViewController === presenter else { return }
                action()
            }
            if let confirm = confirmReplacement {
                confirm({}, perform)
            } else {
                perform()
            }
        }
        return actions.menuElements(
            for: details.path,
            node: details.node,
            additional: additional,
            groupsFileOperations: true,
            // The archive browser offers its own, which can also take a selection.
            offersExtraction: detectedFormat != .archive,
            confirm: confirmBlock,
        )
    }

    /// The document viewer's way out: WebKit declined the file or failed to
    /// draw it. The screen says so and opens nothing else — a `.docx` shown
    /// as the ZIP it is reads as Fila mistaking it for an archive. Open As
    /// stays, for whoever does want the parts, and offers Document again.
    ///
    /// Only from the viewer on screen, and only while nothing else is being
    /// opened: an Open As chosen during the conversion has already replaced
    /// the document, and a failure page landing on top would hide it.
    func documentViewerFailed(from viewer: UIViewController) {
        guard child === viewer, detectedFormat == .document, menuItem.isEnabled else { return }
        FilaLog.info("open \(details.path): WebKit could not display the document")
        detectedFormat = nil
        present(failurePage: ViewerFailureViewController(
            title: String(localized: "Unable to Display This Document"),
            message: String(localized: "iOS could not display this document. To see what is inside it, choose another format under Open As."),
        ))
    }

    /// Whether the open was refused for the file's mode or flags, and
    /// Properties could change them: the daemon changes anything as root,
    /// and without it the app changes only what its own user owns. Not the
    /// daemon refusing the app, which carries no errno.
    private func canChangePermissions(after error: Error) -> Bool {
        guard let failure = error as? FilaFailure,
              failure.systemError == EACCES || failure.systemError == EPERM else { return false }
        return FileSession.shared.hello?.isPrivileged == true || details.node.ownerID == getuid()
    }

    /// Through the same path as Properties in the menu, which reads the
    /// file's details again: the ones this screen holds predate the refusal.
    private func showProperties() {
        guard presentedViewController == nil else { return }
        let directory = URL(fileURLWithPath: details.path).deletingLastPathComponent().path
        FileActions(presenter: self, directory: directory).showProperties(details.path)
    }

    private func reopen(as format: FileFormat) {
        guard format != detectedFormat, menuItem.isEnabled else { return }
        let replace: () -> Void = { [weak self] in self?.open(as: format) }
        if let confirmReplacement {
            confirmReplacement({}, replace)
        } else {
            replace()
        }
    }

    private func open(as format: FileFormat) {
        // Once leaving is approved, keep this editor still until the new
        // descriptor arrives. Open after a possible atomic save so the new
        // viewer sees the replacement inode, never a stale pre-save handle.
        view.endEditing(true)
        view.isUserInteractionEnabled = false
        let buttons = trailingNavigationItems.map { ($0, $0.isEnabled) }
        for (button, _) in buttons {
            button.isEnabled = false
        }
        menuItem.isEnabled = false
        let details = details
        let link = link
        Task { [weak self] in
            defer {
                self?.view.isUserInteractionEnabled = true
                for (button, wasEnabled) in buttons {
                    button.isEnabled = wasEnabled
                }
            }
            do {
                let file = try await DescriptorFile.open(details.path, link: link)
                try self?.present(format: format, file: file)
            } catch {
                self?.presentMessage(String(localized: "Unable to Open This File"), message: FailureMessage.text(for: error))
            }
        }
    }

    private static func name(of format: FileFormat) -> String {
        switch format {
        case .propertyList: String(localized: "Property List")
        case .machO: String(localized: "Mach-O")
        case .archive: String(localized: "Archive")
        case .image: String(localized: "Image")
        case .audio: String(localized: "Audio")
        case .video: String(localized: "Video")
        case .pdf: String(localized: "PDF")
        case .document: String(localized: "Document")
        case .sqlite: String(localized: "Database")
        case .text: String(localized: "Text")
        case .binary: String(localized: "Hex")
        }
    }
}

/// What a viewer shows when the file could not be opened, or when a document
/// could not be drawn. Not a connection failure — those are never surfaced —
/// but a refusal from the kernel, or WebKit declining the document. Only the
/// caller knows whether there is something to do about it, so the button is
/// the caller's.
final class ViewerFailureViewController: TabContentViewController {
    private let heading: String
    private let message: String
    private let button: String?
    private let action: (() -> Void)?

    init(
        title: String = String(localized: "Unable to Open This File"),
        message: String,
        button: String? = nil,
        action: (() -> Void)? = nil,
    ) {
        heading = title
        self.message = message
        self.button = button
        self.action = action
        super.init(nibName: nil, bundle: nil)
    }

    @available(*, unavailable)
    required init?(coder _: NSCoder) {
        fatalError("init(coder:) is not used")
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .systemBackground

        let status = StatusView(content: .message(
            symbol: "exclamationmark.triangle",
            title: heading,
            detail: message,
            button: button,
        ))
        status.action = action
        view.addSubview(status)
        status.snp.makeConstraints { make in
            make.edges.equalToSuperview()
        }
    }
}
