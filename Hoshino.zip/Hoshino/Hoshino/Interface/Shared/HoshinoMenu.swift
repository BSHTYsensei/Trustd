import FilaBackendKit
import FilaBackendUI
import UIKit

@MainActor
enum HoshinoMenu {
    static func groups(_ groups: [UIMenuElement]...) -> [UIMenuElement] {
        groups.filter { !$0.isEmpty }.map { UIMenu(options: .displayInline, children: $0) }
    }

    /// A Go menu: the sidebar's destinations, then Go to Path.
    static func destinations(
        goToPath: @escaping () -> Void,
        open: @escaping (String) -> Void,
        openLocation: ((BackendLocation) -> Void)?,
    ) -> [UIMenuElement] {
        let path = UIAction(title: String(localized: "Go to Path…")) { _ in goToPath() }
        return groups(sidebar(open: open, openLocation: openLocation), [path])
    }

    /// The sidebar's local places and app-wide collections as submenus.
    /// `openLocation` nil leaves out catalogue destinations for a picker
    /// that can only choose a filesystem folder.
    static func sidebar(
        attributes: UIMenuElement.Attributes = [],
        open: @escaping (String) -> Void,
        openLocation: ((BackendLocation) -> Void)?,
    ) -> [UIMenuElement] {
        let places = placeActions(attributes: attributes, open: open, openLocation: openLocation)
        func submenu(_ title: String, _ actions: [UIAction]) -> [UIMenu] {
            actions.isEmpty ? [] : [UIMenu(
                title: title,
                image: compositeIcon(actions.compactMap(\.image)) ?? FilePresentation.image(for: .artwork("folder")),
                children: actions,
            )]
        }
        return submenu(String(localized: "Places"), places)
            + collections(attributes: attributes, open: open)
    }

    /// The exact rows in Go > Places, also used by a long press on the
    /// current breadcrumb. Build at menu-open time so capabilities are fresh.
    static func placeActions(
        attributes: UIMenuElement.Attributes = [],
        open: @escaping (String) -> Void,
        openLocation: ((BackendLocation) -> Void)?,
    ) -> [UIAction] {
        SidebarLocation.orderedDestinations.compactMap { destination in
            switch destination {
            case let .directory(place):
                // A menu cannot wear a badge: the fact goes under the name,
                // where every other explanation in a menu goes.
                UIAction(
                    title: place.title,
                    subtitle: place.isReadOnly ? String(localized: "Read Only") : "",
                    image: preview(for: place),
                    attributes: attributes,
                ) { _ in open(place.path) }
            case let .catalog(catalog):
                root(catalog, attributes: attributes, openLocation: openLocation)
            }
        }
    }

    /// An app-wide catalogue destination, not a filesystem folder.
    private static func root(
        _ root: BackendRoot,
        attributes: UIMenuElement.Attributes,
        openLocation: ((BackendLocation) -> Void)?,
    ) -> UIAction? {
        openLocation.map { openLocation in
            UIAction(title: root.displayName, image: SidebarLocation.image(for: root), attributes: attributes) { _ in
                openLocation(root.location)
            }
        }
    }

    private static func preview(for place: SidebarPlace) -> UIImage? {
        FilePresentation.image(for: place.icon)
    }

    /// A menu row's picture side: a composed icon is drawn at 40 points so it
    /// sits in a menu row the way its siblings do.
    private static let rowIconSide: CGFloat = 40

    /// A submenu's icon composed from what it holds — a square grid of the
    /// first pictures inside it on a rounded tile — so a row that opens a
    /// list says what kind of list, rather than showing the same folder for
    /// Places, Favorites and Recents alike. Exactly three shapes: one
    /// picture fills the tile, nine or more make a 3×3 of the first nine,
    /// and anything between is a 2×2 of the first four — with two or three
    /// pictures the remaining cells stay empty, because a 2×1 or a 3×2 is
    /// a different tile beside its siblings. Nil for an empty list, and the
    /// caller falls back to the plain folder.
    private static func compositeIcon(_ pictures: [UIImage]) -> UIImage? {
        guard !pictures.isEmpty else { return nil }
        let columns = pictures.count == 1 ? 1 : pictures.count >= 9 ? 3 : 2
        let pictures = Array(pictures.prefix(columns * columns))
        let side = rowIconSide
        let inset: CGFloat = 3
        let gap: CGFloat = 2
        let cell = (side - 2 * inset - CGFloat(columns - 1) * gap) / CGFloat(columns)
        let top = inset
        let tile = CGRect(x: 0, y: 0, width: side, height: side)
        // Rendered on every open of the menu (the callers are deferred
        // elements), so the fill resolves for the current appearance.
        let image = UIGraphicsImageRenderer(size: tile.size).image { _ in
            UIColor.secondarySystemFill.setFill()
            UIBezierPath(roundedRect: tile, cornerRadius: side * 0.22).fill()
            for (index, picture) in pictures.enumerated() {
                let box = CGRect(
                    x: inset + CGFloat(index % columns) * (cell + gap),
                    y: top + CGFloat(index / columns) * (cell + gap),
                    width: cell,
                    height: cell,
                )
                // Aspect fit: the artwork is square, but a symbol is not.
                let scale = min(box.width / max(picture.size.width, 1), box.height / max(picture.size.height, 1))
                let size = CGSize(width: picture.size.width * scale, height: picture.size.height * scale)
                picture.draw(in: CGRect(
                    x: box.midX - size.width / 2, y: box.midY - size.height / 2, width: size.width, height: size.height,
                ))
            }
        }
        return image.withRenderingMode(.alwaysOriginal)
    }

    private static func folderIcon(named name: String) -> UIImage? {
        FilePresentation.image(kind: .directory, name: (name as NSString).lastPathComponent)
    }

    /// The favourites as checked folder rows: Go › Favorites and the current
    /// breadcrumb's menu. The list is read when the menu opens, so a change
    /// made since the menu was built is already there.
    static func favoriteItems(
        attributes: UIMenuElement.Attributes = [],
        open: @escaping (String) -> Void,
    ) -> UIDeferredMenuElement {
        folders({ FileSession.shared.favoritePaths }, attributes: attributes, open: open)
    }

    private static func folders(
        _ paths: @escaping @MainActor () -> [String],
        attributes: UIMenuElement.Attributes,
        open: @escaping (String) -> Void,
    ) -> UIDeferredMenuElement {
        UIDeferredMenuElement.uncached { completion in
            Task { @MainActor in
                let session = FileSession.shared
                // After the handshake, which moves favourites that were inside
                // a bootstrap the jailbreak has since replaced.
                await session.ready()
                let decoration = await SystemCapabilities.applications?.decorationLookup() ?? { _ in nil }
                var actions: [UIMenuElement] = []
                for path in paths() {
                    guard let details = try? await session.perform({ try await $0.details(of: path) }),
                          details.node.isNavigable else { continue }
                    let presentation = decoration(path)
                    var image = FilePresentation.image(for: details.node)
                    if let identifier = presentation?.applicationIdentifier,
                       let artwork = SystemCapabilities.applicationArtwork
                    {
                        image = await artwork.icon(for: identifier) ?? image
                    }
                    let name = presentation?.name ?? (path == "/" ? "/" : (path as NSString).lastPathComponent)
                    actions.append(UIAction(
                        title: name,
                        subtitle: path,
                        image: image,
                        attributes: attributes,
                    ) { _ in open(path) })
                }
                completion(actions)
            }
        }
    }

    static func collections(attributes: UIMenuElement.Attributes = [], open: @escaping (String) -> Void) -> [UIMenu] {
        let session = FileSession.shared
        let mounts = UIDeferredMenuElement.uncached { completion in
            Task { @MainActor in
                let mounts = await (try? FileSession.shared.perform { try await $0.mountPoints() }) ?? []
                completion(mounts.map { mount in
                    let name = mount.path == "/"
                        ? String(localized: "Root")
                        : (mount.path as NSString).lastPathComponent
                    return UIAction(
                        title: name,
                        subtitle: mount.path,
                        image: UIImage(named: "FileIcons/drive-internal")?.withRenderingMode(.alwaysOriginal),
                        attributes: attributes,
                    ) { _ in open(mount.path) }
                })
            }
        }
        let folder = FilePresentation.image(for: .artwork("folder"))
        let drive = FilePresentation.image(for: .artwork("drive-internal"))
        let favorites = session.favoritePaths
        let recents = session.recentPaths(limit: 8)
        // As the sidebar: an empty list is no row, and a sandboxed process
        // has no mount table to show.
        var menus: [UIMenu] = []
        if !favorites.isEmpty {
            menus.append(UIMenu(
                title: String(localized: "Favorites"),
                image: compositeIcon(favorites.compactMap(folderIcon(named:))) ?? folder,
                children: [favoriteItems(attributes: attributes, open: open)],
            ))
        }
        if let backend = session.hello?.backend, backend != .local(reach: .container) {
            menus.append(UIMenu(
                // The mounts are listed when the menu opens; the tile says
                // "volumes" with the drive picture, four up.
                title: String(localized: "Mount Points"),
                image: compositeIcon(Array(repeating: drive, count: 4).compactMap(\.self)) ?? drive,
                children: [mounts],
            ))
        }
        if !recents.isEmpty {
            menus.append(UIMenu(
                title: String(localized: "Recents"),
                image: compositeIcon(recents.compactMap(folderIcon(named:))) ?? folder,
                children: [folders({ recents }, attributes: attributes, open: open)],
            ))
        }
        return menus
    }

    /// Palettes suit a small set of mutually exclusive, recognizable icons.
    /// Keep the same action titles and selection state on older systems.
    static func selection(title: String, actions: [UIAction]) -> UIMenu {
        var options: UIMenu.Options = [.displayInline, .singleSelection]
        if #available(iOS 17.0, *) {
            options.insert(.displayAsPalette)
        }
        return UIMenu(title: title, options: options, children: actions)
    }
}
