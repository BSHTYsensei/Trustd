import FilaBackendKit
import FilaBackendUI
import FilaProtocol
import SnapKit
import Then
import UIKit

/// A shared fixed-icon row for files, sidebar destinations and applications.
///
/// The image always owns a 30pt square, independent of artwork or Dynamic Type.
/// File rows can also put their size in a separate right-aligned column.
final class IconRowCell: UICollectionViewListCell {
    /// The type icon, and the seam a thumbnail arrives through.
    ///
    /// `configure` resets it before the caller installs any cached thumbnail.
    let iconView = UIImageView()

    /// The corner mark that says "this row is a symlink".
    ///
    /// It exists because the icon no longer says so: a link draws its target's
    /// picture, so without this a link to a PNG and the PNG itself are the same
    /// row. Drawn over the icon rather than in a column of its own — a column
    /// would be a second thing to scan on every line for a fact that matters on
    /// one line in twenty. Finder's own alias arrow, laid over the whole icon:
    /// the artwork already sits in the bottom-left corner of a full canvas, so
    /// it lands where a Mac user expects it without any placement of its own.
    private let linkBadge = UIImageView()
    private let appBadge = UIImageView()
    private let favoriteBadge = UIImageView()
    /// A read-only volume's mark. It shares the favourite's corner because a
    /// mount row is never a favourite row — favourites are paths, a mount is a
    /// volume — and a lock is what a person reads as "you cannot write here".
    private let readOnlyBadge = UIImageView()

    private let nameLabel = UILabel()
    private let detailLabel = UILabel()
    private let sizeLabel = UILabel()
    private let textStack = UIStackView()
    private let rowStack = UIStackView()
    private var stacksSize = false

    /// Identifies the artwork load in flight, so a cell reused mid-fetch never
    /// ends up showing the previous row's app.
    private var iconToken = UUID()
    private var thumbnailTask: Task<Void, Never>?

    override init(frame: CGRect) {
        super.init(frame: frame)
        build()
    }

    @available(*, unavailable)
    required init?(coder _: NSCoder) {
        fatalError("not supported")
    }

    override func prepareForReuse() {
        super.prepareForReuse()
        thumbnailTask?.cancel()
        iconToken = UUID()
    }

    deinit { thumbnailTask?.cancel() }

    // MARK: - Hierarchy

    /// Big enough to read at a glance on the corner of a 30pt icon, small
    /// enough not to be the picture.
    private static let badgeSize: CGFloat = 12

    private func build() {
        iconView.do {
            $0.contentMode = .scaleAspectFit
            $0.tintColor = .secondaryLabel
            $0.preferredSymbolConfiguration = UIImage.SymbolConfiguration(pointSize: FilaUI.IconSize.inline)
            $0.setContentHuggingPriority(.required, for: .horizontal)
            // The picture and its corner marks are what the row's label
            // already says in words; VoiceOver never stops on them.
            $0.isAccessibilityElement = false
        }

        linkBadge.do {
            $0.image = UIImage(named: "FileIcons/alias")?.withRenderingMode(.alwaysOriginal)
            $0.contentMode = .scaleAspectFit
        }
        iconView.addSubview(linkBadge)

        favoriteBadge.do {
            $0.image = FilePresentation.image(for: .artwork("favorite"))
            $0.contentMode = .scaleAspectFit
        }
        iconView.addSubview(favoriteBadge)

        readOnlyBadge.do {
            $0.image = FilePresentation.image(for: .artwork("read-only"))
            $0.contentMode = .scaleAspectFit
        }
        iconView.addSubview(readOnlyBadge)

        appBadge.do {
            $0.contentMode = .scaleAspectFit
            $0.backgroundColor = .systemBackground
            $0.layer.cornerRadius = 4
            $0.clipsToBounds = true
        }
        iconView.addSubview(appBadge)

        for badge in [linkBadge, appBadge, favoriteBadge, readOnlyBadge] {
            badge.isAccessibilityElement = false
        }

        nameLabel.do {
            $0.font = .preferredFont(forTextStyle: .body)
            $0.adjustsFontForContentSizeCategory = true
            // Middle rather than tail: on this filesystem the extension is half of
            // what identifies a file, and a reversed-domain name is the other half.
            $0.lineBreakMode = .byTruncatingMiddle
            $0.setContentCompressionResistancePriority(.defaultLow, for: .horizontal)
        }

        for label in [detailLabel, sizeLabel] {
            label.font = .preferredFont(forTextStyle: .footnote)
            label.adjustsFontForContentSizeCategory = true
            label.textColor = .secondaryLabel
        }
        detailLabel.do {
            $0.lineBreakMode = .byTruncatingMiddle
            $0.setContentCompressionResistancePriority(.defaultLow, for: .horizontal)
        }
        sizeLabel.do {
            $0.textAlignment = .right
            // The name gives way, the size never does: a size that ellipsises is
            // not a size, and it is one short word beside a name that may be sixty
            // characters long.
            $0.setContentCompressionResistancePriority(.required, for: .horizontal)
            $0.setContentHuggingPriority(.required, for: .horizontal)
        }

        textStack.do {
            $0.addArrangedSubview(nameLabel)
            $0.addArrangedSubview(detailLabel)
            $0.axis = .vertical
            $0.spacing = 1
            $0.alignment = .leading
        }

        rowStack.do {
            $0.addArrangedSubview(iconView)
            $0.addArrangedSubview(textStack)
            $0.addArrangedSubview(sizeLabel)
            $0.axis = .horizontal
            $0.alignment = .center
            $0.spacing = FilaUI.Spacing.medium
        }
        contentView.addSubview(rowStack)
        applyContentSizeCategory()

        iconView.snp.makeConstraints { make in
            make.size.equalTo(FilaUI.IconSize.file)
        }
        linkBadge.snp.makeConstraints { make in
            // The arrow sits in the artwork's bottom-left corner, so scaling the
            // whole canvas from that corner enlarges the arrow and leaves it put.
            // At 1× it is unreadable on a phone.
            make.width.height.equalTo(iconView).multipliedBy(2)
            make.leading.bottom.equalTo(iconView)
        }
        favoriteBadge.snp.makeConstraints { make in
            make.size.equalTo(Self.badgeSize)
            make.leading.bottom.equalTo(iconView)
        }
        readOnlyBadge.snp.makeConstraints { make in
            make.size.equalTo(Self.badgeSize)
            make.leading.bottom.equalTo(iconView)
        }
        appBadge.snp.makeConstraints { make in
            make.width.equalTo(iconView).multipliedBy(0.55)
            make.height.equalTo(appBadge.snp.width)
            make.trailing.bottom.equalTo(iconView)
        }
        rowStack.snp.makeConstraints { make in
            make.edges.equalTo(contentView.layoutMarginsGuide)
        }
        // Without this the separator starts under the icon, because a cell
        // with a custom content view has nothing else to measure from.
        separatorLayoutGuide.snp.makeConstraints { make in
            make.leading.equalTo(nameLabel)
        }
        // One element: the row is one sentence — name, then what the second
        // line and the size column say — and `configure` writes it. Without
        // this the sentence is walked past and each label is a stop of its
        // own, the size read twice over once it joins the sentence. The
        // Properties accessory goes under this too, so `showProperties`
        // hands that button back as a custom action.
        isAccessibilityElement = true
        accessibilityTraits = .button
    }

    override func traitCollectionDidChange(_ previousTraitCollection: UITraitCollection?) {
        super.traitCollectionDidChange(previousTraitCollection)
        applyContentSizeCategory()
    }

    /// At the accessibility text sizes a name and a size no longer fit side
    /// by side: the required size column took the width and the name was
    /// left a few letters. There the size goes under the name, and the name
    /// and its detail wrap instead of truncating.
    private func applyContentSizeCategory() {
        let stacks = traitCollection.preferredContentSizeCategory.isAccessibilityCategory
        nameLabel.numberOfLines = stacks ? 0 : 1
        detailLabel.numberOfLines = stacks ? 0 : 1
        guard stacks != stacksSize else { return }
        stacksSize = stacks
        if stacks {
            textStack.addArrangedSubview(sizeLabel)
        } else {
            rowStack.addArrangedSubview(sizeLabel)
        }
        sizeLabel.textAlignment = stacks ? .natural : .right
    }

    // MARK: - Content

    func configure(
        name: String,
        detail: String? = nil,
        image: UIImage?,
        nameColor: UIColor = .label,
        tintColor: UIColor = .secondaryLabel,
        highlight: String? = nil,
    ) {
        nameLabel.textColor = nameColor
        let visibleName = FilePresentation.visibleName(name)
        // A search hit tints the part that matched, the way a mention is
        // tinted: the text itself is left exactly as it is, so a list of
        // near-identical names says why each one is there. The range is
        // found in the real name; the visible one has the same UTF-16 length.
        if let highlight, !highlight.isEmpty,
           let range = name.range(of: highlight, options: [.caseInsensitive, .diacriticInsensitive])
        {
            let text = NSMutableAttributedString(string: visibleName, attributes: [.foregroundColor: nameColor])
            text.addAttribute(.foregroundColor, value: UIColor.tintColor, range: NSRange(range, in: name))
            nameLabel.attributedText = text
        } else {
            nameLabel.text = visibleName
        }
        detailLabel.text = detail
        detailLabel.isHidden = detail?.isEmpty != false
        sizeLabel.text = nil
        sizeLabel.isHidden = true
        iconView.showIcon(image)
        iconView.tintColor = tintColor
        iconView.alpha = 1
        linkBadge.isHidden = true
        appBadge.isHidden = true
        favoriteBadge.isHidden = true
        readOnlyBadge.isHidden = true
        thumbnailTask?.cancel()
        iconToken = UUID()
        accessories = [.disclosureIndicator()]
        // The accessories are rebuilt here, so the actions that stand in for
        // them go too: a reused cell must not keep the previous row's.
        accessibilityCustomActions = nil
        accessibilityLabel = [name, detail].compactMap(\.self).joined(separator: ", ")
    }

    func showProperties(action: @escaping () -> Void) {
        let title = String(localized: "Properties")
        let button = UIButton(type: .infoLight).then {
            $0.accessibilityLabel = title
            $0.addAction(UIAction { _ in action() }, for: .touchUpInside)
        }
        // UIKit positions the accessory container itself; constraints belong
        // inside it, where they also establish the button's 44-point target.
        let container = UIView()
        container.addSubview(button)
        button.snp.makeConstraints {
            $0.edges.equalToSuperview()
            $0.size.equalTo(FilaUI.minimumTapTarget)
        }
        let info = UICellAccessory.customView(configuration: .init(
            customView: container,
            placement: .trailing(displayed: .whenNotEditing, at: { _ in 0 }),
            reservedLayoutWidth: .custom(FilaUI.minimumTapTarget),
        ))
        accessories.insert(info, at: 1)
        // The row is a single accessibility element, so nothing inside it can
        // be focused: the button would be unreachable. The rotor carries it
        // instead, which is also the only way to reach it under Switch
        // Control on a row that is otherwise one target.
        accessibilityCustomActions = [
            UIAccessibilityCustomAction(name: title) { _ in
                action()
                return true
            },
        ]
    }

    func showFavoriteBadge() {
        favoriteBadge.isHidden = false
    }

    func showReadOnlyBadge() {
        readOnlyBadge.isHidden = false
    }

    /// Application artwork: the row's icon for a bundle, the corner badge for
    /// a container. Cached artwork paints now; the rest arrives from the
    /// applications module and lands only if the cell still shows this row.
    func showApplicationIcon(_ identifier: String?, asBadge: Bool) {
        guard let artwork = SystemCapabilities.applicationArtwork else { return }
        let target = asBadge ? appBadge : iconView
        target.isHidden = false
        let token = UUID()
        iconToken = token
        if let cached = artwork.cachedIcon(for: identifier) {
            target.image = cached
            return
        }
        // A bundle keeps its type artwork until the real icon lands; a badge
        // has nothing else to show.
        if asBadge {
            target.image = artwork.placeholder
        }
        Task { [weak self] in
            let image = await artwork.icon(for: identifier)
            guard let self, iconToken == token else { return }
            target.image = image
        }
    }

    /// A picture of the file itself where one can be made cheaply — see
    /// `FilePresentation.picture`. Lands only if the cell still shows this row.
    func showThumbnail(for path: String, node: FileNode, session: FileSession) {
        guard FilePresentation.canHavePicture(node) else { return }
        let token = UUID()
        iconToken = token
        thumbnailTask?.cancel()
        thumbnailTask = Task { [weak self] in
            let picture = await FilePresentation.picture(for: path, node: node, session: session)
            guard let self, iconToken == token, let picture else { return }
            iconView.show(picture)
        }
    }

    func configure(_ node: FileNode, decoration: FolderDecoration? = nil) {
        let presentation = node.kind == .directory ? decoration : nil
        let image = FilePresentation.image(for: node)
        let name = presentation?.name ?? node.name
        // Both lines can hold a file name — the item's, or a link's target —
        // so the label shows them the way a name is shown; VoiceOver reads
        // them as they are.
        let detail = presentation.map { [$0.detail, node.name].compactMap(\.self).joined(separator: " · ") }
            ?? Self.detail(for: node)
        configure(
            name: name,
            detail: FilePresentation.visibleName(detail),
            image: image,
            nameColor: presentation == nil ? .label : .systemBrown,
        )
        // File rows are always two lines, so a zero-mtime file neither shrinks
        // its row nor shifts the size column.
        detailLabel.isHidden = false
        sizeLabel.text = FilePresentation.sizeLabel(for: node)
        sizeLabel.isHidden = sizeLabel.text?.isEmpty != false
        linkBadge.isHidden = node.kind != .symbolicLink
        if let presentation {
            let isApplication = URL(fileURLWithPath: node.name).pathExtension.lowercased() == "app"
            showApplicationIcon(presentation.applicationIdentifier, asBadge: !isApplication)
        }
        // Hidden files stay legible and stay obviously different, which is what
        // "show hidden" is turned on to see.
        iconView.alpha = node.isHidden ? 0.6 : 1

        accessories = [.multiselect(displayed: .whenEditing)]
        if node.isNavigable {
            accessories.append(.disclosureIndicator(displayed: .whenNotEditing))
        }

        // The alias mark is the one thing the row shows that the words do not:
        // a link wears its target's picture, so without this a link to a PNG
        // and the PNG itself read identically.
        accessibilityLabel = [
            name,
            node.kind == .symbolicLink ? String(localized: "Symbolic Link") : nil,
            sizeLabel.text,
            detail,
        ]
        .compactMap(\.self)
        .filter { !$0.isEmpty }
        .joined(separator: ", ")
    }

    /// The second line: where a link points, or when the item last changed.
    ///
    /// A symlink's target displaces its date because the target is the answer
    /// to the question a link raises, and the row has one line to give.
    private static func detail(for node: FileNode) -> String {
        if node.kind == .symbolicLink, let link = node.link {
            return "→ " + link.target
        }
        return FilePresentation.dateLabel(node.modified)
    }
}
