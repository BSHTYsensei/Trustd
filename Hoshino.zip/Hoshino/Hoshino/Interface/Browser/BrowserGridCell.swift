import FilaBackendKit
import FilaBackendUI
import FilaProtocol
import SnapKit
import Then
import UIKit

/// The grid cell: a thumbnail where one can be made, the icon otherwise.
final class BrowserGridCell: UICollectionViewCell {
    private let image = UIImageView()
    private let appBadge = UIImageView()
    private let label = UILabel()
    /// Identifies the load in flight, so a cell that was reused mid-read does
    /// not end up showing the previous file's thumbnail.
    private var token = UUID()
    private var thumbnailTask: Task<Void, Never>?

    override init(frame: CGRect) {
        super.init(frame: frame)
        appBadge.do {
            $0.contentMode = .scaleAspectFit
            $0.backgroundColor = .systemBackground
            $0.layer.cornerRadius = 6
            $0.clipsToBounds = true
        }
        image.addSubview(appBadge)
        image.isAccessibilityElement = false
        appBadge.isAccessibilityElement = false
        label.do {
            $0.font = .preferredFont(forTextStyle: .footnote)
            $0.adjustsFontForContentSizeCategory = true
            $0.textAlignment = .center
            $0.numberOfLines = 2
            $0.lineBreakMode = .byTruncatingMiddle
        }
        contentView.addSubview(image)
        contentView.addSubview(label)
        image.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(6)
            make.centerX.equalToSuperview()
            make.width.equalTo(64)
            make.height.equalTo(image.snp.width)
        }
        appBadge.snp.makeConstraints { make in
            make.width.equalTo(image).multipliedBy(0.55)
            make.height.equalTo(appBadge.snp.width)
            make.trailing.bottom.equalTo(image)
        }
        label.snp.makeConstraints { make in
            make.top.equalTo(image.snp.bottom).offset(FilaUI.Spacing.compact)
            make.leading.equalToSuperview().offset(2)
            make.trailing.equalToSuperview().offset(-2)
        }
        // One element: the tile is a picture and its name, and `configure`
        // writes the sentence. Without this the cell's own label is never
        // read — the name label under the icon is what VoiceOver stops on.
        isAccessibilityElement = true
        accessibilityTraits = .button
    }

    @available(*, unavailable)
    required init?(coder _: NSCoder) {
        fatalError("not supported")
    }

    override func prepareForReuse() {
        super.prepareForReuse()
        thumbnailTask?.cancel()
        token = UUID()
    }

    deinit { thumbnailTask?.cancel() }

    override var isSelected: Bool {
        didSet {
            contentView.backgroundColor = isSelected ? .systemFill : nil
            // The fill is the only thing that says "picked" in the grid, and
            // a custom element gets no selected state from UIKit.
            accessibilityTraits = isSelected ? [.button, .selected] : [.button]
        }
    }

    func configure(node: FileNode, path: String, session: FileSession, decoration: FolderDecoration? = nil) {
        thumbnailTask?.cancel()
        let presentation = node.kind == .directory ? decoration : nil
        label.text = presentation.map {
            [$0.name, $0.detail].compactMap(\.self).map(FilePresentation.visibleName).joined(separator: "\n")
        } ?? FilePresentation.visibleName(node.name)
        label.textColor = presentation == nil ? .label : .systemBrown
        let isApplication = presentation != nil && URL(fileURLWithPath: node.name).pathExtension.lowercased() == "app"
        appBadge.isHidden = presentation == nil || isApplication
        accessibilityLabel = [presentation?.name, presentation?.detail, node.name]
            .compactMap(\.self)
            .joined(separator: ", ")
        image.showIcon(FilePresentation.image(for: node))
        image.alpha = node.isHidden ? 0.5 : 1
        contentView.layer.cornerRadius = 8
        contentView.clipsToBounds = true

        let token = UUID()
        self.token = token
        if let presentation, let artwork = SystemCapabilities.applicationArtwork {
            // Same seam as the thumbnail: cached artwork now, the rest later,
            // and only onto the cell that is still showing this node.
            let target = isApplication ? image : appBadge
            if let cached = artwork.cachedIcon(for: presentation.applicationIdentifier) {
                target.image = cached
            } else {
                if !isApplication {
                    appBadge.image = artwork.placeholder
                }
                Task { [weak self] in
                    let icon = await artwork.icon(for: presentation.applicationIdentifier)
                    guard let self, self.token == token else { return }
                    target.image = icon
                }
            }
        }
        guard FilePresentation.canHavePicture(node) else { return }
        thumbnailTask = Task { [weak self] in
            let picture = await FilePresentation.picture(for: path, node: node, session: session)
            guard let self, self.token == token, let picture else { return }
            image.show(picture)
        }
    }
}
