import AlertController
import FilaBackendUI
import UIKit

/// User flags are edited together and applied once; system-only bits are retained.
final class FileFlagsEditorViewController: TabContentTableViewController {
    static let flags: [(label: String, mask: UInt32)] = [
        (String(localized: "Locked (uchg)"), UInt32(UF_IMMUTABLE)),
        (String(localized: "Append Only (uappnd)"), UInt32(UF_APPEND)),
        (String(localized: "Hidden (hidden)"), UInt32(UF_HIDDEN)),
        (String(localized: "No Dump (nodump)"), UInt32(UF_NODUMP)),
    ]
    private let originalFlags: UInt32
    private var flags: UInt32
    private let appliesRecursively: Bool
    private let apply: (UInt32) -> Void

    init(flags: UInt32, appliesRecursively: Bool = false, apply: @escaping (UInt32) -> Void) {
        originalFlags = flags
        self.flags = flags
        self.appliesRecursively = appliesRecursively
        self.apply = apply
        super.init(style: .insetGrouped)
        title = String(localized: "Flags")
        trailingNavigationItems = [UIBarButtonItem(
            image: UIImage(systemName: "checkmark"),
            primaryAction: UIAction { [weak self] _ in
                guard let self else { return }
                // `self.` on both: inside the initializer the bare names are
                // its parameters, so `flags` would be the word the editor
                // opened with and every toggle would apply as no change.
                self.commitChanges()
            },
        )]
        navigationItem.rightBarButtonItem?.accessibilityLabel = String(localized: "Apply")
    }

    private func commitChanges() {
        let immutable = UInt32(UF_IMMUTABLE)
        let wasLocked = originalFlags & immutable != 0
        let willBeLocked = flags & immutable != 0
        guard wasLocked != willBeLocked else {
            applyAndClose()
            return
        }

        let title = willBeLocked
            ? String(localized: "Lock Item?")
            : String(localized: "Unlock Item?")
        let explanation = willBeLocked
            ? String(localized: "Locking sets the BSD UF_IMMUTABLE flag. The file system will reject writes, renames, moves, and deletion until it is unlocked.")
            : String(localized: "Unlocking clears UF_IMMUTABLE. Normal filesystem permissions apply again.")
        let recursiveNote = appliesRecursively
            ? "\n\n" + String(localized: "For a directory, this operation also visits descendants. Symbolic links are not followed; shared hard-linked files may be skipped.")
            : ""
        let actionTitle = willBeLocked ? String(localized: "Lock") : String(localized: "Unlock")
        let alert = AlertViewController(title: .init(title), message: .init(explanation + recursiveNote)) { [weak self] context in
            context.allowSimpleDispose()
            context.addAction(title: String.LocalizationValue("Cancel")) {
                context.dispose()
            }
            context.addAction(title: .init(actionTitle), attribute: .accent) {
                context.dispose { self?.applyAndClose() }
            }
        }
        present(alert, animated: true)
    }

    private func applyAndClose() {
        apply(flags)
        navigationController?.popViewController(animated: true)
    }

    @available(*, unavailable)
    required init?(coder _: NSCoder) {
        fatalError("init(coder:) is not used")
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        tableView.reloadWithAnimation()
    }

    override func tableView(_: UITableView, numberOfRowsInSection _: Int) -> Int {
        Self.flags.count
    }

    override func tableView(_: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = UITableViewCell(style: .default, reuseIdentifier: nil)
        let flag = Self.flags[indexPath.row]
        var content = UIListContentConfiguration.cell()
        content.text = flag.label
        content.textProperties.numberOfLines = 0
        cell.contentConfiguration = content
        cell.selectionStyle = .none
        let toggle = UISwitch()
        toggle.isOn = flags & flag.mask != 0
        toggle.accessibilityLabel = flag.label
        toggle.addAction(UIAction { [weak self, weak toggle] _ in
            guard let self, let toggle else { return }
            flags = toggle.isOn ? flags | flag.mask : flags & ~flag.mask
        }, for: .valueChanged)
        cell.accessoryView = toggle
        return cell
    }
}
