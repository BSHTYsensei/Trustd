import FilaBackendKit
import FilaLog
import Foundation

extension Notification.Name {
    /// A preference changed somewhere other than the screen that renders it —
    /// in practice, the settings screen. Browsers re-read their layout and
    /// re-apply their snapshot; a modal settings screen never triggers the
    /// presenting controller's appearance callbacks, so there is nothing else
    /// that would tell them.
    static let filaPreferencesChanged = Notification.Name("com.hoshino.filemanager.preferences")
}

/// Where the browser opens on launch. `AppPreferences.launchDirectory` resolves
/// it — the value is a choice; what was last visited is the local backend's.
///
/// Stored as one string, and a folder stores its own absolute path. The three
/// fixed answers are words and a folder is a path, so the two can never be
/// confused for one another and no second defaults key has to be kept in step
/// with this one.
enum LaunchLocation: RawRepresentable, Equatable {
    case root
    case home
    case lastVisited
    case folder(String)

    init?(rawValue: String) {
        switch rawValue {
        case "root": self = .root
        case "home": self = .home
        case "lastVisited": self = .lastVisited
        default:
            guard rawValue.hasPrefix("/") else { return nil }
            self = .folder(rawValue)
        }
    }

    var rawValue: String {
        switch self {
        case .root: "root"
        case .home: "home"
        case .lastVisited: "lastVisited"
        case let .folder(path): path
        }
    }
}

/// What the app itself remembers between launches: switches that are the
/// app's policy rather than any one backend's. Bookmarks, history and listing
/// options belong to the backend they describe — see `LocalFileBackend`.
///
/// `UserDefaults` rather than a store of our own: it is a handful of switches
/// and a few strings, it has to survive a respring, and nothing here is worth a
/// file format.
@MainActor
final class AppPreferences {
    static let shared = AppPreferences()

    private let defaults = UserDefaults.standard

    private init() {}

    // MARK: - Browsing

    var launchLocation: LaunchLocation {
        get { defaults.string(forKey: "launchLocation").flatMap(LaunchLocation.init) ?? .lastVisited }
        set { defaults.set(newValue.rawValue, forKey: "launchLocation") }
    }

    /// Where the browser opens.
    ///
    /// `/var/mobile` rather than `NSHomeDirectory()`: the app's own container
    /// is the one directory a root file manager's user is *not* looking for.
    /// Checked rather than assumed, because the Mac development loop has no
    /// such directory and launching into one the daemon cannot list would look
    /// like the daemon being broken.
    var launchDirectory: String {
        let session = FileSession.shared
        if case .local(.container) = session.hello?.backend {
            // A restored external path may have lost its temporary grant.
            // Start at the sandboxed backend's own root; explicit navigation
            // can still ask for other paths and receive the real permission
            // error.
            return session.local.rootPath
        }
        switch launchLocation {
        case .root: return session.local.rootPath
        case .home: return FileManager.default.fileExists(atPath: "/var/mobile") ? "/var/mobile" : session.local.rootPath
        case .lastVisited: return session.lastDirectoryPath
        // Not checked for existence: `mobile` cannot stat every directory root
        // can open, so a check would refuse exactly the folders this file
        // manager exists for. A folder that really is gone fails in the
        // browser, where the error says which path and why.
        case let .folder(path): return path
        }
    }

    // MARK: - File operations

    /// The regular delete action follows this choice; items already in the trash
    /// are always deleted permanently.
    var usesTrash: Bool {
        get { defaults.object(forKey: "usesTrash") as? Bool ?? true }
        set { defaults.set(newValue, forKey: "usesTrash") }
    }

    /// Text viewer: soft-wrap long lines. Off is what a log or a minified
    /// file wants; on is what everything else wants.
    var wrapsLines: Bool {
        get { defaults.object(forKey: "wrapsLines") as? Bool ?? true }
        set { defaults.set(newValue, forKey: "wrapsLines") }
    }

    /// Text viewer: colour by grammar. Off reads a file as plain text.
    var highlightsSyntax: Bool {
        get { defaults.object(forKey: "highlightsSyntax") as? Bool ?? true }
        set { defaults.set(newValue, forKey: "highlightsSyntax") }
    }

    // MARK: - Scripts

    /// On by default, because a script written `#!/bin/sh` is every script and
    /// a rootless device has no `/bin/sh` — off, the kernel refuses it and the
    /// user sees a file that will not run. Off is for the case where honouring
    /// the line is wrong: a script that means the system's own interpreter,
    /// on a bootstrap that ships a different one under the same name.
    var redirectsScriptInterpreters: Bool {
        get { defaults.object(forKey: "redirectsScriptInterpreters") as? Bool ?? true }
        set { defaults.set(newValue, forKey: "redirectsScriptInterpreters") }
    }

    // MARK: - History policy

    /// Whether visits are recorded at all. On by default — the list is the
    /// point of having one — but this is a root file manager, so the trail it
    /// leaves is a list of every sensitive directory its user opened, sitting
    /// in a plist any other root process can read. That is a reason to be able
    /// to say no.
    ///
    /// One policy for every backend: each records its own history and this
    /// switch reaches all of them, offline ones included. Turning it off
    /// clears what is already there — a switch that stops adding but leaves
    /// the history behind has not done what its label says.
    var recordsRecents: Bool {
        get { defaults.object(forKey: "recordsRecents") as? Bool ?? true }
        set {
            defaults.set(newValue, forKey: "recordsRecents")
            for backend in BackendComposition.fileBackends {
                do { try backend.setRecordsVisits(newValue) }
                catch { FilaLog.error("history policy not applied to \(backend.id): \(error)") }
            }
        }
    }
}
