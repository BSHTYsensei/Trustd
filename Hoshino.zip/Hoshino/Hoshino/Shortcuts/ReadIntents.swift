import AppIntents
import FilaProtocol
import Foundation

// The Shortcuts actions that read and navigate.
//
// These have exactly the safety profile of the `fila://` scheme — they look at
// the filesystem and they move the app around in it — and the three that
// navigate *are* the scheme: they hand a `fila://` URL back to the app rather
// than reaching into the view hierarchy, so a link and a shortcut cannot drift
// apart about what "reveal" means. Everything that changes the filesystem is
// in `WriteIntents.swift`, behind a confirmation, and is deliberately not
// spellable as a URL.
//
// Every one of them reaches the filesystem through `filad`. There is no
// `FileManager` in this file and there must not be: the app runs as `mobile`
// and would answer questions about a filesystem the user is not looking at.

// MARK: - Navigate

// The three below are the only ones that leave a trail, and they leave exactly
// the trail a tap does. Merely navigating to a directory does not record it:
// the browser records explicit use or backgrounding while it is current. These
// all set `openAppWhenRun`; `recordsRecents` applies to links and shortcuts alike.
//
// Nothing else in this file records anything. A shortcut that lists a folder or
// reads a file at three in the morning shows no browser and touches no
// preference — which is the honest answer, because nobody visited anything.

@available(iOS 16.0, *)
struct OpenPathIntent: AppIntent {
    static var title: LocalizedStringResource = "Open in Hoshino"
    static var description = IntentDescription("Opens a folder — or the folder holding a file — in Hoshino.")
    static var openAppWhenRun: Bool {
        true
    }

    @Parameter(title: "Path", default: "/")
    var path: String

    static var parameterSummary: some ParameterSummary {
        Summary("Open \(\.$path) in Hoshino")
    }

    @MainActor
    func perform() async throws -> some IntentResult {
        try await IntentSupport.navigate("open", ["path": IntentSupport.path(path)])
        return .result()
    }
}

@available(iOS 16.0, *)
struct RevealItemIntent: AppIntent {
    static var title: LocalizedStringResource = "Reveal in Hoshino"
    static var description = IntentDescription("Opens the folder that contains this item and selects it.")
    static var openAppWhenRun: Bool {
        true
    }

    @Parameter(title: "Path")
    var path: String

    static var parameterSummary: some ParameterSummary {
        Summary("Reveal \(\.$path) in Hoshino")
    }

    @MainActor
    func perform() async throws -> some IntentResult {
        try await IntentSupport.navigate("reveal", ["path": IntentSupport.path(path)])
        return .result()
    }
}

// MARK: - Inspect

@available(iOS 16.0, *)
struct GetItemPropertiesIntent: AppIntent {
    static var title: LocalizedStringResource = "Get File Info"
    static var description = IntentDescription(
        "Reads an item's size, dates, permissions and owner, as root.",
    )

    @Parameter(title: "Path")
    var path: String

    static var parameterSummary: some ParameterSummary {
        Summary("Get info about \(\.$path)")
    }

    @MainActor
    func perform() async throws -> some IntentResult & ReturnsValue<FileEntity> {
        try await .result(value: FileEntity(IntentSupport.details(of: IntentSupport.path(path))))
    }
}

@available(iOS 16.0, *)
struct ListDirectoryIntent: AppIntent {
    static var title: LocalizedStringResource = "List Folder"
    static var description = IntentDescription("Lists the contents of a folder for use in other Hoshino actions.")

    @Parameter(title: "Folder", default: "/")
    var path: String

    @Parameter(title: "Include Hidden Items", default: false)
    var includesHidden: Bool

    static var parameterSummary: some ParameterSummary {
        Summary("List \(\.$path)") {
            \.$includesHidden
        }
    }

    @MainActor
    func perform() async throws -> some IntentResult & ReturnsValue<[FileEntity]> {
        let directory = try IntentSupport.path(path)
        let session = try await IntentSupport.session()
        var entries: [FileEntity] = []
        try await IntentSupport.mapping {
            for try await page in DirectoryReader.pages(in: directory, session: session) {
                for node in page where includesHidden || !node.isHidden {
                    entries.append(FileEntity(directory: directory, node: node))
                }
                // Refused rather than cut short: a shortcut cannot tell a capped
                // list from a complete one, and a script that believes it has
                // seen every file in a folder will act on that belief.
                guard entries.count <= IntentSupport.listEntryLimit else {
                    throw IntentFailure.tooManyEntries(directory)
                }
            }
        }
        return .result(value: entries)
    }
}

@available(iOS 16.0, *)
struct FindFilesIntent: AppIntent {
    static var title: LocalizedStringResource = "Find Files"
    static var description = IntentDescription(
        "Searches a folder and its subfolders for names containing the text you enter.",
    )

    @Parameter(title: "Name Contains")
    var query: String

    @Parameter(title: "Starting Folder", default: "/")
    var path: String

    /// The bound has to be a literal here, and stays under
    /// `FileSearch.resultLimit` — `perform` clamps to it as well, so the two
    /// cannot drift into a shortcut asking for more than the walk will ever
    /// produce.
    @Parameter(title: "Maximum Results", default: 100, inclusiveRange: (1, 100))
    var limit: Int

    static var parameterSummary: some ParameterSummary {
        Summary("Find \(\.$query) in \(\.$path)") {
            \.$limit
        }
    }

    @MainActor
    func perform() async throws -> some IntentResult & ReturnsValue<[FileEntity]> {
        let root = try IntentSupport.path(path)
        let needle = query.trimmingCharacters(in: .whitespacesAndNewlines)
        guard HoshinoLink.isPlausibleQuery(needle) else { throw IntentFailure.invalidSearch(query) }
        let session = try await IntentSupport.session()

        // The same walk the search screen runs — breadth-first, in the app,
        // over listings the daemon paged out — stopped as soon as it has found
        // what the shortcut asked for, so "find one thing below `/`" does not
        // cost a full search.
        let wanted = min(limit, FileSearch.resultLimit)
        var found: [FileEntity] = []
        await FileSearch.run(root: root, needle: needle, session: session, limit: wanted) { _ in } onHit: { hit in
            found.append(FileEntity(directory: hit.directory, node: hit.node))
        }
        return .result(value: found)
    }
}

@available(iOS 16.0, *)
struct ReadTextFileIntent: AppIntent {
    static var title: LocalizedStringResource = "Get Text from File"
    static var description = IntentDescription(
        "Reads a text file as root and returns its contents.",
    )

    @Parameter(title: "Path")
    var path: String

    static var parameterSummary: some ParameterSummary {
        Summary("Get text from \(\.$path)")
    }

    @MainActor
    func perform() async throws -> some IntentResult & ReturnsValue<String> {
        let path = try IntentSupport.path(path)
        let details = try await IntentSupport.details(of: path)
        // A directory read as text is not an empty string, and a device node
        // read as text can block forever. Only a regular file — or a link that
        // resolves to one — is a file to read.
        let kind = details.node.link?.resolvedKind ?? details.node.kind
        guard kind == .regular else { throw IntentFailure.notAFile(path) }

        // One byte past the ceiling, so a file that is exactly too big is
        // refused rather than silently handed over short.
        let session = try await IntentSupport.session()
        let data = try await IntentSupport.mapping {
            try await session.read(path, limit: IntentSupport.textByteLimit + 1)
        }
        guard data.count <= IntentSupport.textByteLimit else { throw IntentFailure.tooLarge(path) }
        guard let text = String(data: data, encoding: .utf8) else { throw IntentFailure.notText(path) }
        return .result(value: text)
    }
}
