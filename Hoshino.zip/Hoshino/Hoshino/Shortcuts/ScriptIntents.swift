import AppIntents
import Foundation

@available(iOS 16.0, *)
struct RunScriptIntent: AppIntent {
    static var title: LocalizedStringResource = "Run Script in Hoshino"
    static var description = IntentDescription(
        "Runs a supported script file as the current app user. It does not run as root. Only run scripts you trust.",
    )
    static var openAppWhenRun = true

    @Parameter(title: "Script Path")
    var path: String

    static var parameterSummary: some ParameterSummary {
        Summary("Run script at \(\.$path)")
    }

    @MainActor
    func perform() async throws -> some IntentResult & ReturnsValue<String> {
        let canonicalPath = try IntentSupport.path(path)
        let sourceURL = URL(fileURLWithPath: canonicalPath).standardizedFileURL
        // App-container scripts must work in the sandboxed IPA too; only paths
        // that the app cannot read directly need the privileged metadata/staging
        // route. ScriptRuntime still validates that the selected item is a file.
        if !FileManager.default.isReadableFile(atPath: sourceURL.path) {
            let details = try await IntentSupport.details(of: canonicalPath)
            guard details.node.isShareable else { throw IntentFailure.notAFile(canonicalPath) }
        }
        let ext = sourceURL.pathExtension.lowercased()
        guard ScriptRuntime.isAvailable(for: ext) else {
            throw NSError(domain: "Hoshino.Script", code: 4,
                          userInfo: [NSLocalizedDescriptionKey: "设备上没有可用的 .\(ext) 解释器，或该扩展名不受支持。"])
        }
        try await confirm(
            "Run \(canonicalPath) as the app user? Scripts can read and change files the app process can access. This is not a root shell. Only run trusted code.",
        )
        let result = try await ScriptRuntime.run(path: canonicalPath)
        let output = String(result.output.prefix(256_000))
        let truncated = result.output.count > 256_000 ? "\n\n[Output truncated at 256,000 characters]" : ""
        let summary = "\(result.runtime)\nExit code: \(result.exitCode)\n\n\(output)\(truncated)"
        return .result(value: summary)
    }
}

@available(iOS 16.0, *)
struct RunSelectedScriptsIntent: AppIntent {
    static var title: LocalizedStringResource = "Run Enabled Scripts"
    static var description = IntentDescription(
        "Runs scripts enabled in Hoshino's Documents/Scripts library, sequentially, as the current app user. It does not run as root.",
    )
    static var openAppWhenRun = true

    @MainActor
    func perform() async throws -> some IntentResult & ReturnsValue<String> {
        let entries = try ScriptLibrary.entries()
        let selected = entries.filter(\.isEnabled)
        guard !selected.isEmpty else {
            throw NSError(domain: "Hoshino.ScriptLibrary", code: 2,
                          userInfo: [NSLocalizedDescriptionKey: "No scripts are enabled in Documents/Scripts."])
        }
        try await confirm(
            "Run \(selected.count) enabled script(s) sequentially as the app user? They can read and modify files available to Hoshino, but they do not run as root. Only continue if you trust every enabled script.",
        )

        let executions = await ScriptLibrary.runSelected(maximumOutputCharacters: 256_000)
        let sections = executions.map { execution -> String in
            if let result = execution.result {
                let status = result.timedOut ? "Timed out" : "Exit \(result.exitCode)"
                return "===== \(execution.name) · \(status) =====\n\(result.output)"
            }
            return "===== \(execution.name) · Failed =====\n\(execution.error ?? "Unknown error")"
        }
        let output = sections.joined(separator: "\n\n")
        let bounded = String(output.prefix(1_000_000))
        let summary = bounded + (output.count > 1_000_000 ? "\n\n[Output truncated at 1,000,000 characters]" : "")
        return .result(value: summary)
    }
}

@available(iOS 16.0, *)
struct HoshinoAppShortcuts: AppShortcutsProvider {
    static var appShortcuts: [AppShortcut] {
        AppShortcut(
            intent: RunScriptIntent(),
            phrases: [
                "Run a script in \(.applicationName)",
                "Run script with \(.applicationName)",
            ],
            shortTitle: "Run Script",
            systemImageName: "play.fill",
        )
        AppShortcut(
            intent: RunSelectedScriptsIntent(),
            phrases: [
                "Run enabled scripts in \(.applicationName)",
                "Run my scripts in \(.applicationName)",
            ],
            shortTitle: "Run Scripts",
            systemImageName: "play.rectangle.stack",
        )
    }
}
