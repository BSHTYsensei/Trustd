import Darwin
import Foundation
import JavaScriptCore

private let scriptOutputCapacity = 4 * 1_048_576

@_silgen_name("HoshinoScriptRuntimeAvailable")
private func HoshinoScriptRuntimeAvailable(_ kind: UnsafePointer<CChar>) -> Int32
@_silgen_name("HoshinoRunExternalScript")
private func HoshinoRunExternalScript(
    _ kind: UnsafePointer<CChar>,
    _ path: UnsafePointer<CChar>,
    _ timeout: UInt32,
    _ output: UnsafeMutablePointer<CChar>,
    _ capacity: Int,
) -> Int32

struct ScriptRunResult: Sendable {
    let output: String
    let exitCode: Int32
    let timedOut: Bool
    let runtime: String

    var succeeded: Bool { exitCode == 0 && !timedOut }
}

enum ScriptRuntime {
    static let maximumScriptSize = 8 * 1_048_576

    /// Extensions handled by JavaScriptCore or by a detected device interpreter.
    static let supportedExtensions: Set<String> = [
        "js", "cjs", "mjs", "sh", "command", "bash", "zsh", "fish",
        "py", "pyw", "lua", "rb", "pl", "awk", "php", "r", "tcl",
        "swift", "pl6", "raku",
    ]

    static func isAvailable(for rawExtension: String) -> Bool {
        let kind = rawExtension.lowercased()
        if kind == "js" || kind == "cjs" { return true }
        guard supportedExtensions.contains(kind) else { return false }
        return kind.withCString { HoshinoScriptRuntimeAvailable($0) == 1 }
    }

    static func run(at url: URL, timeoutSeconds: UInt32 = 120) async throws -> ScriptRunResult {
        let kind = url.pathExtension.lowercased()
        guard supportedExtensions.contains(kind) else {
            throw NSError(domain: "Hoshino.Script", code: 1,
                          userInfo: [NSLocalizedDescriptionKey: "不支持的脚本类型：.\(kind)"])
        }
        let resourceValues = try url.resourceValues(forKeys: [.isRegularFileKey, .fileSizeKey])
        guard resourceValues.isRegularFile == true else {
            throw NSError(domain: "Hoshino.Script", code: 2,
                          userInfo: [NSLocalizedDescriptionKey: "脚本路径不是普通文件。"])
        }
        guard let fileSize = resourceValues.fileSize,
              fileSize >= 0, fileSize <= maximumScriptSize else {
            throw NSError(domain: "Hoshino.Script", code: 3,
                          userInfo: [NSLocalizedDescriptionKey: "无法确认脚本大小，或脚本文件超过 8 MiB；为控制内存占用，已拒绝执行。"])
        }

        if kind == "js" || kind == "cjs" {
            return try await Task.detached(priority: .userInitiated) {
                let runtime = try JavaScriptRuntime(rootDirectory: url.deletingLastPathComponent())
                let output = kind == "js" ? try runtime.runClassic(url) : try runtime.runCommonJS(url)
                return ScriptRunResult(output: output, exitCode: 0, timedOut: false,
                                       runtime: kind == "js" ? "JavaScriptCore" : "JavaScriptCore (local CommonJS)")
            }.value
        }

        return try await Task.detached(priority: .userInitiated) {
            var output = [CChar](repeating: 0, count: scriptOutputCapacity)
            let result = kind.withCString { kindPointer in
                url.path.withCString { pathPointer in
                    output.withUnsafeMutableBufferPointer { buffer in
                        HoshinoRunExternalScript(kindPointer, pathPointer, timeoutSeconds,
                                              buffer.baseAddress!, buffer.count)
                    }
                }
            }
            let text = String(cString: output)
            if result == -Int32(Darwin.ETIMEDOUT) {
                return ScriptRunResult(output: text, exitCode: 124, timedOut: true,
                                       runtime: "\(kind.uppercased()) 外部解释器")
            }
            if result < 0 {
                let detail = text.isEmpty ? "解释器启动失败（\(result)）。" : text
                throw NSError(domain: "Hoshino.Script", code: Int(result),
                              userInfo: [NSLocalizedDescriptionKey: detail])
            }
            return ScriptRunResult(output: text, exitCode: result, timedOut: false,
                                   runtime: "\(kind.uppercased()) 外部解释器")
        }.value
    }

    /// Runs a file through Fila's descriptor-backed staging path when the app process
    /// cannot read it directly. A directly readable script stays in its original folder,
    /// so relative assets and local CommonJS modules continue to resolve as expected.
    @MainActor
    static func run(path: String) async throws -> ScriptRunResult {
        try await run(path: path, session: FileSession.shared)
    }

    @MainActor
    static func run(path: String, session: FileSession) async throws -> ScriptRunResult {
        let sourceURL = URL(fileURLWithPath: path).standardizedFileURL
        if FileManager.default.isReadableFile(atPath: sourceURL.path) {
            return try await run(at: sourceURL)
        }
        // The descriptor's fstat is checked before copying, so a large file is
        // refused without first filling the app's temporary workspace.
        let stagedURL = try await session.stage(path, maximumByteCount: Int64(maximumScriptSize))
        defer { try? FileManager.default.removeItem(at: stagedURL.deletingLastPathComponent()) }
        return try await run(at: stagedURL)
    }
}

private final class JavaScriptRuntime: @unchecked Sendable {
    private let context: JSContext
    private let rootDirectory: URL
    private var output = ""
    private var moduleCache: [String: JSValue] = [:]
    private let outputLimit = 4 * 1_048_576 - 128
    private var didTruncateOutput = false

    private func appendOutput(_ value: String) {
        guard !didTruncateOutput else { return }
        let currentCount = output.utf8.count
        guard currentCount < outputLimit else {
            didTruncateOutput = true
            output += "\n[输出已截断：超过 4 MiB]"
            return
        }
        let remaining = outputLimit - currentCount
        let bytes = Array(value.utf8.prefix(remaining))
        output += String(decoding: bytes, as: UTF8.self)
        if value.utf8.count > remaining {
            didTruncateOutput = true
            output += "\n[输出已截断：超过 4 MiB]"
        }
    }

    init(rootDirectory: URL) throws {
        guard let context = JSContext() else {
            throw NSError(domain: "Hoshino.Script.JavaScript", code: 2,
                          userInfo: [NSLocalizedDescriptionKey: "无法创建 JavaScriptCore 执行环境。"])
        }
        self.rootDirectory = rootDirectory.standardizedFileURL.resolvingSymlinksInPath()
        self.context = context
        installConsole()
    }

    func runClassic(_ url: URL) throws -> String {
        let source = try readSource(url)
        _ = context.evaluateScript(source, withSourceURL: url)
        try throwIfException()
        return output
    }

    func runCommonJS(_ url: URL) throws -> String {
        _ = try loadCommonJS(url)
        try throwIfException()
        return output
    }

    private func installConsole() {
        let log: @convention(block) (String) -> Void = { [weak self] value in self?.appendOutput(value + "\n") }
        context.setObject(log, forKeyedSubscript: "print" as NSString)
        let console = JSValue(newObjectIn: context)!
        console.setObject(log, forKeyedSubscript: "log" as NSString)
        console.setObject(log, forKeyedSubscript: "info" as NSString)
        console.setObject(log, forKeyedSubscript: "warn" as NSString)
        console.setObject(log, forKeyedSubscript: "error" as NSString)
        context.setObject(console, forKeyedSubscript: "console" as NSString)
        context.exceptionHandler = { [weak self] _, exception in
            guard let exception else { return }
            self?.appendOutput("ERROR: \(exception.toString() ?? "JavaScript exception")\n")
        }
    }

    private func throwIfException() throws {
        guard let exception = context.exception else { return }
        context.exception = nil
        throw NSError(domain: "Hoshino.Script.JavaScript", code: 1,
                      userInfo: [NSLocalizedDescriptionKey: exception.toString() ?? "JavaScript 执行失败。"])
    }

    private func readSource(_ url: URL) throws -> String {
        let safeURL = try validatedURL(url)
        let data = try readBoundedData(safeURL)
        guard let source = String(data: data, encoding: .utf8) else {
            throw runtimeError("脚本不是有效的 UTF-8 文本：\(safeURL.lastPathComponent)")
        }
        return source
    }

    /// fstat the opened descriptor and read at most limit + 1 bytes. URL resource
    /// values alone can be absent or stale, and a growing file must not bypass
    /// the source-size limit between the metadata check and the read.
    private func readBoundedData(_ url: URL) throws -> Data {
        let handle = try FileHandle(forReadingFrom: url)
        defer { try? handle.close() }
        var status = stat()
        guard fstat(handle.fileDescriptor, &status) == 0,
              status.st_mode & S_IFMT == S_IFREG,
              status.st_size >= 0,
              status.st_size <= 8 * 1_048_576 else {
            throw runtimeError("脚本或本地模块超过 8 MiB，或不是普通文件：\(url.lastPathComponent)")
        }

        let limit = 8 * 1_048_576
        var data = Data()
        while data.count <= limit {
            let remaining = limit + 1 - data.count
            let chunk = try handle.read(upToCount: min(256 * 1_024, remaining)) ?? Data()
            if chunk.isEmpty { break }
            data.append(chunk)
        }
        guard data.count <= limit else {
            throw runtimeError("脚本或本地模块读取期间超过 8 MiB：\(url.lastPathComponent)")
        }
        return data
    }

    private func validatedURL(_ url: URL) throws -> URL {
        let resolved = url.standardizedFileURL.resolvingSymlinksInPath()
        let rootPath = rootDirectory.path.hasSuffix("/") ? rootDirectory.path : rootDirectory.path + "/"
        guard resolved.path.hasPrefix(rootPath), resolved.path != rootDirectory.path else {
            throw runtimeError("模块路径越过脚本库目录，已拒绝加载：\(url.path)")
        }
        var isDirectory: ObjCBool = false
        guard FileManager.default.fileExists(atPath: resolved.path, isDirectory: &isDirectory), !isDirectory.boolValue else {
            throw runtimeError("脚本模块不存在或不是普通文件：\(resolved.lastPathComponent)")
        }
        let ext = resolved.pathExtension.lowercased()
        guard ["js", "cjs", "json"].contains(ext) else {
            throw runtimeError("CommonJS 只允许加载 .js、.cjs、.json 本地模块：\(resolved.lastPathComponent)")
        }
        return resolved
    }

    private func loadCommonJS(_ requestedURL: URL) throws -> JSValue {
        let url = try validatedURL(requestedURL)
        let key = url.path
        if let cachedModule = moduleCache[key] {
            return cachedModule.forProperty("exports") ?? JSValue(undefinedIn: context)
        }
        if url.pathExtension.lowercased() == "json" {
            let data = try readBoundedData(url)
            let value = try JSONSerialization.jsonObject(with: data, options: [.fragmentsAllowed])
            let jsonData = try JSONSerialization.data(withJSONObject: value, options: [.fragmentsAllowed, .sortedKeys])
            guard let json = String(data: jsonData, encoding: .utf8),
                  let parsed = context.evaluateScript("JSON.parse(\(Self.javascriptStringLiteral(json)))") else {
                throw runtimeError("JSON 模块解析失败：\(url.lastPathComponent)")
            }
            return parsed
        }

        let module = JSValue(newObjectIn: context)!
        let exports = JSValue(newObjectIn: context)!
        module.setValue(exports, forProperty: "exports")
        // Cache before evaluating to support the CommonJS circular-dependency rule.
        moduleCache[key] = module

        let requireBlock: @convention(block) (String) -> JSValue? = { [weak self] specifier in
            guard let self else { return nil }
            do {
                return try self.resolveAndLoad(specifier, parent: url)
            } catch {
                let message = Self.javascriptStringLiteral(error.localizedDescription)
                _ = self.context.evaluateScript("throw new Error(\(message))")
                return nil
            }
        }

        let source = try readSource(url)
        let wrapper = "(function(exports, require, module, __filename, __dirname) {\n\(source)\n})"
        guard let function = context.evaluateScript(wrapper, withSourceURL: url) else {
            try throwIfException()
            throw runtimeError("无法创建 CommonJS 模块函数：\(url.lastPathComponent)")
        }
        _ = function.call(withArguments: [exports, requireBlock, module, url.path, url.deletingLastPathComponent().path])
        try throwIfException()
        return module.forProperty("exports") ?? JSValue(undefinedIn: context)
    }

    private func resolveAndLoad(_ specifier: String, parent: URL) throws -> JSValue {
        guard specifier.hasPrefix("./") || specifier.hasPrefix("../") else {
            throw runtimeError("不支持 Node 内置模块或 npm 包：\(specifier)。当前只允许脚本库目录内的相对模块。")
        }
        let base = parent.deletingLastPathComponent().appendingPathComponent(specifier)
        var candidates = [base]
        if base.pathExtension.isEmpty {
            candidates += [base.appendingPathExtension("js"), base.appendingPathExtension("cjs"), base.appendingPathExtension("json"),
                           base.appendingPathComponent("index.js"), base.appendingPathComponent("index.cjs"), base.appendingPathComponent("index.json")]
        }
        for candidate in candidates {
            let resolved = candidate.standardizedFileURL.resolvingSymlinksInPath()
            let rootPath = rootDirectory.path.hasSuffix("/") ? rootDirectory.path : rootDirectory.path + "/"
            guard resolved.path.hasPrefix(rootPath) else { throw runtimeError("模块路径越过脚本库目录：\(specifier)") }
            if FileManager.default.fileExists(atPath: resolved.path) { return try loadCommonJS(resolved) }
        }
        throw runtimeError("找不到本地 CommonJS 模块：\(specifier)")
    }

    private func runtimeError(_ message: String) -> NSError {
        NSError(domain: "Hoshino.Script.CommonJS", code: 2, userInfo: [NSLocalizedDescriptionKey: message])
    }

    private static func javascriptStringLiteral(_ string: String) -> String {
        let data = try! JSONSerialization.data(withJSONObject: [string], options: [.fragmentsAllowed])
        let encoded = String(data: data, encoding: .utf8) ?? "[\"\"]"
        return String(encoded.dropFirst().dropLast())
    }
}
