import Foundation

struct ScriptLibraryEntry: Identifiable, Sendable {
    let fileName: String
    let url: URL
    let isEnabled: Bool
    let runtimeAvailable: Bool

    var id: String { fileName }
    var name: String { (fileName as NSString).deletingPathExtension }
    var fileExtension: String { URL(fileURLWithPath: fileName).pathExtension.lowercased() }
}

struct ScriptLibraryExecution: Sendable {
    let name: String
    let result: ScriptRunResult?
    let error: String?
}

/// Hoshino's managed script folder, implemented on Fila's local-file and
/// script-runtime layers. Scripts run as the app process user, never as root.
@MainActor
enum ScriptLibrary {
    static let maximumScripts = 500
    static let maximumScriptSize = ScriptRuntime.maximumScriptSize
    private static let selectionKey = "Hoshino.ScriptLibrary.Enabled.v1"
    private static let fileManager = FileManager.default

    static var folder: URL {
        fileManager.urls(for: .documentDirectory, in: .userDomainMask)[0]
            .appendingPathComponent("Scripts", isDirectory: true)
    }

    @discardableResult
    static func ensureFolder() throws -> URL {
        let documents = fileManager.urls(for: .documentDirectory, in: .userDomainMask)[0]
        var isDirectory: ObjCBool = false
        if fileManager.fileExists(atPath: folder.path, isDirectory: &isDirectory) {
            let values = try folder.resourceValues(forKeys: [.isDirectoryKey, .isSymbolicLinkKey])
            guard isDirectory.boolValue, values.isDirectory == true, values.isSymbolicLink != true else {
                throw libraryError("Documents/Scripts must be a real directory, not a file or symbolic link.")
            }
        } else {
            try fileManager.createDirectory(at: folder, withIntermediateDirectories: true)
        }

        let resolvedDocuments = documents.standardizedFileURL.resolvingSymlinksInPath()
        let resolvedFolder = folder.standardizedFileURL.resolvingSymlinksInPath()
        guard resolvedFolder.deletingLastPathComponent() == resolvedDocuments else {
            throw libraryError("Documents/Scripts resolves outside the app's Documents directory.")
        }
        return resolvedFolder
    }

    static func entries() throws -> [ScriptLibraryEntry] {
        let root = try ensureFolder().standardizedFileURL.resolvingSymlinksInPath()
        let urls = try fileManager.contentsOfDirectory(
            at: root,
            includingPropertiesForKeys: [.isRegularFileKey, .isSymbolicLinkKey, .fileSizeKey],
            options: [.skipsHiddenFiles, .skipsPackageDescendants],
        )
        let selected = Set(UserDefaults.standard.stringArray(forKey: selectionKey) ?? [])
        var availabilityByExtension: [String: Bool] = [:]
        return urls.compactMap { url in
            let values = try? url.resourceValues(forKeys: [.isRegularFileKey, .isSymbolicLinkKey])
            guard values?.isRegularFile == true,
                  values?.isSymbolicLink != true,
                  ScriptRuntime.supportedExtensions.contains(url.pathExtension.lowercased())
            else { return nil }
            let name = url.lastPathComponent
            let ext = url.pathExtension.lowercased()
            let available = availabilityByExtension[ext] ?? ScriptRuntime.isAvailable(for: ext)
            availabilityByExtension[ext] = available
            return ScriptLibraryEntry(
                fileName: name,
                url: url,
                isEnabled: selected.contains(name),
                runtimeAvailable: available,
            )
        }
        .sorted { $0.fileName.localizedStandardCompare($1.fileName) == .orderedAscending }
    }

    static func setEnabled(_ enabled: Bool, for fileName: String) throws {
        let validNames = Set(try entries().map(\.fileName))
        guard validNames.contains(fileName) else { throw libraryError("Script no longer exists: \(fileName)") }
        var selected = Set(UserDefaults.standard.stringArray(forKey: selectionKey) ?? [])
        if enabled { selected.insert(fileName) } else { selected.remove(fileName) }
        UserDefaults.standard.set(selected.sorted(), forKey: selectionKey)
    }

    @discardableResult
    static func importScript(from source: URL) throws -> ScriptLibraryEntry {
        let didAccess = source.startAccessingSecurityScopedResource()
        defer { if didAccess { source.stopAccessingSecurityScopedResource() } }

        let values = try source.resourceValues(forKeys: [.isRegularFileKey, .isSymbolicLinkKey, .fileSizeKey])
        let ext = source.pathExtension.lowercased()
        guard values.isRegularFile == true, values.isSymbolicLink != true else {
            throw libraryError("Only regular script files can be imported.")
        }
        guard ScriptRuntime.supportedExtensions.contains(ext) else {
            throw libraryError("Unsupported script type: .\(ext)")
        }
        guard let fileSize = values.fileSize,
              fileSize >= 0, fileSize <= maximumScriptSize else {
            throw libraryError("The script size could not be verified, or it exceeds 8 MiB. Import was refused to protect memory use.")
        }

        let destinationFolder = try ensureFolder()
        guard try entries().count < maximumScripts else {
            throw libraryError("The script library can contain up to \(maximumScripts) scripts.")
        }

        let baseName = source.deletingPathExtension().lastPathComponent
        let safeBaseName = baseName.isEmpty ? "Script" : baseName
        var candidate = destinationFolder.appendingPathComponent(safeBaseName).appendingPathExtension(ext)
        var suffix = 2
        while fileManager.fileExists(atPath: candidate.path) {
            candidate = destinationFolder.appendingPathComponent("\(safeBaseName) (\(suffix))").appendingPathExtension(ext)
            suffix += 1
        }
        try fileManager.copyItem(at: source, to: candidate)
        return ScriptLibraryEntry(
            fileName: candidate.lastPathComponent,
            url: candidate,
            isEnabled: false,
            runtimeAvailable: ScriptRuntime.isAvailable(for: ext),
        )
    }

    static func delete(_ fileName: String) throws {
        guard !fileName.isEmpty,
              URL(fileURLWithPath: fileName).lastPathComponent == fileName
        else { throw libraryError("Invalid script file name.") }

        let root = try ensureFolder().standardizedFileURL.resolvingSymlinksInPath()
        let candidate = root.appendingPathComponent(fileName).standardizedFileURL
        guard candidate.deletingLastPathComponent() == root else {
            throw libraryError("Script path is outside the script library.")
        }
        let values = try candidate.resourceValues(forKeys: [.isRegularFileKey, .isSymbolicLinkKey])
        guard values.isRegularFile == true, values.isSymbolicLink != true else {
            throw libraryError("Only regular script files can be deleted here.")
        }
        try fileManager.removeItem(at: candidate)
        var selected = Set(UserDefaults.standard.stringArray(forKey: selectionKey) ?? [])
        selected.remove(fileName)
        UserDefaults.standard.set(selected.sorted(), forKey: selectionKey)
    }

    static func runSelected(maximumOutputCharacters: Int = 1_000_000) async -> [ScriptLibraryExecution] {
        let selected: [ScriptLibraryEntry]
        do {
            selected = try entries().filter(\.isEnabled)
        } catch {
            return [ScriptLibraryExecution(name: "Script Library", result: nil, error: error.localizedDescription)]
        }

        var executions: [ScriptLibraryExecution] = []
        var remainingOutputCharacters = max(0, maximumOutputCharacters - 2_048)
        for entry in selected {
            guard entry.runtimeAvailable else {
                executions.append(ScriptLibraryExecution(
                    name: entry.fileName,
                    result: nil,
                    error: "Missing interpreter for .\(entry.fileExtension)",
                ))
                continue
            }
            do {
                let result = try await ScriptRuntime.run(at: entry.url)
                let retained = String(result.output.prefix(remainingOutputCharacters))
                let wasTruncated = retained.count < result.output.count
                remainingOutputCharacters = max(0, remainingOutputCharacters - retained.count)
                let boundedResult = ScriptRunResult(
                    output: retained + (wasTruncated ? "\n[Batch output truncated at 1,000,000 characters]" : ""),
                    exitCode: result.exitCode,
                    timedOut: result.timedOut,
                    runtime: result.runtime,
                )
                executions.append(ScriptLibraryExecution(name: entry.fileName, result: boundedResult, error: nil))
            } catch {
                let message = String(error.localizedDescription.prefix(4_096))
                executions.append(ScriptLibraryExecution(name: entry.fileName, result: nil, error: message))
            }
        }
        return executions
    }

    private static func libraryError(_ message: String) -> NSError {
        NSError(domain: "Hoshino.ScriptLibrary", code: 1, userInfo: [NSLocalizedDescriptionKey: message])
    }
}
