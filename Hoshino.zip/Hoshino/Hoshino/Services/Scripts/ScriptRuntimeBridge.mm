#include "ScriptRuntimeBridge.h"

#include <cerrno>
#include <csignal>
#include <cstdlib>
#include <cstdint>
#include <cstring>
#include <string>
#include <vector>

#include <fcntl.h>
#include <poll.h>
#include <spawn.h>
#include <sys/stat.h>
#include <sys/wait.h>
#include <time.h>
#include <unistd.h>

extern char **environ;

namespace {
constexpr size_t kMaximumCapturedBytes = 4U * 1024U * 1024U - 128U;
constexpr char kTruncationMessage[] = "\n[Output truncated after 4 MiB]\n";
constexpr char kTimeoutMessage[] = "\n[Script timed out and its process group was stopped]\n";
constexpr unsigned int kDefaultTimeoutSeconds = 120;

std::vector<std::string> searchPaths() {
    std::vector<std::string> paths = {
        "/var/jb/usr/bin", "/var/jb/bin", "/opt/procursus/bin",
        "/usr/local/bin", "/usr/bin", "/bin", "/usr/sbin", "/sbin", "/opt/bin"
    };
    if (const char *environment = std::getenv("PATH")) {
        std::string value(environment);
        size_t start = 0;
        while (start <= value.size()) {
            const size_t end = value.find(':', start);
            const std::string item = value.substr(start, end == std::string::npos ? std::string::npos : end - start);
            if (!item.empty()) paths.push_back(item);
            if (end == std::string::npos) break;
            start = end + 1;
        }
    }
    return paths;
}

bool isExecutableFile(const std::string &path) {
    return access(path.c_str(), X_OK) == 0;
}

std::string findExecutable(const std::vector<std::string> &names) {
    for (const auto &directory : searchPaths()) {
        for (const auto &name : names) {
            const std::string candidate = directory + "/" + name;
            if (isExecutableFile(candidate)) return candidate;
        }
    }
    return {};
}

struct Command {
    std::string executable;
    std::vector<std::string> arguments;
};

bool buildCommand(const std::string &kind, const std::string &path, Command &command) {
    auto use = [&](const std::vector<std::string> &names, std::vector<std::string> args) {
        command.executable = findExecutable(names);
        if (command.executable.empty()) return false;
        command.arguments.push_back(command.executable);
        command.arguments.insert(command.arguments.end(), args.begin(), args.end());
        return true;
    };

    if (kind == "sh" || kind == "command") {
        command.executable = "/bin/sh";
        if (!isExecutableFile(command.executable)) return false;
        command.arguments = {command.executable, path};
        return true;
    }
    if (kind == "bash") return use({"bash"}, {path});
    if (kind == "zsh") return use({"zsh"}, {path});
    if (kind == "fish") return use({"fish"}, {path});
    if (kind == "py" || kind == "pyw") return use({"python3", "python"}, {path});
    if (kind == "mjs") return use({"node", "nodejs"}, {path});
    if (kind == "lua") return use({"lua", "lua5.4", "lua5.3"}, {path});
    if (kind == "rb") return use({"ruby"}, {path});
    if (kind == "pl") return use({"perl"}, {path});
    if (kind == "awk") return use({"awk", "gawk", "mawk"}, {"-f", path});
    if (kind == "php") return use({"php"}, {path});
    if (kind == "r") return use({"Rscript"}, {"--vanilla", path});
    if (kind == "tcl") return use({"tclsh"}, {path});
    if (kind == "swift") return use({"swift"}, {path});
    if (kind == "pl6" || kind == "raku") return use({"raku", "perl6"}, {path});
    return false;
}

uint64_t monotonicMilliseconds() {
    struct timespec value{};
    clock_gettime(CLOCK_MONOTONIC, &value);
    return static_cast<uint64_t>(value.tv_sec) * 1000U + static_cast<uint64_t>(value.tv_nsec) / 1000000U;
}

void writeOutput(char *output, size_t capacity, const std::string &text) {
    if (!output || capacity == 0) return;
    const size_t count = text.size() < capacity - 1 ? text.size() : capacity - 1;
    std::memcpy(output, text.data(), count);
    output[count] = '\0';
}

std::string parentDirectory(const std::string &path) {
    const size_t separator = path.find_last_of('/');
    if (separator == std::string::npos) return ".";
    if (separator == 0) return "/";
    return path.substr(0, separator);
}
} // namespace

extern "C" int HoshinoScriptRuntimeAvailable(const char *rawKind) {
    if (!rawKind) return 0;
    const std::string kind(rawKind);
    if (kind == "sh" || kind == "command") return isExecutableFile("/bin/sh") ? 1 : 0;
    Command command;
    return buildCommand(kind, "/dev/null", command) ? 1 : 0;
}

extern "C" int HoshinoRunExternalScript(const char *rawKind, const char *rawPath,
                                      unsigned int timeoutSeconds, char *output, size_t capacity) {
    if (output && capacity) output[0] = '\0';
    if (!rawKind || !rawPath || !output || capacity < 2) return -EINVAL;

    const std::string kind(rawKind);
    const std::string path(rawPath);
    if (path.empty() || path[0] != '/') return -EINVAL;

    struct stat scriptStatus{};
    if (stat(path.c_str(), &scriptStatus) != 0) return -errno;
    if (!S_ISREG(scriptStatus.st_mode) || scriptStatus.st_size < 0) return -EINVAL;
    if (scriptStatus.st_size > 8 * 1024 * 1024) return -EFBIG;

    Command command;
    if (!buildCommand(kind, path, command)) {
        const std::string message = "No compatible interpreter is installed for ." + kind + " files.\n";
        writeOutput(output, capacity, message);
        return -ENOENT;
    }

    int descriptors[2] = {-1, -1};
    if (pipe(descriptors) != 0) return -errno;
    const int readFD = descriptors[0];
    const int writeFD = descriptors[1];
    fcntl(readFD, F_SETFD, FD_CLOEXEC);
    fcntl(writeFD, F_SETFD, FD_CLOEXEC);
    const int flags = fcntl(readFD, F_GETFL, 0);
    if (flags >= 0) fcntl(readFD, F_SETFL, flags | O_NONBLOCK);

    posix_spawn_file_actions_t actions;
    posix_spawnattr_t attributes;
    int setupResult = posix_spawn_file_actions_init(&actions);
    if (setupResult != 0) {
        close(readFD);
        close(writeFD);
        return -setupResult;
    }
    setupResult = posix_spawnattr_init(&attributes);
    if (setupResult != 0) {
        posix_spawn_file_actions_destroy(&actions);
        close(readFD);
        close(writeFD);
        return -setupResult;
    }
    setupResult = posix_spawn_file_actions_adddup2(&actions, writeFD, STDOUT_FILENO);
    if (setupResult == 0) setupResult = posix_spawn_file_actions_adddup2(&actions, writeFD, STDERR_FILENO);
    if (setupResult == 0) setupResult = posix_spawn_file_actions_addclose(&actions, readFD);
    if (setupResult == 0) setupResult = posix_spawn_file_actions_addclose(&actions, writeFD);
    if (setupResult == 0) setupResult = posix_spawn_file_actions_addopen(&actions, STDIN_FILENO, "/dev/null", O_RDONLY, 0);
    // Relative paths used by a script resolve against the script's own folder.
    if (setupResult == 0) setupResult = posix_spawn_file_actions_addchdir_np(&actions, parentDirectory(path).c_str());
    if (setupResult == 0) setupResult = posix_spawnattr_setflags(&attributes, POSIX_SPAWN_SETPGROUP);
    if (setupResult == 0) setupResult = posix_spawnattr_setpgroup(&attributes, 0);
    if (setupResult != 0) {
        posix_spawn_file_actions_destroy(&actions);
        posix_spawnattr_destroy(&attributes);
        close(readFD);
        close(writeFD);
        return -setupResult;
    }

    std::vector<char *> argv;
    argv.reserve(command.arguments.size() + 1);
    for (auto &argument : command.arguments) argv.push_back(const_cast<char *>(argument.c_str()));
    argv.push_back(nullptr);

    pid_t process = 0;
    const int spawnResult = posix_spawn(&process, command.executable.c_str(), &actions, &attributes,
                                        argv.data(), environ);
    posix_spawn_file_actions_destroy(&actions);
    posix_spawnattr_destroy(&attributes);
    close(writeFD);
    if (spawnResult != 0) {
        close(readFD);
        return -spawnResult;
    }

    const unsigned int boundedTimeout = timeoutSeconds == 0 ? kDefaultTimeoutSeconds
                                                             : (timeoutSeconds > 900 ? 900 : timeoutSeconds);
    const uint64_t deadline = monotonicMilliseconds() + static_cast<uint64_t>(boundedTimeout) * 1000U;
    std::string captured;
    captured.reserve(64U * 1024U);
    bool didTruncate = false;
    bool pipeOpen = true;
    bool childExited = false;
    int childStatus = 0;
    int waitError = 0;
    bool timedOut = false;

    uint64_t drainDeadline = 0;
    bool sentTermination = false;
    while (pipeOpen || !childExited) {
        if (!childExited) {
            const pid_t waitResult = waitpid(process, &childStatus, WNOHANG);
            if (waitResult == process) childExited = true;
            else if (waitResult < 0 && errno != EINTR) {
                waitError = errno;
                childExited = true;
            }
        }
        // A script can exit while a background descendant keeps the output
        // pipe open. The deadline therefore covers both the leader and pipe.
        if (!timedOut && monotonicMilliseconds() >= deadline && (!childExited || pipeOpen)) {
            timedOut = true;
            sentTermination = true;
            drainDeadline = monotonicMilliseconds() + 750U;
            kill(-process, SIGTERM);
        }
        if (timedOut && sentTermination && monotonicMilliseconds() >= drainDeadline) {
            kill(-process, SIGKILL);
            if (pipeOpen) {
                close(readFD);
                pipeOpen = false;
            }
            if (!childExited) {
                const pid_t waited = waitpid(process, &childStatus, WNOHANG);
                if (waited == process) childExited = true;
            }
            sentTermination = false;
        }

        if (pipeOpen) {
            struct pollfd descriptor{readFD, POLLIN | POLLHUP | POLLERR, 0};
            const int pollResult = poll(&descriptor, 1, 100);
            if (pollResult > 0 && (descriptor.revents & (POLLIN | POLLHUP | POLLERR))) {
                char buffer[32768];
                for (;;) {
                    const ssize_t count = read(readFD, buffer, sizeof(buffer));
                    if (count > 0) {
                        const size_t remaining = captured.size() < kMaximumCapturedBytes
                            ? kMaximumCapturedBytes - captured.size() : 0;
                        const size_t accepted = static_cast<size_t>(count) < remaining ? static_cast<size_t>(count) : remaining;
                        if (accepted) captured.append(buffer, accepted);
                        if (accepted != static_cast<size_t>(count)) didTruncate = true;
                    } else if (count == 0) {
                        pipeOpen = false;
                        close(readFD);
                        break;
                    } else {
                        if (errno == EINTR) continue;
                        if (errno == EAGAIN || errno == EWOULDBLOCK) break;
                        pipeOpen = false;
                        close(readFD);
                        break;
                    }
                }
            } else if (pollResult < 0 && errno != EINTR) {
                pipeOpen = false;
                close(readFD);
            }
        } else if (!childExited) {
            // A script may redirect both output streams and keep running. With
            // no pipe left to poll, still yield between waitpid(WNOHANG) calls.
            (void)poll(nullptr, 0, 100);
        }
        if (timedOut && childExited && !pipeOpen) break;
    }

    if (!childExited) {
        pid_t waited;
        do { waited = waitpid(process, &childStatus, 0); } while (waited < 0 && errno == EINTR);
        if (waited < 0) waitError = errno;
    }
    // Do not leave a background descendant running after the user has closed the result.
    kill(-process, SIGTERM);
    usleep(25000);
    kill(-process, SIGKILL);

    if (didTruncate) captured += kTruncationMessage;
    if (timedOut) captured += kTimeoutMessage;
    writeOutput(output, capacity, captured);
    if (timedOut) return -ETIMEDOUT;
    if (waitError != 0) return -waitError;
    if (WIFEXITED(childStatus)) return WEXITSTATUS(childStatus);
    if (WIFSIGNALED(childStatus)) return 128 + WTERMSIG(childStatus);
    return -ECHILD;
}
