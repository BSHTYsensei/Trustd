import SnapKit
import UIKit

@MainActor
final class ScriptOutputViewController: UIViewController {
    private let result: ScriptRunResult
    private let scriptName: String
    private let textView = UITextView()

    init(scriptName: String, result: ScriptRunResult) {
        self.scriptName = scriptName
        self.result = result
        super.init(nibName: nil, bundle: nil)
        modalPresentationStyle = .formSheet
        navigationItem.title = scriptName
        navigationItem.rightBarButtonItem = UIBarButtonItem(
            image: UIImage(systemName: "doc.on.doc"),
            primaryAction: UIAction { [weak self] _ in
                UIPasteboard.general.string = self?.result.output ?? ""
            },
        )
        navigationItem.rightBarButtonItem?.accessibilityLabel = String(localized: "Copy Output")
        navigationItem.leftBarButtonItem = UIBarButtonItem(
            systemItem: .close,
            primaryAction: UIAction { [weak self] _ in self?.dismiss(animated: true) },
        )
    }

    @available(*, unavailable)
    required init?(coder: NSCoder) { fatalError("init(coder:) is not used") }

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .systemBackground

        let status = UILabel()
        status.numberOfLines = 0
        status.font = .preferredFont(forTextStyle: .footnote)
        status.textColor = result.succeeded ? .secondaryLabel : .systemRed
        status.text = result.timedOut
            ? "\(result.runtime) · Timed Out"
            : (result.succeeded
                ? "\(result.runtime) · Exit 0"
                : "\(result.runtime) · Exit \(result.exitCode)")

        textView.font = .monospacedSystemFont(ofSize: 12, weight: .regular)
        textView.isEditable = false
        textView.isSelectable = true
        textView.alwaysBounceVertical = true
        textView.text = result.output.isEmpty ? String(localized: "No output.") : result.output
        textView.textContainerInset = UIEdgeInsets(top: 12, left: 12, bottom: 20, right: 12)
        textView.accessibilityLabel = String(localized: "Script Output")

        let stack = UIStackView(arrangedSubviews: [status, textView])
        stack.axis = .vertical
        stack.spacing = 8
        view.addSubview(stack)
        stack.snp.makeConstraints { make in
            make.edges.equalTo(view.safeAreaLayoutGuide).inset(12)
        }
        status.snp.makeConstraints { make in
            make.height.greaterThanOrEqualTo(22)
        }
    }
}
