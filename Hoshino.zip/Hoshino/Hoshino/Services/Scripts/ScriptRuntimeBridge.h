#ifndef FILA_SCRIPT_RUNTIME_BRIDGE_H
#define FILA_SCRIPT_RUNTIME_BRIDGE_H
#include <stddef.h>
#ifdef __cplusplus
extern "C" {
#endif
int HoshinoScriptRuntimeAvailable(const char *kind);
/// Returns 0 on success, a positive interpreter exit status, or a negative errno-style error.
/// Output is UTF-8, NUL-terminated, capped at capacity-1 bytes. A 120-second limit is used by default.
int HoshinoRunExternalScript(const char *kind, const char *path, unsigned int timeoutSeconds,
                          char *output, size_t capacity);
#ifdef __cplusplus
}
#endif
#endif
