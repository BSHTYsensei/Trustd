#!/usr/bin/env python3
"""Reject native process APIs that the iOS SDK explicitly marks unavailable."""
from __future__ import annotations

import hashlib
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
NATIVE_SUFFIXES = {".m", ".mm", ".c", ".cc", ".cpp", ".h", ".hpp"}
BRIDGE = ROOT / "Hoshino/Services/Scripts/ScriptRuntimeBridge.mm"

# Split the identifier so the guard itself does not look like a call-site hit.
forbidden = "posix_spawn_file_actions_add" + "chdir_np"
call_pattern = re.compile(rf"\b{re.escape(forbidden)}\s*\(")
roots = (ROOT / "Hoshino", ROOT / "Frameworks", ROOT / "Filad", ROOT / "FilaArchive", ROOT / "Packages")
failures: list[str] = []
for source_root in roots:
    if not source_root.exists():
        continue
    for path in source_root.rglob("*"):
        if path.is_file() and path.suffix in NATIVE_SUFFIXES:
            try:
                content = path.read_text(encoding="utf-8")
            except UnicodeDecodeError:
                continue
            if call_pattern.search(content):
                failures.append(f"{path.relative_to(ROOT)}: contains an iOS-unavailable spawn chdir call")

if failures:
    print("error: iOS native API preflight failed:", file=sys.stderr)
    print("\n".join(failures), file=sys.stderr)
    print("Replace the stale ScriptRuntimeBridge.mm with the iOS-safe launcher from this source archive.", file=sys.stderr)
    raise SystemExit(65)

if not BRIDGE.is_file():
    raise SystemExit("error: ScriptRuntimeBridge.mm is missing")
bridge_hash = hashlib.sha256(BRIDGE.read_bytes()).hexdigest()
bridge_text = BRIDGE.read_text(encoding="utf-8")
if not all(token in bridge_text for token in ("CDPATH= cd", "shift; exec", "$1", "$@")):
    raise SystemExit("error: ScriptRuntimeBridge.mm does not contain the verified iOS-safe working-directory launcher")
print(f"[OK] iOS spawn API preflight: no unavailable calls; ScriptRuntimeBridge.mm sha256={bridge_hash}")
