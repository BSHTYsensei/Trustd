#!/bin/bash
# Install a built .deb onto a jailbroken device over SSH; optionally relaunch.
#
# The device is reached through usbmuxd, not the network: `iproxy 2333 22`
# forwards a local port to the device's sshd, which is how a VM guest or a
# phone on a cable is reachable without either of them having an address.
#
#   Scripts/install-device.sh build/Packages/wiki.qaq.fila_0.1.0_iphoneos-arm64.deb
#
# Overridable: DEVICE_HOST, DEVICE_PORT, DEVICE_USER, DEVICE_PASSWORD.
# Without DEVICE_PASSWORD the usual ssh key path is used.

set -euo pipefail

if [[ $# -lt 1 || $# -gt 2 || ($# -eq 2 && "$2" != --launch) ]]; then
    echo "usage: install-device.sh <package.deb> [--launch]" >&2
    exit 64
fi
package="$1"
host="${DEVICE_HOST:-127.0.0.1}"
port="${DEVICE_PORT:-2333}"
user="${DEVICE_USER:-mobile}"
password="${DEVICE_PASSWORD:-}"

test -f "$package" || { echo "error: $package does not exist" >&2; exit 66; }

# Host keys change every time a VM guest is rebuilt, and this is a loopback
# port to a device we just built for — recording them would only produce a
# mismatch to clear by hand later.
ssh_options=(
    -o StrictHostKeyChecking=no
    -o UserKnownHostsFile=/dev/null
    -o LogLevel=ERROR
    -o ConnectTimeout=10
)

if [ -n "$password" ]; then
    command -v sshpass >/dev/null || { echo "error: DEVICE_PASSWORD is set but sshpass is not installed (install it with your preferred package manager)" >&2; exit 69; }
    # Through the environment, never `-p`: an argument is on the process list
    # for anyone on the Mac to read until sshpass overwrites it.
    run_ssh() { SSHPASS="$password" sshpass -e ssh "${ssh_options[@]}" -p "$port" "$user@$host" "$@"; }
else
    run_ssh() { ssh "${ssh_options[@]}" -p "$port" "$user@$host" "$@"; }
fi

if ! nc -z "$host" "$port" 2>/dev/null; then
    echo "error: nothing is listening on $host:$port." >&2
    echo "       Start the usbmuxd forward first:  iproxy $port 22" >&2
    exit 69
fi

# Quote one argument for the remote POSIX shell, including embedded quotes.
shell_quote() {
    local quote="'" escaped="'\\''"
    printf "'%s'" "${1//$quote/$escaped}"
}

# A non-login ssh shell on a jailbroken guest can come up with nothing but
# /usr/bin:/bin — the vphone's does — and sudo and dpkg live in
# the bootstrap. Added rather than substituted, and inside the remote shell as
# well because sudo may impose its own secure_path. A relocated roothide
# bootstrap is not guessable from here; its own profile puts it on PATH.
bootstrap_bin='/var/jb/usr/bin:/var/jb/usr/sbin:/var/jb/bin:/var/jb/sbin'

# The same PATH for the unprivileged calls — killall, uiopen and the upload.
run_remote() {
    run_ssh "PATH=\"\$PATH:$bootstrap_bin\"; export PATH; $1"
}

# Keep the password on sudo's stdin, never in the remote command string.
run_sudo() {
    local command="sh -c $(shell_quote "PATH=\"\$PATH:$bootstrap_bin\"; export PATH; $1")"
    if [ -n "$password" ]; then
        printf '%s\n' "$password" | run_ssh "PATH=\"\$PATH:$bootstrap_bin\" sudo -S -p '' $command"
    else
        run_ssh "PATH=\"\$PATH:$bootstrap_bin\" sudo $command"
    fi
}

remote_directory=
cleanup_upload() {
    if [ -n "$remote_directory" ]; then
        run_sudo "rm -f $(shell_quote "$remote_directory/package.deb") && rmdir $(shell_quote "$remote_directory")" || {
            echo "error: could not remove installation temporary: $remote_directory" >&2
            return 1
        }
    fi
}
trap cleanup_upload EXIT
trap 'exit 130' INT
trap 'exit 143' TERM

# This installer updates an existing Fila installation. Derive its actual
# bootstrap from dpkg instead of guessing a rootless or roothide prefix.
remote_directory="$(run_sudo '
    set -eu
    if ! daemon="$(dpkg -L wiki.qaq.fila | grep "/usr/libexec/filad$")" || [ ! -f "$daemon" ]; then
        echo "error: cannot locate the installed Fila daemon; install Fila before using this updater" >&2
        exit 1
    fi
    case "$daemon" in /*) ;; *) echo "error: installed Fila daemon path is not absolute" >&2; exit 1 ;; esac
    install_root="${daemon%/usr/libexec/filad}"
    install_root="$(cd -P "${install_root:-/}" && pwd -P)"
    directory="$(mktemp -d "${install_root%/}/.fila-install.XXXXXXXX")"
    cleanup() { rmdir "$directory"; }
    trap cleanup EXIT
    chown "${SUDO_UID:?}:${SUDO_GID:?}" "$directory"
    chmod 0700 "$directory"
    printf "%s\n" "$directory"
    trap - EXIT
')"
remote_package="$remote_directory/package.deb"
echo "==> copying $(basename "$package") to $user@$host:$port"
# Streamed over the ssh session rather than scp'd: scp speaks sftp now, and a
# jailbroken guest's sftp-server lives in the bootstrap where the system sshd
# does not look for it. The destination is the temporary this script just made
# and chowned to this user.
run_remote "cat > $(shell_quote "$remote_package")" <"$package"

if [[ "${2:-}" == --launch ]]; then
    # Let app-owned work finish cleanup before replacing its executable.
    run_remote 'if killall -0 Fila 2>/dev/null; then
        killall -TERM Fila || exit
        attempts=0
        while killall -0 Fila 2>/dev/null; do
            attempts=$((attempts + 1))
            if [ "$attempts" -ge 20 ]; then echo "error: Fila did not exit" >&2; exit 1; fi
            sleep 0.25
        done
    fi'
fi

# `dpkg -i` runs the package's postinst to boot the daemon
# (`launchctl bootstrap system`); uikittools triggers register the app with
# SpringBoard. Neither step is duplicated here.
#
# The password reaches `sudo -S` down the ssh session's own stdin and is never
# written into the remote command line. Spelling it into a quoted string there
# would make a password containing a quote — or anything else a shell reads —
# into remote code execution as root, which is a peculiar way to lose a device
# you were installing a file manager onto.
echo "==> installing"
run_sudo "dpkg -i $(shell_quote "$remote_package")"

echo "==> installed; removing the copy"
cleanup_upload
remote_directory=

if [[ "${2:-}" == --launch ]]; then
    echo "==> opening Fila"
    run_remote "uiopen --bundleid wiki.qaq.fila"
fi
