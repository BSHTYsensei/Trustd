#!/usr/bin/env python3
"""Collect reviewed offline notices into Hoshino.app/Licenses.json.

The app's build phase collects the repository license, vendored binary
notices and notices from SwiftPM checkouts materialized by Xcode for the
current build destination (including nested notices). Pins without a checkout
are retained in Package.resolved but are not part of that materialized graph.
Missing or changed active notices and unreviewed binary upgrades fail the
build. See Licenses/README.md and Licenses/Compatibility.md.
"""

import argparse
import hashlib
import json
import os
import re
import sys
import subprocess

LICENSE_FILE = re.compile(r"^(LICEN[CS]E|COPYING|NOTICE)([-_.].*)?$", re.IGNORECASE)
PACKAGE_RESOLVED = os.path.join(
    "Hoshino.xcodeproj", "project.xcworkspace", "xcshareddata", "swiftpm", "Package.resolved"
)
# Xcode resolves the app's package graph from the workspace lockfile. A local
# Swift package can also retain an independent lockfile for its standalone
# host-test workflow; that lockfile is not part of this iOS app build graph and
# must not be merged into the app's notice inventory. The workspace lockfile
# still contains pins that Xcode may not materialize for a particular build
# destination, so checkout presence is checked separately below.
SKIPPED_DIRECTORIES = {
    ".git", ".build", ".swiftpm", "Tests", "Test", "Example", "Examples",
    "docs", "Documentation", "node_modules", "Script", "Scripts", "Patches",
}
# Initial label suggestions only. The bundled labels come from review.json;
# keyword matches are never a compatibility decision.
LICENSE_KINDS = [

    ("Apache-2.0", re.compile(r"Apache License,?\s+Version 2\.0", re.IGNORECASE)),
    ("MPL-2.0", re.compile(r"Mozilla Public License,? (Version |v\.? ?)2\.0", re.IGNORECASE)),
    ("OFL-1.1", re.compile(r"SIL OPEN FONT LICENSE", re.IGNORECASE)),
    ("MIT", re.compile(r"MIT License|Permission is hereby granted, free of charge, to any person obtaining a copy\s+of this software", re.IGNORECASE)),
    ("BSD", re.compile(r"Redistribution and use in source and binary forms", re.IGNORECASE)),
    ("ISC", re.compile(r"ISC License|Permission to use, copy, modify, and/or distribute", re.IGNORECASE)),
    ("Unlicense", re.compile(r"This is free and unencumbered software", re.IGNORECASE)),
    ("Zlib", re.compile(r"This software is provided 'as-is', without any express or implied warranty", re.IGNORECASE)),
]


def fail(message):
    # Xcode reads "error:" lines into the issue navigator.
    print(f"error: collect-licenses: {message}", file=sys.stderr)
    sys.exit(1)


def read(path):
    try:
        with open(path, encoding="utf-8", errors="strict") as stream:
            return stream.read().strip("\n") + "\n"
    except UnicodeDecodeError as error:
        fail(f"{path} is not valid UTF-8: {error}")
    except OSError as error:
        fail(f"cannot read {path}: {error}")


def load_json(path):
    try:
        with open(path, encoding="utf-8") as stream:
            return json.load(stream)
    except json.JSONDecodeError as error:
        fail(f"invalid JSON in {path} at line {error.lineno}, column {error.colno}: {error.msg}")
    except UnicodeDecodeError as error:
        fail(f"{path} is not valid UTF-8: {error}")
    except OSError as error:
        fail(f"cannot read {path}: {error}")


def license_kind(text):
    kinds = [kind for kind, pattern in LICENSE_KINDS if pattern.search(text)]
    return " / ".join(kinds) or "Other"


def entry(name, version, url, text):
    kind = license_kind(text)
    item = {"name": name, "license": kind, "url": url, "text": text}
    if version:
        item["version"] = version
    return item


def xcconfig_setting(path, key):
    for line in read(path).splitlines():
        head, sep, value = line.partition("=")
        if sep and head.strip() == key:
            return value.split("//")[0].strip()
    fail(f"{key} is missing from {path}")


def app_entry(project):
    manifest = load_json(os.path.join(project, "manifest.json"))
    if not isinstance(manifest, dict):
        fail("manifest.json must contain a JSON object")
    homepage = manifest.get("homepage", "")
    if not isinstance(homepage, str):
        fail("manifest.json homepage must be a string")
    item = entry(
        "Hoshino",
        xcconfig_setting(os.path.join(project, "Configuration", "Version.xcconfig"), "MARKETING_VERSION"),
        homepage,
        read(os.path.join(project, "LICENSE")),
    )
    item["id"] = "app/Hoshino"
    return item


def checked_relative_path(root, relative, context):
    """Resolve a repository metadata path without permitting traversal."""
    if not isinstance(relative, str) or not relative or os.path.isabs(relative):
        fail(f"{context}: expected a non-empty relative path, got {relative!r}")
    parts = relative.replace("\\", "/").split("/")
    if any(part in ("", ".", "..") for part in parts):
        fail(f"{context}: unsafe relative path {relative!r}")
    root_real = os.path.realpath(root)
    path = os.path.join(root, *parts)
    path_real = os.path.realpath(path)
    try:
        if os.path.commonpath((root_real, path_real)) != root_real:
            fail(f"{context}: path escapes its package checkout: {relative!r}")
    except ValueError:
        fail(f"{context}: path escapes its package checkout: {relative!r}")
    return path


def vendored_entries(project, checkouts):
    root = os.path.join(project, "Licenses")
    entries = []
    for folder in sorted(os.listdir(root)):
        directory = os.path.join(root, folder)
        if not os.path.isdir(directory):
            continue
        notice_path = os.path.join(directory, "notice.json")
        license_path = os.path.join(directory, "LICENSE")
        for required in (notice_path, license_path):
            if not os.path.isfile(required):
                fail(f"Licenses/{folder} lacks {os.path.basename(required)}")
        notice = load_json(notice_path)
        if not isinstance(notice, dict) or not isinstance(notice.get("name"), str) or not notice["name"].strip():
            fail(f"Licenses/{folder}/notice.json must contain a non-empty name")
        version = notice.get("version")
        version_file = notice.get("version_file")
        if version_file:
            path = checked_relative_path(checkouts, version_file, f"Licenses/{folder}")
            if not os.path.isfile(path):
                fail(f"Licenses/{folder}: version_file {version_file} is not in the package checkouts")
            version = read(path).strip()
        url = notice.get("url", "")
        if not isinstance(url, str):
            fail(f"Licenses/{folder}/notice.json has a non-string url")
        item = entry(notice["name"], version, url, read(license_path))
        item["id"] = "vendored/" + folder
        entries.append(item)
    return entries


def normalized_text(data, source):
    try:
        text = data.decode("utf-8")
    except UnicodeDecodeError as error:
        fail(f"{source} is not valid UTF-8: {error}")
    # Match read()'s universal-newline behavior and stable trailing newline.
    return text.replace("\r\n", "\n").replace("\r", "\n").strip("\n") + "\n"


def read_pinned_git_file(checkout, revision, relative_path, package):
    """Read a reviewed notice from the exact pinned Git object if the checkout
    working tree omitted it. Xcode/SwiftPM checkouts retain their Git metadata;
    this avoids weakening the notice inventory merely because a working-tree
    file is unavailable during the build phase.
    """
    safe_parts = relative_path.replace("\\", "/").split("/")
    if relative_path.startswith("/") or any(part in ("", ".", "..") for part in safe_parts):
        fail(f"{package}: unsafe reviewed notice path {relative_path!r}")

    verify_checkout_revision(checkout, package, revision)

    result = subprocess.run(
        ["git", "-C", checkout, "cat-file", "blob", f"{revision}:{relative_path}"],
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        check=False,
    )
    if result.returncode != 0:
        fail(
            f"{package}: reviewed notice {relative_path} is absent from both the checkout and "
            f"pinned Git revision {revision}: {result.stderr.decode('utf-8', errors='replace').strip()}"
        )
    print(f"collect-licenses: restored {package}/{relative_path} from pinned Git object {revision[:12]}")
    return normalized_text(result.stdout, f"{package}/{relative_path}@{revision}")


def checkout_for_pin(checkouts, identity, location):
    """Return the materialized checkout for a lockfile pin, or None.

    Package.resolved is a pin store, not a guarantee that every pin has a
    source checkout for every destination. SwiftPM can retain pins for
    platform-conditional or otherwise inactive packages; Xcode materializes
    only the checkouts needed by the current package graph. A missing checkout
    is therefore not itself an error. A present checkout, however, must be
    the exact pinned revision before its notices are trusted.
    """
    if not isinstance(identity, str) or not identity or identity in (".", "..") or "/" in identity or "\\" in identity:
        fail(f"invalid SwiftPM package identity {identity!r}")

    try:
        names = sorted(os.listdir(checkouts))
    except OSError as error:
        fail(f"cannot list SwiftPM checkouts at {checkouts}: {error}")

    directories = [name for name in names if os.path.isdir(os.path.join(checkouts, name))]
    direct = os.path.join(checkouts, identity)
    if os.path.isdir(direct):
        return direct

    # SwiftPM normalizes identities. Retain a case-insensitive fallback for
    # older checkouts/filesystems, but never guess between ambiguous names.
    matches = [name for name in directories if name.casefold() == identity.casefold()]
    if len(matches) == 1:
        return os.path.join(checkouts, matches[0])
    if len(matches) > 1:
        fail(f"{identity}: ambiguous case-insensitive SwiftPM checkout directories: {matches}")

    url_name = ""
    if isinstance(location, str):
        url_name = location.removesuffix(".git").rstrip("/").rsplit("/", 1)[-1]
    url_matches = [name for name in directories if url_name and name.casefold() == url_name.casefold()]
    if len(url_matches) == 1:
        return os.path.join(checkouts, url_matches[0])
    if len(url_matches) > 1:
        fail(f"{identity}: ambiguous URL-basename checkout directories for {url_name!r}: {url_matches}")

    return None


def resolved_pins(project):
    """Read the lockfile that Xcode uses for this app build.

    Packages/FilaKit/Package.resolved is used by the package's standalone
    host-test workflow. Combining it with the Xcode workspace lockfile can
    falsely require checkouts that do not belong to the current iOS graph.
    """
    absolute_path = os.path.join(project, PACKAGE_RESOLVED)
    if not os.path.isfile(absolute_path):
        fail(f"required Xcode SwiftPM lockfile is missing: {absolute_path}")

    resolved = load_json(absolute_path)
    if not isinstance(resolved, dict):
        fail(f"{PACKAGE_RESOLVED} must contain a JSON object")
    pins = resolved.get("pins")
    if not isinstance(pins, list):
        fail(f"{PACKAGE_RESOLVED} does not contain a valid pins array")

    result = {}
    print(f"collect-licenses: reading {PACKAGE_RESOLVED} ({len(pins)} pins)", flush=True)
    for index, pin in enumerate(pins):
        if not isinstance(pin, dict):
            fail(f"{PACKAGE_RESOLVED}: pin #{index + 1} is not a JSON object")
        identity = pin.get("identity")
        location = pin.get("location")
        kind = pin.get("kind")
        state = pin.get("state")
        if not isinstance(identity, str) or not identity or identity in (".", "..") or "/" in identity or "\\" in identity:
            fail(f"{PACKAGE_RESOLVED}: pin #{index + 1} has an invalid identity {identity!r}")
        if kind != "remoteSourceControl":
            fail(f"{identity}: unsupported SwiftPM pin kind {kind!r}; expected remoteSourceControl")
        if not isinstance(location, str) or not location.strip():
            fail(f"{identity}: Package.resolved has no valid repository location")
        if not isinstance(state, dict):
            fail(f"{identity}: Package.resolved state is not an object")
        revision = state.get("revision")
        if not isinstance(revision, str) or not re.fullmatch(r"[0-9a-fA-F]{40,64}", revision):
            fail(f"{identity}: Package.resolved has an invalid Git revision {revision!r}")
        if identity in result:
            previous = result[identity]
            previous_revision = previous["state"]["revision"]
            if previous_revision.lower() != revision.lower():
                fail(
                    f"{identity} appears more than once in {PACKAGE_RESOLVED} with conflicting revisions: "
                    f"{previous_revision} vs {revision}"
                )
            fail(f"{identity} appears more than once in {PACKAGE_RESOLVED}; regenerate the lockfile")
        result[identity] = pin

    ordered = [result[identity] for identity in sorted(result)]
    print(f"collect-licenses: Xcode workspace inventory ({len(ordered)} unique pins)", flush=True)
    return ordered


def verify_checkout_revision(checkout, identity, revision):
    """Refuse to read notices from a checkout that differs from the lockfile."""
    head = subprocess.run(
        ["git", "-C", checkout, "rev-parse", "HEAD"],
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
        check=False,
    )
    if head.returncode != 0:
        fail(f"{identity}: cannot inspect SwiftPM checkout Git metadata at {checkout}: {head.stderr.strip()}")
    actual_revision = head.stdout.strip()
    if actual_revision.lower() != revision.lower():
        fail(
            f"{identity}: checkout revision {actual_revision} does not match Package.resolved {revision}; "
            "refusing to collect notices from a different dependency revision"
        )


def package_entries(project, checkouts, pins=None):
    if pins is None:
        pins = resolved_pins(project)
    review = load_json(os.path.join(project, "Licenses", "review.json"))
    if not isinstance(review, dict):
        fail("Licenses/review.json must be a JSON object")
    reviewed_notices = review.get("notices")
    if not isinstance(reviewed_notices, dict):
        fail("Licenses/review.json must contain a notices object")

    entries = []
    active_identities = set()
    inactive_identities = set()
    for pin in pins:
        identity = pin["identity"]
        location = pin["location"]
        url = location[:-4] if location.endswith(".git") else location
        package = url.rstrip("/").rsplit("/", 1)[-1]
        version = pin.get("state", {}).get("version") or pin["state"]["revision"]
        revision = pin["state"]["revision"]
        checkout = checkout_for_pin(checkouts, identity, location)
        if checkout is None:
            inactive_identities.add(identity)
            print(
                f"collect-licenses: skipping pinned package {identity} {version or revision[:12]}: "
                "Xcode did not materialize a checkout for this build destination",
                flush=True,
            )
            continue

        verify_checkout_revision(checkout, identity, revision)
        active_identities.add(identity)
        print(
            f"collect-licenses: scanning {identity} {version or revision[:12]} at {checkout}",
            flush=True,
        )

        found = []

        def walk_error(error):
            fail(f"{identity}: cannot scan checkout directory {error.filename}: {error.strerror}")

        checkout_real = os.path.realpath(checkout)
        for directory, subdirectories, files in os.walk(checkout, followlinks=False, onerror=walk_error):
            subdirectories[:] = sorted(d for d in subdirectories if d not in SKIPPED_DIRECTORIES)
            for filename in sorted(files):
                if LICENSE_FILE.match(filename) and not filename.endswith(".template"):
                    candidate = os.path.join(directory, filename)
                    candidate_real = os.path.realpath(candidate)
                    try:
                        if os.path.commonpath((checkout_real, candidate_real)) != checkout_real:
                            fail(f"{identity}: license symlink escapes the package checkout: {candidate}")
                    except ValueError:
                        fail(f"{identity}: license symlink escapes the package checkout: {candidate}")
                    if not os.path.isfile(candidate):
                        fail(f"{identity}: license notice is not a regular file: {candidate}")
                    found.append(candidate)

        # Restore only reviewed paths omitted from the working tree, and only
        # from the exact Git revision just verified above.
        found_ids = {identity + "/" + os.path.relpath(path, checkout).replace(os.sep, "/") for path in found}
        missing_reviewed = sorted(
            notice_id[len(identity) + 1:]
            for notice_id in reviewed_notices
            if notice_id.startswith(identity + "/") and notice_id not in found_ids
        )
        for relative_path in missing_reviewed:
            text = read_pinned_git_file(checkout, revision, relative_path, package)
            relative_directory = os.path.dirname(relative_path) or "."
            stem = os.path.splitext(os.path.basename(relative_path))[0]
            suffix = re.sub(r"^(LICEN[CS]E|COPYING|NOTICE)[-_.]?", "", stem, flags=re.IGNORECASE)
            if relative_directory == ".":
                name = package
            elif suffix:
                name = package + " / " + relative_directory + " / " + suffix
            else:
                name = package + " / " + relative_directory
            item = entry(name, version if relative_directory == "." else None, url, text)
            item["id"] = identity + "/" + relative_path
            entries.append(item)

        # The root license first, nested notices after it.
        found.sort(key=lambda path: (os.path.dirname(path) != checkout, path))
        for path in found:
            relative_directory = os.path.relpath(os.path.dirname(path), checkout)
            relative_path = os.path.relpath(path, checkout).replace(os.sep, "/")
            stem = os.path.splitext(os.path.basename(path))[0]
            suffix = re.sub(r"^(LICEN[CS]E|COPYING|NOTICE)[-_.]?", "", stem, flags=re.IGNORECASE)
            if relative_directory == ".":
                name = package
            elif suffix:
                name = package + " / " + relative_directory + " / " + suffix
            else:
                name = package + " / " + relative_directory
            item = entry(name, version if relative_directory == "." else None, url, read(path))
            item["id"] = identity + "/" + relative_path
            entries.append(item)

        if not found and not missing_reviewed:
            fail(f"{package} has no LICENSE, COPYING, or NOTICE file in its checkout")

    print(
        "collect-licenses: package checkout summary: "
        f"{len(active_identities)} active, {len(inactive_identities)} pinned but not materialized",
        flush=True,
    )
    return entries, active_identities, inactive_identities

def validate_review(project, entries, pins=None, active_identities=None):
    """Require every active notice to be reviewed without requiring inactive pins.

    Xcode's Package.resolved can retain pins that are not checked out for the
    current destination. Those packages are not part of this app build's
    materialized dependency graph and are omitted from this app's license UI.
    A reviewed ID for a package no longer pinned at all remains stale and fails.
    """
    review = load_json(os.path.join(project, "Licenses", "review.json"))
    if not isinstance(review, dict):
        fail("Licenses/review.json must be a JSON object")
    reviewed_notices = review.get("notices")
    binary_revisions = review.get("binaryRevisions")
    if not isinstance(reviewed_notices, dict) or not isinstance(binary_revisions, dict):
        fail("Licenses/review.json must contain notices and binaryRevisions objects")
    for notice_id, record in reviewed_notices.items():
        if not isinstance(notice_id, str) or "/" not in notice_id:
            fail(f"Licenses/review.json contains an invalid notice ID: {notice_id!r}")
        if not isinstance(record, dict) or not isinstance(record.get("sha256"), str) or not re.fullmatch(r"[0-9a-f]{64}", record["sha256"]):
            fail(f"Licenses/review.json has an invalid SHA-256 record for {notice_id}")
        if not isinstance(record.get("license"), str) or not record["license"].strip():
            fail(f"Licenses/review.json has no reviewed license label for {notice_id}")
    for package, revision in binary_revisions.items():
        if not isinstance(package, str) or not package or not isinstance(revision, str) or not re.fullmatch(r"[0-9a-fA-F]{40,64}", revision):
            fail(f"Licenses/review.json has an invalid binary revision record for {package!r}")

    if pins is None:
        pins = resolved_pins(project)
    if active_identities is None:
        active_identities = {pin["identity"] for pin in pins}
    pinned_identities = {pin["identity"] for pin in pins}
    revisions = {pin["identity"]: pin["state"]["revision"] for pin in pins}
    for package, revision in binary_revisions.items():
        if revisions.get(package, "").lower() != revision.lower():
            fail(f"{package} binary changed or is no longer pinned; review its bundled components and update Licenses/review.json")

    actual = {item["id"] for item in entries}
    # App and vendored notices are always present. For package notices, compare
    # only active checkouts; allow historical reviewed notices for still-pinned
    # but unmaterialized packages to remain in the review file. A review entry
    # whose identity is no longer pinned stays in expected and therefore fails.
    expected = set()
    for notice_id in reviewed_notices:
        identity = notice_id.split("/", 1)[0]
        if identity in ("app", "vendored") or identity in active_identities or identity not in pinned_identities:
            expected.add(notice_id)
    if len(actual) != len(entries) or actual != expected:
        fail(f"notice inventory changed; added={sorted(actual - expected)}, removed={sorted(expected - actual)}")

    for item in entries:
        reviewed = reviewed_notices[item["id"]]
        if not isinstance(reviewed, dict) or not isinstance(reviewed.get("sha256"), str):
            fail(f"Licenses/review.json has an invalid review record for {item['id']}")
        digest = hashlib.sha256(item["text"].encode("utf-8")).hexdigest()
        if reviewed["sha256"] != digest:
            fail(f"{item['id']} license text changed; review before updating its hash")
        label = reviewed.get("license")
        if not isinstance(label, str) or not label.strip():
            fail(f"Licenses/review.json has no reviewed license label for {item['id']}")
        item["license"] = label

def find_source_packages(build_dir):
    """Find the SourcePackages sibling of Xcode's Build directory.

    BUILD_DIR may be Build/Products or a deeper configuration-specific
    products directory. Walk all ancestors and report every attempted path so
    a CI failure can be diagnosed from the build log without guesswork.
    """
    directory = os.path.abspath(build_dir)
    searched = []
    while True:
        candidate = os.path.join(directory, "SourcePackages")
        searched.append(candidate)
        if os.path.isdir(os.path.join(candidate, "checkouts")):
            return candidate
        parent = os.path.dirname(directory)
        if parent == directory:
            break
        directory = parent
    fail(
        f"cannot find SourcePackages/checkouts for BUILD_DIR={os.path.abspath(build_dir)}; "
        f"searched: {searched}. Pass -clonedSourcePackagesDirPath under the same DerivedData "
        "directory and ensure Xcode resolves packages before running Collect Licenses."
    )


def resolve_source_packages(build_dir, source_packages=None):
    """Validate an explicitly pinned SwiftPM directory or discover Xcode's default."""
    if source_packages:
        path = os.path.abspath(source_packages)
        checkouts = os.path.join(path, "checkouts")
        if not os.path.isdir(checkouts):
            try:
                children = sorted(os.listdir(path)) if os.path.isdir(path) else []
            except OSError as error:
                fail(f"cannot inspect SwiftPM directory {path}: {error}")
            fail(
                f"SwiftPM SourcePackages directory is missing checkouts: {path}; "
                f"contents={children or '<directory missing or empty>'}. "
                "Make sure xcodebuild receives -clonedSourcePackagesDirPath pointing here."
            )
        return path
    return find_source_packages(build_dir)


def main():
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--project", required=True, help="the repository root (SRCROOT)")
    parser.add_argument("--build-dir", required=True, help="Xcode's BUILD_DIR, used to find SourcePackages")
    parser.add_argument(
        "--source-packages",
        help="explicit Xcode -clonedSourcePackagesDirPath; preferred over BUILD_DIR discovery",
    )
    parser.add_argument("--output", required=True, help="where to write Licenses.json")
    arguments = parser.parse_args()

    print(f"collect-licenses: Python {sys.version.split()[0]}", flush=True)
    print(f"collect-licenses: project={os.path.abspath(arguments.project)}", flush=True)
    print(f"collect-licenses: BUILD_DIR={os.path.abspath(arguments.build_dir)}", flush=True)
    source_packages = resolve_source_packages(arguments.build_dir, arguments.source_packages)
    checkouts = os.path.join(source_packages, "checkouts")
    print(f"collect-licenses: using SwiftPM checkouts at {checkouts}", flush=True)
    pins = resolved_pins(arguments.project)
    entries = [app_entry(arguments.project)]
    entries += vendored_entries(arguments.project, checkouts)
    package_entries_result, active_identities, inactive_identities = package_entries(
        arguments.project, checkouts, pins=pins
    )
    entries += package_entries_result
    validate_review(arguments.project, entries, pins=pins, active_identities=active_identities)

    output = os.path.abspath(arguments.output)
    os.makedirs(os.path.dirname(output), exist_ok=True)
    temporary = output + f".tmp.{os.getpid()}"
    try:
        with open(temporary, "w", encoding="utf-8") as f:
            json.dump(entries, f, ensure_ascii=False, indent=2)
            f.write("\n")
        os.replace(temporary, output)
    finally:
        try:
            os.unlink(temporary)
        except FileNotFoundError:
            pass
    print(f"collect-licenses: {len(entries)} licenses -> {arguments.output}", flush=True)


if __name__ == "__main__":
    try:
        main()
    except (OSError, UnicodeError, KeyError, TypeError, ValueError, subprocess.SubprocessError) as error:
        fail(f"unexpected collector error: {error}")
