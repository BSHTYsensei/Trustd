#!/usr/bin/env python3
"""Collect reviewed offline notices into Hoshino.app/Licenses.json.

The app's build phase collects the repository license, vendored binary
notices and resolved Swift checkouts (including nested notices). Missing notices, changed text, and unreviewed binary upgrades
fail the build. See Licenses/README.md and Licenses/Compatibility.md.
"""

import argparse
import hashlib
import json
import os
import re
import sys
import subprocess

LICENSE_FILE = re.compile(r"^(LICEN[CS]E|COPYING|NOTICE)([-_.].*)?$", re.IGNORECASE)
PACKAGE_RESOLVED = os.path.join(
    "Hoshino.xcodeproj", "project.xcworkspace", "xcshareddata", "swiftpm", "Package.resolved"
)
SKIPPED_DIRECTORIES = {
    ".git", ".build", ".swiftpm", "Tests", "Test", "Example", "Examples",
    "docs", "Documentation", "node_modules", "Script", "Scripts", "Patches",
}
# Initial label suggestions only. The bundled labels come from review.json;
# keyword matches are never a compatibility decision.
LICENSE_KINDS = [

    ("Apache-2.0", re.compile(r"Apache License,?\s+Version 2\.0", re.IGNORECASE)),
    ("MPL-2.0", re.compile(r"Mozilla Public License,? (Version |v\.? ?)2\.0", re.IGNORECASE)),
    ("OFL-1.1", re.compile(r"SIL OPEN FONT LICENSE", re.IGNORECASE)),
    ("MIT", re.compile(r"MIT License|Permission is hereby granted, free of charge, to any person obtaining a copy\s+of this software", re.IGNORECASE)),
    ("BSD", re.compile(r"Redistribution and use in source and binary forms", re.IGNORECASE)),
    ("ISC", re.compile(r"ISC License|Permission to use, copy, modify, and/or distribute", re.IGNORECASE)),
    ("Unlicense", re.compile(r"This is free and unencumbered software", re.IGNORECASE)),
    ("Zlib", re.compile(r"This software is provided 'as-is', without any express or implied warranty", re.IGNORECASE)),
]


def fail(message):
    # Xcode reads "error:" lines into the issue navigator.
    print(f"error: collect-licenses: {message}", file=sys.stderr)
    sys.exit(1)


def read(path):
    try:
        with open(path, encoding="utf-8", errors="strict") as stream:
            return stream.read().strip("\n") + "\n"
    except UnicodeDecodeError as error:
        fail(f"{path} is not valid UTF-8: {error}")
    except OSError as error:
        fail(f"cannot read {path}: {error}")


def load_json(path):
    try:
        with open(path, encoding="utf-8") as stream:
            return json.load(stream)
    except json.JSONDecodeError as error:
        fail(f"invalid JSON in {path} at line {error.lineno}, column {error.colno}: {error.msg}")
    except UnicodeDecodeError as error:
        fail(f"{path} is not valid UTF-8: {error}")
    except OSError as error:
        fail(f"cannot read {path}: {error}")


def license_kind(text):
    kinds = [kind for kind, pattern in LICENSE_KINDS if pattern.search(text)]
    return " / ".join(kinds) or "Other"


def entry(name, version, url, text):
    kind = license_kind(text)
    item = {"name": name, "license": kind, "url": url, "text": text}
    if version:
        item["version"] = version
    return item


def xcconfig_setting(path, key):
    for line in read(path).splitlines():
        head, sep, value = line.partition("=")
        if sep and head.strip() == key:
            return value.split("//")[0].strip()
    fail(f"{key} is missing from {path}")


def app_entry(project):
    manifest = load_json(os.path.join(project, "manifest.json"))
    item = entry(
        "Hoshino",
        xcconfig_setting(os.path.join(project, "Configuration", "Version.xcconfig"), "MARKETING_VERSION"),
        manifest.get("homepage", ""),
        read(os.path.join(project, "LICENSE")),
    )
    item["id"] = "app/Hoshino"
    return item


def vendored_entries(project, checkouts):
    root = os.path.join(project, "Licenses")
    entries = []
    for folder in sorted(os.listdir(root)):
        directory = os.path.join(root, folder)
        if not os.path.isdir(directory):
            continue
        notice_path = os.path.join(directory, "notice.json")
        license_path = os.path.join(directory, "LICENSE")
        for required in (notice_path, license_path):
            if not os.path.isfile(required):
                fail(f"Licenses/{folder} lacks {os.path.basename(required)}")
        notice = load_json(notice_path)
        version = notice.get("version")
        version_file = notice.get("version_file")
        if version_file:
            path = os.path.join(checkouts, version_file)
            if not os.path.isfile(path):
                fail(f"Licenses/{folder}: version_file {version_file} is not in the package checkouts")
            version = read(path).strip()
        item = entry(notice["name"], version, notice.get("url", ""), read(license_path))
        item["id"] = "vendored/" + folder
        entries.append(item)
    return entries


def normalized_text(data, source):
    try:
        text = data.decode("utf-8")
    except UnicodeDecodeError as error:
        fail(f"{source} is not valid UTF-8: {error}")
    # Match read()'s universal-newline behavior and stable trailing newline.
    return text.replace("\r\n", "\n").replace("\r", "\n").strip("\n") + "\n"


def read_pinned_git_file(checkout, revision, relative_path, package):
    """Read a reviewed notice from the exact pinned Git object if the checkout
    working tree omitted it. Xcode/SwiftPM checkouts retain their Git metadata;
    this avoids weakening the notice inventory merely because a working-tree
    file is unavailable during the build phase.
    """
    safe_parts = relative_path.replace("\\", "/").split("/")
    if relative_path.startswith("/") or any(part in ("", ".", "..") for part in safe_parts):
        fail(f"{package}: unsafe reviewed notice path {relative_path!r}")

    head = subprocess.run(
        ["git", "-C", checkout, "rev-parse", "HEAD"],
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
        check=False,
    )
    if head.returncode != 0:
        fail(f"{package}: cannot inspect SwiftPM checkout Git metadata at {checkout}: {head.stderr.strip()}")
    actual_revision = head.stdout.strip()
    if actual_revision != revision:
        fail(
            f"{package}: checkout revision {actual_revision} does not match Package.resolved {revision}; "
            "refusing to restore a notice from a different dependency revision"
        )

    result = subprocess.run(
        ["git", "-C", checkout, "cat-file", "blob", f"{revision}:{relative_path}"],
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        check=False,
    )
    if result.returncode != 0:
        fail(
            f"{package}: reviewed notice {relative_path} is absent from both the checkout and "
            f"pinned Git revision {revision}: {result.stderr.decode('utf-8', errors='replace').strip()}"
        )
    print(f"collect-licenses: restored {package}/{relative_path} from pinned Git object {revision[:12]}")
    return normalized_text(result.stdout, f"{package}/{relative_path}@{revision}")


def checkout_for_pin(checkouts, identity, location):
    """Resolve the checkout by SwiftPM identity, not the URL's display casing.

    SwiftPM names checkout directories with the normalized package identity.
    Repository URLs often preserve mixed case (for example, AlertController),
    while Package.resolved records alertcontroller. Comparing the URL basename
    directly is therefore incorrect on case-sensitive APFS volumes.
    """
    if not isinstance(identity, str) or not identity or identity in (".", "..") or "/" in identity or "\\" in identity:
        fail(f"invalid SwiftPM package identity {identity!r}")

    direct = os.path.join(checkouts, identity)
    if os.path.isdir(direct):
        return direct

    try:
        names = sorted(os.listdir(checkouts))
    except OSError as error:
        fail(f"cannot list SwiftPM checkouts at {checkouts}: {error}")

    # Accommodate a checkout directory whose filesystem casing differs from
    # the normalized identity, while refusing ambiguous case-folded matches.
    matches = [
        name for name in names
        if name.casefold() == identity.casefold() and os.path.isdir(os.path.join(checkouts, name))
    ]
    if len(matches) == 1:
        return os.path.join(checkouts, matches[0])
    if len(matches) > 1:
        fail(f"{identity}: ambiguous case-insensitive SwiftPM checkout directories: {matches}")

    url_name = ""
    if isinstance(location, str):
        url_name = location.removesuffix(".git").rstrip("/").rsplit("/", 1)[-1]
    url_matches = [
        name for name in names
        if url_name and name.casefold() == url_name.casefold() and os.path.isdir(os.path.join(checkouts, name))
    ]
    if len(url_matches) == 1:
        return os.path.join(checkouts, url_matches[0])

    available = [name for name in names if os.path.isdir(os.path.join(checkouts, name))]
    fail(
        f"{identity} is pinned in Package.resolved but its SwiftPM checkout was not found. "
        f"Expected identity directory {direct}; URL basename is {url_name or '<unavailable>'}. "
        f"Available checkouts: {available or '<none>'}. "
        "Ensure Xcode has resolved packages into this DerivedData directory."
    )


def package_entries(project, checkouts):
    resolved_path = os.path.join(project, PACKAGE_RESOLVED)
    resolved = load_json(resolved_path)
    review = load_json(os.path.join(project, "Licenses", "review.json"))
    reviewed_ids = set(review["notices"])
    entries = []
    for pin in sorted(resolved["pins"], key=lambda pin: pin["identity"]):
        identity = pin["identity"]
        location = pin["location"]
        if not isinstance(location, str) or not location:
            fail(f"{identity}: Package.resolved has no valid repository location")
        url = location[:-4] if location.endswith(".git") else location
        package = url.rstrip("/").rsplit("/", 1)[-1]
        version = pin.get("state", {}).get("version") or pin.get("state", {}).get("revision")
        revision = pin.get("state", {}).get("revision")
        if not isinstance(revision, str) or not revision:
            fail(f"{identity}: Package.resolved has no pinned Git revision")
        checkout = checkout_for_pin(checkouts, identity, location)

        found = []
        for directory, subdirectories, files in os.walk(checkout, followlinks=False):
            subdirectories[:] = sorted(d for d in subdirectories if d not in SKIPPED_DIRECTORIES)
            for filename in sorted(files):
                if LICENSE_FILE.match(filename) and not filename.endswith(".template"):
                    found.append(os.path.join(directory, filename))

        # Xcode can leave a reviewed notice out of a checkout's working tree
        # even though the exact pinned commit remains in its local Git object
        # database. Restore only IDs explicitly listed in review.json; any
        # genuinely new notice still fails validate_review below.
        found_ids = {identity + "/" + os.path.relpath(path, checkout).replace(os.sep, "/") for path in found}
        missing_reviewed = sorted(
            notice_id[len(identity) + 1:]
            for notice_id in reviewed_ids
            if notice_id.startswith(identity + "/") and notice_id not in found_ids
        )
        for relative_path in missing_reviewed:
            text = read_pinned_git_file(checkout, revision, relative_path, package)
            relative_directory = os.path.dirname(relative_path) or "."
            stem = os.path.splitext(os.path.basename(relative_path))[0]
            suffix = re.sub(r"^(LICEN[CS]E|COPYING|NOTICE)[-_.]?", "", stem, flags=re.IGNORECASE)
            if relative_directory == ".":
                name = package
            elif suffix:
                name = package + " / " + relative_directory + " / " + suffix
            else:
                name = package + " / " + relative_directory
            item = entry(name, version if relative_directory == "." else None, url, text)
            item["id"] = identity + "/" + relative_path
            entries.append(item)

        # The root license first, nested notices after it, so a package reads
        # as itself and then what it vendors.
        found.sort(key=lambda path: (os.path.dirname(path) != checkout, path))
        for path in found:
            relative_directory = os.path.relpath(os.path.dirname(path), checkout)
            relative_path = os.path.relpath(path, checkout).replace(os.sep, "/")
            stem = os.path.splitext(os.path.basename(path))[0]
            suffix = re.sub(r"^(LICEN[CS]E|COPYING|NOTICE)[-_.]?", "", stem, flags=re.IGNORECASE)
            if relative_directory == ".":
                name = package
            elif suffix:
                name = package + " / " + relative_directory + " / " + suffix
            else:
                name = package + " / " + relative_directory
            item = entry(name, version if relative_directory == "." else None, url, read(path))
            item["id"] = identity + "/" + relative_path
            entries.append(item)

        if not found and not missing_reviewed:
            fail(f"{package} has no LICENSE, COPYING, or NOTICE file in its checkout")
    return entries


def validate_review(project, entries):
    """Changed/new notices and binary upgrades require a fresh human review."""
    review = load_json(os.path.join(project, "Licenses", "review.json"))
    pins = load_json(os.path.join(project, PACKAGE_RESOLVED))["pins"]
    revisions = {pin["identity"]: pin["state"]["revision"] for pin in pins}
    for package, revision in review["binaryRevisions"].items():
        if revisions.get(package) != revision:
            fail(f"{package} binary changed; review its bundled components and update Licenses/review.json")
    actual = {item["id"] for item in entries}
    expected = set(review["notices"])
    if len(actual) != len(entries) or actual != expected:
        fail(f"notice inventory changed; added={sorted(actual - expected)}, removed={sorted(expected - actual)}")
    for item in entries:
        reviewed = review["notices"][item["id"]]
        digest = hashlib.sha256(item["text"].encode("utf-8")).hexdigest()
        if reviewed["sha256"] != digest:
            fail(f"{item['id']} license text changed; review before updating its hash")
        item["license"] = reviewed["license"]


def find_source_packages(build_dir):
    """Find the SourcePackages sibling of Xcode's Build directory.

    BUILD_DIR may be Build/Products or a deeper configuration-specific
    products directory. Walk all ancestors and report every attempted path so
    a CI failure can be diagnosed from the build log without guesswork.
    """
    directory = os.path.abspath(build_dir)
    searched = []
    while True:
        candidate = os.path.join(directory, "SourcePackages")
        searched.append(candidate)
        if os.path.isdir(os.path.join(candidate, "checkouts")):
            return candidate
        parent = os.path.dirname(directory)
        if parent == directory:
            break
        directory = parent
    fail(
        f"cannot find SourcePackages/checkouts for BUILD_DIR={os.path.abspath(build_dir)}; "
        f"searched: {searched}. Xcode must resolve Swift packages in the same DerivedData directory."
    )


def main():
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--project", required=True, help="the repository root (SRCROOT)")
    parser.add_argument("--build-dir", required=True, help="Xcode's BUILD_DIR, used to find SourcePackages")
    parser.add_argument("--output", required=True, help="where to write Licenses.json")
    arguments = parser.parse_args()

    source_packages = find_source_packages(arguments.build_dir)
    checkouts = os.path.join(source_packages, "checkouts")
    print(f"collect-licenses: using SwiftPM checkouts at {checkouts}")
    entries = [app_entry(arguments.project)]
    entries += vendored_entries(arguments.project, checkouts)
    entries += package_entries(arguments.project, checkouts)
    validate_review(arguments.project, entries)

    os.makedirs(os.path.dirname(arguments.output), exist_ok=True)
    with open(arguments.output, "w", encoding="utf-8") as f:
        json.dump(entries, f, ensure_ascii=False, indent=2)
        f.write("\n")
    print(f"collect-licenses: {len(entries)} licenses -> {arguments.output}")


if __name__ == "__main__":
    try:
        main()
    except (OSError, UnicodeError, KeyError, TypeError, ValueError, subprocess.SubprocessError) as error:
        fail(f"unexpected collector error: {error}")
