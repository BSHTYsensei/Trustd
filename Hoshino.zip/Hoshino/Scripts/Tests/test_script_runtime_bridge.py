"""Regression coverage for the iOS-safe external script process launcher."""

from __future__ import annotations

import shutil
import subprocess
import tempfile
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[2]
BRIDGE = ROOT / "Hoshino/Services/Scripts/ScriptRuntimeBridge.mm"
HEADER_DIR = BRIDGE.parent
RELEASE_CONFIG = ROOT / "Configuration/Release.xcconfig"


class ScriptRuntimeBridgeTests(unittest.TestCase):
    def test_release_build_uses_speed_optimizations_without_unchecked_mode(self) -> None:
        settings = RELEASE_CONFIG.read_text(encoding="utf-8")
        for setting in (
            "SWIFT_OPTIMIZATION_LEVEL = -O",
            "SWIFT_COMPILATION_MODE = wholemodule",
            "SWIFT_LTO = YES_THIN",
            "GCC_OPTIMIZATION_LEVEL = 3",
            "LLVM_LTO = YES_THIN",
            "DEAD_CODE_STRIPPING = YES",
            "ENABLE_TESTABILITY = NO",
        ):
            with self.subTest(setting=setting):
                self.assertIn(setting, settings)
        self.assertNotIn("-Ounchecked", settings)

    def test_ios_spawn_preflight_runs_before_xcodebuild(self) -> None:
        makefile = (ROOT / "Makefile").read_text(encoding="utf-8")
        check_target = makefile.split("\ncheck:\n", 1)[1].split("\nharness:", 1)[0]
        self.assertIn("Scripts/check-ios-spawn-apis.py", check_target)
        self.assertLess(
            check_target.index("check-ios-spawn-apis.py"),
            check_target.index("xcodebuild is required"),
        )

    def test_working_directory_is_set_without_unavailable_spawn_extension(self) -> None:
        source = BRIDGE.read_text(encoding="utf-8")
        unavailable_api = "posix_spawn_file_actions_add" + "chdir_np"
        self.assertNotRegex(
            source,
            rf"\b{unavailable_api}\s*\(",
            "The working-directory spawn extension is unavailable when targeting iOS.",
        )
        self.assertIn('"CDPATH= cd \\"$1\\" || exit 126; shift; exec \\"$@\\""', source)

        compiler = shutil.which("clang++")
        if compiler is None:
            self.skipTest("clang++ is unavailable; source-level iOS API guard passed")

        with tempfile.TemporaryDirectory(prefix="hoshino-script-runtime-") as temporary:
            root = Path(temporary)
            script_directory = root / "script folder ; $HOME"
            script_directory.mkdir()
            (script_directory / "relative data.txt").write_text("relative-resource-ok\n", encoding="utf-8")
            script = script_directory / "run script.sh"
            script.write_text(
                "printf 'working-directory=%s\\n' \"$PWD\"\n"
                "cat 'relative data.txt'\n",
                encoding="utf-8",
            )

            driver = root / "driver.cpp"
            driver.write_text(
                '#include "ScriptRuntimeBridge.h"\n'
                "#include <cerrno>\n"
                "#include <cstdio>\n"
                "#include <cstdlib>\n"
                "#include <vector>\n"
                "int main(int argc, char **argv) {\n"
                "  if (argc != 4) return 90;\n"
                "  const unsigned int timeout = static_cast<unsigned int>(std::strtoul(argv[3], nullptr, 10));\n"
                "  std::vector<char> output(4U * 1024U * 1024U, 0);\n"
                "  const int result = HoshinoRunExternalScript(argv[1], argv[2], timeout, output.data(), output.size());\n"
                "  std::fputs(output.data(), stdout);\n"
                "  if (result == -ETIMEDOUT) return 124;\n"
                "  return result < 0 ? 125 : result;\n"
                "}\n",
                encoding="utf-8",
            )
            executable = root / "script-runtime-test"
            compile_result = subprocess.run(
                [
                    compiler,
                    "-std=c++17",
                    "-Wall",
                    "-Wextra",
                    "-Werror",
                    "-x",
                    "c++",
                    str(BRIDGE),
                    str(driver),
                    "-I",
                    str(HEADER_DIR),
                    "-o",
                    str(executable),
                ],
                text=True,
                capture_output=True,
                check=False,
            )
            self.assertEqual(
                compile_result.returncode,
                0,
                compile_result.stdout + compile_result.stderr,
            )

            def run_bridge(target: Path, timeout_seconds: int = 10) -> subprocess.CompletedProcess[str]:
                return subprocess.run(
                    [str(executable), "sh", str(target), str(timeout_seconds)],
                    text=True,
                    capture_output=True,
                    check=False,
                    timeout=20,
                )

            run_result = run_bridge(script)
            self.assertEqual(run_result.returncode, 0, run_result.stdout + run_result.stderr)
            self.assertIn(f"working-directory={script_directory}\n", run_result.stdout)
            self.assertIn("relative-resource-ok\n", run_result.stdout)

            # Both stdout and stderr are merged, and interpreter exit statuses
            # survive the Objective-C++ bridge unchanged.
            failure = script_directory / "failure.sh"
            failure.write_text("printf 'stdout-marker\n'\nprintf 'stderr-marker\n' >&2\nexit 7\n", encoding="utf-8")
            failed_result = run_bridge(failure)
            self.assertEqual(failed_result.returncode, 7, failed_result.stdout + failed_result.stderr)
            self.assertIn("stdout-marker\n", failed_result.stdout)
            self.assertIn("stderr-marker\n", failed_result.stdout)

            # A live child must be killed at the timeout and the caller must
            # receive a stable timeout result instead of hanging indefinitely.
            hanging = script_directory / "timeout.sh"
            hanging.write_text("sleep 5\n", encoding="utf-8")
            timeout_result = run_bridge(hanging, timeout_seconds=1)
            self.assertEqual(timeout_result.returncode, 124, timeout_result.stdout + timeout_result.stderr)
            self.assertIn("Script timed out", timeout_result.stdout)

            # A detached descendant keeps the pipe open after the script leader
            # exits. The deadline must still terminate that process group.
            background = script_directory / "background.sh"
            background.write_text("sleep 5 &\nprintf 'background-started\n'\n", encoding="utf-8")
            background_result = run_bridge(background, timeout_seconds=1)
            self.assertEqual(background_result.returncode, 124, background_result.stdout + background_result.stderr)
            self.assertIn("background-started\n", background_result.stdout)

            # Output capture is bounded even when a script is deliberately noisy.
            noisy = script_directory / "noisy.sh"
            noisy.write_text("i=0\nwhile [ $i -lt 5000 ]; do printf '%1024s' x; i=$((i + 1)); done\n", encoding="utf-8")
            noisy_result = run_bridge(noisy)
            self.assertEqual(noisy_result.returncode, 0, noisy_result.stdout + noisy_result.stderr)
            self.assertIn("Output truncated after 4 MiB", noisy_result.stdout)
            self.assertLess(len(noisy_result.stdout.encode("utf-8")), 4 * 1024 * 1024)


if __name__ == "__main__":
    unittest.main()
