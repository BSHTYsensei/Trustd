"""Regression coverage for the iOS-safe external script process launcher."""

from __future__ import annotations

import shutil
import subprocess
import tempfile
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[2]
BRIDGE = ROOT / "Hoshino/Services/Scripts/ScriptRuntimeBridge.mm"
HEADER_DIR = BRIDGE.parent
RELEASE_CONFIG = ROOT / "Configuration/Release.xcconfig"


class ScriptRuntimeBridgeTests(unittest.TestCase):
    def test_release_build_uses_speed_optimizations_without_unchecked_mode(self) -> None:
        settings = RELEASE_CONFIG.read_text(encoding="utf-8")
        for setting in (
            "SWIFT_OPTIMIZATION_LEVEL = -O",
            "SWIFT_COMPILATION_MODE = wholemodule",
            "SWIFT_LTO = YES_THIN",
            "GCC_OPTIMIZATION_LEVEL = 3",
            "LLVM_LTO = YES_THIN",
            "DEAD_CODE_STRIPPING = YES",
            "ENABLE_TESTABILITY = NO",
        ):
            with self.subTest(setting=setting):
                self.assertIn(setting, settings)
        self.assertNotIn("-Ounchecked", settings)

    def test_ios_spawn_preflight_runs_before_xcodebuild(self) -> None:
        makefile = (ROOT / "Makefile").read_text(encoding="utf-8")
        check_target = makefile.split("\ncheck:\n", 1)[1].split("\nharness:", 1)[0]
        self.assertIn("Scripts/check-ios-spawn-apis.py", check_target)
        self.assertLess(
            check_target.index("check-ios-spawn-apis.py"),
            check_target.index("xcodebuild is required"),
        )

    def test_working_directory_is_set_without_unavailable_spawn_extension(self) -> None:
        source = BRIDGE.read_text(encoding="utf-8")
        unavailable_api = "posix_spawn_file_actions_add" + "chdir_np"
        self.assertNotRegex(
            source,
            rf"\b{unavailable_api}\s*\(",
            "The working-directory spawn extension is unavailable when targeting iOS.",
        )
        self.assertIn('"CDPATH= cd \\"$1\\" || exit 126; shift; exec \\"$@\\""', source)

        compiler = shutil.which("clang++")
        if compiler is None:
            self.skipTest("clang++ is unavailable; source-level iOS API guard passed")

        with tempfile.TemporaryDirectory(prefix="hoshino-script-runtime-") as temporary:
            root = Path(temporary)
            script_directory = root / "script folder ; $HOME"
            script_directory.mkdir()
            (script_directory / "relative data.txt").write_text("relative-resource-ok\n", encoding="utf-8")
            script = script_directory / "run script.sh"
            script.write_text(
                "printf 'working-directory=%s\\n' \"$PWD\"\n"
                "cat 'relative data.txt'\n",
                encoding="utf-8",
            )

            driver = root / "driver.cpp"
            driver.write_text(
                '#include "ScriptRuntimeBridge.h"\n'
                "#include <cstdio>\n"
                "int main(int argc, char **argv) {\n"
                "  if (argc != 2) return 90;\n"
                "  char output[4096]{};\n"
                "  const int result = HoshinoRunExternalScript(\"sh\", argv[1], 10, output, sizeof(output));\n"
                "  std::fputs(output, stdout);\n"
                "  return result;\n"
                "}\n",
                encoding="utf-8",
            )
            executable = root / "script-runtime-test"
            compile_result = subprocess.run(
                [
                    compiler,
                    "-std=c++17",
                    "-Wall",
                    "-Wextra",
                    "-Werror",
                    "-x",
                    "c++",
                    str(BRIDGE),
                    str(driver),
                    "-I",
                    str(HEADER_DIR),
                    "-o",
                    str(executable),
                ],
                text=True,
                capture_output=True,
                check=False,
            )
            self.assertEqual(
                compile_result.returncode,
                0,
                compile_result.stdout + compile_result.stderr,
            )

            run_result = subprocess.run(
                [str(executable), str(script)],
                text=True,
                capture_output=True,
                check=False,
                timeout=15,
            )
            self.assertEqual(run_result.returncode, 0, run_result.stdout + run_result.stderr)
            self.assertIn(f"working-directory={script_directory}\n", run_result.stdout)
            self.assertIn("relative-resource-ok\n", run_result.stdout)


if __name__ == "__main__":
    unittest.main()
