"""Catch accidental truncation of the backend-module contract before SwiftPM runs."""

from pathlib import Path
import re
import unittest


ROOT = Path(__file__).resolve().parents[2]
SOURCE = ROOT / "Packages/FilaKit/Sources/FilaBackendKit/BackendModule.swift"


class BackendModuleContractSourceTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.text = SOURCE.read_text(encoding="utf-8")

    def test_registry_types_are_declared(self):
        declarations = (
            r"public\s+struct\s+BackendResolver\b",
            r"struct\s+BackendFactory\b",
            r"public\s+struct\s+BackendModuleIdentity\b",
            r"public\s+enum\s+BackendModuleError\b",
        )
        for declaration in declarations:
            with self.subTest(declaration=declaration):
                self.assertRegex(self.text, declaration)

    def test_resolver_exposes_provider_and_backend_lookup(self):
        resolver = self.text.split("public struct BackendResolver", 1)[1]
        resolver = resolver.split("/// Deferred backend construction", 1)[0]
        self.assertIn("func provider<Provider>", resolver)
        self.assertIn("func backend(_ id: BackendID)", resolver)

    def test_module_identity_keeps_discovery_fields(self):
        identity = self.text.split("public struct BackendModuleIdentity", 1)[1]
        identity = identity.split("public enum BackendModuleError", 1)[0]
        for field in ("bundleIdentifier", "frameworkName", "displayNameKey", "entryClassName"):
            with self.subTest(field=field):
                self.assertIn(field, identity)

    def test_removed_remote_connection_setup_contract_stays_removed(self):
        self.assertNotIn("BackendConnectionSetup", self.text)
        self.assertNotIn("connectionSetups", self.text)


if __name__ == "__main__":
    unittest.main()
