"""Tests for reproducible third-party license collection."""

from __future__ import annotations

import hashlib
import contextlib
import io
import importlib.util
import json
import shutil
import subprocess
import tempfile
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[2]
SCRIPT = ROOT / "Scripts/collect-licenses.py"
SPEC = importlib.util.spec_from_file_location("collect_licenses", SCRIPT)
assert SPEC and SPEC.loader
COLLECT = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(COLLECT)


class CollectLicensesTests(unittest.TestCase):
    def setUp(self) -> None:
        if shutil.which("git") is None:
            self.skipTest("git is required to test pinned notice recovery")
        self.temporary = tempfile.TemporaryDirectory(prefix="hoshino-license-test-")
        self.root = Path(self.temporary.name)
        self.project = self.root / "project"
        self.checkouts = self.root / "SourcePackages" / "checkouts"
        self.checkout = self.checkouts / "swift-nio"
        self.checkout.mkdir(parents=True)
        (self.project / "Hoshino.xcodeproj/project.xcworkspace/xcshareddata/swiftpm").mkdir(parents=True)
        (self.project / "Licenses").mkdir(parents=True)

    def tearDown(self) -> None:
        self.temporary.cleanup()

    def git(self, *arguments: str) -> str:
        result = subprocess.run(
            ["git", *arguments],
            cwd=self.checkout,
            text=True,
            capture_output=True,
            check=False,
        )
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        return result.stdout.strip()

    @staticmethod
    def normalized_hash(text: str) -> str:
        normalized = text.replace("\r\n", "\n").replace("\r", "\n").strip("\n") + "\n"
        return hashlib.sha256(normalized.encode("utf-8")).hexdigest()

    def make_package_commit(self) -> tuple[str, dict[str, str]]:
        notices = {
            "LICENSE.txt": "Pinned root license text\n",
            "NOTICE.txt": "Pinned attribution notice\n",
            "Sources/CNIOLLHTTP/LICENSE": "Pinned nested MIT license\n",
        }
        for relative, text in notices.items():
            path = self.checkout / relative
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(text, encoding="utf-8")
        self.git("init", "-q")
        self.git("config", "user.email", "test@example.invalid")
        self.git("config", "user.name", "License Collector Test")
        self.git("add", ".")
        self.git("commit", "-qm", "Pinned package sources")
        revision = self.git("rev-parse", "HEAD")
        return revision, notices

    def write_manifests(
        self,
        revision: str,
        notices: dict[str, str],
        identity: str = "swift-nio",
        location: str = "https://github.com/apple/swift-nio.git",
    ) -> None:
        package_resolved = {
            "version": 3,
            "pins": [
                {
                    "identity": identity,
                    "kind": "remoteSourceControl",
                    "location": location,
                    "state": {"revision": revision, "version": "2.102.0"},
                }
            ],
        }
        resolved_path = self.project / COLLECT.PACKAGE_RESOLVED
        resolved_path.parent.mkdir(parents=True, exist_ok=True)
        resolved_path.write_text(json.dumps(package_resolved), encoding="utf-8")
        reviewed = {
            "binaryRevisions": {},
            "notices": {
                identity + "/" + relative: {
                    "sha256": self.normalized_hash(text),
                    "license": "Apache-2.0" if relative != "Sources/CNIOLLHTTP/LICENSE" else "MIT",
                }
                for relative, text in notices.items()
            },
        }
        (self.project / "Licenses/review.json").write_text(json.dumps(reviewed), encoding="utf-8")

    def test_resolved_pins_reads_only_the_xcode_workspace_lockfile(self) -> None:
        revision, notices = self.make_package_commit()
        self.write_manifests(revision, notices, identity="swift-nio")
        local_lock = self.project / "Packages/FilaKit/Package.resolved"
        local_lock.parent.mkdir(parents=True)
        local_lock.write_text(json.dumps({
            "version": 3,
            "pins": [{
                "identity": "swift-atomics",
                "kind": "remoteSourceControl",
                "location": "https://github.com/apple/swift-atomics.git",
                "state": {"revision": "a" * 40, "version": "1.3.1"},
            }],
        }), encoding="utf-8")

        pins = COLLECT.resolved_pins(str(self.project))
        self.assertEqual([pin["identity"] for pin in pins], ["swift-nio"])

    def test_missing_checkout_pin_is_skipped_as_inactive_for_this_destination(self) -> None:
        revision, notices = self.make_package_commit()
        self.write_manifests(revision, notices, identity="swift-nio")
        resolved_path = self.project / COLLECT.PACKAGE_RESOLVED
        resolved = json.loads(resolved_path.read_text(encoding="utf-8"))
        inactive_revision = "a" * 40
        resolved["pins"].append({
            "identity": "swift-atomics",
            "kind": "remoteSourceControl",
            "location": "https://github.com/apple/swift-atomics.git",
            "state": {"revision": inactive_revision, "version": "1.3.1"},
        })
        resolved_path.write_text(json.dumps(resolved), encoding="utf-8")

        review_path = self.project / "Licenses/review.json"
        review = json.loads(review_path.read_text(encoding="utf-8"))
        review["notices"]["swift-atomics/LICENSE.txt"] = {
            "sha256": self.normalized_hash("Inactive pinned package license\n"),
            "license": "Apache-2.0",
        }
        review_path.write_text(json.dumps(review), encoding="utf-8")

        entries, active, inactive = COLLECT.package_entries(
            str(self.project), str(self.checkouts)
        )
        self.assertEqual(active, {"swift-nio"})
        self.assertEqual(inactive, {"swift-atomics"})
        self.assertEqual({item["id"] for item in entries}, {"swift-nio/" + path for path in notices})
        COLLECT.validate_review(
            str(self.project), entries,
            pins=COLLECT.resolved_pins(str(self.project)),
            active_identities=active,
        )

    def test_invalid_lockfile_root_type_reports_a_collector_error(self) -> None:
        resolved_path = self.project / COLLECT.PACKAGE_RESOLVED
        resolved_path.parent.mkdir(parents=True, exist_ok=True)
        resolved_path.write_text("[]", encoding="utf-8")

        diagnostic = io.StringIO()
        with contextlib.redirect_stderr(diagnostic):
            with self.assertRaises(SystemExit):
                COLLECT.resolved_pins(str(self.project))
        self.assertIn("must contain a JSON object", diagnostic.getvalue())

    def test_inactive_notice_review_records_are_still_schema_validated(self) -> None:
        revision, notices = self.make_package_commit()
        self.write_manifests(revision, notices, identity="swift-nio")
        resolved_path = self.project / COLLECT.PACKAGE_RESOLVED
        resolved = json.loads(resolved_path.read_text(encoding="utf-8"))
        resolved["pins"].append({
            "identity": "swift-atomics",
            "kind": "remoteSourceControl",
            "location": "https://github.com/apple/swift-atomics.git",
            "state": {"revision": "a" * 40, "version": "1.3.1"},
        })
        resolved_path.write_text(json.dumps(resolved), encoding="utf-8")

        review_path = self.project / "Licenses/review.json"
        review = json.loads(review_path.read_text(encoding="utf-8"))
        review["notices"]["swift-atomics/LICENSE.txt"] = {
            "sha256": "not-a-sha256",
            "license": "Apache-2.0",
        }
        review_path.write_text(json.dumps(review), encoding="utf-8")

        entries, active, _inactive = COLLECT.package_entries(str(self.project), str(self.checkouts))
        diagnostic = io.StringIO()
        with contextlib.redirect_stderr(diagnostic):
            with self.assertRaises(SystemExit):
                COLLECT.validate_review(
                    str(self.project), entries,
                    pins=COLLECT.resolved_pins(str(self.project)),
                    active_identities=active,
                )
        self.assertIn("invalid SHA-256 record for swift-atomics/LICENSE.txt", diagnostic.getvalue())

    def test_repository_workspace_lock_keeps_all_pins_but_does_not_merge_the_package_test_lock(self) -> None:
        pins = COLLECT.resolved_pins(str(ROOT))
        identities = {pin["identity"] for pin in pins}
        self.assertTrue({"swift-atomics", "swift-collections", "swift-system"}.issubset(identities))
        self.assertNotIn("swift-nio", identities)
        self.assertNotIn("swift-nio-transport-services", identities)

    def test_duplicate_pin_identities_fail_even_if_revision_matches(self) -> None:
        revision, notices = self.make_package_commit()
        self.write_manifests(revision, notices, identity="swift-nio")
        resolved_path = self.project / COLLECT.PACKAGE_RESOLVED
        resolved = json.loads(resolved_path.read_text(encoding="utf-8"))
        resolved["pins"].append(resolved["pins"][0])
        resolved_path.write_text(json.dumps(resolved), encoding="utf-8")

        diagnostic = io.StringIO()
        with contextlib.redirect_stderr(diagnostic):
            with self.assertRaises(SystemExit):
                COLLECT.resolved_pins(str(self.project))
        self.assertIn("appears more than once", diagnostic.getvalue())

    def test_checkout_directory_uses_normalized_identity_not_url_casing(self) -> None:
        # SwiftPM normalizes the checkout directory to the Package.resolved
        # identity. The remote URL intentionally keeps mixed-case spelling;
        # those names differ on a case-sensitive filesystem (as in CI).
        self.checkout.rmdir()
        self.checkout = self.checkouts / "alertcontroller"
        self.checkout.mkdir()
        notices = {"LICENSE": "Pinned AlertController license\n"}
        for relative, text in notices.items():
            (self.checkout / relative).write_text(text, encoding="utf-8")
        self.git("init", "-q")
        self.git("config", "user.email", "test@example.invalid")
        self.git("config", "user.name", "License Collector Test")
        self.git("add", ".")
        self.git("commit", "-qm", "Pinned package sources")
        revision = self.git("rev-parse", "HEAD")
        self.write_manifests(
            revision,
            notices,
            identity="alertcontroller",
            location="https://github.com/Lakr233/AlertController",
        )

        entries, active, inactive = COLLECT.package_entries(str(self.project), str(self.checkouts))
        self.assertEqual(active, {"alertcontroller"})
        self.assertEqual(inactive, set())
        self.assertEqual([item["id"] for item in entries], ["alertcontroller/LICENSE"])
        self.assertEqual(entries[0]["text"], notices["LICENSE"])
    def test_missing_worktree_files_are_restored_from_exact_pinned_git_objects(self) -> None:
        revision, notices = self.make_package_commit()
        self.write_manifests(revision, notices)

        # Simulate Xcode's package checkout having incomplete working-tree files
        # while preserving the exact pinned Git object database.
        for relative in notices:
            (self.checkout / relative).unlink()

        entries, active, inactive = COLLECT.package_entries(str(self.project), str(self.checkouts))
        by_id = {item["id"]: item for item in entries}
        self.assertEqual(active, {"swift-nio"})
        self.assertEqual(inactive, set())
        self.assertEqual(set(by_id), {"swift-nio/" + path for path in notices})
        for relative, text in notices.items():
            self.assertEqual(by_id["swift-nio/" + relative]["text"], text)

        # The normal review/hash validation remains mandatory after recovery.
        COLLECT.validate_review(
            str(self.project),
            [COLLECT.entry(item["name"], item.get("version"), item["url"], item["text"]) | {"id": item["id"]} for item in entries],
            pins=COLLECT.resolved_pins(str(self.project)),
            active_identities=active,
        )


    def test_new_unreviewed_notice_still_fails_inventory_validation(self) -> None:
        revision, notices = self.make_package_commit()
        self.write_manifests(revision, notices)
        (self.checkout / "LICENSE-extra.txt").write_text("Unreviewed license notice\n", encoding="utf-8")

        entries, active, inactive = COLLECT.package_entries(str(self.project), str(self.checkouts))
        diagnostic = io.StringIO()
        with contextlib.redirect_stderr(diagnostic):
            with self.assertRaises(SystemExit):
                COLLECT.validate_review(str(self.project), entries)
        self.assertIn("notice inventory changed", diagnostic.getvalue())
        self.assertIn("swift-nio/LICENSE-extra.txt", diagnostic.getvalue())

    def test_refuses_to_restore_from_a_checkout_at_another_revision(self) -> None:
        revision, notices = self.make_package_commit()
        self.write_manifests(revision, notices)
        for relative in notices:
            (self.checkout / relative).unlink()
        (self.checkout / "README.md").write_text("changed working tree revision\n", encoding="utf-8")
        self.git("add", "README.md")
        self.git("commit", "-qm", "Different checkout revision")

        diagnostic = io.StringIO()
        with contextlib.redirect_stderr(diagnostic):
            with self.assertRaises(SystemExit):
                COLLECT.package_entries(str(self.project), str(self.checkouts))
        self.assertIn("does not match Package.resolved", diagnostic.getvalue())


    def test_checkout_revision_is_verified_even_when_worktree_contains_all_notices(self) -> None:
        revision, notices = self.make_package_commit()
        self.write_manifests(revision, notices)
        (self.checkout / "README.md").write_text("another commit\n", encoding="utf-8")
        self.git("add", "README.md")
        self.git("commit", "-qm", "A later checkout revision")

        diagnostic = io.StringIO()
        with contextlib.redirect_stderr(diagnostic):
            with self.assertRaises(SystemExit):
                COLLECT.package_entries(str(self.project), str(self.checkouts))
        self.assertIn("does not match Package.resolved", diagnostic.getvalue())

    def test_source_packages_discovery_walks_up_from_configuration_products(self) -> None:
        derived = self.root / "DerivedData"
        build_dir = derived / "Build" / "Products" / "Release-iphoneos"
        build_dir.mkdir(parents=True)
        (derived / "SourcePackages" / "checkouts").mkdir(parents=True)
        self.assertEqual(
            Path(COLLECT.find_source_packages(str(build_dir))),
            derived / "SourcePackages",
        )

    def test_explicit_source_packages_path_is_used_and_validated(self) -> None:
        derived = self.root / "CustomSwiftPM"
        (derived / "checkouts").mkdir(parents=True)
        self.assertEqual(
            Path(COLLECT.resolve_source_packages(str(self.root / "OtherBuild"), str(derived))),
            derived,
        )

        diagnostic = io.StringIO()
        with contextlib.redirect_stderr(diagnostic):
            with self.assertRaises(SystemExit):
                COLLECT.resolve_source_packages(str(self.root / "OtherBuild"), str(self.root / "missing"))
        self.assertIn("-clonedSourcePackagesDirPath", diagnostic.getvalue())


if __name__ == "__main__":
    unittest.main()
