"""Guard the LaunchServices private API probes against OS-version drift."""

from pathlib import Path
import unittest


ROOT = Path(__file__).resolve().parents[2]
SOURCE = ROOT / "Packages/FilaKit/Sources/FilaApplications/ApplicationCatalog.swift"
MUSIC_BRIDGE = ROOT / "Packages/FilaKit/Sources/CFilaMusicLibrary/NativeMusicLibrary.m"
SCRIPT_RUNTIME = ROOT / "Hoshino/Services/Scripts/ScriptRuntime.swift"
ICON_RENDERER = ROOT / "Frameworks/FilaApplications/ApplicationIconRenderer.swift"
MUSIC_VIEW = ROOT / "Frameworks/FilaMusicLibrary/MusicTrackViewController.swift"
MODE_EDITOR = ROOT / "Hoshino/Interface/Properties/ModeEditorViewController.swift"
MACHO_INSPECTOR = ROOT / "Hoshino/Interface/Viewer/MachO/MachOInspectorViewController.swift"


class LaunchServicesGuardTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.text = SOURCE.read_text(encoding="utf-8")

    def test_workspace_selector_is_checked_before_perform(self):
        block = self.text.split("private static func workspaceApplications()", 1)[1]
        block = block.split("/// Private LaunchServices properties", 1)[0]
        self.assertIn('NSSelectorFromString("allInstalledApplications")', block)
        self.assertIn("workspace.responds(to: selector)", block)
        self.assertIn("workspace.perform(selector)", block)

    def test_private_kvc_reads_share_a_selector_guard(self):
        self.assertIn("private static func kvcValue(_ key: String, from object: NSObject)", self.text)
        helper = self.text.split("private static func kvcValue", 1)[1]
        helper = helper.split("/// Any LaunchServices detail", 1)[0]
        self.assertIn("object.responds(to: selector)", helper)
        self.assertIn("object.value(forKey: key)", helper)
        # Direct KVC is confined to the guarded helper.
        self.assertEqual(self.text.count(".value(forKey:"), 1)

    def test_private_method_signature_probe_handles_missing_type_strings(self):
        source = MUSIC_BRIDGE.read_text(encoding="utf-8")
        self.assertIn("BOOL matches = type && strcmp(type, result) == 0;", source)

    def test_icon_services_private_selectors_are_checked_before_protocol_calls(self):
        source = ICON_RENDERER.read_text(encoding="utf-8")
        self.assertIn('NSSelectorFromString("initWithBundleIdentifier:")', source)
        self.assertIn('NSSelectorFromString("initWithSize:scale:")', source)
        self.assertIn('NSSelectorFromString("prepareImageForDescriptor:")', source)
        self.assertIn('NSSelectorFromString("setShouldApplyMask:")', source)
        self.assertGreaterEqual(source.count("class_respondsToSelector("), 3)
        self.assertIn("iconObject.responds(to: prepareImage)", source)
        self.assertIn("scale.isFinite, scale > 0", source)

    def test_registered_table_cells_use_checked_casts_with_safe_fallbacks(self):
        music = MUSIC_VIEW.read_text(encoding="utf-8")
        mode = MODE_EDITOR.read_text(encoding="utf-8")
        self.assertIn('register(MusicTrackPreviewCell.self, forCellReuseIdentifier: "Preview")', music)
        self.assertNotIn("as! MusicTrackPreviewCell", music)
        self.assertIn("as? MusicTrackPreviewCell", music)
        self.assertIn('register(PermissionGroupCell.self, forCellReuseIdentifier: "Group")', mode)
        self.assertNotIn("as! PermissionGroupCell", mode)
        self.assertIn("as? PermissionGroupCell", mode)

    def test_property_list_dictionary_conversion_does_not_force_unwrap(self):
        source = MACHO_INSPECTOR.read_text(encoding="utf-8")
        self.assertIn("values.keys.sorted().compactMap", source)
        self.assertNotIn("values[$0]!", source)

    def test_commonjs_file_reader_rejects_special_files_without_blocking(self):
        source = SCRIPT_RUNTIME.read_text(encoding="utf-8")
        self.assertIn("O_RDONLY | O_CLOEXEC | O_NOFOLLOW | O_NONBLOCK", source)
        self.assertIn("fstat(handle.fileDescriptor, &status)", source)
        self.assertIn("status.st_mode & S_IFMT == S_IFREG", source)



if __name__ == "__main__":
    unittest.main()
