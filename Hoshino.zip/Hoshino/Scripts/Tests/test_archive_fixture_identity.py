"""Guard external archive fixtures against accidental product-rename edits."""

from __future__ import annotations

import base64
import gzip
import re
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[2]
ARCHIVE_TESTS = ROOT / "Packages/FilaKit/Tests/FilaFormatsTests/ArchiveTests.swift"


class ArchiveFixtureIdentityTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.source = ARCHIVE_TESTS.read_text(encoding="utf-8")

    def _multiline_fixture(self, name: str) -> bytes:
        match = re.search(
            rf"private static let {re.escape(name)} = \"\"\"\s*(.*?)\s*\"\"\"",
            self.source,
            re.DOTALL,
        )
        self.assertIsNotNone(match, f"missing {name} fixture")
        encoded = "".join(match.group(1).split())
        return base64.b64decode(encoded, validate=True)

    def _single_line_fixture(self, name: str) -> bytes:
        match = re.search(
            rf'private static let {re.escape(name)} = "([A-Za-z0-9+/=]+)"',
            self.source,
        )
        self.assertIsNotNone(match, f"missing {name} fixture")
        return base64.b64decode(match.group(1), validate=True)

    def test_external_seven_zip_fixture_keeps_its_original_control_member(self) -> None:
        archive = self._multiline_fixture("sevenZip")
        self.assertIn(b"Package: wiki.qaq.fila\n", archive)
        self.assertIn(
            '#expect(contents["control"] == "Package: wiki.qaq.fila\\n")',
            self.source,
        )

    def test_external_gzip_fixture_and_expectation_match_exactly(self) -> None:
        payload = gzip.decompress(self._single_line_fixture("lonelyGzip"))
        expected = b"Package: wiki.qaq.fila\nVersion: 1.0\n"
        self.assertEqual(payload, expected)
        self.assertIn(
            '== "Package: wiki.qaq.fila\\nVersion: 1.0\\n")',
            self.source,
        )

    def test_generated_package_fixtures_use_hoshino_identifier(self) -> None:
        self.assertIn('Data("Package: com.hoshino.filemanager\\n".utf8)', self.source)
        self.assertIn('== "Package: com.hoshino.filemanager\\n")', self.source)


if __name__ == "__main__":
    unittest.main()
