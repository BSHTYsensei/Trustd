"""Regression tests for build receipts on Git checkouts and ZIP extracts."""
import importlib.util
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest


SCRIPT = Path(__file__).resolve().parents[1] / "build-package-inputs.py"
SPEC = importlib.util.spec_from_file_location("build_package_inputs", SCRIPT)
assert SPEC is not None and SPEC.loader is not None
BUILD_INPUTS = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(BUILD_INPUTS)


class BuildPackageInputsTests(unittest.TestCase):
    def make_source_tree(self, root: Path) -> None:
        (root / "Hoshino").mkdir(parents=True)
        (root / "Hoshino" / "App.swift").write_text("struct App {}\n")
        (root / "Hoshino" / ".hidden-config").write_text("included\n")
        (root / "Hoshino" / ".build" / "artifacts").mkdir(parents=True)
        (root / "Hoshino" / ".build" / "artifacts" / "cache.bin").write_bytes(b"ignored")
        (root / "Hoshino" / "build").mkdir()
        (root / "Hoshino" / "build" / "generated.swift").write_text("ignored\n")
        (root / "Configuration").mkdir()
        (root / "Configuration" / "DeveloperLocal.xcconfig").write_text("ignored\n")
        (root / "Configuration" / "Developer.xcconfig.example").write_text("included\n")
        (root / "Makefile").write_text("all:\n\t@true\n")
        (root / ".gitignore").write_text("**/.build/\nbuild/\nConfiguration/Developer*.xcconfig\n!Configuration/Developer.xcconfig.example\n")

    def test_zip_extract_without_git_uses_filesystem_snapshot(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            self.make_source_tree(root)

            paths = BUILD_INPUTS.source_paths(root)
            relative = {path.relative_to(root).as_posix() for path in paths}

            self.assertIn("Hoshino/App.swift", relative)
            self.assertIn("Hoshino/.hidden-config", relative)
            self.assertIn("Configuration/Developer.xcconfig.example", relative)
            self.assertIn("Makefile", relative)
            self.assertNotIn("Hoshino/.build/artifacts/cache.bin", relative)
            self.assertNotIn("Hoshino/build/generated.swift", relative)
            self.assertNotIn("Configuration/DeveloperLocal.xcconfig", relative)

    def test_archive_snapshot_digest_changes_when_source_changes(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            self.make_source_tree(root)
            first = BUILD_INPUTS.digest(BUILD_INPUTS.source_paths(root), root)
            (root / "Hoshino" / "App.swift").write_text("struct UpdatedApp {}\n")
            second = BUILD_INPUTS.digest(BUILD_INPUTS.source_paths(root), root)
            self.assertNotEqual(first, second)

    def test_git_checkout_includes_tracked_and_nonignored_untracked_files(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            self.make_source_tree(root)
            subprocess.run(["git", "init", "-q", str(root)], check=True)
            subprocess.run(["git", "-C", str(root), "add", "Hoshino/App.swift", "Makefile"], check=True)
            (root / "Hoshino" / "Untracked.swift").write_text("struct NewFile {}\n")

            paths = BUILD_INPUTS.source_paths(root)
            relative = {path.relative_to(root).as_posix() for path in paths}
            self.assertIn("Hoshino/App.swift", relative)
            self.assertIn("Hoshino/Untracked.swift", relative)
            self.assertNotIn("Hoshino/build/generated.swift", relative)

    def test_build_receipt_build_and_verify_work_without_git_metadata(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary) / "source"
            root.mkdir()
            for entry in BUILD_INPUTS.INPUTS:
                path = root / entry
                if entry == "Makefile":
                    path.write_text("all:\n\t@true\n")
                else:
                    path.mkdir(parents=True, exist_ok=True)
                    (path / "input.txt").write_text(f"{entry}\n")
            script = root / "Scripts" / "build-package-inputs.py"
            script.write_bytes(SCRIPT.read_bytes())
            products = Path(temporary) / "products"
            fake_builder = Path(temporary) / "fake_builder.py"
            fake_builder.write_text(
                "import pathlib, sys\n"
                "out = pathlib.Path(sys.argv[1])\n"
                "(out / 'Hoshino.app').mkdir(parents=True, exist_ok=True)\n"
                "(out / 'Hoshino.app' / 'Info.plist').write_text('bundle')\n"
                "(out / 'filad').write_text('daemon')\n"
                "(out / 'fila-archive').write_text('archive')\n"
            )

            build = subprocess.run(
                [sys.executable, str(script), "build", str(products), sys.executable, str(fake_builder), str(products)],
                cwd=root, text=True, capture_output=True,
            )
            self.assertEqual(build.returncode, 0, build.stdout + build.stderr)
            self.assertTrue((products / "FilaBuild.json").is_file())

            verify = subprocess.run(
                [sys.executable, str(script), "verify", str(products)],
                cwd=root, text=True, capture_output=True,
            )
            self.assertEqual(verify.returncode, 0, verify.stdout + verify.stderr)

            (root / "Hoshino" / "input.txt").write_text("changed after build\n")
            stale = subprocess.run(
                [sys.executable, str(script), "verify", str(products)],
                cwd=root, text=True, capture_output=True,
            )
            self.assertNotEqual(stale.returncode, 0)
            self.assertIn("source differs from the last successful build", stale.stderr)

    def test_digest_ignores_local_developer_override_but_tracks_example(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            self.make_source_tree(root)
            previous_root = BUILD_INPUTS.ROOT
            BUILD_INPUTS.ROOT = root
            try:
                first = BUILD_INPUTS.source_digest()
                (root / "Configuration" / "DeveloperLocal.xcconfig").write_text("local change\n")
                self.assertEqual(first, BUILD_INPUTS.source_digest())
                (root / "Configuration" / "Developer.xcconfig.example").write_text("example change\n")
                self.assertNotEqual(first, BUILD_INPUTS.source_digest())
            finally:
                BUILD_INPUTS.ROOT = previous_root

    def test_release_builds_compile_before_swiftpm_harness(self):
        makefile = (SCRIPT.parents[1] / "Makefile").read_text()
        self.assertRegex(makefile, r"(?m)^build: compile harness$")
        self.assertRegex(makefile, r"(?m)^build-sandboxed: compile-sandboxed harness$")
        self.assertRegex(makefile, r"(?m)^tipa: build$")

    def test_xcodebuild_pins_swiftpm_checkouts_under_each_derived_data_path(self):
        makefile = (SCRIPT.parents[1] / "Makefile").read_text()
        self.assertIn(
            '-clonedSourcePackagesDirPath "$(XCODEBUILD_DERIVED_DATA)/SourcePackages"',
            makefile,
        )
        project = (SCRIPT.parents[1] / "Hoshino.xcodeproj/project.pbxproj").read_text()
        self.assertEqual(project.count('--source-packages "$BUILD_DIR/../../SourcePackages"'), 2)
        self.assertIn('python3 -u "$SRCROOT/Scripts/collect-licenses.py"', project)


if __name__ == "__main__":
    unittest.main()
