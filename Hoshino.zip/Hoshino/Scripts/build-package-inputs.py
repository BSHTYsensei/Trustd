#!/usr/bin/env python3
"""Bind packaging to a successful build of the current source and exact outputs."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent.parent
INPUTS = ["Hoshino", "Frameworks", "Filad", "FilaArchive", "FilaSaveAction", "Hoshino.xcodeproj", "Configuration", "Packaging", "Licenses", "Scripts", "Packages/FilaKit", "Makefile"]
# The full composition's products. The sandboxed composition builds Hoshino.app
# alone into its own directory and names that with `--products Hoshino.app`.
PRODUCTS = ["Hoshino.app", "filad", "fila-archive"]


def digest(paths, base):
    result = hashlib.sha256()
    for path in sorted(paths):
        result.update(os.fsencode(str(path.relative_to(base))) + b"\0")
        if path.is_symlink():
            result.update(b"link\0" + os.fsencode(os.readlink(path)))
        elif path.is_file():
            result.update(f"{path.stat().st_mode & 0o777:o}\0".encode())
            with path.open("rb") as stream:
                while block := stream.read(1024 * 1024):
                    result.update(block)
        else:
            raise ValueError(f"missing build input: {path}")
        result.update(b"\0")
    return result.hexdigest()


IGNORED_DIRECTORY_NAMES = {
    ".git", ".build", ".swiftpm", "DerivedData", "build", "xcuserdata",
    "__pycache__", ".pytest_cache", ".mypy_cache", ".ruff_cache",
    ".venv", "venv", ".claude", ".cursor", ".vscode", "generated",
}
IGNORED_FILE_NAMES = {".DS_Store", "TODO.md"}
IGNORED_SUFFIXES = {".xcuserstate", ".hmap", ".pyc", ".pyo", ".pyd", ".swp"}


def is_ignored_source_path(relative, is_directory=False):
    """Approximate the repository's .gitignore rules for extracted ZIP sources."""
    parts = relative.parts
    name = relative.name
    if any(part in IGNORED_DIRECTORY_NAMES for part in parts[:-1] if not is_directory):
        return True
    if is_directory and name in IGNORED_DIRECTORY_NAMES:
        return True
    if name in IGNORED_FILE_NAMES or name.endswith("~"):
        return True
    if Path(name).suffix in IGNORED_SUFFIXES:
        return True
    if name.endswith(".dSYM") or name.endswith(".dSYM.zip") or name.endswith(".ipa") or name.endswith("$py.class"):
        return True
    if parts and parts[0] == "Configuration" and name.startswith("Developer") and name.endswith(".xcconfig") and name != "Developer.xcconfig.example":
        return True
    return False


def filesystem_source_paths(base):
    """Enumerate build inputs when the source was unpacked from Hoshino.zip.

    A source archive has no .git directory, so `git ls-files` cannot be used.
    This walker mirrors the relevant standard ignore rules while retaining
    hidden source files and symlink entries. Symlinked directories are hashed
    as links and are never traversed.
    """
    selected = set()
    for entry in INPUTS:
        root = base / entry
        if root.is_symlink() or root.is_file():
            if not is_ignored_source_path(root.relative_to(base), root.is_dir()):
                selected.add(root)
            continue
        if not root.is_dir():
            continue
        for current, directory_names, file_names in os.walk(root, topdown=True, followlinks=False):
            current_path = Path(current)
            retained_directories = []
            for directory_name in directory_names:
                candidate = current_path / directory_name
                relative = candidate.relative_to(base)
                if is_ignored_source_path(relative, is_directory=True):
                    continue
                if candidate.is_symlink():
                    selected.add(candidate)
                    continue
                retained_directories.append(directory_name)
            directory_names[:] = retained_directories
            for file_name in file_names:
                candidate = current_path / file_name
                relative = candidate.relative_to(base)
                if is_ignored_source_path(relative, is_directory=False):
                    continue
                if candidate.is_file() or candidate.is_symlink():
                    selected.add(candidate)
    return selected


def source_paths(base):
    """Return all source inputs from Git or from a plain extracted source tree."""
    try:
        repository = subprocess.run(
            ["git", "rev-parse", "--is-inside-work-tree"],
            cwd=base,
            stdout=subprocess.PIPE,
            stderr=subprocess.DEVNULL,
            check=False,
        )
        if repository.returncode == 0 and repository.stdout.strip() == b"true":
            names = subprocess.check_output(
                ["git", "ls-files", "-z", "--cached", "--others", "--exclude-standard", "--", *INPUTS],
                cwd=base,
            ).split(b"\0")
            return {base / os.fsdecode(name) for name in names if name}
    except (OSError, subprocess.CalledProcessError):
        # ZIP extracts and source snapshots do not contain Git metadata.
        pass
    return filesystem_source_paths(base)


def source_digest():
    paths = source_paths(ROOT)
    # Submodule contents are build inputs too, including local edits.
    expanded = set()
    for path in paths:
        if path.is_dir() and not path.is_symlink():
            expanded.update(p for p in path.rglob("*") if (p.is_file() or p.is_symlink()) and not is_ignored_source_path(p.relative_to(ROOT), p.is_dir()))
        elif path.exists() or path.is_symlink():
            expanded.add(path)
    expanded.update(
        path for path in (ROOT / "Configuration").glob("*.xcconfig")
        if not is_ignored_source_path(path.relative_to(ROOT), is_directory=False)
    )
    return digest(expanded, ROOT)


def product_digest(directory, products):
    paths = []
    for name in products:
        path = directory / name
        if not path.exists():
            raise ValueError(f"missing build product: {path}")
        if path.is_dir():
            paths.extend(p for p in path.rglob("*") if p.is_file() or p.is_symlink())
        else:
            paths.append(path)
    return digest(paths, directory)


def main():
    arguments = sys.argv[1:]
    products = PRODUCTS
    if arguments[:1] == ["--products"]:
        if len(arguments) < 2 or not arguments[1]:
            raise ValueError("--products needs a comma-separated list")
        products = arguments[1].split(",")
        arguments = arguments[2:]
    if len(arguments) < 2 or arguments[0] not in ("build", "verify"):
        raise ValueError("usage: build-package-inputs.py [--products a,b] build <products> <build command...> | verify <products>")
    mode, directory = arguments[0], Path(arguments[1]).resolve()
    receipt = directory / "FilaBuild.json"
    if mode == "build":
        if len(arguments) < 3:
            raise ValueError("missing build command")
        receipt.unlink(missing_ok=True)
        source = source_digest()
        subprocess.run(arguments[2:], check=True, cwd=ROOT)
        if source_digest() != source:
            raise ValueError("build inputs changed during compilation; rebuild before packaging")
        value = {"source": source, "products": product_digest(directory, products), "names": products}
        temporary = receipt.with_suffix(f".tmp.{os.getpid()}")
        try:
            temporary.write_text(json.dumps(value, indent=2) + "\n")
            temporary.replace(receipt)
        finally:
            temporary.unlink(missing_ok=True)
        print("Recorded verified build inputs and product hashes.")
    else:
        if len(arguments) != 2:
            raise ValueError("unexpected verification arguments")
        if not receipt.is_file():
            raise ValueError("no successful build receipt; run make build before packaging")
        receipt_bytes = receipt.read_bytes()
        value = json.loads(receipt_bytes)
        if value.get("source") != source_digest():
            raise ValueError("source differs from the last successful build; rebuild before packaging")
        if value.get("names", PRODUCTS) != products:
            raise ValueError(f"the receipt covers {value.get('names', PRODUCTS)}, not {products}; this directory holds the other composition")
        if value.get("products") != product_digest(directory, products):
            raise ValueError("build products changed after compilation; rebuild before packaging")
        print(hashlib.sha256(receipt_bytes).hexdigest())


if __name__ == "__main__":
    try:
        main()
    except (ValueError, OSError, subprocess.CalledProcessError) as error:
        sys.exit(f"error: {error}")
