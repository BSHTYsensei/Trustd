# 逆向静态线索 → Hoshino 模块映射

这份映射只用于说明参考关系。源逆向报告注明没有连接设备进行动态 UI 验证，因此不对 Filza 原版实际交互做额外推断。

| 逆向文件 / 类 | 线索主题 | Hoshino 独立实现 |
|---|---|---|
| `FileItem.h` | 文件项、隐藏、链接和元信息 | `Models/FileSystemModels.swift`、`UI/Browser/FileBrowserView.swift` |
| `TGFileSystemListViewController.h` | 浏览、排序、复制/移动/重命名/删除/废纸篓 | `UI/Browser/FileBrowserView.swift`、`Services/FileSystemService.swift` |
| `TGRootFileManager.h`, `TGLocalFileManager.h` | 本地文件管理、符号链接/硬链接 API 线索 | `Services/FileSystemService.swift`（当前 UI 提供符号链接，不提供硬链接） |
| `FavoritesTableViewController.h`, `AddLinkViewController.h` | 收藏和自定义路径快捷入口 | `Models/FavoritesStore.swift`、`UI/Settings/FavoritesView.swift` |
| `SymbolicLinkViewController.h` | 符号链接创建界面 | `UI/Browser/FileBrowserView.swift` 的 SymbolicLinkSheet |
| `TGFastTextEditViewController.h`, `TGTextEditorController.h` | 文本编辑、查找、保存 | `UI/Editors/TextFileEditorView.swift` |
| `TGTextOrHexEditorViewController.h`, `TGHexEditorViewController.h` | 文本/十六进制切换、地址跳转和字节搜索 | `UI/Editors/HexEditorView.swift` |
| `TGPlistViewController.h`, `TGPlistNaviViewController.h` | Plist root、format、树节点、添加和保存 | `Models/PlistNode.swift`、`UI/Editors/PlistEditorView.swift` |
| `TGImageViewerController.h` | 图片查看 | `UI/Editors/MediaPreviewViews.swift` |
| `TGVideoPlayerViewController.h` | 视频播放 | `MediaPreviewViews.swift`（AVPlayer 本地播放） |
| `QuickLookViewerController.h` | Quick Look 预览 | `MediaPreviewViews.swift` |
| `ViewersSelectionTableViewController.h`, `ViewerPrefsTableViewController.h`, `ExternalViewersViewController.h` | 按扩展名选择默认查看器 | `Models/EditorAssociation.swift`、`UI/Settings/EditorAssociationSettingsView.swift` |
| `FileAttributes.h`, `PermissionSetting.h` | 文件属性、权限 | `UI/Details/FileDetailsView.swift`、`Services/FileSystemService.swift` |
| `TGFileSystemInfoViewController.h` | 文件系统容量 | `StorageInfoView` |
| `Zipper.h`, `ZipViewController.h` | 压缩/解压和归档浏览 | `Services/ArchiveService.swift`、`UI/Editors/ArchiveBrowserView.swift`（当前只内置普通 ZIP） |

## 独立实现的重点

Plist 编辑器走 Foundation `PropertyListSerialization` 数据模型：读取 XML/Binary 格式后转换为 `PlistNode` 树；编辑完成后再转换回 Property List 对象，并按打开时的格式保存。Plist round-trip 测试位于 `Tests/PlistNodeRoundTrip.swift`。

编辑器关联是本地 UserDefaults 配置，每个扩展名映射到 `EditorKind`；它没有调用 Filza 原始 viewer 插件或复制其 UI 资源。
